﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MessagesInABottle
{
    public struct CipherElement
    {
        public char letter;
        public string digits;

        public CipherElement(char letter, string numbers)
        {
            this.letter = letter;
            this.digits = numbers;
        }
    }

    public struct DecodingState
    {
        public string decodedString;
        public string remainingEncodedString;

        public DecodingState(string decodedString, string remainingEncodedString)
        {
            this.decodedString = decodedString;
            this.remainingEncodedString = remainingEncodedString;
        }
    }

    class MessagesInABottle
    {
        static void Main(string[] args)
        {
            string encodedString = Console.ReadLine();
            string cipher = Console.ReadLine();

            // split cipher to its elements
            List<CipherElement> cipherElements = CipherElements(cipher);

            // decoding
            List<string> decodedStrings = new List<string>();

            List<DecodingState> decodingStates = new List<DecodingState>();
            decodingStates.Add(new DecodingState("", encodedString));

            int decodingStatesIndex = 0;
            while (decodingStatesIndex < decodingStates.Count)
            {
                DecodingState currentState = decodingStates[decodingStatesIndex];
                decodingStatesIndex++;
                foreach (CipherElement cipherElement in cipherElements)
                {
                    if (currentState.remainingEncodedString.StartsWith(cipherElement.digits))
                    {
                        DecodingState state = new DecodingState();
                        state.decodedString = currentState.decodedString + cipherElement.letter;
                        state.remainingEncodedString = currentState.remainingEncodedString.Remove(0, cipherElement.digits.Length);

                        if (state.remainingEncodedString == string.Empty)
                        {
                            decodedStrings.Add(state.decodedString);
                        }
                        else
                        {
                            decodingStates.Add(state);
                        }
                    }
                }
            }

            decodedStrings.Sort();

            Console.WriteLine(decodedStrings.Count);
            foreach (string decodedString in decodedStrings)
            {
                Console.WriteLine(decodedString);
            }
        }

        public static List<CipherElement> CipherElements(string cipher)
        {
            List<CipherElement> cipherElements = new List<CipherElement>();

            string[] letters = Regex.Split(cipher, "[0-9]+");
            string[] digits = Regex.Split(cipher, "[A-Z]+");

            for (int i = 0; i < letters.Length - 1; i++)
            {
                cipherElements.Add(new CipherElement(letters[i][0], digits[i + 1]));
            }

            return cipherElements;
        }
    }
}
