﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tubes
{
    class Tubes
    {
        static void Main(string[] args)
        {
            int tubesCount = int.Parse(Console.ReadLine());
            int neededTubesCount = int.Parse(Console.ReadLine());
            int maxLength = -1;

            int[] tubes = new int[tubesCount];

            for (int i = 0; i < tubesCount; i++)
            {
                tubes[i] = int.Parse(Console.ReadLine());
            }

            // binary search to find the maximal length of the needed tubes
            int currentMinLength = 0; // left range limit
            int currentMaxLength = 2000000000; // right range limit from the task description (or we can get the tube with maximal length)
            int currentLength = (currentMinLength + currentMaxLength) / 2; // center of the range, which is used in the search
            int currentTubesCount = 0; // how many tubes can we cut with the currentLength

            while (currentMinLength <= currentMaxLength)
            {
                currentTubesCount = 0;

                for (int i = 0; i < tubes.Length; i++)
                {
                    currentTubesCount += tubes[i] / currentLength;
                }

                if (currentTubesCount >= neededTubesCount)
                {
                    currentMinLength = currentLength + 1;
                    maxLength = currentLength;
                }
                else
                {
                    currentMaxLength = currentLength - 1;
                }

                currentLength = (currentMinLength + currentMaxLength) / 2;
            }

            Console.WriteLine(maxLength);
        }
    }
}
