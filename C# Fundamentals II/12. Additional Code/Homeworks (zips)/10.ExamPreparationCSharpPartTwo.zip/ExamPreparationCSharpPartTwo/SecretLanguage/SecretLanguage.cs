﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecretLanguage
{
    class SecretLanguage
    {
        static void Main()
        {
            string sentence = Console.ReadLine();
            string words = Console.ReadLine();
            string[] validWords = words.Split(new char[] { ' ', ',', '\"' }, StringSplitOptions.RemoveEmptyEntries);

            Console.WriteLine(CalculateCost(sentence, validWords));
        }

        public static int CalculateCost(string sentence, string[] validWords)
        {
            // sort the valid words alphabetically
            string[] validSortedWords = new string[validWords.Length];
            for (int i = 0; i < validWords.Length; i++)
            {
                char[] wordAsChars = validWords[i].ToCharArray();
                Array.Sort(wordAsChars);
                validSortedWords[i] = new string(wordAsChars);
            }

            // create table with minimal costs for each word in the sentence
            int[] minimalCosts = new int[sentence.Length + 1];
            for (int i = 0; i < sentence.Length; i++)
            {
                minimalCosts[i + 1] = 999999;
            }

            // calculate cost for each word in the sentence
            for (int i = 0; i < sentence.Length; i++)
            {
                for (int j = 0; j < validWords.Length; j++)
                {
                    // if there is a valid word with the same length as the current word
                    if (i + 1 >= validWords[j].Length)
                    {
                        // get current word and sort it
                        string currentWord = sentence.Substring(i - validWords[j].Length + 1, validWords[j].Length);
                        char[] currentWordAsChars = currentWord.ToCharArray();
                        Array.Sort(currentWordAsChars);
                        string sortedCurrentWord = new string(currentWordAsChars);

                        // compare the current sorted word with all valid sorted words and if they are equal - calculate the cost for the current word
                        if (sortedCurrentWord == validSortedWords[j])
                        {
                            int currentCost = 0;
                            for (int k = 0; k < validWords[j].Length; k++)
                            {
                                if (currentWord[k] != validWords[j][k])
                                {
                                    currentCost++;
                                }
                            }

                            minimalCosts[i + 1] = Math.Min(minimalCosts[i + 1], minimalCosts[i + 1 - validWords[j].Length] + currentCost);
                        }
                    }
                }
            }

            return minimalCosts[sentence.Length] < 999999 ? minimalCosts[sentence.Length] : -1;
        }
    }
}
