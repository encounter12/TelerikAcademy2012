using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Telerik
{
    class EgaTi
    {
        static void Main(string[] args)
        {
            Task1();
            Task2();
            Task3();
        }
 
        private static void Task3()
        {
            var sp = Console.ReadLine().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
            var k = 0;
            do
            {
                if (sp[0] < sp[3])
                {
                    if (ConvertToGold(sp) == -1)
                    {
                        if (ConvertToSilver(sp) == -1)
                        {
                            Console.WriteLine(-1);
                            return;
                        }
                    }
                    k++;
                }
                if (sp[1] < sp[4])
                {
                    if (ConvertToSilver(sp) == -1)
                        if (ConvertToSilverG(sp) == -1)
                        {
                            Console.WriteLine(-1);
                            return;
                        }
 
                    k++;
                }
                if (sp[2] < sp[5])
                {
                    if (ConvertToBronze(sp) == -1)
                        if (ConvertToSilver(sp) == -1)
                            if (ConvertToSilverG(sp) == -1)
                            {
                                Console.WriteLine(-1);
                                return;
                            }
                    k++;
                }
                if (sp[3] <= sp[0] && sp[4] <= sp[1] && sp[5] <= sp[2]) break;
            } while (true);
            Console.WriteLine(k );
        }
 
        private static int ConvertToBronze(int[] sp)
        {
            if (sp[1] < 1)
                return -1;
            sp[1] -= 1;
            sp[2] += 11;
            return 0;
        }
 
        private static int ConvertToSilverG(int[] sp)
        {
            if (sp[0] < 1) return -1;
            sp[1] += 11;
            sp[0] -= 1;
            return 0;
        }
 
        private static int ConvertToSilver(int[] sp)
        {
            if (sp[2] < 9) return -1;
            sp[1] += 1;
            sp[2] -= 9;
            return 0;
        }
 
        private static int ConvertToGold(int[] sp)
        {
            if (sp[1] < 9) return -1;
            sp[0] += 1;
            sp[1] -= 9;
            return 0;
        }
 
        private static void Task2()
        {
            var sp = Console.ReadLine().Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).OrderByDescending(x => x).ToArray();
            var fr = int.Parse(Console.ReadLine());
            int mee = 0;
            for (int i = 0; i < sp.Length; i += fr + 1) mee += sp[i];
            Console.WriteLine(mee);
 
        }
 
        private static void Task1()
        {
            var sp = Console.ReadLine().Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
            var max = int.MinValue;
            var maxI = -1;
            var d21 = -1;
            for (int i = 0; i < sp.Length; i++)
            {
                if (sp[i] > max)
                {
                    max = sp[i];
                    maxI = i;
                }
                if (sp[i] == 21)
                    if (d21 == -1) d21 = i;
                    else
                    {
                        Console.WriteLine(-1);
                        return;
                    }
            }
            if (d21 != -1) Console.WriteLine(d21);
            else if (Array.IndexOf(sp, max, maxI + 1) == -1)
                Console.WriteLine(maxI);
            else
                Console.WriteLine(-1);
        }
    }
}