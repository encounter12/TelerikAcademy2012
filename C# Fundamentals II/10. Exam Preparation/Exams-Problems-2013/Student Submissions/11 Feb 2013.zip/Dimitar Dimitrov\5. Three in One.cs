using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        string inputBlackjack = "20, 20, 19, 12, 21";
        string[] arrayBlack = inputBlackjack.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        Array.Sort(arrayBlack);
        int[] arrB = new int[arrayBlack.Length];
        for (int i = 0; i < arrB.Length; i++)
        {
            arrB[i] = int.Parse(arrayBlack[i]);
        }
        if (arrB[0] <= 21)
        {
            if (arrB[0] == arrB[1])
            {
                Console.WriteLine(-1);
            }
            Console.WriteLine(0);
        }
        else 
        {
            Console.WriteLine(-1);
        }
    }

}
