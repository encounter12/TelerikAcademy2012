using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // 5. Three in One

        // Input
        string firstTask = Console.ReadLine();
        string secondTask = Console.ReadLine();
        string secondTask2 = Console.ReadLine();
        string thirdTask = Console.ReadLine();

        // Solution
        SolveFirstTask(firstTask);
        SolveSecondTask(secondTask, secondTask2);
        SolveThirdTask(thirdTask);
    }

    private static void SolveThirdTask(string thirdTask)
    {
        string[] input = thirdTask.Split(' ');
        int gold = int.Parse(input[0]);
        int silver = int.Parse(input[1]);
        int bronze = int.Parse(input[2]);
        int goldNeeded = int.Parse(input[3]);
        int silverNeeded = int.Parse(input[4]);
        int bronzeNeeded = int.Parse(input[5]);

        if (gold >= goldNeeded && silver >= silverNeeded && bronze >= bronzeNeeded)
        {
            Console.WriteLine("0");
        }
        else
        {
            Console.WriteLine(-1);
        }
    }

    private static void SolveSecondTask(string input, string friendsStr)
    {
        // Bites of cake
        int friends = int.Parse(friendsStr);

        string[] cakeBitesStr = input.Split(',');
        List<int> cakeBites = new List<int>();
        for (int i = 0; i < cakeBitesStr.Length; i++)
        {
            cakeBitesStr[i] = cakeBitesStr[i].Trim();
            cakeBites.Add(int.Parse(cakeBitesStr[i]));
        }

        cakeBites.Sort();
        int eatenBites = 0;

        for (int i = cakeBites.Count - 1; i >= 0; i--)
        {
            eatenBites += cakeBites[i];
            i -= friends;
        }

        Console.WriteLine(eatenBites);
    }

    private static void SolveFirstTask(string input)
    {
        // Blackjack

        string[] pointsStr = input.Split(',');
        List<int> points = new List<int>();
        for (int i = 0; i < pointsStr.Length; i++)
        {
            pointsStr[i] = pointsStr[i].Trim();
            points.Add(int.Parse(pointsStr[i]));
        }

        points.Sort();

        int winnerPoints = 0;
        for (int i = 0; i < points.Count; i++)
        {
            if (points[i] > 21)
            {
                winnerPoints = points[i - 1];
                break;
            }
            else
            {
                winnerPoints = points[i];
            }
        }

        int winners = 0;
        int winnerIndex = 0;
        for (int i = 0; i < pointsStr.Length; i++)
        {
            if (int.Parse(pointsStr[i]) == winnerPoints)
            {
                winners++;
                winnerIndex = i;
            }

        }

        if (winners == 1)
        {
            Console.WriteLine(winnerIndex);
        }
        else
        {
            Console.WriteLine("-1");
        }
    }
}