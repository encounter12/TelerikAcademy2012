using System;

namespace Problem1
{
	class Problem1
	{
		static void Main()
		{
			string[] digits = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
			string gag = Console.ReadLine();
			decimal result = 0;

			int position = 0;
			decimal pow = 1;
			string tmpGag = string.Empty;
			while (position < gag.Length)
			{
				int maxLength = 0;
				int digit = 0;
				for (int i = 0; i < 9; i++)
				{
					if ((gag.Length - position - digits[i].Length) >= 0)
						tmpGag = gag.Substring(gag.Length - position - digits[i].Length, digits[i].Length);
					else
						tmpGag = string.Empty;
					int tmpPos = tmpGag.LastIndexOf(digits[i]);
					if (tmpPos == 0)
					{
						if (maxLength <= digits[i].Length && (gag.Length - position > 1))
						{
							maxLength = digits[i].Length;
							digit = i;
						}
					}
				}
				result += digit * pow;
				position += digits[digit].Length;
				pow *= 9;
			}
			Console.WriteLine(result);
		}
	}
}
