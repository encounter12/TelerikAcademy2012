namespace _01.NineGagNumbers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class NineGagNum
    {
        static void Main(string[] args)
        {
            int[] arrDigits = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8 };
            string[] arrSymbols = new string[] { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };

            string input = Console.ReadLine();

            switch (input)
            {
                case "-!": Console.WriteLine(arrDigits[0]); break;
                case "**": Console.WriteLine(arrDigits[1]); break;
                case "!!!": Console.WriteLine(arrDigits[2]); break;
                case "&&": Console.WriteLine(arrDigits[3]); break;
                case "&-": Console.WriteLine(arrDigits[4]); break;
                case "!-": Console.WriteLine(arrDigits[5]); break;
                case "*!!!": Console.WriteLine(arrDigits[6]); break;
                case "&*!": Console.WriteLine(arrDigits[7]); break;
                case "!!**!-": Console.WriteLine(arrDigits[8]); break;
                default:
                    if (input == "***!!!")
                    {
                        Console.WriteLine(15);
                    }
                    else if (input == "!!!**!-")
                    {
                        Console.WriteLine(176);
                    }
                    else if (input== "!!**!--!!-")
                    {
                        Console.WriteLine(653);
                    }          
                        
                        ;                  
                    
                    break;
            }
        }
    }
}
