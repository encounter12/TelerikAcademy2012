using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] SortArray = new int[200];
            Console.WriteLine("Enter number of players?");
            int NumberCount = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(" ");
            Console.WriteLine("\nEnter their scores\n");
            for (int i = 0; i < NumberCount; i++)
            {
                SortArray[i] = Convert.ToInt32(Console.ReadLine());
                if (SortArray[i] > 21)
                {
                    Console.WriteLine("player {0} looses", i+1);
                    continue;
                }
            }
            int min;
            for (int q = 0; q < NumberCount - 1; q++)
            {
                min = q;
                for (int i = q + 1; i < NumberCount; i++)
                {
                    if (SortArray[min] > SortArray[i])
                        min = i;
                }
                if (min != q)
                {
                    int k = SortArray[q];
                    SortArray[q] = SortArray[min];
                    SortArray[min] = k;
                }
            }
            Console.WriteLine(" ");
            Console.WriteLine("Selection Sort Results: ");
            for (int j = 0; j < NumberCount; j++)
                if (SortArray[j] == 21)
                {
                    Console.WriteLine(0);
                }
        }
    }
}