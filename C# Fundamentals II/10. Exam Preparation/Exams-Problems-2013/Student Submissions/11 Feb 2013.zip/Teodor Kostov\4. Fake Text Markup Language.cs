using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_4
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string output =  input.ToUpper();
            Console.WriteLine(output);
        }
    }
}
