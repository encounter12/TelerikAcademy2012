using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    public static string[] Digits = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };


    static int NineGagTest(string numbers)
    {
        StringBuilder sb = new StringBuilder();
        int multiplier = 0;
        int finalResult = 0;
        List<string> testList = new List<string>();
        while (numbers.Length > 0)
        {
            for (int i = 0; i < Digits.Length; i++)
            {
                if (Digits[i].Length > numbers.Length)
                {
                    continue;
                }
                else
                {
                    sb.Append(numbers.Substring(0, Digits[i].Length));
                    string testString = sb.ToString();
                    if (testString.Contains(Digits[i]))
                    {
                            testList.Add(testString);
                            numbers = numbers.Remove(0, testString.Length);
                            sb.Clear();
                            break;
                    }
                    sb.Clear();
                }
                
            }
        }
        for (int i = testList.Count - 1; i >= 0; i--)
        {
            for (int j = 0; j < Digits.Length; j++)
            {
                if (testList[i].Equals(Digits[j]))
                {
                    if (multiplier == 0)
                    {
                        finalResult += j;
                        multiplier++;
                    }
                    else if (multiplier > 0)
                    {
                        finalResult += j * (int)(Math.Pow(9.0, multiplier));
                        multiplier++;
                    }
                }
            }
        }
        return finalResult;
    }

    static void Main()
    {
        string blabla = Console.ReadLine();
        int result = NineGagTest(blabla);
        Console.WriteLine(result);
    }
}
