using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace _01._9Gag_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputChars = Console.ReadLine();//"***!!!";

            string zero = "-!";
            string one = "**";
            string two = "!!!";
            string three = "&&";
            string four = "&-";
            string five = "!-";
            string six = "*!!!";
            string seven = "&*!";
            string eight = "!!**!-";

            StringBuilder currentBuild = new StringBuilder();
            List<int> digitsInLine = new List<int>();
            if (inputChars.Length > 0)
            {
                for (int i = 0; i < inputChars.Length; i++)
                {
                    currentBuild.Append(inputChars[i]);

                    if (currentBuild.ToString() == zero)
                    {
                        digitsInLine.Add(0);
                        currentBuild.Clear();
                    }
                    if (currentBuild.ToString() == one)
                    {
                        digitsInLine.Add(1);
                        currentBuild.Clear();
                    }
                    if (currentBuild.ToString() == two)
                    {
                        digitsInLine.Add(2);
                        currentBuild.Clear();
                    }
                    if (currentBuild.ToString() == three)
                    {
                        digitsInLine.Add(3);
                        currentBuild.Clear();
                    }
                    if (currentBuild.ToString() == four)
                    {
                        digitsInLine.Add(4);
                        currentBuild.Clear();
                    } if (currentBuild.ToString() == five)
                    {
                        digitsInLine.Add(5);
                        currentBuild.Clear();
                    }
                    if (currentBuild.ToString() == six)
                    {
                        digitsInLine.Add(6);
                        currentBuild.Clear();
                    }
                    if (currentBuild.ToString() == seven)
                    {
                        digitsInLine.Add(7);
                        currentBuild.Clear();
                    }
                    if (currentBuild.ToString() == eight)
                    {
                        digitsInLine.Add(8);
                        currentBuild.Clear();
                    }
                }
            }

            //if (inputChars.Length > 0)
            //{
            //    BigInteger sumInDec = 0;
            //    for (int i = digitsInLine.Count - 1; i >= 0; i--)
            //    {
            //        sumInDec += digitsInLine[i] *
            //            (BigInteger)Math.Pow(9, digitsInLine.Count - 1 - i);
            //    }
            //    Console.WriteLine(sumInDec);
            //}
            //int power = 1;
            if (inputChars.Length > 0)
            {
                BigInteger sumInDec = 0;
                BigInteger result = 1;
                for (int i = digitsInLine.Count - 1; i >= 0; i--)
                {
                    sumInDec += digitsInLine[i] *result;
                    result = result * 9;
                }
                Console.WriteLine(sumInDec);
            }

        }
    }
}
