using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class SpecialValue
{
    static List<Coords> visited = new List<Coords>();
    class Coords
    {
        public int row;
        public int colum;
        public Coords()
        {

        }
        public Coords(int y, int x)
        {
            this.row = y;
            this.colum = x;
        }
    }
    static int TryPath(Coords pos, int pathTillNow, List<Coords> hops, int[][] matrix)
    {
        int matValue = matrix[pos.row][pos.colum];
        if (hops.Contains(pos))
        {
            return 0;
        }
        hops.Add(pos);
        visited.Add(pos);
        if (matValue < 0)
        {
            return pathTillNow + Math.Abs(matValue);
        }
        if (pos.row == matrix.Length - 1)
        {
            pos.row = -1;
        }
        Coords newpos = new Coords();
        newpos.row = pos.row + 1;
        newpos.colum = matValue;
        return TryPath(newpos, pathTillNow + 1, hops, matrix);

    }
    static void Main()
    {
        int rows = int.Parse(Console.ReadLine());
        int[][] matrix = new int[rows][];
        List<int> tempList = new List<int>();
        long maxValue = 0;
        for (int i = 0; i < rows; i++)
        {
            foreach (string num in Console.ReadLine().Split(','))
            {
                tempList.Add(int.Parse(num));
            }
            matrix[i] = tempList.ToArray();
            tempList.Clear();
        }
        int temp;
        int currDim = 0;
        Coords tempCoords = new Coords();
        currDim = matrix[0].Length;
        for (int j = 0; j < currDim; j++)
        {
            tempCoords = new Coords(0, j);
            if (!visited.Contains(tempCoords))
            {
                temp = TryPath(tempCoords,0,new List<Coords>(),matrix);
                if (maxValue < temp)
                {
                    maxValue = temp;
                }
            }
        }
        Console.WriteLine(maxValue + 1);
    }
}