using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{

    static void Main()
    {
        //string signs = "-! ** !!! && &- !- *!!! &*! !!**!-";
        //string[] words = signs.Split(' ');
        string input = Console.ReadLine();


        for (int i = 0; i < 9; i++)
        {

            switch (input)
            {
                case "-!": input = "0";
                    break;
                case "**": input = "1";
                    break;
                case "!!!": input = "2";
                    break;
                case "&&": input = "3";
                    break;
                case "&-": input = "4";
                    break;
                case "!-": input = "5";
                    break;
                case "*!!!": input = "6";
                    break;
                case "&*!": input = "7";
                    break;
                case "!!**!-": input = "8";
                    break;
                default:
                    break;
            }
        }
        Console.Write(ConvertToType(input, 9));
    }

    public static int ConvertToType(string nineGag, int dec)
    {
        string stringNumber = nineGag.ToString();

        int count = stringNumber.Length - 1;
        int result = 0;
        for (int i = 0; i < stringNumber.Length; i++)
        {
            result = result + int.Parse(stringNumber[i].ToString()) * (int)(Math.Pow(dec, count));
            count--;
        }
        return result;
    }
}