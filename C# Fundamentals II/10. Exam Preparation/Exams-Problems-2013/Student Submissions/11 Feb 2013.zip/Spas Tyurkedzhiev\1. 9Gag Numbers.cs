using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
    class Number
    {
        public static readonly String NULL = "-!";
        public static readonly String ONE = "**";
        public static readonly String TWO = "!!!";
        public static readonly String THREE = "&&";
        public static readonly String FOUR = "&-";
        public static readonly String FIVE = "!-";
        public static readonly String SIX = "*!!!";
        public static readonly String SEVEN = "&*!";
        public static readonly String EIGHT = "!!**!-";
    }
    class Program
    {
        static void Main(string[] args)
        {
          
            long suma = 0;
            string number = Console.ReadLine();
            int grade = 0;
            do
            {
                int digit = Get(number);
                number = Remove(digit, number);
                long multiplier = (long)Math.Pow(9, grade);
                suma =suma+ (digit * multiplier);
                grade++;
            }
            while (number.Length != 0);
            Console.WriteLine(suma);
        }

        public static String Remove(int d, String number)
        {
            string temp1 = null;
            if (d == 0 || d == 1 || d == 3 || d == 4 || d == 5)
            {
               temp1 = number.Remove(number.Length - 2);
                return temp1;
            }
            else if (d == 2 || d == 7)
            {
                temp1 = number.Remove(number.Length - 3);
                return temp1;
            }
            else if (d == 6)
            {
                 temp1 = number.Remove(number.Length - 4);
                return temp1;
            }

            else
            {
                temp1 = number.Remove(number.Length - 6);
                return temp1;
            }
          
        }

        public static int Get(String number)
        {
            if (number.EndsWith(Number.NULL))
                return 0;
            else if (number.EndsWith(Number.ONE))
                return 1;
            else if (number.EndsWith(Number.SIX))
                return 6;
            else if (number.EndsWith(Number.THREE))
                return 3;
            else if (number.EndsWith(Number.FOUR))
                return 4;
            else if (number.EndsWith(Number.EIGHT))
                return 8;
            else if (number.EndsWith(Number.TWO))
                return 2;
            else if (number.EndsWith(Number.SEVEN))
                return 7;
            else
                return 5;
        }
     

    }

}