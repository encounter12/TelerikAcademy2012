using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace ex_04
{
    class Program
    {
        static void Main()
        {
            Console.Write("Enter number of lines: ");
            int numberOfLines = Convert.ToInt16(Console.ReadLine());
            for (int i = 0; i < numberOfLines; i++)
            {
                Console.WriteLine("your FTML text: ");
                string inputText = Console.ReadLine();

                string pattern = @"(<upper>)|(<lower>)|(<toggle)|(<del>)|(<rev>)";
                Regex regex = new Regex(pattern);

                string[] testSplitted = regex.Split(inputText);
                for (int index = 0; index < testSplitted.Length; index++)
                {

                    if (testSplitted[index].Equals("<upper>"))
                    {
                        testSplitted[index+1].ToUpper();
                    }
                    Console.WriteLine(testSplitted[index]);
                }

            }
        }
    }
}
