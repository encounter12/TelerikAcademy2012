using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTML
{
    class FTML
    {
        static void Main()
        {
            string test = "So<rev><upper>saw</upper> txet em</rev>";

            int linesCount = 0; 
            do
	        {
                linesCount = int.Parse(Console.ReadLine());
	        } while (!(linesCount >0 && linesCount < 500));

            while (index !=-1)
            {
                index = test.LastIndexOf(keyword[i]);
            }

            
        }
    }
}
