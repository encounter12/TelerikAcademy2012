using System;

class FTML
{
    static void Main(string[] args)
    {
        int N = 0;
        String input = null;


        N = int.Parse(Console.ReadLine());
        String[] output = new String[N];
        for (int i = 0; i < N; i++)
        {
            input = Console.ReadLine();
            if (input.IndexOf("upper") > 0)
            {
                output[i] = input.ToUpper();
            }
            else
            {
                output[i] = input;
            }
            if (input.IndexOf("lower") > 0)
            {
                output[i] = input.ToLower();
            }
            else
            {
                output[i] = input;
            }
            
            input = output[i].Replace("<UPPER>", "");
            input = input.Replace("</UPPER>", "");
            input = input.Replace("</rev>", "");
            input = input.Replace("<rev>", "");
            input = output[i].Replace("<lower>", "");
            input = input.Replace("</lower>", "");
            input = input.Replace("<toggle>", "");
            input = input.Replace("</toggle>", "");
            output[i] = input;



        }

        for (int i = 0; i < output.Length; i++)
        {
            Console.WriteLine(output[i]);
        }







    }
}
