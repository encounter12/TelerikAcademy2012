using System;
using System.Text;

class Program
{
    static void Main()
    {
	// A.
	// The input string.
	//const string s = "!!**!--!!-";
    string s = "***!!!";

    //string numZero = "-!";
        //string numOne = "**";
        //string numTwo = "!!!";
        //string numThree = "&&";
        //string numFour = "&-";
        //string numFive = "!-";
        //string numSix = "*!!!";
        //string numSeven = "&*!";
        //string numEight = "!!**!-";

        string[] sequenceofNum = 
        {
            "-!",       //0
            "**",       //1
            "!!!",      //2 
            "&&",       //3
            "&-",       //4
            "!-",       //5
            "*!!!",     //6
            "&*!",      //7
            "!!**!-",   //8
        };
        int j = 0;
  
        StringBuilder result = new StringBuilder();
        for (int i = sequenceofNum.Length - 1; i >=0 ; i--)
        {
            string keyword = sequenceofNum[i];
            int  a = s.IndexOf(keyword, j);
             if ((a) != -1 )
	            {
                    //Console.WriteLine(a);
                     j+=a;
                   

                 result.Append(a);
                 Console.WriteLine(i + "-->" + a);
                    // }
                    
                }
        };
    }
}