using System;
using System.Text;

class Program
{
    static void Main()
    {
        string value = Console.ReadLine();
        string[] symbols = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };

        int digit = 0;
        int power = 9;
        int sum = 0;
        int count = 0;

        StringBuilder substring = new StringBuilder();
        StringBuilder equalString = new StringBuilder();

        for (int i = value.Length - 1; i >= 0; i--)
        {
            substring.Insert(0, value[i]);
            if (substring.Length > 1)
            {
                for (int j = 0; j < symbols.Length - 1; j++)
                {
                    equalString.Append(symbols[j]);
                    if (substring.Equals(equalString))
                    {
                        if (count == 0) digit = j;
                        if (count > 0)
                        {
                            digit = j * power;
                            power *= power;
                        }
                        substring.Remove(0, substring.Length);
                        count++;
                        sum += digit;
                    }
                    equalString.Remove(0, equalString.Length);
                }
            }
        }
        Console.WriteLine(sum);
    }
}