using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace _9GagNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            String imput = Console.ReadLine();
            //Console.WriteLine(imput);
            List<string> parsedDigits = new List<string>();
            int currentIndex = 0;
            int nextDigitIndex = 0;
            String[] digits = { "!!**!-", "&*!", "*!!!", "!!!", "&-", "!-", "-!", "&&", "**", };
            for (int i = 0; i < digits.Length;)
            {
                currentIndex = imput.IndexOf(digits[i], currentIndex);
                if (currentIndex != -1 && currentIndex == nextDigitIndex)
                {
                    
                    //Console.WriteLine(imput.Substring(currentIndex, digits[i].Length));
                    parsedDigits.Add(imput.Substring(currentIndex, digits[i].Length));
                    currentIndex = currentIndex + digits[i].Length;
                    nextDigitIndex = currentIndex;
                    i = 0;
                }
                else
                {
                    i++;
                    currentIndex = nextDigitIndex;
                }
            }

            parsedDigits.Reverse();
           // ulong decimalRepresebtation = 0;
            BigInteger decimalRepresebtation = 0;

            for (int i = 0; i < parsedDigits.Count; i++)
            {
                decimalRepresebtation = decimalRepresebtation + vaueFinder(parsedDigits[i]) * Pow(i);
            }
            Console.WriteLine(decimalRepresebtation);
        }



        public static int vaueFinder(string digit)
        {
            int number;
            switch (digit)
            {
                case "-!": number = 0; break;
                case "**":number=1;break;
                case "!!!": number = 2; break;
                case "&&": number = 3; break;
                case "&-": number =4; break;
                case "!-": number = 5; break;
                case "*!!!": number = 6; break;
                case "&*!": number = 7; break;
                case "!!**!-": number = 8; break;
                default: number = -1;
                    break;

                   
            }
            return number;
        }

        public static BigInteger Pow(int j)
        {
            BigInteger number = 1 ;
            for (int i = 0; i < j; i++)
            {
                number = number * 9;
            }

            return number;
        }
    }
}
