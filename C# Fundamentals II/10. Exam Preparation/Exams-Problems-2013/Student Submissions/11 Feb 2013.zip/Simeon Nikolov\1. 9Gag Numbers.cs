using System;
using System.Collections.Generic;
using System.Text;


class Program
{
    static void Main()
    {
        string number = Console.ReadLine();
        string convertedNumber = ConvertNumber(number);
        decimal dNumber = 0m;
        decimal digit = 0m;

        for (int i = 0; i < convertedNumber.Length; i++)
        {
            digit = int.Parse(convertedNumber[i].ToString());
            int power = convertedNumber.Length - i - 1;
            dNumber += digit * pow(power);
        }
        Console.WriteLine(dNumber);
    }

    private static string ConvertNumber(string number)
    {
        StringBuilder convertedNumber = new StringBuilder(number.Length);
        StringBuilder gagNumber = new StringBuilder(number.Length);
        gagNumber.Append(number);

        int startIndex = 0;

        while (startIndex < gagNumber.Length)
        {
            if (gagNumber.ToString().Substring(startIndex).StartsWith("-!"))
            {
                convertedNumber.Append(0);
                startIndex += 2;
            }
            else if (gagNumber.ToString().Substring(startIndex).StartsWith("**"))
            {
                convertedNumber.Append(1);
                startIndex += 2;
            }
            else if (gagNumber.ToString().Substring(startIndex).StartsWith("!!!"))
            {
                convertedNumber.Append(2);
                startIndex += 3;
            }
            else if (gagNumber.ToString().Substring(startIndex).StartsWith("&&"))
            {
                convertedNumber.Append(3);
                startIndex += 2;
            }
            else if (gagNumber.ToString().Substring(startIndex).StartsWith("&-"))
            {
                convertedNumber.Append(4);
                startIndex += 2;
            }
            else if (gagNumber.ToString().Substring(startIndex).StartsWith("!-"))
            {
                convertedNumber.Append(5);
                startIndex += 2;
            }
            else if (gagNumber.ToString().Substring(startIndex).StartsWith("*!!!"))
            {
                convertedNumber.Append(6);
                startIndex += 4;
            }
            else if (gagNumber.ToString().Substring(startIndex).StartsWith("&*!"))
            {
                convertedNumber.Append(7);
                startIndex += 3;
            }
            else if (gagNumber.ToString().Substring(startIndex).StartsWith("!!**!-"))
            {
                convertedNumber.Append(8);
                startIndex += 6;
            }
        }

        return convertedNumber.ToString();
    }

    private static decimal pow(int power)
    {
        decimal result = 1m;
        for (int i = 0; i < power; i++)
        {
            result *= 9m;
        }

        return result;
    }
}
