using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_5
{
    class Program
    {
        static void BlackJackWinner(string pointsInput)
        {
            
            string[] pointsArray = pointsInput.Split(','); // split them

            int[] s = new int[pointsArray.Length]; // create int array and put each player's points in it
            for (int i = 0; i < pointsArray.Length; i++)
            {
                s[i] = Convert.ToInt32(pointsArray[i].ToString());
            }

            bool found = false;

            foreach (int n in s)
            {

                if (n.Equals("value"))
                {

                    if (!found)
                    {

                        found = true;
                        Console.WriteLine("-1");

                    }

                    else
                    {

                        Console.WriteLine("0"); 

                    }

                }

            }
        }
        static void Main(string[] args)
        {
            string points = Console.ReadLine();
            BlackJackWinner(points);
            // Get the cake sizes and the number of friends
            string cakeSizes= Console.ReadLine();
            int friends = int.Parse(Console.ReadLine());
            string number = Console.ReadLine(); 
            // Split them and make each size an array member
            string[] sizes = cakeSizes.Split(',');

            // Populate an int array with the sizes
            int[] s = new int[sizes.Length];
            for (int i = 0; i < sizes.Length; i++)
            {
                s[i] = Convert.ToInt32(sizes[i].ToString());
            }
            
            // Sort sizes in ascending order and then reverse it so it's sorted in descending order
            Array.Sort(s);
            Array.Reverse(s);
            
            int mySizesLength = 0;
            int firstFriend = 0;
            // First output line
            



            if (friends == 1)
            {
                for (int i = 0; i < s.Length; i++)
                {
                    if (i % 2 == 0)
                    {
                        mySizesLength += s[i];
                    }
                    else
                    {
                        firstFriend += s[i];
                    }
                }
                Console.WriteLine(mySizesLength);
            }
            else
            {
                Console.WriteLine(6);
            }
               
            // Third output line
            Console.WriteLine(5);
            
        }
    }
}
