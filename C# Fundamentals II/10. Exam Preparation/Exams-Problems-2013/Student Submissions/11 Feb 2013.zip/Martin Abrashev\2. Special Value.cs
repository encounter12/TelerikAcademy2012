using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecialValue
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int lines = int.Parse(input);

            string[][] redove = new string[lines][];

            for (int i = 0; i < lines; i++)
            {
                input = Console.ReadLine();
                string[] line = input.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                redove[i] = line;
            }

            int special = 0;
            int times = 1;
            int row = 0;

            foreach (string item in redove[row])
            {
                int cell = int.Parse(item);
                if (cell < 0 && special < -1*cell + 1)
                {
                    special = -1 * cell + 1;
                }
                else
                {
                    times = 1;
                    while (cell >= 0)
                    {
                        if (row == lines - 1)
                        {
                            row = -1;
                        }
                        cell = int.Parse(redove[++row][cell]);
                        if (cell < 0 && special < -1 * cell + times + 1)
                        {
                            special = -1 * cell + times + 1;
                        }
                        times++;
                    }
                    row = 0;
                }
            }

            Console.WriteLine(special);

            
        }
    }
}
