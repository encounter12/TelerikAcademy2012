using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02.SpecialValue
{
    class SpecialValue
    {
        static int counterPath = 1;
        static void Main()
        {
            string line = Console.ReadLine();
            int length = int.Parse(line);
            int[,] array = new int[length, 1000];
            int specialValue = 0;
            int maxSpecialValue =0;
            for (int i = 0; i < length; i++)
            {
                line = Console.ReadLine();
                GetNumbers(line, ref array, i);
            }
            for (int i = 0; i < 1000; i++)
            {
                if (array[0, i] < 0)
                {
                    specialValue = counterPath + Math.Abs(array[0, i]);
                    if (specialValue > maxSpecialValue)
                    {
                        maxSpecialValue = specialValue;
                        specialValue = 0;
                    }
                }
            }
            Console.WriteLine(maxSpecialValue);
        }

        private static void GetNumbers(string line, ref int[,] arr, int index)
        {
            string[] stringArr = line.Split(',');
            foreach (var item in stringArr)
            {
                item.Trim();
            }
            for (int i = 0; i < stringArr.GetLength(0); i++)
            {
                arr[index, i] = int.Parse(stringArr[i]);
            }
        }
    }
}
