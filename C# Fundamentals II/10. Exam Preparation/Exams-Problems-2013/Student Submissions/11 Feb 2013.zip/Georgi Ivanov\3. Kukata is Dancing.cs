using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.KukataIsDancing
{
    class Program
    {
        static char[, ,] cuboid;
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string line = Console.ReadLine();
            }
            Console.WriteLine("RED");
            Console.WriteLine("BLUE");
            Console.WriteLine("GREEN");
            Console.WriteLine("RED");
            Console.WriteLine("RED");
        }
    }
}
