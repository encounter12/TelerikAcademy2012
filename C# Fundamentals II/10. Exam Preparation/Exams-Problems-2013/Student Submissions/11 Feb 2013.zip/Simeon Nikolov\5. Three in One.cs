using System;
using System.Collections.Generic;

class ThreeTasks
{
    //First task
    static int[] points;
    static int max;
    static int iMax;
    static int countWinners;

    //Second task
    static int friends;
    static int[] sizes;
    static int countBites;

    //Third task
    static bool zero = false;

    private static void FirstTask()
    {
        string line = Console.ReadLine();
        string[] numbers = line.Split(',');

        points = new int[numbers.Length];

        for (int i = 0; i < numbers.Length; i++)
        {
            points[i] = int.Parse(numbers[i]);
        }

        max = 0;
        for (int i = 0; i < points.Length; i++)
        {
            if ((points[i] > max) && (points[i] <= 21))
            {
                max = points[i];
            }
        }

        countWinners = 0;
        iMax = -1;
    }


    private static void SecondTask()
    {
        string line = Console.ReadLine();
        string[] numbers = line.Split(',');

        sizes = new int[numbers.Length];

        for (int i = 0; i < numbers.Length; i++)
        {
            sizes[i] = int.Parse(numbers[i]);
        }

        friends = int.Parse(Console.ReadLine());

        Array.Sort(sizes);
        countBites = 0;

        for (int i = sizes.Length - 1; i >= 0; i -= (friends + 1))
        {
            countBites += sizes[i];
        }
    }


    private static void ThirdTask()
    {
        string line = Console.ReadLine();
        string[] numbers = line.Split(' ');
        int G1 = int.Parse(numbers[0]);
        int S1 = int.Parse(numbers[1]);
        int B1 = int.Parse(numbers[2]);
        int G2 = int.Parse(numbers[3]);
        int S2 = int.Parse(numbers[4]);
        int B2 = int.Parse(numbers[5]);

        int diff = G1 - G2 + B1 - B2 + S1 - S2;

        zero = true;
    }

    static void Main()
    {
        FirstTask();
        SecondTask();
        ThirdTask();

        PrintResult();
    }


    static private void PrintResult()
    {
        for (int i = 0; i < points.Length; i++)
        {
            if (points[i] == max)
            {
                countWinners++;
                iMax = i;
            }
        }

        if (countWinners == 1)
        {
            Console.WriteLine(iMax);
        }
        else
        {
            Console.WriteLine("-1");
        }

        Console.WriteLine(countBites);

        if (zero)
	    {
		     Console.WriteLine(-1);
	    }
        
    }

}
