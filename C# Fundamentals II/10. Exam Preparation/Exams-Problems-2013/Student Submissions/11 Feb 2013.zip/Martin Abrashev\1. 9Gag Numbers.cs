using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace GAG
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] digits = new string[9] { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
            BigInteger number = 0;
            string input = Console.ReadLine();
            StringBuilder digit = new StringBuilder();
            List<int> numbers = new List<int>();

            for (int i = 0; i < input.Length; i++)
            {
                digit.Append(input[i]);

                for (int j = 0; j < digits.Length; j++)
                {
                    if (digits[j] == digit.ToString())
                    {
                        numbers.Add(j);
                        digit.Clear();
                        break;
                    }
                }
            }

            numbers.Reverse();

            for (int i = 0; i < numbers.Count; i++)
            {
                BigInteger stepen9 = 1;
                for (int j = 1; j <= i; j++)
                {
                    stepen9 *= 9;
                }
                number += numbers[i] * stepen9;
            }
            Console.WriteLine(number);

            
        }
    }
}
