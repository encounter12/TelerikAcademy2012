using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Telerik
{
    class SpecialValue
    {
        private static int[][] rows;
        private static int n;
        static int maxColumn = 0;
        static void Main(string[] args)
        {
            #if DEBUG
            Console.SetIn(new StreamReader("inn1.txt"));
#endif
            n = int.Parse(Console.ReadLine());
            rows = new int[n][];

            for (int i = 0; i < n; i++)
            {
                var line = Console.ReadLine();
                var sp = line.Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                rows[i] = sp.Select(int.Parse).ToArray();
                var length = rows[i].Length;
                if (length > maxColumn) maxColumn = length;
            }
            var max = -1;
            for (int j = 0; j < rows[0].Length; j++)
            {
                var value = GetSpecialValue(0, j);
                if (value > max)
                    max = value;
            }
            Console.WriteLine(max);
        }

        private static int GetSpecialValue(int i, int j)
        {
            var element = rows[i][j];
            if (element < 0)
                return 1 - element;
            var list = new bool[n, maxColumn];
            list[i, j] = true;
            return JumpTo((i + 1) % n, element, list, 1);
        }

        private static int JumpTo(int i, int j, bool[,] list, int path)
        {
            if (list[i, j])
                return path;
            path += 1;
            var element = rows[i][j];
            if (element < 0)
                return path - element;
            list[i, j] = true;
            return JumpTo((i + 1) % n, element, list, path);
        }

    }
}
