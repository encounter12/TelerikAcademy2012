using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.KukataIsDancing
{
    class KukataIsDancing
    {
        static string[, ,] cube = new string[3, 3, 3] 
            {
            { {"r", "b", "r"}, {"b", "g", "b"}, {"r", "b", "r"} }, 
            { {"r", "b", "r"}, {"b", "g", "b"}, {"r", "b", "r"} },
            { {"r", "b", "r"}, {"b", "g", "b"}, {"r", "b", "r"} }
            };
        static List<string> square = new List<string>();
        static void Main()
        {
            string line = Console.ReadLine();
            int length = int.Parse(line);
            string moves;
            string result;
            for (int i = 0; i < length; i++)
            {
                moves = Console.ReadLine();
                result = onePlace(moves);
                square.Add(result);
            }
            printFinalResult();
        }

        static string onePlace(string moves)
        {
            int length = moves.Length;
            for (int i = 0; i < length; i++)
            {
                if (moves[i] == 'L' || moves[i] == 'R')
                {
                    return "GREEN";
                }
            }
            return "";
        }
        static void printFinalResult()
        {
            foreach (var item in square)
            {
                Console.WriteLine(item);
            }
        }
    }
}
