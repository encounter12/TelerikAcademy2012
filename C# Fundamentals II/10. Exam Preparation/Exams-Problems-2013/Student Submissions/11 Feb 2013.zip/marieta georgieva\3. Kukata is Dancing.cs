using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Task03
{
    static void Main(string[] args)
    {
        int dance = int.Parse(Console.ReadLine());
        string[] steps = new string[dance];
        string[]result=new string[dance];
        for (int i = 0; i < dance; i++)
        {
            steps[i] = Console.ReadLine();
        }
        for (int j = 0; j < steps.Length; j++)
        {
            //string steps = "LWWW";
            int col = 1;
            int row = 1;
            int nextCol = 0;
            int nextRow = 0;
            string direction = "front";
            string current = "front";
            char turn = new char();

            for (int i = 0; i < steps[j].Length; i++)
            {
                turn = steps[j][i];
                if (turn != 'W')
                {
                    if ((current == "front") && (turn == 'L')) direction = "left";
                    else if ((current == "front") && (turn == 'R')) direction = "right";
                    else if ((current == "left") && (turn == 'L')) direction = "back";
                    else if ((current == "left") && (turn == 'R')) direction = "front";
                    else if ((current == "back") && (turn == 'L')) direction = "right";
                    else if ((current == "back") && (turn == 'R')) direction = "left";
                    else if ((current == "right") && (turn == 'L')) direction = "front";
                    else if ((current == "right") && (turn == 'R')) direction = "back";
                }
                else
                {

                    if (direction == "left")
                    {
                        nextCol = -1;
                        nextRow = 0;
                    }
                    else if (direction == "right")
                    {
                        nextCol = +1;
                        nextRow = 0;
                    }
                    else if (direction == "front")
                    {
                        nextCol = 0;
                        nextRow = -1;
                    }
                    else if (direction == "back")
                    {
                        nextCol = 0;
                        nextRow = +1;
                    }

                    col = col + nextCol;
                    if (col < 0)
                    {
                        col = 2;
                    }
                    else if (col > 2)
                    {
                        col = 0;
                    }
                    row = row + nextRow;
                    if (row < 0)
                    {
                        row = 2;
                    }
                    else if (row > 2)
                    {
                        row = 0;
                    }


                }
                current = direction;
            }


            if (row == 1 && col == 1) result[j]="GREEN";
            else if ((row == 0 && col == 0) || (row == 0 && col == 2) || (row == 2 && col == 0) || (row == 2 && col == 2)) result[j]="RED";
            else if ((row == 0 && col == 1) || (row == 1 && col == 0) || (row == 1 & col == 2) || (row == 2 && col == 1)) result[j]="BLUE";
        }
        for (int i = 0; i < dance; i++)
        {
            Console.WriteLine(result[i]);
        }

    }
}




