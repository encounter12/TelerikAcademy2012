using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static int dances;
    static string[] moves; 
    static int[,]  cub={{1,2,1},
                        {2,3,2},
                        {1,2,1}};
    static int direction = 0;
    static int dwizi = 0;//dwizenie
    static int[] whereY = { -1, 0, 1, 0 };
    static int[] whereX = { 0, +1, 0, -1};
    static string[,] colors ={{"RED","BLUE","RED"},
                      {"BLUE","GREEN","BLUE"},
                      {"RED","BLUE","RED"}};

    static int x = 1;
    static int y = 1; 
    static int big;//proceed dance                  

    static void Main()
    {
              
        dances = int.Parse(Console.ReadLine());
        moves = new string[dances];
        for (int i = 0; i < dances; i++)
        {
            moves[i]=Console.ReadLine();
        }
        //PrintDances();
        x = 1;
        y = 1;
        for (big= 0; big < dances; big++)
        {
            x = 1;
            y = 1;
            direction = 0;
            GoDance();//only one dance
            //Console.WriteLine("end square {0} {1}", y, x);
            Console.WriteLine(colors[y,x]);
        }
           
    
    }
    public static void PrintDances()
    {
        for (int i = 0; i < dances; i++)
        {
            Console.WriteLine(moves[i]);
        }   
    }
    public static void GoDance()
    {
        string str=moves[big];
        for (int i = 0; i < str.Length; i++)
        {
            //Console.WriteLine(str[i]);
            if (str[i] == 'R')
            {
                direction++;
                if (direction > 3)
                {
                    direction =0;
                }
            }
            if (str[i] == 'L')
            {
                direction--;
                if (direction <0)
                {
                    direction =3;
                }
            }
            if (str[i] == 'W')
            {
                MadeMove();
            }
        
        
        }
    }
    public static void MadeMove()
    {
        //Console.Write("direction {0} ", direction);
        x = x + whereX[direction];
        if (x > 2)
        {
            x = 0;
        }
        if (x <0)
        {
            x = 2;
        }
       // Console.Write(" x{0} ",x);
        y= y + whereY[direction];
        if (y > 2)
        {
            y = 0;
        }
        if (y < 0)
        {
            y = 2;
        }
        //Console.WriteLine(" y{0} ", y);
        
    }

}

