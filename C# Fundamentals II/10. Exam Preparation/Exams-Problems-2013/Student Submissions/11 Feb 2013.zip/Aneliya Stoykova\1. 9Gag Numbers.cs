using System;
using System.Collections.Generic;


class Program
{
    static void Main()
    {
        string number = Console.ReadLine();
        int i = 0;

        string twoStr = "";
        string threeStr = "";
        string fourStr = "";
        string sixStr = "";
        List<string> list = new List<string>();
        int length = number.Length;
        while (i < length)
        {
            if (i + 2 <= length)
            {
                twoStr = number.Substring(i, 2);
            }
            if (i + 3 <= length)
            {
                threeStr = number.Substring(i, 3);
            }
            if (i + 4 <= length)
            {
                fourStr = number.Substring(i, 4);
            }
            if (i + 6 <= length)
            {
                sixStr = number.Substring(i, 6);
            }

            if (twoStr == "-!" || twoStr == "**" || twoStr == "&&" || twoStr == "&-" || twoStr == "!-")
            {
                i += 2;
                list.Add(twoStr);
                twoStr = "";
            }
            else if (threeStr == "!!!" || threeStr == "&*!")
            {
                i += 3;
                list.Add(threeStr);
                threeStr = "";
            }
            else if (fourStr == "*!!!")
            {
                i += 4;
                list.Add(fourStr);
                fourStr = "";
            }
            else if (sixStr == "!!**!-")
            {
                i += 6;
                list.Add(sixStr);
                sixStr = "";
            }
        }

        int sum = 0;
        for (int j = 0, l = list.Count - 1; l >= 0; j++, l--)
        {
            if (list[l] == "**")
            {
                sum += 1 * Check(9, j);
            }
            else if (list[l] == "!!!")
            {
                sum += 2 * Check(9, j);
            }
            else if (list[l] == "&&")
            {
                sum += 3 * Check(9, j);
            }
            else if (list[l] == "&-")
            {
                sum += 4 * Check(9, j);
            }
            else if (list[l] == "!-")
            {
                sum += 5 * Check(9, j);
            }
            else if (list[l] == "*!!!")
            {
                sum += 6 * Check(9, j);
            }
            else if (list[l] == "&*!")
            {
                sum += 7 * Check(9, j);
            }
            else if (list[l] == "!!**!-")
            {
                sum += 8 * Check(9, j);
            }
        }
        Console.WriteLine(sum);
    }
    static int Check(int a, int b)
    {
        if (b < 0)
        {
            throw new ApplicationException("B must be a positive integer or zero");
        }
        if (b == 0) return 1;
        if (a == 0) return 0;
        if (b % 2 == 0)
        {
            return Check(a * a, b / 2);
        }
        else if (b % 2 == 1)
        {
            return a * Check(a * a, b / 2);
        }
        return 0;
    }
}