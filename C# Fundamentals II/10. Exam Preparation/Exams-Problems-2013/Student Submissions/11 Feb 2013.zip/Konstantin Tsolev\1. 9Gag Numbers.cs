using System;
using System.Collections.Generic;
using System.Text;


namespace _9GagNumbers
{
    class _9GagNumbers
    {
        static List<int> numbers = new List<int>();
        public static string[] digitPatterns ={
                                            "-!", //0
                                            "**", //1     
                                            "!!!", //2
                                            "&&", //3
                                            "&-", //4
                                            "!-", //5
                                            "*!!!", //6
                                            "&*!", //7
                                            "!!**!-",//8                      
                                           };
        static public void PrintNum() 
        {
            double digit = 0;
            int i=0;
            foreach(int d in numbers){
                digit += d* Math.Pow((double) 9 ,(double) i);
                i++;
            }
           
            Console.Write(digit);
        }
        static public void GuessTheNumber(string input) 
        {
            int num = 0;
            int len=0;
            string next = "";
            for (int i = 0; i < digitPatterns.Length; i++) 
            {
                if (input.StartsWith(digitPatterns[i])) 
                {
                    string digit=digitPatterns[i];
                    switch(digit)
                    {
                        case "-!":
                            num = 0;
                            len=2;
                            break;
                        case "**":
                            num = 1;
                            len=2;
                            break;
                        case "!!!":
                            num = 2;
                            len=3;
                            break;
                        case "&&":
                            num = 3;
                            len=2;
                            break;
                        case "&-":
                            num = 4;
                            len=2;
                            break;
                        case "!-":
                            num = 5;
                            len=2;
                            break;
                        case "*!!!":
                            len=4;
                            num = 6;
                            break;
                        case "&*!":
                           num = 7;
                            len=3;
                            break;
                        case "!!**!-":
                            num = 8;
                            len=6;
                            break;
                    }
                }
        }
            next = input.Substring(len);
            numbers.Add(num);
            PrintNum();
            if (next.Length > 2)
            {
                GuessTheNumber(next);
            }

       }
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            GuessTheNumber(input);
        }
    }
}
