using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter string");
            string str = Console.ReadLine();
            if (str == "-!")
            {
                Console.WriteLine(0);
            }
            else if(str == "!!**!-")
            {
                Console.WriteLine(8);
            }
            else if (str == "**")
            {
                Console.WriteLine(1);
            }
            else if (str == "!!!")
            {
                Console.WriteLine(2);
            }
            else if (str == "&&")
            {
                Console.WriteLine(3);
            }
            else if (str == "&-")
            {
                Console.WriteLine(4);
            }
            else if (str == "!-")
            {
                Console.WriteLine(5);
            }
            else if (str == "*!!!")
            {
                Console.WriteLine(6);
            }
            else if (str == "&*!")
            {
                Console.WriteLine(7);
            }
            else
            {
                Console.WriteLine("100");
            }

            
        }
    }

   
}
