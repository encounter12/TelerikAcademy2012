using System;
using System.IO;

class SpecialValue
{
	public int[][] Rows;
	public bool[][] Visited;
	static void Main()
	{
		SpecialValue s = new SpecialValue("Special.txt");
		int maxSpecialNumber = 0;
		for (int j = 0; j < s.Rows[0].Length; j++)
		{
			PathInfo p = s.GetPath(j);
			if (p.HasSpecialValue)
			{
				if (maxSpecialNumber < p.Length)
				{
					maxSpecialNumber = p.Length;
				}
			}
		}
		Console.WriteLine(maxSpecialNumber);


	}
	public struct PathInfo
	{
		public int Length;
		public bool HasSpecialValue;
		public PathInfo(int length, bool isSpecial)
		{
			Length = length;
			HasSpecialValue = isSpecial;
		}
	}
	public PathInfo GetPath(int j)
	{
		int i = 0;
		int length = 1;
		bool isSpecial = false;
		Visited[i][j] = true;
		while (Rows[i][j] >= 0 && !Visited[i][j])
		{
			length++;
			i++;
			if(i > Rows.Length - 1)
			{
				i = 0;
			}
			j = Rows[i][j];
		}
		if (Rows[i][j] < 0)
		{
			isSpecial = true;
			length -= Rows[i][j];
		}
		return new PathInfo(length, isSpecial);
	}



	public SpecialValue(string file)
	{
#if DEBUG
		Console.SetIn(new StreamReader(file));
#endif
		int n = int.Parse(Console.ReadLine());
		string[] lines = new string[n];
		for (int i = 0; i < n; i++)
		{
			lines[i] = Console.ReadLine();
		}
		Rows = new int[n][];
		Visited = new bool[n][];
		for (int i = 0; i < n; i++)
		{
			string[] input = lines[i].Split(',');
			Rows[i] = new int[input.Length];
			Visited[i] = new bool[input.Length];
			for (int j = 0; j < input.Length; j++)
			{
				Rows[i][j] = int.Parse(input[j].Trim());
			}
		}
	}
	public void ForgetPath()
	{
		for (int i = 0; i < Visited.Length; i++)
		{
			for (int j = 0; j < Visited[i].Length; j++)
			{
				Visited[i][j] = false;
			}
		}
	}
	public void Print()
	{
		for (int i = 0; i < Rows.Length; i++)
		{
			for (int j = 0; j < Rows[i].Length - 1; j++)
			{
				Console.Write(Rows[i][j] + " ");
			}
			Console.WriteLine(Rows[i][Rows[i].Length - 1]);
		}
	}
}
