using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        String pointsInput = Console.ReadLine();
        String cakesInput = Console.ReadLine();
        int friends = int.Parse(Console.ReadLine());
        String coinsIntput = Console.ReadLine();

        //Black Jack
        String[] pointsArr = pointsInput.Split(',');
        int winnerPoints =-1, winnerIndex = -1, numberOfWinners = 0;
        for (int i = 0; i < pointsArr.Length; i++)
		{
            int playerPoints = int.Parse(pointsArr[i]);
            if (playerPoints > winnerPoints && playerPoints <= 21)
            {
                winnerPoints = playerPoints;
                winnerIndex = i;
                numberOfWinners = 1;
            }
            else if (playerPoints == winnerPoints)
            {
                numberOfWinners++;
            }
		}
        if (numberOfWinners != 1)
        {
            Console.WriteLine(-1);
        }
        else
        {
            Console.WriteLine(winnerIndex);
        }

        //Cakes
        String[] bitesStr = cakesInput.Split(',');
        int[] bites = new int[bitesStr.Length];
        for (int i = 0; i < bitesStr.Length; i++)
        {
            bites[i] = int.Parse(bitesStr[i]);
        }
        Array.Sort(bites);

        int bitesSum = 0;
        for (int i = bites.Length - 1; i >=0 ; i = i - friends -1)
        {
            bitesSum += bites[i];
        }
        Console.WriteLine(bitesSum);

        //Coins
        String[] coins = coinsIntput.Split(' ');
        long 
            ge = long.Parse(coins[0]) - long.Parse(coins[3]), se = long.Parse(coins[1]) - long.Parse(coins[4]), be = long.Parse(coins[2]) - long.Parse(coins[5]);

        bool haveEnoughMoney = true;
        int numberOfTransfers = 0;
        while (haveEnoughMoney && (be < 0 || ge < 0 || be < 0))
        {
            numberOfTransfers++;
            if (ge < 0)
            {
                if (se < 0)
                {
                    if (be < 0)
                    {
                        haveEnoughMoney = false;
                    }
                    else
                    {
                        se++;
                        be -= 11;
                    }
                }
                else
                {
                    ge++;
                    se -= 11;
                }
            }
            else
            {
                if (be < 0)
                {
                    if (se < 0)
                    {
                        se += 9;
                        ge--;
                    }
                    else
                    {
                        be += 9;
                        se--;
                    }
                }
                else
                {
                    ge--;
                    se += 9;
                }
            }
        }
        if (haveEnoughMoney)
        {
            Console.WriteLine(numberOfTransfers);
        }
        else
        {
            Console.WriteLine(-1);
        }
    }
}
