using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static string[,] cube = new string[,]{
    {"RED","BLUE","RED"},
    {"BLUE","GREEN","BLUE"},
    {"RED","BLUE","RED"}};


    static int N;
    static string dir;
    static int posX = 1;
    static int posY = 1;
    //static string result;
    static StringBuilder result = new StringBuilder();

    static void Main()
    {
        N = int.Parse(Console.ReadLine());

        for (int i = 0; i < N; i++)
        {
            posX = 1;
            posY = 1;
            dir = "up";
            //result = cube[posX, posY];
            string line = Console.ReadLine();
            for (int j = 0; j < line.Length; j++)
            {
                if (!line.Contains('W'))
                    break;
                else if (dir == "up")
                {
                    if (line[j] == 'L')
                    {
                        dir = "left";
                    }
                    else if (line[j] == 'R')
                    {
                        dir = "right";
                    }
                    else if (line[j] == 'W')
                    {
                        posY--;
                        if (posY < 0)
                        {
                            posY = 2;
                        }
                    }
                }
                else if (dir == "down")
                {
                    if (line[j] == 'L')
                    {
                        dir = "right";
                    }
                    else if (line[j] == 'R')
                    {
                        dir = "left";
                    }
                    else if (line[j] == 'W')
                    {
                        posY++;
                        if (posY > 2)
                        {
                            posY = 0;
                        }
                    }
                }
                else if (dir == "right")
                {
                    if (line[j] == 'L')
                    {
                        dir = "up";
                    }
                    else if (line[j] == 'R')
                    {
                        dir = "down";
                    }
                    else if (line[j] == 'W')
                    {
                        posX++;
                        if (posX > 2)
                        {
                            posX = 0;
                        }
                    }
                }
                else if (dir == "left")
                {
                    if (line[j] == 'L')
                    {
                        dir = "down";
                    }
                    else if (line[j] == 'R')
                    {
                        dir = "up";
                    }
                    else if (line[j] == 'W')
                    {
                        posX--;
                        if (posX < 0)
                        {
                            posX = 2;
                        }
                    }
                }
            }
            result.AppendLine(cube[posX, posY]);
        }

        Console.WriteLine(result);
    }
}