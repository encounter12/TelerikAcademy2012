using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelerikExam
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine() ;
            char[] s = input.ToCharArray();
            int length = input.Length;
            List<int> translatedNumbers = new List<int>();
            int skip = 0;
            int sum = 0;
          // for (int i = 0; i < s.Length; i+=skip)
           {
                
                for (int j = length-1; j >0; j-=skip)
                {

                    if (s[j] == '-' && s[j - 1] == '!' && s[j - 2] == '*' && s[j - 3] == '*' && s[j - 4] == '!' && s[j - 5] == '!')
                    {
                        skip =skip+ 5;
                        translatedNumbers.Add(8);
                        
                    }
                    else if (s[j] == '!' && s[j - 1] == '*' && s[j - 2] == '&')
                    {
                        skip = skip + 3;
                        translatedNumbers.Add(7);

                    }
                    if (s[j] == '!' && s[j - 1] == '!' && s[j - 2] == '!' && s[j - 3] == '*') 
                    {
                        skip = skip+ 4;
                        translatedNumbers.Add(6);
                        
                    }
                    else if (s[j] == '-' && s[j - 1] == '!')
                    {
                        skip = skip + 2;
                        translatedNumbers.Add(5);

                    }
                
                    else if (s[j] == '!' && s[j-1] == '-')
                    {
                        skip =skip+ 2;
                        translatedNumbers.Add(0);
                        
                    }
                    else if (s[j] == '*' && s[j - 1] == '*')
                    {
                        skip = skip + 2;
                        translatedNumbers.Add(1);

                    }
                    else if (s[j] == '!' && s[j - 1] == '!' && s[j - 2] == '!')
                    {
                        skip = skip + 3;
                        translatedNumbers.Add(2);

                    }
                    else if (s[j] == '&' && s[j - 1] == '&')
                    {
                        skip = skip + 2;
                        translatedNumbers.Add(3);

                    }
                    else if (s[j] == '-' && s[j - 1] == '&')
                    {
                        skip += 2;
                        translatedNumbers.Add(4);

                    }
               
                   
                

                }

            }
           int[] numbers = translatedNumbers.ToArray();
           for (int k = 0; k < numbers.Length; k++)
           {
               if (k == 0)
               {
                   sum += (numbers[k]);
               }
               else
               {
                   sum += (numbers[k] * (9*k));
               }
           



           }
          /* foreach (int i in translatedNumbers)
           {
               Console.WriteLine(i);
           }*/
           Console.WriteLine(sum);
        }
    }
}
