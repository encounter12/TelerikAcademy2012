using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;


class Program
{
    static int checkInDictionary(string gagDigit)
    {
        string[] dict = {
                          "-!",
                          "**",
                          "!!!",
                          "&&",
                          "&-",
                          "!-",
                          "*!!!",
                          "&*!",
                          "!!**!-"
                      };
        for (int i = 0; i < dict.Length; i++)
        {
            if(gagDigit.CompareTo(dict[i]) == 0)
            {
                return i;
            }
        }
        return -1;
    }

    static BigInteger Pow(int y)
    {
        BigInteger num = 1;
        for (int i = 0; i < y; i++)
        {
            num = num * 9;
        }
        return num;
    }

    static BigInteger convertGagNumber(string gagNumber)
    {
        BigInteger decNumber = 0;        
        int index = 0;
        int temp = 0;
        List<string> gagDigits = new List<string>();
        List<int> decDigits = new List<int>();
        StringBuilder tryGag = new StringBuilder();

        while (index < gagNumber.Length)
        {
            tryGag.Append(gagNumber[index]);
            temp = checkInDictionary(tryGag.ToString());
            if (temp >= 0)
            {
                gagDigits.Add(tryGag.ToString());
                decDigits.Add(temp);
                tryGag.Clear();
            }
            index++;
        }

        for (int j = 0; j < decDigits.Count; j++)
        {
            decNumber = decNumber + decDigits[j]*Pow(decDigits.Count-1-j); 
        }

        return decNumber;
    }

    static void Main()
    {
        string gagNumber = Console.ReadLine();
        BigInteger decNumber = convertGagNumber(gagNumber);

        Console.WriteLine(decNumber);

    }
}