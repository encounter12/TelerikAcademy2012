using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace izpit5
{
    class Program
    {
        static int cnt = 0;

        static void Main(string[] args)
        {

            string rededBlackJack = Console.ReadLine();
            
            string rededCakeSize = Console.ReadLine();
            int friends = int.Parse(Console.ReadLine());

            string readedCoins = Console.ReadLine();

            first(rededBlackJack);
            second(rededCakeSize, friends);
            third(readedCoins);

        }

        static void first(string rededBlackJack)
        {
            string[] arr = rededBlackJack.Split(',');
            int maxNum = 0;
            int counter = 0;
            int winner = 0;

            for (int i = 0; i < arr.Length; i++)
            {
                if (int.Parse(arr[i]) <= 21 && int.Parse(arr[i]) > maxNum)
                {
                    maxNum = int.Parse(arr[i]);
                    winner = i;
                }
            }

            for (int j = 0; j < arr.Length; j++)
            {
                if (maxNum == int.Parse(arr[j]))
                {
                    counter++;
                }
            }

            if (counter == 1)
            {
                Console.WriteLine(winner);
            }
            else
            {
                Console.WriteLine(-1);
            }
        }

        static void second(string readedCakeSize, int friends)
        {
            int sum = 0;
            string[] cakeSize = readedCakeSize.Split(',');
            Array.Sort(cakeSize);

            for (int p = cakeSize.Length - 1; p >= 0; p--)
            {
                sum += int.Parse(cakeSize[p]);

                p = p - friends;
            }

            Console.WriteLine(sum);
        }

        static void third(string readedCoins)
        {
            string[] splitCoins = readedCoins.Split(' ');
            int[] myCoins = { int.Parse(splitCoins[0]), int.Parse(splitCoins[1]), int.Parse(splitCoins[2]) };
            int[] neededCoins = { int.Parse(splitCoins[3]), int.Parse(splitCoins[4]), int.Parse(splitCoins[5]) };

            for (int i = myCoins.Length - 1; i >= 0; i--)
            {
                if (myCoins[i] <= neededCoins[i])
                {
                    continue;
                }
                else
                {


                    if (i == 2 && myCoins[i] - 11 >= neededCoins[i])
                    {
                        if (myCoins[1] > neededCoins[1])
                            continue;
                        myCoins[2] = myCoins[i] - 11;
                        myCoins[1] = myCoins[1] + exchange(0, 0, 11);
                    }

                    if (i == 1)
                    {
                        if (myCoins[i] / 11 > 0 && myCoins[i] - 11 >= neededCoins[i])
                        {
                            if (myCoins[0] > neededCoins[0])
                                continue;
                            myCoins[1] = myCoins[i] - 11;
                            myCoins[0] = myCoins[0] + exchange(0, 11, 0);

                        }
                        else
                        {
                            if (myCoins[2] > neededCoins[2])
                                continue;
                            myCoins[1] = myCoins[i] - 1;
                            myCoins[2] = myCoins[2] + exchange(0, 1, 0);
                        }
                    }

                    if (i == 0 && myCoins[i] - 1 >= neededCoins[i])
                    {
                        if (myCoins[1] > neededCoins[1])
                            continue;
                        myCoins[0] = myCoins[i] - 1;
                        myCoins[1] = myCoins[1] + exchange(1, 0, 0);

                    }

                    i = myCoins.Length - 1;

                }
            }


            if (myCoins[2] < neededCoins[2] || myCoins[1] < neededCoins[1] || myCoins[0] < neededCoins[0])
            {
                Console.Write(-1);
            }
            else
            {
                Console.Write(cnt);
            }
        }

        static int exchange(int gold, int silver, int bronze)
        {
            cnt++;
            if (gold == 1)
                return 9;
            if (silver == 11)
                return 1;
            if (silver == 1)
                return 9;
            if (bronze == 11)
                return 1;

            return 1;
        }
    }
}
