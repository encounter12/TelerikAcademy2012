using System;

namespace Problem3
{
	class Problem3
	{
		static void Main()
		{
			string[,] matrix = { { "RED", "BLUE", "RED" },
						     { "BLUE", "GREEN", "BLUE" },
						     { "RED", "BLUE", "RED" } };
			int[] pos = { -1, 0, 1, 0 };

			int n = int.Parse(Console.ReadLine());
			string[] result = new string[n];
			int count = 0;
			for (int i = 0; i < n; i++)
			{
				int row = 1;
				int col = 1;
				int posRow = 0;
				int posCol = 1;
				string path = Console.ReadLine();
				for (int j = 0; j < path.Length; j++)
				{
					switch (path[j])
					{
						case 'L':
							posRow--;
							if (posRow > 3)
								posRow = 0;
							if (posRow < 0)
								posRow = 3;

							posCol--;
							if (posCol > 3)
								posCol = 0;
							if (posCol < 0)
								posCol = 3;

							break;
						case 'R':
							posRow++;
							if (posRow > 3)
								posRow = 0;
							if (posRow < 0)
								posRow = 3;

							posCol++;
							if (posCol > 3)
								posCol = 0;
							if (posCol < 0)
								posCol = 3;

							break;
						case 'W':
							row += pos[posRow];
							if (row > 2)
								row = 0;
							if (row < 0)
								row = 2;
							col += pos[posCol];
							if (col > 2)
								col = 0;
							if (col < 0)
								col = 2;
							break;
					}
				}
				result[count] = matrix[row, col];
				count++;
			}
			for (int i = 0; i < n; i++)
				Console.WriteLine(result[i]);
		}
	}
}
