using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        ushort N = byte.Parse(Console.ReadLine());
        string[] lines = new string[N];

        for (int i = 0; i < N; i++)
        {
            lines[i] = Console.ReadLine();
        }
        for (int i = 0; i < N; i++)
        {
            Console.WriteLine(parse(lines[i], ""));
        }
    }

    static string parse(string line, string tag)
    {
        StringBuilder text = new StringBuilder();
        StringBuilder tagname = new StringBuilder();
        StringBuilder tagbody = new StringBuilder();
        bool intag = false;
        bool closetag = false;
        int level = 0;

        foreach (char letter in line)
        {
            if (letter == '<')
            {
                intag = true;
                level++;
            }

            if (intag && letter == '/')
            {
                level--;
                closetag = true;
                if (level == 1)
                {
                    tagbody.Remove(tagbody.Length-1, 1);
                }
            }

            if (letter == '>' && !closetag)
            {
                intag = false;
                if (level == 1)
                {
                    tagname.Append(letter);
                    continue;
                }
            }

            if ((level > 1) || (level == 1 && !intag))
                tagbody.Append(letter);

            if (letter == '>' && closetag)
            {
                level--;
                intag = false;
                closetag = false;
                if (level==0)
                {
                    text.Append(parse(tagbody.ToString(), tagname.ToString()));
                    tagname.Remove(0, tagname.Length);
                    tagbody.Remove(0, tagbody.Length);
                    continue;
                }
            }


            if (intag && !closetag && level==1)
                tagname.Append(letter);


            if (level==0 && !intag)
                text.Append(letter);

        }

        tagbody.Remove(0, tagbody.Length);


        switch (tag)
        {
            case "<upper>":
                return text.ToString().ToUpper();
            case "<lower>":
                return text.ToString().ToLower();
            case "<toggle>":
                {
                    foreach (char c in text.ToString())
                        tagbody.Append(char.IsUpper(c) ? char.ToLower(c) : char.ToUpper(c));
                    return tagbody.ToString();
                }
            case "<rev>":
                {
                    char[] arr = text.ToString().ToCharArray();
                    Array.Reverse(arr);
                    return new string(arr);
                }
            case "<del>":
                return "";
            default:
                return text.ToString();
        }
    }

}
