using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = Console.ReadLine();
            string[] numbers = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
            string charToStr = "";
            string result = "";
           

            for (int i = 0; i < text.Length; i++)
            {
                charToStr += text[i].ToString();
                for (int j = 0; j < numbers.Length; j++)
                {
                    if (charToStr==numbers[j])
                    {
                        result += j+"";
                        charToStr = "";
                        break;
                    }
                }
            }
            Console.WriteLine(Convert(result));
          
 }
        static long Convert(string input)
        {
            char[] inputArr = input.ToCharArray(); 
            Array.Reverse(inputArr);
            long inputToDecimal = 0;
            for (int i = 0; i < inputArr.Length; i++)
            {
                inputToDecimal += ((long)inputArr[i] - 48) * (long)Math.Pow(9, i);
                
            }
            return inputToDecimal;
        }
    }
}
