using System;

class KukataIsDancing
{
    static void Main(string[] args)
    {
        int N = 0;
        String movements = null;

        String position = "GREEN";
        String direction = null;

        N = int.Parse(Console.ReadLine());

        for (int i = 0; i < N; i++)
        {
            movements = Console.ReadLine();

            if (movements.IndexOf('L') > 0)
            {
                direction = "LEFT";

            }

            if (movements.IndexOf('R') > 0)
            {
                direction = "RIGHT";
            }

            if (movements.IndexOf('W') > 0)
            {
                if (movements.IndexOf('L') > 0)
                {
                    position = "BLUE";
                    direction = "LEFT";
                }
            }
            if (movements.IndexOf('W') > 0)
            {
                position = "BLUE";
                if (movements.IndexOf('W') > 0)
                {
                    position = "BLUE";
                    if (movements.IndexOf('W') > 0 )
                    {
                        position = "GREEN";
                    }
                }
            }

            if (movements.IndexOf('R') > 0)
            {
                if (movements.IndexOf('W') > 0)
                {
                    position = "RED";
                    direction = "LEFT";
                }
            }

            

            Console.WriteLine(position);
            position = "GREEN";
        }