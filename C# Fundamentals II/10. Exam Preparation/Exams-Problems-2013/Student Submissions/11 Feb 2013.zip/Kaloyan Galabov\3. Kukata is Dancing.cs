using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Kukata
{
    class bla
    {
        public int x = 2;
        public int y = 2;
        byte direction = 1;
        private void ChangeDir(char dir)
        {
            if (dir == 'L')
            {
                this.direction--;
                if (direction == 0) direction = 4;
            }
            if (dir == 'R')
            {
                this.direction++;
                if (direction == 5) direction = 1;
            }
        }
        private void Move()
        {
            switch (direction)
            {
                case 1: this.x++; break;
                case 2: this.y--; break;
                case 3: this.x--; break;
                case 4: this.y++; break;
            }
            if (this.x == 0) this.x = 3;
            if (this.x == 4) this.x = 1;
            if (this.y == 0) this.y = 3;
            if (this.y == 4) this.y = 1;
        }
        public void NextMove(char instruction)
        {
            if (instruction == 'W')
            {
                this.Move();
                return;
            }
            ChangeDir(instruction);
        }
        public string GetResult()
        {
            if (x == 2 && y == 2)
            {
                return "GREEN" + '\n';
            }
            if ((x == 1 && y == 2)||(x==2 && (y==1||y==3))||(x == 3 && y == 2))
            {
                return "BLUE" + '\n';
            }
            return "RED" + '\n';
        }
    }
    static void Main()
    {
        int dances = int.Parse(Console.ReadLine());
        string[] dance = new string[dances];
        StringBuilder result = new StringBuilder(dances*3);
        for (int i = 0; i < dances; i++)
        {
            dance[i] = Console.ReadLine();
        }
        bla thisDance;
        for (int i = 0; i < dances; i++)
        {
            thisDance = new bla();
            for (int j = 0; j < dance[i].Length; j++)
            {
                thisDance.NextMove(dance[i][j]);
            }
            result.Append(thisDance.GetResult());
        }
        Console.WriteLine(result.ToString());
    }
}