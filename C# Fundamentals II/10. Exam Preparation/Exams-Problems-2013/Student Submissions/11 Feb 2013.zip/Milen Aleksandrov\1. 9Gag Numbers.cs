using System;
using System.Collections.Generic;
using System.Text;

class Program
{
    static void Main()
    {
        string[] numbers = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
        string numberToDecode = Console.ReadLine();
        List<int> decNumbers = new List<int>();
        int index = 0;

        while (numberToDecode.Length > 0)
	    {
	        for (int i = 0; i < numbers.Length; i++)
            {
                if (numberToDecode.Length >= numbers[i].Length)
                {
                    string test = numberToDecode.Substring(0, numbers[i].Length);
                    if (numbers[i] == test)
                    {
                        decNumbers.Add(i);
                        numberToDecode = numberToDecode.Remove(0, numbers[i].Length);
                        break;
                    }
                }
            }
        }

        index = 0;
        decNumbers.Reverse();
        for (int i = 0; i < decNumbers.Count; i++)
        {
            index = index + (decNumbers[i] * (int)Math.Pow(9, i));
        }
        Console.WriteLine(index);
    }


}