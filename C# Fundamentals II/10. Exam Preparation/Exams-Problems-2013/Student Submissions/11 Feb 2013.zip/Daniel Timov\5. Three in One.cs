using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeInOne
{
    class Program
    {
        static void Main()
        {
            string[] strPoints = Console.ReadLine().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            List<int> points = new List<int>();
            for (int i = 0; i < strPoints.Length; i++)
            {
                points.Add(int.Parse(strPoints[i]));
            }
            string[] strSizes = Console.ReadLine().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            
            List<int> sizes = new List<int>();
            for (int i = 0; i < strSizes.Length; i++)
            {
                sizes.Add(int.Parse(strSizes[i]));
            }
            int friends = int.Parse(Console.ReadLine());
            Console.WriteLine(BlackJack(points));
            Console.WriteLine(TaskTwo(sizes, friends));
            
            
            
            
            
        }

      
        private static int TaskTwo(List<int> sizes, int friends) 
        {
            int myBites = 0;
            int turn = 0;
            int currTurn = 0;
            if (sizes.Count > friends * 2)
            {
                for (int i = 0; i < sizes.Count; i++)
                {
                    int max = GetMax(sizes);
                    if (turn == currTurn)
                    {
                        myBites += max;
                        turn += friends;
                    }
                    sizes.Remove(max);
                    currTurn++;
                }
                

            }
            else {
                while (sizes.Count != 0) {
                    int max = GetMax(sizes);
                    if (turn == currTurn)
                    {
                        myBites += max;
                        turn += friends;
                    }
                    sizes.Remove(max);
                    currTurn++;
                }
            }
            return myBites;
        }

        private static int GetMax(List<int> list)
        {
            int max = int.MinValue;
            for (int i = 0; i < list.Count; i++)
            {
               
                if (max < list[i])
                {
                    max = list[i];
                }
               
            }
            return max;
        }
       
        public static int BlackJack(List<int> points)
        {
            StringBuilder newPoints = new StringBuilder();
            for (int i = 0; i < points.Count; i++)
            {
                newPoints.Append(points[i]);
            }
            bool isRerpeated = false;
            string strNewPoints = newPoints.ToString();
            int max = int.MinValue;
            for (int i = 0; i < points.Count; i++)
            {
                if ((strNewPoints.Split(strNewPoints[i]).Length - 1) <= 1)
                {
                    isRerpeated = true;
                }
            }
            for (int i = 0; i < points.Count; i++)
            {
                if (!isRerpeated) {
                    if (points[i] <= 21)
                    {
                        if (max < points[i])
                        {
                            max = points[i];
                        }
                    } 
                }
            }
            
            return points.IndexOf(max);
        }
    }
}
