using System;
using System.Collections.Generic;

class KukataIsDancing
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string[] dance = new string[n];
        for (int i = 0; i < n; i++)
        {
            dance[i] = Console.ReadLine();
        }
        string[,] colours = new string[3, 3] {
        {"RED", "BLUE", "RED"},
        {"BLUE", "GREEN", "BLUE"},
        {"RED", "BLUE", "RED"}};
        string position = colours[1,1];
 
        for (int i = 0; i < n; i++)
        {
            List<char> moves = new List<char>();
            int countW = 0;
            int countNoW = 0;
            foreach(var move in dance[i])
            {
                moves.Add(move);  
            }
            foreach (var move in moves)
            {
                if (move.CompareTo('W') == 0)
                {
                    countW++;
                }
                else
                {
                    countNoW++;
                }
                
            }
            if (countW == moves.Count)
            {
                if (countW % 3 == 0)
                {
                    Console.WriteLine("GREEN");
                }
                else
                {
                    Console.WriteLine("BLUE");
                }
            }
            if (countNoW == moves.Count)
            {
                Console.WriteLine("GREEN");
            }
        }
    } 
}

