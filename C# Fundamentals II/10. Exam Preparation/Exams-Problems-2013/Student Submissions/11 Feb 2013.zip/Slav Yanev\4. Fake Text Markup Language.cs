using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace FakeTML
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            StringBuilder text = new StringBuilder();
            for (int i = 0; i < N; i++)
            {
                text.Append(Console.ReadLine());
                text.Append("\n");
            }
            text.Remove(text.Length - 1, 1);
            string resText = text.ToString(); //@"(<)(\w+)(>)((\w|\s|[!@#$%^&,])+?)(</)(\w+)(>)"
            while (Regex.Matches(resText, @"(<)(\w+)(>)((\w|\s|[$!?@#%^&,.*/])+?)(</)(\w+)(>)").Count > 0)
            {
                resText = Regex.Replace(resText, @"(<)(\w+)(>)((\w|\s|[$!?@#%^&,.*/])+?)(</)(\w+)(>)", ReplaceTag);
            }
            Console.WriteLine(resText);
        }

        static string ReplaceTag(Match m)
        {
            string x = m.ToString();
            Regex delTag = new Regex(@"(<del>)((\w|\s|[$!?@#%^&,.*/])+?)(</del>)");
            Regex lowerTag = new Regex(@"(<lower>)((\w|\s|[$!?@#%^&,.*/])+?)(</lower>)");
            Regex upperTag = new Regex(@"(<upper>)((\w|\s|[$!?@#%^&,.*/])+?)(</upper>)");
            Regex toggleTag = new Regex(@"(<toggle>)((\w|\s|[$!?@#%^&,.*/])+?)(</toggle>)");
            Regex reverseTag = new Regex(@"(<rev>)((\w|\s|[$!?@#%^&,.*/])+?)(</rev>)");

            if (toggleTag.IsMatch(x))
            {
                x = x.Substring(8, x.Length - 17);
                char ch;
                StringBuilder result = new StringBuilder();
               for (int i = 0; i < x.Length; i++)
                {
                    ch=x[i];
                    if (Char.IsLower(ch))
                    {
                        result.Append(Char.ToUpper(ch));
                    }
                    else if (Char.IsUpper(ch))
                    {
                        result.Append(Char.ToLower(ch));
                    }
                    else
                    {
                        result.Append(ch);
                    }
                }
                return result.ToString();
            }

            if (upperTag.IsMatch(x))
            {
                x=x.ToUpper();
                return x.Substring(7, x.Length - 15);
            }

            if (delTag.IsMatch(x))
            {
                return "";
            }

            if (lowerTag.IsMatch(x))
            {
                x=x.ToLower();
                return x.Substring(7, x.Length - 15);
            }

            if(reverseTag.IsMatch(x))
            {
                x = x.Substring(5,x.Length-11);
                string newL = System.Environment.NewLine;//--------------
                newL = ReverseString(newL);//----------------
                x = ReverseString(x);
                x = Regex.Replace(x, newL, System.Environment.NewLine);//-----------------------------
                return x;
            }

            return x;
        }

        public static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }
    }
}
