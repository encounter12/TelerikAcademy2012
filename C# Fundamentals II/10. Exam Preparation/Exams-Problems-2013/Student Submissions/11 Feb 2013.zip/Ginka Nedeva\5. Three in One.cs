using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;



namespace ConsoleApplication3
{

    public static class Program
    {



        static void Main(string[] args)
        {

            string points = "21pointstowin";

            char player = 'b';

            Console.WriteLine(Individualchar(points, player));

            Console.ReadLine();

        }



        public static int Individualchar(string srtingsr, char Charfind)
        {

            int cnt = 0;

            char[] ch = srtingsr.ToCharArray();

            foreach (char c in ch)
            {

                if (c == Charfind)
                {

                    cnt++;

                }

            }

            return cnt;

        }





    }

}



Second Task


using System;

class CheckSymmetry
{
    static void Main()
    {
        Console.Write("Number of people = ");
        int size = int.Parse(Console.ReadLine());

        // Declaring the array
        int[] array = new int[size];

        // Filing the array
        for (int i = 0; i < size; i++)
        {
            Console.Write("arr[{0}] = ", i);
            array[i] = int.Parse(Console.ReadLine());
        }

        bool isSymmetric = true;
        for (int i = 0; i < (array.Length) / 2; i++)
        {
            if (array[i] != array[size - i - 1])
            {
                isSymmetric = false;
                break;
            }
        }
        Console.WriteLine("Symmetric? --> {0}", isSymmetric);
    }
}

