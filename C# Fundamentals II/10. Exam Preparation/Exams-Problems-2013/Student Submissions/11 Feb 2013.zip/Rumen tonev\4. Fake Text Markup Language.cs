using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace _4.FakeText
{
    class Program
    {
        static string Toggle(string title)
        {
            string temp="";
             for (int i = 0; i <= title.Length - 1; i++)
            {
                if (Char.IsLetter(title[i]))
                {
                    if (Char.IsLower(title[i]))
                    {
                        temp = (Char.ToUpper(title[i])).ToString();

                        title = title.Remove(i, 1);
                        title = title.Insert(i, temp);
                    }
                    else
                    {
                        temp = (Char.ToLower(title[i])).ToString();

                        title = title.Remove(i, 1);
                        title = title.Insert(i, temp);
                    }

                }
            } 
            return title;
        }
        static string toUpper(string title)
        {
            string temp = "";
            for (int i = 0; i <= title.Length - 1; i++)
            {
                if (Char.IsLetter(title[i]))
                {
                    if (Char.IsLower(title[i]))
                    {
                        temp = (Char.ToUpper(title[i])).ToString();
                        title = title.Remove(i, 1);
                        title = title.Insert(i, temp);
                    }
                }
            }
            return title;
        }
        static string toLower(string title)
        {
            string temp = "";
            for (int i = 0; i <= title.Length - 1; i++)
            {
                if (Char.IsLetter(title[i]))
                {
                    if (Char.IsUpper(title[i]))
                    {
                        temp = (Char.ToLower(title[i])).ToString();

                        title = title.Remove(i, 1);
                        title = title.Insert(i, temp);
                    }
                    

                }
            }
            return title;
        }


        static string reverse(string input)
        {
            char[] arr =input.ToCharArray();
	Array.Reverse(arr);
            string output=new string(arr);
	return output;
        }

        static string dealer(string input,string tag)
        {
            string output="";
            switch (tag)
	{
	    case "</upper>":output=toUpper(input);break;
	    case "</lower>":output=toLower(input);break;
	    case "</toggle>":output=Toggle(input);break;
	    case "</del>":output=String.Empty;break;
	    case "</rev>":output=reverse(input);break;
	   
		
	}


      return output ; }

        static void Main(string[] args)
        {

            int N =int.Parse( Console.ReadLine());
            int DelBeg;
            int firstInd;
            int Bigend;
            string input="";
            string bigString="";
            string output="";
            int textstart;
            string[] result = new string[N];
            string tag = "";
            for (int i = 0; i <= N-1; i++)
            {
                bigString = Console.ReadLine();
                while(bigString.IndexOf("</")!=-1)
                {
                    firstInd = bigString.IndexOf("</");
                    Bigend = bigString.IndexOf(">", firstInd);
                    textstart = bigString.LastIndexOf(">", firstInd)+1;
                    DelBeg = bigString.LastIndexOf("<", textstart);
                    tag = bigString.Substring(firstInd, Bigend-firstInd+1);
                    input = bigString.Substring(textstart, firstInd - textstart);
                    bigString = bigString.Remove(DelBeg, Bigend - DelBeg+1);
                output=dealer(input,tag);
                bigString = bigString.Insert(DelBeg, output);
                }
                result[i] = bigString;

            }
            for (int i = 0; i <= N - 1; i++)
            {
                Console.WriteLine(result[i]);
            }

        }


        }
    }
