using System;
using System.Collections.Generic;

    class Program
    {
        static void Main(string[] args)
        {
            string input_blackjack = "21,21,19";
            //string input_blackjack = Console.ReadLine();
            string[] str = input_blackjack.Split(',');
            int[] array2 = Array.ConvertAll<string, int>(str,int.Parse);
            


            string input_birthdayCake = "6,7,9,6,4";
           // string input_birthdayCake = Console.ReadLine();
            int friends = int.Parse(Console.ReadLine());
            string[] str_cake = input_birthdayCake.Split(',');
            int[] array1 = Array.ConvertAll<string, int>(str_cake, int.Parse);
            //int friends = 2;

           string proba = Console.ReadLine();
            
            
            
            


            
            BlackJack(array2);
            BirthdayCake(array1,friends);
         
            }
        
            
       
        private static void BirthdayCake(int[] cake,int friends)
        {
            
            int[] person = new int[friends + 1];
            int k = cake.Length - 1; int m = 0;

            Array.Sort(cake);
 
            while (k >= 0)
            {
                person[m] += cake[k];
                k--;
                m++;
                if (m == person.Length)
                {
                    m = 0;
                }
            }
            Console.WriteLine(person[0]);
        }

        private static void BlackJack(int[] points)
        {
           // int[] points = { 5, 20, 10, 23, 20 };
            int index_of_winner = 0;
            int max = int.MinValue;

            for (int i = 0; i < points.Length; i++)
            {
                int count = 0;

                if ((points[i] > max) && (points[i] <= 21) && (points[i] != max))
                {
                    count++;
                    max = points[i];
                    index_of_winner = i;
                }
                else if (points[i] == max)
                {
                    index_of_winner = -1;
                }

            }

            Console.WriteLine(index_of_winner);
        }
 

        }
    

