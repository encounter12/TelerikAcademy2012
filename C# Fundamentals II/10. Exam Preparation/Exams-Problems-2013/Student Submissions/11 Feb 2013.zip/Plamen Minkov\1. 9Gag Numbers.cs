using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
class Program
{
    static void Main(string[] args)
    {
        
        string text = Console.ReadLine();
        string numbers="";
        int br = 0;
        for (int i = 0; i < text.Length; i+=br)
        {
            if (text[i] == '-' && text[i + 1] == '!')
            {
                numbers += '0';
                br = 2;
            }
            else if (text[i] == '*' && text[i + 1] == '*')
            {
                numbers += '1';
                br = 2;
            }
            else if (text[i] == '!' && text[i + 1] == '!' && text[i + 2] == '!')
            {
                numbers += '2';
                br = 3;
            }
            //3
            else if (text[i] == '&' && text[i + 1] == '&')
            {
                numbers += '3';
                br = 2;
            }
            //4
            else if (text[i] == '&' && text[i + 1] == '-')
            {
                numbers += '4';
                br = 2;
            }
            //5
            else if (text[i] == '!' && text[i + 1] == '-')
            {
                numbers += '5';
                br = 2;
            }
            //6
            else if (text[i] == '*' && text[i + 1] == '!' && text[i+2] == '!' && text[i + 3] == '!')
            {
                numbers += '6';
                br = 4;
            }
            //7
            else if (text[i] == '&' && text[i + 1] == '*' && text[i + 2] == '!' )
            {
                numbers += '7';
                br = 3;
            }
            //8
            else if (text[i] == '!' && text[i + 1] == '!' && text[i + 2] == '*' && text[i + 3] == '*'
                    && text[i + 4] == '!' && text[i + 5] == '-')
            {
                numbers += '8';
                br = 6;
            }
        }
        double br1 = (double)numbers.Length,count=0;
        foreach (var item in numbers)
        {
            double n = item - '0';
            count+=Math.Pow(9.0, br1 - 1) * n; 
            br1--;
        }
        Console.WriteLine(count);
    }
}
