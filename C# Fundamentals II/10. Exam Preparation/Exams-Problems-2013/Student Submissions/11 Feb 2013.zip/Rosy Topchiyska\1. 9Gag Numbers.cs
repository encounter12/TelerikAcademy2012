using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace problem1
{
  class Program
  {
    static void Main()
    {
      StringBuilder input = new StringBuilder(Console.ReadLine());
      BigInteger number = 0;
      int digit = 0;
      while(input.Length > 0) {
        if(input.ToString().StartsWith("-!")) {
          digit = 0;
          input.Remove(0,2);
        } else if(input.ToString().StartsWith("**")) {
          digit = 1;
          input.Remove(0,2);
        } else if (input.ToString().StartsWith("!!!")) {
          digit = 2;
          input.Remove(0,3);
        } else if (input.ToString().StartsWith("&&")) {
          digit = 3;
          input.Remove(0,2);
        } else if (input.ToString().StartsWith("&-")) {
          digit = 4;
          input.Remove(0,2);
        } else if (input.ToString().StartsWith("!-")) {
          digit = 5;
          input.Remove(0,2);
        } else if (input.ToString().StartsWith("*!!!")) {
          digit = 6;
          input.Remove(0,4);
        } else if (input.ToString().StartsWith("&*!")) {
          digit = 7;
          input.Remove(0,3);
        } else if (input.ToString().StartsWith("!!**!-")) {
          digit = 8;
          input.Remove(0,6);
        }

        number = number * 9 + digit;
      }
      Console.WriteLine(number);

    }
  }
}
