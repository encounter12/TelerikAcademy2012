using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kukata_dancing
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            LinkedList<String> commands= new LinkedList<string>();
            for (int i = 0; i < n; i++)
            {
                commands.AddLast(new LinkedListNode<string>(Console.ReadLine()));
            }
            foreach (string dance in commands)
            {
                getDanceResult(dance);
            }
        }

        public static void getDanceResult(String dance)
        {
            Position pos = new Position();
            for (int i = 0; i < dance.Length; i++)
            {
                if (dance[i].Equals('L'))
                {
                    pos.turnLeft();
                }
                else if (dance[i].Equals('R'))
                {
                    pos.turnRight();
                }
                else
                {
                    pos.walk();
                }
            }
            Console.WriteLine(pos.currentPos);
        }

        public class Position
        {
            static readonly String b = "BLUE";
            static readonly String g = "GREEN";
            static readonly String r = "RED";

            public String currentPos;
            String prevPos;
            String currentDir;
            String prevDir;

            public Position()
            {
                currentPos = Position.g;
                prevPos = "";
                currentDir = Position.b;
                prevDir = "";
            }

            public void turnRight()
            {
                if (currentPos.Equals(Position.g))
                    return;
                else if (currentPos.Equals(Position.b))
                {
                    if (currentDir.Equals(Position.g) || currentDir.Equals(Position.b))
                    {
                        prevDir = currentDir;
                        currentDir = Position.r;
                    }
                    else
                    {
                        if (prevDir.Equals(Position.g))
                        {
                            prevDir = currentDir;
                            currentDir = Position.b;
                        }
                        else
                        {
                            prevDir = currentDir;
                            currentDir = Position.b;
                        }
                    }
                }
                else
                {
                    if (currentDir.Equals(Position.r))
                    {
                        if (prevDir.Equals(Position.b))
                        {
                            prevDir = currentDir;
                            currentDir = Position.r;
                        }
                        else
                        {
                            if (!prevPos.Equals(Position.b))
                            {
                                prevDir = currentDir;
                                currentDir = Position.b;
                            }
                            else
                            {
                                prevDir = Position.r;
                                currentDir = Position.r;
                            }
                        }
                    }
                    else
                    {
                        if (prevDir.Equals(Position.b))
                        {
                            prevDir = currentDir;
                            currentDir = Position.r;
                        }
                        else
                        {
                            prevDir = currentDir;
                            currentDir = Position.b;
                        }
                    }
                }
            }
            public void turnLeft()
            {
                if (currentPos.Equals(Position.g))
                    return;
                else if (currentPos.Equals(Position.b))
                {
                    if (currentDir.Equals(Position.g) || currentDir.Equals(Position.b))
                    {
                        prevDir = currentDir;
                        currentDir = Position.r;
                    }
                    else
                    {
                        if (prevDir.Equals(Position.g))
                        {
                            prevDir = currentDir;
                            currentDir = Position.b;
                        }
                        else
                        {
                            prevDir=currentDir;
                            currentDir = Position.g;
                        }
                    }
                }
                else
                {
                    if (currentDir.Equals(Position.r))
                    {
                        if (prevDir.Equals(Position.b))
                        {
                            prevDir = currentDir;
                            currentDir = Position.r;
                        }
                        else
                        {
                            prevDir = currentDir;
                            currentDir = Position.b;
                        }
                    }
                    else
                    {
                        if (prevDir.Equals(Position.b))
                        {
                            prevDir = currentDir;
                            currentDir = Position.r;
                        }
                        else
                        {
                            prevDir = currentDir;
                            currentDir = Position.b;
                        }
                    }
                }
            }
            public void walk()
            {
                if (currentPos.Equals(Position.g))
                {
                    prevPos = Position.g;
                    currentPos = Position.b;
                }
                else if (currentPos.Equals(Position.b))
                {
                    if (currentDir.Equals(Position.b))
                    {
                        currentDir = Position.g;
                    }
                    else if (currentDir.Equals(Position.g))
                    {
                        prevPos = currentPos;
                        currentPos = Position.g;
                        prevDir = currentDir;
                        currentDir = Position.b;
                    }
                    else if (currentDir.Equals(Position.r))
                    {
                        prevPos = currentPos;
                        currentPos = Position.r;
                        prevDir = currentDir;
                        currentDir = Position.r;
                    }
                }
                else
                {
                    if (currentDir.Equals(Position.b))
                    {
                        prevPos = currentPos;
                        currentPos = Position.b;
                        prevDir = currentDir;
                        currentDir = Position.r;
                    }
                    else if (currentDir.Equals(Position.r))
                    {
                        prevPos = currentPos;
                        currentPos = currentDir;
                        prevDir = currentDir;
                        currentDir = Position.b;
                    }
                }
            }
        }
    }
}
