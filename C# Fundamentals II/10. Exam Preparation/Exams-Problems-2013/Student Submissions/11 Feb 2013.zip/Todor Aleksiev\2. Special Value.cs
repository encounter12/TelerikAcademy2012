using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpecialValue
{
    class Program
    {
        static void CheckNum(int row, int col)
        {
            int nextIndex;
            if (array[row][col] >= 0)
            {
                nextIndex = array[row][col];
                path++;
                if (row + 1 == N)
                {
                    CheckNum(0, nextIndex);
                }
                else
                {
                    CheckNum(row + 1, nextIndex);
                }
            }
            else if (array[row][col] < 0)
            {
                sum = path + Math.Abs(array[row][col]);
                sums.Add(sum);
                sum = 0;
                path = 1;
                return;
            }
        }

        static int[][] array;
        static int N;
        static int path = 1;
        static int sum = 0;
        static List<int> sums = new List<int>();

        static void Main()
        {
            char[] separators = new char[] {' ', ',', '.'};
            string[] numbers;
            string input;
            

            N = int.Parse(Console.ReadLine());
            
            array = new int[N][];
            
            for (int i = 0; i < N; i++)
            {
                input = Console.ReadLine();
                numbers = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                array[i] = new int[numbers.Length];
                for (int t = 0; t < array[i].Length; t++)
                {
                    array[i][t] = int.Parse(numbers[t]);
                }
            }
            for (int m = 0; m < array[0].Length; m++)
            {
                CheckNum(0, m);
            }

            Console.WriteLine(sums.Max());
        }
    }
}
