
	
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
 
class Gag_Nine
{
    static void Main(string[] args)
    {
 
        string NineGag = "!!!!!**!-";
 
        ExtractCapitals(NineGag);
        // string NineGag="!!-!";
        //
        // string[] Digits = {"-!","**","!!!","&&","&-","!-","*!!!","&*!","!!**!-"};
        // for (int i = 0; i < Digits.Length; i++)
        // {
        //     Console.WriteLine("The decimal representation of {0} is {1}",Digits[i],i);
        // }
    }
    public static string ExtractCapitals(string NineGag)
    {
 
 
        string[] Digits = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < NineGag.Length; i++)
        {
            if (NineGag.Substring(NineGag.Length - 6, 6) == Digits[i])
            {
                Console.Write(i);
                break;
            }
            if (NineGag.Substring(NineGag.Length - 3, 3) == Digits[i])
            {
                Console.Write(i);
                break;
 
            }
            if (NineGag.Substring(NineGag.Length - 2, 2) == Digits[i])
            {
                Console.Write(i);
                break;
            }
       
            
             
        }
 
            return result.ToString();
           
 
 
 
        }
        
 
    }
