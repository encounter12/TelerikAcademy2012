using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01._9gagNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string Number9gag=Console.ReadLine();
            string[] NumberKey = {"-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
            StringBuilder digit = new StringBuilder();
            int[] Number=new int[100];
            int numberIndex = 0;
            int powerOfNine=1;
            int digitPosition = 0;
            int NumberDecimal = 0;

            for (int position = 0; position < Number9gag.Length; position++)
            {
                digit.Insert(digitPosition, Number9gag[position]); digitPosition++;
                for (int counter = 0; counter < 9; counter++)
                {
                    StringBuilder buffer = new StringBuilder();
                    buffer.Append(NumberKey[counter]);
                    if (buffer.Equals(digit)) { Number[numberIndex] = counter; numberIndex++; digitPosition = 0; digit.Clear(); }
                }
            }

            for (int counter = numberIndex-1; counter >= 0; counter--)
            {
                Number[counter] *= powerOfNine;
                powerOfNine *= 9;
                NumberDecimal+=Number[counter];
            }

            Console.WriteLine(NumberDecimal);
        }
    }
}