sing System;

class ThreeInOne
{
    static void Main()
    {
        string input = Console.ReadLine();
        string[] substrings = input.Split(',');
        int len = substrings.Length;
        int[] array = new int[len];  
        for (int i = 0; i < len; i++)
        {
            array[i] = int.Parse(substrings[i]);
        }
        Array.Sort(array);
        if (array[len - 1] != array[len - 2])
        {
            Console.WriteLine(0);
        }
        else
        {
            Console.WriteLine(-1);
        } 
    }
}