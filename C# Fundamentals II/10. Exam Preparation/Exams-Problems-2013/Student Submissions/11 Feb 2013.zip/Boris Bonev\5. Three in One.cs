using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class ThreeInOne
{
    static void Main()
    {
        string blackJackInput = Console.ReadLine();
        string[] blackJackPoint = blackJackInput.Split(',');
        int[] blackJarckPointsInt = new int[blackJackPoint.Length];

        int max = -1;
        int count = 0;
        bool oneWinner = true;

        for (int i = 0; i < blackJackPoint.Length; i++)
        {
            blackJarckPointsInt[i] = int.Parse(blackJackPoint[i]);
            if (blackJarckPointsInt[i] > 21) blackJarckPointsInt[i] = 0;
        }
        

        for (int i = 0; i < blackJarckPointsInt.Length; i++)
        {
            if (blackJarckPointsInt[i] > max) max = blackJarckPointsInt[i];            
        }

        for (int i = 0; i < blackJarckPointsInt.Length; i++)
        {            
            if (blackJarckPointsInt[i] == max) count++;
            if (count > 1) oneWinner = false;
        }

        if (oneWinner==true)
        {
            Console.WriteLine(0);
        }
        else
        {
            Console.WriteLine(-1);
        }
       
    }
}