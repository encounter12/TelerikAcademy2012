using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeInOne
{
    class Program
    {
        static void Main(string[] args)
        {
            string fLine = Console.ReadLine();
            string sLine = Console.ReadLine();
            int friends = int.Parse(Console.ReadLine());
            string thirdLine = Console.ReadLine();
            firstTask(fLine);
            secondTask(sLine,friends);
            Third(thirdLine);
        }

        static void firstTask(string line)
        {
            string[] numbersStr = line.Split(',');
            bool isWinner = false;
            int winnerIndex = 0;
            int[] scores = new int[numbersStr.Length];
            for (int i = 0; i < scores.Length; i++)
            {
                scores[i] = int.Parse(numbersStr[i]);
                if (scores[i] == 21 && !isWinner)
                {
                    winnerIndex = i;
                    isWinner = true;
                }

                else if (scores[i] == 21 && !isWinner)
                {
                    isWinner = false;
                    break;
                }
                else { }

            }

            if (isWinner)
            {
                Console.WriteLine(winnerIndex);
            }
            else
            {
                Console.WriteLine(-1);
            }
        }

        static void secondTask(string line, int friends)
        {
            string[] numbersStr = line.Split(',');
            int[] cakeBits = new int[numbersStr.Length];
            for (int i = 0; i < cakeBits.Length; i++)
            {
                cakeBits[i] = int.Parse(numbersStr[i]);
            }
            Array.Sort(cakeBits);
            int aten = 0;
            for (int i = cakeBits.Length - 1; i >= 0; i = i - friends-1)
            {
                aten += cakeBits[i];
            }
            Console.WriteLine(aten);
        }

        static void Third(string line)
        {
            string[] numbersStr = line.Split(' ');
            int givenG, givenS, givenB;
            int seekG, seekS, seekB;
            int counter = 0, delta;
            givenG = int.Parse(numbersStr[0]);
            givenS = int.Parse(numbersStr[1]);
            givenB = int.Parse(numbersStr[2]);
            seekG = int.Parse(numbersStr[3]);
            seekS = int.Parse(numbersStr[4]);
            seekB = int.Parse(numbersStr[5]);
            int totalGiven = givenG * 81 + givenS * 9 + givenB;
            int totalSeek = seekG * 81 + seekS * 9 + seekB;
            if (totalGiven >= totalSeek)
            {
                /*if (totalGiven == totalSeek)
                {
                    if (givenG >= seekG && givenS >= seekS && givenB >= seekB)
                    {
                        counter=
                    }
                }*/

                delta = totalGiven - totalSeek;
                if (givenG >= seekG&&givenS>=seekS)
                {
                    counter = delta / 9;
                }

                else if (givenG < seekG || givenS < seekS)
                {
                    counter = delta / 11;
                }
                else
                {
                    counter = delta / 10;
                }
            }

            else
            {
                counter = -1;
            }
            Console.WriteLine(counter);
        }

    }
}
