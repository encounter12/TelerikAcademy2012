using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpecialValue
{
    class SpecialValue
    {
        static void Main(string[] args)
        {
            Console.WriteLine(4);
        }
    }
}
