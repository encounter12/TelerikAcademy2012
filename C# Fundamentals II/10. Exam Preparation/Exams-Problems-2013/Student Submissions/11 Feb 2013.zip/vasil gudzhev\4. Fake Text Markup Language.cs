using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task2
{
    class Program
    {
        static void Main(string[] args)
        {

            string upper = "upper";
            string lower = "lower";
            string del = "del";
            string toggle = "toggle";
            int a = int.Parse(Console.ReadLine());
            string[] line = new string[a];
            string current = "";
            string final="";
            for (int i = 0; i < line.Length; i++)
            {
                line[i] = Console.ReadLine();
                current = line[i];

                int indexUpper = current.IndexOf(upper);
                while (indexUpper != -1)
                {
                    indexUpper = current.IndexOf(upper, indexUpper + 1);
                    final = ToUpper(current);
                }

                int indexLower = current.IndexOf(lower);
                while (indexLower != -1)
                {
                    indexLower = current.IndexOf(lower, indexLower + 1);
                    final = ToLower(current);
                }

                int indexDel = current.IndexOf(del);
                while (indexDel != -1)
                {
                    indexDel = current.IndexOf(del, indexDel + 1);
                    final = DeleteText(current);
                }

                int indexToggle = current.IndexOf(toggle);
                while (indexToggle != -1)
                {
                    indexToggle = current.IndexOf(toggle, indexToggle + 1);
                    final = Toggle(current);
                }
            }

          



         Console.WriteLine(final);

        }
        public static string ToUpper(string text)
        {
            string TagStart = "<upper>";
            string TagEnd = "</upper>";
            while (text.IndexOf(TagStart) != -1)
            {
                int PosStart = text.IndexOf(TagStart);
                int PosEnd = text.IndexOf(TagEnd);
                string temp = text.Substring(PosStart + TagStart.Length, PosEnd - PosStart - TagStart.Length);
                text = text.Replace(TagStart + temp + TagEnd, temp.ToUpper());
            }
            return text;
        }

        public static string ToLower(string text)
        {


            string TagStart = "<lower>";
            string TagEnd = "</lower>";
            while (text.IndexOf(TagStart) != -1)
            {
                int PosStart = text.IndexOf(TagStart);
                int PosEnd = text.IndexOf(TagEnd);
                string temp = text.Substring(PosStart + TagStart.Length, PosEnd - PosStart - TagStart.Length);
                text = text.Replace(TagStart + temp + TagEnd, temp.ToLower());
            }
            return text;
        }

        public static string DeleteText(string text)
        {


            string TagStart = "<del>";
            string TagEnd = "</del>";
            while (text.IndexOf(TagStart) != -1)
            {
                int PosStart = text.IndexOf(TagStart);
                int PosEnd = text.IndexOf(TagEnd);
                string temp = text.Substring(PosStart + TagStart.Length, PosEnd - PosStart - TagStart.Length);
                text = text.Replace(TagStart + temp + TagEnd, "");
            }
            return text;
        }

        public static string Toggle(string text)
        {

            string TagStart = "<toggle>";
            string TagEnd = "</toggle>";
            while (text.IndexOf(TagStart) != -1)
            {
                int PosStart = text.IndexOf(TagStart);
                int PosEnd = text.IndexOf(TagEnd);
                string temp = text.Substring(PosStart + TagStart.Length, PosEnd - PosStart - TagStart.Length);
                for (int i = 0; i < text.Length; i++)
                {
                   
                    if (char.IsLower(text[i]))
                    {
                        text = text.Replace(TagStart + temp + TagEnd, temp.ToUpper()); 
                    }
                    else if (char.IsUpper(text[i]))
                    {
                        text = text.Replace(TagStart + temp + TagEnd, temp.ToLower());
                    }
                }
            }
            return text;
        }

        //public static string Reverse(string text, string tag)
        //{


        //    string TagStart = "<" + tag + ">";
        //    string TagEnd = "</" + tag + ">";
        //    char[] array = text.ToCharArray();
        //    Array.Reverse(array);
        //    text = array.ToString();
        //    string text1 = text;
        //    while (text1.IndexOf(TagStart) != -1)
        //    {
        //        int PosStart = text1.IndexOf(TagStart);
        //        int PosEnd = text1.IndexOf(TagEnd);
        //        string temp = text1.Substring(PosStart + TagStart.Length, PosEnd - PosStart - TagStart.Length);
        //        text1 = text1.Replace(TagStart + temp + TagEnd, temp);
        //    }
        //    return text;
        //}
    }
}
