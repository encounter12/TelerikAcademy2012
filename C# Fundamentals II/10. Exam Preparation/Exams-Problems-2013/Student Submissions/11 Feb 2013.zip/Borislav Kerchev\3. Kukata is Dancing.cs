using System;
using System.Collections.Generic;
using System.Text;

namespace BB
{
    class Program
    {
        static void Main(string[] args)
        {
            char[,] rubik = new char[2, 2];

            // read steps
            int lx, ly, x, y;
            String steps = Console.ReadLine();
            int N = Convert.ToInt16(steps);
            for (int i = 1; i <= N; i++)
            {
                x = 1; y = 1;
                lx = 1; ly = 1;
                steps = Console.ReadLine();
                while (steps != "")
                {
                    switch(steps.Substring(0, 1))
                    {
                        case "L":
                            if ((ly == 1) && (lx == 0)) { ly = 0; lx = 1; }
                            if ((ly == 0) && (lx == 1)) { ly = -1; lx = 0; }
                            if ((ly == -1) && (lx == 0)) { ly = 0; lx = -1; }
                            if ((ly == 0) && (lx == -1)) { ly = 1; lx = 0; }
                            break;
                        case "R":
                            if ((ly == 1) && (lx == 0)) { ly = 0; lx = -1; }
                            if ((ly == 0) && (lx == -1)) { ly = -1; lx = 0; }
                            if ((ly == -1) && (lx == 0)) { ly = 0; lx = 1; }
                            if ((ly == 0) && (lx == 1)) { ly = 1; lx = 0; }
                            break;
                        case "W":
                            x += lx;
                            y += ly;
                            if (x > 2) x = 0;
                            if (y > 0) y = 0;
                            if (x < 0) x = 2;
                            if (y < 0) y = 2;
                            break;
                    }
                    // remove passed char
                    steps = steps.Substring(1);
                }
                // write final color
                switch (Math.Abs(x - y))
                {
                    case 0:
                        if (x == 1) 
                            Console.Write("GREEN \r\n");
                        else
                            Console.Write("RED \r\n");
                        break;
                    case 1:
                        Console.Write("BLUE \r\n");
                        break;
                    case 2:
                        Console.Write("RED \r\n");
                        break;
                }
            }
        }
    }
}