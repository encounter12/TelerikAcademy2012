using System;

//{}
//[]
class Task2
{
    static int CalcPath(int indexRow, int indexCol, int[,] fieldArr, bool[,] visited)
    { 
        if (!visited [indexRow,indexCol])
        {
            int nextColIndex = fieldArr[indexRow, indexCol];
            if (nextColIndex >=0)
            {
                visited[indexRow, indexCol] = true;
                indexRow++;
                if (indexRow == fieldArr.GetLength(0))
                {
                    indexRow = 0;
                }
                return CalcPath(indexRow, nextColIndex, fieldArr, visited) + 1;
            }
            else
            {
                return Math.Abs(nextColIndex)+1;
            }
        }
        else
        {
            return 0;
        }
    }

    static void Main()
    {
        int numberRows = int.Parse(Console.ReadLine());
        int [,] field = new int [numberRows,1000];
        bool [,] visited = new bool [numberRows,1000];
        int firstRowCount = 0;
        string[] row = Console.ReadLine().Split(new string []{", "},StringSplitOptions.None);
        firstRowCount = row.Length;
        for (int j = 0; j < row.Length; j++)
        {
            field[0, j] = int.Parse(row[j]);
        }
            
        for (int i = 1; i < numberRows; i++)
        {
            row = Console.ReadLine().Split(new string[] { ", " }, StringSplitOptions.None);
            for (int j = 0; j < row.Length; j++)
            {
                field[i, j] = int.Parse(row[j]);
            }
        }

        int maxPath = 0;
        for (int i = 0; i < firstRowCount; i++)
        {
            int currentPath = CalcPath(0, i, field, visited);

            if (maxPath < currentPath)
            {
                maxPath = currentPath;
            }
        }
        Console.WriteLine(maxPath);
    }
}
