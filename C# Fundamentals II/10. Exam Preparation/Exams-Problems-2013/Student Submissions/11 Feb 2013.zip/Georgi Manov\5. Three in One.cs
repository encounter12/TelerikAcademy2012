using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Three_in_One
{
    class Program
    {
        static void Main(string[] args)
        {
            //1.
            int result1 = BlackJack();
            Console.WriteLine("The first result is {0}", result1);

            //2.
            Console.WriteLine("Enter the number of friends:");
            int F = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the number of cackes:");
            int s = int.Parse(Console.ReadLine());
            int[] sizes = new int[s];

            int max = 0, pos = 0;

            int[] people = new int[F + 1];

            while (s > 0)
            {
                for (int i = 0; i < people.Length; i++)
                {
                    for (int j = 0; j < sizes.Length; j++)
                    {
                        if (max <= sizes[j]) { max = sizes[j]; pos = j; }
                    }
                    people[i] += max;
                    sizes[pos] = 0; s--;
                }
            }

            Console.WriteLine("The amount of cackes I have is: {0}", people[0]);

            //3.
            int G1, S1, B1, G2, S2, B2;
            G1 = int.Parse(Console.ReadLine());
            S1 = int.Parse(Console.ReadLine());
            B1 = int.Parse(Console.ReadLine());

            G2 = int.Parse(Console.ReadLine());
            S2 = int.Parse(Console.ReadLine());
            B2 = int.Parse(Console.ReadLine());



        }

        public static int Beer(int G1, int S1, int B1, int G2, int S2, int B2)
        {
            int count = 0;
            if (G1 < G2)
            {
                if (S1 <= S2)
                {
                    if (B1 <= B2) { return -1; }
                    else
                    {
                        S1 += BronzetoSilver(B1 - B2); count += B1 - B2;
                        if (S1 <= S2) return -1;
                        else
                        {
                            G1 += SilvertoGold(S1 - S2); count += S1 - S2;
                            if (G1 < G2) return -1;
                            else return count;
                        }
                    }
                }
                else
                {
                    G1 = SilvertoGold(S1 - S2); count += S1 - S2;
                    if (G1 < G2) return -1;
                    else
                    {
                        if (B1 < B2) return -1;
                        else return count;
                    }
                }
            }
            else
            {
                if (S1 < S2)
                {
                    if (B1 <= B2)
                    {
                        S1 += GoldtoSilver(G1 - G2); count += G1 - G2;
                        if (S1 < S2) return -1;
                        else return count;
                    }
                    else
                    {
                        S1 += BronzetoSilver(B1 - B2); count += B1 - B2;
                        if (S1 < S2)
                        {
                            if (G1 <= G2) return -1;
                            else
                            {
                                S1 = GoldtoSilver(G1 - G2); count = G1 - G2;
                            }
                        }
                        else return count;
                    }
                }
                else
                {
                    if (B1 < B2)
                    {
                        B1 += SilvertoBronze(S1 - S2); count += S1 - S2;
                        if (B1 < B2)
                        {
                            S1 += GoldtoSilver(G1 - G2); count += G1 - G2;
                            B1 += SilvertoBronze(S1 - S2); count += S1 - S2;
                            if (B1 < B2) return -1;
                            else return count;
                        }
                        else return count;
                    }
                    else return count;
                } return count; 
            }
        }
        public static int SilvertoGold(int S)
        {
            return (int)S / 9;
        }
        public static int GoldtoSilver(int G)
        {
            return G * 11;
        }
        public static int SilvertoBronze(int S)
        {
            return (int)S / 9;
        }
        public static int BronzetoSilver(int B)
        {
            return B*11;
        }


        public static int BlackJack()
        {
            int winner = 0, counter = 0, maxnum = 0;
            string number = "";

            Console.WriteLine("Enter the number of players: ");
            int i = int.Parse(Console.ReadLine());

            int[] points = new int[i];

            string players;
            Console.WriteLine("Enter the point of each player:");
            players = Console.ReadLine();

            int j = 0;
            while (j < players.Length)
            {
                if (players[j] != ',')
                {
                    number = number + players[j]; j++;
                }
                else
                {
                    points[counter] = int.Parse(number); counter++; j++;
                }
            }

            for (int k = 0; k < points.Length; k++)
            {
                if (points[k] <= 21)
                {
                    if (points[k] > maxnum)
                    {
                        maxnum = points[k]; winner = k;
                    }
                    else if (points[k] == maxnum) { winner = -1; }
                    else continue;
                }
                else { winner = -1; }
            }

            return winner;
        }
    }
}

