using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

class FTML
{
	static void Main()
	{
#if DEBUG
		Console.SetIn(new StreamReader("TestInput001.txt"));
#endif
		int n = int.Parse(Console.ReadLine());
		string[] lines = new string[n];
		string text = string.Empty;
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < n; i++)
		{
			lines[i] = Console.ReadLine();
			sb.AppendLine(lines[i]);
		}
		text = sb.ToString();
		Regex inner = new Regex(@"<(?<tag>[\w]+)>(?<content>[^<>]*)</\1>", RegexOptions.IgnoreCase);
		while (inner.IsMatch(text))
		{
			text = inner.Replace(text, ReplaceInnermostElement);
		}
		Console.Write(text);
	}
	public static string ReplaceInnermostElement(Match m)
	{
		string s = m.Groups["content"].Value;
		StringBuilder sb = new StringBuilder();
		switch (m.Groups["tag"].Value)
		{
			case "del": 
				s = string.Empty;
				break;
			case "rev": 
				sb = new StringBuilder(s.Length);
				for (int i = s.Length - 1; i >= 0; i--)
				{
					if (i > 0 && s[i] == '\n' && s[i - 1] == '\r')
					{
						sb.AppendLine();
						i--;
					}
					else
					{
						sb.Append(s[i]);
					}
				}
				s = sb.ToString();
				break;
			case "upper":
				s = s.ToUpper();
				break;
			case "lower":
				s = s.ToLower();
				break;
			case "toggle": 
				sb = new StringBuilder(s.Length);
				for (int i = 0; i < s.Length; i++)
				{
					if (s[i] >= 'a' && s[i] <= 'z')
					{
						sb.Append((char)(s[i] - 32));
					}
					else if (s[i] >= 'A' && s[i] <= 'Z')
					{
						sb.Append((char)(s[i] + 32));
					}
				}
				s = sb.ToString();
				break;
			default: throw new ArgumentOutOfRangeException();
		}
		return s;
	}
}