using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class sBaseTorBase
{
    static string Convert (string toconvert)
    {
        string converted = "";
        switch (toconvert)
        {
            case "-!": converted = "0"; break;
            case "**": converted = "1"; break;
            case "!!!": converted = "2"; break;
            case "&&": converted = "3"; break;
            case "&-": converted = "4"; break;
            case "!-": converted = "5"; break;
            case "*!!!": converted = "6"; break;
            case "&*!": converted = "7"; break;
            case "!!**!-": converted = "8"; break;

        }
        return converted;
    }

    static void Main()
    {
        string input = Console.ReadLine();
        
        //string input = "!!**!--!!-";

        string finalString = "";
        string[] pattern = { "^\\-\\!", "^\\*\\*", "^\\!\\!\\!", "^\\&\\&", "^\\&\\-", "^\\!\\-", "^\\*\\!\\!\\!", "^\\&\\*\\!", "^\\!\\!\\*\\*\\!\\-" };

        //string digit = pattern[0];
        int check = 0;
       
        int left = input.Length;
        while (left > 0)
        {
            for (int i = 0; i < pattern.Length; i++)
            {
                string digit = pattern[i];
                Match match = Regex.Match(input, digit);
                while (match.Success)
                {
                    finalString += Convert((match.Value).ToString());
                    check = match.Value.Length;
                    match = match.NextMatch();
                    left -= check;
                    string temp = input.Substring(check,input.Length-check);
                    input = temp;
                    continue;
                }
            }
        }
        double finalDigit = 0;
        //Console.WriteLine(finalString);

        for (int i = 0; i < finalString.Length; i++)
        {
            finalDigit += double.Parse(finalString[i].ToString()) * Math.Pow(9, finalString.Length-1 - i);
            //Console.WriteLine(finalDigit);
        }
        Console.WriteLine(finalDigit);
    }
}
