using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9gag
{
    class Program
    {
        public static long convertToDecimal(string text)
        {
            string[] legend = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };

            for (int i = legend.Length - 1; i >= 0; i--)
            {
                while (text.IndexOf(legend[i]) != -1)
                {
                    if (text.IndexOf(legend[i]) != 1)
                    {

                        int startPosition = text.IndexOf(legend[i]);
                        int endPosition = startPosition + legend[i].Length;

                        string temp = text.Substring(startPosition + legend[i].Length, endPosition - startPosition - legend[i].Length);
                        text = text.Replace(legend[i], i.ToString());
                    }
                    else if (text.IndexOf(legend[i]) == 1 && char.IsDigit(text[0]))
                    {
                        int startPosition = text.IndexOf(legend[i]);
                        int endPosition = startPosition + legend[i].Length;

                        string temp = text.Substring(startPosition + legend[i].Length, endPosition - startPosition - legend[i].Length);
                        text = text.Replace(legend[i], i.ToString());
                    }
                    else break;
                }
            }

            text = ReverseString(text);
            
            long sum = (long)(text[0] - '0');
            for (int i = 1; i < text.Length; i++)
            {
                char c = text[i];
                int k = (int)(c - '0');
                sum += k * (long)Math.Pow(9, i);
            }

            return sum;

        }

        public static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }

        static void Main(string[] args)
        {
            string text = Console.ReadLine();
            Console.WriteLine(convertToDecimal(text));
        }
    }
}
