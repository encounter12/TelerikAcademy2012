using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] names = new string[9] { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
            foreach (string name in names)
            {
                System.Console.WriteLine(name);
            }
            Console.WriteLine("type your 9Gag number(between 1 and 20 digits):");
            string input = Console.ReadLine();
            if (input == names[0])
            {
                Console.WriteLine(0);
            }
            else if (input == names[1])
            {
                Console.WriteLine(1);
            }
            else if (input == names[2])
            {
                Console.WriteLine(2);
            }
            else if (input == names[3])
            {
                Console.WriteLine(3);
            }
            else if (input == names[4])
            {
                Console.WriteLine(4);
            }
            else if (input == names[5])
            {
                Console.WriteLine(5);
            }
            else if (input == names[6])
            {
                Console.WriteLine(6);
            }
            else if (input == names[7])
            {
                Console.WriteLine(7);
            }
            else if (input == names[8])
            {
                Console.WriteLine(8);
            }
            else if (input == names[9])
            {
                Console.WriteLine(9);
            }
        }
    }
}