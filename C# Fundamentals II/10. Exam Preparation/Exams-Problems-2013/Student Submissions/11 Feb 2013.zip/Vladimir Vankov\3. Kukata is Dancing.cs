using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kukata
{
    class Kukata
    {   
        static string KukataMove(string[] movements,string[,] danceFloar)
        {
            int rows = 1;
            int cols = 1;
            for (int i = 0; i < movements.Length; i++)
            {
                string subString = movements[i];
                char[] charMovements = subString.ToCharArray();
                for (int j = 0; j < charMovements.Length; j++)
                {
                    if (charMovements[i] == 'W')
                    {
                        if (cols < 3)
                        {
                            cols++;
                        }
                        else
                        {
                            cols = 0;
                        }

                    }
                }
            }
            return danceFloar[rows, cols];
        }
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] movements = new string[n];
            for (int i = 0; i < n; i++)
            {
                movements[i] = Console.ReadLine();
            }
            
            string[,] danceFloar = new string[3,3]
            {
            {"RED","BLUE","RED"},
            {"BLUE","GREEN","RED"},
            {"RED","BLUE","RED"}                 
            };

            Console.WriteLine(KukataMove(movements,danceFloar));

        }
    }
}
