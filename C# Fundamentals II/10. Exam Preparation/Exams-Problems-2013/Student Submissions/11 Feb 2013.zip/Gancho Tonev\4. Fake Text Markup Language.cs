using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Markup
{
    static void Main()
    {
        int numberRows = int.Parse(Console.ReadLine());
        //int numberRows = 1;
        int lastCommand = 0;
        int[] tagBegin = new int[6];
        string[] lines = new string[501];
        int currentTagBegin;
        //lines[0] = "<lower>Inside nested</lower> <upper>Before nested <lower>Inside nested</lower> After nested </upper><del>xxx</del> ";
        //lines[0] = "<upper><lower><upper>here</upper></lower></upper>";
        StringBuilder result = new StringBuilder();
        string lineInp="";
        for (int lineN = 0; lineN < numberRows; lineN++)
        {
            string nextRow = Console.ReadLine();
            lineInp = lineInp + nextRow;
        }

        for (int lineN = 0; lineN < numberRows; lineN++)
        {
            
           
            for (int charIndex = 0; charIndex < lineInp.Length - 1; charIndex++)
            {
                char currentChar = lineInp[charIndex];
                for (int i = currentChar; i < lineInp.Length - 1; i++)
                {
                    if (lineInp[i] == '<')
                    {
                        break;
                    }
                    result.Append(char.ToUpper(lineInp[i]));
                }
                if (currentChar == '<')
                {
                    char tagComm = char.ToUpper(lineInp[charIndex + 1]);
                    if (tagComm == 'U')
                    {
                        charIndex = tagUpper(result, lineInp, charIndex, tagComm);
                    }

                    if (tagComm == 'L')
                    {
                        charIndex = tagLower(result, lineInp, charIndex, tagComm);
                    }

                    if (tagComm == 'D')
                    {
                        for (int del = charIndex; del < lineInp.Length - 2; del++)
                        {
                            if ((lineInp[del] == '<') && (lineInp[del + 1] == '/'))
                            {
                                if (lineInp.Substring(del + 2, 4).ToUpper() == "DEL>")
                                {
                                    charIndex = del + 5;
                                    break;
                                }
                            }
                        }
                    }
                    continue;
                }

            }
            lineN = 10;

        }
        Console.WriteLine(result);
    }

    private static int tagLower(StringBuilder result, string lineInp, int charIndex, char tagComm)
    {


        charIndex = charIndex + 7;
        int stop = 0;
        for (int del = charIndex; del < lineInp.Length - 2; del++)
        {
            while (lineInp[del] == '<')
            {
                if ((lineInp[del] == '<') && (lineInp[del + 1] == '/'))
                {
                    string delim = lineInp.Substring(del + 2, 6).ToUpper();
                    if (lineInp.Substring(del + 2, 6).ToUpper() == "LOWER>")
                    {
                        charIndex = del + 7;
                        stop = 1;
                        break;
                    }

                }
                if (lineInp[del] == '<')
                {
                    for (int nestedTag = del + 1; nestedTag < lineInp.Length - 1; nestedTag++)
                    {
                        if (lineInp[nestedTag] == '>')
                        {
                            del = nestedTag + 1;
                            break;
                        }
                    }
                }
            }
            if (stop == 1)
            {
                break;
            }
           
            result.Append(char.ToLower(lineInp[del]));
         
        }

        return charIndex;

    }
    private static int tagUpper (StringBuilder result, string lineInp, int charIndex, char tagComm)
    {


        charIndex = charIndex + 7;
        int stop = 0;
        for (int del = charIndex; del < lineInp.Length - 2; del++)
        {
            while (lineInp[del] == '<')
            {
                if ((lineInp[del] == '<') && (lineInp[del + 1] == '/'))
                {
                    string delim = lineInp.Substring(del + 2, 6).ToUpper();
                    if (lineInp.Substring(del + 2, 6).ToUpper() == "UPPER>")
                    {
                        charIndex = del + 7;
                        stop = 1;
                        break;
                    }

                }
                if (lineInp[del] == '<')
                {
                    for (int nestedTag = del + 1; nestedTag < lineInp.Length - 1; nestedTag++)
                    {
                        if (lineInp[nestedTag] == '>')
                        {
                            del = nestedTag + 1;
                            break;
                        }
                    }
                }
            }
            if (stop == 1)
            {
                break;
            }

            result.Append(char.ToUpper(lineInp[del]));

        }

        return charIndex;

    }
}
