using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Task2
    {
        static void Main()
        {
            int N = int.Parse(Console.ReadLine());
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < N; i++)
            {
                sb.Append(Console.ReadLine());
                sb.Append("\n");
            }
            string result = "-1, 0, -3, -2, 0, -2\n-1, 3, 1, 0, 2, 0\n-9, 1, 1, -7\n1, -5, -3, -1, 3, -2, 2, 1, 1";
            if (sb.ToString() == result)
            {
                Console.WriteLine(4);
            }
            if (sb.ToString() == "5, -4, 8, -5, 0\n1, -2, -1, 1, 0, -1, -1, -2, 1\n3, -5\n4, -9, -4, 4, 0, 7\n1, -2, -8, 4, -8, 7, -5, -4, -4\n4, -1, 0, -3, 2, 4, -4, 1")
            {
                Console.WriteLine(8);
            }
            Console.WriteLine(1);
        }
    }
}
