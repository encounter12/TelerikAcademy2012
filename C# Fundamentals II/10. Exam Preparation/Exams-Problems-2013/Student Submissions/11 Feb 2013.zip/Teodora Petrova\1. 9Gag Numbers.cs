using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

 
namespace _9GagNumbers
{
    public struct stack_element
    {
        public int j; //koe chislo podred
        public int temp_result; //pazi teku6toto 4islo
        public int ind; //index v samiq string-4islo
    }
   
    class Program
    {
        public static string[] digitsLibrary = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };

        static void Main(string[] args)
        {
            Stack<stack_element> myStack = new Stack<stack_element>();

            string NGagNumber = Console .ReadLine ();
            bool exit = false;

            stack_element s = new stack_element ();
            s.j = 0;
            s.ind = NGagNumber .Length ;
            s.temp_result = 0;

            myStack.Push(s);

            while (myStack.Count != 0)
            {
                stack_element element = myStack.Pop();
                for (int k = element.ind - 1; k >= 0; k--)
                {
                    for (int l = 0; l < digitsLibrary.Length; l++)
                    {
                        if(NGagNumber .Substring (k,element .ind -k).CompareTo(digitsLibrary [l]) == 0)
                        {
                            stack_element new_element = new stack_element();
                            new_element .temp_result  = element.temp_result + l * (int)Math.Pow ((double)9,(double)element.j);
                            new_element.j = element.j + 1;
                            new_element.ind  = k;
                            if (k == 0)
                            {
                                Console.WriteLine(new_element.temp_result);
                                exit = true;
                                break;
                            }
                            else
                            {
                                myStack.Push(new_element);
                            }
                        }
                    }
                    if (exit)
                        break;
                }
                if (exit)
                    break;
            }
        }
        
    }
}
