using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
 
class Program
{
    static string inp;
    static StringBuilder result = new StringBuilder();
    static StringBuilder tmpsb = new StringBuilder();
    static bool deleted = false;
 
    static void Main()
    {
        StringBuilder sbinput = new StringBuilder();
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            sbinput.AppendLine(Console.ReadLine());
            //sbinput.Append("\r\n");
        }
        inp = sbinput.ToString();
        bool inTag = false;
        int inTagCnt = 0;
        for (int i = 0; i < inp.Length; i++)
        {
             
           // bool inClosingTag = false;
 
            //if (!inTag)
            if (!inTag)
            {
 
                if (inp[i] == '<')
                {
                    if (inTagCnt == 0)
                    {
                        result.Append(tmpsb);
                        tmpsb.Clear();
                    }
                    inTag = true;
                    inTagCnt++;
                    tmpsb.Append('}');
                }
                else
                {
                    if (inp[i] == '\r' && inp[i+1] == '\n')
                    {
                        tmpsb.Append(Environment.NewLine);
                        i++;
                    }
                    else if (inp[i] == '\n' && inp[i+1] == '\r')
                    {
                        tmpsb.Append(Environment.NewLine);
                        i++;
                    }
                    else
                    {
                        tmpsb.Append(inp[i]);
 
                    }
                }
            }
            else
            {
                if (inp[i] == '>')
                {
                    inTag = false;
                    //inTagCnt--;
                }
                else if (inp[i] == '/')
                {
                    tmpsb.Remove(tmpsb.Length - 1,1);
                    //inClosingTag = true;
                    string tagname = ReadTag(i);
                    Execute(tagname, i);
                    i += tagname.Length - 1;
                    inTag = false;
                    inTagCnt--;
                    inTagCnt--;
                    if (inTagCnt == 0)
                    {
                        //if (string.IsNullOrEmpty(tmpsb.ToString()) && deleted)
                        //{
                        //    if (result.Length >= 1)
                        //        result.Remove(result.Length - 1, 1);
                        //    deleted = false;
                             
                        //}
                        result.Append(tmpsb.ToString());
                        tmpsb.Clear();
                    }
                }
            }
        }
        Console.WriteLine(result);
    }
 
    private static void Execute(string function, int pos)
    {
        string toManip = tmpsb.ToString();
        string manip = toManip.Substring(toManip.LastIndexOf('}')+1);
        string remaining = toManip.Substring(0, toManip.Length - manip.Length-1);
 
        if(function == "/rev>"){
            string revtxt = ReverseString(manip);
            tmpsb.Clear();
            tmpsb.Append(remaining);
            tmpsb.Append(revtxt);
            return;
        }
        else if(function == "/upper>")
        {
            string upper = manip.ToUpper();
            tmpsb.Clear();
            tmpsb.Append(remaining);
            tmpsb.Append(upper);
            return;
        }
        else if(function == "/lower>")
        {
            string lower = manip.ToLower();
            tmpsb.Clear();
            tmpsb.Append(remaining);
            tmpsb.Append(lower);
            return;
        }
        else if(function == "/toggle>")
        {
            StringBuilder togled = new StringBuilder();
            for (int i = 0; i < manip.Length; i++)
            {
                if (char.IsUpper(manip[i]))
                {
                    if (manip[i] != '\n' && manip[i] != '\r')
                        togled.Append(char.ToLower(manip[i]));
                }
                else
                {
                    if (manip[i] != '\n' && manip[i] != '\r')
                        togled.Append(char.ToUpper(manip[i]));
                }
            }
            tmpsb.Clear();
            tmpsb.Append(remaining);
            tmpsb.Append(togled);
            return;
        }
 
        else if (function == "/del>")
        {
            tmpsb.Clear();
            //if (!string.IsNullOrEmpty(remaining))
                tmpsb.Append(remaining);
                deleted = true;
            return;
        }
    }
 
    private static string ReadTag(int i)
    {
        StringBuilder tmptag = new StringBuilder();
 
        for (int j = i; j < inp.Length; j++)
        {
            tmptag.Append(inp[j]);
 
            if (inp[j] == '>')
                return tmptag.ToString();
        }
        return tmptag.ToString();
    }
 
    private static string ReverseString(string str)
    {
        //char[] tmp = str.ToCharArray();
        //Array.Reverse(tmp);
        //return new string(tmp);
 
        StringBuilder tmp = new StringBuilder();
        for (int i = str.Length-1; i >= 0; i--)
        {
            if (str[i] == '\n' || str[i] == '\r')
            {
                 
                //if (str[i - 1] == '\r')
                //{
                //    i--;
                //    tmp.Append(Environment.NewLine);
                //}
                //else
                //{
                //    tmp.Append(str[i]);
                //}
                tmp.Append(Environment.NewLine);
                i--;
            }
 
            //else if (str[i] == '\r')// str[i] == '\n')
            //if (str[i] == Environment.NewLine)
            //{
                //if (str[i] = 'r')
                //tmp.Append(str[i - 1]);
                //tmp.Append(str[i]);
                 
 
                //tmp.Append(Environment.NewLine);
                //i--;
                 
            //}
            else
            {
                tmp.Append(str[i]);
            }
             
        }
        return tmp.ToString();
    }
 
}
 
//      <rev></rev>
//      <upper></upper>
//      <lower></lower>
//      <toggle></toggle>
//      <del></del>