using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1
    {
    class Program
        {
        static void Main()
        {                
            Console.WriteLine("Vyvedi string:");
            string digits;
            digits = Console.ReadLine();
            while (digits.Length > 20){
            digits = Console.ReadLine();
                };
            string[] basic = new string[] { "-!","**","!!!","&&","&-","!-","*!!!","&*!","!!**!-"};
            if(digits.Length<6)   
            Compare(digits);
                }

        static void Compare(string input)
            {
            string str;
            for (int i = 1; i < input.Length;)
                {
                str = input.Substring(0, i);
                Num(str);
                i++;
                }
            //if (h = true) {
            //input = input.Substring(str.Length, input.Length);
            //Compare(input);
            //    }
            //Compare(input);
                                              
            }
        static void Num(string input ) 
            {
            switch (input)
                {
                case "-!": 
                    Console.WriteLine("0");
                    break;
                case "**": Console.WriteLine("1"); break;
                case "!!!": Console.WriteLine("2"); break;
                case "&&": Console.WriteLine("3"); break;
                case "&-": Console.WriteLine("4"); break;
                case "!-": Console.WriteLine("5"); break;
                case "*!!!": Console.WriteLine("6"); break;
                case "&*!": Console.WriteLine("7"); break;
                case "!!**!-": Console.WriteLine("8"); break;
                }
            }
                 
        }
        }
   
