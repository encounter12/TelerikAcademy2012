using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class KukataIsDancing
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string[] moves = new string[n];
        for (int i = 0; i < n; i++)
        {
            moves[i] = Console.ReadLine();
        }
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine("GREEN");    
        }
        

        //for (int dance = 0; dance < n; dance++)
        //{
        //    string oneDance = moves[dance];
        //    for (int move = 0; move < oneDance.Length; move++)
        //    {
                
        //    }
        //}

    }
}