using System;

class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        String[] dances = new String[n];
        for (int i = 0; i < n; i++)
        {
            dances[i] = Console.ReadLine();
        }

        int[,] moves = {{1, 0}, {0, -1}, {-1, 0}, {0, 1}};
        int move = 0;
        for (int i = 0; i < n; i++)
        {
            int xMove = 1, yMove = 0, x = 1, y = 1;
            for (int j = 0; j < dances[i].Length; j++)
			{
                switch (dances[i][j])
                {
                    case 'L':
                        move++;
                        if (move == 4)
                        {
                            move = 0;
                        }
                        break;
                    case 'R':
                        move--;
                        if (move == -1)
                        {
                            move = 3;
                        }
                        break;
                    case 'W':
                        x = x + moves[move,0];
                        y = y + moves[move,1];
                        if (x == 3)
                        {
                            x = 0;
                        }
                        else if (x == -1)
                        {
                            x = 2;
                        }

                        if (y == 3)
                        {
                            y = 0;
                        }
                        else if (y == -1)
                        {
                            y = 2;
                        }
                        break;
                }
			}
            if (x == 1 && y == 1)
            {
                Console.WriteLine("GREEN");
            }
            else if ((x == 0 || x == 2) && (y == 0 || y == 2))
            {
                Console.WriteLine("RED");
            }
            else
            {
                Console.WriteLine("BLUE");
            }
        }

    }
}