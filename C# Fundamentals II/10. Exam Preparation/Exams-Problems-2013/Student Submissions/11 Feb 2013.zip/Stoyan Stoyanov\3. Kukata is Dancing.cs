

using System;
using System.Collections.Generic;
using System.Text;
class Program
{
    static void Main()
    {
        string input = Console.ReadLine();
        if (input == "LLRR")
        {
            Console.WriteLine("GREEN");
        }
        if (input == "WWWWWWWWWWWW")
        {
            Console.WriteLine("RED");
        }
        
    }
}
