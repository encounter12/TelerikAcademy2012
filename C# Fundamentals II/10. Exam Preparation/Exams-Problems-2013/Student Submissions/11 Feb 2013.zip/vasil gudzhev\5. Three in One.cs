using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = Console.ReadLine();
            int[] numbers = Array.ConvertAll(s.Split(','), int.Parse);

            string two = Console.ReadLine();
            int[] twoSizes = Array.ConvertAll(two.Split(','), int.Parse);
            int friend=int.Parse(Console.ReadLine());

            string three = Console.ReadLine();
            string[] threeArr = three.Split(' ');

            bool isTrue = true;
            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i]==21)
                {
                    isTrue = true;
                    Console.WriteLine("0");
                    break;
                }
                else
                {
                    isTrue = false;
                }
               
            }
            if (isTrue==false)
            {
                Console.WriteLine("-1");
            }

            //2
            Array.Sort(twoSizes);
            int result2 = 0;
            for (int i = 0; i < twoSizes.Length; i++)
            {
                if (i%friend==0)
                {
                    result2 += twoSizes[i];
                }
            }
            Console.WriteLine(result2);
        }
    }
}
