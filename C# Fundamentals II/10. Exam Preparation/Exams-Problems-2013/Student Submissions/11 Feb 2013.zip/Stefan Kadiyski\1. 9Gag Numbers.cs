using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, decimal> dic = new Dictionary<string, decimal>();

            dic.Add("-!", 0);
            dic.Add("**", 1);
            dic.Add("!!!", 2);
            dic.Add("&&", 3);
            dic.Add("&-", 4);
            dic.Add("!-", 5);
            dic.Add("*!!!", 6);
            dic.Add("&*!", 7);
            dic.Add("!!**!-", 8);

            string numberStr = Console.ReadLine();
            string str = "";
            decimal number = 0;

            for (int i = 0; i < numberStr.Length; i++)
            {
                str += numberStr[i];
                if (dic.ContainsKey(str))
                {
                    decimal value = dic[str];
                    
                    if (i < numberStr.Length - 1 )
                    {
                        number = (number + value) * 9;
                    }
                    if (i == numberStr.Length - 1)
                    {
                        number += value;
                    }
                    str = "";
                }
            }
            Console.Write(number);
        }
    }
}