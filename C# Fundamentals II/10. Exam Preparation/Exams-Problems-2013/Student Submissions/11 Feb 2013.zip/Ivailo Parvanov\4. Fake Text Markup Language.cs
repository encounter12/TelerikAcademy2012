using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        int length = int.Parse(Console.ReadLine());

        for (int k = 0; k < length; k++)
        {
            string input = Console.ReadLine();
            bool inBracets = false;
            StringBuilder buffer = new StringBuilder();


            for (int i = 0; i < input.Length; i++)
            {

                if (input[i] == '<')
                {
                    inBracets = true;
                }
                if (!inBracets)
                {
                    buffer.Append(input[i]);
                }
                else
                {
                    string shit = input.Substring(i);
                    int x = shit.Length;
                    string shit2 = Pass(shit);
                    buffer.Append(shit2);
                    i += (x - shit2.Length);
                    input = input.Substring(x);
                }
            }

            string shitt = buffer.ToString();
            Console.WriteLine(shitt);
        }

        



    }

    private static string Pass(string input)
    {
        int startPossition = input.IndexOf("</");
        int endPossition = input.IndexOf(">", startPossition);
        string tag = input.Substring(startPossition, endPossition - startPossition + 1);

        if (tag == "</upper>")
        {
            int shit = input.IndexOf("<upper>");
            string text = input.Substring(shit + 7, startPossition - 7);
            text = text.ToUpper();
            return text;
        }

        if (tag == "</lower>")
        {
            int shit = input.IndexOf("<lower>");
            string text = input.Substring(shit + 7, startPossition - 7);
            text = text.ToLower();
            return text;
        }

        if (tag == "</del>")
        {
            int shit = input.IndexOf("<del>");
            string text = input.Substring(shit + 5, startPossition - 5);
            text = text.Remove(0);
            return text;
        }

        if (tag == "</rev>")
        {
            int shit = input.IndexOf("<rev>");
            string text = input.Substring(shit + 5, startPossition - 5);

            char[] arr = text.ToCharArray();
            Array.Reverse(arr);
            text = new string(arr);
            return text;
        }

        else
        {
            string asd = "";
            return asd;
        }
    }
}
