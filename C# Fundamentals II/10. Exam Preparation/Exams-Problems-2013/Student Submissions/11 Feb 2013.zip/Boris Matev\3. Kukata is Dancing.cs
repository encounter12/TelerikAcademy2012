using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.KukataDancing
{
    class Program
    {
        static char[,] floor = new char[3, 3];
        static State state = State.Left;
        static int curRow = 1;
        static int curCol = 1;
        static void Main(string[] args)
        {
            InitFloor();
            Dance();
        }
        static void Dance()
        {
            int moves = int.Parse(Console.ReadLine());
            for (int i = 0; i < moves; i++)
            {
                string line = Console.ReadLine();
                for (int k = 0; k < line.Length; k++)
                {
                    if (line[k] == 'L' || line[k] == 'R')
                    {
                        ChangeDirection(line[k]);
                    }
                    else
                    {
                        Walk();
                    }
                }
                char position = floor[curRow, curCol];
                switch (position)
                {
                    case 'R':
                        Console.WriteLine("RED"); break;
                    case 'B':
                        Console.WriteLine("BLUE"); break;
                    case 'G':
                        Console.WriteLine("GREEN"); break;
                    default:
                        break;
                }
            }
        }
        static void Walk()
        {
            if (state == State.Left)
            {
                curCol++;
                if (curCol > 2)
                {
                    curCol = 0;
                }
            }
            else if (state == State.Right)
            {
                curCol--;
                if (curCol < 0)
                {
                    curCol = 2;
                }
            }
            else if (state == State.Up)
            {
                curRow++;
                if (curRow > 2)
                {
                    curCol = 0;
                }
            }
            else if (state == State.Down)
            {
                curRow--;
                if (curRow < 0)
                {
                    curRow = 2;
                }
            }
        }
        static void ChangeDirection(char dir)
        {
            if (state == State.Left && dir == 'L')
            {
                state = State.Down; 
            }
            else if (state == State.Left && dir == 'R')
            {
                state = State.Up;
            }
            else if (state == State.Right && dir == 'L')
            {
                state = State.Up;
            }
            else if (state == State.Right && dir == 'R')
            {
                state = State.Down;
            }
            else if (state == State.Up  && dir == 'L')
            {
                state = State.Left;
            }
            else if (state == State.Up && dir == 'R')
            {
                state = State.Right;
            }
            else if (state == State.Down && dir == 'L')
            {
                state = State.Right;
            }
            else if (state == State.Down && dir == 'R')
            {
                state = State.Left;
            }
        }
        static void InitFloor()
        {
            floor[0, 0] = 'R';
            floor[0, 1] = 'B';
            floor[0, 2] = 'R';
            floor[1, 0] = 'B';
            floor[1, 1] = 'G';
            floor[1, 2] = 'B';
            floor[2, 0] = 'R';
            floor[2, 1] = 'B';
            floor[2, 2] = 'R';
        }
        enum State
        { 
            Left,
            Right,
            Up,
            Down
        }
    }
}
