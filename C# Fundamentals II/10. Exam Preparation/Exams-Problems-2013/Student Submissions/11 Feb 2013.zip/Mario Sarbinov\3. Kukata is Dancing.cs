using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class KukataIsDancing
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        string[] moves = new string[n];
        for (int i = 0; i < n; i++)
        {
            moves[i] = Console.ReadLine();
        }
        string current = "GREEN";
        //int a = 1, b = 1, c = 0, d = 1, count = 0;
        int[,] array = new int[3, 3];
        for (int j = 0; j < n; j++)
        {
            for (int i = 0; i < moves[i].Length; i++)
            {
                moves[i].IndexOf('W');
                current = "BLUE";
            }
            Console.WriteLine(current);
        }

    }
}
