using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9Gag
{
    class Program
    {
        static void Main(string[] args)
        {
            String number;
            long sum=0;
            number = Console.ReadLine();
            byte grade = 0;
            do
            {
                int digit = GetDigit(number);
                number = RemoveLastTakenDigit(digit, number);
                long multiplier = (long)Math.Pow(9, grade);
                sum += digit * multiplier;
                grade++;
            } while (number.Length!=0);
            Console.WriteLine(sum);
        }

        public static String RemoveLastTakenDigit(int digit, String number)
        {
            if (digit==0 || digit==1 || digit==3 || digit==4 || digit==5)
            {
               String temp = number.Remove(number.Length - 2);
               return temp;
            }
            if (digit==2 || digit==7)
            {
                String temp = number.Remove(number.Length - 3);
                return temp;
            }
            if (digit==6)
            {
                String temp = number.Remove(number.Length - 4);
                return temp;
            }
            String val = number.Remove(number.Length - 6);
            return val;
        }

        public static int GetDigit(String number)
        {
            if (number.EndsWith(NumberConstants.NULL))
                return 0;
            else if (number.EndsWith(NumberConstants.ONE))
                return 1;
            else if (number.EndsWith(NumberConstants.SIX))
                return 6;
            else if (number.EndsWith(NumberConstants.THREE))
                return 3;
            else if (number.EndsWith(NumberConstants.FOUR))
                return 4;
            else if (number.EndsWith(NumberConstants.EIGHT))
                return 8;
            else if (number.EndsWith(NumberConstants.TWO))
                return 2;
            else if (number.EndsWith(NumberConstants.SEVEN))
                return 7;
            else 
                return 5;
        }
        class NumberConstants
        {
            public static readonly String NULL="-!";
            public static readonly String ONE = "**";
            public static readonly String TWO = "!!!";
            public static readonly String THREE = "&&";
            public static readonly String FOUR = "&-";
            public static readonly String FIVE = "!-";
            public static readonly String SIX = "*!!!";
            public static readonly String SEVEN = "&*!";
            public static readonly String EIGHT = "!!**!-";
        }
    }
}