using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
  
namespace Exam1
{
    class GagNumbers
    {
        static string[] digits = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
        static void Main(string[] args)
        {
            string str = Console.ReadLine();
            for (int i = 0; i < digits.Length; i++)
            {
                if (digits[i] == str)
                {
                    Console.Write(i);
                }
            }
             
        }     
    }
}