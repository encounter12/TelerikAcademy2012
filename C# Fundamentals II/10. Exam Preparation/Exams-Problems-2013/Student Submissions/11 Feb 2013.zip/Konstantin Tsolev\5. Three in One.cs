using System;
using System.Collections.Generic;
namespace ThreeIn1
{
    class ThreeIn1
    {
        static List<int> player = new List<int>();
        static List<int> cakes = new List<int>();
        public static void TaskOne(string[] input)
        {
            int playerWithMaxScore = 1;
            int[] playerScores = new int[input.Length];
            for (int i = 0; i < playerScores.Length; i++)
            {
                playerScores[i] = int.Parse(input[i]);
                player.Add(playerScores[i]);
            }
            int maxScore = playerScores[0];
            for (int j = 0; j < player.Count; j++)
            {
                if (player[j] > 21)
                {
                    player.Remove(player[j]);
                }
                else
                {
                    if (player[j] >= maxScore)
                    {
                        maxScore = player[j];
                    }
                }
            }
            player.Sort();
            for (int l = 0; l < player.Count - 1; l++)
            {
                if (player[l] >= maxScore)
                {
                    playerWithMaxScore++;
                }
            }
            if (playerWithMaxScore == 1)
            {
                Console.WriteLine(0);
            }
            else
            {
                Console.WriteLine(-1);
            }
        }
        public static int GetMax()
        {
            int max = int.MinValue;
            for (int j = 0; j < cakes.Count; j++)
            {
                if (cakes[j] >= max)
                {
                    max = cakes[j];
                }
            }
            return max;
        }
        public static void TaskTwo(string[] input, int palls)
        {
            int[] friends = new int[palls];
            for (int i = 0; i < input.Length; i++)
            {
                cakes.Add(int.Parse(input[i]));
            }
            for (int k = 0; k < cakes.Count; k++)
            {
                for (int l = 0; l < friends.Length; l++)
                {
                    friends[l] += GetMax();
                    cakes.Remove(GetMax());
                }
            }
            Console.WriteLine(friends[0]);
        }
        static public long GetMin(long a,long b,long c)
        {
            long[] digits=new long[3];
            digits[0]=a;
            digits[1]=b;
            digits[2]=c;
            long min=digits[0];
            for(int k=0;k<digits.Length;k++)
            {
                if(digits[k] < min && digits[k] != 0)
                {
                    min=digits[k];
                }
            }
            return min;
        }
        public static void TaskThree(string[] input) 
        {
            long heroGoldCoins = long.Parse(input[0]);
            long heroSilverCoins = long.Parse(input[1]);
            long heroBronzeCoins = long.Parse(input[2]);
            long beerGoldCoins = long.Parse(input[3]);
            long beerSilverCoins = long.Parse(input[4]);
            long beerBronzeCoins = long.Parse(input[5]);
            long minExchanges = 0;
            long heroTotalCoins=0, beerTotalCoins = 0;
            bool beerIsInGoldCoins = false, beerIsInSilverCoins = false, beerIsInBronzeCoins = false;
            heroTotalCoins = GetMin(heroGoldCoins, heroSilverCoins, heroBronzeCoins);
            beerTotalCoins = GetMin(beerGoldCoins, beerSilverCoins, beerBronzeCoins);
            if (beerTotalCoins == beerGoldCoins) beerIsInGoldCoins = true;
            if (beerTotalCoins == beerSilverCoins) beerIsInSilverCoins = true;
            if (beerTotalCoins == beerBronzeCoins) beerIsInBronzeCoins = true;
            if (beerIsInGoldCoins) 
            {
                minExchanges = 1;
                
                while (heroGoldCoins > 0) 
                {
                    minExchanges++;
                }
            }

            if(heroTotalCoins>=beerTotalCoins){
            Console.WriteLine(minExchanges);
            }else
            {
                Console.WriteLine(-1);
            }
        }
        static void Main(string[] args)
        {
             string[] inputForFirstTask = Console.ReadLine().Split(',');
             string[] inputForSecondTask = Console.ReadLine().Split(',');
             int palls = int.Parse(Console.ReadLine());
             string[] inputForTaskThree = Console.ReadLine().Split(',');
             TaskOne(inputForFirstTask);
             TaskTwo(inputForSecondTask, palls);
             TaskThree(inputForTaskThree);

        }
    }
}
