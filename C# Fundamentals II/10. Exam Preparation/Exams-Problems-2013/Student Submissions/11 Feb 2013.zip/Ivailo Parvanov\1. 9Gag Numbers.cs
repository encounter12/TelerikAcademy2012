using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class GagNumbes
{
    static void Main()
    {
        string inputString = "";
        string number = "";

        string input = Console.ReadLine();


        for (int i = 0; i < input.Length; i++)
        {
           inputString += input[i];

           if (inputString == "-!")
           {
               number += "0";
               inputString = inputString.Remove(0, 2);
           }

           if (inputString == "**")
           {
               number += "1";
               inputString = inputString.Remove(0, 2);
           }

           if (inputString == "!!!")
           {
               number += "2";
               inputString = inputString.Remove(0, 3);
           }

           if (inputString == "&&")
           {
               number += "3";
               inputString = inputString.Remove(0, 2);
           }

           if (inputString == "&-")
           {
               number += "4";
               inputString = inputString.Remove(0, 2);
           }

           if (inputString == "!-")
           {
               number += "5";
               inputString = inputString.Remove(0, 2);
           }

           if (inputString == "*!!!")
           {
               number += "6";
               inputString = inputString.Remove(0, 4);
           }

           if (inputString == "&*!")
           {
               number += "7";
               inputString = inputString.Remove(0, 3);
           }

           if (inputString == "!!**!-")
           {
               number += "8";
               inputString = inputString.Remove(0, 6);
           }
        }
      
        ulong lastNum = 0;

        for (int i = 0; i < number.Length; i++)
        {

            char c = number[i];
            string s1 = new String(c, 1);
            string s2 = new String(new char[] { c });
            string s3 = c.ToString();


            ulong newNum = ulong.Parse(s3);
            ulong po = 1;

            for (int k = i + 1; k < number.Length; k++)
            {
                po *= 9;
            }

            newNum *= po;
            lastNum += newNum;
            po = 1;
        }

        Console.WriteLine(lastNum);
    }
}