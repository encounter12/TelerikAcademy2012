using System;

class gagnumbers
{
    static void Main()
    {
        string number = Console.ReadLine();
        for(int i = 0 ; i < Int32.MaxValue ; i ++)
        {
            Console.WriteLine(i);
        }
    }
}