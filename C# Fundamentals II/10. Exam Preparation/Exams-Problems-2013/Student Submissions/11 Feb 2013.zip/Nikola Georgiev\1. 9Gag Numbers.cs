using System;


class GagNumbers
{
    static void Main()
    {


        int array = int.Parse(Console.ReadLine());

        switch (array)
        {
            case 0: Console.WriteLine("-!"); break;
            case 1: Console.WriteLine("**"); break;
            case 2: Console.WriteLine("!!!"); break;
            case 3: Console.WriteLine("&&"); break;
            case 4: Console.WriteLine("&-"); break;
            case 5: Console.WriteLine("!-"); break;
            case 6: Console.WriteLine("*!!!"); break;
            case 7: Console.WriteLine("&*!"); break;
            case 8: Console.WriteLine("!!**!-"); break;
            default: Console.WriteLine("Try again"); break;
        }
    }
}

