using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GagNumbers
{
    class Program
    {
        static void Main()
        {
            string gag = Console.ReadLine();
            if (gag == "-!")
            {
                Console.WriteLine(0);
            }
            else if (gag == "**")
            {
                Console.WriteLine(1);
            }
            else if (gag == "!!!")
            {
                Console.WriteLine(2);
            }
            else if (gag == "&&")
            {
                Console.WriteLine(3);
            }
            else if (gag == "&-")
            {
                Console.WriteLine(4);
            }
            else if (gag == "!-")
            {
                Console.WriteLine(5);
            }
            else if (gag == "*!!!")
            {
                Console.WriteLine(6);
            }
            else if (gag == "&*!")
            {
                Console.WriteLine(7);
            }
            else if (gag == "!!**!-")
            {
                Console.WriteLine(8);
            }
        }
    }
}
