using System;

class task1
{
    static void Main()
    {
        
        string input = Console.ReadLine();
        if (input.Length > 20)
        {
            return;
        }
        else
        {
            string check = "";
            int multiplier = 1;
            int result = 0;
            char[] chArr = input.ToCharArray();
            string[] resArr = new string[10];
            Array.Reverse(chArr);
            int j = 0;

            for (int i = 0; i < chArr.Length; i++)
            {
                check += chArr[chArr.Length - i - 1];
                
                switch (check)
                { 
                    case "-!":
                        resArr[j] = "0";
                        j++;
                        check = "";
                        break;
                    case "**":
                        resArr[j] = "1";
                        j++;
                        check = "";
                        break;
                    case "!!!":
                        resArr[j] = "2";
                        j++;
                        check = "";
                        break;
                    case "&&":
                        resArr[j] = "3";
                        j++;
                        check = "";
                        break;
                    case "&-":
                        resArr[j] = "4";
                        j++;
                        check = "";
                        break;
                    case "!-":
                        resArr[j] = "5";
                        j++;
                        check = "";
                        break;
                    case "*!!!":
                        resArr[j] = "6";
                        j++;
                        check = "";
                        break;
                    case "&*!":
                        resArr[j] = "7";
                        j++;
                        check = "";
                        break;
                    case "!!**!-":
                        resArr[j] = "8";
                        j++;
                        check = "";
                        break;
                    default:
                        continue;
                }
            }
            for (int i = 0; i < resArr.Length; i++)
            {
                if (resArr[resArr.Length - i - 1] == null)
                {
                    continue;
                }
                result += int.Parse(resArr[resArr.Length - i - 1]) * multiplier;
                multiplier *= 9;
            }
            Console.WriteLine(result);
        }
    }
}