using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class One
{
    static void Main()
    {
        string inputString = Console.ReadLine();
        StringBuilder input = new StringBuilder();

        for (int i = 0; i < inputString.Length; i++)
        {
            input.Append(inputString[i]);
        }



        string[] numbers = new string[] 
        {
            "!!**!-",     // 8
            "*!!!",       // 6
            "!!!",        // 2
            "&*!",        // 7
            "!-",         // 5
            "&-",         // 4
            "&&",         // 3
            "**",         // 1
            "-!",         // 0
        };

        byte[] numValues = new byte[] { 8, 6, 2, 7, 5, 4, 3, 1, 0 };


        var currentElement = new StringBuilder();
        int currentCount = 0;
        string currentEl = "";
        BigInteger result = 0, multiplier = 9;

        while (input.Length > 0)
        {
            for (int i = 0; i < numbers.Length; i++)
            {
                //Clear the previous element
                currentEl = "";


                if (numbers[i].Length > input.Length)
                {
                    continue;
                }
                else
                {
                    //Get appropriate lenght of string
                    currentEl = input.ToString().Substring(input.Length - numbers[i].Length, numbers[i].Length);

                    //check if equal to the current element
                    if (currentEl == numbers[i].ToString())
                    {
                        //if equal - remove the lenght of the element from the input
                        input.Remove(input.Length - numbers[i].Length, numbers[i].Length);
                        //calculate position * 9
                        if (currentCount == 0)
                        {
                            result += numValues[i];
                        }
                        else
                        {
                            //result += numValues[i] * multiplier;
                            //multiplier *= 9;
                            result += GetResMultipliedByNine(currentCount, numValues[i]);
                        }
                        //increase the *9 count
                        currentCount++;
                        //break
                        break;
                    }
                    else
                    {
                        continue;
                    }


                }
            }
        }
        Console.WriteLine(result);
    }

    private static BigInteger GetResMultipliedByNine(int currentCount, byte p)
    {
        BigInteger res = 1;

        for (int i = 1; i <= currentCount; i++)
        {
            res *= 9;
        }
        return res * p;
    }


}