using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Three_in_One
{
    class Program
    {
        static void Main(string[] args)
        {   //Blackjack
           string p = Console.ReadLine();
          
            string p2 = Console.ReadLine();
            int f2 = int.Parse(Console.ReadLine());
            
            string p3 = Console.ReadLine();
            Blackjack(p);
            Bites(p2, f2);
            Beer(p3);
           

        }
        static void Blackjack(string s)
        {

            string[] values = s.Split(',');
            int[] blackjack = new int[values.Length];
            int index1 = 0, index2 = 0;
            int max = 0;
            bool fail = false;
            bool found21 = false;
            bool check = false;
            for (int i = 0; i < values.Length; i++)
            {
                blackjack[i] = int.Parse(values[i]);
            }
            for (int z = 0; z < values.Length; z++)
            {
                if (blackjack[z] > max && blackjack[z] <= 20)
                {
                    max = blackjack[z];
                    index1 = z;
                    check = true;
                    fail = false;

                }
                if (blackjack[z] == 21 && found21 == true)
                {
                    fail = true;
                    break;
                }
                if (blackjack[z] == 21 && found21 == false)
                {
                    index2 = z;
                    found21 = true;
                    fail = false;
                }
                if (blackjack[z] == max && check == false)
                {
                    fail = true;
                }

                check = false;

            }
            if (fail == true)
            {
                Console.WriteLine("-1");
            }
            else if (found21 == true)
            {
                Console.WriteLine(index2);
            }
            else
                Console.WriteLine(index1);
            }
        static void Bites(string p2,int f1)
        {
            
            int F = f1;
            string[] values = p2.Split(',');
            int temp = 0;
            int bites = 0;
            int tempbites = 0;
            int spin = 0;
            int dal = values.Length;
            List<int> cakes = new List<int>();
            for (int i = 0; i < values.Length; i++)
            {
                temp = int.Parse(values[i]);
                cakes.Add(temp);
            }
            while (cakes.Count != 0)
            {
                if (spin == 0)
                {
                    tempbites = cakes.Max();
                    bites += tempbites;
                    for (int i = cakes.Count - 1; i >= 0; i--)
                    {
                        if (cakes[i] == tempbites)
                            cakes.RemoveAt(i);
                    }
                    spin = F;

                }
                else
                    tempbites = cakes.Max();
                for (int z = cakes.Count - 1; z >= 0; z--)
                {
                    if (cakes[z] == tempbites)
                        cakes.RemoveAt(z);
                }
                spin--;

            }
            Console.WriteLine(bites);
        }
        static void Beer(string z)
        {
            
            string[] values = z.Split(' ');
           
            int rr=10;
            int op = 10;
            int[] money = new int[5];
            for (int i = 0; i < 5; i++)
            {
                if (i >= 3)
                {
                    money[i] = int.Parse(values[i]);
                }
                else
                    money[i] = int.Parse(values[i]);
            }
    /*        while (rr>0)
            {
              
                if (money[0] > money[3])
                {
                    money[0]--;
                    money[4] += 9;
                    op++;
                    rr--;
                }
                if (money[1] > money[4])
                {
                    money[1]--;
                    money[5] += 9;
                    op++;
                    rr--;
                }
                if ((money[1]-11) > money[0])
                {
                    money[0]++;
                    money[1] -= 11;
                    op++;
                    rr--;
                }
                if ((money[1]-11) > money[2])
                {
                    money[2]++;
                    money[3] -=11;
                    op++;
                    rr--;
                }
                if ((money[2] - 11) > money[1])
                {
                    money[1]++;
                    money[2] -= 11;
                    op++;
                    rr--;
                }
                rr--;
     
        */

            Console.WriteLine(op);
        
        }
    }
}
