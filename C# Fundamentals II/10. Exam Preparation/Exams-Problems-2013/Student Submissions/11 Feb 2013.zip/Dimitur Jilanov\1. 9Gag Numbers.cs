using System;

    class gag9
    {
        static void Main()
        {
            string N = Console.ReadLine();
            string zero="-!";
            string one="**";
            string two="!!!";
            string three="&&";
            string four="&-";
            string five="!-";
            string six="*!!!";
            string seven="&*!";
            string eight="!!**!-";
            string star = "*";
            string point="!";
            int sizer = 0;
            int finale9 = 1;
            int result = 0;


            for (int counter = 0; counter+sizer < N.Length; counter++)
            {
                if ((sizer + eight.Length) <= N.Length)
                    if ((N.Substring(sizer, 6) == eight))
                    {
                        
                            sizer += eight.Length;
                            finale9 *= 9;
                        
                    }
                if ((sizer + seven.Length) <= N.Length)
                    if ((N.Substring(sizer, 3) == seven))
                    {

                        sizer += seven.Length;
                        finale9 *= 9;
                    }
                if ((sizer + six.Length) <= N.Length)
                    if ((N.Substring(sizer, 4) == six))
                    {

                        sizer += six.Length;
                        finale9 *= 9;
                    }
                if ((sizer + two.Length) <= N.Length)
                    if ((N.Substring(sizer, 3) == two))
                    {
                        
                            sizer += two.Length;
                            finale9 *= 9;
                        
                    }
                if ((sizer + zero.Length) <= N.Length)
                    if ((N.Substring(sizer, 2) == zero))
                    {

                        sizer += zero.Length;
                        finale9 *= 9;

                    }
                if ((sizer + one.Length) <= N.Length)
                    if ((N.Substring(sizer, 2) == one))
                    {

                        sizer += one.Length;
                        finale9 *= 9;

                    }

                if ((sizer + three.Length) <= N.Length)
                    if ((N.Substring(sizer, 2) == three))
                    {

                        sizer += three.Length;
                        finale9 *= 9;
                    }
                if ((sizer + four.Length) <= N.Length)
                    if ((N.Substring(sizer, 2) == four))
                    {

                        sizer += four.Length;
                        finale9 *= 9;
                    }
                if ((sizer + five.Length) <= N.Length)
                    if ((N.Substring(sizer, 2) == five))
                    {

                        sizer += five.Length;
                        finale9 *= 9;
                    }



            }



            sizer = 0;
            for (int counter = 0; counter < N.Length; counter++)
            {
                if ((sizer + eight.Length) <= N.Length)
                    if ((N.Substring(sizer, 6) == eight))
                    {
                            finale9 /= 9;
                            sizer += eight.Length;
                            result = result + finale9 * 8;
                            
                    }
                if ((sizer + seven.Length) <= N.Length)
                    if ((N.Substring(sizer, 3) == seven))
                    {
                        finale9 /= 9;
                        sizer += seven.Length;
                        result = result + finale9 * 7;
                        
                    }
                if ((sizer + six.Length) <= N.Length)
                    if ((N.Substring(sizer, 4) == six))
                    {
                        finale9 /= 9;
                        sizer += six.Length;
                        result = result + finale9 * 6;
                        
                    }
                if ((sizer + two.Length) <= N.Length)
                    if ((N.Substring(sizer, 3) == two))
                    {
                            finale9 /= 9;
                            sizer += two.Length;
                            result = result + finale9 * 2;
                            
                    }
                if ((sizer + zero.Length) <= N.Length)
                    if ((N.Substring(sizer, 2) == zero))
                    {
                        finale9 /= 9;
                        sizer += zero.Length;

                    }
                if ((sizer + one.Length) <= N.Length)
                    if ((N.Substring(sizer, 2) == one))
                    {
                        finale9 /= 9;
                            sizer += one.Length;
                            result = result + finale9 * 1;
                            
                        
                    }
                
                if ((sizer + three.Length) <= N.Length)
                    if ((N.Substring(sizer, 2) == three))
                    {
                        finale9 /= 9;
                        sizer += three.Length;
                        result=result+finale9*3;
                        
                    }
                if ((sizer + four.Length) <= N.Length)
                    if ((N.Substring(sizer, 2) == four))
                    {
                        finale9 /= 9;
                        sizer += four.Length;
                        result=result+finale9*4;
                        
                    }
                if ((sizer + five.Length) <= N.Length)
                    if ((N.Substring(sizer, 2) == five))
                    {
                        finale9 /= 9;
                        sizer += five.Length;
                        result=result+finale9*5;
                        
                    }
                if ((sizer + zero.Length) <= N.Length)
                    if ((N.Substring(sizer, 2) == zero))
                    {

                        sizer += zero.Length;
                        finale9 /= 9;

                    }
                
                
                
            }
            Console.WriteLine(result);

        }
    }