using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        string ngag = Console.ReadLine();
        StringBuilder sb = new StringBuilder();
        StringBuilder sbn = new StringBuilder();
        ulong dgag = 0;
        int pos = 0;

        foreach (char letter in ngag)
        {
            sb.Append(letter);
            switch (sb.ToString())
            {
                case "-!": 
                    sbn.Append('0');
                    sb.Remove(0, sb.Length);
                    break;
                case "**":
                    sbn.Append('1');
                    sb.Remove(0, sb.Length);
                    break;
                case "!!!":
                    sbn.Append('2');
                    sb.Remove(0, sb.Length);
                    break;
                case "&&": 
                    sbn.Append('3');
                    sb.Remove(0, sb.Length);
                    break;
                case "&-": 
                    sbn.Append('4');
                    sb.Remove(0, sb.Length);
                    break;
                case "!-": 
                    sbn.Append('5');
                    sb.Remove(0, sb.Length);
                    break;
                case "*!!!":
                    sbn.Append('6');
                    sb.Remove(0, sb.Length);
                    break;
                case "&*!": 
                    sbn.Append('7');
                    sb.Remove(0, sb.Length);
                    break;
                case "!!**!-": 
                    sbn.Append('8');
                    sb.Remove(0, sb.Length);
                    break;
                default:
                    break;
            }
        }
        sb.Remove(0, sb.Length);
        foreach (char letter in sbn.ToString().Reverse())
        {
            dgag += (ulong)char.GetNumericValue(letter) * (ulong)Math.Pow(9, pos);
            pos += 1;
        }
        Console.WriteLine(dgag);
    }
}
