using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeInOne
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] cards = Console.ReadLine().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            string[] cakes = Console.ReadLine().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            int friends = int.Parse(Console.ReadLine());
            string[] coins = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            int bestIndex = 0;
            bool singleOne = true;
            int maxValue = int.MinValue;
            for (int i = 0; i < cards.Length; i++)
            {

                if (Convert.ToInt16(cards[i]) > maxValue && Convert.ToInt16(cards[i]) <= 21)
                {
                    maxValue = Convert.ToInt16(cards[i]);
                    bestIndex = i;
                    singleOne = true;
                }
                if (Convert.ToInt16(cards[i]) == maxValue)
                {
                    singleOne = false;
                }
            }
            if (maxValue == 0)
            {
                Console.WriteLine("-1");
            }
            else if (singleOne)
            {
                Console.WriteLine(bestIndex);
            }
            else
            {
                Console.WriteLine("-1");
            }
            int sumCakes = 0;
            Array.Sort(cakes);
            for (int i = 0, f = 0; i < cakes.Length; i++, f++)
            {
                if (f == 2)
                {
                    sumCakes += Convert.ToInt16(cakes[i]);
                    f = 0;
                }
            }
            Console.WriteLine(sumCakes);

            int G1 = Convert.ToInt16(coins[0]);
            int S1 = Convert.ToInt16(coins[1]);
            int B1 = Convert.ToInt16(coins[2]);
            int G2 = Convert.ToInt16(coins[3]);
            int S2 = Convert.ToInt16(coins[4]);
            int B2 = Convert.ToInt16(coins[5]);
            int counter = 1;
            int pocketB1 = 0;
            int pocketS1 = 0;            
            
            while (B1 != B2)
            {
                if (B1 > B2)
                {
                    B1 -= 1;
                    pocketB1 += 1;
                    if (pocketB1 == 11)
                    {
                        S1 += 1;
                        counter++;
                        pocketB1 = 0;
                    }
                }
                if (B1 < B2)
                {
                    if (pocketB1 == 0)
                    {
                        S1 -= 1;
                        counter++;
                        pocketB1 = 11;

                    }
                    B1 += 1;
                    pocketB1--;
                }
            }
            while (S1 != S2)
            {
                if (S1 > S2)
                {
                    S1 -= 1;
                    pocketS1 += 1;
                    if (pocketS1 == 9)
                    {
                        G1 +=1;
                        counter++;
                        pocketS1 = 0;
                    }
                }
                if (S1 < S2)
                {
                    
                    if (pocketS1 == 0)
                    {
                        G1 -= 1;
                        counter++;
                        pocketS1 = 9;
                    }
                    S1 += 1;
                    pocketS1--;

                    
                }
            }
     

            Console.WriteLine(counter);
           
        }
    }
}
