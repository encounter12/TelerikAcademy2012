using System;
using System.Collections.Generic;

class ThreeInOne
{

    static void Main()
    {
        Winners();
        Bites();
        Exchanges();
    }

    // Winners
    static void Winners()
    {
        string[] input = Console.ReadLine().Split(',');

        byte[] points = new byte[input.Length];
        byte max = 0;

        List<byte> winners = new List<byte>();

        for (byte i = 0; i < input.Length; i++)
        {
            points[i] = byte.Parse(input[i]);
            if (points[i] > 21)
            {
                continue;
            }
            if (points[i] > max)
            {
                max = points[i];
                winners.Clear();
            }
            if (points[i] >= max)
            {
                winners.Add(i);
            }
        }

        Console.WriteLine(winners.Count == 1 ? winners[0] : -1);
    }

    // Bites
    static void Bites()
    {
        string[] input = Console.ReadLine().Split(',');
        int[] bites = new int[input.Length];
        for (int i = 0; i < input.Length; i++)
        {
            bites[i] = int.Parse(input[i]);
        }

        int f = int.Parse(Console.ReadLine());

        Array.Sort(bites);

        int myBites = 0;

        for (int i = bites.Length - 1; i >= 0; i--)
        {
            myBites += bites[i];
            i -= f;
        }

        Console.WriteLine(myBites);
    }

    static int G1, S1, B1, G2, S2, B2;

    //
    static void Exchanges()
    {
        string[] input = Console.ReadLine().Split(' ');

        G1 = int.Parse(input[0]);
        S1 = int.Parse(input[1]);
        B1 = int.Parse(input[2]);
        G2 = int.Parse(input[3]);
        S2 = int.Parse(input[4]);
        B2 = int.Parse(input[5]);

        int n = 0;

        if (CanBuy())
        {
            Console.WriteLine(0);
            return;
        }

        bool gainedGold = false;
        bool gainedSilver = false;
        bool gainedBronze = false;

        while (!CanBuy())
        {
            // Ensure we have enought gold
            while (G1 < G2) // If we need more gold
            {
                // Try to gain gold
                gainedGold = true;
                while (S1 < 11)
                {
                    // Try to gain silver
                    gainedSilver = true;
                    if (B1 < 11)
                    {
                        Console.WriteLine(-1);
                        return;
                    }
                    S1 += 1;
                    B1 -= 11;
                    n++;
                }
                G1 += 1;
                S1 -= 11;
                n++;
            }

            // Ensure we have enought silver
            while (S1 < S2) // If we need more silver
            {
                if (!gainedGold && G1 > G2)
                {
                    // Exchange gold for silver
                    G1 -= 1;
                    S1 += 9;
                    n++;
                }
                else
                {
                    // Try to gain silver
                    gainedSilver = true;
                    if (B1 < 11)
                    {
                        Console.WriteLine(-1);
                        return;
                    }
                    S1 += 1;
                    B1 -= 11;
                    n++;
                }
            }

            // Ensure we have enought bronze
            while (B1 < B2) // If we need more bronze
            {
                if (!gainedSilver)
                {
                    if (S1 > S2)
                    {
                        B1 += 9;
                        S1 -= 1;
                        n++;
                        continue;
                    }
                    if (G1 > G2)
                    {
                        G1 -= 1;
                        S1 += 9;
                        n++;
                        continue;
                    }
                    Console.WriteLine(-1);
                    return;
                }
                else
                {
                    Console.WriteLine(-1);
                    return;
                }
            }
        }

        Console.WriteLine(n);
    }


    static bool CanBuy()
    {
        return (G1 >= G2 && S1 >= S2 && B1 >= B2);
    }


}
