using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Exam
{
    class Task1
    {
        static void Main()
        {
            string number = Console.ReadLine();
            //string number = "*!!!";
            
            BigInteger numberDecimal = 0;

            string zero = "-!";
            string one = "**";
            string two = "!!!";
            string three = "&&";
            string four = "&-";
            string five = "!-";
            string six = "*!!!";
            string seven = "&*!";
            string eight = "!!**!-";
            StringBuilder bufferSb = new StringBuilder();
            List<int> result = new List<int>();

            for (int i = 0; i < number.Length; i++)
            {
                bufferSb.Append(number[i]);
                //string temp = bufferSb.ToString();

                string buffer = bufferSb.ToString();
                
                if (buffer == zero)
                {
                    result.Add(0);
                    bufferSb.Clear();
                }
                if (buffer == one)
                {
                    result.Add(1);
                    bufferSb.Clear();
                }
                if (buffer == two)
                {
                    result.Add(2);
                    bufferSb.Clear();
                }
                if (buffer == three)
                {
                    result.Add(3);
                    bufferSb.Clear();
                }
                if (buffer == four)
                {
                    result.Add(4);
                    bufferSb.Clear();
                }
                if (buffer == five)
                {
                    result.Add(5);
                    bufferSb.Clear();
                }
                if (buffer == six)
                {
                    result.Add(6);
                    bufferSb.Clear();
                }
                if (buffer == seven)
                {
                    result.Add(7);
                    bufferSb.Clear();
                }
                if (buffer == eight)
                {
                    result.Add(8);
                    bufferSb.Clear();
                }
            }
            result.Reverse();
            for (int j = 0; j < result.Count; j++)
            {
                numberDecimal = numberDecimal + (result[j] * (int)Math.Pow(9, j));
            }
            Console.WriteLine(numberDecimal);
        }
        
    }
}