using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        int dances = int.Parse(Console.ReadLine());

        string[] moves = new string[dances];
        for (int i = 0; i < dances; i++)
        {
            moves[i] = Console.ReadLine();
        }
        int[,] matrix = 
        {
            {1,2,1},
            {2,0,2},
            {1,2,1},
        };

        int cordinator = 0;
        int rows = 1;
        int cols = 1;
        int possition = 0;
        for (int j = 0; j < dances; j++)
        {
            for (int i = 0; i < moves[j].Length; i++)
            {
                string current = "";
                current += moves[j];
                if (current[i] == 'L')
                {
                    if (possition == 3)
                    {
                        possition = 0;
                    }
                    else
                    {
                        possition++;
                    }
                }
                if (current[i] == 'R')
                {
                    if (possition == -3)
                    {
                        possition = 0;
                    }
                    else
                    {
                        possition--;
                    }
                }
                if (current[i] == 'W')
                {
                    if ((possition == 1) || (possition == -3))
                    {
                        if (cols == 0)
                        {
                            cols = 3;
                            cordinator = matrix[rows, cols - 1];
                            cols--;
                        }
                        else
                        {
                            cordinator = matrix[rows, cols - 1];
                            cols--;
                        }
                    }
                    if ((possition == 2) || (possition == -2))
                    {
                        if (rows == 2)
                        {
                            rows = 0;
                            cordinator = matrix[rows, cols];

                        }
                        else
                        {
                            cordinator = matrix[rows + 1, cols];
                            rows++;
                        }
                    }
                    if ((possition == 3) || (possition == -1))
                    {
                        if (cols == 2)
                        {
                            cols = 0;
                            cordinator = matrix[rows, cols];
                        }
                        else
                        {

                            cordinator = matrix[rows, cols + 1];
                            cols++;
                        }
                    }
                    if ((possition == 0) || (possition == 0))
                    {
                        if (rows == 0)
                        {
                            rows = 2;
                            cordinator = matrix[rows, cols];
                        }
                        else
                        {
                            cordinator = matrix[rows - 1, cols];
                            rows--;
                        }
                    }
                }
            }
            if (cordinator == 1)
            {
                Console.WriteLine("RED");
            }
            else if (cordinator == 2)
            {
                Console.WriteLine("BLUE");
            }
            else if (cordinator == 0)
            {
                Console.WriteLine("GREEN");
            }
            possition = 0;
            rows = 1;
            cols = 1;
        }
    }
}
