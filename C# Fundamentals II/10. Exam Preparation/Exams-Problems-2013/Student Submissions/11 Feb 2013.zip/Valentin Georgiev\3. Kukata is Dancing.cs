using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kuka
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number for N:");
            int N = int.Parse(Console.ReadLine());
            //We making a string from a char array, from a series of repeated letters, and from a char array range.
            @L();
            @R();
            @W();
        }
        static void @L()
        {
           
            
            // Create new string from char array.
            //
            char[] charArray = new char[6];
            charArray[0] = 'G';
            charArray[1] = 'R';
            charArray[2] = 'E';
            charArray[3] = 'E';
            charArray[4] = 'N';

            string exampleString = new string(charArray);
            Console.WriteLine(exampleString);
            Console.WriteLine(exampleString);
            //Console.WriteLine(exampleString == "GREEN");
        }
        static void @R()
        {
            //
            // Create new string of repeated characters.
            //
            char[] charArray = new char[3];
            charArray[0] = 'R';
            charArray[1] = 'E';
            charArray[2] = 'D';
            string exampleString = new string(charArray);
            Console.WriteLine(exampleString);
            //Console.WriteLine(exampleString == "RED");
        }
        static void @W()
    {
	//
	// Create new string from range of characters in array.
	//
	char[] charArray = new char[4];
	charArray[0] = 'B';
	charArray[1] = 'L';
	charArray[2] = 'U';
	charArray[3] = 'E';
	


	string exampleString = new string(charArray, 0, 4);
	Console.WriteLine(exampleString);
    Console.WriteLine(exampleString);
	//Console.WriteLine(exampleString == "BLUE");
    }
  }
}


