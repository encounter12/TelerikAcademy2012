using System;
using System.Text.RegularExpressions;

class Problem1
{
    static void Main()
    {
        string patterzero = "-!";
        string patternone = "**";
        string patterntwo = "!!!";
        string patternthree = "&&";
        string pattternfour = "&-";
        string patternfive = "!-";
        string patternsix = "*!!!";
        string patternseven = "&*!";
        string patterneight="!!**!-";
        string inputNumber = Console.ReadLine();
        if (inputNumber == patterzero)
        {
            Console.WriteLine(0);
        }
        else if (inputNumber == patternone)
        {
            Console.WriteLine(1);
        }
        else if (inputNumber == patterntwo)
        {
            Console.WriteLine(2);
        }
        else if (inputNumber == patternthree)
        {
            Console.WriteLine(3);
        }
        else if (inputNumber == pattternfour)
        {
            Console.WriteLine(4);
        }
        else if (inputNumber == patternfive)
        {
            Console.WriteLine(5);
        }
        else if (inputNumber == patternsix)
        {
            Console.WriteLine(6);
        }
        else if (inputNumber == patternseven)
        {
            Console.WriteLine(7);
        }
        else if (inputNumber == patterneight)
        {
            Console.WriteLine(8);
        }
        
    }
}
