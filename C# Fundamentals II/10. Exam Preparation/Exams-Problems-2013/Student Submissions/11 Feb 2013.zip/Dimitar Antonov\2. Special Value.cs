using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace P2.SpecialValue
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<string> stringRows = new List<string>(n);
            for (int i = 0; i < n; i++)
            {
                stringRows.Add(Console.ReadLine());
            }
            int[][] jagged=new int[n][];
            for (int i = 0; i < n; i++)
            {
                string[] numbers = stringRows[i].Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                jagged[i] = new int[numbers.Length];
                for (int j = 0; j < numbers.Length; j++)
                {
                    jagged[i][j]=int.Parse(numbers[j]);
                }
            }
            int maxResult=0;
            int cellNumber;
            for (int i = 0; i < jagged[0].Length; i++)
            {
                int row = 0;
                int pathCounter = 0;
                int tempMaxResult=0;
                int lastPosition = 0;
                cellNumber = i;
                do
                {
                    pathCounter++;
                    if (jagged[row][cellNumber] < 0)
                    {
                        tempMaxResult = pathCounter + (-1) * jagged[row][cellNumber];
                        break;
                    }
                    else
                    {
                        cellNumber = jagged[row][cellNumber];
                        if (row + 1 > n - 1) row = 0;
                        else row++;
                    }
                    if (pathCounter % n == 1)
                    {
                        if (cellNumber == lastPosition) break;
                        else lastPosition = cellNumber;
                    }
                } while (true);
                if (tempMaxResult > maxResult) maxResult = tempMaxResult;
            }
            Console.WriteLine(maxResult);
        }

    }
}
