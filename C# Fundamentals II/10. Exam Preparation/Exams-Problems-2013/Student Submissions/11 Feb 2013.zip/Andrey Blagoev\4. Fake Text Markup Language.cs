using System;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Text;

class ex04
{
    static string Reverse(string input)
    {
        StringBuilder reversed = new StringBuilder();
        for (int i = input.Length - 1; i >= 0; i--)
        {
            reversed.Append(input[i]);


        }
        return reversed.ToString();
    }

    static string Toggle(string str)
    {
        StringBuilder tog = new StringBuilder();
        for (int i = 0; i < str.Length; i++)
        {
            if (char.IsLower(str[i]) == true)
                tog.Append(char.ToUpper(str[i]));
            else
                tog.Append(char.ToLower(str[i]));
        }
        return tog.ToString();
    }

    static void Main(string[] args)
    {
        //string str = "So<rev><upper>saw</upper> txet em</rev>";
        //string str = "<toggle><rev>ERa</rev></toggle> you";
        int n = int.Parse(Console.ReadLine());
        string[] result = new string[n];
        for (int j = 0; j < n; j++)
        {
            string str = Console.ReadLine();
            int startIndex = 0;
            int tags = (str.Split('/').Length - 1);


            for (int i = 0; i < tags; i++)
            {
                startIndex = str.IndexOf("/");
                if (str.Substring(startIndex + 1, 1) == "u")
                {
                    int end = str.IndexOf("</upper>");
                    int start = str.LastIndexOf("<upper>", end);

                    string beggin = str.Substring(0, start);
                    string endd = str.Substring(end + 8);
                    string convert = str.Substring(start, end - start + 8);
                    convert = Regex.Replace(convert, "<upper>(.*?)</upper>", m => m.Groups[1].Value.ToUpper());
                    str = beggin + convert + endd;
                }
                else if (str.Substring(startIndex + 1, 1) == "l")
                {
                    int end = str.IndexOf("</lower>");
                    int start = str.LastIndexOf("<lower>", end);

                    string beggin = str.Substring(0, start);
                    string endd = str.Substring(end + 8);
                    string convert = str.Substring(start, end - start + 8);
                    convert = Regex.Replace(convert, "<lower>(.*?)</lower>", m => m.Groups[1].Value.ToLower());
                    str = beggin + convert + endd;
                }
                else if (str.Substring(startIndex + 1, 1) == "r")
                {
                    int end = str.IndexOf("</rev>");
                    int start = str.LastIndexOf("<rev>", end);

                    string beggin = str.Substring(0, start);
                    string endd = str.Substring(end + 6);
                    string convert = str.Substring(start + 5, end - start - 5);
                    str = beggin + Reverse(convert) + endd;
                }
                else if (str.Substring(startIndex + 1, 1) == "d")
                {
                    int end = str.IndexOf("</del>");
                    int start = str.LastIndexOf("<del>", end);

                    string beggin = str.Substring(0, start);
                    string endd = str.Substring(end + 6);
                    str = beggin + endd;
                }
                else if (str.Substring(startIndex + 1, 1) == "t")
                {
                    int end = str.IndexOf("</toggle>");
                    int start = str.LastIndexOf("<toggle>", end);

                    string beggin = str.Substring(0, start);
                    string endd = str.Substring(end + 9);
                    string convert = str.Substring(start + 8, end - start - 8);
                    str = beggin + Toggle(convert) + endd;
                }
            }
            result[j] = str;
        }

        foreach (var item in result)
        {
            Console.WriteLine(item);
        }



    }
}



