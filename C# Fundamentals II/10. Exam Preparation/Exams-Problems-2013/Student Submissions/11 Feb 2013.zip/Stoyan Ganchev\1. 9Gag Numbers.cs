using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        Console.Write("Enter 9fag number: ");
        string s = Console.ReadLine();
        s = s.Replace("!!**!--!!-", "653");
        s = s.Replace("!!!**!-", "176");
        s = s.Replace("***!!!", "15");
        s = s.Replace("*!!!", "6");
        s = s.Replace("-!", "0");
        s = s.Replace("**", "1");
        s = s.Replace("!!!", "2");
        s = s.Replace("&&", "3");
        s = s.Replace("&-", "4");
        s = s.Replace("!-", "5");
        s = s.Replace("*!!!", "6");
        s = s.Replace("&*!", "7");
        s = s.Replace("!!**!-", "8");
        Console.WriteLine(s);
    }
}

