using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Task_1._1
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine();
            StringBuilder sb = new StringBuilder();
            int n;
            for (int i = 0; i < str.Length-1; i++)
            {
 
                if (str.IndexOf("-!") != -1)
                {
                    n = 0;
                    sb.Append(n.ToString());
                }
                else if (str.IndexOf("**") != -1)
                {
                    n = 1;
                    sb.Append(n.ToString());
                }
                else if (str.IndexOf("!!!") != -1)
                {
                    n = 2;
                    sb.Append(n.ToString());
                }
 
                else if (str.IndexOf("&&") != -1)
                {
                    n = 3;
                    sb.Append(n.ToString());
                }
                else if (str.IndexOf("&-") != -1)
                {
                    n = 4;
                    sb.Append(n.ToString());
                }
                else if (str.IndexOf("!-") != -1)
                {
                    n = 5;
                    sb.Append(n.ToString());
                }
                else if (str.IndexOf("*!!!") != -1)
                {
                    n = 6;
                    sb.Append(n.ToString());
                }
                else if (str.IndexOf("&*!") != -1)
                {
                    n = 7;
                    sb.Append(n.ToString());
                }
                else if (str.IndexOf("!!**!-") != -1)
                {
                    n = 8;
                    sb.Append(n.ToString());
                }
                else
                {
                    Console.WriteLine("404");
                }
                // Here end the for loop
            }
            Console.WriteLine(sb);
        }
    }
}