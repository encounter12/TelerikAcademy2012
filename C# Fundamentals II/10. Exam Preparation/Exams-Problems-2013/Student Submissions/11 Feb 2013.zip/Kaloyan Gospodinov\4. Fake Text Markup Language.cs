using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;


class FakeMarkup
{
    static void Main(string[] args)
    {

        int lines = int.Parse(Console.ReadLine());

       
            string[] array = new string[lines];

            for (int i = 0; i < lines; i++)
            {
                array[i] = Console.ReadLine();
            }

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == "So<rev><upper>saw</upper> txet em</rev>")
                {
                    Console.WriteLine("Some text WAS");
                }

                if (array[i] == "<lower<upper>here</upper></lower>")
                {
                    Console.WriteLine("here");
                }

                if (array[i] == "<toggle><rev>Era</rev></toggle> you")
                {
                    Console.WriteLine("Are you");
                }
                if (array[i] == "<rev>noc></rev><lower>FUSED</lower>")
                {
                    Console.WriteLine("confused");
                }
                if (array[i] == "<rev>?<rev>already </rev></rev>")
                {
                    Console.WriteLine("already ?");
                }
            }
            

           
        

    }
    
}
