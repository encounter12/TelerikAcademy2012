using System;
using System.Text;

class FTML
{
    static void Main()
    {
        StringBuilder input = new StringBuilder();
        int linesCount = int.Parse(Console.ReadLine());
        for (int i = 0; i < linesCount; i++)
        {
            input.Append(Console.ReadLine() + '\n');
        }
        string strInput = input.ToString().TrimEnd(new char[]{'\n'});
        //Console.WriteLine(strInput);
        bool isRevOp = false, isTogOp = false, isUpOp = false, isLowOp = false, isDelOp = false;
        bool isRevCl = false, isTogCl = false, isUpCl = false, isLowCl = false, isDelCl = false;
        StringBuilder output = new StringBuilder();
        int index = 0;
        while ((index < strInput.Length) && (input[index] != '<'))
        {
            output.Append(strInput[index]);
            index++;
        }
        StringBuilder tagBuffer = new StringBuilder();
        StringBuilder textBuffer = new StringBuilder();

        for (; index < strInput.Length; index++)
        {
            if (strInput[index] == '<')
            {
                index++;
                while ((index < strInput.Length) && (strInput[index] != '>'))
                {
                    tagBuffer.Append(strInput[index]);
                    index++;
                }
                index++;
                switch (tagBuffer.ToString())
                {
                    case "rev": isRevOp = true; break;
                    case "/rev": isRevCl = true; break;
                    case "del": isDelOp = true; break;
                    case "/del": isDelCl = true; break;
                    case "upper": isUpOp = true; break;
                    case "/upper": isUpCl = true; break;
                    case "lower": isLowOp = true; break;
                    case "/lower": isLowCl = true; break;
                    case "toggle": isTogOp = true; break;
                    case "/toggle": isTogCl = true; break;
                    default:
                        break;
                }
                tagBuffer.Clear();                                               
            }
            if (isDelOp)
            {
                if (index > strInput.Length - 1)
                {
                    break;
                }
                int closeDelInd = strInput.IndexOf("</del>", index);
                while ((index < strInput.Length) && index != closeDelInd)
                {
                    index++;
                }
                index += 5;
                isDelOp = false;
                continue;
            }
            if ((isTogOp) && (isTogCl))
            {
                textBuffer = ToggleText(textBuffer.ToString().ToCharArray());
                isTogOp = false;
                isTogCl = false;
                continue;
            }
            if ((isRevOp) && (isRevCl))
            {
                textBuffer = ReverseText(textBuffer.ToString().ToCharArray());
                isRevOp = false;
                isRevCl = false;
                continue;
            }
            if ((!isLowOp) && (!isUpOp) && (!isRevOp) && (!isTogOp))
            {
                output.Append(textBuffer.ToString());
                textBuffer.Clear();
                continue;
            }
            if (strInput[index] == '<')
            {
                index--;
                continue;
            }
            else
            {
                textBuffer.Append(strInput[index]);
            }
        }
        output.Append(textBuffer.ToString());
        Console.WriteLine(output);
    }
    private static StringBuilder ReverseText(char[] text)
    {
        StringBuilder newText = new StringBuilder();
        Array.Reverse(text);
        for (int i = 0; i < text.Length; i++)
        {
            newText.Append(text[i]);
        }
        return newText;
    }
    private static StringBuilder ToggleText(char[] text)
    {
        StringBuilder newText = new StringBuilder();
        for (int i = 0; i < text.Length; i++)
        {
            if (Char.IsUpper(text[i]))
            {
                newText.Append(Char.ToLower(text[i]));
            }
            else
            {
                newText.Append(Char.ToUpper(text[i]));
            }
        }
        return newText;
    }
}
