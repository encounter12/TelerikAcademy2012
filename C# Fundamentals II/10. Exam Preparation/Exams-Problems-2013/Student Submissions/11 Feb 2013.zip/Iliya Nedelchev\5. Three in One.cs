using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thirdPartyYEEEEEEEEEE
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] arr = new string[4];
            arr[0] = Console.ReadLine();
            arr[1] = Console.ReadLine();
            arr[2] = Console.ReadLine();
            arr[3] = Console.ReadLine();
            string[] blackJack=arr[0].Split(',');
            string[] sizeOfCake = arr[1].Split(',');
            int NumberOfFriend = int.Parse(arr[2]);
            string[] Resurs = arr[3].Split(' ');

            int countOfPlayer = 0;
            foreach (var item in blackJack)
                countOfPlayer++;
            int[] arrayPlayers = new int[countOfPlayer];
            for (int i = 0; i < countOfPlayer; i++)
            {
                arrayPlayers[i] = int.Parse(blackJack[i]);
            }
            int winner = -1;
            int max = 0;
            for (int i = 0; i < countOfPlayer; i++)
            {
                if (arrayPlayers[i] > max && arrayPlayers[i] < 22)
                {
                    winner = i;
                    max=arrayPlayers[i];
                }
                else if (max == arrayPlayers[i])
                {
                    winner = -1;
                }
            }
            Console.WriteLine(winner);

            int countCake=0;
            foreach (var item in sizeOfCake)
                countCake++;

            int[] sizeOfCakes = new int[countCake];
            for (int i = 0; i < countCake; i++)
                sizeOfCakes[i] = int.Parse(sizeOfCake[i]);
            Array.Sort(sizeOfCakes);
            int sumOfMyCake=0;
            for (int i = countCake - 1; i >= 0; i--)
            {
                sumOfMyCake += sizeOfCakes[i];
                int numberOfFriends = NumberOfFriend;
                do
                {
                    i--;
                    numberOfFriends--;
                }
                while (numberOfFriends > 0);
            }
            Console.WriteLine(sumOfMyCake);

            int g1 = int.Parse(Resurs[0]);
            int s1 = int.Parse(Resurs[1]);
            int b1 = int.Parse(Resurs[2]);
            int g2 = int.Parse(Resurs[3]);
            int s2 = int.Parse(Resurs[4]);
            int b2 = int.Parse(Resurs[5]);

            int countOfExchange=0;
            while (true)
            {
                if (g1 <= g2 &&  (s1 <= s2 && s1 < 11) && (b1 <= b2 && b1 < 11))
                {
                    //if (s1 < s2 || b1 < b2 || g1 < g2)
                    //{
                        countOfExchange = -1;
                        break;
                    //}
                }
                if (g1 >= g2 && s1 >= s2 && b1 >= b2)
                    break;
                if (g1 > g2)
                {
                    if (s1 < s2)
                    {
                        g1--;
                        s1 = s1 + 9;
                        countOfExchange++;
                    }
                }
                if (s1 >= s2)
                {
                    if (b1 < b2)
                    {
                        s1--;
                        b1 = b1 + 9;
                        countOfExchange++;
                    }
                    if (g1 < g2 )
                    {
                        g1++;
                        s1 -= 11;
                        countOfExchange++;
                    }
                }
                if (b1 >= b2)
                {
                    if (s1 < s2)
                    {
                        b1-=11;
                        s1++;
                        countOfExchange++;
                    }
                }
            }

            Console.WriteLine(countOfExchange);

        }
    }
}