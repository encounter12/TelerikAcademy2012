using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine();

            var words = new List<string>();

            var number = new List<int>();
            foreach (Match word in Regex.Matches(str, @"\w+"))
                words.Add(word.Value);

            
            
            foreach (string word in words)
            {
                number.Add(int.Parse(word));
                
            }
            int bestNumber = 0;
            int answer1 = 0;
            
            for (int i = 0; i < number.Count; i++)
            {
                if ((bestNumber < number[i]))
                {
                    bestNumber = number[i];
                    answer1 = i;
                }
               // else
                //{
                  //  answer1 = -1;
                //}
            }




            

            string str2 = Console.ReadLine();
            int F = int.Parse(Console.ReadLine());
            var words2 = new List<string>();
            var number2 = new List<int>();
            foreach (Match word in Regex.Matches(str2, @"\w+"))
                words2.Add(word.Value);



            foreach (string word in words2)
            {
                number2.Add(int.Parse(word));

            }

            int[] array = new int[number2.Count];
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = number2[i];
            }

            Array.Sort(array);
            Array.Reverse(array);



            int numberOfBites = 0;

            for (int i = 0; i < array.Length; i++)
            {
                if (i % (F + 1) == 0)
                {
                    numberOfBites = numberOfBites + array[i];
                }
            }

            Console.WriteLine(answer1);
            Console.WriteLine(numberOfBites);
        }
    }
}
