using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KukataIsDancing
{
    class Program
    {
        static string CheckMove(string input)
        {
            if (input.IndexOf('W') < 0)
            {
                return "GREEN";
            }
            else if (input.IndexOf('L') < 0 && input.IndexOf('R') < 0)
            {
                if (input.Length % 3 == 0) return "GREEN";
                else return "BLUE";
            }
            else return "RED";

        }

        static void Main()
        {
            List<string> inputs = new List<string>();
            string temp;

            byte N = byte.Parse(Console.ReadLine());

            for (int i = 0; i < N; i++)
            {
                temp = Console.ReadLine();
                inputs.Add(temp);
            }
            foreach (string str in inputs)
            {
                Console.WriteLine(CheckMove(str));
            }
        }
    }
}
