using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5
{
    class Program
    {
        struct Winner
        {
            public int index;
            public int points;
            public int count;
        }


        static void Main(string[] args)
        {
            //First Task

            string input = Console.ReadLine();
            string[] points = input.Split(',');

            string[] sizes = Console.ReadLine().Split(',');
            int F = int.Parse(Console.ReadLine());
            Array.Sort(sizes);
            int mySizes = 0;

            Winner player = new Winner();
            int j = 0;
            player.index = 0;
            player.points = 0;
            player.count = 0;

            foreach (var item in points)
            {
                if (int.Parse(item) <= 21)
                {
                    if (int.Parse(item) == player.points)
                    {
                        player.count++;
                    }

                    if (int.Parse(item) > player.points)
                    {
                        player.count = 0;
                        player.points = int.Parse(item);
                        player.count += 1;
                        player.index = j;
                    }
                }
                j++;
            }

            // SecondTask();

            

            for (int i = sizes.Length - 1; i >= 0; i = i - (F + 1))
            {
                mySizes += int.Parse(sizes[i]);
            }


            if (player.count == 1)
            {
                Console.WriteLine(player.index);
            }
            else
            {
                Console.WriteLine(-1);
            }

            Console.WriteLine(mySizes);

            Random gen = new Random();
            

            Console.WriteLine(gen.Next(-1, 10));

        }
    }
}
