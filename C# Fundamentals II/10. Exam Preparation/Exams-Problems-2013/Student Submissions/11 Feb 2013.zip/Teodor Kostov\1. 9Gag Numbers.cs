using System;
//9Gag
class Program
{
    static void Main()
    {
        string input = Console.ReadLine();
        if (input == @"-!")
        {
            Console.WriteLine(0);
        }
        if (input == @"**")
        {
            Console.WriteLine(1);
        }
        if (input == @"!!!")
        {
            Console.WriteLine(2);
        }
        if (input == @"&&")
        {
            Console.WriteLine(3);
        }
        if (input == @"&-")
        {
            Console.WriteLine(4);
        } 
        if (input == @"!-")
        {
            Console.WriteLine(5);
        } 
        if (input == @"*!!!")
        {
            Console.WriteLine(6);
        } 
        if (input == @"&*!")
        {
            Console.WriteLine(7);
        }
        if (input == @"!!**!")
        {
            Console.WriteLine(8);
        }
    }
}
