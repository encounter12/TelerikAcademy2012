using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Task_1
{
    class Program
    {
        static void Main()
        {
            string GagStr = Console.ReadLine();

           List<int> digits = GetNumbers(GagStr);

           BigInteger sum = 0;
            BigInteger multiplier = 1;
           for (int i = digits.Count-1; i >=0; i--)
           {
               sum += digits[i] * multiplier;
               multiplier *= 9;
           }

           Console.WriteLine(sum);
        }

        public static List<int> GetNumbers(string str)
        {
            string GagStr = str;

            List<string> Digits = new List<string>();

            Digits.Add("-!");
            Digits.Add("**");
            Digits.Add("!!!");
            Digits.Add("&&");
            Digits.Add("&-");
            Digits.Add("!-");
            Digits.Add("*!!!");
            Digits.Add("&*!");
            Digits.Add("!!**!-");

            List<string> possibleDigits = new List<string>();
            List<string> triedDigits = Digits;

            string digit = "";
            BigInteger digitCount = 0;

                possibleDigits.Clear();
                digit = "";
                for (int i = 0; i < GagStr.Length; i++)
                {
                    digit += GagStr[i].ToString();

                    if (Digits.Contains(digit))
                    {
                        possibleDigits.Add(digit);
                        triedDigits.Add(digit);
                        digitCount++;
                        digit = "";
                    }             
                }

            List<int> numbers = new List<int>();

            foreach (string Str in possibleDigits)
            {
                string num = Str;

                numbers.Add(Digits.IndexOf(num));
            }
            return numbers;
        }
    }
}
