using System;

class NineGagNumbers
{
    static void Main()
    {
        Console.WriteLine("Enter String:");
        string gagnumber = Console.ReadLine();
        Console.WriteLine("The entered string is: {0}", gagnumber);
        string[] symbols = new string[] { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
        string number = "";
        string p = gagnumber;
        while (p != "")
        {
            for (int i = 0; i < symbols.Length; i++)
            {
                if (p.IndexOf(symbols[i]) == 0)
                {
                    number = number + i.ToString();
                    p = p.Substring(symbols[i].Length, p.Length - symbols[i].Length);
                }
            }
        }
        int result = 0;
        for (int i = 1; i <= number.Length; i++)
        {
            result = result + number[number.Length - i] * (int)Math.Pow(9.0, i - 1);
        }
        Console.WriteLine(number);
        Console.WriteLine(result);
    }
}