using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Three_in_One
{
    class Program
    {

        static void Main(string[] args)
        {
            /*First task a round of Blackjack (Rule one - if player has more than 21 points he loses)
             * Rule 2 - if player have 21 or fewer points , he wins */

            Console.WriteLine("Enter n =");
            int n = int.Parse(Console.ReadLine());
            
           // Create an array of three ints.
	int[] array = { 21, 20, 19 };

	// Use for loop.
	for (int i = 0; i < array.Length; i++)
	{
	    Console.WriteLine(array[i]);
	}

   }
            
   

           
       
            static int IndexOfInt(int[] points, int value)
        {
            for (int i = 0; i < points.Length; i++)
            {
                if (points[i] == value && points[i] == 21)
                {
                    return 0;
                }
            }
            return -1;
        }
       


    }

} 