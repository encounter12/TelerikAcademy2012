using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        List<string> list = new List<string>(){"-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
        List<int> sumList = new List<int>();
        int helperSum = 0;
        decimal sum = 0;
        string temp = "";
        string input = Console.ReadLine();

        for (int i = 0; i < input.Length; i++)
        {
            temp += input[i];
            if(list.Contains(temp))
            {              
                helperSum = list.IndexOf(temp);
                //sum += helperSum + count * 9;
                sumList.Add(helperSum);
                temp = "";
            }
            
        }
        sum = 0;
        for (int i = 0; i < sumList.Count; i++)
        {
            int nine = 1;
            if (sumList.Count - 1 - i != 0)
            {
                for (int j = 0; j < sumList.Count - 1 - i; j++)
                {
                    nine *= 9;
                }
                sumList[i] = nine * sumList[i];//(sumList.Count - 1 - i) * 9 * sumList[i];
                //sum += sumList[i];
            }
            else
            {
                sumList[i] = sumList[i];
            }
            
            sum += sumList[i];
        }
        Console.WriteLine(sum);
    }
}
