using System;
using System.Collections.Generic;

class FakeTextMarkupLanguage
{
    static void Main()
    {
        string str = @"We <del>are</del> living <rev>in</rev> a <upper>yellow <lower>SUB</lower>submarine</upper>. We don't HAVE <lower>ANYthing</lower> else.";
        Console.WriteLine(MakeItLower(str));
        Console.WriteLine(MakeItUpper(str));
        Console.WriteLine(MakeItLower(MakeItUpper(str)));
        Console.WriteLine(MakeItUpper(MakeItLower(str)));
        Console.WriteLine(DeleteText(str));
        Console.WriteLine(ReverseText(str));


    }
    static string ConvertText(string str)
    {
        string FTML = (MakeItLower(MakeItUpper(str)));
        return FTML;
    }
    static string MakeItUpper(string str)
    {
        int startIndex = 0;
        int endIndex = 0;
        for (int i = 0; i < str.Length - 8; i++)
        {
            if (str.Substring(i, 7) == "<upper>")
            {
                startIndex = i + 7;
                i = startIndex;
            }
            if (str.Substring(i, 8) == "</upper>")
            {
                endIndex = i;
                int length = endIndex - startIndex;
                string upperStr = str.Substring(startIndex, length).ToUpper();
                str = str.Remove(startIndex, length);
                str = str.Insert(startIndex, upperStr);
                str = str.Remove(startIndex - 7, 7);
                str = str.Remove(endIndex - 7, 8);
            }
        }
        return str;
    }
    static string MakeItLower(string str)
    {
        int startIndex = 0;
        int endIndex = 0;
        for (int i = 0; i < str.Length - 8; i++)
        {
            if (str.Substring(i, 7) == "<lower>")
            {
                startIndex = i + 7;
                i = startIndex;
            }
            if (str.Substring(i, 8) == "</lower>")
            {
                endIndex = i;
                int length = endIndex - startIndex;
                string lowerStr = str.Substring(startIndex, length).ToLower();
                str = str.Remove(startIndex, length);
                str = str.Insert(startIndex, lowerStr);
                str = str.Remove(startIndex - 7, 7);
                str = str.Remove(endIndex - 7, 8);
            }
        }
        return str;
    }
    static string ToggleUpAndLow(string str)
    {
        int startIndex = 0;
        int endIndex = 0;
        for (int i = 0; i < str.Length - 9; i++)
        {
            if (str.Substring(i, 8) == "<toggle>")
            {
                startIndex = i + 8;
                i = startIndex;
            }
            if (str.Substring(i, 9) == "</toggle>")
            {
                endIndex = i;
                int length = endIndex - startIndex;
                string toggledStr = str.Substring(startIndex, length).ToLower();
                //Console.WriteLine(upperStr);
                str = str.Remove(startIndex, length);
                //Console.WriteLine(str);
                str = str.Insert(startIndex, toggledStr);
                //Console.WriteLine(str);
                str = str.Remove(startIndex - 8, 8);
                str = str.Remove(endIndex - 8, 9);
            }
        }
        return str;
    }
    static string DeleteText(string str)
    {
        int startIndex = 0;
        int endIndex = 0;
        for (int i = 0; i < str.Length - 6; i++)
        {
            if (str.Substring(i, 5) == "<del>")
            {
                startIndex = i + 5;
                i = startIndex;
            }
            if (str.Substring(i, 6) == "</del>")
            {
                endIndex = i;
                int length = endIndex - startIndex;
                string deletedStr = ("");
                str = str.Remove(startIndex, length);
                str = str.Insert(startIndex, deletedStr);
                str = str.Remove(startIndex - 5, 6);
                str = str.Remove(endIndex - 8, 6);
            }
        }
        return str;
    }
    static string ReverseText(string str)
    {
        int startIndex = 0;
        int endIndex = 0;
        for (int i = 0; i < str.Length - 6; i++)
        {
            if (str.Substring(i, 5) == "<rev>")
            {
                startIndex = i + 5;
                i = startIndex;
            }
            if (str.Substring(i, 6) == "</rev>")
            {
                endIndex = i;
                int length = endIndex - startIndex;
                string revStr = ReverseString(str.Substring(startIndex, length));
                str = str.Remove(startIndex, length);
                str = str.Insert(startIndex, revStr);
                str = str.Remove(startIndex - 5,5);
                str = str.Remove(endIndex - 5, 6);
            }
        }
        return str;
    }
    public static string ReverseString(string s)
    {
        char[] arr = s.ToCharArray();
        Array.Reverse(arr);
        return new string(arr);
    }
}



