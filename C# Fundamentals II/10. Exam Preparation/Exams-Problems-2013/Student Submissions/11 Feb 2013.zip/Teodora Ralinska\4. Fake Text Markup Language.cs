using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem4FakeTextMarkupLanguage
{
  class Problem4FakeTextMarkupLanguage
  {
    static string upper(string fakeText)
    {
      return fakeText.ToUpper();
    }
    static string lower(string fakeText)
    {
      return fakeText.ToLower();
    }
    static string toggle(string fakeText)
    {
      int n = fakeText.Length();
      for (int q = 0; q < n; q++)
      {
        return fakeText;
      }
    }
    static string del(string fakeText, int indexOne, int indexTwo)
    {
      return fakeText.Remove(indexOne, indexTwo - indexOne);
    }
    static string rev(string fakeText, int IndexOne, int indexTwo)
    {
      int i = 0;
      for (int r = indexOne; r <= indexTwo; r++)
      {
        char ch = fakeText[r];
        fakeText[r] = fakeText[indexTwo - i];
        fakeText[indexTwo - i] = ch;
      }
      return fakeText;
    }
    static void Main(string[] args)
    {
      int N = int.Parse(Console.ReadLine());
      string[] fakeText = new string[N];
      for (int n = 0; n < N; n++)
      {
        fakeText[N] = Console.ReadLine();
      }
      for (int i = 0; i < N; i++)
      {
        int indexOneUp = fakeText[i].IndexOf("<upper>");
        int indexTwoUp = fakeText[i].IndexOf("</upper>");
        if ((indexOne != - 1) and (indexTwo != - 1))
        {
          string upper = upper(fakeText[i].Substring(indexOneUp + 6, indexTwoUp));
          fakeText[i] = fakeText[i].Replace(fakeText[i].Substring(indexOneUp + 6, indexTwoUp), upper);
        }
        int indexOneLow = fakeText[i].IndexOf("<lower>");
        int indexTwoLow = fakeText[i].IndexOf("</lower>");
        if ((indexOne != - 1) and (indexTwo != - 1))
        {
          string lower = lower(fakeText[i].Substring(indexOneLow + 6, indexTwoLow));
          fakeText[i] = fakeText[i].Replace(fakeText[i].Substring(indexOneLow + 6, indexTwoLow, lower);
        }
        int indexOneTog = fakeText[i].IndexOf("<toggle>");
        int indexTwoTog = fakeText[i].IndexOf("</toggle>");
        if ((indexOne != - 1) and (indexTwo != - 1))
        {
          string toggle = toggle(fakeText[i].Substring(indexOneTog + 7, indexTwoTog));
          fakeText[i] = faleText[i].Replace(fakeText[i].Substring(indexOneTog + 7, indexTwoTog, toggle);
        }
        int indexOneDel = fakeText[i].IndexOf("<del>");
        int indexTwoDel = fakeText[i].IndexOf("</del>");
        if ((indexOne != - 1) and (indexTwo != - 1))
        {
          string del = del(fakeText[i].Substring(indexOneDel + 4, indexTwoDel), indexOneDel, indexTwoDel); 
          fakeText[i] = fakeText[i].Replace(fakeText[i].Substring(indexOneDel + 4, indexTwoDel, del);
        }
        int indexOneRev = fakeText[i].IndexOf("<Rev>");
        int indexTwoRev = fakeText[i].IndexOf("</Rev>");
        if ((indexOne != - 1) and (indexTwo != - 1))
        {
          string rev = rev(fakeText[i].Substring(indexOneRev + 4, indexTwoRev), indexOneRev, IndexTwoRev);
          fakeText[i] = fakeText[i].Replace(fakeText[i].Substring(indexOneRev + 4, indexTwoRev, rev);
        }
      }
      for (int p = 0; p < N; p++)
      {
        Console.WriteLine("{0}", fakeText[p]);
      }
    }
  }
}