    using System;

        class Program
        {
            static void Main()
            {
                int N = int.Parse(Console.ReadLine());
                string[] options = new string[N];
             
                if(N < 5 && N > 10)
                {
                    Main();
                    Console.WriteLine("asd");
                }
                for (int i = 0; i < N; i++)
                {
                    options[i] = Console.ReadLine();
                    options[i] = options[i].ToUpper();
                    for (int j = 0; j < options[i].Length; j++)
			        {
			            if(!(options[i][j] == 'W' || options[i][j] == 'R' || options[i][j] == 'L'))
                            Main();
			        }
                    if (options[i].IndexOf('W') == -1)
                    {
                        Console.WriteLine("GREEN");
                        continue;
                    }
                    else if (options[i].IndexOf('L') == -1 && options[i].IndexOf('R') == -1)
                    {
                        if (options[i].Length % 3 == 0)
                        {
                            Console.WriteLine("GREEN");
                        }
                        else
                        {
                            Console.WriteLine("BLUE");
                        }
                    }
                    else
                    {
                        int count = 0;
                        int count2 = 0;
                        char[] symbols = options[i].ToCharArray();
                        int elements = 0;

                        for (int j = 0; j < symbols.Length; j++)
                        {
                            if (symbols[j] == 'W')
                            {
                                break;
                            }
                            elements++;
                        }
                        options[i] = options[i].Remove(0, elements);
                        symbols = options[i].ToCharArray();
                        elements = 0;
                        for (int j = symbols.Length - 1; j >= 0; j--)
                        {
                            if (symbols[j] == 'W')
                            {
                                break;
                            }
                            elements++;

                        }
                        options[i] = options[i].Remove(options[i].Length - elements, elements);
                        for (int j = 0; j < options[i].Length; j++)
                        {
                            if (options[i][j] == 'W')
                            {
                                count++;
                            }
                            else
                            {
                                count2++;
                            }
                        }

                        if (count - count2 < 2)
                        {

                            Console.WriteLine("RED");
                        }
                        else
                        {
                            Console.WriteLine("BLUE");



                        }
                    }

                }
            }
        }