using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5tasks
{
  class Program
  {
    static List<long> QuickSort(List<long> arr) {
      if(arr.Count <= 1) {
        return arr;
      }
      int i;
      int midIndex = arr.Count / 2;
      long mid = arr[midIndex];
      arr.RemoveAt(midIndex);
      List<long> left = new List<long>();
      List<long> right = new List<long>();
    
      for(i = 0; i < arr.Count; i++) {
        if(arr[i] < mid) right.Add(arr[i]);
        else left.Add(arr[i]);
      }
      return Merge(QuickSort(left), mid, QuickSort(right));
    } 
    
    static List<long> Merge(List<long> left, long mid, List<long> right) {
      List<long> result = new List<long>();
      foreach(var i in left) result.Add(i);
      result.Add(mid);
      foreach(var i in right) result.Add(i);
      return result;
       
    }

    static long Blackjack(long[] scores) {
      long winCount = 0;
      long maxScore = 0;
      long playerIndex = 0;
      for(long i = 0; i < scores.Length; i++) {
        if (scores[i] <= 21) {
          if(scores[i] > maxScore) {
            maxScore = scores[i];
            winCount = 1;
            playerIndex = i;
          } else if (scores[i] == maxScore) {
            winCount++;
          }
        }
      }
      if (winCount == 1) return playerIndex;
      else               return -1;
    }
    
    static long CakeEating(long[] cake, long fellows) {
      cake = QuickSort(cake.ToList()).ToArray();
      long amount = cake[0];
      long index = 0;
      while (index + fellows < cake.Length) {
        index += fellows;
        amount += cake[index];
      }
      return amount;
    }
    
    static bool BankMerge(long[] coins, long index) {
      if (index > 2 || index <= 0) return false;
      if (coins[index] < 11) return false;
      coins[index] -= 11;
      coins[index - 1] += 1;
      return true;
    }

    static bool BankSplit(long[] coins, long index) {
      if(index < 0 || index >= 2) return false;
      if(coins[index] < 1) return false; 
      coins[index]--;
      coins[index + 1] += 9;
      return true;
    }

    static long Exchanges(long[] myCoins, long[] beer) {
      long exchanges = 0;
      while(myCoins[2] - beer[2] < 0) {
        if(!BankSplit(myCoins,1)) {
          BankSplit(myCoins,0);
        }
        exchanges++;
      }
      while(myCoins[0] - beer[0] < 0) {
        if(!BankMerge(myCoins,1)) {
          BankMerge(myCoins,2);
        }
        exchanges++;
      } 
      if (myCoins[1] - beer[1] >= 0) return exchanges;       //-->
      while(myCoins[1] - beer[1] < 0) {
        if(myCoins[0] - beer[0] > 0) {
          BankSplit(myCoins,0);
        } else {
          BankMerge(myCoins, 2);
        }
        exchanges++;
      }
      return exchanges;
    }
    
    
    static void Main()
    {
      long[] points = Console.ReadLine().Split(',').Select(x => long.Parse(x)).ToArray();
      long[] cake   = Console.ReadLine().Split(',').Select(x => long.Parse(x)).ToArray();
      long fellows = long.Parse(Console.ReadLine()) + 1;
      long[] coins = Console.ReadLine().Split(' ').Select(x => long.Parse(x)).ToArray();
      long[] mine = new long[] {coins[0], coins[1], coins[2]};
      long[] beer = new long[] {coins[3], coins[4], coins[5]};
      long[] aaa = new long[10] {4,9,1,2,3,4,3,1,8,7};
      Console.WriteLine(Blackjack(points));
      Console.WriteLine(CakeEating(cake, fellows));
      Console.WriteLine(Exchanges(mine,beer));
    }                                               
  }
}
