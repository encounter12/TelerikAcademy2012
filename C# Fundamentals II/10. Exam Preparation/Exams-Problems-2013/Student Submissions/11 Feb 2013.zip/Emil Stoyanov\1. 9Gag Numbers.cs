using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;

class NineGagNumbers
{
    static Dictionary<string, int> Digits = new Dictionary<string, int>()
    {
        { "-!", 0 }, { "**", 1 }, { "!!!", 2 }, { "&&", 3 }, { "&-", 4 },
        { "!-", 5 }, { "*!!!", 6 }, { "&*!", 7 }, { "!!**!-", 8 }
    };

    static void Main()
    {
        string line = Console.ReadLine();

        Stack<string> stack = new Stack<string>();
        StringBuilder digit = new StringBuilder();

        foreach (char ch in line)
        {
            digit.Append(ch);
            if (Digits.ContainsKey(digit.ToString())) {
                stack.Push(digit.ToString());
                digit.Clear();
            }
        }
        if (digit.Length > 0)
        {
            stack.Push(digit.ToString());
        }

        BigInteger number = 0;

        if (stack.Count > 0)
        {
            number += Digits[stack.Pop()];
        }

        BigInteger mul = 9;
        while (stack.Count > 0) {
            number += Digits[stack.Pop()] * mul;
            mul *= 9;
        }

        Console.WriteLine(number);
    }
}
