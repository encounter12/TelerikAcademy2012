using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace ConsoleApplication1
{
    class Program
    {
        
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            string[] numbers = new string[9]
            {
            "-!",
            "**",
            "!!!",
            "&&",
            "&-",
            "!-",
            "*!!!",
            "&*!",
            "!!**!-"
            };

            string numbersCon = "";
            string sub = "";
            int count = 0;
            BigInteger numChar = 0;

            foreach(char c in input)
            for (int i = 0; i < 9; i++)
            {
                if ((input.Contains(numbers[i])) && (input.IndexOf(numbers[i]) == 0))
                {
                    sub = numbers[i];
                    numbersCon = Convert.ToString(i) + numbersCon;
                    //input = input.Remove(sub);
                    int index = input.IndexOf(sub);
                    input = (index < 0)
                        ? input
                        : input.Remove(index, sub.Length);
                }

            }

            foreach (char c in numbersCon) 
                {
                    numChar += ((BigInteger)c - (int)'0') * (BigInteger)Math.Pow(9, count);
                    count++;
                }

            Console.WriteLine("{0}", numChar);

        }
    }
}
