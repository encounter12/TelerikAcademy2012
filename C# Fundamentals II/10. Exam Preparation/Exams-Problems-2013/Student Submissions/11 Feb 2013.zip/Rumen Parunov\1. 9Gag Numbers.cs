using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _9GagNumbers   ///E ne stana na tozi etap!No borbata prodajava!!!
{
    class Program
    {
        
        static int Found(string[] gags, string gagnumber)
        {

            int result = -1;
            int k = 0;
            for (int i = 1; i < gagnumber.Length; i++)
            {
                for (int j = 0; j < gags.Length; j++)
                {
                    if (gagnumber.Substring(k, i + k) == gags[j])
                    {
                        result = j;
                        break;
                    }
                }
            }
            
            return result;
           
        }

        static void Main(string[] args)
        {
            string gagnumber = Console.ReadLine();
            string[] gags = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
            List<int> numbers = new List<int>();
            int count = 0;
            int result = 0;
            for (int i = 0; i < gags.Length; i++)
            {
                if (gags[i] == gagnumber)
                {
                    Console.WriteLine(i);
                    break;
                }
                else
                {
                    if (i==gags.Length-1)
                    {
                        string temp = gagnumber;
                        do
                        {
                            
                            int rez = Found(gags, temp);
                           
                            if (rez != -1)
                            {
                                numbers.Add(rez); 
                                temp = gagnumber.Substring(gags[rez].Length);
                                break;
                            }
                            else
                            {
                                rez = 3;
                            }
                            
                            if ((gagnumber.Substring(gags[rez].Length).Length - 1) < 0)
                            {
                                break;
                            }
                            

                        } while (true);
                    }
                }

            }
            for (int row = 0; row < count; row++)
            {
                result += (numbers[row] * 9 ^ (count - row));
            }
           // Console.WriteLine(result);


        }




    }
}

