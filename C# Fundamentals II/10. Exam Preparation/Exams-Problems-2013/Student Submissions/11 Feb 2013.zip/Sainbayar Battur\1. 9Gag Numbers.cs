using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2._NineDigitsSystem
{
    class Program
    {
        static void Main(string[] args)

        {
            Console.Write("Enter Symbol: ");
            string str = Console.ReadLine();

             Console.WriteLine(Convert.ToString(str, 10));

        }
    }
    static int convertToNineDiint (string digit)
    {
        
        int digit;
        switch (lastDigit)
        {
            case "-!": digit = 0; break;
            case "**": digit = 1; break;
            case "!!!": digit = 2; break;
            case "&&":digit = 3; break;
            case "&-":digit = 4; break;
            case "!-":digit = 5; break;
            case "*!!!":digit = 6; break;
            case "&*!":digit= 7; break;
            case "!!**!-":digit = 8; break;
           
            default:
                break;
        }
        return digit
    }


}
