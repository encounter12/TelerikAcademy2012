using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KukataIsDancing
{
    class Program
    {
        enum field { RED, GREEN, BLUE, None };
        enum direction { Up, Down, Left, Right};
        direction p = new direction();
        static int x = 4, y = 4;

        private void getCommand(string command)
        {   
            if (command.Equals("L"))
            {
                switch (p)
                {
                    case direction.Up:
                        p = direction.Left;
                        break;
                    case direction.Right:
                        p = direction.Up;
                        break;
                    case direction.Down:
                        p = direction.Right;
                        break;
                    case direction.Left:
                        p = direction.Left;
                        break;
                }
            }
            if (command.Equals("R"))
            {
                switch (p)
                {
                    case direction.Up:
                        p = direction.Right;
                        break;
                    case direction.Left:
                        p = direction.Up;
                        break;
                    case direction.Down:
                        p = direction.Left;
                        break;
                    case direction.Right:
                        p = direction.Right;
                        break;
                }
            }
        }

        static void Main(string[] args)
        {
            Program pr = new Program();
            field[,] fieldDance = new field[,] { 
                                             { field.None, field.None, field.None,  field.RED, field.BLUE, field.RED,   field.None, field.None, field.None },
                                             { field.None, field.None, field.None,  field.BLUE, field.GREEN, field.BLUE,   field.None, field.None, field.None },
                                             { field.None, field.None, field.None,  field.RED, field.BLUE, field.RED,   field.None, field.None, field.None },

                                             { field.RED, field.BLUE, field.RED,    field.RED, field.BLUE, field.RED,   field.RED, field.BLUE, field.RED},
                                             { field.BLUE, field.GREEN, field.BLUE,  field.BLUE, field.GREEN, field.BLUE,   field.BLUE, field.GREEN, field.BLUE },
                                             { field.RED, field.BLUE, field.RED,   field.RED, field.BLUE, field.RED,   field.RED, field.BLUE, field.RED},

                                             { field.None, field.None, field.None,  field.RED, field.BLUE, field.RED,   field.None, field.None, field.None },
                                             { field.None, field.None, field.None,  field.BLUE, field.GREEN, field.BLUE,   field.None, field.None, field.None },
                                             { field.None, field.None, field.None,  field.RED, field.BLUE, field.RED,   field.None, field.None, field.None }};
            int numberOfLines = 0;
            do
            {
                Console.WriteLine("Number of lines: ");
                try
                {
                    numberOfLines = int.Parse(Console.ReadLine());
                }
                catch (Exception e)
                {
                    Console.WriteLine("Only integers accepted!");
                }
            } while (numberOfLines < 5 || numberOfLines > 10);

            string commandLine = Console.ReadLine();
            string commandPrev = commandLine.Substring(0,1);
            string KUKATA = "";

            if (commandPrev.Equals("L"))
            {
                pr.p = direction.Left;
            }
            else if (commandPrev.Equals("R"))
            {
                pr.p = direction.Right;
            }

            for (int line = 0; line < numberOfLines; line++)
            {
                for (int i = 1; i < commandLine.Length; i++)
                {
                    if (commandPrev != commandLine.Substring(i,1))
                    {
                        pr.getCommand(commandLine.Substring(i,1));
                        if (commandLine.Substring(i,1).Equals("W"))
                        {
                            switch (pr.p)
                            {
                                case direction.Up:
                                    Program.x--;
                                    KUKATA = fieldDance[x, y].ToString();
                                    break;
                                case direction.Left:
                                    Program.y--;
                                    KUKATA = fieldDance[x, y].ToString();
                                    break;
                                case direction.Right:
                                    Program.y++;
                                    KUKATA = fieldDance[x, y].ToString();
                                    break;
                                case direction.Down:
                                    Program.x++;
                                    KUKATA = fieldDance[x, y].ToString();
                                    break;
                            }
                        }
                        else if (commandLine.Substring(i, 1).Equals("L"))
                        {
                            pr.getCommand(commandLine.Substring(i,1));
                            KUKATA = fieldDance[x, y].ToString();
                        }
                        else if (commandLine.Substring(i, 1).Equals("R"))
                        {
                            pr.getCommand(commandLine.Substring(i, 1));
                            KUKATA = fieldDance[x, y].ToString();
                        }
                    }
                    pr.getCommand(commandLine.Substring(i, 1));
                    commandPrev = commandLine.Substring(i,1);
                }
                Console.WriteLine(KUKATA);
                commandLine = Console.ReadLine();
                commandPrev = commandLine.Substring(0,1);
            }
        }
    }
}
