using System;

class KukataIsDancing
{
    static void Main()
    {
        Console.Write("Number of dances: ");
        int n = int.Parse(Console.ReadLine());
        if (n < 5 || n > 10)
        {
            Console.WriteLine("N is not between 5 and 10");
        }
        string greenSquare = "GREEN";
        string blueSquare = "BLUE";
        string redSquare = "RED";
        string finalSquare = "GREEN";
        Console.WriteLine("Sequence: ");
        for (int i = 0; i < n; i++)
        {
            char move = char.Parse(Console.ReadLine());
            if (finalSquare == greenSquare)
            {
                if (move == 'W')
                {
                    finalSquare = blueSquare;   
                }
                if (move == 'R')
                {
                    finalSquare = greenSquare;
                }
                if (move == 'L')
                {
                    finalSquare = greenSquare;                 
                }
            }
            if (finalSquare == blueSquare)
            {
                if (move == 'W')
                {
                  
                }
                if (move == 'R')
                {
                    
                }
                if (move == 'L')
                {
                    
                }
            }
            if (finalSquare == redSquare)
            {
                if (move == 'W')
                {

                }
                if (move == 'R')
                {

                }
                if (move == 'L')
                {

                }
            }
        }
        Console.WriteLine(finalSquare);
    }
}