using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _9GagNumbers
{
    class Program
    {
        static string[] Numbers = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };

        static void Main()
        {
            int count = 2;

            List<int> list = new List<int>();
            string input = Console.ReadLine();
            string substr = "";
            decimal sum = 0;
            decimal temp = 0;

            for (int i = 0; i < input.Length; i++)
            {
                while (count < 7)
                {
                    for (int t = 0; t < Numbers.Length; t++)
                    {
                        substr = input.Substring(i, count);

                        if (substr.Equals(Numbers[t]))
                        {
                            list.Add(t);
                            i += count;
                            count = 1;

                            break;
                        }
                    }
                    if (i == input.Length) break;
                    count++;
                }

                for (int m = 0; m < list.Count; m++)
                {
                    temp = (decimal)list[m] * (decimal)Math.Pow(9, (list.Count - m - 1));
                    sum += temp;
                }
                Console.WriteLine(sum);
            }
        }
    }
}