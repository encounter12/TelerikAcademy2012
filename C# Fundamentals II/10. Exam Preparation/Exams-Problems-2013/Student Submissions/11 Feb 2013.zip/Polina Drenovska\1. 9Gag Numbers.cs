using System;
using System.Text;
using System.Numerics;

class GagNumbers
{
    static void Main()
    {
        string number = Console.ReadLine();
        int eventual = GetDigit(number);
        if (eventual >= 0)
        {
            Console.WriteLine(eventual);
        }
        else
        {
            StringBuilder razkodirahmeGo = new StringBuilder();
            string current = "";
            for (int i = 0; i < number.Length; i++)
            { 
                current += number[i].ToString();
                int digit = GetDigit(current);
                if (digit >= 0)
                {
                    razkodirahmeGo.Append(digit);
                    current = "";
                }
            }
            Console.WriteLine(AdditionDigits(razkodirahmeGo));
        }

    }
    static int GetDigit(string number)
    {
        int digit;
        switch (number)
        {
            case "-!":
                return 0;
                break;
            case "**":
                return 1;
                break;
            case "!!!":
                return 2;
                break;
            case "&&":
                return 3;
            case "&-":
                return 4;
            case "!-":
                return 5;
            case "*!!!":
                return 6;
            case "&*!":
                return 7;
            case "!!**!-":
                return 8;
            default : return -1;
        }
    }
    static BigInteger AdditionDigits(StringBuilder number)
    {
        BigInteger numBase = 1;
        BigInteger result = 0;
        for (int i = number.Length-1; i >=0 ; i--)
        {
            result += int.Parse(number[i].ToString()) * numBase;
            numBase *= 9;
        }
        return result;
    }
}
