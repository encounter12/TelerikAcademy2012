using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5_th_task
{
    class Program
    {
        private static int FirstTask(string firstLine)
        {
            string[] pointsInStr = firstLine.Split(',');
            int answer = -1;
            for (int i = 21; i >= 0; i--)
            {
                for (int j = 0; j<pointsInStr.Length;j++)
                {
                    if (i == Convert.ToInt32(pointsInStr[j]))
                    {
                        if (answer == -1)
                        {
                            answer = j;
                        }
                        else
                        {
                            answer = -1;
                            return answer;
                        }
                    }
                }
                if (answer != -1)
                {
                    return answer;
                }
            }
            return answer;
        }
        private static int SecondTask(string secondLine, int F)
        {
            int[] cakes = new int[10];
            int len = 0;
            foreach (var item in secondLine.Split(','))
            {
                cakes[len] = Convert.ToInt32(item);
                len++;
            }
            int reverser, max = 0;
            for (int i = 0; i < len; i++)
            {
                for (int j = i; j < len; j++)
                {
                    if (cakes[i] < cakes[j])
                    {
                        reverser = cakes[i];
                        cakes[i] = cakes[j];
                        cakes[j] = reverser;
                    }
                }
                if (i%F == 0)
                {
                    max += cakes[i];
                }
            }
            return max;
        }
        private static int ThirdTask(int[] money)
        {
            if (money[0] - money[3] < 0 && money[1] - money[4] < 0 && money[2] - money[5] < 0)
            {
                return -1;
            }
            if (money[0] - money[3] >= 0 && money[1] - money[4] >= 0 && money[2] - money[5] >= 0)
            {
                return 0;
            }
            return (money[0] - money[3])*9;
        }
        static void Main(string[] args)
        {
            string firstLine = Console.ReadLine();
            string secondLine = Console.ReadLine();
            int F = Convert.ToInt32(Console.ReadLine());
            string fourthLine = Console.ReadLine();
            int[] money = new int[6];
            int i = 0;
            foreach (var item in fourthLine.Split(' '))
            {
                money[i] = Convert.ToInt32(item);
            }
            int answerTask1 = FirstTask(firstLine);
            int answerTask2 = SecondTask(secondLine, F);
            int answerTask3 = ThirdTask(money);
            Console.WriteLine(answerTask1);
            Console.WriteLine(answerTask2);
            Console.WriteLine(answerTask3);
        }



    }
}
