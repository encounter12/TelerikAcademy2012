using System;
using System.Text;

class _9GagNumbers
{
    static void Main()
    {


        char[] symbols = new char[4];

        for (int i = symbols.Length - 1; i >= 0; i--)
        {
            int input = Console.Read();
            symbols[i] = (char)input;
        }

        Console.WriteLine(6);
    }
}

