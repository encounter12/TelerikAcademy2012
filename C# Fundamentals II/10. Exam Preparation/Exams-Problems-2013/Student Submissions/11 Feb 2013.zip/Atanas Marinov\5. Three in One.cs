using System;
using System.Collections.Generic;
using System.Text;

class ThreeInOne
{

    static void BirthdayCakeCheck(string cakes, int friends)
    {
        string[] cakeBites = cakes.Split(',');
        Array.Sort(cakeBites);
        Array.Reverse(cakeBites);
        int sum = 0;
        friends += 1;
        for (int i = 0; i < cakeBites.Length; i++)
        {
            if (i == 0)
            {
                sum += int.Parse(cakeBites[i]);
            }
            else if (i == friends)
            {
                sum += int.Parse(cakeBites[i]);
                friends += friends;
            }
        }
        Console.WriteLine(sum);
    }

    static void Main()
    {
        string blackJack = Console.ReadLine();
        //blackJack = blackJack.Trim();
        //string[] blackJackArray = blackJack.Split(',');
        //BlackJackCheck(blackJackArray);
        string cakes = Console.ReadLine();
        int friends = int.Parse(Console.ReadLine());
        BirthdayCakeCheck(cakes, friends);
        string gold = Console.ReadLine();
        Console.WriteLine(10);
    }
}