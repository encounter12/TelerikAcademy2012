using System;

class KukataIsDancing
{

    static int width, height, depth;

    static void Main()
    {
        string[, ,] cuboid = new string[3, 3, 3];

        for (int width = 0; width < 3; width++)
        {
            for (int height = 0; height < 3; height++)
            {
                for (int depth = 0; depth < 3; depth++)
                {
                    if ((width == 0 || width == 2) && (depth == 0 || depth == 2) &&
                        (height == 0 || height == 2))
                    {
                        cuboid[width, height, depth] = "RED";
                        //Console.WriteLine("{0} ", cuboid[width, height, depth]);

                    }
                    else
                    {
                        cuboid[width, height, depth] = "BLUE";
                        //Console.WriteLine("{0} ", cuboid[width, height, depth]);

                    }
                    if ((width == 1 && height == 1 && depth == 0) || (width == 1 && height == 1 && depth == 2) ||
                        (width == 1 && height == 2 && depth == 1) || (width == 1 && height == 1 && depth == 1) ||
                        (width == 1 && height == 0 && depth == 1))
                    {
                        cuboid[width, height, depth] = "GREEN";
                        //Console.WriteLine("{0} ", cuboid[width, height, depth]);
                    }
                }
            }

        }

        int n = int.Parse(Console.ReadLine());
        char[] letters = new char[51];
        int direction = 0;
        int oldDirection = -1;
        string startPosition = cuboid[1, 2, 1];
        int currentPositionWidth = 1;
        int currentPositionHeight = 2;
        int currentPositionDepth = 1;

        for (int i = 0; i < n; i++)
        {
            int symbol = Console.Read();
            letters[i] = (char)symbol;
        }


            for (int j = 0; j <= 0; j++)
            {
                switch (letters[j])
                {
                    case 'L':
                        direction--;
                        oldDirection++;
                        break;
                    case 'R':
                        direction++;
                        oldDirection--;
                        break;
                    case 'W':
                        if (direction < oldDirection)
                        {
                            currentPositionDepth++;
                            //currentPositionWidth++;

                            if (currentPositionDepth > 2 || currentPositionWidth > 2 ||
                                (currentPositionWidth > 2 && currentPositionDepth > 2))
                            {

                                currentPositionDepth--;
                                currentPositionWidth--;
                                currentPositionHeight--;
                            }
                        }
                        else
                        {
                            currentPositionDepth--;
                            //currentPositionWidth--;

                            if (currentPositionDepth < 0 || currentPositionWidth < 0 ||
                                (currentPositionWidth < 0 && currentPositionDepth < 0))
                            {
                                currentPositionDepth++;
                                currentPositionWidth++;
                                currentPositionHeight--;
                            }
                        }
                        break;
                }
                Console.WriteLine(cuboid[currentPositionWidth, currentPositionHeight, currentPositionDepth]);
            }
        }
}

