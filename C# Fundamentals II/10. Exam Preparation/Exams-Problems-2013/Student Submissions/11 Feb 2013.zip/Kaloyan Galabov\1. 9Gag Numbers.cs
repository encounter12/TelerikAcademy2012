using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
class Program
{
    static string[] crazyBase = new string[9] { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-", };
    static int ConvertToNine(string num)
    {
        double result = 0;
        for (int i = 0; i < num.Length; i++)
        {
            result += ((int)num[num.Length - 1 - i] - 48) * Math.Pow(9, i);
        }
        return (int)result;
    }
    static void CalcNum(string workOn, string obtained)
    {
        if (workOn.Length == 0)
        {
            Console.WriteLine(ConvertToNine(obtained));
        }
        int temp = 0;
        for (int j = 2; j < Math.Min(6, workOn.Length + 1); j++)
        {
            temp = Array.IndexOf(crazyBase, workOn.Substring(0, j));
            if (temp != -1)
            {
                CalcNum(workOn.Substring(j), obtained + temp.ToString());
            }
        }
    }
    static void CalcNum2(string workOn, StringBuilder obtained)
    {
        if (workOn.Length == 0)
        {
            Console.WriteLine(obtained);
        }
        int temp = 0;
        for (int j = 2; j < 6; j++)
        {
            temp = Array.IndexOf(crazyBase, workOn.Substring(0, j));
            if (temp != -1)
            {
                CalcNum(workOn.Substring(j), obtained + temp.ToString());
                return;
            }
        }
    }
    static void Main()
    {
        string inputNum = Console.ReadLine();
        CalcNum2(inputNum, new StringBuilder(""));
    }
}