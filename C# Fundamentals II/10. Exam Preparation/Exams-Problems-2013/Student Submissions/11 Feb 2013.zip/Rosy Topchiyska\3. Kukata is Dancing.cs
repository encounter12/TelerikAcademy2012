using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3kukata
{
  class Program
  {
    static void Main()
    {
      long n = long.Parse(Console.ReadLine());
      int i;
      List<string> moves = new List<string>();
      for(i = 0; i < n; i++) {
        moves.Add(Console.ReadLine());
      }
      string[,] dancing = new string[3,3] {{"RED", "BLUE", "RED"}, {"BLUE", "GREEN", "BLUE"}, {"RED", "BLUE", "RED"}};
      int[,] direction = new int[4,2] {{0,1},{-1,0},{0,-1},{1,0}};
      int dir = 0;
      int x = 1;
      int y = 1;



      for(i = 0; i < n; i++) {
        x = 1;
        y = 1;
        foreach(var move in moves[i]) {
          switch(move) {
            case 'R': dir = (dir + 4 - 1) % 4; break;
            case 'L': dir = (dir + 4 + 1) % 4; break;
            case 'W': 
              x = (x + 3 + direction[dir,0]) % 3;
              y = (y + 3 + direction[dir,1]) % 3;
            break;
          }
        }
        Console.WriteLine(dancing[x,y]);
      }
    }
  }
}
