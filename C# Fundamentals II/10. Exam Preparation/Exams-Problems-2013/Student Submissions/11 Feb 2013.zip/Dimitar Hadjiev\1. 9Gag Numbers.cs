using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class Numbers
{
    static void Main()
    {
        string str = Console.ReadLine();
        int[] sum = new int[20];
        string symbol = "";
        int count = 0;
        for (int i = 0; i < str.Length; i++)
        {
            symbol += str[i];
            int num =  CheckForNum(symbol);
            if (num >= 0)
            {
                symbol = "";
                sum[count] = num;
                count++;

            }
        }
        decimal endSum = 0M;
        int[] summ = new int[count];
        for (int i = 0; i <= count-1; i++)
        {
            summ[i] = sum[count -1 - i];
        }
        
        for (int i = 0; i <= count-1 ; i++)
        {
            if (i ==0)
            {
                endSum += summ[i];
                continue;
            }
            endSum += summ[i]*(decimal)Math.Pow(9,i);    
            
        }
            Console.WriteLine(endSum);    
        
    }

    private static int CheckForNum(string symbol)
    {
        if (symbol == "-!")//0
        {
            return 0;
        }
        if (symbol == "**")//1
        {
            return 1;
        }
        if (symbol == "!!!")//2
        {
            return 2;
        }
        if (symbol == "&&")//3
        {
            return 3;
        }
        if (symbol == "&-")//4
        {
            return 4;
        }
        if (symbol == "!-")//5
        {
            return 5;
        }
        if (symbol == "*!!!")//6
        {
            return 6;
        }
        if (symbol == "&*!")//7
        {
            return 7;
        }
        if (symbol == "!!**!-")//8
        {
            return 8;
        }
        return -1;
    }
}