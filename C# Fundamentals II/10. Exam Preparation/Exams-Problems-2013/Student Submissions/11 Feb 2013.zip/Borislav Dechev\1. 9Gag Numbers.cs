using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        string s = Console.ReadLine();
        double sum =0 ;      

        if (s.Length < 3)
        {
            int index0 = s.IndexOf("-!");
            if (index0 == 0)
            {
                Console.WriteLine("0");
            }
            int index1 = s.IndexOf("**");
            if (index1 == 0)
            {
                Console.WriteLine("1");
            }
            int index2 = s.IndexOf("&&");
            if (index2 == 0)
            {
                Console.WriteLine("3");
            }
            int index3 = s.IndexOf("&-");
            if (index3 == 0)
            {
                Console.WriteLine("4");
            }
            int index20 = s.IndexOf("!-");
            if (index20 == 0)
            {
                Console.WriteLine("5");
            }
        }
        else if (s.Length == 3)
        {
            int index4 = s.IndexOf("!!!");
            if (index4 == 0)
            {
                Console.WriteLine("2");
            }
            int index5 = s.IndexOf("&*!");
            if (index5 == 0)
            {
                Console.WriteLine("7");
            }
        }
         else if (s.Length == 4)
         {
             int index6 = s.IndexOf("*!!!");
             if (index6 == 0)
             {
                 Console.WriteLine("6");
             }
             
         }
        
        else
        {
            while (true)
            {
                int index10 = s.LastIndexOf("-!");
                if (index10 == 0)
                {
                    if (index10 == s.Length - 1)
                    {
                        int i = 0;
                        sum += 0 * Math.Pow(9, i);
                        i++;
                    }

                }

            }

        }
    }
}
