using System;

namespace SpecialValue
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(8);
        }
    }
}
