using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task3
{
    class Task3
    {
        static void Main()
        {
            string[, ,] cube = new string[3, 3, 3];
            bool turnLeft = false;
            bool turnRight = false;
            string currentCommand = "";

            cube[0, 0, 0 ] = "RED";
            cube[0, 0, 2 ] = "RED";
            cube[2, 0, 0 ] = "RED";
            cube[0, 2, 0 ] = "RED";
            cube[2, 2, 0 ] = "RED";
            cube[0, 2, 2 ] = "RED";
            cube[2, 2, 2 ] = "RED";
            cube[2, 0, 2 ] = "RED";
            cube[0,1,0] = "BLUE";
            cube[1,0,0] = "BLUE";
            cube[1,2,0] = "BLUE";
            cube[2,1,0] = "BLUE";
            cube[0,0,1] = "BLUE";
            cube[0,2,1] = "BLUE";
            cube[2,0,1] = "BLUE";
            cube[2,2,1] = "BLUE";
            cube[0,1,2] = "BLUE";
            cube[1,0,2] = "BLUE";
            cube[1,2,2] = "BLUE";
            cube[2,1,2] = "BLUE";
            cube[1 ,1 ,0] = "GREEN";
            cube[0 ,1 ,1] = "GREEN";
            cube[1, 0, 1] = "GREEN";
            cube[1, 2, 1] = "GREEN";
            cube[2, 1, 1] = "GREEN";
            cube[1, 1, 2] = "GREEN";


            int N = int.Parse(Console.ReadLine());
            string[] results = new string[N];
            for (int i = 0; i < N; i++)
            {
                string result = "GREEN";
                int dirWidth = 1;
                int dirHeight = 0;

                int posWidth = 1;
                int posHeight = 1;
                int posDepth = 0;
                string danceMoves = Console.ReadLine();
                foreach (var move in danceMoves)
                {
                    if (move == 'L')
                    {
                        if (dirWidth == 0 && dirHeight == 1)
                        {
                            dirHeight = 0;
                            dirWidth = -1;
                            continue;
                        }
                        if (dirWidth == - 1 && dirHeight == 0)
                        {
                            dirHeight = -1;
                            dirWidth = 0;
                            continue;
                        }
                        if (dirWidth == 0 && dirHeight == -1)
                        {
                            dirHeight = 0;
                            dirWidth = 1;
                            continue;
                        }
                        if (dirWidth == 1 && dirHeight == 0)
                        {
                            dirHeight = 1;
                            dirWidth = 0;
                            continue;
                        }

                    }
                    if (move == 'R')
                    {
                        if (dirWidth == 0 && dirHeight == 1)
                        {
                            dirHeight = 0;
                            dirWidth = 1;
                            continue;
                        }
                        if (dirWidth == 1 && dirHeight == 0)
                        {
                            dirHeight = -1;
                            dirWidth = 0;
                            continue;
                        }
                        if (dirWidth == 0 && dirHeight == -1)
                        {
                            dirHeight = 0;
                            dirWidth = -1;
                            continue;
                        }
                        if (dirWidth == -1 && dirHeight == 0)
                        {
                            dirHeight = 1;
                            dirWidth = 0;
                            continue;
                        }
                    }
                    
                    if (move == 'W')
                    {
                        if (posWidth + dirWidth <= 2 && posWidth + dirWidth >= 0 && posHeight + dirHeight <=2 && posHeight + dirHeight >= 0)
                        {
                            posWidth += dirWidth;
                            posHeight += dirHeight;
                            result = cube[posWidth, posHeight, posDepth];
                            continue;
                        }
                        else
                        {
                            if (posWidth + dirWidth > 2)
                            {
                                posWidth = 0;
                                result = cube[posWidth, posHeight, posDepth];
                                continue;
                            }
                            if (posWidth + dirWidth < 0)
                            {
                                posWidth = 2;
                                result = cube[posWidth, posHeight, posDepth];
                                continue;
                            }
                            if (posHeight + dirHeight > 2)
                            {
                                posHeight = 0;
                                result = cube[posWidth, posHeight, posDepth];
                                continue;
                            }
                            if (posHeight + dirHeight < 0)
                            {
                                posHeight = 2;
                                result = cube[posWidth, posHeight, posDepth];
                                continue;
                            }
                        }
                    }
                }
                results[i] = result;
            }
            for (int i = 0; i < results.Length; i++)
            {
                Console.WriteLine(results[i]);
            }
        }
    }
}
