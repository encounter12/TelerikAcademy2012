using System;

class Program
{
    static void Main()
    {
        string input = Console.ReadLine();
        string[] gagStyle = new string[] {"-!","**","!!!","&&","&-","!-","*!!!","&*!","!!**!-"}; 
        int index = 0;
        int length = input.Length;
        string digit = input.Substring(index, length);
        int count = 1;
        int sum = 0;
        string tempDigit = string.Empty;
        while (index<=input.Length-1)
        {
            for (int i = gagStyle.Length-1; i >= 0; i--)
            {
                if (digit.CompareTo(gagStyle[i]) == 0 && count == 1)
                {
                    sum = sum + i;
                    count++;
                    tempDigit = digit;
                    break;
                }

                else if (digit.CompareTo(gagStyle[i]) == 0 && count != 1)
                {
                    sum = sum + i * (int)Math.Pow(count, 9);
                    count++;
                    tempDigit = digit;
                }
            }
            if (tempDigit.Length.CompareTo(input.Length) == 0)
            {
                break;
            }
            else
            {
                index++;
                length--;
                digit = input.Substring(index, length);
            }
           
        }
        
        Console.WriteLine(sum);
    }
}

