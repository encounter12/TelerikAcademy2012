using System;
using System.Linq;

namespace Kukata_is_dancing
{
    class Kukata
    {
        static void Main(string[] args)
        {
            ////dancefloor
            //char[] possibleSides = {'a', 'b', 'c', 'd', 'e', 'f'};
            //byte[] possiblePositions = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

            //starting point
            char currentSide = 'c';
            byte currentPosition = 5;
            char nextSide = 'a';

            //input
            byte numberOfDances = byte.Parse(Console.ReadLine());
            string[] dance = new string[numberOfDances];
            for (int i = 0; i < numberOfDances; i++)
            {
                dance[i] = Console.ReadLine();
            }

            for (int i = 0; i < dance.Length; i++)
            {
                string currentDance = dance[i];
                for (int j = 0; j < currentDance.Length; j++)
                {
                    switch (currentSide)
                    {
                        case 'a':
                            switch (nextSide)
                            {
                                case 'f':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'b';
                                            break;
                                        case 'R':
                                            nextSide = 'd';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    currentPosition = 4;
                                                    break;
                                                case 2:
                                                    currentPosition = 5;
                                                    break;
                                                case 3:
                                                    currentPosition = 6;
                                                    break;
                                                case 4:
                                                    currentPosition = 7;
                                                    break;
                                                case 5:
                                                    currentPosition = 8;
                                                    break;
                                                case 6:
                                                    currentPosition = 9;
                                                    break;
                                                case 7:
                                                    nextSide = 'e';
                                                    currentPosition = 1;
                                                    currentSide = 'f';
                                                    break;
                                                case 8:
                                                    nextSide = 'e';
                                                    currentPosition = 2;
                                                    currentSide = 'f';
                                                    break;
                                                case 9:
                                                    nextSide = 'e';
                                                    currentPosition = 3;
                                                    currentSide = 'f';
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'd':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'f';
                                            break;
                                        case 'R':
                                            nextSide = 'c';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    currentPosition = 2;
                                                    break;
                                                case 2:
                                                    currentPosition = 3;
                                                    break;
                                                case 3:
                                                    nextSide = 'e';
                                                    currentPosition = 7;
                                                    currentSide = 'd';
                                                    break;
                                                case 4:
                                                    currentPosition = 5;
                                                    break;
                                                case 5:
                                                    currentPosition = 6;
                                                    break;
                                                case 6:
                                                    nextSide = 'e';
                                                    currentPosition = 8;
                                                    currentSide = 'd';
                                                    break;
                                                case 7:
                                                    currentPosition = 8;
                                                    break;
                                                case 8:
                                                    currentPosition = 9;
                                                    break;
                                                case 9:
                                                    nextSide = 'e';
                                                    currentPosition = 9;
                                                    currentSide = 'd';
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'c':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'd';
                                            break;
                                        case 'R':
                                            nextSide = 'b';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    nextSide = 'e';
                                                    currentPosition = 7;
                                                    currentSide = 'c';
                                                    break;
                                                case 2:
                                                    nextSide = 'e';
                                                    currentPosition = 8;
                                                    currentSide = 'c';
                                                    break;
                                                case 3:
                                                    nextSide = 'e';
                                                    currentPosition = 9;
                                                    currentSide = 'c';
                                                    break;
                                                case 4:
                                                    currentPosition = 1;
                                                    break;
                                                case 5:
                                                    currentPosition = 2;
                                                    break;
                                                case 6:
                                                    currentPosition = 3;
                                                    break;
                                                case 7:
                                                    currentPosition = 4;
                                                    break;
                                                case 8:
                                                    currentPosition = 5;
                                                    break;
                                                case 9:
                                                    currentPosition = 6;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'b':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'c';
                                            break;
                                        case 'R':
                                            nextSide = 'f';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    nextSide = 'e';
                                                    currentPosition = 9;
                                                    currentSide = 'b';
                                                    break;
                                                case 2:
                                                    currentPosition = 1;
                                                    break;
                                                case 3:
                                                    currentPosition = 2;
                                                    break;
                                                case 4:
                                                    nextSide = 'e';
                                                    currentPosition = 8;
                                                    currentSide = 'b';
                                                    break;
                                                case 5:
                                                    currentPosition = 4;
                                                    break;
                                                case 6:
                                                    currentPosition = 5;
                                                    break;
                                                case 7:
                                                    nextSide = 'e';
                                                    currentPosition = 7;
                                                    currentSide = 'b';
                                                    break;
                                                case 8:
                                                    currentPosition = 7;
                                                    break;
                                                case 9:
                                                    currentPosition = 8;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                default:
                                    break;
                            }
                            break;
                        case 'b':
                            switch (nextSide)
                            {
                                case 'a':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'f';
                                            break;
                                        case 'R':
                                            nextSide = 'c';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    currentPosition = 4;
                                                    break;
                                                case 2:
                                                    currentPosition = 5;
                                                    break;
                                                case 3:
                                                    currentPosition = 6;
                                                    break;
                                                case 4:
                                                    currentPosition = 7;
                                                    break;
                                                case 5:
                                                    currentPosition = 8;
                                                    break;
                                                case 6:
                                                    currentPosition = 9;
                                                    break;
                                                case 7:
                                                    nextSide = 'd';
                                                    currentPosition = 7;
                                                    currentSide = 'a';
                                                    break;
                                                case 8:
                                                    nextSide = 'd';
                                                    currentPosition = 4;
                                                    currentSide = 'a';
                                                    break;
                                                case 9:
                                                    nextSide = 'd';
                                                    currentPosition = 1;
                                                    currentSide = 'a';
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'c':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'a';
                                            break;
                                        case 'R':
                                            nextSide = 'e';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    currentPosition = 2;
                                                    break;
                                                case 2:
                                                    currentPosition = 3;
                                                    break;
                                                case 3:
                                                    nextSide = 'd';
                                                    currentPosition = 1;
                                                    currentSide = 'c';
                                                    break;
                                                case 4:
                                                    currentPosition = 5;
                                                    break;
                                                case 5:
                                                    currentPosition = 6;
                                                    break;
                                                case 6:
                                                    nextSide = 'd';
                                                    currentPosition = 4;
                                                    currentSide = 'c';
                                                    break;
                                                case 7:
                                                    currentPosition = 8;
                                                    break;
                                                case 8:
                                                    currentPosition = 9;
                                                    break;
                                                case 9:
                                                    nextSide = 'd';
                                                    currentPosition = 7;
                                                    currentSide = 'c';
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'e':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'c';
                                            break;
                                        case 'R':
                                            nextSide = 'f';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    nextSide = 'd';
                                                    currentPosition = 1;
                                                    currentSide = 'e';
                                                    break;
                                                case 2:
                                                    nextSide = 'd';
                                                    currentPosition = 7;
                                                    currentSide = 'e';
                                                    break;
                                                case 3:
                                                    nextSide = 'e';
                                                    currentPosition = 3;
                                                    currentSide = 'b';
                                                    break;
                                                case 4:
                                                    currentPosition = 1;
                                                    break;
                                                case 5:
                                                    currentPosition = 2;
                                                    break;
                                                case 6:
                                                    currentPosition = 3;
                                                    break;
                                                case 7:
                                                    currentPosition = 4;
                                                    break;
                                                case 8:
                                                    currentPosition = 5;
                                                    break;
                                                case 9:
                                                    currentPosition = 6;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'f':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'e';
                                            break;
                                        case 'R':
                                            nextSide = 'a';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    nextSide = 'd';
                                                    currentPosition = 7;
                                                    currentSide = 'f';
                                                    break;
                                                case 2:
                                                    currentPosition = 1;
                                                    break;
                                                case 3:
                                                    currentPosition = 2;
                                                    break;
                                                case 4:
                                                    nextSide = 'd';
                                                    currentPosition = 4;
                                                    currentSide = 'f';
                                                    break;
                                                case 5:
                                                    currentPosition = 4;
                                                    break;
                                                case 6:
                                                    currentPosition = 5;
                                                    break;
                                                case 7:
                                                    nextSide = 'd';
                                                    currentPosition = 7;
                                                    currentSide = 'f';
                                                    break;
                                                case 8:
                                                    currentPosition = 7;
                                                    break;
                                                case 9:
                                                    currentPosition = 8;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                default:
                                    break;
                            }
                            break;
                        case 'c':
                            switch (nextSide)
                            {
                                case 'a':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'b';
                                            break;
                                        case 'R':
                                            nextSide = 'd';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    currentPosition = 4;
                                                    break;
                                                case 2:
                                                    currentPosition = 5;
                                                    break;
                                                case 3:
                                                    currentPosition = 6;
                                                    break;
                                                case 4:
                                                    currentPosition = 7;
                                                    break;
                                                case 5:
                                                    currentPosition = 8;
                                                    break;
                                                case 6:
                                                    currentPosition = 9;
                                                    break;
                                                case 7:
                                                    nextSide = 'f';
                                                    currentPosition = 1;
                                                    currentSide = 'a';
                                                    break;
                                                case 8:
                                                    nextSide = 'f';
                                                    currentPosition = 2;
                                                    currentSide = 'a';
                                                    break;
                                                case 9:
                                                    nextSide = 'f';
                                                    currentPosition = 3;
                                                    currentSide = 'a';
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'd':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'a';
                                            break;
                                        case 'R':
                                            nextSide = 'e';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    currentPosition = 2;
                                                    break;
                                                case 2:
                                                    currentPosition = 3;
                                                    break;
                                                case 3:
                                                    nextSide = 'f';
                                                    currentPosition = 1;
                                                    currentSide = 'd';
                                                    break;
                                                case 4:
                                                    currentPosition = 5;
                                                    break;
                                                case 5:
                                                    currentPosition = 6;
                                                    break;
                                                case 6:
                                                    nextSide = 'f';
                                                    currentPosition = 4;
                                                    currentSide = 'd';
                                                    break;
                                                case 7:
                                                    currentPosition = 8;
                                                    break;
                                                case 8:
                                                    currentPosition = 9;
                                                    break;
                                                case 9:
                                                    nextSide = 'f';
                                                    currentPosition = 7;
                                                    currentSide = 'd';
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'e':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'd';
                                            break;
                                        case 'R':
                                            nextSide = 'b';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    nextSide = 'f';
                                                    currentPosition = 7;
                                                    currentSide = 'e';
                                                    break;
                                                case 2:
                                                    nextSide = 'f';
                                                    currentPosition = 8;
                                                    currentSide = 'e';
                                                    break;
                                                case 3:
                                                    nextSide = 'f';
                                                    currentPosition = 9;
                                                    currentSide = 'e';
                                                    break;
                                                case 4:
                                                    currentPosition = 1;
                                                    break;
                                                case 5:
                                                    currentPosition = 2;
                                                    break;
                                                case 6:
                                                    currentPosition = 3;
                                                    break;
                                                case 7:
                                                    currentPosition = 4;
                                                    break;
                                                case 8:
                                                    currentPosition = 5;
                                                    break;
                                                case 9:
                                                    currentPosition = 6;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'b':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'e';
                                            break;
                                        case 'R':
                                            nextSide = 'a';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    nextSide = 'f';
                                                    currentPosition = 3;
                                                    currentSide = 'b';
                                                    break;
                                                case 2:
                                                    currentPosition = 1;
                                                    break;
                                                case 3:
                                                    currentPosition = 2;
                                                    break;
                                                case 4:
                                                    nextSide = 'f';
                                                    currentPosition = 6;
                                                    currentSide = 'b';
                                                    break;
                                                case 5:
                                                    currentPosition = 4;
                                                    break;
                                                case 6:
                                                    currentPosition = 5;
                                                    break;
                                                case 7:
                                                    nextSide = 'f';
                                                    currentPosition = 9;
                                                    currentSide = 'b';
                                                    break;
                                                case 8:
                                                    currentPosition = 7;
                                                    break;
                                                case 9:
                                                    currentPosition = 8;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                default:
                                    break;
                            }
                            break;
                        case 'd':
                            switch (nextSide)
                            {
                                case 'a':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'c';
                                            break;
                                        case 'R':
                                            nextSide = 'f';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    currentPosition = 4;
                                                    break;
                                                case 2:
                                                    currentPosition = 5;
                                                    break;
                                                case 3:
                                                    currentPosition = 6;
                                                    break;
                                                case 4:
                                                    currentPosition = 7;
                                                    break;
                                                case 5:
                                                    currentPosition = 8;
                                                    break;
                                                case 6:
                                                    currentPosition = 9;
                                                    break;
                                                case 7:
                                                    nextSide = 'b';
                                                    currentPosition = 3;
                                                    currentSide = 'c';
                                                    break;
                                                case 8:
                                                    nextSide = 'b';
                                                    currentPosition = 6;
                                                    currentSide = 'c';
                                                    break;
                                                case 9:
                                                    nextSide = 'b';
                                                    currentPosition = 9;
                                                    currentSide = 'c';
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'f':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'a';
                                            break;
                                        case 'R':
                                            nextSide = 'e';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    currentPosition = 2;
                                                    break;
                                                case 2:
                                                    currentPosition = 3;
                                                    break;
                                                case 3:
                                                    nextSide = 'b';
                                                    currentPosition = 9;
                                                    currentSide = 'f';
                                                    break;
                                                case 4:
                                                    currentPosition = 5;
                                                    break;
                                                case 5:
                                                    currentPosition = 6;
                                                    break;
                                                case 6:
                                                    nextSide = 'b';
                                                    currentPosition = 6;
                                                    currentSide = 'f';
                                                    break;
                                                case 7:
                                                    currentPosition = 8;
                                                    break;
                                                case 8:
                                                    currentPosition = 9;
                                                    break;
                                                case 9:
                                                    nextSide = 'b';
                                                    currentPosition = 3;
                                                    currentSide = 'f';
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'e':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'f';
                                            break;
                                        case 'R':
                                            nextSide = 'c';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    nextSide = 'e';
                                                    currentPosition = 9;
                                                    currentSide = 'b';
                                                    break;
                                                case 2:
                                                    nextSide = 'e';
                                                    currentPosition = 6;
                                                    currentSide = 'b';
                                                    break;
                                                case 3:
                                                    nextSide = 'e';
                                                    currentPosition = 3;
                                                    currentSide = 'b';
                                                    break;
                                                case 4:
                                                    currentPosition = 1;
                                                    break;
                                                case 5:
                                                    currentPosition = 2;
                                                    break;
                                                case 6:
                                                    currentPosition = 3;
                                                    break;
                                                case 7:
                                                    currentPosition = 4;
                                                    break;
                                                case 8:
                                                    currentPosition = 5;
                                                    break;
                                                case 9:
                                                    currentPosition = 6;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'c':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'e';
                                            break;
                                        case 'R':
                                            nextSide = 'a';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    nextSide = 'b';
                                                    currentPosition = 3;
                                                    currentSide = 'c';
                                                    break;
                                                case 2:
                                                    currentPosition = 1;
                                                    break;
                                                case 3:
                                                    currentPosition = 2;
                                                    break;
                                                case 4:
                                                    nextSide = 'b';
                                                    currentPosition = 6;
                                                    currentSide = 'c';
                                                    break;
                                                case 5:
                                                    currentPosition = 4;
                                                    break;
                                                case 6:
                                                    currentPosition = 5;
                                                    break;
                                                case 7:
                                                    nextSide = 'b';
                                                    currentPosition = 9;
                                                    currentSide = 'c';
                                                    break;
                                                case 8:
                                                    currentPosition = 7;
                                                    break;
                                                case 9:
                                                    currentPosition = 8;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                default:
                                    break;
                            }
                            break;
                        case 'e':
                            switch (nextSide)
                            {
                                case 'c':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'b';
                                            break;
                                        case 'R':
                                            nextSide = 'd';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    currentPosition = 4;
                                                    break;
                                                case 2:
                                                    currentPosition = 5;
                                                    break;
                                                case 3:
                                                    currentPosition = 6;
                                                    break;
                                                case 4:
                                                    currentPosition = 7;
                                                    break;
                                                case 5:
                                                    currentPosition = 8;
                                                    break;
                                                case 6:
                                                    currentPosition = 9;
                                                    break;
                                                case 7:
                                                    nextSide = 'a';
                                                    currentPosition = 1;
                                                    currentSide = 'c';
                                                    break;
                                                case 8:
                                                    nextSide = 'a';
                                                    currentPosition = 2;
                                                    currentSide = 'c';
                                                    break;
                                                case 9:
                                                    nextSide = 'a';
                                                    currentPosition = 3;
                                                    currentSide = 'c';
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'd':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'c';
                                            break;
                                        case 'R':
                                            nextSide = 'f';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    currentPosition = 2;
                                                    break;
                                                case 2:
                                                    currentPosition = 3;
                                                    break;
                                                case 3:
                                                    nextSide = 'a';
                                                    currentPosition = 3;
                                                    currentSide = 'd';
                                                    break;
                                                case 4:
                                                    currentPosition = 5;
                                                    break;
                                                case 5:
                                                    currentPosition = 6;
                                                    break;
                                                case 6:
                                                    nextSide = 'a';
                                                    currentPosition = 2;
                                                    currentSide = 'd';
                                                    break;
                                                case 7:
                                                    currentPosition = 8;
                                                    break;
                                                case 8:
                                                    currentPosition = 9;
                                                    break;
                                                case 9:
                                                    nextSide = 'a';
                                                    currentPosition = 1;
                                                    currentSide = 'd';
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'f':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'd';
                                            break;
                                        case 'R':
                                            nextSide = 'b';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    nextSide = 'a';
                                                    currentPosition = 7;
                                                    currentSide = 'f';
                                                    break;
                                                case 2:
                                                    nextSide = 'a';
                                                    currentPosition = 8;
                                                    currentSide = 'f';
                                                    break;
                                                case 3:
                                                    nextSide = 'a';
                                                    currentPosition = 9;
                                                    currentSide = 'f';
                                                    break;
                                                case 4:
                                                    currentPosition = 1;
                                                    break;
                                                case 5:
                                                    currentPosition = 2;
                                                    break;
                                                case 6:
                                                    currentPosition = 3;
                                                    break;
                                                case 7:
                                                    currentPosition = 4;
                                                    break;
                                                case 8:
                                                    currentPosition = 5;
                                                    break;
                                                case 9:
                                                    currentPosition = 6;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'b':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'f';
                                            break;
                                        case 'R':
                                            nextSide = 'c';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    nextSide = 'a';
                                                    currentPosition = 1;
                                                    currentSide = 'b';
                                                    break;
                                                case 2:
                                                    currentPosition = 1;
                                                    break;
                                                case 3:
                                                    currentPosition = 2;
                                                    break;
                                                case 4:
                                                    nextSide = 'a';
                                                    currentPosition = 2;
                                                    currentSide = 'b';
                                                    break;
                                                case 5:
                                                    currentPosition = 4;
                                                    break;
                                                case 6:
                                                    currentPosition = 5;
                                                    break;
                                                case 7:
                                                    nextSide = 'a';
                                                    currentPosition = 3;
                                                    currentSide = 'b';
                                                    break;
                                                case 8:
                                                    currentPosition = 7;
                                                    break;
                                                case 9:
                                                    currentPosition = 8;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                default:
                                    break;
                            }
                            break;
                        case 'f':
                            switch (nextSide)
                            {
                                case 'e':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'b';
                                            break;
                                        case 'R':
                                            nextSide = 'd';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    currentPosition = 4;
                                                    break;
                                                case 2:
                                                    currentPosition = 5;
                                                    break;
                                                case 3:
                                                    currentPosition = 6;
                                                    break;
                                                case 4:
                                                    currentPosition = 7;
                                                    break;
                                                case 5:
                                                    currentPosition = 8;
                                                    break;
                                                case 6:
                                                    currentPosition = 9;
                                                    break;
                                                case 7:
                                                    nextSide = 'c';
                                                    currentPosition = 1;
                                                    currentSide = 'e';
                                                    break;
                                                case 8:
                                                    nextSide = 'c';
                                                    currentPosition = 2;
                                                    currentSide = 'e';
                                                    break;
                                                case 9:
                                                    nextSide = 'e';
                                                    currentPosition = 3;
                                                    currentSide = 'e';
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'd':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'e';
                                            break;
                                        case 'R':
                                            nextSide = 'a';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    currentPosition = 2;
                                                    break;
                                                case 2:
                                                    currentPosition = 3;
                                                    break;
                                                case 3:
                                                    nextSide = 'c';
                                                    currentPosition = 9;
                                                    currentSide = 'd';
                                                    break;
                                                case 4:
                                                    currentPosition = 5;
                                                    break;
                                                case 5:
                                                    currentPosition = 6;
                                                    break;
                                                case 6:
                                                    nextSide = 'c';
                                                    currentPosition = 6;
                                                    currentSide = 'd';
                                                    break;
                                                case 7:
                                                    currentPosition = 8;
                                                    break;
                                                case 8:
                                                    currentPosition = 9;
                                                    break;
                                                case 9:
                                                    nextSide = 'c';
                                                    currentPosition = 3;
                                                    currentSide = 'd';
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'a':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'd';
                                            break;
                                        case 'R':
                                            nextSide = 'b';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    nextSide = 'c';
                                                    currentPosition = 7;
                                                    currentSide = 'a';
                                                    break;
                                                case 2:
                                                    nextSide = 'c';
                                                    currentPosition = 8;
                                                    currentSide = 'a';
                                                    break;
                                                case 3:
                                                    nextSide = 'c';
                                                    currentPosition = 9;
                                                    currentSide = 'a';
                                                    break;
                                                case 4:
                                                    currentPosition = 1;
                                                    break;
                                                case 5:
                                                    currentPosition = 2;
                                                    break;
                                                case 6:
                                                    currentPosition = 3;
                                                    break;
                                                case 7:
                                                    currentPosition = 4;
                                                    break;
                                                case 8:
                                                    currentPosition = 5;
                                                    break;
                                                case 9:
                                                    currentPosition = 6;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                case 'b':
                                    switch (currentDance[j])
                                    {
                                        case 'L':
                                            nextSide = 'a';
                                            break;
                                        case 'R':
                                            nextSide = 'e';
                                            break;
                                        case 'W':
                                            switch (currentPosition)
                                            {
                                                case 1:
                                                    nextSide = 'c';
                                                    currentPosition = 7;
                                                    currentSide = 'b';
                                                    break;
                                                case 2:
                                                    currentPosition = 1;
                                                    break;
                                                case 3:
                                                    currentPosition = 2;
                                                    break;
                                                case 4:
                                                    nextSide = 'c';
                                                    currentPosition = 4;
                                                    currentSide = 'b';
                                                    break;
                                                case 5:
                                                    currentPosition = 4;
                                                    break;
                                                case 6:
                                                    currentPosition = 5;
                                                    break;
                                                case 7:
                                                    nextSide = 'c';
                                                    currentPosition = 1;
                                                    currentSide = 'b';
                                                    break;
                                                case 8:
                                                    currentPosition = 7;
                                                    break;
                                                case 9:
                                                    currentPosition = 8;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                default:
                                    break;
                            }
                            break;
                        default:
                            break;
                    }
                }
                //print the color of the last position
                switch (currentPosition)
                {
                    case 1:
                    case 3:
                    case 7:
                    case 9:
                        Console.WriteLine("RED");
                        break;
                    case 2:
                    case 4:
                    case 6:
                    case 8:
                        Console.WriteLine("BLUE");
                        break;
                    case 5:
                        Console.WriteLine("GREEN");
                        break;
                    default:
                        break;
                }
                currentPosition = 5;
                currentSide = 'c';
                nextSide = 'a';
            }
        }
    }
}
