using System;
using System.Linq;
using System.Text;


namespace zad4
{
    class Program
    {
        static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }
        static string ChangeCase(string s)
        {
            char[] arr = s.ToCharArray();
            bool inBrackets = false;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == '<') inBrackets = true;
                else if (arr[i] == '>') inBrackets = false;

                if (arr[i] >= 'a' && arr[i] <= 'z' && !inBrackets)
                {
                    arr[i] = (char)('A' + arr[i] - 'a');
                }
                else if (arr[i] >= 'A' && arr[i] <= 'Z' && !inBrackets)
                {
                    arr[i] = (char)('a' + arr[i] - 'A');
                }
            }
            return new string(arr);
        }
        static void Main(string[] args)
        {
            string ftml = "";
            StringBuilder buffer = new StringBuilder();
            int nLines = int.Parse(Console.ReadLine());
            for (int i = 0; i < nLines; i++)
            {
                 ftml = Console.ReadLine(); //Console.ReadLine();

                
                int openDelTag = ftml.IndexOf("<del>", 0);
                int closeDelTag = ftml.IndexOf("</del>", 0);

                while (openDelTag >= 0)
                {
                    if (closeDelTag > openDelTag)
                    {
                        
                        ftml = ftml.Remove(openDelTag+5, closeDelTag - openDelTag - 5);
                    }
                    openDelTag = ftml.IndexOf("<del>", openDelTag + 1);
                    closeDelTag = ftml.IndexOf("</del>");
                }
                ftml = ftml.Replace("<del>","");
                ftml = ftml.Replace("</del>","");
               // Console.WriteLine(ftml);
                int openUpperTag = ftml.IndexOf("<upper>", 0);
                int closeUpperTag = ftml.IndexOf("</upper>", 0); ;
                int openLowTag = ftml.IndexOf("<lower>", 0);
                int closelowerTag = ftml.IndexOf("</lower>", 0); ;
                if (closeUpperTag < openLowTag || closelowerTag<openUpperTag)
                {
                    while (openUpperTag >= 0)
                    {

                        if (closeUpperTag > openUpperTag)
                        {
                            string str = ftml.Substring(openUpperTag + 7, closeUpperTag - openUpperTag - 7);
                            string replace = ftml.Substring(openUpperTag + 7, closeUpperTag - openUpperTag - 7).ToUpper();
                            ftml = ftml.Replace(str, replace);
                            // ftml = ftml.Remove(openDelTag + 5, closeDelTag - openDelTag - 5);
                        }

                        openUpperTag = ftml.IndexOf("<upper>", openUpperTag + 1);
                        closeUpperTag = ftml.IndexOf("</upper>");
                    }
                    ftml = ftml.Replace("<upper>", "");
                    ftml = ftml.Replace("</upper>", "");

                    
                     openLowTag = ftml.IndexOf("<lower>", 0);
                     closelowerTag = ftml.IndexOf("</lower>", 0); ;
                    while (openLowTag >= 0)
                    {

                        if (closelowerTag > openLowTag)
                        {
                            string str = ftml.Substring(openLowTag + 7, closelowerTag - openLowTag - 7);
                            string replace = ftml.Substring(openLowTag + 7, closelowerTag - openLowTag - 7).ToLower();
                            ftml = ftml.Replace(str, replace);
                            // ftml = ftml.Remove(openDelTag + 5, closeDelTag - openDelTag - 5);
                        }

                        openLowTag = ftml.IndexOf("<lower>", openLowTag + 1);
                        closelowerTag = ftml.IndexOf("</lower>");
                    }
                    ftml = ftml.Replace("<lower>", "");
                    ftml = ftml.Replace("</lower>", "");
                }
                if (openUpperTag < openLowTag && closelowerTag<closeUpperTag)
                {
                    openUpperTag = ftml.IndexOf("<upper>", 0);
                     closeUpperTag = ftml.IndexOf("</upper>", 0); ;
                    
                    while (openUpperTag >= 0)
                    {

                        if (closeUpperTag > openUpperTag)
                        {
                            string str = ftml.Substring(openUpperTag + 7, closeUpperTag - openUpperTag - 7);
                            string replace = ftml.Substring(openUpperTag + 7, closeUpperTag - openUpperTag - 7).ToUpper();
                            ftml = ftml.Replace(str, replace);
                            // ftml = ftml.Remove(openDelTag + 5, closeDelTag - openDelTag - 5);
                        }

                        openUpperTag = ftml.IndexOf("<upper>", openUpperTag + 1);
                        closeUpperTag = ftml.IndexOf("</upper>");
                    }
                    ftml = ftml.Replace("<upper>", "");
                    ftml = ftml.Replace("</upper>", "");


                  

                      
                    ftml = ftml.Replace("<lower>", "");
                    ftml = ftml.Replace("</lower>", "");
                }
                else if (openUpperTag > openLowTag && closelowerTag > closeUpperTag)
                {
                    openLowTag = ftml.IndexOf("<lower>", openLowTag + 1);
                    closelowerTag = ftml.IndexOf("</lower>");
                    while (openLowTag >= 0)
                    {

                        if (closelowerTag > openLowTag)
                        {
                            string str = ftml.Substring(openLowTag + 7, closelowerTag - openLowTag - 7);
                            string replace = ftml.Substring(openLowTag + 7, closelowerTag - openLowTag - 7).ToLower();
                            ftml = ftml.Replace(str, replace);
                            // ftml = ftml.Remove(openDelTag + 5, closeDelTag - openDelTag - 5);
                        }

                        openLowTag = ftml.IndexOf("<lower>", openLowTag + 1);
                        closelowerTag = ftml.IndexOf("</lower>");
                    }
                    ftml = ftml.Replace("<lower>", "");
                    ftml = ftml.Replace("</lower>", "");

                   
                    ftml = ftml.Replace("<upper>", "");
                    ftml = ftml.Replace("</upper>", "");
                }
               
                int openToggleTag = ftml.IndexOf("<toggle>", 0);
                int closeToggleTag = ftml.IndexOf("</toggle>", 0); ;
                while (openToggleTag >= 0)
                {

                    if (closeToggleTag > openToggleTag)
                    {
                        string str = ftml.Substring(openToggleTag + 8, closeToggleTag - openToggleTag - 8);
                        string replace = ReverseString(ftml.Substring(openToggleTag + 8, closeToggleTag - openToggleTag - 8));
                        ftml = ftml.Replace(str, replace);
                        // ftml = ftml.Remove(openDelTag + 5, closeDelTag - openDelTag - 5);
                    }

                    openToggleTag = ftml.IndexOf("<toggle>", openToggleTag + 1);
                    closeToggleTag = ftml.IndexOf("</toggle>");
                }
                ftml = ftml.Replace("<toggle>", "");
                ftml = ftml.Replace("</toggle>", "");
                int openRevTag = ftml.IndexOf("<rev>", 0);
                int closeRevTag = ftml.IndexOf("</rev>", 0); ;
                while (openRevTag >= 0)
                {

                    if (closeRevTag > openRevTag)
                    {
                        Console.WriteLine();
                        string str = ftml.Substring(openRevTag + 5, closeRevTag - openRevTag - 5);
                        string replace = ReverseString(ftml.Substring(openRevTag + 5, closeRevTag - openRevTag - 5)).Trim();
                        ftml = ftml.Replace(str, replace);
                        // ftml = ftml.Remove(openDelTag + 5, closeDelTag - openDelTag - 5);
                    }

                    openRevTag = ftml.IndexOf("<rev>", openRevTag + 1);
                    closeRevTag = ftml.IndexOf("</rev>");

                }
                ftml = ftml.Replace("<rev>", "");
                ftml = ftml.Replace("</rev>", "");
                buffer.Append(ftml);
                buffer.Append("\r\n");
            }
            Console.WriteLine(buffer.ToString());
        }
           
    }
}
