using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        
        string inputNum = Console.ReadLine();
        TransformToDecimal(FindTheStartingNum(inputNum));         
    }
    static string FindTheStartingNum(string inputNum)
    {
        StringBuilder digit = new StringBuilder();
        string result = "";
        string[] inputDigits = new string[] {"-!","**","!!!","&&","&-","!-","*!!!","&*!","!!**!-"};
        for (int i = 0; i < inputNum.Length; i++)
		{
            digit.Append(inputNum[i]);
			if ((digit.ToString() == "-!")||(digit.ToString() == "**")||(digit.ToString() == "!!!")||
                (digit.ToString() == "&&")||(digit.ToString() == "&-")||(digit.ToString() == "!-")||
                (digit.ToString() == "*!!!")||(digit.ToString() == "&*!")||(digit.ToString() == "!!**!-"))
	        {
                string digitStr = digit.ToString();
                for (int j = 0; j < inputDigits.Length; j++)
			    {
			        if (digitStr == inputDigits[j])
                    {
                        result += j;
                        break;
                    }  
			    }
                digit.Clear();
                digitStr = "";
	        }
		}
        return result;
    }
    static void TransformToDecimal(string result)
    {
        decimal decNum = 0;
        decimal pow = 1;
        for (int i = (result.Length - 1); i >= 0; i--)
		{
            int digit = int.Parse(result[i].ToString());
            decNum += digit * pow;
            pow *= 9;
		}
        Console.WriteLine(decNum);
    }
}

