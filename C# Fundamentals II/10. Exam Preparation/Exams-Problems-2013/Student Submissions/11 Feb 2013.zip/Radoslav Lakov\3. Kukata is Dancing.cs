using System;
using System.IO;


class KukataIsDancing
{
	public char[, ,] Cube = new char[3, 3, 3];
	static void Main()
	{
#if DEBUG
		Console.SetIn(new StreamReader("Kukata.txt"));
#endif
		int n = int.Parse(Console.ReadLine());
		string[] lines = new string[n];
		for (int i = 0; i < n; i++)
		{
			lines[i] = Console.ReadLine();
		}
		KukataIsDancing dance = new KukataIsDancing();
		Position pos = new Position(1, 0, 1, 0, -1, 0, 1, 0, 0);
		foreach (string s in lines)
		{
			pos = new Position(1, 0, 1, 0, -1, 0, 1, 0, 0);
			foreach (char c in s)
			{
				switch (c)
				{
					case 'L':
						pos.Turn(left: true);
						break;
					case 'R': 
						pos.Turn(left: false);
						break;
					case 'W': 
						pos.Walk();
						break;
					default:
						break;
				}
				//Console.WriteLine(dance.Cube[pos.X, pos.Y, pos.Z]);
			}
			switch (dance.Cube[pos.X, pos.Y, pos.Z])
			{
				case 'g': Console.WriteLine("GREEN"); break;
				case 'r': Console.WriteLine("RED"); break;
				case 'b': Console.WriteLine("BLUE"); break;
			default:
					break;
			}
		}
	}
	public KukataIsDancing()
	{
		for (int h = 0; h < 3; h++)
		{
			for (int d = 0; d < 3; d++)
			{
				for (int w = 0; w < 3; w++)
				{
					if (h != 1 && d != 1 && w != 1)
					{
						Cube[h, d, w] = 'r';
					}
					else if ((h + d + w) % 2 > 0)
					{
						Cube[h, d, w] = 'b';
					}
					else
					{
						Cube[h, d, w] = 'g';
					}
				}
			}
		}
	}
	public struct Position
	{
		public int X, Y, Z;
		int HeadX, HeadY, HeadZ;
		int FaceX, FaceY, FaceZ;
		public Position(int x, int y, int z,
			int headX, int headY, int headZ,
			int faceX, int faceY, int faceZ)
		{
			X = x;
			Y = y;
			Z = z;
			HeadX = headX;
			HeadY = headY;
			HeadZ = headZ;
			FaceX = faceX;
			FaceY = faceY;
			FaceZ = faceZ;
		}
		public void Walk()
		{
			X += FaceX;
			Y += FaceY;
			Z += FaceZ;
			if (X < 0)
			{
				if (HeadZ != 0)
				{
					FaceZ = -HeadZ;
				}
				else
				{
					FaceY = -HeadY;
				}
				FaceX = 0;
				X = 0;
				HeadX = -1;
				HeadY = 0;
				HeadZ = 0;
			}
			else if (X > 2)
			{
				if (HeadZ != 0)
				{
					FaceZ = -HeadZ;
				}
				else
				{
					FaceY = -HeadY;
				}
				FaceX = 0;
				X = 2;
				HeadX = 1;
				HeadY = 0;
				HeadZ = 0;
			}
			if (Y < 0)
			{
				if (HeadZ != 0)
				{
					FaceZ = -HeadZ;
				}
				else
				{
					FaceX = -HeadX;
				}
				FaceY = 0;
				Y = 0;
				HeadX = 0;
				HeadY = -1;
				HeadZ = 0;
			}
			else if (Y > 2)
			{
				if (HeadZ != 0)
				{
					FaceZ = -HeadZ;
				}
				else
				{
					FaceX = -HeadX;
				}
				FaceY = 0;
				Y = 2;
				HeadX = 0;
				HeadY = 1;
				HeadZ = 0;
			}
			if (Z < 0)
			{
				if (HeadY != 0)
				{
					FaceY = -HeadY;
				}
				else
				{
					FaceX = -HeadX;
				}
				FaceZ = 0;
				Z = 0;
				HeadX = 0;
				HeadY = 0;
				HeadZ = -1;
			}
			else if (Z > 2)
			{
				if (HeadY != 0)
				{
					FaceY = -HeadY;
				}
				else
				{
					FaceX = -HeadX;
				}
				FaceZ = 0;
				Z = 2;
				HeadX = 0;
				HeadY = 0;
				HeadZ = 1;
			}
		}
		public void Turn(bool left)
		{
			int direction = left ? 1 : -1;
			if (HeadZ != 0)
			{
				if (FaceX == 1)
				{
					FaceX = 0; FaceY = direction * HeadZ;
				}
				else if (FaceY == 1)
				{
					FaceX = -direction * HeadZ; FaceY = 0;
				}
				else if (FaceX == -1)
				{
					FaceX = 0; FaceY = -direction * HeadZ;
				}
				else
				{
					FaceX = direction * HeadZ; FaceY = 0;
				}
			}
			else if (HeadX != 0)
			{
				if (FaceY == 1)
				{
					FaceY = 0; FaceZ = direction * HeadX;
				}
				else if (FaceZ == 1)
				{
					FaceY = -direction * HeadX; FaceZ = 0;
				}
				else if (FaceY == -1)
				{
					FaceY = 0; FaceZ = -direction * HeadX;
				}
				else
				{
					FaceY = direction * HeadX; FaceZ = 0;
				}
			}
			else if (HeadY != 0)
			{
				if (FaceZ == 1)
				{
					FaceZ = 0; FaceX = direction * HeadY;
				}
				else if (FaceX == 1)
				{
					FaceZ = -direction * HeadY; FaceX = 0;
				}
				else if (FaceZ == -1)
				{
					FaceZ = 0; FaceX = -direction * HeadY;
				}
				else
				{
					FaceZ = direction * HeadY; FaceX = 0;
				}
			}
		}
	}
}