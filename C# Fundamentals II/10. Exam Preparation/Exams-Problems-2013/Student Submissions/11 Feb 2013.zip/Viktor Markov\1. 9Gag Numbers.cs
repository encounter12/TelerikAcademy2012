using System;
using System.Collections.Generic;

class Program
{
    public static bool Strncmp(string a, string b)
    {
        bool flag = true;
        for (int i = 0 ; i<Math.Min(a.Length, b.Length) && flag; i++)
        {
            if(a[i] != b[i] )
            {
                flag = false;
            }
        }
        return flag; 
    }
    public static int ValidNumber(ref string str, string[] search, ref int counter, ref List<int> values )
    {

        bool flag = false;
        byte i = 0 ;
        for(i = 0 ; i<9 && !flag ; i++)
        {
            if(Strncmp(str, search[i]))
            {
                flag = true;
                values.Add(i);
                counter++;
                if(str.Length >= search[i].Length)
                {
                    str = str.Remove(0, search[i].Length);
                }

            }
        }
        return i;
    }
    static void Main()
    {
        string[] table = {"-!","**","!!!","&&","&-","!-","*!!!","&*!","!!**!-"};
        string input = Console.ReadLine();
        string buffer = input;
        int counter = 0 ;
        List<int> values = new List<int>();
        do
        {
            ValidNumber(ref buffer, table, ref counter, ref values);
        }while(buffer.Length>0);
        //Console.WriteLine(table[1][1]);
        double sum = 0;
        for(int i = counter-1 ; i>=0; i--)
        {
            sum = sum + values[i]*Math.Pow(9,counter - i - 1 );
        }
        Console.WriteLine(sum);
    }
}
