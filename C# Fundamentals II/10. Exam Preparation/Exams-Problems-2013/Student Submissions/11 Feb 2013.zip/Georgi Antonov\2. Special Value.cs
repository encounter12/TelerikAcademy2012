using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int[][] input = new int[n][];
        bool[][] visited = new bool[n][];
        for (int i = 0; i < n; i++)
        {
            String[] line = Regex.Split(Console.ReadLine(),", ");
            input[i] = new int[line.Length];
            visited[i] = new bool[line.Length];
            for (int j = 0; j < line.Length; j++)
            {
                input[i][j] = int.Parse(line[j]);
            }
        }

        bool hasLoop = false;
        int currentRow, currentCell, pathLength, max=0;
        for (int i = 0; i < input[0].Length; i++)
        {
            currentRow = 0;
            currentCell = i;
            pathLength = 0;
            while (!hasLoop && currentCell >=0)
            {
                if (visited[currentRow][currentCell])
                {
                    hasLoop = true;
                }
                else
                {
                    visited[currentRow][currentCell] = true;
                    currentCell = input[currentRow][currentCell];
                    pathLength++;
                    currentRow++;
                    if (currentRow == input.Length)
                    {
                        currentRow = 0;
                    }
                }
            }
            if (!hasLoop && max < pathLength + currentCell * (-1))
            {
                max = pathLength + currentCell * (-1);
            }
            for (int p = 0; p < visited.Length; p++)
            {
                for (int j = 0; j < visited[p].Length; j++)
                {
                    visited[p][j] = false;
                }
            }
        }
        Console.WriteLine(max);
    }
}