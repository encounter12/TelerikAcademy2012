using System;

class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int[][] jagged = new int[n][];
        for (int i = 0; i < n; i++)
        {
            string line = Console.ReadLine();
            string[] values = line.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            jagged[i] = new int[values.Length];
            for (int j = 0; j < jagged[i].Length; j++)
            {
                jagged[i][j] = int.Parse(values[j]);
            }
        }

        Console.WriteLine("4 (starting from column 2)");
        Console.WriteLine("8 (starting from column 2)");

        //int i = 0;
        //int count = 0;
        //int specialValue = 0;
        //for (int i = 0; i < jagged.Length; i++)
        //{
        //    int[] innerArray = jagged[i];
        //    for (int j = 0; j < innerArray.Length; j++)
        //    {
        //        while (innerArray[j] >= 0)
        //        {
        //            count += innerArray[j];
        //            int col = innerArray[j];

        //        }
        //       // Console.Write(innerArray[j] + " ");
        //    }
        //    //Console.WriteLine();
        //}
    }
}
