using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Hook
    {
        static void Main(string[] args)
        {
            string[,] cuboid = { { "RED", "BLUE", "RED" }, { "BLUE", "GREEN", "BLUE" }, { "RED", "BLUE", "RED" } };
            {
                /* foreach (var item in cuboid)
                 { Console.WriteLine(item); }*/
                int number = int.Parse(Console.ReadLine());
                string[] words = new string[number];
                for (int i = 0; i < number; i++)
                {
                    words[i] = Console.ReadLine();
                }
                for (int j = 0; j < number; j++)
                {
                    char[] temp = words[j].ToCharArray();

                    string position = cuboid[1, 1];
                    string positionlast = string.Empty;
                    //Console.WriteLine(position);
                    int rotationleft = 0;
                    int rotationright = 0;
                    int p =1;
                    int q =1;
                    for (int k = 0; k < temp.Length; k++)
                    {

                        if (temp[k] == 'L')
                        { rotationleft++; }
                        if (temp[k] == 'R')
                        { rotationright++; }
                        if (temp[k] == 'W')
                        {
                            if (rotationleft == 3 || rotationright == 1)
                            {
                                q = q + 1;
                                if (q > 2)
                                { q = 0; }
                            }

                            if (rotationleft == 1 || rotationright == 3)
                            {
                                q = q - 1;
                                if (q < 0)
                                { q = 2; }
                            }
                            if (rotationleft == 2 || rotationright == 2)
                            {
                                p = p + 1;
                                if (p > 2)
                                { p = 0; }
                            }
                            if (rotationleft == 0 || rotationright == 0)
                            {
                                p = p - 1;
                                if (p < 0)
                                { p = 2; }
                            }
                        }

                    }
                    Console.WriteLine(cuboid[p, q]);

                }

            }
        }
    }

}
