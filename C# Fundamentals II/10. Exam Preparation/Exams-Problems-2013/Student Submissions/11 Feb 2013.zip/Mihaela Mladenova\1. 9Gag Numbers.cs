using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        string nineGagString = Console.ReadLine();
        string[] scheme = new string[] { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
        char[] gagCharArr = nineGagString.ToCharArray();
        List<string> ansSymbols = new List<string>();
        int j = 0;
        string digitToCompare = gagCharArr[j].ToString();

        do
        {
            for (int i = 0; i < 9; i++)
            {
                int result = string.Compare(digitToCompare, scheme[i]);
                if (result == 0)
                {
                    ansSymbols.Add(digitToCompare);
                    digitToCompare = "";
                    Console.WriteLine("done");
                }
                j++;
                if (j == gagCharArr.Length) break;
                digitToCompare += gagCharArr[j].ToString();
            }
            j++;
        }
        while (j == gagCharArr.Length);
        
             ansSymbols.ForEach(Console.WriteLine);
    


    }
}

