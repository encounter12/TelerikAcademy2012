using System;
using System.Collections.Generic;
using System.Text;

class ProblemFour
{
    static void Main()
    {
        int lineNumber = int.Parse(Console.ReadLine());
        List<string> text = new List<string>();

        for (int counter = 0; counter < lineNumber; counter++)
        {
            text.Add(Console.ReadLine());
        }

        //text.Add("So<rev><upper>saw</upper> txet em</rev>");
        //text.Add("<lower><upper>here</upper></lower>");

        bool outOfTag = true;
        bool inTag = false;
        bool isRev = false;
        StringBuilder checkedLine = new StringBuilder();
        List<string> revText = new List<string>();
        List<string> lowerText = new List<string>();
        List<char> activeTags = new List<char>();
        List<string> readyText = new List<string>();

        int count = 0;
        char prevChar = '0';

        foreach (string line in text)
        {
            foreach (char symbol in line)
            {
                if (count > 0)
                {
                    count--;
                    continue;
                }
                else
                {
                    if (outOfTag)
                    {
                        if (activeTags.Count.Equals(0))
                        {
                            if (symbol.Equals('<'))
                            {
                                inTag = true;
                                outOfTag = false;
                            }
                            else
                            {
                                checkedLine.Append(symbol);
                            }
                        }
                        else 
                        {
                            if (symbol.Equals('<'))
                            {
                                inTag = true;
                                outOfTag = false;
                            }
                            else
                            {
                                if (activeTags[activeTags.Count - 1].Equals('u'))
                                {
                                    if (isRev)
                                    {
                                        revText.Add(symbol.ToString().ToUpper());
                                    }
                                    else
                                    {
                                        checkedLine.Append(symbol.ToString().ToUpper());
                                    }
                                }
                                else if (activeTags[activeTags.Count - 1].Equals('l'))
                                {
                                    if (isRev)
                                    {
                                        revText.Add(symbol.ToString().ToLower());
                                    }
                                    else
                                    {
                                        checkedLine.Append(symbol.ToString().ToLower());
                                    }
                                }
                                else if (activeTags[activeTags.Count - 1].Equals('d'))
                                {
                                    continue;
                                }
                                else if (activeTags[activeTags.Count - 1].Equals('r'))
                                {
                                        revText.Add(symbol.ToString());
                                }
                                else if (activeTags[activeTags.Count - 1].Equals('t'))
                                {
                                    if (isRev)
                                    {
                                        if (char.IsLower(symbol))
                                        {
                                            revText.Add(symbol.ToString().ToUpper());
                                        }
                                        else
                                        {
                                            revText.Add(symbol.ToString().ToLower());
                                        }
                                    }
                                    else
                                    {
                                        if (char.IsLower(symbol))
                                        {
                                            checkedLine.Append(symbol.ToString().ToUpper());
                                        }
                                        else
                                        {
                                            checkedLine.Append(symbol.ToString().ToLower());
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else if (inTag)
                    {
                        if (symbol.Equals('>'))
                        {
                            inTag = false;
                            outOfTag = true;
                        }
                        else if (symbol.Equals('u'))
                        {
                            if (!prevChar.Equals('/'))
                            {
                                activeTags.Add(symbol);
                            }
                            count = 4;
                        }
                        else if (symbol.Equals('l'))
                        {
                            if (!prevChar.Equals('/'))
	                        {
		                        activeTags.Add(symbol);
	                        }
                            count = 4;
                        }
                        else if (symbol.Equals('t'))
                        {
                            if (!prevChar.Equals('/'))
                            {
                                activeTags.Add(symbol);
                            }
                            count = 5;
                        }
                        else if (symbol.Equals('r'))
                        {
                            if (!prevChar.Equals('/'))
                            {
                                activeTags.Add(symbol);
                                isRev = true;
                            }
                            count = 2;
                        }
                        else if (symbol.Equals('d'))
                        {
                            if (!prevChar.Equals('/'))
                            {
                                activeTags.Add(symbol);
                            }
                            count = 2;
                        }
                        else if (symbol.Equals('/'))
                        {
                            if ((isRev) && activeTags[activeTags.Count - 1].Equals('r'))
                            {
                                isRev = false;
                                revText.Reverse();
                                foreach (var s in revText)
                                {
                                    checkedLine.Append(s);
                                }
                            }
                            activeTags.Reverse();
                            activeTags.RemoveAt(0);
                            activeTags.Reverse();
                        }
                    }
                }
                prevChar = symbol;
            }
            readyText.Add(checkedLine.ToString());
            checkedLine.Clear();
        }

        foreach (var line in readyText)
        {
            Console.WriteLine(line);
        }
    }
}
