using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FTMLReader
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = Int32.Parse(Console.ReadLine());

            string[] lines = new string[n];
            for (int i = 0; i < n; i++)
            {
                lines[i] = Console.ReadLine();
            }

            string[] openTags = new string[5] { "<upper>", "<lower>", "<toggle>", "<del>","<rev>" };
            string[] closeTags = new string[5] { "</upper>", "</lower>", "</toggle>", "</del>" ,"</rev>"};

            for(int i=0;i<lines.Length ;i++)
            {
                Dictionary<int, string> dictionaryOfTagPositions = new Dictionary<int, string>();
                StringBuilder builder = new StringBuilder (lines [i]);
                int[,] tagsIndexes = new int[5, 1];
                for (int j = 0; j < openTags.Length; j++)
                {
                    int indx = lines[i].IndexOf(openTags[j],0);
                    while (indx != -1)
                    {
                        dictionaryOfTagPositions.Add(indx, openTags[j]);
                        indx = lines[i].IndexOf(openTags[j],indx+1 );
                    }
                }
                var list = dictionaryOfTagPositions.Keys.ToList();
                list.Sort();
                for (int k = list.Count -1; k>=0 ; k--)
                {
                    int endIndx = builder.ToString ().IndexOf(closeTags[getCloseTagIndex(dictionaryOfTagPositions[list[k]])], list[k]);
                    int startIndx = list [k];
                    
                    if (dictionaryOfTagPositions[list[k]] == "<upper>")
                    {
                        builder.Replace(builder.ToString().Substring(list[k], endIndx + dictionaryOfTagPositions[list[k]].Length + 1 - list[k]), toUpper(builder.ToString().Substring(list[k] + dictionaryOfTagPositions[list[k]].Length, endIndx - closeTags[getCloseTagIndex(dictionaryOfTagPositions[list[k]])].Length + 1 - list[k])), list[k], endIndx + dictionaryOfTagPositions[list[k]].Length - list[k] + 1);
                    }
                    if (dictionaryOfTagPositions[list[k]] == "<lower>")
                    {
                        builder.Replace(builder.ToString().Substring(list[k], endIndx + dictionaryOfTagPositions[list[k]].Length + 1 - list[k]), toLower(builder.ToString().Substring(list[k] + dictionaryOfTagPositions[list[k]].Length, endIndx - closeTags[getCloseTagIndex(dictionaryOfTagPositions[list[k]])].Length + 1 - list[k])), list[k], endIndx + dictionaryOfTagPositions[list[k]].Length - list[k] + 1);
                    }
                    if (dictionaryOfTagPositions[list[k]] == "<toggle>")
                    {
                        builder.Replace(builder.ToString().Substring(list[k], endIndx + dictionaryOfTagPositions[list[k]].Length + 1 - list[k]), Toggle(builder.ToString().Substring(list[k] + dictionaryOfTagPositions[list[k]].Length, endIndx - closeTags[getCloseTagIndex(dictionaryOfTagPositions[list[k]])].Length + 1 - list[k])), list[k], endIndx + dictionaryOfTagPositions[list[k]].Length - list[k] + 1);
                    } 
                    if (dictionaryOfTagPositions[list[k]] == "<del>")
                    {
                        builder.Replace(builder.ToString().Substring(list[k], endIndx + dictionaryOfTagPositions[list[k]].Length + 1 - list[k]), Del(builder.ToString().Substring(list[k] + dictionaryOfTagPositions[list[k]].Length, endIndx - closeTags[getCloseTagIndex(dictionaryOfTagPositions[list[k]])].Length + 1 - list[k])), list[k], endIndx + dictionaryOfTagPositions[list[k]].Length - list[k] + 1);
                    }
                    if (dictionaryOfTagPositions[list[k]] == "<rev>")
                    {
                        builder.Replace(builder.ToString().Substring(list[k], endIndx + dictionaryOfTagPositions[list[k]].Length + 1 - list[k]), ReverseString(builder.ToString().Substring(list[k] + dictionaryOfTagPositions[list[k]].Length, endIndx - closeTags[getCloseTagIndex(dictionaryOfTagPositions[list[k]])].Length + 1 - list[k])), list[k], endIndx + dictionaryOfTagPositions[list[k]].Length - list[k] + 1);
                    }

                }
                Console.WriteLine(builder.ToString());
            }
        }

        private static int getCloseTagIndex(string str)
        {
            if (str == "<upper>")
                return 0;
            if (str == "<lower>")
                return 1;
            if (str == "<toggle>")
                return 2;
            if (str == "<del>")
                return 3;
            else
                return 4;
        }
        public static string  toUpper(string str)
        {
            return str.ToUpper();
        }
        public static string toLower(string str)
        {
            return str.ToLower ();
        }
        public static string Del(string str)
        {
            return "";
        }
        public static string Toggle(string str)
        {
            StringBuilder builder = new StringBuilder ();
            foreach (char c in str)
            {
                if (Char.IsLower(c))
                {
                    builder.Append(char.ToUpper(c));
                }
                else
                {
                    builder.Append(char.ToLower (c));
                }
            }
            return builder.ToString();
        }
        public static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }

    }
}
