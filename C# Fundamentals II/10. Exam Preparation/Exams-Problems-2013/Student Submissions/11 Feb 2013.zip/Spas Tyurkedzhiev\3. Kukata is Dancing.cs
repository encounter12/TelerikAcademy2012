using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static string[,] dancefloor =
            {   {"RED","BLUE","RED"},
                 {"BLUE","GREEN","BLUE"},
             {"RED","BLUE","RED"}
        };
        static void Main(string[] args)
        {
           int n = int.Parse(Console.ReadLine());
           for (int i = 0; i < n; i++)
          {
                Finish();
          }
        }
        static void Finish()
        {
         
            int x1=1, y1=1;
            char p = 'n'; //north
            string moves;
            moves= Console.ReadLine();
            char[] read = moves.ToCharArray();
            for (int i = 0; i < moves.Length; i++)
            { 
            switch(read[i])
            {
                case 'L':
                  if(p=='n') p='w';
                  if(p=='e') p='n';
                  if(p=='s') p='e';
                  if(p=='w') p='s';
                    break;
                case 'R':
                  if(p=='n') p='e';
                  if(p=='e') p='s';
                  if(p=='s') p='w';
                  if(p=='w') p='n';
                  break;
                case 'W':
                  if (p == 'n')
                  {
                      if (x1 == 0)
                      {
                          x1 = 0;
                      }
                      else
                      x1--;
                  }
                  if (p == 's')
                  {
                      if (x1 == 2)
                      {
                          x1 = 0;
                      }
                      else
                      x1++;
                  }
                  if (p == 'e')
                  {
                      if (y1 == 2)
                      {
                          y1 = 0;
                      }
                      else
                      y1++;
                  }  
                  if (p == 'w')
                  {
                      if (y1 == 0)
                      {
                          y1 = 2;
                      }
                      else
                      y1--;
                  }
                  break;
            }
            
            }
            Console.WriteLine(dancefloor[x1, y1]);


        }
        
    }
}
