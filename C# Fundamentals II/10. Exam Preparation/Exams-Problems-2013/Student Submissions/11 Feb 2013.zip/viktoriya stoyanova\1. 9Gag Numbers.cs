using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



class GagNumbers
{
    static void Main()
    {
        string input = Console.ReadLine();

        string[,] model = new string[,] { 
                          { "-!" , "**" , "!!!" , "&&" , "&-" , "!-" , "*!!!" , "&*!" , "!!**!-" },
                          { "0" , "1" , "2" , "3" , "4" , "5" , "6" , "7" , "8" } };

        double number1 = 0;
        double number2 = 0;
        double number3 = 0;
        double number4 = 0;
        double number5 = 0;
        double number6 = 0;
        double number7 = 0;
        double number8 = 0;
        double number9 = 0;
        double number10 = 0;
        double number11 = 0;
        double number12 = 0;
        double number13 = 0;
        double number14 = 0;
        double number15 = 0;
        double number16 = 0;
        double number17 = 0;
        double number18 = 0;
        double number19 = 0;
        double number20 = 0;
        int position = 0;
        double sum = 0;

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < input.Length; i++)
        {
            sb.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb.ToString() == model[0, j])
                {
                    number1 = double.Parse(model[1, j]);
                    sum = number1;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sbb = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sbb.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sbb.ToString() == model[0, j])
                {
                    number2 = double.Parse(model[1, j]);
                    sum = 9 * number1 + number2;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sbbb = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sbbb.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sbbb.ToString() == model[0, j])
                {
                    number3 = double.Parse(model[1, j]);
                    sum = 9 * 9 * number1 + 9 * number2 + number3;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sbbbb = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sbbbb.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sbbbb.ToString() == model[0, j])
                {
                    number4 = double.Parse(model[1, j]);
                    sum = 9 * 9 * 9 * number1 + 9 * 9 * number2 + 9 * number3 + number4;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sbbbbb = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sbbbbb.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sbbbbb.ToString() == model[0, j])
                {
                    number5 = double.Parse(model[1, j]);
                    sum = 9 * 9 * 9 * 9 * number1 + 9 * 9 * 9 * number2 + 9 * 9 * number3 + 9 * number4 + number5;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sbbbbbb = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sbbbbbb.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sbbbbbb.ToString() == model[0, j])
                {
                    number6 = double.Parse(model[1, j]);
                    sum = 9 * 9 * 9 * 9 * 9 * number1 + 9 * 9 * 9 * 9 * number2 + 9 * 9 * 9 * number3 + 9 * 9 * number4 + 9 * number5 + number6;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sb7 = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sb7.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb7.ToString() == model[0, j])
                {
                    number7 = double.Parse(model[1, j]);
                    sum = Math.Pow(9, 6) * number1 + Math.Pow(9, 5) * number2
                        + Math.Pow(9, 4) * number3 + Math.Pow(9, 3) * number4
                        + Math.Pow(9, 2) * number5 + Math.Pow(9, 1) * number6 + number7;
                    position = i;                  
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sb8 = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sb8.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb8.ToString() == model[0, j])
                {
                    number8 = double.Parse(model[1, j]);
                    sum = Math.Pow(9, 7) * number1
                        + Math.Pow(9, 6) * number2
                        + Math.Pow(9, 5) * number3
                        + Math.Pow(9, 4) * number4 
                        + Math.Pow(9, 3) * number5
                        + Math.Pow(9, 2) * number6
                        + Math.Pow(9, 1) * number7
                        + number8;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sb9 = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sb9.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb9.ToString() == model[0, j])
                {
                    number9 = double.Parse(model[1, j]);
                    sum = Math.Pow(9, 8) * number1
                        + Math.Pow(9, 7) * number2
                        + Math.Pow(9, 6) * number3
                        + Math.Pow(9, 5) * number4
                        + Math.Pow(9, 4) * number5
                        + Math.Pow(9, 3) * number6
                        + Math.Pow(9, 2) * number7
                        + Math.Pow(9, 1) * number8
                        + number9;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sb10 = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sb10.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb10.ToString() == model[0, j])
                {
                    number10 = double.Parse(model[1, j]);
                    sum = Math.Pow(9, 9) * number1
                        + Math.Pow(9, 8) * number2
                        + Math.Pow(9, 7) * number3
                        + Math.Pow(9, 6) * number4
                        + Math.Pow(9, 5) * number5
                        + Math.Pow(9, 4) * number6
                        + Math.Pow(9, 3) * number7
                        + Math.Pow(9, 2) * number8
                        + Math.Pow(9, 1) * number9
                        + number10;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sb11 = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sb11.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb11.ToString() == model[0, j])
                {
                    number11 = double.Parse(model[1, j]);

                    sum = Math.Pow(9, 10) * number1
                        + Math.Pow(9, 9) * number2
                        + Math.Pow(9, 8) * number3
                        + Math.Pow(9, 7) * number4
                        + Math.Pow(9, 6) * number5
                        + Math.Pow(9, 5) * number6
                        + Math.Pow(9, 4)* number7
                        + Math.Pow(9, 3) * number8
                        + Math.Pow(9, 2) * number9
                        + Math.Pow(9, 1) * number10
                        + Math.Pow(9, 0) * number11;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sb12 = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sb12.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb12.ToString() == model[0, j])
                {
                    number12 = double.Parse(model[1, j]);

                    sum = Math.Pow(9, 11) * number1
                        + Math.Pow(9, 10) * number2
                        + Math.Pow(9, 9) * number3
                        + Math.Pow(9, 8) * number4
                        + Math.Pow(9, 7) * number5
                        + Math.Pow(9, 6) * number6
                        + Math.Pow(9, 5) * number7
                        + Math.Pow(9, 4) * number8
                        + Math.Pow(9, 3) * number9
                        + Math.Pow(9, 2) * number10
                        + Math.Pow(9, 1) * number11
                        + number12;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sb13 = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sb13.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb13.ToString() == model[0, j])
                {
                    number13 = double.Parse(model[1, j]);

                    sum = Math.Pow(9, 12) * number1
                        + Math.Pow(9, 11) * number2
                        + Math.Pow(9, 10) * number3
                        + Math.Pow(9, 9) * number4
                        + Math.Pow(9, 8) * number5
                        + Math.Pow(9, 7) * number6
                        + Math.Pow(9, 6) * number7
                        + Math.Pow(9, 5) * number8
                        + Math.Pow(9, 4) * number9
                        + Math.Pow(9, 3) * number10
                        + Math.Pow(9, 2) * number11
                        + Math.Pow(9, 1) * number12
                        + Math.Pow(9, 0) * number13;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sb14 = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sb14.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb14.ToString() == model[0, j])
                {
                    number14 = double.Parse(model[1, j]);

                    sum = Math.Pow(9, 13) * number1
                        + Math.Pow(9, 12) * number2
                        + Math.Pow(9, 11) * number3
                        + Math.Pow(9, 10) * number4
                        + Math.Pow(9, 9) * number5
                        + Math.Pow(9, 8) * number6
                        + Math.Pow(9, 7) * number7
                        + Math.Pow(9, 6) * number8
                        + Math.Pow(9, 5) * number9
                        + Math.Pow(9, 4) * number10
                        + Math.Pow(9, 3) * number11
                        + Math.Pow(9, 2) * number12
                        + Math.Pow(9, 1) * number13
                        + Math.Pow(9, 0) * number14;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sb15 = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sb15.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb15.ToString() == model[0, j])
                {
                    number15 = double.Parse(model[1, j]);

                    sum = Math.Pow(9, 14) * number1
                        + Math.Pow(9, 13) * number2
                        + Math.Pow(9, 12) * number3
                        + Math.Pow(9, 11) * number4
                        + Math.Pow(9, 10) * number5
                        + Math.Pow(9, 9) * number6
                        + Math.Pow(9, 8) * number7
                        + Math.Pow(9, 7) * number8
                        + Math.Pow(9, 6) * number9
                        + Math.Pow(9, 5) * number10
                        + Math.Pow(9, 4) * number11
                        + Math.Pow(9, 3) * number12
                        + Math.Pow(9, 2) * number13
                        + Math.Pow(9, 1) * number14
                        + Math.Pow(9, 0) * number15;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sb16 = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sb16.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb16.ToString() == model[0, j])
                {
                    number16 = double.Parse(model[1, j]);

                    sum = Math.Pow(9, 15) * number1
                        + Math.Pow(9, 14) * number2
                        + Math.Pow(9, 13) * number3
                        + Math.Pow(9, 12) * number4
                        + Math.Pow(9, 11) * number5
                        + Math.Pow(9, 10) * number6
                        + Math.Pow(9, 9) * number7
                        + Math.Pow(9, 8) * number8
                        + Math.Pow(9, 7) * number9
                        + Math.Pow(9, 6) * number10
                        + Math.Pow(9, 5) * number11
                        + Math.Pow(9, 4) * number12
                        + Math.Pow(9, 3) * number13
                        + Math.Pow(9, 2) * number14
                        + Math.Pow(9, 1) * number15
                        + Math.Pow(9, 0) * number16;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sb17 = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sb17.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb17.ToString() == model[0, j])
                {
                    number17 = double.Parse(model[1, j]);

                    sum = Math.Pow(9, 16) * number1
                        + Math.Pow(9, 15) * number2
                        + Math.Pow(9, 14) * number3
                        + Math.Pow(9, 13) * number4
                        + Math.Pow(9, 12) * number5
                        + Math.Pow(9, 11) * number6
                        + Math.Pow(9, 10) * number7
                        + Math.Pow(9, 9) * number8
                        + Math.Pow(9, 8) * number9
                        + Math.Pow(9, 7) * number10
                        + Math.Pow(9, 6) * number11
                        + Math.Pow(9, 5) * number12
                        + Math.Pow(9, 4) * number13
                        + Math.Pow(9, 3) * number14
                        + Math.Pow(9, 2) * number15
                        + Math.Pow(9, 1) * number16
                        + Math.Pow(9, 0) * number17;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sb18 = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sb18.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb18.ToString() == model[0, j])
                {
                    number18 = double.Parse(model[1, j]);

                    sum = Math.Pow(9, 17) * number1
                        + Math.Pow(9, 16) * number2
                        + Math.Pow(9, 15) * number3
                        + Math.Pow(9, 14) * number4
                        + Math.Pow(9, 13) * number5
                        + Math.Pow(9, 12) * number6
                        + Math.Pow(9, 11) * number7
                        + Math.Pow(9, 10) * number8
                        + Math.Pow(9, 9) * number9
                        + Math.Pow(9, 8) * number10
                        + Math.Pow(9, 7) * number11
                        + Math.Pow(9, 6) * number12
                        + Math.Pow(9, 5) * number13
                        + Math.Pow(9, 4) * number14
                        + Math.Pow(9, 3) * number15
                        + Math.Pow(9, 2) * number16
                        + Math.Pow(9, 1) * number17
                        + Math.Pow(9, 0) * number18;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sb19 = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sb19.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb19.ToString() == model[0, j])
                {
                    number19 = double.Parse(model[1, j]);

                    sum = Math.Pow(9, 18) * number1
                        + Math.Pow(9, 17) * number2
                        + Math.Pow(9, 16) * number3
                        + Math.Pow(9, 15) * number4
                        + Math.Pow(9, 14) * number5
                        + Math.Pow(9, 13) * number6
                        + Math.Pow(9, 12) * number7
                        + Math.Pow(9, 11) * number8
                        + Math.Pow(9, 10) * number9
                        + Math.Pow(9, 9) * number10
                        + Math.Pow(9, 8) * number11
                        + Math.Pow(9, 7) * number12
                        + Math.Pow(9, 6) * number13
                        + Math.Pow(9, 5) * number14
                        + Math.Pow(9, 4) * number15
                        + Math.Pow(9, 3) * number16
                        + Math.Pow(9, 2) * number17
                        + Math.Pow(9, 1) * number18
                        + number19;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }

        StringBuilder sb20 = new StringBuilder();
        for (int i = position + 1; i < input.Length; i++)
        {
            sb20.Append(input[i]);
            for (int j = 0; j < 9; j++)
            {
                if (sb20.ToString() == model[0, j])
                {
                    number20 = double.Parse(model[1, j]);

                    sum = Math.Pow(9, 19) * number1
                        + Math.Pow(9, 18) * number2
                        + Math.Pow(9, 17) * number3
                        + Math.Pow(9, 16) * number4
                        + Math.Pow(9, 15) * number5
                        + Math.Pow(9, 14) * number6
                        + Math.Pow(9, 13) * number7
                        + Math.Pow(9, 12) * number8
                        + Math.Pow(9, 11) * number9
                        + Math.Pow(9, 10) * number10
                        + Math.Pow(9, 9) * number11
                        + Math.Pow(9, 8) * number12
                        + Math.Pow(9, 7) * number13
                        + Math.Pow(9, 6) * number14
                        + Math.Pow(9, 5) * number15
                        + Math.Pow(9, 4) * number16
                        + Math.Pow(9, 3) * number17
                        + Math.Pow(9, 2) * number18
                        + Math.Pow(9, 1) * number19
                        + number20;
                    position = i;
                }
                else
                {
                    continue;
                }
            }
        }
        Console.WriteLine(sum);
    }
}