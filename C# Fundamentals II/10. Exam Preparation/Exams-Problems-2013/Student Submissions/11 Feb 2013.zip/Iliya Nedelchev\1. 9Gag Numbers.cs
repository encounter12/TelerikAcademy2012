using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9gag
{
    class Program
    {
        static void Main(string[] args)
        {
            string nineGagNumber = Console.ReadLine();
            ulong sum = 0;
            int count = 0;
            string[] arrCode ={
                              "-!",
                              "**",
                              "!!!",
                              "&&",
                              "&-",
                              "!-",
                              "*!!!",
                              "&*!",
                              "!!**!-"

                          };
            List<ulong> numbers=new List<ulong>();
            int countOfnumber=0;
            StringBuilder number = new StringBuilder();
            do
            {
                number.Append(nineGagNumber.ToCharArray(count, 1));
                for (uint i = 0; i < 9; i++)
                {
                    if (arrCode[i] == number.ToString())
                    {
                        number.Clear();
                        numbers.Add(i);
                        for (int j = 0; j < countOfnumber; j++)
                        {
                            numbers[j] = numbers[j] * 9;
                        }
                        countOfnumber++;
                        break;
                    }
                }
                count++;
            }
            while (count < nineGagNumber.Length);
            foreach (var item in numbers)
                sum += item;
            Console.WriteLine(sum);
        }
    }
}