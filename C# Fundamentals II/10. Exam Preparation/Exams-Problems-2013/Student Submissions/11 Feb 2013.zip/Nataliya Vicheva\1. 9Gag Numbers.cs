using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GagStyle
{
    class Program
    {
        static void Main()
        {
            string a = "-!";
            string b = "**";
            string c = "!!!";
            string d = "&&";
            string e = "&-";
            string f = "!-";
            string g = "*!!!";
            string h = "&*!";
            string i = "!!**!-";
            string GagNum = Console.ReadLine();
            if (GagNum == a)
            {
                Console.WriteLine(0);
            }
            if (GagNum == b)
            {
                Console.WriteLine(1);
            }
            if (GagNum == c)
            {
                Console.WriteLine(2);
            }
            if (GagNum == d)
            {
                Console.WriteLine(3);
            }
            if (GagNum == e)
            {
                Console.WriteLine(4);
            }
            if (GagNum == f)
            {
                Console.WriteLine(5);
            } if (GagNum == g)
            {
                Console.WriteLine(6);
            }
            if (GagNum == h)
            {
                Console.WriteLine(7);
            }
            if (GagNum == i)
            {
                Console.WriteLine(8);
            }
        }
    }
}