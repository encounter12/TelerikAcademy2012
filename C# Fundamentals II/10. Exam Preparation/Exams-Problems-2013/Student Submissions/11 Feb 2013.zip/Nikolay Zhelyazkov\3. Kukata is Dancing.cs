using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kukata
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append(Console.ReadLine());
                if (sb.Length % 3 == 0)
                {
                    Console.WriteLine("GREEN");
                }
            }
        }
    }
}
