using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1_SEC
{
    class Program
    {
        static void Main(string[] args)
        {
            string gag = Console.ReadLine();

            int[] tempValues = new int[90];
            int counter = 0;
            while (gag.Length > 0)
            {



                if (gag.Length >= 2 && gag[0] == '-' && gag[1] == '!')
                {
                    tempValues[counter] = 0;
                    counter++;
                    gag = gag.Remove(0, 2);
                }
                if (gag.Length > 0 && gag[0] == '*' && gag[1] == '*')
                {
                    tempValues[counter] = 1;
                    counter++;
                    gag = gag.Remove(0, 2);
                }
                if (gag.Length > 0 && gag[0] == '&' && gag[1] == '&')
                {
                    tempValues[counter] = 3;
                    counter++;
                    gag = gag.Remove(0, 2);
                }
                if (gag.Length > 0 && gag[0] == '&' && gag[1] == '-')
                {
                    tempValues[counter] = 4;
                    counter++;
                    gag = gag.Remove(0, 2);
                }
                if (gag.Length > 0 && gag[0] == '!' && gag[1] == '-')
                {
                    tempValues[counter] = 5;
                    counter++;
                    gag = gag.Remove(0, 2);
                }
                if (gag.Length >= 3 && gag[0] == '!' && gag[1] == '!' && gag[2] == '!')
                {
                    tempValues[counter] = 2;
                    counter++;
                    gag = gag.Remove(0, 3);
                }
                if (gag.Length >= 3 && gag[0] == '&' && gag[1] == '*' && gag[2] == '!')
                {
                    tempValues[counter] = 7;
                    counter++;
                    gag = gag.Remove(0, 3);
                }
                if (gag.Length >= 4 && gag[0] == '*' && gag[1] == '!' && gag[2] == '!' && gag[3] == '!')
                {
                    tempValues[counter] = 6;
                    counter++;
                    gag = gag.Remove(0, 4);
                }
                if (gag.Length >= 6 && gag[0] == '!' && gag[1] == '!' && gag[2] == '*' && gag[3] == '*' && gag[4] == '!' && gag[5] == '-')
                {
                    tempValues[counter] = 8;
                    counter++;
                    gag = gag.Remove(0, 6);
                }
            }
            int value = 0;
            int c2 = counter;
            int multiplyer = 1;
            while (c2>1)
            {
                multiplyer *= 9;
                c2--;

            }
            for (int i = 0; i < counter + 1; i++)
            {
                value = value + tempValues[i] * multiplyer;
                multiplyer = multiplyer / 9;
            }
            Console.WriteLine(value);
        }
    }
}
