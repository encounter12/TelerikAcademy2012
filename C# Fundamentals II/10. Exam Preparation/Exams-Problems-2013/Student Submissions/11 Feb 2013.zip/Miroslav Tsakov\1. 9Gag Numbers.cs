using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

class Ex2
{
    static void Main()
    {
        string input = Console.ReadLine();
        string[] arr = new string[10];
        arr[0] = "-!";
        arr[1] = "**";
        arr[2] = "!!!";
        arr[3] = "&&";
        arr[4] = "&-";
        arr[5] = "!-";
        arr[6] = "*!!!";
        arr[7] = "&*!";
        arr[8] = "!!**!-";
        List<string> data = arr.ToList();
        string temp = string.Empty;
        List<int> res = new List<int>();
        for (int i = 0; i < input.Length; i++)
        {
            string tempOne = input[i].ToString();
            if (i + 1 <= input.Length)
            {
                temp += tempOne;
                int index = data.IndexOf(temp);
                if (index != -1)
                {
                    res.Add(index);
                    temp = string.Empty;
                }
            }
        }
        double sum = 0;
        double times = res.Count - 1;
        double var = 9;
        for (int i = 0; i < res.Count; i++)
        {
            sum += res[i] * Math.Pow(var, times);
            times--;
        }
        BigInteger result = (BigInteger)sum;
        Console.WriteLine(result);
    }
}