using System;
using System.Text;
using System.Numerics;

class GagNumbers
{
    static void Main()
    {
        string[] strNumbers= {"-!", "**", "!!!", "&&", "&-","!-", "*!!!","&*!", "!!**!-"};
        string strInputText = Console.ReadLine();
        StringBuilder converted = new StringBuilder();

        while (strInputText != "")
        {
            for (int i = 0; i < strNumbers.Length; i++)
            {
                if (strNumbers[i].Length <= strInputText.Length && strNumbers[i].Equals(strInputText.Substring(0, strNumbers[i].Length)))
                {
                    converted.Append(i);
                    strInputText = strInputText.Substring(strNumbers[i].Length);
                }
            }         
        }

        BigInteger replacedStr = BigInteger.Parse(converted.ToString());
        //Console.WriteLine(replacedStr);
        BigInteger result = 0;
        int count = 0;

        while (replacedStr > 0)
        {
            result = result + (replacedStr % 10) * (BigInteger)Math.Pow(9, count);
            replacedStr = replacedStr / 10;
            count++;
        }

        Console.WriteLine(result);

    }
}   
