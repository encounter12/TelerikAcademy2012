using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Array;

namespace _9Gag_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Enter a 9Gag-style-number: ");

            string zero = "-!";
            string one = "**";
            string two = "!!!";
            string tree = "&&";
            string four = "&-";
            string five = "!-";
            string six = "*!!!";
            string seven = "&*!";
            string eight = "!!**!-";

            string[] numberNineGag = new string[9] {
                "-!", "**", "!!!", "&&", "&-", "!-", "!!!", "&*!", "!!**!-"
            };

            //while (true)
           //{
                string numberGag = Console.ReadLine();

                bool result = numberGag.Equals(zero, StringComparison.Ordinal);
                bool resultOne = numberGag.Equals(one, StringComparison.Ordinal);
                bool resultTwo = numberGag.Equals(two, StringComparison.Ordinal);
                bool resultTree = numberGag.Equals(tree, StringComparison.Ordinal);
                bool resultFour = numberGag.Equals(four, StringComparison.Ordinal);
                bool resultFive = numberGag.Equals(five, StringComparison.Ordinal);
                bool resultSix = numberGag.Equals(six, StringComparison.Ordinal);
                bool resultSeven = numberGag.Equals(seven, StringComparison.Ordinal);
                bool resultEight = numberGag.Equals(eight, StringComparison.Ordinal);

                if (result == true)
                {
                    Console.WriteLine("0");
                }

                if (resultOne == true)
                {
                    Console.WriteLine("1");
                }
                if (resultTwo == true)
                {
                    Console.WriteLine("2");
                }
                if (resultTree == true)
                {
                    Console.WriteLine("3");
                }
                if (resultFour == true)
                {
                    Console.WriteLine("4");
                }
                if (resultFive == true)
                {
                    Console.WriteLine("5");
                }
                if (resultSix == true)
                {
                    Console.WriteLine("6");
                }
                if (resultSeven == true)
                {
                    Console.WriteLine("7");
                }
                if (resultEight == true)
                {
                    Console.WriteLine("8");
                }


                if (result == false || resultOne == false || resultTwo == false || resultTree == false ||
                    resultFour == false || resultFive == false || resultSix == false || resultSeven == false || resultEight == false)
                {
                    string[] numberGagSymbols = numberGag.Split(new char[] { ' ' }, 2);
                    int index;

                    for (index = 0; index <= numberGagSymbols.Lenght; index++)
                    {
                        if (numberGagSymbols[index] == " ")
                        {
                            break;
                        }

                        if (numberGag == numberNineGag[index])
                        {
                            numberGag = numberNineGag[index].ToString();
                        }
                    }
                 }


            

            //Calculate parseCalculator = new Calculate();
            //parseCalculator.ExecuteParse(numberNineGag);
            //Console.Write(parseCalculator.GetOutputResult());


        //class Calculate
        //{
        //    readonly StringBuilder output;
        //    string[] numberNineGag;

        //    public Calculate()
        //    {
        //        output = new StringBuilder();
        //        numberNineGag = new string[0];
        //    }


        //    public void ExecuteParse(string[] numberNineGag) {
        //        this.numberNineGag = numberNineGag;

        //        while (true)
        //        {

        //        }

        //    }

        }
    }
}
