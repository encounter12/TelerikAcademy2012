using System;
using System.Collections.Generic;

class SpecialValue
{
    static int[][] Grid;
    static bool[][] GridVisited;

    //
    static void Main()
    {
        int N = int.Parse(Console.ReadLine());

        Grid = new int[N][];
        GridVisited = new bool[N][];

        for (int i = 0; i < N; i++)
        {
            string[] values = Console.ReadLine().Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);

            Grid[i] = new int[values.Length];
            GridVisited[i] = new bool[values.Length];

            for (int j = 0; j < values.Length; j++)
            {
                Grid[i][j] = int.Parse(values[j]);
            }
        }

        int max = -1;
        for (int i = 0; i < Grid[0].Length; i++)
        {
            // Reset visited
            for (int j = 0; j < Grid.Length; j++)
            {
                GridVisited[j] = new bool[Grid[j].Length];
                /*
                for (int k = 0; k < Grid[j].Length; k++)
                {
                    GridVisited[j][k] = false;
                }
                 */
            }

            // Walk
            int res = WalkPath(0, i);
            if (res > max)
            {
                max = res;
            }
        }

        Console.WriteLine(max);

    }

    //
    static int WalkPath(int row, int col, int sum = 0)
    {

        if (GridVisited[row][col])
        {
            return -1;
        }

        GridVisited[row][col] = true;
        sum += 1;

        if (Grid[row][col] < 0)
        {
            return sum + (-Grid[row][col]);
        }

        int nextRow = row < Grid.Length - 1 ? row + 1 : 0;
        //int nextCol = Grid[row][col] < 0 ? (-Grid[row][col]) : Grid[row][col];

        return WalkPath(nextRow, Grid[row][col], sum);
    }
}
