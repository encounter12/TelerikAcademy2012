using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeInOne
{
    class Program
    {
        static void Main(string[] args)
        {
            string blackJack = Console.ReadLine();
            string cakes = Console.ReadLine();
            int friends = int.Parse(Console.ReadLine());

            string bearCoins = Console.ReadLine();


            int position = BlackJackWinner(blackJack);
            Console.WriteLine(position);

            int cakeBite = CakeBiteForMe(cakes, friends);
            Console.WriteLine(cakeBite);

            int counter = BuyBeer(bearCoins);
            Console.WriteLine(counter);

            Console.WriteLine();
            Console.WriteLine();
        }

        private static int BuyBeer(string bearCoins)
        {
            string[] coins = bearCoins.Split(' ');
            int g1 = int.Parse(coins[0]);
            int s1 = int.Parse(coins[1]);
            int b1 = int.Parse(coins[2]);

            int g2 = int.Parse(coins[3]);
            int s2 = int.Parse(coins[4]);
            int b2 = int.Parse(coins[5]);
            int counter = 0;
            while (true)
            {
                if (b1 < b2)
                {
                    if (s1 != 0)
                    {
                        s1--;
                        b1 += 9;
                        counter++;
                    }
                    else
                    {
                        if (g1 != 0)
                        {
                            g1--;
                            s1 += 9;
                            counter++;
                        }
                    }
                }
                else
                {
                    b1 -= b2;
                    break;
                }
            }

            while (true)
            {
                if (s1 < s2)
                {
                    if (b1 >= 11)
                    {
                        b1 -= 11;
                        s1++;
                        counter++;
                    }
                    else
                    {
                        if (g1 != 0)
                        {
                            g1--;
                            s1 += 9;
                            counter++;
                        }
                    }
                }
                else
                {
                    s1 -= s2;
                    break;
                }
            }
            while (g1 < g2)
            {
                if (s1 >= 11)
                {
                    s1 -= 11;
                    g1++;
                    counter++;
                }
                else
                {
                    if (b1 >= 11)
                    {
                        b1 -= 11;
                        s1++;
                        counter++;
                    }
                }
            }

            return counter;
        }

        private static int CakeBiteForMe(string cakes, int friends)
        {
            string[] bites = cakes.Split(',');
            List<int> friendsBites = new List<int>(bites.Length);
            for (int i = 0; i < bites.Length; i++)
            {
                friendsBites.Add(int.Parse(bites[i]));
            }

            friendsBites.Sort();
            friendsBites.Reverse();
            int myCakes = 0;
            for (int i = 0; i < friendsBites.Count; i++)
            {
                if (i % (friends + 1) == 0)
                {
                    myCakes += friendsBites[i];
                }
            }
            return myCakes;
        }

        private static int BlackJackWinner(string blackJack)
        {
            string[] player = blackJack.Split(',');
            int[] playerCardSum = new int[player.Length];
            for (int i = 0; i < player.Length; i++)
            {
                playerCardSum[i] = int.Parse(player[i]);
            }
            int bestSum = -1;
            int playerPos = 0;
            for (int i = 0; i < playerCardSum.Length; i++)
            {
                if (playerCardSum[i] <= 21)
                {
                    if (playerCardSum[i] > bestSum)
                    {
                        bestSum = playerCardSum[i];
                        playerPos = i;
                    }
                }
            }
            int counter = 0;
            for (int i = 0; i < playerCardSum.Length; i++)
            {
                if (playerCardSum[i] == bestSum)
                {
                    counter++;
                }
            }
            if (counter != 1)
            {
                return -1;
            }
            return playerPos;
        }
    }
}
