using System;

class ExamProblemOne
{
    static void Main()
    {
        string inputNum = Console.ReadLine();
        int currentIndex = 0, outputIndex = 0;
        ulong myPow = 1, outputDecimal;
        int[] outputNum = new int[inputNum.Length];
        char[] nineGagChar = inputNum.ToCharArray();
        while (currentIndex < inputNum.Length)
        {
            if (nineGagChar[currentIndex] == '!')
            {
                currentIndex++;
                if (nineGagChar[currentIndex] == '!')
                {
                    currentIndex++;
                    if (nineGagChar[currentIndex] == '!')
                    {
                        currentIndex++;
                        outputNum[outputIndex] = 2;
                        outputIndex++;
                    }
                    else
                    {
                        currentIndex += 4;
                        outputNum[outputIndex] = 8;
                        outputIndex++;
                    }
                }
                else
                {
                    currentIndex++;
                    outputNum[outputIndex] = 5;
                    outputIndex++;
                }
            }
            else if (nineGagChar[currentIndex] =='*')
            {
                currentIndex++;
                if (nineGagChar[currentIndex] == '*')
                {
                    currentIndex++;
                    outputNum[outputIndex] = 1;
                    outputIndex++;
                }
                else
                {
                    currentIndex += 3;
                    outputNum[outputIndex] = 6;
                    outputIndex++;
                }
            }
            else if (nineGagChar[currentIndex] == '&')
            {
                currentIndex++;
                if (nineGagChar[currentIndex] == '&')
                {
                    currentIndex++;
                    outputNum[outputIndex] = 3;
                    outputIndex++;
                }
                else if (nineGagChar[currentIndex] == '-')
                {
                    currentIndex++;
                    outputNum[outputIndex] = 4;
                    outputIndex++;
                }
                else
                {
                    currentIndex += 2;
                    outputNum[outputIndex] = 7;
                    outputIndex++;
                }
            }
            else
            {
                currentIndex += 2;
                outputNum[outputIndex] = 0;
                outputIndex++;
            }
        }
        int[] workArr = new int[outputIndex];
        for (int i = 0; i < workArr.Length; i++)
        {
            workArr[i] = outputNum[i];
        }
        Array.Reverse(workArr);
        outputDecimal = (ulong)workArr[0];
        for (int i = 1; i < outputIndex; i++)
        {
            myPow *= 9;
            outputDecimal += (ulong)workArr[i] * myPow;
        }

        Console.WriteLine(outputDecimal);
    }
}