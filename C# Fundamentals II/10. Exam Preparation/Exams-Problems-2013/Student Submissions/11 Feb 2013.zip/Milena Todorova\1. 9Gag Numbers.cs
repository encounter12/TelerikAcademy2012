using System;
using System.Text;

class GagNumbers
{
    static void Main()
    {
        string gagNumbers = Console.ReadLine();
        //int[] numbers = new int[20];
        int i = 0;
        StringBuilder sb = new StringBuilder();
        while (gagNumbers != "")
        {

            if (gagNumbers.EndsWith("!!**!-"))
            {
                gagNumbers = gagNumbers.Substring(0, gagNumbers.LastIndexOf("!!**!-"));
                sb.Insert(0, "8");
                break;
            }


            else if (gagNumbers.EndsWith("&*!"))
            {
                gagNumbers = gagNumbers.Substring(0, gagNumbers.LastIndexOf("&*!"));
                sb.Insert(0, "7");
            }

            else if (gagNumbers.EndsWith("*!!!"))
            {
                gagNumbers = gagNumbers.Substring(0, gagNumbers.LastIndexOf("*!!!"));
                sb.Insert(0, "6");
            }

            else if (gagNumbers.EndsWith("!-"))
            {
                gagNumbers = gagNumbers.Substring(0, gagNumbers.LastIndexOf("!-"));
                sb.Insert(0, "5");
            }


            else if (gagNumbers.EndsWith("&-"))
            {
                gagNumbers = gagNumbers.Substring(0, gagNumbers.LastIndexOf("&-"));
                sb.Insert(0, "4");
            }

            else if (gagNumbers.EndsWith("&&"))
            {
                gagNumbers = gagNumbers.Substring(0, gagNumbers.LastIndexOf("&&"));
                sb.Insert(0, "3");
            }

            else if (gagNumbers.EndsWith("!!!"))
            {
                gagNumbers = gagNumbers.Substring(0, gagNumbers.LastIndexOf("!!!"));
                sb.Insert(0, "2");
            }

            else if (gagNumbers.EndsWith("**"))
            {
                gagNumbers = gagNumbers.Substring(0, gagNumbers.LastIndexOf("**"));
                sb.Insert(0, "1");
            }

            else if (gagNumbers.EndsWith("-!"))
            {
                gagNumbers = gagNumbers.Substring(0, gagNumbers.LastIndexOf("-!"));
                sb.Insert(0, "0");
            }
            i++;
        }

        int decimalNumber = 0;

        string strNum = sb.ToString();
        int nineNum = int.Parse(strNum);


        int count = strNum.Length-1;

        int n = 0;
        for (int m = 0; m < strNum.Length; m++)
        {
            if (m>=0)
            {

                n = int.Parse(Convert.ToString(strNum[m]));
            }
            decimalNumber = decimalNumber + n * (int)(Math.Pow(9, count));
            count--;
        }

        Console.WriteLine(decimalNumber);
    }
}
