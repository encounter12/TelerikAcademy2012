using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CSharpSecondPart
{
    class Program
    {
        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            StringBuilder digits = new StringBuilder();
            StringBuilder currentDigit = new StringBuilder();
            char ch;
            for(int i=0;i<line.Length;i++)
            {
                ch = line[i];
                currentDigit.Append(ch);
                if (isGagDigit(currentDigit.ToString()))
                {
                    digits.Append(getDigit(currentDigit.ToString()));
                    currentDigit = new StringBuilder();
                }
            }
            
            Console.WriteLine(toDecimal(digits.ToString()));
        }

        static int getDigit(string str)
        {
            if (str.Equals("-!"))
            {
                return 0;
            }

            else if (str.Equals("**"))
            {
                return 1;
            }
            else if (str.Equals("!!!"))
            {
                return 2;
            }
            else if (str.Equals("&&"))
            {
                return 3;
            }
            else if (str.Equals("&-"))
            {
                return 4;
            }
            else if (str.Equals("!-"))
            {
                return 5;
            }
            else if (str.Equals("*!!!"))
            {
                return 6;
            }
            else if (str.Equals("&*!"))
            {
                return 7;
            }
            else if (str.Equals("!!**!-"))
            {
                return 8;
            }
            else
            {
                return -1;
            }
        }

        static bool isGagDigit(string str)
        {
            if (str.Equals("-!"))
            {
                return true;
            }

            else if (str.Equals("**"))
            {
                return true;
            }
            else if (str.Equals("!!!"))
            {
                return true;
            }
            else if (str.Equals("&&"))
            {
                return true;
            }
            else if (str.Equals("&-"))
            {
                return true;
            }
            else if (str.Equals("!-"))
            {
                return true;
            }
            else if (str.Equals("*!!!"))
            {
                return true;
            }
            else if (str.Equals("&*!"))
            {
                return true;
            }
            else if (str.Equals("!!**!-"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        static BigInteger toDecimal(string str)
        {
            BigInteger result = 0;
            BigInteger multiplier = 1;
            int digitBase=9;
            BigInteger number = BigInteger.Parse(str);
            while (number > 0)
            {
                int currentDigit =(int)((BigInteger)number % 10);
                result += currentDigit * multiplier;
                multiplier*=digitBase;
                number = number / 10;
            }
            return result;
        }

    }
}
