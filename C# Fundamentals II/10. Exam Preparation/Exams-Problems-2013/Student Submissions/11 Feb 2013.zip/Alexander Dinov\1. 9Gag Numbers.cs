using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;

class task1
{
    static void Main()
    {

        Dictionary<string, int> gag = new Dictionary<string, int>();
        gag.Add("-!", 0);
        gag.Add("**", 1);
        gag.Add("!!!", 2);
        gag.Add("&&", 3);
        gag.Add("&-", 4);
        gag.Add("!-", 5);
        gag.Add("*!!!", 6);
        gag.Add("&*!", 7);
        gag.Add("!!**!-", 8);
        string input = Console.ReadLine();
        List<BigInteger> numbs = new List<BigInteger>();
        StringBuilder buffer = new StringBuilder();
        int count;
        for (int i = 0; i < input.Length; i++)
        {
            buffer.Append(input[i]);
            if (gag.TryGetValue(buffer.ToString(), out count))
            {
                numbs.Add(count);
                buffer.Clear();
            }
        }
        BigInteger sum = 0;
        long counter =0;
        
        for (int i = numbs.Count-1; i >= 0; i--)
        {
            sum += numbs[i] * (BigInteger)Math.Pow(9,counter);
            counter++;
        }
        Console.WriteLine(sum);
    }

}
