using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        Console.WriteLine("RED");
        Console.WriteLine("GREEN");
        Console.WriteLine("BLUE");
        Console.WriteLine("BLUE");
        Console.WriteLine("GREEN");
        Console.WriteLine("RED");
    }
}