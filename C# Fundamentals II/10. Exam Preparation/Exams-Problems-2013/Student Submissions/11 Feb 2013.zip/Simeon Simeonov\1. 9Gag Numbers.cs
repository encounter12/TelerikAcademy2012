using System;

//{}
//[]

class Task1
{
    static int [] TranslateNumber(string number, out int count)
    {
        int[] result = new int[20];
        int index = 0;
        while  (number.Length > 0)
        {
            switch (number[0])
	        {
                case '-': //0
                    result[index] = 0;
                    number = number.Substring(2);
                    break;
                case '*':
                    if (number[1] == '*') //1
                    {
                        result[index] = 1;
                        number = number.Substring(2);
                    }
                    else //6
                    {
                        result[index] = 6;
                        number = number.Substring(4);
                    }
                    break;
                case '&':
                    if (number[1] == '&') //3
                    {
                        result[index] = 3;
                        number = number.Substring(2);
                    }
                    else if (number[1] == '-') //4
                    {
                        result[index] = 4;
                        number = number.Substring(2);
                    }
                    else //7
                    {
                        result[index] = 7;
                        number = number.Substring(3);
                    }
                    break;
                case '!':
                    if (number[1] == '-') //5
                    {
                        result[index] = 5;
                        number = number.Substring(2);
                    }
                    else if (number[2] == '!') //2
                    {
                        result[index] = 2;
                        number = number.Substring(3);
                    }
                    else //8
                    {
                        result[index] = 8;
                        number = number.Substring(6);
                    }
                    break;
            }
            index++;
        }

        count = index;
        return result;
    }


    static long ToDecimal(int[] arrNumber, int count)
    {
        long result = 0;
        long pow = 1;
        for (int i = count-1; i >= 0; i--)
        {
            result += arrNumber[i] * pow;
            pow *= 9;
        }

        return result;
    }
    static void Main()
    {
        string inputNumber = Console.ReadLine();

        int count = 0;
        int[] arrNumber = TranslateNumber(inputNumber, out count);

        long resultNumber = ToDecimal(arrNumber, count);
        Console.WriteLine(resultNumber);
    }
}
