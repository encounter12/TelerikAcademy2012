using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeInOne
{
    class Program
    {
        static void Main(string[] args)
        {
            String earnedPointsAsString = Console.ReadLine();
            String[] earnedPointsParts = earnedPointsAsString.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            int[] earnedPoints = earnedPointsParts.Select(x => int.Parse(x)).ToArray();
            int count = 0;
            int bjResult;
            bjResult = blackJack(earnedPoints, count);
            Console.WriteLine(bjResult);
             
        }

        public static int blackJack(int[] earnedPoints, int count)
        {
           
            for (int i = 0; i < earnedPoints.Length; i++)
            {
                if (earnedPoints[i] > 21)
                {
                    continue;
                }
                else
                {
                    count = i + 1;
                    
                }

                
            }
            return count;
        }
    }
}
