using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1
{
    class Program
    {
        static void Main(string[] args)
        {
            int moveCount = int.Parse(Console.ReadLine());

            string[] colors =  {            "RED",  "BLUE",  "RED", 
                                           "BLUE", "GREEN", "BLUE", 
                                           "RED",   "BLUE", "RED" };

            string[] allMoves = new string[moveCount];


            for (int i = 0; i < moveCount; i++)
            {
                allMoves[i] = Console.ReadLine();
            }

            for (int i = 0; i < allMoves.Length; i++)
            {
                int direction = 0;
                int currentPos = 4;
                string moves = allMoves[i];

                for (int j = 0; j < moves.Length; j++)
                {
                    if (moves[j] == 'L')
                    {
                        if (direction == -3)
                        {
                            direction = 1;
                        }
                        direction--;
                    }
                    if (moves[j] == 'R')
                    {
                        if (direction == 3)
                        {
                            direction = -1;
                        }
                        direction++;
                    }
                    if (moves[j] == 'W')
                    {
                        switch (currentPos)
                        {
                            case 0:
                                if (direction == 0)//UP
                                {
                                    currentPos = 3;
                                    direction = 0;
                                }
                                if (direction == 1 || direction == -3)//RIGHT
                                {
                                    currentPos = 1;
                                    direction = 1;
                                }
                                if (direction == 2 || direction == -2)//DOWN
                                {
                                    currentPos = 6;
                                    direction = 2;
                                }
                                if (direction == 3 || direction == -1)//LEFT
                                {
                                    currentPos = 2;
                                    direction = 3;
                                }
                                break;
                            case 1:
                                if (direction == 0)                  //UP
                                {
                                    currentPos = 4;
                                    direction = 0;
                                }
                                if (direction == 1 || direction == -3)//RIGHT
                                {
                                    currentPos = 2;
                                    direction = 1;
                                }
                                if (direction == 2 || direction == -2)//DOWN
                                {
                                    currentPos = 7;
                                    direction = 2;
                                }
                                if (direction == 3 || direction == -1)//LEFT
                                {
                                    currentPos = 0;
                                    direction = 3;
                                }
                                break;
                            case 2:
                                if (direction == 0)                  //UP
                                {
                                    currentPos = 5;
                                    direction = 0;
                                }
                                if (direction == 1 || direction == -3)//RIGHT
                                {
                                    currentPos = 0;
                                    direction = 1;
                                }
                                if (direction == 2 || direction == -2)//DOWN
                                {
                                    currentPos = 8;
                                    direction = 2;
                                }
                                if (direction == 3 || direction == -1)//LEFT
                                {
                                    currentPos = 1;
                                    direction = 3;
                                }
                                break;
                            case 3:
                                if (direction == 0)                  //UP
                                {
                                    currentPos = 6;
                                    direction = 0;
                                }
                                if (direction == 1 || direction == -3)//RIGHT
                                {
                                    currentPos = 4;
                                    direction = 1;
                                }
                                if (direction == 2 || direction == -2)//DOWN
                                {
                                    currentPos = 0;
                                    direction = 2;
                                }
                                if (direction == 3 || direction == -1)//LEFT
                                {
                                    currentPos = 5;
                                    direction = 3;
                                }
                                break;
                            case 4:
                                if (direction == 0)                  //UP
                                {
                                    currentPos = 7;
                                    direction = 0;
                                }
                                if (direction == 1 || direction == -3)//RIGHT
                                {
                                    currentPos = 5;
                                    direction = 1;
                                }
                                if (direction == 2 || direction == -2)//DOWN
                                {
                                    currentPos = 1;
                                    direction = 2;
                                }
                                if (direction == 3 || direction == -1)//LEFT
                                {
                                    currentPos = 3;
                                    direction = 3;
                                }
                                break;
                            case 5:
                                if (direction == 0)                  //UP
                                {
                                    currentPos = 8;
                                    direction = 0;
                                }
                                if (direction == 1 || direction == -3)//RIGHT
                                {
                                    currentPos = 3;
                                    direction = 1;
                                }
                                if (direction == 2 || direction == -2)//DOWN
                                {
                                    currentPos = 2;
                                    direction = 2;
                                }
                                if (direction == 3 || direction == -1)//LEFT
                                {
                                    currentPos = 4;
                                    direction = 3;
                                }
                                break;
                            case 6:
                                if (direction == 0)                  //UP
                                {
                                    currentPos = 0;
                                    direction = 0;
                                }
                                if (direction == 1 || direction == -3)//RIGHT
                                {
                                    currentPos = 7;
                                    direction = 1;
                                }
                                if (direction == 2 || direction == -2)//DOWN
                                {
                                    currentPos = 3;
                                    direction = 2;
                                }
                                if (direction == 3 || direction == -1)//LEFT
                                {
                                    currentPos = 8;
                                    direction = 3;
                                }
                                break;
                            case 7:
                                if (direction == 0)                  //UP
                                {
                                    currentPos = 1;
                                    direction = 0;
                                }
                                if (direction == 1 || direction == -3)//RIGHT
                                {
                                    currentPos = 8;
                                    direction = 1;
                                }
                                if (direction == 2 || direction == -2)//DOWN
                                {
                                    currentPos = 4;
                                    direction = 2;
                                }
                                if (direction == 3 || direction == -1)//LEFT
                                {
                                    currentPos = 6;
                                    direction = 3;
                                }
                                break;
                            case 8:
                                if (direction == 0)                  //UP
                                {
                                    currentPos = 2;
                                    direction = 0;
                                }
                                if (direction == 1 || direction == -3)//RIGHT
                                {
                                    currentPos = 6;
                                    direction = 1;
                                }
                                if (direction == 2 || direction == -2)//DOWN
                                {
                                    currentPos = 5;
                                    direction = 2;
                                }
                                if (direction == 3 || direction == -1)//LEFT
                                {
                                    currentPos = 7;
                                    direction = 3;
                                }
                                break;
                            default: break;
                        }

                    }



                }


                Console.WriteLine(colors[currentPos]);
            }
        }
    }
}
