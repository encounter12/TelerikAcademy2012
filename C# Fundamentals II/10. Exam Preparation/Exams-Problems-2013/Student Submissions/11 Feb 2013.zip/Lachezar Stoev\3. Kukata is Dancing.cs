using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_3___Kukata
{
    class Program
    {
        static void Main(string[] args)
        {
            int N=int.Parse(Console.ReadLine());
            string[] moves = new string[N];
            
            
            
            for (int i = 0; i < N; i++)
            {
                moves[i] = Console.ReadLine();
            }
            for (int i = 0; i < N; i++)
            {
                int jStart = 1;
                int kStart = 1;
                int direction = 0;
                for (int j = 0; j < moves[i].Length ; j++)
                {


                    if (moves[i][j] == 'R')
                    {
                        if (direction == 2)
                        {
                            direction = -1;
                        }
                        else
                        {
                            direction += 1;
                        }
                    }
                    if (moves[i][j] == 'L')
                    {

                        if (direction == -2)
                        {
                            direction = 1;
                        }
                        else
                        {
                            direction += -1;
                        }
                    }
                    if (moves[i][j] == 'W')
                    {
                        if (direction == 0)
                        {
                            if (jStart == 0)
                            {
                                jStart = 2;
                            }
                            else
                            {
                                jStart--;
                            }
                        }
                        if (direction == 1)
                        {
                            if (kStart == 2)
                            {
                                kStart = 0;
                            }
                            else
                            {
                                kStart++;
                            }
                        }
                        if (direction == -1)
                        {
                            if (kStart == 0)
                            {
                                kStart = 2;
                            }
                            else
                            {
                                kStart--;
                            }
                        }
                        if (direction == 2 || direction == -2)
                        {
                            if (jStart == 2)
                            {
                                jStart = 0;
                            }
                            else
                            {
                                jStart++;
                            }
                        }

                    }
                }
                if (jStart==1 && kStart ==1)
                {
                    Console.WriteLine("GREEN");
                }
                if ((jStart == 0 && kStart == 0) || (jStart == 0 && kStart == 2) || (jStart == 2 && kStart == 0) || (jStart == 2 && kStart == 2))
                {
                    Console.WriteLine("RED");
                }
                if(Math.Abs(jStart-kStart)==1)
                {
                    Console.WriteLine("BLUE");
                }
            }
        }
    }
}
