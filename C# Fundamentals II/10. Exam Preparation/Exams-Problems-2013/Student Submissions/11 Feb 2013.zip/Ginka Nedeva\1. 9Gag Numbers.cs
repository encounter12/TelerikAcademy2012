using System;

class Program
{
    static void Main()
    {
        string[] arr = new string[4]; 
        arr[0] = "-!";               
        arr[1] = "**";              
        arr[2] = "!!!";           
        arr[3] = "&&";         

        for (int i = 0; i < arr.Length; i++)
        {
            string s = arr[i];
            Console.WriteLine(s);
        }

        for (int i = arr.Length - 1; i >= 0; i--)
        {
            string s = arr[i];
            Console.WriteLine(s);
        }
    }
}