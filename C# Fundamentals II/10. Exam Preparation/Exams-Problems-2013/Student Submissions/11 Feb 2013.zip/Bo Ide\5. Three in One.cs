using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeInOne
{
    class Program
    {
        static void Main(string[] args)
        {
        }
        //first Task
        class FirstProblem
        {
            List<int> points = new List<int>();
            private void DetermineTheWinner()
            {
                int winnerScore = 0, winnerIndex=0, compareScore = 0, checkIfExactlyOne =0;

                foreach (var i in points)
                {
                    if (points[i] <= 21)
                    {
                        compareScore = points[i];
                        break;
                    }
                    else
                    {
                        Console.WriteLine("-1");
                    }
                }

                foreach (var i in points)
                {
                    if (points[i] <= 21 && points[i] > compareScore)
                    {
                        winnerScore = compareScore;
                        winnerIndex = i;
                    }
                }

                foreach (var i in points)
                {
                    if (points[i] == winnerScore && i!=winnerIndex)
                    {
                        Console.WriteLine("-1");
                    }
                }
                Console.WriteLine(winnerIndex);
            }

        }
    }
}
