using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string word = "";
            int[] arr = new int[20];
            List<int> lst = new List<int>();
            int counter = -1;
            double number = 0;
            int j = 0;
            Dictionary<string, int> dict = new Dictionary<string, int>();
            dict.Add("-!",0);
            dict.Add("**",1);
            dict.Add("!!!",2);
            dict.Add("&&",3);
            dict.Add("&-",4);
            dict.Add("!-",5);
            dict.Add("*!!!",6);
            dict.Add("&*!",7);
            dict.Add("!!**!-",8);

            foreach (var character in input)
            {
                word += character;
                foreach (var item in dict)
                {
                    if (item.Key == word)
                    {
                        //Console.Write(item.Value+"\n");
                       // arr[counter+1] = item.Value;
                        lst.Add(item.Value);
                        counter++;
                        word = "";
                        break;
                    }
                }
            }

            //for (int i = counter; i >= 0; i--)
            //{
            //    number += arr[j] * Math.Pow(9.0, (double)i);
            //    //Console.Write("~"+number);
            //    j++;
            //}
            foreach (var item in lst)
            {
                number += item * Math.Pow(9.0, counter);
                counter--;
            }

            Console.WriteLine(number);
        }
    }
}
