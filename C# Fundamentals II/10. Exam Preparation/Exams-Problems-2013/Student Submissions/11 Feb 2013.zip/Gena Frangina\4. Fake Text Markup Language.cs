/* 5. You are given a text. Write a program that changes the text in all regions surrounded by the tags <upcase> and </upcase> to uppercase. The tags cannot be nested. Example:
 
We are living in a <upcase>yellow submarine</upcase>. We don't have <upcase>anything</upcase> else.
 
The expected result:
 
We are living in a YELLOW SUBMARINE. We don't have ANYTHING else. */

using System;
using System.Collections.Generic;
using System.Text;


class UpperTag
{
    static void Main()
    {
        string str = "So<rev><upper>saw</upper> txet em<del>ba</del></rev> <lower><upper>here</upper></lower> "; 
		int startIndex = 0;
        int endIndex = 0;
        //Console.WriteLine(str);
        for (int i = 0; i < str.Length - 7; i++)
        {
            if (str.Substring(i, 7) == "<upper>")
            {
                startIndex = i + 7;
                i = startIndex;
            }
            if (str.Substring(i, 8) == "</upper>")
            {
                endIndex = i;
                int length = endIndex - startIndex;
                string upperStr = str.Substring(startIndex, length).ToUpper();
                //Console.WriteLine(upperStr);
                str = str.Remove(startIndex, length);
                //Console.WriteLine(str);
                str = str.Insert(startIndex, upperStr);
                //Console.WriteLine(str);
                str = str.Remove(startIndex - 7, 7);
                str = str.Remove(endIndex - 7, 8);
            }

        }

        for (int i = 0; i < str.Length - 7; i++)
        {
            if (str.Substring(i, 7) == "<lower>")
            {
                startIndex = i + 7;
                i = startIndex;
            }
            if (str.Substring(i, 8) == "</lower>")
            {
                endIndex = i;
                int length = endIndex - startIndex;
                string lowerStr = str.Substring(startIndex, length).ToLower();
                //Console.WriteLine(upperStr);
                str = str.Remove(startIndex, length);
                //Console.WriteLine(str);
                str = str.Insert(startIndex, lowerStr);
                //Console.WriteLine(str);
                str = str.Remove(startIndex - 7, 7);
                str = str.Remove(endIndex - 7, 8);
            }

        }
        for (int i = 0; i < str.Length - 5; i++)
        {
            if (str.Substring(i, 5) == "<del>")
            {
                startIndex = i + 5;
                i = startIndex;
            }
            if (str.Substring(i, 6) == "</del>")
            {
                endIndex = i;
                int length = endIndex - startIndex;
                string delStr = str.Trim();
                //Console.WriteLine(delStr);
                str = str.Remove(startIndex, length);
                //Console.WriteLine(str);
               //Console.WriteLine(str);
                str = str.Remove(startIndex - 5, 5);
                str = str.Remove(endIndex - 5, 6);
            }

        }
       
        Console.WriteLine(str);
    }
}		
        		
        
    
