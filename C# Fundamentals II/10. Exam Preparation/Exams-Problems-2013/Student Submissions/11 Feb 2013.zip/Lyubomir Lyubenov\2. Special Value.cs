using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class SpecialValue
{

    static void Main()
    {
        int rows = int.Parse(Console.ReadLine());
        List<List<int>> myArray = new List<List<int>>();
        int[][] visited = new int[rows][];
        int specV = 0;

        for (int i = 0; i < rows; i++)
        {
            List<int> lineList = new List<int>();
            string line = Console.ReadLine();
            //Console.WriteLine(line.Length);
            string[] strNum = line.Split(',');

            foreach (var item in strNum)
            {
                lineList.Add(int.Parse(item));
            }            
            myArray.Add(lineList);
            visited[i] = new int[myArray[i].Count];
        }

        for (int i = 0; i < myArray[0].Count; i++)
        {
            int sum = 0;
            int row = 0;
            int index = i;
            while (true)
            {
                if (myArray[row][index] < 0)
                {
                    sum++;
                    sum -= myArray[row][index];
                    if (sum > specV)
                    {
                        specV = sum;
                    }
                    break;
                }
                else
                {
                    sum++;
                    index = myArray[row][index];
                    row++;
                    if (row == myArray.Count)
                    {
                        row = 0;
                    }                    
                }
                if (sum > specV)
                {
                    specV = sum;
                }
            }
        }
        Console.WriteLine(specV);
        //Console.WriteLine();
        //for (int y = 0; y < myArray.Count; y++ )
        //{
        //    for(int x = 0; x < myArray[y].Count; x ++)
        //    {
        //        Console.Write(myArray[y][x]);
        //    }

        //}
    }
}
