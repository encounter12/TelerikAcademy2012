using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GagNumbers
{
    class GagNumbers
    {
        static void Main()
        {
            int counter = 0;

            string[] keyword = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
            string emptySpace = " ";
            string inputValue = Console.ReadLine();

            int index = 0;
            int result = 0;
            int position = inputValue.Length;

            while (index != -1)
            {
                for (int i = 8; i >= 0; i--)
                {
                    index = inputValue.LastIndexOf(keyword[i]);
                    if (index != -1)
                    {
                        // Console.WriteLine("{0}", i);
                        inputValue = inputValue.Replace(keyword[i], emptySpace);
                        counter++;
                        if (counter > 1)
                        {
                            result = result + (i * 9);
                        }
                        else
                        {
                            result = result + i;
                        }
                        //Console.WriteLine(inputValue);
                        //Console.WriteLine(counter);
                    }
                }
            }
            Console.WriteLine(result);
            //if (inputValue.Equals("*!!!"))
            //{
            //    Console.WriteLine(6);
            //}
            //if (inputValue.Equals("***!!!"))
            //{
            //    Console.WriteLine(15);
            //}
            //if (inputValue.Equals("!!!**!-"))
            //{
            //    Console.WriteLine(176);
            //}
            //if (inputValue.Equals("!!**!--!!-"))
            //{
            //    Console.WriteLine(653);
            //}
        }
    }
}