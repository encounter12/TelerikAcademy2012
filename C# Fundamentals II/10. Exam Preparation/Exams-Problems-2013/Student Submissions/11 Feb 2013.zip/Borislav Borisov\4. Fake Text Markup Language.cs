using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5.ChangeToUpper
{
    class Program
    {
        public static string changeToUpper(string text)
        {
            string startTag = "<upper>";
            string endTag = "</upper>";

            while (text.IndexOf(startTag) != -1)
            {
                int startPosition = text.IndexOf(startTag);
                int endPosition = text.IndexOf(endTag);
                string temp = text.Substring(startPosition + startTag.Length, endPosition - startPosition - startTag.Length);

                text = text.Replace(startTag + temp + endTag, temp.ToUpper());
            }
            return text;
        }
        static void Main(string[] args)
        {
            int line = int.Parse(Console.ReadLine());
            string[] ftml = new string[line];
            for (int i = 0; i < ftml.Length; i++) {
                ftml[i] = Console.ReadLine();
            }
            foreach (var element in ftml) {
                Console.WriteLine(changeToUpper(element));
            }
        }
    }
}
