using System;
using System.Collections.Generic;
using System.Numerics;

class NineGagNumbers
{
    static void Main()
    {
        BigInteger result = 0;
        string nineGagNum = Console.ReadLine();
        string zero = "-!",
            one = "**",
            two = "!!!",
            three = "&&",
            four = "&-",
            five = "!-",
            six = "*!!!",
            seven = "&*!",
            eight = "!!**!-";
        List<int> digits = new List<int>();

        while (nineGagNum.Length > 0)
        {
            if (nineGagNum.StartsWith(zero))
            {
                digits.Add(0);
                nineGagNum = nineGagNum.Remove(0, zero.Length);
            }
            else if (nineGagNum.StartsWith(one))
            {
                digits.Add(1);
                nineGagNum = nineGagNum.Remove(0, one.Length);
            }
            else if (nineGagNum.StartsWith(two))
            {
                digits.Add(2);
                nineGagNum = nineGagNum.Remove(0, two.Length);
            }
            else if (nineGagNum.StartsWith(three))
            {
                digits.Add(3);
                nineGagNum = nineGagNum.Remove(0, three.Length);
            }
            else if (nineGagNum.StartsWith(four))
            {
                digits.Add(4);
                nineGagNum = nineGagNum.Remove(0, four.Length);
            }
            else if (nineGagNum.StartsWith(five))
            {
                digits.Add(5);
                nineGagNum = nineGagNum.Remove(0, five.Length);
            }
            else if (nineGagNum.StartsWith(six))
            {
                digits.Add(6);
                nineGagNum = nineGagNum.Remove(0, six.Length);
            }
            else if (nineGagNum.StartsWith(seven))
            {
                digits.Add(7);
                nineGagNum = nineGagNum.Remove(0, seven.Length);
            }
            else if (nineGagNum.StartsWith(eight))
            {
                digits.Add(8);
                nineGagNum = nineGagNum.Remove(0, eight.Length);
            }
        }

        for (int i = digits.Count - 1, power = 0; i >= 0; i--, power++)
        {
            result += (BigInteger)(digits[i] * (Math.Pow(9, power)));
        }        
        
        Console.Write(result);
    }
}