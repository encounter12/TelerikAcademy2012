using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
 
namespace _9Gac
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
             
            BigInteger mainNum = new BigInteger();
            List<int> intList = new List<int>();
            string[] array = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
            while (input.Length > 0)
            {
                for (int i = 0; i <= 8; i++)
                {
                    if (input.StartsWith(array[i]))
                    {
                        intList.Add(i);
                       input= input.Remove(0,array[i].Length);
                        break;
                    }
                }
            }
            for (int pow = intList.Count - 1, i = 0; i <= intList.Count - 1; i++,pow--)
            {
                mainNum = mainNum + (int)Math.Pow(9, pow) * intList[i];
            }
            Console.WriteLine(mainNum);
        }
    }
}
