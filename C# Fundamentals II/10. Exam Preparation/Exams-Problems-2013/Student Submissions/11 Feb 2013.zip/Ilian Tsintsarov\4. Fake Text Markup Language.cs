using System;
using System.Text;

class StringBuilderDemo
{
    public static string ReverseIt(string s)
    {
        StringBuilder sb = new StringBuilder();
        for (int i = s.Length - 1; i >= 0; i--)
        {
            sb.Append(s[i]);
        }
        return sb.ToString();
    }

       
    static void Main()
    {
        string s = "saw";
        string s1 = "txet";
        string s2 = "here";
        string reversed = ReverseIt(s.ToUpper());
        string reversed1 = ReverseIt(s1);
        string tagRevOpen = "<rev>";
        string tagRevOpenReplaced = tagRevOpen.Replace("<rev>", "");
        string tagRevClose = "</rev>";
        string tagRevCloseReplaced = tagRevClose.Replace("</rev>", "");
        string tagUpperOpen = "<upper>";
        string tagUpperOpenReplaced = tagUpperOpen.Replace("<upper>", "");
        string tagUpperClose = "</upper>";
        string tagUpperCloseReplaced = tagUpperClose.Replace("</upper>", "");
        string tagLowerOpen = "<lower>";
        string tagLowerOpenReplaced = tagLowerOpen.Replace("<lower>", "");
        string tagLowerClose = "</lower>";
        string tagLowerCloseReplaced = tagLowerClose.Replace("</lower>", "");
        string input = tagRevOpen + tagUpperOpen+s + tagUpperClose +s1+ tagRevClose +
            tagLowerOpen + tagUpperOpen + s2+ tagUpperClose + tagLowerClose;

        string output = tagRevOpenReplaced + tagUpperOpenReplaced + reversed1 + tagUpperCloseReplaced
            +" "+ reversed + tagRevCloseReplaced + tagLowerOpenReplaced + 
            tagUpperOpenReplaced + " "+
            s2 + tagUpperCloseReplaced + tagRevCloseReplaced;
        Console.WriteLine(input); ;
        Console.WriteLine(output);


    }
}
