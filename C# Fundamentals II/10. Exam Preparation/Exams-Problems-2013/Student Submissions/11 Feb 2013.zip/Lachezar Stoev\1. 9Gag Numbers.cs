using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;


namespace Problem_1
{
    class Program
    {
        static void Main(string[] args)
        {

            string gagNumber = Console.ReadLine();
            List<sbyte> numbers=new List<sbyte>();
            BigInteger result = 0;
           
                for (int i = 0; i < gagNumber.Length - 1; i++)
                {
                    if (gagNumber[i] == '!')
                    {
                        if (gagNumber[i + 1] == '-')
                        {
                            numbers.Add(5);
                            i += 1;
                            continue;
                        }
                        if (gagNumber[i + 2] == '!')
                        {
                            numbers.Add(2);
                            i += 2;
                            continue;
                        }
                        if (gagNumber[i + 2] == '*')
                        {
                            numbers.Add(8);
                            i += 5;
                            continue;
                        }

                    }
                    if (gagNumber[i] == '-')
                    {
                        numbers.Add(0);
                        i += 1;
                        continue;

                    }
                    if (gagNumber[i] == '&')
                    {
                        if (gagNumber[i + 1] == '&')
                        {
                            numbers.Add(3);
                            i += 1;
                            continue;
                        }
                        if (gagNumber[i + 1] == '-')
                        {
                            numbers.Add(4);
                            i += 1;
                            continue;
                        }
                        if (gagNumber[i + 1] == '*')
                        {
                            numbers.Add(7);
                            i += 1;
                            continue;
                        }
                    }
                    if (gagNumber[i] == '*')
                    {
                        if (gagNumber[i + 1] == '*')
                        {
                            numbers.Add(1);
                            i += 1;
                            continue;
                        }
                        if (gagNumber[i + 1] == '!')
                        {
                            numbers.Add(6);
                            i += 3;
                            continue;
                        }

                    }
                }
            
            for (int i = 1,j=numbers.Count-1; j>=0; j--,i*=9)
            {
                result += numbers[j] * i;
            }
            Console.WriteLine(result);
               

        }
    }
}
