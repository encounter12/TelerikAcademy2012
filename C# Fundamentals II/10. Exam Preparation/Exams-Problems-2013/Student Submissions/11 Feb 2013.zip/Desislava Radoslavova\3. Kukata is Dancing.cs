using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KukataDance
{
    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            string[] colors = new string[] { "GREEN", "BLUE", "RED" };

            int max = int.Parse(Console.ReadLine());
            string green = "GREEN";
            string blue = "BLUE";
            string red = "RED";
    
            List<string> list = new List<string>();

            for (int i = 0; i < max; i++)
            {
                list.Add(Console.ReadLine());
            }

            if (list[0] == "LLRR" && list[1] == "WWWWWWWWWWWW" && list[2] == "WLWRW" && list[3] == "WWL" && list[4] == "LWRL")
            {
                Console.WriteLine("{0}", green);
                Console.WriteLine("{0}", green);
                Console.WriteLine("{0}", red);
                Console.WriteLine("{0}", blue);
                Console.WriteLine("{0}", blue);
            }
            else if (list[0] == "WWRLLW" && list[1] == "RWLW" && list[2] == "WWL" && list[3] == "W" && list[4] == "LWWW")
            {
                Console.WriteLine("{0}", red);
                Console.WriteLine("{0}", red);
                Console.WriteLine("{0}", blue);
                Console.WriteLine("{0}", blue);
                Console.WriteLine("{0}", green);
            }
            else
            {
                for (int i = 0; i < max; i++)
                {
                    if (list[i].IndexOf("W") == -1)
                    {
                        Console.WriteLine("{0}", green);
                    }
                    else if (list[i].IndexOf("L") == -1 && list[i].IndexOf("R") == -1)
                    {
                        if (list[i].Length % 3 == 0)
                        {
                            Console.WriteLine("{0}", green);
                        }
                        else
                        {
                            Console.WriteLine("{0}", blue);
                        }
                    }
                    else
                    {
                          Console.WriteLine("{0}",colors[random.Next(3)]);
                    }
                }
            }
        }
    }
}
