using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecialValue
{
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            string[] dances = new string[n];
            for (int i = 0; i < dances.Length; i++)
            {
                dances[i] = Console.ReadLine();
            }
            foreach (string dance in dances)
            {
                if (dances[0] == "L" || dances[0] == "R" || dances[0] == "LL")
                    Console.WriteLine("GREEN");
            }

        }
        
    }
}