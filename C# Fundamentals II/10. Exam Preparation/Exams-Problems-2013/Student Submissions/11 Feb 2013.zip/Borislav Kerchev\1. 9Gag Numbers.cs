using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace ConsoleApplication_testCSharp
{
    class Program
    {
        static void Main()
        {

          //  ulong a = Problem1("!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-");
            Console.WriteLine(Problem1(Console.ReadLine()));
        }

        static string Translate(Match m)
        {
            switch (m.ToString())
            {
                case "-!":
                    return "0";
                case "**":
                    return "1";
                case "!!!":
                    return "2";
                case "&&":
                    return "3";
                case "&-":
                    return "4";
                case "!-":
                    return "5";
                case "*!!!":
                    return "6";
                case "&*!":
                    return "7";
                case "!!**!-":
                    return "8";
            }
            throw new Exception("Match not found...");
        }


        static ulong Problem1(string input)
        {
            ulong result = 0;
            string s = Regex.Replace(input, @"-!|[*][*]|&&|&-|!-|[*]?!!!|&[*]!|!![*][*]!-", Program.Translate);

            for (int i = 0; i < s.Length; i++)
            {
                result += ulong.Parse(s[i].ToString()) * Convert.ToUInt64(Math.Pow(9D, Convert.ToDouble(s.Length - i - 1)));
            }
            return result;
        }
    }
}