using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Gag_numbers
{
    class Numbers
    {
        static void Main(string[] args)
        {
            //// Create new stopwatch
            //Stopwatch stopwatch = new Stopwatch();

            //// Begin timing
            //stopwatch.Start();

            //input
            string input = Console.ReadLine();

            //an array holding the digits in 9gag format
            string[] gagDigits = new string[] { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };

            //a list to hold the digits as arab numbers
            List<byte> arabDigits = new List<byte>();

            //a string builder to hold the input
            StringBuilder sb = new StringBuilder(input);
            int currentPosition = 0;

            while (sb.Length > 0)
            {
                //0
                if (input.Substring(currentPosition, gagDigits[0].Length) == gagDigits[0])
                {
                    arabDigits.Add(0);
                    sb.Remove(0, gagDigits[0].Length);
                    currentPosition += gagDigits[0].Length;
                }
                //1
                else if (input.Substring(currentPosition, gagDigits[1].Length) == gagDigits[1])
                {
                    arabDigits.Add(1);
                    sb.Remove(0, gagDigits[1].Length);
                    currentPosition += gagDigits[1].Length;
                }

                //3
                else if (input.Substring(currentPosition, gagDigits[3].Length) == gagDigits[3])
                {
                    arabDigits.Add(3);
                    sb.Remove(0, gagDigits[3].Length);
                    currentPosition += gagDigits[3].Length;
                }
                //4
                else if (input.Substring(currentPosition, gagDigits[4].Length) == gagDigits[4])
                {
                    arabDigits.Add(4);
                    sb.Remove(0, gagDigits[4].Length);
                    currentPosition += gagDigits[4].Length;
                }
                //5
                else if (input.Substring(currentPosition, gagDigits[5].Length) == gagDigits[5])
                {
                    arabDigits.Add(5);
                    sb.Remove(0, gagDigits[5].Length);
                    currentPosition += gagDigits[5].Length;
                }
                //2
                else if (input.Substring(currentPosition, gagDigits[2].Length) == gagDigits[2])
                {
                    arabDigits.Add(2);
                    sb.Remove(0, gagDigits[2].Length);
                    currentPosition += gagDigits[2].Length;
                }
                //7
                else if (input.Substring(currentPosition, gagDigits[7].Length) == gagDigits[7])
                {
                    arabDigits.Add(7);
                    sb.Remove(0, gagDigits[7].Length);
                    currentPosition += gagDigits[7].Length;
                }
                //6
                else if (input.Substring(currentPosition, gagDigits[6].Length) == gagDigits[6])
                {
                    arabDigits.Add(6);
                    sb.Remove(0, gagDigits[6].Length);
                    currentPosition += gagDigits[6].Length;
                }
                //8
                else if (input.Substring(currentPosition, gagDigits[8].Length) == gagDigits[8])
                {
                    arabDigits.Add(8);
                    sb.Remove(0, gagDigits[8].Length);
                    currentPosition += gagDigits[8].Length;
                }
            }


            //for (int i = 0; i < arabDigits.Count; i++)
            //{
            //    Console.WriteLine(arabDigits[i]);
            //}

            arabDigits.Reverse();
            BigInteger result = SourceToDecimal(9, arabDigits);
            Console.WriteLine(result);



            //// Stop timing
            //stopwatch.Stop();

            //// Write result
            //Console.WriteLine("Time elapsed: {0}",
            //    stopwatch.Elapsed);

        }

        static BigInteger SourceToDecimal(int s, List<byte> list)
        {
            BigInteger source = 0;
            for (int i = 0; i < list.Count; i++)
            {
                //multiply each digit list[i] with the base of the source numeral system to the power of the digit position and sum all to get the number in decimal
                source += list[i] * BigInteger.Pow(s, i);
            }
            return source;
        }
    }
}
