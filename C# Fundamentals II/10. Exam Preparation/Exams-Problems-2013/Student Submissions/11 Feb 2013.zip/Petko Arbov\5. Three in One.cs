using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task5
{
    class Program
    {
        static int BlackJack(int[] array)
        {
            //88
            // az 51
            int winnerCounter = 0;
            int maxPoints = 0;
            int indexMaxPoints = -1;
            int currentPoints = 0;
            for (int i = 0; i < array.Length; i++)
            {
                currentPoints = array[i];
                if (currentPoints <= 21)
                {
                    if (currentPoints > maxPoints)
                    {
                        maxPoints = currentPoints;
                        indexMaxPoints = i;
                        winnerCounter = 0;
                    }
                    if (currentPoints == maxPoints)
                    {
                        winnerCounter++;
                    }
                }
            }
            if (winnerCounter == 1)
            {
                return indexMaxPoints;
            }
            else
            {
                return -1;
            }
        }
        static int CakeBites(int[] array, int f)
        {
            int myBites = 0;
            Array.Sort(array);
            for (int i = array.Length-1; i >=0 ; i--)
            {
                myBites = myBites + array[i];
                i = i - f;
            }
            return myBites;
        }
        static int Money(int G1, int S1, int B1, int G2, int S2, int B2)
        {
            int numberTransactions = 0;
            if (G1 >= G2)  //imame dostatu4no zlato
            {
                if (S1 <= S2 && B1 < B2)
                {
                    //stariq kod
                    while (G1 > G2)
                    {
                        S1 = S1 + 9;
                        G1--;
                        numberTransactions++;
                    }
                    if (S1 >= S2)
                    {
                        while (S1 > S2)
                        {
                            B1 = B1 + 11;
                            S1--;
                            numberTransactions++;
                        }
                    }
                    else
                    {
                        if (B1 > B2)
                        {
                            while (B1 > B2)
                            {
                                S1 = S1 + 1;
                                B1 = B1 - 9;
                                numberTransactions++;
                            }
                        }
                        else
                        {
                            return -1;
                        }
                    }//krai na stariq kod
                }
                else if (B1 < B2 &&S1>S2)
                {
                    while (S1 > S2)
                    {
                        B1 = B1 + 11;
                        S1--;
                        numberTransactions++;
                        if (S1 < S2 ||S1==0)
                        {
                            while (G1 > G2)
                            {
                                S1 = S1 + 9;
                                G1--;
                                numberTransactions++;
                            }
                        }
                    }
                    
                }
            }
            else  //slu4ai imanoto zlato e po-malko ot iskanoto
            {
                if (S1 > S2)
                {
                    if (S1 > S2 && B1 > B2)
                    {  //imame dostatu4no bronz i srebro
                        while (S1 > S2)
                        {
                            G1 = G1 + 1;
                            S1 = S1 - 9;
                            numberTransactions++;
                            if (G1 >= G2)
                            {
                                break;
                            }
                        }
                    }
                    else //imame dostatu4no srebro, no ne i bronz
                    {
                        while (S1 > S2)
                        {
                            B1 = B1 + 9;
                            S1--;
                            numberTransactions++;
                            if (B1 >= B2)
                            {
                                break;
                            }
                        }
                        while (S1 > S2)
                        {
                            G1 = G1 + 1;
                            S1 = S1 - 9;
                            numberTransactions++;
                            if (G1 >= G2)
                            {
                                break;
                            }
                        }
                    }
                }//krai slu4ai imame dostatu4no srebro
                else //nqmame dostatu4no srebro
                {
                    if (B1 > B2)
                    {
                        while (B1 > B2)
                        {
                            S1 = S1 + 1;
                            B1 = B1 - 9;
                            numberTransactions++;
                        }
                        while (S1 > S2)
                        {
                            G1 = G1 + 1;
                            S1 = S1 - 9;
                            numberTransactions++;

                            if (G1 >= G2)
                            {
                                break;
                            }
                        }
                    }
                    else
                    {
                        return -1;
                    }
                }
            }//krai else dostatu4no zlato
            if (G1 >= G2 && S1 >= S2 && B1 >= B2)
            {

                return numberTransactions;
            }
           else
            {
                return -1;
            }
        }
        static void Main()
        {
            //blackjack function ready
            string text = Console.ReadLine();
            string[] bjscores = text.Split(',');
            
            int[] testArray = new int[bjscores.Length];
            for (int i = 0; i < testArray.Length; i++)
            {
                testArray[i] = int.Parse(bjscores[i]);
            }
          //  int[] testArray = { 6, 7, 9, 6, 4 };
            int blackjackwinner = BlackJack(testArray);

            //cakes
            string cakeInput = Console.ReadLine();
            string[] cakes = cakeInput.Split(',');
            int[] cakeArray = new int[cakes.Length];
            for (int j = 0; j < cakeArray.Length; j++)
            {
                cakeArray[j] = int.Parse(cakes[j]);
            }
            int f = int.Parse(Console.ReadLine());
            int bites = CakeBites(cakeArray,f);

            //rpg game
            string moneyInput = Console.ReadLine();
            string[] money = moneyInput.Split(' ');
         //   int[] moneyArr = new int[money.Length];
            int g1 = int.Parse(money[0]);
            int s1 = int.Parse(money[1]);
            int b1 = int.Parse(money[2]);
            int g2 = int.Parse(money[3]);
            int s2 = int.Parse(money[4]);
            int b2 = int.Parse(money[5]);
             int transactions=Money(g1, s1, b1, g2, s2, b2);

            //printing
            Console.WriteLine(blackjackwinner);
            Console.WriteLine(bites);
            Console.WriteLine(transactions);

        }
    }
}
