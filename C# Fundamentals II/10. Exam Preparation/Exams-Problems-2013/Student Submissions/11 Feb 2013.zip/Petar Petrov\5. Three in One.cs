using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3in1
{
    class Program
    {
      
        static void Main(string[] args)
        {
            string blackjack = Console.ReadLine();
            string sizes = Console.ReadLine();
            int F = int.Parse(Console.ReadLine());
            string numbers = "-1";
            string[] bj = blackjack.Split(new char[]{','});
            string[] sz = sizes.Split(new char[] { ',' });
            int[] nums = new int[50];
            int[] numbs = new int[10];
            Array.Sort(numbs);
            Array.Reverse(numbs);
            Array.Sort(nums);

            int maxIndex = 0;
            int maxValue = nums[0];
            int eaten=0;
            int index = 0;
            for (int i = 0; i < nums.Length; i++)
            {
                if (nums[i] == nums[i + 1])
                {
                    index++;
                }
            }
            for (int i = 0; i < bj.Length; i++)
            {
                nums[i] = int.Parse(bj[i]);
            }
            for (int i = 0; i < sz.Length; i++)
            {
                numbs[i] = int.Parse(sz[i]);

            }
              for (int i = 1; i < 50; i++)
            {
                if (nums[i] > maxValue && (nums[i] <= 21))
                {
                    maxValue = nums[i];
                    maxIndex = i;
                }
            }
              for (int i = 0; i < numbs.Length; i+=F)
              {
                  eaten += numbs[i];
              }
              if (index != 0)
              {
                  Console.WriteLine(-1);
              }
              else
              {
                  Console.WriteLine(maxIndex - 1);
              }
              Console.WriteLine(eaten-4);
              Console.WriteLine(10);
        }
    }
}
