
using System;
using System.Linq;

class Problem5
{
    static void Main(string[] args)
    {

        Console.Out.Write("Please eneter number of players:");
        int n = int.Parse(Console.ReadLine());

        int[] points = new int[n];

        Console.Out.WriteLine("Please eneter points for each player");
        for (int index = 0; index < points.Length; index++)
        {
            Console.Out.Write(",");
            points[index] = int.Parse(Console.ReadLine());

        }

        int result = -1;
        int maxValue = points.Max();
        int maxIndex = points.ToList().IndexOf(maxValue);



        for (int index = 0; index < points.Length; index++)
        {
            if (maxValue != points[index] && maxValue <= 21)
            {
                result = maxIndex;
            }
            else
            {
                result = -1;
            }

        }
        Console.Out.WriteLine(result);
    }

}