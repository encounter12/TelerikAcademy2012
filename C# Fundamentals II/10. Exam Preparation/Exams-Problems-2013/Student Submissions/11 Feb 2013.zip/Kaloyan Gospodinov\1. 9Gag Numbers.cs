using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

class NineGagNum
{
    static void Main()
    {
        string str = Console.ReadLine();

        if (str.Length > 20)
        {
            Console.WriteLine("You've endtered more than 20 characters");
        }

        else
        {
            
            Dictionary<string, int> dictionary = new Dictionary<string, int>();
            {
                dictionary.Add("-!", 0);
                dictionary.Add("**", 1);
                dictionary.Add("!!!", 2);
                dictionary.Add("&&", 3);
                dictionary.Add("&-", 4);
                dictionary.Add("!-", 5);
                dictionary.Add("*!!!", 6);
                dictionary.Add("&*!", 7);
                dictionary.Add("!!**!-", 8);
            }
            if (dictionary.ContainsKey(str))
            {
                Console.WriteLine(dictionary[str]); // true
            }
            
        }
        
    }
}
