using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            List<string> tags = new List<string>();
            for (int i = 0; i < N; i++)
            {
                string line = GetResult(Console.ReadLine());
                tags.Add(line);
            }

            foreach (string line in tags)
            {
                Console.WriteLine(line);
            }
        }

        public static string GetResult(string line)
        {
            string toPrint = "";

            bool upper = false;
            bool reverse = false;
            bool toggle = false;
            bool lower = false;

            string _upper = "";
            string _toggle = "";
            string _lower = "";
            string _reverse = "";
            string curStr = "";

            List<string> complex = new List<string>();
            string[] separators = new string[2];
            separators[0] = "<";
            separators[1] = ">";
            string[] text = line.Split(separators,StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == "rev")
                {
                    reverse = true;
                    complex.Add("rev");
                }

                if (text[i] == "toggle")
                {
                    toggle = true;
                    complex.Add("toggle");
                }

                if (text[i] == "lower")
                {
                    lower = true;
                    complex.Add("lower");
                }

                if (text[i] == "upper")
                {
                    upper = true;
                    complex.Add("upper");
                }

                string c = text[i];
                if (complex.Contains(c) || text[i] == "/upper" || text[i] == "/lower" || text[i] == "/toggle" || text[i] == "/rev")
                {

                }
                else
                {
                    if (complex.Contains("upper"))
                    {
                        c = c.ToUpper();
                    }

                    if (complex.Contains("lower"))
                    {
                        c = c.ToLower();
                    }

                    if (complex.Contains("toggle"))
                    {
                        string _c = "";
                        for (int j = 0; j < c.Length; j++)
                        {
                            if (c[j] >= 'A' && c[j] <= 'Z')
                            {
                                _c += c[j].ToString().ToLower();
                            }
                            else if (c[j] >= 'a' && c[j] <= 'z')
                            {
                                _c += c[j].ToString().ToUpper();
                            }
                        }
                        c = _c;
                    }

                    if (complex.Contains("rev"))
                    {
                        _reverse += c;
                    }

                    curStr += c;
                }

                if (text[i] == "/rev")
                {
                    reverse = true;
                    complex.Remove("rev");
                }

                if (text[i] == "/toggle")
                {
                    toggle = true;
                    complex.Remove("toggle");
                }

                if (text[i] == "/lower")
                {
                    lower = true;
                    complex.Remove("lower");
                }

                if (text[i] == "/upper")
                {
                    upper = true;
                    complex.Remove("upper");
                }

                

            }
            if(curStr.IndexOf(_reverse)!=-1)
            {
                int strind = curStr.IndexOf(_reverse);
                toPrint = curStr.Substring(0,strind) + ReverseString(_reverse) + curStr.Substring(strind+_reverse.Length);
            }
            return toPrint;
        }

        public static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }
    }
}
