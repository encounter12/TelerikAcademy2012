using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem5ThreeInOne
{
  class Problem5ThreeInOne
  {
    static byte WinnerOfBlackJack(byte[] listOfResults)
    {
      int n = listOfResults.Length;
      byte result = 0; 
      count = 0;
      for (int i = 0; i < n; i++)
      {
        if (listOfResults[i] > 21)
        {
          listOfResults[i] = 0;
        }
      }
        for (int l = 0; l < n; l++)
        {
          for (int j = 0; j < n; j++)
          {
            if listOfResults[l] >= listOfResults[j]
            {
            result = l;
            count + = 1;
            }
          }
        }
        if (count > 1)
        {
          result = - 1;
        }
        return result;
     }
    static byte eatenCakes(byte[] sizeOfCakes, friends)
    {
      Array.Sort(sizeOfCakes);
      byte n = sizeOfCakes.Length;
      byte myCakes = sizeOfCakes[0];
      byte inrdex = friends + 1;
      do
      {
        myCakes = sizeOfCakes[index];
        indexer = indexer + friends + 1;
      }
      while (index < n);
      return myCakes;
    } 
    static int ExchangeCoins(int[] sizeOfCoins)
    {
      int count = 0;
      if (sizeOfCoins[3] > sizeOfCoins[0])
      {
        do
        {
          sizeOfCoins[1] = sizeOfCoins[1] - 9;
          sizeOfCoins[0] = sizeOfCoins[0] + 1;
          count++;
        }
        while (sizeOfCoins[1] == sizeOfCoins[3]);
      }
      if (sizeOfCoins[5] > sizeOfCoins[2])
      {
        do
        {
        sizeOfCoins[1] = sizeOfCoins[1] - 1;
        sizeOfCoins[2] = sizeOfCoins[2] + 11;
        count++;
        }
        while(sizeOfCoins[2] == sizeOfCoins[5]);
      }
      if (sizeOfCoins[1] < sizeOfCoins[4])
      {
        do 
        { 
          sizeOfCoins[1] = sizeOfCoins[1] + 1;
          sizeOfCoins[2] =sizeOfCoins[2] - 9;
          count++;
        }
        while(sizeOfCoins[1] == sizeOfCoins[4]);
      }
      return count;
    }
    
    static void Main(string[] args)
    {
      string points = Console.ReadLine();
      byte[] listOfResults = points.Split(',');
      byte winner = 0;
      winner = WinnerOfBlackJack(listOfResults);
      Console.WriteLine("{0}", winner);
      string cakes = Console.ReadLine();
      byte friends = Byte.Parse(Console.ReadLine());
      byte[] sizeOfCakes = cakes.Split(',');
      byte getCakes = 0;
      getCakes = eatenCakes(sizeOfCakes, friends);
      Console.WtiteLine("{0}", getCakes);
      string coins = Console.RaedLine();
      int[] sizeOfCoins = coins.Split(',');
      int exchangeOperations = 0;
      exchangeOperations = ExchangeCoins(sizeOfCoins);
      Console.WriteLine("{0}", exchangeOperations);

    }
  }
}