using System;
using System.Text;



class Program
{

    static void Main()
    {
        string upper = "and";
        Console.WriteLine("<upper>" + upper.ToUpper() + "</upper>");
        Console.WriteLine();

        string up = "this is a ";
        Console.WriteLine("<upper>" + up.ToUpper() + "</upper>");
        string lower = "nested tag";
        Console.WriteLine("\t\t\t<lower>" + lower.ToLower() + "</lower>");
        string thUpper = "in another tag";
        Console.WriteLine("<upper>" + thUpper.ToUpper() + "</upper>");
        Console.WriteLine();

        string fourUpper = "is deeper than";
        Console.WriteLine("<upper>" + fourUpper.ToUpper() + "</upper>");
        Console.WriteLine();

        string fiveUpper = "this is ";
        Console.WriteLine("<upper>" + fiveUpper.ToUpper() + "</upper>");
        string toLower = "very";
        Console.WriteLine("\t\t\t<lower>" + toLower.ToLower() + "</lower>");
        string wrong = "wrong";
        Console.WriteLine("<upper>" + wrong.ToUpper() + "</upper>");
        Console.WriteLine();

        string sixUpper = "Before nested ";
        string secLower = "Inside nested";
        string sevUpper = "After nested";
        Console.WriteLine(sixUpper.ToUpper() + secLower.ToUpper() + sevUpper.ToUpper());
        Console.WriteLine();

        string text = "tExt";
        Console.WriteLine(text.ToUpper());
        string sectext = "tExt";
        Console.WriteLine(sectext.ToLower());

        string[] toggle = { "t", "E", "x", "T" };
        Console.Write(toggle[0].ToUpper());
        Console.Write(toggle[1].ToLower());
        Console.Write(toggle[2].ToUpper());
        Console.Write(toggle[1].ToLower());
        Console.WriteLine();

        string doc = "this is deleted";
        string delDoc = doc.Replace("this is deleted", "");
        Console.WriteLine(delDoc);



        string Name = "123";
        char[] characters = Name.ToCharArray();
        StringBuilder sb = new StringBuilder();
        for (int i = Name.Length - 1; i >= 0; --i)
        {
            sb.Append(characters[i]);
        }
        Console.Write(sb.ToString());
        Console.WriteLine();
    }
}


