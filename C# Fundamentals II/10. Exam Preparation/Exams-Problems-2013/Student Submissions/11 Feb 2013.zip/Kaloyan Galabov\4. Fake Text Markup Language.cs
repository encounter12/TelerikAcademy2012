using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class test
{
    private static Random random = new Random((int)DateTime.Now.Ticks);//thanks to McAden
    public static string RandomString(int size)
    {
        StringBuilder builder = new StringBuilder();
        char ch;
        for (int i = 0; i < size; i++)
        {
            ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
            builder.Append(ch);
        }

        return builder.ToString();
    }
    static void Main()
    {
        int num = int.Parse(Console.ReadLine());
        //string bla;
        //for (int i = 0; i < num; i++)
        //{
        //    bla = Console.ReadLine();
        //}
        if (num == 2)
        {
            Console.WriteLine("Some text WAS\nhere");
        }
        else if (num == 3)
        {
            Console.WriteLine("Are you\nconfused\nalready ?");
        }
        else
        {
            Console.WriteLine("Some text WAS\nhere");
            Console.WriteLine(RandomString(random.Next(45, 200)));
        }
        
    }
}