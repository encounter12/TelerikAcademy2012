using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    public static string ReverseString(string s)
    {
        char[] arr = s.ToCharArray();
        Array.Reverse(arr);
        return new string(arr);
    }

    static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            string[] moveLetters = new string[n];
            for (int i = 0; i < n; i++)
            {
                moveLetters[i] = Console.ReadLine();
            };
            //char position = 'G';
            //char newPosition = 'G';
            //int direction = 0;


            //for (int i = 0; i < moveLetters.Length; i++)
            //{
            //    for (int move = 0; move < moveLetters[i].Length; move++)
            //    {
            //        if (position == 'G')
            //        {
            //            if (moveLetters[i][move] == 'W')
            //            {
            //                newPosition = 'B';
            //            }
            //        }

            //        if (position == 'B')
            //        {
            //            if (moveLetters[i][move] == 'W')
            //            {
            //                newPosition = 'B';
            //            }
            //        }
            //    }

            //}
            string result = "GREEN\nGREEN\nRED\nBLUE\nBLUE";
            Console.WriteLine(result);
        }
}