using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleApplication4
{
    class Program
    {


        static void Main()
        {
            StringBuilder code = new StringBuilder();
            //int linesCount = int.Parse(Console.ReadLine());

            bool del_tag = false;

            int lengthLines = int.Parse(Console.ReadLine());

            string[] lines = new string[lengthLines];
            string[] editedLines = new string[lengthLines];

            for (int i = 0; i < lengthLines; i++)
            {
                lines[i] = Console.ReadLine();
                code.Append(lines[i] + '\n');
            }

            string code1 = code.ToString();
            int index = code1.IndexOf("<del>");
            string new_str = "";

            while (index != -1)
            {
                int index1 = code1.IndexOf("</del>");
                int n = code1.IndexOf("\n", index + 4, index1 - index + 4);
                int count_n = 0;
                while (n != -1)
                {
                    count_n++;
                    n = code1.IndexOf("\n", n + 1, index1 - n + 1);
                }

                new_str = code1.Remove(index, index1 + 4);

                for (int k = 0; k < count_n; k++)
                {
                    new_str = new_str.Insert(index, "\n");
                }
                code.Clear();
                code.Append(new_str);
                index = new_str.IndexOf("<del>");
            }


            code1 = code.ToString();
            for (int j = 0; j < code.Length; j++)
            {
                int indexa = code1.IndexOf("<");
                int indexb = code1.IndexOf(">");
                string sub = code1.Substring(indexa, indexb - indexa);
                if (sub == "upper")
                {
                    int indexc = code1.IndexOf("<", indexb, code1.Length - indexb);
                    string sub_up = code1.Substring(indexb, indexc - indexb);
                    sub_up = sub_up.ToUpper();
                    code1 = code1.Remove(indexb, indexc - indexb);
                    code1 = code1.Insert(indexb + 1, sub_up);
                    continue;

                }
                else if (sub == "lower")
                { }
                else if (sub == "toggle")
                { }
                else if (sub == "rev")
                { }
            }

            string str = code.ToString();
            str = str.Remove(str.Length - 2, 2);
            //Console.WriteLine(str);

            string[] code_lines1 = str.Split('\n');  //StringSplitOptions.RemoveEmptyEntries
            foreach (string str_ in code_lines1)
            {
                if (!string.IsNullOrWhiteSpace(str))
                {
                    Console.WriteLine(str);
                }
            }
        }
    }
}
