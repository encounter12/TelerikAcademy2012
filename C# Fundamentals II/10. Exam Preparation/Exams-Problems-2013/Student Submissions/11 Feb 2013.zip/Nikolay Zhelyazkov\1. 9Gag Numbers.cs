using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
namespace _01.NineGAG
{
    class Program
    {
        public static StringBuilder keepStrNums = new StringBuilder();
        public static int index = 0;
        //public static int currentSymbols = 0;
        static void Main(string[] args)
        {
            string nineGAG = Console.ReadLine();
            //string nineGAG = "";
            
            for (int i = 0; i < nineGAG.Length; i++)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append(nineGAG[i]);
                for (int j = 1; j < 6; j++)
                {
                    if (i + j > nineGAG.Length - 1)
                    {
                        break;
                    }
                    sb.Append(nineGAG[i + j]);
                    string str = sb.ToString();
                    if (CheckCaseDoesMatch(str))
                    {
                        i += j;
                        break;
                    }
                }
            }
            ulong[] numsIntArr = new ulong[keepStrNums.Length];
            
            for (int i = 0; i < keepStrNums.Length; i++)
            {
                numsIntArr[i] = Convert.ToUInt64(Convert.ToString(keepStrNums[i]));
            }
            int pow = 1;
            BigInteger sum = 0;
            //int currentPosition = nineGAG.Length - 1;
            for (int i = numsIntArr.Length - 1; i >= 0; i--)
            {
                if (i == numsIntArr.Length - 1)
                {
                    sum = +numsIntArr[i];
                }
                else
                {
                    sum += numsIntArr[i] * Convert.ToUInt64(Math.Pow(9, pow));
                    pow++;
                }
            }
            Console.WriteLine(sum);

            //foreach (var item in numsIntArr)
            //{
            //    Console.WriteLine(item);
            //}
        }
        static bool CheckCaseDoesMatch(string s)
        {
            bool b = true;
            switch (s)
            {
                case "-!": keepStrNums.Append("0");index++;break;
                case "**": keepStrNums.Append("1"); index++; break;
                case "!!!": keepStrNums.Append("2"); index++; break;
                case "&&": keepStrNums.Append("3"); index++; break;
                case "&-": keepStrNums.Append("4"); index++; break;
                case "!-": keepStrNums.Append("5"); index++; break;
                case "*!!!": keepStrNums.Append("6"); index++; break;
                case "&*!": keepStrNums.Append("7"); index++; break;
                case "!!**!-": keepStrNums.Append("8"); index++; break;
                default: b = false;
                    break;
            }
            return b;
        }
    }
}