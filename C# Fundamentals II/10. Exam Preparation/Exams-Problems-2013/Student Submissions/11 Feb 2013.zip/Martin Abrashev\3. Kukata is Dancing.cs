using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DanceCube
{
    class Program
    {
        static int x = 1;
        static int y = 1;
        static int z = 0;
        static void Main(string[] args)
        {
            string[, ,] cube = new string[3, 3, 3]
            {
                {
                    {"RED","BLUE","RED"},
                    {"BLUE","GREEN","BLUE"},
                    {"RED","BLUE","RED"},
                },
                {
                    {"RED","BLUE","RED"},
                    {"BLUE","GREEN","BLUE"},
                    {"RED","BLUE","RED"},
                },
                {
                    {"RED","BLUE","RED"},
                    {"BLUE","GREEN","BLUE"},
                    {"RED","BLUE","RED"},
                }
            };

            string input = Console.ReadLine();
            int Nlines = int.Parse(input);

            string[] lines = new string[Nlines];
            for (int i = 0; i < Nlines; i++)
            {
                lines[i] = Console.ReadLine();
            }


            int onY = -1;
            int onX = 0;

            //string input = Console.ReadLine();
            ////Console.WriteLine(cube[z,y,x]);

            foreach (string line in lines)
            {
                for (int i = 0; i < line.Length; i++)
                {
                    if (line[i] == 'R')
                    {
                        if (onY == 1)
                        {
                            onY = 0;
                            onX = 1;
                        }
                        else if (onY == -1)
                        {
                            onY = 0;
                            onX = -1;
                        }
                        else if (onY == 0)
                        {
                            onY = -onX;
                            onX = 0;
                        }
                    }
                    else if (line[i] == 'L')
                    {
                        if (onY == 1)
                        {
                            onY = 0;
                            onX = -1;
                        }
                        else if (onY == -1)
                        {
                            onY = 0;
                            onX = 1;
                        }
                        else if (onY == 0)
                        {
                            onY = onX;
                            onX = 0;
                        }
                    }
                    else if (line[i] == 'W')
                    {
                        MoveX(onX);
                        MoveY(onY);
                    }
                }
                Console.WriteLine(cube[z, y, x]);
                x = 1;
                y = 1;
                z = 0;
                onY = -1;
                onX = 0;
            }
        }

        static void MoveY(int onY)
        {
            if (y == 0 && onY == -1)
            {
                z -= 1;
                if (z == -1) z = 2;
                y = 2;
            }
            else if (y == 2 && onY == 1)
            {
                z += 1;
                if (z == 3) z = 0;
                y = 0;
            }
            else
            {
                y += onY;
            }
        }

        static void MoveX(int onX)
        {
            if (x == 0 && onX == -1)
            {
                z -= 1;
                if (z == -1) z = 2;
                x = 2;
            }
            else if (x == 2 && onX == 1)
            {
                z += 1;
                if (z == 3) z = 0;
                x = 0;
            }
            else
            {
                x += onX;
            }
        }

    }
}
