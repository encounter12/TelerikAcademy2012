using System;
using System.Collections.Generic;
using System.Text;

class Kukata
{
    static int number;
    static string[] dances;
    static int row;
    static int col;

    static void Main()
    {
        ReadInput();
        WriteOutput();
    }

    static void ReadInput()
    {
        number = int.Parse(Console.ReadLine());
        dances = new string[number];

        for (int i = 0; i < number; i++)
        {
            dances[i] = Console.ReadLine();
        }
    }

    static void WriteOutput()
    {
/*        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                Console.WriteLine(GetColor(i, j));
            }
        } */

        for (int i = 0; i < number; i++)
        {
            Dance(dances[i]);
            Console.WriteLine(GetColor(row, col));
        }
    }

    static string GetColor(int r, int c)
    {
        if (r == 1 && c == 1)
            return "GREEN";

        if (r != 1 && c != 1)
            return "RED";

        return "BLUE";
    }

    static void Dance(string steps)
    {
        bool moveInRow = false;
        bool moveInColumn = true;
        int move = -1;

        row = 1;
        col = 1;

        foreach (char step in steps)
        {
            switch (step)
            {
                case 'L' :
                    if (moveInRow)
                    {
                        move = 0 - move;
                    }

                    moveInColumn = !moveInColumn;
                    moveInRow = !moveInRow;

                    break;
                case 'R' :
                    if (moveInColumn)
                    {
                        move = 0 - move;
                    }

                    moveInColumn = !moveInColumn;
                    moveInRow = !moveInRow;

                    break;
                case 'W' :
                    if (moveInRow)
                    {
                        col += move;
                        if (col < 0) col = 2;
                        if (col > 2) col = 0;
                    }
                    else
                    {
                        row += move;
                        if (row < 0) row = 2;
                        if (row > 2) row = 0;
                    }
                    break;
            }
        }

    }
}