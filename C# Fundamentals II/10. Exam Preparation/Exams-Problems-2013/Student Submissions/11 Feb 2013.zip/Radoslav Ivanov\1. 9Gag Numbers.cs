using System;
using System.Text;

class Program
{
    static int pow(int a, int b)//A^b
    {
        int y = a;
        for (int i =2; i <= b; i++)
        {
            y *= a;
        }
        return y;
    }
    static void Main()
    {
        
        string digit = Console.ReadLine();
        const string zerro = "-!";
        const string one = "**";
        const string two = "!!!";
        const string three = "&&";
        const string four = "&-";
        const string five = "!-";
        const string six = "*!!!";
        const string seven = "&*!";
        const string eight = "!!*!-";
        switch (digit)
        {
            case zerro: Console.WriteLine(0);return ; break;
            case one: Console.WriteLine(1); return; break;
            case two: Console.WriteLine(2); return; break;
            case three: Console.WriteLine(3); return; break;
            case four: Console.WriteLine(4); return; break;
            case five: Console.WriteLine(5); return; break;
            case six: Console.WriteLine(6); return; break;
            case seven: Console.WriteLine(7); return; break;
            case eight: Console.WriteLine(8); return; break;
            default:
                break;
        }
        if (digit.CompareTo( "**!!!") == 0) Console.WriteLine(15);
        else if (digit.CompareTo("!!!**!" ) == 0)
        {
            Console.WriteLine(176);
        }
        else if (digit.CompareTo("!!**!--!!-") == 0)
        {
            Console.WriteLine(653);
        }
    }
}
