using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KukataIsDancing
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine()); //Number of performed dances
            for (int i = 0; i <= N; i++)
            {
                string moves = Console.ReadLine();
            }
          
        }
    }
}
