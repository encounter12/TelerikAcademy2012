using System;
using System.Collections.Generic;
using System.Text;

class GagNumbers
{
    static void Main()
    {
        StringBuilder digits = new StringBuilder();
        string givenNumber = Console.ReadLine();       
        int counter = 0;
        int sum = 0;
        string finalNumber = null;
        List<int> num = new List<int>();


        for (int i = givenNumber.Length - 1; i >= 0; i--)
        {
            digits.Insert(0, givenNumber[i]);
            finalNumber = digits.ToString();
            switch (finalNumber)
            {
                case "-!":
                    num.Add(0);
                    counter++;
                    digits.Clear();
                    break;
                case "**":
                    num.Add(1);
                    counter++;
                    digits.Clear();
                    break;
                case "!!!":
                    num.Add(2);
                    counter++;
                    digits.Clear();
                    break;
                case "&&":
                    num.Add(3);
                    counter++;
                    digits.Clear();
                    break;
                case "&-":
                    num.Add(4);
                    counter++;
                    digits.Clear();
                    break;
                case "!-":
                    if (givenNumber[i - 1] != '*')
                    {
                        num.Add(5);
                        counter++;
                        digits.Clear();
                    }
                    break;
                case "*!!!":
                    num.Add(6);
                    counter++;
                    digits.Clear();
                    break;
                case "&*!":
                    num.Add(7);
                    counter++;
                    digits.Clear();
                    break;
                case "!!**!-":
                    num.Add(8);
                    counter++;
                    digits.Clear();
                    break;
            }

        }

        for (int i = 0; i < num.Count; i++)
        {
            sum += num[i] * Convert.ToInt32(Math.Pow(9, i));

        }
        Console.WriteLine(sum);
    }

}

