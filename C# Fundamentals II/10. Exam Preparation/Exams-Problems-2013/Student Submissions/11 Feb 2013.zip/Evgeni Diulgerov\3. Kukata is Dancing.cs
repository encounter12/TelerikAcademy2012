using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());

            string[, ,] cube = new string[3, 3, 3];
            cube[0, 0, 0] = "R";
            cube[0, 0, 1] = "B";
            cube[0, 0, 2] = "R";

            cube[0, 1, 0] = "B";
            cube[0, 1, 1] = "G";
            cube[0, 1, 2] = "B";

            cube[0, 2, 0] = "R";
            cube[0, 2, 1] = "B";
            cube[0, 2, 2] = "R";


            cube[1, 0, 0] = "B";
            cube[1, 0, 1] = "G";
            cube[1, 0, 2] = "B";

            cube[1, 1, 0] = "G";
            cube[1, 1, 1] = "B";
            cube[1, 1, 2] = "G";

            cube[1, 2, 0] = "B";
            cube[1, 2, 1] = "G";
            cube[1, 2, 2] = "B";

            cube[2, 0, 0] = "R";
            cube[2, 0, 1] = "B";
            cube[2, 0, 2] = "R";

            cube[2, 1, 0] = "B";
            cube[2, 1, 1] = "G";
            cube[2, 1, 2] = "B";

            cube[2, 2, 0] = "R";
            cube[2, 2, 1] = "B";
            cube[2, 2, 2] = "R";

            List<string> dances = new List<string>();
            for (int i = 0; i < N; i++)
            {
                dances.Add(Console.ReadLine());
            }

            List<string> stops = GetStops(dances,cube);

            foreach (string s in stops)
            {
                if (s == "G")
                {
                    Console.WriteLine("GREEN");
                }

                if (s == "R")
                {
                    Console.WriteLine("RED");
                }

                if (s == "B")
                {
                    Console.WriteLine("BLUE");
                }
            }
        }

        public static List<string> GetStops(List<string> dances, string[,,] cube)
        {
            List<string> stops = new List<string>();

            int curPosZ = 0;
            int curPosY = 1;
            int curPosX = 1;

            

            int posibleZ = 0;
            int posibleY = 0; 
            int posibleX = 0;

            bool up = true;
            bool down = false;
            bool left = false;
            bool right = false;
            bool lastWalk = false;
            string direction = "Y";
            foreach (string str in dances)
            {
                for (int i = 0; i<str.Length; i++)
                {
                    if (str[i] == 'L')
                    {
                        
                            if (left)
                            {
                                posibleZ = curPosZ;
                                posibleX = curPosX;
                                if (curPosY != 0)
                                {
                                    posibleY = curPosY - 1;
                                }
                                else
                                {
                                    posibleY = 2;
                                }

                                left = false;
                                right = false;
                                up = false;
                                down = true;
                            }

                            if (right)
                            {
                                posibleZ = curPosZ;
                                posibleX = curPosX;
                                if (curPosY != 2)
                                {
                                    posibleY = curPosY + 1;
                                }
                                else
                                {
                                    posibleY = 0;
                                }

                                left = false;
                                right = false;
                                up = true;
                                down = false;
                            }

                            if (down)
                            {
                                posibleZ = curPosZ;
                                posibleY = curPosY;
                                if (curPosX != 2)
                                {
                                    posibleX = curPosX + 1;
                                }
                                else
                                {
                                    posibleX = 0;
                                }

                                left = false;
                                right = true;
                                up = false;
                                down = false;
                            }

                            if (up)
                            {
                                posibleZ = curPosZ;
                                posibleY = curPosY;
                                if (curPosX != 0)
                                {

                                    posibleX = curPosX - 1;
                                }
                                else
                                {
                                    posibleX = 2;
                                }

                                left = true;
                                right = false;
                                up = false;
                                down = false;
                            }  
                    }
                    else if (str[i] == 'R')
                    {
                            if (right)
                            {
                                posibleZ = curPosZ;
                                posibleX = curPosX;
                                if (curPosY != 2)
                                {

                                    posibleY = curPosY + 1;
                                }
                                else
                                {
                                    posibleY = 0;
                                }
                                left = false;
                                right = false;
                                up = false;
                                down = true;
                            }

                            if (left)
                            {
                                posibleZ = curPosZ;
                                posibleX = curPosX;
                                if (curPosY != 0)
                                {
                                    posibleY = curPosY - 1;
                                }
                                else
                                {
                                    posibleY = 2;
                                }

                                left = false;
                                right = false;
                                up = true;
                                down = false;
                            }
                       
                            if (up)
                            {
                                posibleZ = curPosZ;
                                posibleY = curPosY;
                                if (curPosY != 0)
                                {
                                    posibleX = curPosX - 1;
                                }
                                else
                                {
                                    posibleX = 2;
                                }

                                left = false;
                                right = true;
                                up = false;
                                down = false;
                            }

                            if (down)
                            {
                                posibleZ = curPosZ;
                                posibleY = curPosY;
                                if (curPosX != 2)
                                {
                                    posibleX = curPosX + 1;
                                }
                                else
                                {
                                    posibleX = 0;
                                }

                                left = true;
                                right = false;
                                up = false;
                                down = false;
                            }
                    }
                    else if (str[i] == 'W')
                    {
                        if (i == 0)
                        {
                            curPosY = 0;
                        }
                        else
                        {
                                curPosX = posibleX;
                                curPosY = posibleY;
                                curPosZ = posibleZ;

                        }
                    }
                }

                stops.Add(cube[curPosZ, curPosY, curPosX]);
            }


            return stops;
        }
    }
}
