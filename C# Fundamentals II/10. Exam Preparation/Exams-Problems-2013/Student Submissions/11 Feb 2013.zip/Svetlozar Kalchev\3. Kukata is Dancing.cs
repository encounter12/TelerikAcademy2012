using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Task_3___Kukata
{
    class Program
    {
        static void Main(string[] args)
        {
            // Input the number of dances
            int moves = int.Parse(Console.ReadLine());
            // Input each sequence as a string array member
            string[] input = new string[moves];
            for (int i = 0; i < input.Length; i++) // Populate the array
            {
                input[i] = Console.ReadLine();
            }
            char[] ch = input[0].ToCharArray();
            for (int i = 0; i < moves; i++)
            {
                if (ch.Contains<char>('W') && ch.Contains<char>('L'))
                {
                    Console.WriteLine("RED");
                }
                else if (!(ch.Contains<char>('W')))
                {
                    Console.WriteLine("GREEN");
                }
                else if (ch.Contains<char>('W') && ch.Contains<char>('R'))
                {
                    Console.WriteLine("BLUE");
                }
            }
            
           
            }
           
        }
    }



 