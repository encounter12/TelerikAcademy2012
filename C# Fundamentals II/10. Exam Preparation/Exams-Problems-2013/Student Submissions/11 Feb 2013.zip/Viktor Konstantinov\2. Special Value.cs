using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs2
{
    class Program
    {
        static int rnd = 1;
        static int findval(int i, int j, int[,] table, int n, int[,] v, int[,] r)
        {
            /*Console.Write("--findval: ");
            Console.Write(i);
            Console.Write(", ");
            Console.WriteLine(j);*/
            int ii = (i + 1) % n;
            if (table[i,j] < 0) return -table[i,j];
            if (v[i,j] == rnd) return -1000000000;
            v[i,j] = rnd;

            int h;
            if (r[ii, table[i,j]] != -12243324)
                h = r[ii, table[i,j]];
            else
            {
                h = findval(ii, table[i,j], table, n, v, r);
                r[ii, table[i,j]] = h;
            }

            return 1 + h;
        }
        
        static void Main(string[] args)
        {
            int[,] v = new int[1100, 1100];
            int[,] r = new int[1100, 1100];
            int fl = 0;
            int n;
            int.TryParse(Console.ReadLine(), out n);
            int[,] table = new int[1100, 1100];
            for (int i = 0; i < n; i++)
            {
                String line = Console.ReadLine();
                int j = 0;
                int jj = 0;
                while (line.IndexOf(',',j) >= 0)
                {
                    int a;
                    int.TryParse(line.Substring(j, line.IndexOf(',',j) - j), out a);
                    table[i,jj]=a;
                    jj++;
                    j = line.IndexOf(',',j)+1;
                }
                int aa;
                int.TryParse(line.Substring(j,line.Length-j), out aa);
                table[i,jj]=aa;
                if (i == 0) fl = jj + 1;
            }


            for (int p = 0; p < 1100; p++)
                for (int q = 0; q < 1100; q++)
                {
                    r[p, q] = -12243324;
                    v[p, q] = 0;

                }

            int max = 0;
            for (int j = 0; j < fl; j++)
            {
                int m = findval(0, j, table, n, v,r)+1;
                if (m > max) max = m;
                rnd++;
            }
            Console.WriteLine(max);
        }
    }
}
