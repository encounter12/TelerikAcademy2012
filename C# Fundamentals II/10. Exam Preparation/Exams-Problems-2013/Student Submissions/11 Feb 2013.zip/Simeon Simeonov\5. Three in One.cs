using System;

//{}
//[]

class Task5
{
    static int GetWinnerIndex (string [] points)
    {
        byte indexWinner = 0;
        byte pointsWinner = byte.MinValue;
        byte index = 0;
        byte countWinners = 0;
        while ((pointsWinner < 21) && (index < points.Length))
        {
            byte currentPoints = byte.Parse(points[index]);
            if ((currentPoints <= 21) && (pointsWinner < currentPoints))
            {
                pointsWinner = currentPoints;
                indexWinner = index;
                countWinners = 1;
            }
            else if (pointsWinner == currentPoints)
            {
                countWinners = 2;
            }
            index++;
        }

        if (countWinners == 1)
        {
            return indexWinner;
        }
        else
        {
            return -1;
        }
    }

    static byte GetMyBites(byte[] cakes, byte friends)
    {
        friends++;
        byte[] friendBites = new byte[friends];
        byte index = 0;

        for (int i = 0; i < cakes.Length; i++)
        {
            friendBites[index] += cakes[i];
            index = (byte)((index + 1) % friends);
        }

        return friendBites[0];
    }

    static int GetBeerMoney(int[] moneyInt)
    {
        if ((moneyInt[0]==moneyInt[3])&&
            (moneyInt[1]==moneyInt[4])&&
            (moneyInt[2]==moneyInt[5]))
        {
            return 0;
        }
        else
        {
            int exchanges = 0;
            int extraGold = moneyInt[0] - moneyInt[3];
            int extraSilver = moneyInt[1] - moneyInt[4];
            int extraBronze = moneyInt[2] - moneyInt[5];

            //Fix gold
            if (extraGold < 0)
            {
                int neededGold = -extraGold * 121;
                if ((extraSilver / 11 + extraBronze/121) < -extraGold)
                {
                    return -1;
                }
                else
                {
                    if (extraSilver > 0)
                    {
                        int silverForGold = neededGold / 11;
                        if (neededGold % 11 > 0)
                        {
                            silverForGold++;
                        }

                        if (extraSilver < silverForGold)
                        {
                            exchanges += extraSilver / 11;
                            neededGold -= extraSilver / 11;
                            extraSilver = 0;
                        }
                        else
                        {
                            exchanges += silverForGold / 11;
                            neededGold = 0;
                            extraSilver -= silverForGold;
                        }
                    }

                    if ((neededGold>0) && (extraBronze > 0))
                    {
                        int bronzForGold = neededGold;

                        if (extraBronze < bronzForGold)
                        {
                            exchanges += extraBronze / 11 + extraBronze / 121;
                            neededGold -= extraBronze;
                            extraBronze = 0;
                        }
                        else
                        {
                            exchanges += bronzForGold / 11 + bronzForGold / 121;
                            neededGold = 0;
                            extraBronze -= bronzForGold;
                        }
                    }
                }

                extraGold = -neededGold / 121 - neededGold % 121;
            }

            if (extraGold < 0)
            {
                return -1;
            }

            if (extraSilver < 0)
            {
                int neededSilver = -extraSilver * 11;
                if ((extraGold * 9 + extraBronze / 11) < -extraSilver)
                {
                    return -1;
                }
                else
                {
                    if (extraGold > 0)
                    {
                        int goldForSilver = neededSilver / 99;

                        if (neededSilver % 99 > 0)
                        {
                            goldForSilver++;
                        }

                        if (extraGold < goldForSilver)
                        {
                            exchanges += extraGold;
                            neededSilver -= extraGold * 99;
                            extraGold = 0;
                        }
                        else
                        {
                            exchanges += goldForSilver;
                            neededSilver -= goldForSilver * 99;
                            extraGold -= goldForSilver;
                        }
                    }

                    if ((neededSilver > 0) && (extraBronze > 0))
                    {
                        int bronzForSilver = neededSilver * 11;

                        if (extraBronze < bronzForSilver)
                        {
                            exchanges += extraBronze / 11;
                            neededSilver -= extraBronze / 11;
                            extraBronze = 0;
                        }
                        else
                        {
                            exchanges += bronzForSilver / 11;
                            neededSilver -= bronzForSilver / 11;
                            extraBronze -= bronzForSilver;
                        }
                    }
                }

                extraSilver = -neededSilver / 11 - neededSilver % 11;
            }

            if (extraSilver < 0)
            {
                return -1;
            }

            if (extraBronze < 0)
            {
                int neededBronze = -extraBronze;
                if ((extraGold * 81 + extraSilver * 9) < neededBronze)
                {
                    return -1;
                }
                else
                {
                    if (extraGold > 0)
                    {
                        int goldForBronze = neededBronze / 81;

                        if (neededBronze % 81 > 0)
                        {
                            goldForBronze++;
                        }

                        if (extraGold < goldForBronze)
                        {
                            exchanges += extraGold * 81;
                            neededBronze -= extraGold * 81;
                            extraGold = 0;
                        }
                        else
                        {
                            exchanges += goldForBronze + goldForBronze * 9;
                            neededBronze -= goldForBronze * 81;
                            extraGold -= goldForBronze;
                        }
                    }

                    if ((neededBronze > 0) && (extraSilver > 0))
                    {
                        int silverForBronze = neededBronze / 9;

                        if (neededBronze % 9 > 0)
                        {
                            silverForBronze++;
                        }

                        if (extraSilver < silverForBronze)
                        {
                            exchanges += extraSilver;
                            neededBronze -= extraSilver * 9;
                            extraSilver = 0;
                        }
                        else
                        {
                            exchanges += silverForBronze;
                            neededBronze -= silverForBronze * 9;
                            extraSilver -= silverForBronze;
                        }
                    }
                }

                extraBronze = -neededBronze;
            }

            if (extraBronze < 0)
            {
                return -1;
            }

            return exchanges;
        }
    }

    static void Main()
    {
        string [] points = Console.ReadLine().Split(',');

        //First part
        int winnerIndex = GetWinnerIndex(points);

        //Second part
        string[] cakes = Console.ReadLine().Split(',');
        byte friends = byte.Parse(Console.ReadLine());
        byte[] cakesByte = new byte[cakes.Length];

        for (int i = 0; i < cakes.Length; i++)
        {
            cakesByte[i] = byte.Parse(cakes[i]);
        }

        Array.Sort(cakesByte);
        Array.Reverse(cakesByte);

        byte myBites = GetMyBites(cakesByte, friends);
        
        //Third part
        string[] money = Console.ReadLine().Split(' ');

        int[] moneyInt = new int[money.Length];

        for (int i = 0; i < money.Length; i++)
        {
            moneyInt[i] = int.Parse(money[i]);
        }

        int beerMoney = GetBeerMoney(moneyInt);

        Console.WriteLine(winnerIndex);
        Console.WriteLine(myBites);
        Console.WriteLine(beerMoney);
    }
}
