using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kukata
{
    class Kukata
    {
        static void Main(string[] args)
        {
            string[,] matrix = new string[800, 800];
            for (int rows = 0,k = 1; rows < matrix.GetLength(0); rows++)
            {
                if (rows != k)
                {
                    for (int cols = 0, j = 1; cols < matrix.GetLength(1); cols++)
                    {
                        if (cols != j)
                        {
                            matrix[rows, cols] = "RED";
                        }
                        else
                        {
                            matrix[rows, cols] = "BLUE";
                            j = j + 3;
                        }
                    }
                }
                else
                {
                    for (int colsPrim = 0, f = 1; colsPrim < matrix.GetLength(0); colsPrim++)
                    {
                        if (colsPrim != f)
                        {
                            matrix[rows, colsPrim] = "BLUE";
                        }
                        else
                        {
                            matrix[rows, colsPrim] = "GREEN";
                            f = f + 3;
                        }
                    }
                    k = k + 3;
                }
            }
            
            int number = int.Parse(Console.ReadLine());
            string[] commands = new string[number];

            for (int i = 0; i < number; i++)
            {
                commands[i] = Console.ReadLine();
            }
            
            for (int i = 0; i < number; i++)
            {
                bool moveCols = true;
                bool moveLeft = false;
                bool moveRight = false;
                bool moveRows = false;
                int initRow = 400;
                int initCol = 400;
                string result = commands[i];
                foreach (var item in result)
                {
                    if (item == 'W' && moveCols == true)
                    {
                        initCol = initCol + 1;
                    }
                    else if (item == 'W' && moveRows == true )
                    {
                        if (moveLeft == true)
                        {
                            initRow = initRow - 1;
                        }
                        else
                        {
                            initRow = initRow + 1;
                        }
                        
                    }
                    else if (item == 'L')
                    {
                        moveLeft = true;
                        moveCols = !moveCols;
                        moveRows = !moveRows;
                        moveRight = false;
                        
                    }
                    else if (item == 'R')
                    {
                        moveRight = true;
                        moveCols = !moveCols;
                        moveRows = !moveRows;
                        moveLeft = false;
                    }
                }
                Console.WriteLine(matrix[initRow, initCol]);
            }
        }
    }
}