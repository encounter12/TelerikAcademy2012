using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeInOne
{
    class ThreeTasks
    {
        static void Main()
        {
            string blackJackPoints = Console.ReadLine();
            string cakeBites = Console.ReadLine();
            int friends = int.Parse(Console.ReadLine());
            string money = Console.ReadLine();
            Console.WriteLine(BlackJackWinner(blackJackPoints));
            Console.WriteLine(MyCakeBites(cakeBites, friends));
            Console.WriteLine(DoIHaveMoneyForBeer(money)); 
        }
        static int BlackJackWinner(string blackJackPoints)
        {
            string[] pointsArr = blackJackPoints.Split(',');
            int[] intPoints = new int[pointsArr.Length];
            for (int i = 0; i < pointsArr.Length; i++)
            {
                intPoints[i] = int.Parse(pointsArr[i]);
            }
            int maxPoints = 0;
            int index = -1;
            for (int i = 0; i < pointsArr.Length; i++)
            {
                if (intPoints[i] > 21)
                {
                    continue;
                }
                if (maxPoints < intPoints[i])
                {
                    maxPoints = intPoints[i];
                    index = i;
                }
                else if (maxPoints == intPoints[i])
                {
                    index = -1;
                }
            }
            return index; 
        }
        static int MyCakeBites(string cakebites, int friends)
        {
            string[] cakeBitesStr = cakebites.Split(',');
            int[] cakeBites = new int[cakeBitesStr.Length];
            for (int i = 0; i < cakeBitesStr.Length; i++)
            {
                cakeBites[i] = int.Parse(cakeBitesStr[i]);
            }
            int numOfPicks = (cakeBites.Length / (friends + 1)) + 1;
            int myBites = 0;
            int maxByte = 0;
            int index = 0;
            for (int i = 0; i < numOfPicks; i++)
            {             
                for (int j = 0; j < friends + 1; j++)                   
                {
                    maxByte = cakeBites[0];
                    index = 0;
                    for (int k = 0; k < cakeBites.Length; k++)
                    {
                        if (cakeBites[k] == 0)
                        {
                            continue;
                        }
                        if (maxByte < cakeBites[k])
                        {
                            maxByte = cakeBites[k];
                            index = k;
                        }
                    }
                    if (maxByte == 0)
                    {
                        break;
                    }
                    if (j == 0)
                    {
                        myBites += maxByte;
                    }
                    cakeBites[index] = 0;
                }
                if (maxByte == 0)
                {
                    break;
                }
            }
            return myBites;
        }
        static int DoIHaveMoneyForBeer(string money)
        {
            string[] moneyStrArr = money.Split(' ');
            int[] moneyArr = new int[moneyStrArr.Length];
            int count = 0;
            int exchange = 0;
            for (int i = 0; i < moneyStrArr.Length; i++)
            {
                moneyArr[i] = int.Parse(moneyStrArr[i]);                
            }
            for (int i = 0; i < 3; i++)
            {
                if ((moneyArr[i] == 0)||(moneyArr[i] == 0))
                {
                    continue;
                }
                if (moneyArr[i] < moneyArr[i+3])
                {
                    moneyArr[i + 3] -= moneyArr[i];
                    moneyArr[i] = 0;
                }
                else
	            {
                    moneyArr[i] -= moneyArr[i + 3];
                    moneyArr[i + 3] = 0;
	            }
            }
            if (((moneyArr[0] == 0)&&(moneyArr[1] == 0)&&(moneyArr[2] == 0))&&
                ((moneyArr[3] != 0) || (moneyArr[4] != 0) || (moneyArr[5] != 0)))
            {
                return -1;
            }
            if (moneyArr[3] != 0)
            {
                if (moneyArr[1] != 0)
                {                    
                    exchange = moneyArr[1] / 11;
                    for (int i = 0; i < exchange; i++)
                    {
                        if (moneyArr[3] == 0)
                        {
                            break;
                        }
                        moneyArr[3] -= 1;
                        moneyArr[1] -= 11;
                        count++;
                    }
                                       
                }                  
                if ((moneyArr[2] != 0)&&(moneyArr[3] != 0))
                {
                    exchange = moneyArr[2] / 121;
                    for (int i = 0; i < exchange; i++)
                    {
                        if (moneyArr[3] == 0)
                        {
                            break;
                        }
                        moneyArr[3] -= 1;
                        moneyArr[2] -= 121;
                        count+=12;
                    }
                    if ((moneyArr[1] != 0)&&(moneyArr[3] != 0))
                    {
                        exchange = moneyArr[3] / 11;
                        for (int i = 0; i < exchange; i++)
                        {
                            moneyArr[1]++;
                            moneyArr[2] -= 11;
                        }
                        if (moneyArr[1] >10)
                        {
                            moneyArr[3]--;
                        }
                    }
                }
                    
            }
            if (moneyArr[4] != 0)
            {
                if (moneyArr[1] != 0)
                {
                    moneyArr[4] -= moneyArr[1];
                }
                if (moneyArr[0] != 0)
                {
                    if (moneyArr[4] < 9)
                    {
                        count++;
                        moneyArr[0]--;
                        moneyArr[1] += 9 - moneyArr[4];
                        moneyArr[4] = 0;
                    }
                    exchange = moneyArr[4] / 9;
                    for (int i = 0; i < exchange; i++)
                    {
                        if (moneyArr[0] == 0)
                        {
                            break;
                        }
                        moneyArr[4] -= 9;
                        moneyArr[1] -= 1;
                        count++;
                    }
                }                  
                if ((moneyArr[2] != 0)&&(moneyArr[4] !=0))
                {                  
                    exchange = moneyArr[2] / 11;
                    for (int i = 0; i < exchange; i++)
                    {
                        if (moneyArr[4] == 0)
                        {
                            break;
                        }
                        moneyArr[4] -= 1;
                        moneyArr[2] -= 11;
                        count++;
                    }
                }                  
            }
            if (moneyArr[5] != 0)
            {
                
                if (moneyArr[1] != 0)
                {
                    if (moneyArr[5] < 9)
                    {
                        count++;
                        moneyArr[5] = 0;
                    }
                    exchange = moneyArr[5] / 9;
                    for (int i = 0; i < exchange; i++)
                    {
                        if (moneyArr[1] == 0)
                        {
                            break;
                        }
                        moneyArr[5] -= 9;
                        moneyArr[1] -= 1;
                        count++;
                    }
                }      
                if ((moneyArr[0] != 0)&&(moneyArr[5] != 0))
                {
                    
                    exchange = moneyArr[5] / 81;
                    for (int i = 0; i < exchange; i++)
                    {
                        if (moneyArr[0] == 0)
                        {
                            break;
                        }
                        moneyArr[5] -= 81;
                        moneyArr[0] -= 1;
                        count+= 10;
                    }
                    if ((moneyArr[5] < 81)&&(moneyArr[0] != 0)||(moneyArr[1] != 0))
                    {
                        if ((moneyArr[0] != 0)&&(moneyArr[1] <= 0))
                        {
                            moneyArr[0]--;
                            moneyArr[1] += 9;
                            count++;
                        }
                        count++;
                        moneyArr[0]--;
                        moneyArr[1] += 9;
                        int counterIn = 0;
                        while (moneyArr[5] > 0)
                        {
                            counterIn++;
                            moneyArr[5]--;
                            if ((counterIn % 9) == 0)
                            {
                                count++;
                                moneyArr[1]--;
                            }
                        }
                    }
                }                   
                             
                if (moneyArr[5] > 0)
                {
                    if (moneyArr[0] != 0)
                    {
                        count += 2;
                        moneyArr[5] = 0;
                    }
                    if (moneyArr[1] != 0)
                    {
                        count ++;
                        moneyArr[5] = 0;
                    }
                }
            }                           
            if ((moneyArr[3] != 0) || (moneyArr[4] != 0) || (moneyArr[5] != 0))
            {
                return -1;
            }
            else
            {
                return count;
            }
        }
    }
}
