using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());

        string[] input = new string[n];
        for (int i = 0; i < n; i++)
        {
            input[i] = Console.ReadLine();
        }

        for (int j = 0; j < 5; j++)
        {
            for (int i = 0; i < n; i++)
            {
                input[i] = ClearTags(input[i]);                
            }
        }
        foreach (var line in input)
        {
            Console.WriteLine(line);
        }
    }

    static string ClearTags(string input)
    {
        MatchCollection inners = Regex.Matches(input, @"<\w+>[^<]*</\w+>");
        foreach (var inner in inners)
        {
            if (inner.ToString().Contains("<del>"))
            {
                input = input.Replace(inner.ToString(), "");
            }

            if (inner.ToString().Contains("<upper>"))
            {
                input = input.Replace(inner.ToString(),
                                            (inner.ToString().Substring(7, inner.ToString().Length - 15)).ToUpper());
            }

            if (inner.ToString().Contains("<lower>"))
            {
                input = input.Replace(inner.ToString(),
                                            (inner.ToString().Substring(7, inner.ToString().Length - 15)).ToLower());
            }

            if (inner.ToString().Contains("<rev>"))
            {
                if (inner.ToString().Contains(Environment.NewLine))
                {
                 input = input.Replace(inner.ToString(), revString(inner.ToString().Substring(5, inner.ToString().Length - 7)));    
                }
                else input = input.Replace(inner.ToString(), revString(inner.ToString().Substring(5, inner.ToString().Length - 11)));
            }

            if (inner.ToString().Contains("<toggle>"))
            {
                input = input.Replace(inner.ToString(),
                                            toggleString(inner.ToString().Substring(8, inner.ToString().Length - 17)));
            }
        }
        return input;
    }

    static string revString(string reverseMe)
    {
        char[] arr = reverseMe.ToCharArray();
        Array.Reverse(arr);
        return new string(arr);
    }

    static string toggleString(string toggleMe)
    {
        string toggled = "";
        for (int i = 0; i < toggleMe.Length; i++)
        {
            if (toggleMe[i] <= 'Z') toggled+=toggleMe[i].ToString().ToLower();
            else toggled += toggleMe[i].ToString().ToUpper();
        }
        return toggled;
    }
}