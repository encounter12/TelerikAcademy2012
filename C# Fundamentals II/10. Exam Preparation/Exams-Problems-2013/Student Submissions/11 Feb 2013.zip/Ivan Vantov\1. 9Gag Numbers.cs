using System;
using System.Text;

  class _9GagNumbers
  {
    
    static void Main ()
    {

      int decimalDigit;
      int result = 0;
      int powerOfNine = 1;

      int startIndex = 0;
      int strLength;
      string digit;
       
      string str = Console.ReadLine();

      strLength = str.Length;

      str = ReverseString(str);

      // Console.WriteLine("9gag number = {0}", str);

      try
      {

        while (startIndex + 1 < strLength)
        {

          if (strLength - startIndex < 6)
          {
            goto Check4;
          }

          // Eight

          digit = str.Substring(startIndex, 6);

          if (digit == "-!**!!")
          {
            decimalDigit = 8;
            result += decimalDigit * powerOfNine;
            powerOfNine = powerOfNine * 9;
            startIndex = startIndex + 6;
            continue;
          }

Check4:

          if (strLength - startIndex < 4)
          {
            goto Check3;
          }
          
          // Six

          digit = str.Substring(startIndex, 4);

          if (digit == "!!!*")
          {
            decimalDigit = 6;
            result += decimalDigit * powerOfNine;
            powerOfNine = powerOfNine * 9;
            startIndex = startIndex + 4;
            continue;
          }

Check3:

          if (strLength - startIndex < 3)
          {
            goto Check2;
          }

          // Two or seven

          digit = str.Substring(startIndex, 3);

          if (digit == "!!!")
          {
              decimalDigit = 2;
              result += decimalDigit * powerOfNine;
              powerOfNine = powerOfNine * 9;
              startIndex = startIndex + 3;
              continue;
          }

          if (digit == "!*&")
          {
              decimalDigit = 7;
              result += decimalDigit * powerOfNine;
              powerOfNine = powerOfNine * 9;
              startIndex = startIndex + 3;
              continue;
          }

Check2:

          // Zero or one or three or four or five

          digit = str.Substring(startIndex, 2);

          if (digit == "!-")
          {
              decimalDigit = 0;
              result += decimalDigit * powerOfNine;
              powerOfNine = powerOfNine * 9;
              startIndex = startIndex + 2;
              continue;
          }

          if (digit == "**")
          {
              decimalDigit = 1;
              result += decimalDigit * powerOfNine;
              powerOfNine = powerOfNine * 9;
              startIndex = startIndex + 2;
              continue;
          }

          if (digit == "&&")
          {
              decimalDigit = 3;
              result += decimalDigit * powerOfNine;
              powerOfNine = powerOfNine * 9;
              startIndex = startIndex + 2;
              continue;
          }

          if (digit == "-&")
          {
              decimalDigit = 4;
              result += decimalDigit * powerOfNine;
              powerOfNine = powerOfNine * 9;
              startIndex = startIndex + 2;
              continue;
          }

          if (digit == "-!")
          {
              decimalDigit = 5;
              result += decimalDigit * powerOfNine;
              powerOfNine = powerOfNine * 9;
              startIndex = startIndex + 2;
              continue;
          }

        }

      }

      catch (ArgumentOutOfRangeException e)
      {
        // Console.WriteLine(e.Message);
      }         

      Console.WriteLine("{0}", result);
      // Console.WriteLine("{0}", powerOfNine);

    }


    public static string ReverseString (string s)
    {
      StringBuilder sb = new StringBuilder();
      for (int i = s.Length - 1; i >= 0; i--)
      {
        sb.Append(s[i]);
      }
      return sb.ToString();
    }

  }
