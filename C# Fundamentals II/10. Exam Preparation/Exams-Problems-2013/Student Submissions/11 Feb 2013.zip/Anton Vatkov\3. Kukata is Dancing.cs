using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KukataDancing
{
    
    class Program
    {
        public  const byte cubeW = 3;
        public  const byte cubeH = 3;
        public  const byte cubeD = 3;
        public  const string colorB="BLUE";
        public  const string colorR="RED";
        public  const string colorG="GREEN";
        public const bool left = false;
        public const bool rigth = false;

        
        //private static char[] LineCommandReaderAndJoinerInCharArray(string moveSequance)
        //{
          //  StringBuilder moveCommands = new StringBuilder();
            
          //  for (int i = 0; i < moveSequance.Length; i++)
          //  {
          //      char[] commands = new char[moveCommands.Length];
          //      commands[i] = moveSequance[i];
         //   return  commands;
        //    }
      //  }

        public static void KukataPosition()
        {

        }
        static void Main()
        {
            //read input data
            
            byte varMovesLines=byte.Parse(Console.ReadLine());
            
            //StringBuilder myCommands = new StringBuilder();
            //for (int i = 0; i < varMovesLines; i++)
            //{
                
                //myCommands.Append(line);
            //}
            //Console.WriteLine(myCommands);
            //lineCommandReaderAndJoinerInCharArray(moveSequance);
                byte currentW = 1;
                 byte currentH = 0;
                 byte currentD = 1;

            
          
            
            
            
            string[ , , ] specialCube = new string[cubeW, cubeH, cubeD];
            
            for (int h = 0; h <cubeW ; h++)
            {
                for (int w = 0; w < cubeH; w++)
                {
                    for (int d = 0; d < cubeD; d++)
                    {
                        specialCube[w,h,d]=colorB;
                        
                    }
                }
            }
            
            for (int h = 0; h < cubeW; h++)
            {
                for (int w = 0; w < cubeH; w++)
                {
                    for (int d = 0; d < cubeD; d++)
                    {
                        if ((w == 1) && (h == 1) && (d == 0))
                        {
                            specialCube[w, h, d] = colorG;
                        }
                        if (((w == 0) && (h == 1) && (d == 1)))
                        {
                            specialCube[w, h, d] = colorG;
                        }
                        if (((w == 2) && (h == 1) && (d == 1)))
                        {
                            specialCube[w, h, d] = colorG;
                        }
                        if ((w == 1) && (h == 0) && (d == 1))
                        {
                            specialCube[w, h, d] = colorG;
                        }
                        if (((w == 1) && (h == 2) && (d == 1)))
                        {
                            specialCube[w, h, d] = colorG;
                        }
                        if (((w == 1) && (h == 1) && (d == 2)))
                        {
                            specialCube[w, h, d] = colorG;
                        } 
                        if ((w==0)&&(h==0)&&(d==0))
	                    {
		                    specialCube[w,h,d]=colorR;
	                    }
                         if (((w==0)&&(h==2)&&(d==0)))
                         {
                             specialCube[w, h, d] = colorR;
                         }
                         if (((w==2)&&(h==0)&&(d==0)))
                         {
                             specialCube[w, h, d] = colorR;
                         }
                         if ((w == 0) && (h == 0) && (d == 2))
                         {
                             specialCube[w, h, d] = colorR;
                         }
                         if (((w == 0) && (h == 2) && (d == 2)))
                         {
                             specialCube[w, h, d] = colorR;
                         }
                         if (((w == 2) && (h == 0) && (d == 2)))
                         {
                             specialCube[w, h, d] = colorR;
                         }
                         
                    }
                }
            }

            //print input data
           //for (int w = 0; w < cubeW; w++)
           // {
            //for (int h = 0; h < cubeH; h++)
                 //{
                   //  for (int d = 0; d < cubeD; d++)
                    // {
                      //  Console.WriteLine("element{0}={1}",d,specialCube[w,h,d]);
                    // }
                // }
           // }
            
            string[ , , ] kukataPosition = new string[cubeW, cubeH, cubeD];
            kukataPosition[1, 0, 1]="kukata";
            StringBuilder code = new StringBuilder();
            for (int i = 0; i <varMovesLines ; i++)
            {
               string line = Console.ReadLine();
               code.Append(line);
               code.Append('|');
            }
            //string[] theDataLines=new string[varMovesLines];
            //string[] theDataLines=theDataLines.Split('|');
            //string line= c
            for (int w = 0; w < code.Length; w++)
            {
                if (code[w] == 'L')
                {
                    kukataPosition[currentW, currentH, currentD] = specialCube[currentW, currentH, currentD];
                    
                    bool left = true;
                }
                if (code[w] == 'R')
                {
                    kukataPosition[currentW, currentH, currentD] = specialCube[currentW, currentH, currentD];
                    
                    bool right = true;
                }
                if (code[w] == 'W')
                {

                    kukataPosition[currentW, currentH, currentD] = specialCube[currentW+1, currentH, currentD];
                    
                }
                if (code[w]=='|')
                {
                    Console.WriteLine(kukataPosition[currentW, currentH, currentD]);
                }
            }

            
            //Console.ReadKey();
        }
        
    }
}
