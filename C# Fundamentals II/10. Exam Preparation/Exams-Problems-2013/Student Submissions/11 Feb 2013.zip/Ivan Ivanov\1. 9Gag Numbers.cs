using System;
using System.Collections.Generic;
using System.Text;


    class Program
    {
        static void Main()
        {
            //!!**!--!!-!!**!--!!-!!**!-!!**!-!!**!-!!**!-!!**!-!!**!-
            //!!!**!-

            StringBuilder buffer = new StringBuilder();  // pitai dali sa 20 digits ili 20 chars
            char inputChar;
            string nextChar;
            int count = 0;
            List<int> listOfNums = new List<int>();
            decimal result = 0;
            

            while (true)
            {
                int token = Console.Read();
                inputChar = (char)token;
                nextChar = inputChar.ToString();
                buffer.Append(nextChar);

                if (token == 13)
                {
                    if (listOfNums.Count == 0) Console.WriteLine(0);

                    for (int i = 0; i < listOfNums.Count; i++)
                    {
                        result += listOfNums[i]*(decimal)Math.Pow(9, (listOfNums.Count - i - 1));
                        
                    }
                    Console.WriteLine(result);

                    break;
                }

                

                int checkForMatch = HaveMatch(buffer);

                if (checkForMatch >= 0)
                {
                    
                    count++;
                    listOfNums.Add(checkForMatch);
                                     
                    buffer.Clear();
                                      
                    
                }

                



            }

            
        }

        static int HaveMatch(StringBuilder buffer)
        {

            string check = buffer.ToString();

            switch (check)
            {
                case "-!": return 0; 
                case "**": return 1;
                case "!!!": return 2;
                case "&&": return 3;
                case "&-": return 4;
                case "!-": return 5;
                case "*!!!": return 6;
                case "&*!": return 7;
                case "!!**!-": return 8;
                default: return -1;  
                

            }


            
        }
        
    }
