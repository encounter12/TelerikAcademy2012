using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    
    class Program
    {
        static void Main()
        {
            StringBuilder input = new StringBuilder();
            input.Append(Console.ReadLine());

            Dictionary<string, int> dictionary = new Dictionary<string, int>();
            dictionary.Add("-!", 0);
            dictionary.Add("**", 1);
            dictionary.Add("!!!", 2);
            dictionary.Add("&&", 3);
            dictionary.Add("&-", 4);
            dictionary.Add("!-", 5);
            dictionary.Add("*!!!", 6);
            dictionary.Add("&*!", 7);
            dictionary.Add("!!**!-", 8);

            Dictionary<string, int> dictionary1 = new Dictionary<string, int>();
            dictionary1.Add("0", 0);
            dictionary1.Add("1", 1);
            dictionary1.Add("2", 2);
            dictionary1.Add("3", 3);
            dictionary1.Add("4", 4);
            dictionary1.Add("5", 5);
            dictionary1.Add("6", 6);
            dictionary1.Add("7", 7);
            dictionary1.Add("8", 8);
            dictionary1.Add("9", 9);

            StringBuilder str = new StringBuilder();
            string digits = "";
           
            string str1 = "";

            for (int i = input.Length - 1; i >= 0;  i--)
            {
                str.Append(input[i]);
                str1 = str.ToString();
                char[] chr = str1.ToCharArray();
                Array.Reverse(chr);
                str.Clear();
                foreach (char ch in chr)
                {
                    str.Append(ch);
                }
                str1 = str.ToString();

                if (dictionary.ContainsKey(str1))
                {
                    if (i > 1 || i == 0)
                    {
                        digits = digits + dictionary[str1];
                        str.Clear();
                    }


                }
            }
            double output =0 ;
            char[] digits_arr_char = digits.ToCharArray();
           
            for (int i = 0; i < digits_arr_char.Length; i++)
            {
               
                if (dictionary1.ContainsKey(digits_arr_char[i].ToString()))
                {
                    int k = dictionary1[digits_arr_char[i].ToString()];
                    output = output + k * Math.Pow(9, i);
                }
               
            }
          
            Console.WriteLine(output);
           
        }
    }
}
