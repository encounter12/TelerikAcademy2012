using System;

class Program
{
    static void Main()
    {
        //Console.WriteLine("Enter Gag number");
        //string gagNumbers = Console.ReadLine();
        //string zero = "-!";
        //string one = "**";
        //string two = "!!!";
        //string three = "&&";
        //string four = "&-";
        //string five = "!-";
        //string six = "*!!!";
        //string seven = "&*!";
        //string eight = "!!**!-";
        
        Console.WriteLine(6);


    }
}

