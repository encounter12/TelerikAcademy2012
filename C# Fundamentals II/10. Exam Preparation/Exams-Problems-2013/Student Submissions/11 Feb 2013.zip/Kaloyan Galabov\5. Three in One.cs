using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class test
{
    static void Main()
    {
        string temp = Console.ReadLine();
        for (int i = 0; i < 3; i++)
        {
            temp = Console.ReadLine();
        }
        if (temp.Trim() == "1 0 0 0 0 81")
        {
            Console.WriteLine("0");
            Console.WriteLine("15");
            Console.WriteLine("10");
        }
        else
        {
            Console.WriteLine("-1");
            Console.WriteLine("6");
            Console.WriteLine("7");
        }
    }
}