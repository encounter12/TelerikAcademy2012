using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem19GagNumbers
{
  class ProgramdigitOne 
  {
    static int GetLastDigit(string nineGagNumber, length)
    {
      int n = nineGagDigit.Length;
      int result = 0;
    lastDigit = nineGagNumber.Substring(n- length - 2, n - length);
      if (digitOne.Length == 2)
      {
      switch (digitOne)
      {
        case: "-!"
           {
             result = 0;
             break;
           }
        case: "**"
          {
            result = 1;
            break;
          }
        case:  "&&"
          {
            result = 3;
          }
        case: "&-"
          {
            result = 4;
          }
        case: "!-"
          {
            result = 5;
          }
       }
      
       }
      else digitOne = nineGagNumber.Sustring(n - 3, n);
      if (digitOne.Length == 3)
      {
        switch (digitOne)
        {
          case: "!!!"
          {
            result = 2;
          }
          case: "&*!"
          {
            result = 7;
          }
        }
        
      }
      else digitOne = nineGagNumber.Substring(n - 4, n);
      if (digitOne.Length == 4)
      {
        if (digitOne.Equals("*!!!"))
        {
        result = 6;
        }
        
      }
      else 
        digitOne = nineGagNumber.Substring(n - 5, n);
      if (giditOne.Length == 5)
      {
        if (digitOne.Equals("!!**!-"))
        {
          result = 8;
        }
       
      }
      return result;
    }
  
    static void Main(string[] args)
    {
      
  
      Srting nineGagNumber = Console.ReadLine();
      int nineGagNumberLength = n;
      int length = 0;
      int desimal = 0;
      int num = 0;
      byte baseOfNumber = 1;
      do {
        decimal = decimal + GetLastDigit(nineGagNumber, lenght)*baseOfNumber;
        baseOfNumber = baseOfNumber + 1;
        num = GetLastDigit(nineGagNumber, length);
        if ( (num == 0) || (num == 1) || (num == 3) || (num == 4) || (num == 5))
        {
          length = 2;
        }
        else if ((num == 2) || (num == 7))
        {
          lenght = 3;
        }
        else if (num == 6)
        {
          length = 4;
        }
        else length = 6;
      }
      nineGagNumberLength = nineGagNumber.Length - lenght;
      while (nineGagNumberLength > 0);
      Console.WriteLine("{0}", desimal);
    }
  }
}