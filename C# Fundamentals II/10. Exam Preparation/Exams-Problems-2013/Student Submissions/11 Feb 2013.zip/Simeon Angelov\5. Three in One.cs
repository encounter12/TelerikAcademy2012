using System;
using System.Collections.Generic;
using System.Text;

class ProblemFive
{
    static void Main()
    {
        string points = Console.ReadLine();
        string sizes = Console.ReadLine();
        int friends = int.Parse(Console.ReadLine());
        string numbers = Console.ReadLine();

        StringBuilder sb = new StringBuilder();
        List<int> extractedNums = new List<int>();

        //first problem

        foreach (char symbol in points)
        {
            if (!symbol.Equals(','))
            {
                sb.Append(symbol);
            }
            else
            {
                extractedNums.Add(Convert.ToInt32(sb));
            }
        }

        extractedNums.Add(Convert.ToInt32(sb));
        sb.Clear();

        int[] playersOrder = new int[extractedNums.Count];
        extractedNums.CopyTo(playersOrder);

        extractedNums.Sort();
        extractedNums.Reverse();

        int[] playersPoints = new int[extractedNums.Count];
        extractedNums.CopyTo(playersPoints);

        for (int i = 0; i < playersPoints.Length; i++)
        {
            if (playersPoints[i].Equals(playersPoints[i+1]) && ((playersPoints[i] <= 21)))
            {
                Console.WriteLine("-1");
                break;
            }
            else if ((playersPoints[i] > playersPoints[i+1]) && ((playersPoints[i] <= 21)))
            {
                FindMax(playersOrder, playersPoints[i]);
            }
        }
    }

    static int FindMax(int[] playersOrder, int x)
    {
        int index = 0;

        for (int i = 0; i < playersOrder.Length; i++)
        {
            if (playersOrder[i].Equals(x))
            {
                index = i;
                break;
            }
        }

        return index;
    }
}
