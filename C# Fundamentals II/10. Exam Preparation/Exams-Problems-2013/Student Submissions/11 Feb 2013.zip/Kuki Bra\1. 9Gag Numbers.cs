using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace examFeb11
{
    class Program
    {
        static void Main()
        {
            string[] numbers = {"-!","**","!!!","&&","&-","!-","*!!!","&*!","!!**!-"};

            string input = Console.ReadLine();

            StringBuilder currentNum = new StringBuilder();

            List<int> digits = new List<int>();


            for (int i = 0; i < input.Length; i++)
            {
                currentNum.Append(input[i].ToString());
                for (int k = 0; k < numbers.Length; k++)
                {
                    if (currentNum.ToString() == numbers[k])
                    {
                        digits.Add(k);
                        currentNum.Clear();
                    }
                }
            }

            int finalNumber = 0;

            digits.Reverse();

            for (int i = 0; i < digits.Count; i++)
            {
                finalNumber = finalNumber + digits[i] *(int)Math.Pow(9, i);
            }

            Console.WriteLine(finalNumber);

        }
    }
}
