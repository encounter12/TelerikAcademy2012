using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9GagNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string number = Console.ReadLine();
            for (int i = 0; i < number.Length; i++)
			{
			 char lastdigit=number[number.Length -1];
                char lastlastdigit = number[number.Length - 2];
                 Console.WriteLine(lastlastdigit + lastdigit);
			}
           
                

          
                 }
      
            }
  
    }
