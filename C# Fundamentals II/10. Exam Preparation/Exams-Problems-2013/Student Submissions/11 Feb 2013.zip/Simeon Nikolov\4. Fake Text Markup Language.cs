using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

class FTML
{
    static bool upper = false;
    static bool lower = false;
    static bool toggle = false;
    static bool del = false;
    static bool rev = false;

    static bool inTag = false;

    static int depth = 0;
    static int revDepth = 0;
    static Stack<int> lastIndex = new Stack<int>();
    static Stack<string> inner = new Stack<string>();

    static string upperStart = "<upper>";
    static string upperEnd = "</upper>";
    static string lowerStart = "<lower>";
    static string lowerEnd = "</lower>";
    static string toggleStart = "<toggle>";
    static string toggleEnd = "</toggle>";
    static string delStart = "<del>";
    static string delEnd = "</del>";
    static string revStart = "<rev>";
    static string revEnd = "</rev>";

    static int linesCount;
    static string[] textLines;

    static StringBuilder[] formatedTextLines;

    static StringBuilder[] toReverse;
   

    static void Main()
    {
        InputData();
        CountRevs();
        FormatText();

        for (int i = 0; i < formatedTextLines.Length; i++)
        {
            Console.WriteLine(formatedTextLines[i]);
        }
    }

    private static void CountRevs()
    {
        int index = -1;
        int count = 0;
        for (int i = 0; i < textLines.Length; i++)
        {
            index = textLines[i].IndexOf("<rev>", 0);
            while (index != -1)
            {
                count++;
                index = textLines[i].IndexOf("<rev>", index + 1);
            }
        }

        toReverse = new StringBuilder[count];
        for (int i = 0; i < count; i++)
        {
            toReverse[i] = new StringBuilder();
        }
    }

    private static void FormatText()
    {
        int fLine = 0;
        bool increaseLines = true;
        for (int line = 0; line < linesCount; line++)
        {
            for (int i = 0; i < textLines[line].Length; i++)
            {
                if (textLines[line][i] == '<')
                {
                    inTag = true;
                }

                if (textLines[line].Substring(i).StartsWith(upperStart))
                {
                    upper = true;
                    depth++;
                    inner.Push(upperStart);
                }
                else if (textLines[line].Substring(i).StartsWith(upperEnd))
                {
                    upper = false;
                    depth--;
                    inner.Pop();
                }
                else if (textLines[line].Substring(i).StartsWith(lowerStart))
                {
                    lower = true;
                    depth++;
                    inner.Push(lowerStart);
                }
                else if (textLines[line].Substring(i).StartsWith(lowerEnd))
                {
                    lower = false;
                    depth--;
                    inner.Pop();
                }
                else if (textLines[line].Substring(i).StartsWith(toggleStart))
                {
                    toggle = true;
                    depth++;
                    inner.Push(toggleStart);
                }
                else if (textLines[line].Substring(i).StartsWith(toggleEnd))
                {
                    toggle = false;
                    depth--;
                    inner.Pop();
                }
                else if (textLines[line].Substring(i).StartsWith(delStart))
                {
                    del = true;
                    depth++;
                    inner.Push(delStart);
                }
                else if (textLines[line].Substring(i).StartsWith(delEnd))
                {
                    del = false;
                    increaseLines = true;
                    depth--;
                    inner.Pop();
                }
                else if (textLines[line].Substring(i).StartsWith(revStart))
                {
                    rev = true;
                    revDepth++;
                    depth++;
                    inner.Push(revStart);
                }
                else if (textLines[line].Substring(i).StartsWith(revEnd))
                {
                    rev = false;
                    formatedTextLines[fLine].Append(Reverse(toReverse[revDepth - 1].ToString()));
                    revDepth--;
                    depth--;
                    inner.Pop();
                }


                if ((!inTag) && inner.Count > 0)
                {
                    string operation = inner.Peek();
                    if (operation == "<del>")
                    {
                        increaseLines = false; //premahva novi redove
                    }
                    else if (operation == "<rev>")
                    {
                        toReverse[revDepth - 1].Append(textLines[line][i]);
                    }
                    else //if (!del && !rev)
                    {
                        switch (operation)
                        {
                            case "<upper>":
                                formatedTextLines[fLine].Append(textLines[line][i].ToString().ToUpperInvariant());
                                break;
                            case "<lower>":
                                formatedTextLines[fLine].Append(textLines[line][i].ToString().ToLowerInvariant());
                                break;
                            case "<toggle>":
                                if (char.IsLower(textLines[line][i]))
                                {
                                    formatedTextLines[fLine].Append(textLines[line][i].ToString().ToUpperInvariant());
                                }
                                else
                                {
                                    formatedTextLines[fLine].Append(textLines[line][i].ToString().ToLowerInvariant());
                                }
                                break;
                        }
                    }
                }
                else if (!inTag)
                {
                    formatedTextLines[fLine].Append(textLines[line][i]);
                }

                if (textLines[line][i] == '>')
                {
                    inTag = false;
                }
            }
            if (increaseLines)
            {
                fLine++;
            }
        }
    }

    private static string Reverse(string toRev)
    {
        StringBuilder reverse = new StringBuilder();
        for (int i = toRev.Length - 1; i >= 0; i--)
        {
            reverse.Append(toRev[i]);
        }

        return reverse.ToString();
    }

    private static void InputData()
    {
        linesCount = int.Parse(Console.ReadLine());
        textLines = new string[linesCount];
        formatedTextLines = new StringBuilder[linesCount];

        for (int i = 0; i < linesCount; i++)
        {
            textLines[i] = Console.ReadLine();
            formatedTextLines[i] = new StringBuilder(textLines[i].Length);
        }
    }
}
