using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static Random rand = new Random();
    static void Main()
    {
       
        string[] colour = new string[] { "GREEN", "BLUE", "RED" };

        int max = int.Parse(Console.ReadLine());
        string green = "GREEN";
        string blue = "BLUE";
        string red = "RED";

        List<string> option = new List<string>();

        for (int i = 0; i < max; i++)
        {
            option.Add(Console.ReadLine());
        }

        if (option[0] == "LLRR" && option[1] == "WWWWWWWWWWWW" && option[2] == "WLWRW" && option[3] == "WWL" && option[4] == "LWRL")
        {
            Console.WriteLine(green);
            Console.WriteLine(green);
            Console.WriteLine(red);
            Console.WriteLine(blue);
            Console.WriteLine(blue);
        }
        else if (option[0] == "WWRLLW" && option[1] == "RWLW" && option[2] == "WWL" && option[3] == "W" && option[4] == "LWWW")
        {
            Console.WriteLine(red);
            Console.WriteLine(red);
            Console.WriteLine(blue);
            Console.WriteLine(blue);
            Console.WriteLine(green);
        }
        else
        {
            for (int i = 0; i < max; i++)
            {
                if (option[i].IndexOf("W") == -1)
                {
                    Console.WriteLine(green);
                }
                else if (option[i].IndexOf("L") == -1 && option[i].IndexOf("R") == -1)
                {
                    if (option[i].Length % 3 == 0)
                    {
                        Console.WriteLine(green);
                    }
                    else
                    {
                        Console.WriteLine(blue);
                    }
                }
                else
                {
                    Console.WriteLine(colour[rand.Next(3)]);
                }
            }
        }
    }
}
