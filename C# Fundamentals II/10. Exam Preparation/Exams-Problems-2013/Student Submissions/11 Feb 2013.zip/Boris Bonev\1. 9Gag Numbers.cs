using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

class Program
{

    static string[] numbers = new string[] { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
    static string nums = "";

    private static void Main()
    {
        string input = Console.ReadLine();               
        if (input == "-!")
        {
            Console.WriteLine(0);
            return;
        }

        if (GetValue(input) == "")
        {
            BigInteger output = 0;

            for (int i = 0; i < nums.Length; i++)
            {
                output += BigInteger.Parse(Convert.ToString(nums[nums.Length - 1 - i]))*((BigInteger) (Math.Pow(9, i)));
            }

            Console.WriteLine(output);
        }       
    }

    static string GetValue(string input)
    {
        string tempInput = input;
        
        for (int i = 0; i < numbers.Length; i++)
        {           

            if (tempInput.IndexOf(numbers[i])==0)
            {
                nums += i;
                return GetValue(tempInput.Substring(numbers[i].Length));
            }
            
        }
        return tempInput;
    }
}