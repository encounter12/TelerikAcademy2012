using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace task1_vtori_variant
{
    class Program
    {
        static int ReturnNumber(string input)
        {
            int number = 0;
            switch (input)
            {
                case "-!": number = 0; return number;
                case "**": number = 1; return number;
                case "&&": number = 3; return number;
                case "&-": number = 4; return number;
                case "!-": number = 5; return number;
                default: number = 10; return number;
            }
        }
        static void Main()
        {
            string input = Console.ReadLine();

            int inputLength = input.Length;
            int number = 0;
            BigInteger result = 0;
            int razrqd = 0;
            string checkString = "";
            int[] resultArr=new int[21];

            for (int i = 0; i < inputLength; i++)
            {
                checkString = input.Substring(i, 2);
                number = ReturnNumber(checkString);

                if (number != 10)
                {
                    
                    i++;
                    resultArr[razrqd] = number;
                    razrqd++;
                }
                else
                {
                    if (input.Substring(i, 3) == "!!!")
                    {
                        i++;
                        i++;
                        resultArr[razrqd] = 2;
                        razrqd++;
                    }
                    else if (input.Substring(i, 3) == "&*!")
                    {
                        i++;
                        i++;
                        resultArr[razrqd] = 7;
                        razrqd++;
                    }
                    else if (input.Substring(i, 4) == "*!!!")
                    {
                        i++;
                        i++;
                        i++;
                        resultArr[razrqd] = 6;
                        razrqd++;
                    }
                    else if (input.Substring(i, 6) == "!!**!-")
                    {
                        i = i + 5;
                        resultArr[razrqd] = 8;
                        razrqd++;
                    }
                }
            }
            for (int j = 0; j < razrqd; j++)
            {
     
                BigInteger temp = resultArr[j] * (BigInteger)(BigInteger.Pow(9, razrqd - j - 1));
                result = result + temp;
            }
            Console.WriteLine(result);
        }
    }
}
