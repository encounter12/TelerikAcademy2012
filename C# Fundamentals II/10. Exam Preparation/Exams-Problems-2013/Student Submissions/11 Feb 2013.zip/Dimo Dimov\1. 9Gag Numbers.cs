using System;
using System.Collections.Generic;
using System.Linq;

namespace _01._9GagNumbers
{
    class Program
    {
        static void Main()
        {
            string line = Console.ReadLine();
            
            List<ulong> numbersForCalculation = new List<ulong>();
            int increment = 0;
            while (increment<line.Length)
            {

                if (increment < line.Length && line[increment] == '!' && 
                    (increment + 1) < line.Length && line[(increment + 1)] == '!' &&
                    (increment + 2) < line.Length && line[(increment + 2)] == '*' &&
                    (increment + 3) < line.Length && line[(increment + 3)] == '*' &&
                    (increment + 4) < line.Length && line[(increment + 4)] == '!' &&
                    (increment + 5) < line.Length && line[(increment + 5)] == '-'
                    )
                {
                    increment += 6;
                    numbersForCalculation.Add(8);
                }

                if (increment < line.Length && line[increment] == '*' &&
                    (increment + 1) < line.Length && line[(increment + 1)] == '!' &&
                    (increment + 2) < line.Length && line[(increment + 2)] == '!' &&
                    (increment + 3) < line.Length && line[(increment + 3)] == '!'
                    )
                {
                    increment += 4;
                    numbersForCalculation.Add(6);
                }

                if (increment < line.Length && line[increment] == '!' &&
                    (increment + 1) < line.Length && line[(increment + 1)] == '!' &&
                    (increment + 2) < line.Length && line[(increment + 2)] == '!'
                    )
                {
                    increment += 3;
                    numbersForCalculation.Add(2);
                }

                if (increment < line.Length && line[increment] == '&' &&
                    (increment + 1) < line.Length && line[(increment + 1)] == '*' &&
                    (increment + 2) < line.Length && line[(increment + 2)] == '!'
                    )
                {
                    increment += 3;
                    numbersForCalculation.Add(7);
                }

                if (increment < line.Length && line[increment] == '*' &&
                    (increment + 1) < line.Length && line[(increment + 1)] == '*'
                    )
                {
                    increment += 2;
                    numbersForCalculation.Add(1);
                }

                if (increment < line.Length && line[increment] == '&' &&
                    (increment + 1) < line.Length && line[(increment + 1)] == '&'
                    )
                {
                    increment += 2;
                    numbersForCalculation.Add(3);
                }

                if (increment < line.Length && line[increment] == '&' &&
                    (increment + 1) < line.Length && line[(increment + 1)] == '-'
                    )
                {
                    increment += 2;
                    numbersForCalculation.Add(4);
                }

                if (increment < line.Length && line[increment] == '!' &&
                    (increment + 1) < line.Length && line[(increment + 1)] == '-'
                    )
                {
                    increment += 2;
                    numbersForCalculation.Add(5);
                }

                if (increment < line.Length && line[increment] == '-' &&
                    (increment + 1) < line.Length && line[(increment + 1)] == '!'
                    )
                {
                    increment += 2;
                    numbersForCalculation.Add(0);
                }
            }
            ulong sum = 0;
            ulong corrector = 1;
            for (int i = numbersForCalculation.Count-1; i >= 0; i--)
			{
                sum = sum + numbersForCalculation[i]*corrector;
                corrector *= 9;
            }
            Console.WriteLine(sum);
        }
    }
}
