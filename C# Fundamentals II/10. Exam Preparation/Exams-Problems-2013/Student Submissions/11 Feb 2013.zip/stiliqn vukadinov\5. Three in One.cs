using System;
using System.Text.RegularExpressions;
 
namespace Problem5
{
    class Problem5
    {
        static void Main()
        {
            string[] pointsLine = Regex.Split(Console.ReadLine(), ",");
            int[] points = new int[pointsLine.Length];
            int maxHand = 0;
            int maxHandIndex = -1;
            bool isOne = true;
            for (int i = 0; i < pointsLine.Length; i++)
            {
                points[i] = Convert.ToInt32(pointsLine[i]);
                if (maxHand < points[i] && points[i] <= 21)
                {
                    maxHand = points[i];
                    maxHandIndex = i;
                    isOne = true;
                }
                else    if (maxHand == points[i])
                    isOne = false;
            }
 
            string[] cakesLine = Regex.Split(Console.ReadLine(), ",");
            int[] cakes = new int[cakesLine.Length];
            for (int i = 0; i < cakesLine.Length; i++)
                cakes[i] = Convert.ToInt32(cakesLine[i]);
            int f = int.Parse(Console.ReadLine());
            int myCakes = 0;
 
            Array.Sort(cakes);
            for (int i = cakes.Length - 1; i >= 0; i -= f + 1)
                myCakes += cakes[i];
 
            string[] coinsLine = Regex.Split(Console.ReadLine(), " ");
            int g1 = int.Parse(coinsLine[0]);
            int s1 = int.Parse(coinsLine[1]);
            int b1 = int.Parse(coinsLine[2]);
 
            int g2 = int.Parse(coinsLine[3]);
            int s2 = int.Parse(coinsLine[4]);
            int b2 = int.Parse(coinsLine[5]);
 
            int moves = 0;
            //gold
            while (g1 > g2)
            {
                g1--;
                s1 += 11;
                moves++;
            }
            if (g1 < g2)
            {
                while (b1 >= 9)
                {
                    s1++;
                    b1 -= 9;
                    moves++;
                }
                while (g1 < g2 && s1 >= 9)
                {
                    g1++;
                    s1 -= 9;
                    moves++;
                }
            }
            //silver
            while (s1 > s2)
            {
                s1--;
                b1 += 11;
                moves++;
            }
            while (s1 < s2)
            {
                s1++;
                b1 -= 9;
                moves++;
            }
            if (isOne)
                Console.WriteLine(maxHandIndex);
            else
                Console.WriteLine(-1);
            Console.WriteLine(myCakes);
            Console.WriteLine(moves);
        }
    }
}