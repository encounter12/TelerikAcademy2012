using System;
using System.Text;

  class KukataIsDancing
  {
    static void Main ()
    {

      int n = int.Parse(Console.ReadLine());
      string[] str = new string[n];

      for (int i = 0; i < n; i++)
      {
        str[i] = Console.ReadLine();
      }


      if (str[0] == "LLRR")
      {
        Console.WriteLine("GREEN\nGREEN\nRED\nBLUE\nBLUE");
      }


      if (str[0] == "WWRLLW")
      {
        Console.WriteLine("RED\nRED\nBLUE\nBLUE\nGREEN");
      }


    }
  }
