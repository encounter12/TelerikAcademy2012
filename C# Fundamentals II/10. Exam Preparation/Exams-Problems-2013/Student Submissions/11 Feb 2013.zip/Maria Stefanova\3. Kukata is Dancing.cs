using System;

class Program
{
    static void GetPositionOnBoard(string str)
    {
        string[,]  arrBoard = {                                
                                    {"RED","BLUE", "RED"},
                                    {"BLUE", "GREEN","BLUE"},
                                    {"RED","BLUE", "RED"}
                                };
        int n = 2;
        
        foreach (var item in str)
        {
            Console.WriteLine(item);
            if (item == 'R')
            {
                for (int i = 0; i < n; ++i)
                {
                    for (int j = 0; j < n; ++j)
                    {
                        arrBoard[i, j] = arrBoard[j, n - i - 1];
                    }
                }

            }

            //if (item == 'L')
            //{
            //    for ( int i = 0; i < 3; i++)
            //    {
            //        for (int j = 2; j >= 0; --j)
            //        {
            //            arrBoard[j, 3 - i] = arrBoard[i, j];
            //        }
            //    }
            //}
            
            //if (item == 'W')
            //{


            //}


        }

        Console.WriteLine(arrBoard[1,1]);
    }


    static void Main()
    {
        // number of lines
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            GetPositionOnBoard(Console.ReadLine());
        }
    }
}
