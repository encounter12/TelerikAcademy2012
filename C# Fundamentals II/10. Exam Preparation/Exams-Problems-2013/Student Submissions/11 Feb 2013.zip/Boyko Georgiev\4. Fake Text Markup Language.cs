using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Fake Text Markup Language

namespace task1
{
    class FTML
    {

        //Method changing chars -> ToUpper. FTML tag <upper>. 

        //public static void ToUpper()
        //{ 
        //    string upper = "LOWer CASES are given AWAY";
        //    string getupper = upper.ToUpper();
        //    Console.WriteLine(getupper);
        //}

        //Method changing chars -> ToLower. FTML tag <lower>.

        //public static void ToLower()
        //{
        //    string lower = "LOWer CASES are given AWAY";
        //    string getlower = lower.ToLower();
        //    Console.WriteLine(getlower);
        //}

        //Method changing chars -> Toggle. FTML tag <toggle>. Exmp.: TeXt -> tExT 

        //static string Toggle()
        //{

        //}

        //Method changing chars -> Delete. FTML tag <del> 

        //static string Del()
        //{

        //}

        //Method changing chars -> Reverse. FTML tag <rev>

        //public static void Rev()
        //{
        //    Console.Write("Write a text here:");
        //    char[] rev = Console.ReadLine().ToCharArray();

        //    Array.Reverse(rev);

        //    Console.WriteLine(rev);
        //}

        public static void Main()
        {

            //UPPER TEXT

            // Enter text with open and close tags <upper> in order to make this word bigger.
            string input = Console.ReadLine(); 

            int upperIndex = 0;
         // int lowerIndex = 0;


            while (upperIndex > -1)
            {
                int indexOpenTag = input.IndexOf("<upper>", upperIndex);

                if (indexOpenTag == -1)
                {
                    break;
                }

                int indexCloseTag = input.IndexOf("</upper>", indexOpenTag + 7);
                if (indexCloseTag == -1)
                {
                    break;
                }

                string betweenTags = input.Substring(indexOpenTag + 7, indexCloseTag - indexOpenTag - 7);
                input = input.Replace(betweenTags, betweenTags.ToUpper());
                upperIndex = indexCloseTag + 10;


                input = input.Replace("<upper>", "");
                input = input.Replace("</upper>", "");
                Console.WriteLine(input);

            }
          
            

            //while (lowerIndex > -1)
            //{
            //    int indexOpenTag = input.IndexOf("<lower>", lowerIndex);

            //    if (indexOpenTag == -1)
            //    {
            //        break;
            //    }

            //    int indexCloseTag = input.IndexOf("</lower>", indexOpenTag + 7);
            //    if (indexCloseTag == -1)
            //    {
            //        break;
            //    }

            //    string betweenTags = input.Substring(indexOpenTag + 7, indexCloseTag - indexOpenTag - 7);
            //    input = input.Replace(betweenTags, betweenTags.ToLower());

            //    lowerIndex = indexCloseTag + 10;


            //    input = input.Replace("<lower>", "");
            //    input = input.Replace("</lower>", "");
            //    Console.WriteLine(input);
            //}

            

            }

       }
  }
