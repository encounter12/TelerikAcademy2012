using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _9Gag_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string gag, number_gag = "";
            int value = 0, count = 0, j=0;
            gag = Console.ReadLine();
            List<int> number = new List<int>();
            
            for (int i = 0; i < gag.Length; i++)
            {
                number_gag += gag[i];
                switch (number_gag)
                {
                    case ("-!"): number.Add(0); Console.WriteLine(number[i]); j++; number_gag = String.Empty; break;
                    case ("**"): number.Add(1); Console.WriteLine(number[i]); j++; number_gag = String.Empty; break;
                    case ("!!!"): number.Add(2); Console.WriteLine(number[i]); j++; number_gag = String.Empty; break;
                    case ("&&"): number.Add(3); Console.WriteLine(number[i]); j++; number_gag = String.Empty; break;
                    case ("&-"): number.Add(4); Console.WriteLine(number[i]); j++; number_gag = String.Empty; break;
                    case ("!-"): number.Add(5); Console.WriteLine(number[i]); j++; number_gag = String.Empty; break;
                    case ("*!!!"): number.Add(6); Console.WriteLine(number[i]); j++; number_gag = String.Empty; break;
                    case ("&*!"): number.Add(7); Console.WriteLine(number[i]); j++; number_gag = String.Empty; break;
                    case ("!!**!-"): number.Add(8); Console.WriteLine(number[i]); j++; number_gag = String.Empty; break;
                    default: break;
                }
            }

            count = number.Count;
            int temp = count;
            for (int i = 0; i < temp; i++)
            {
                value += (int)Math.Pow(number[i], count); count--;
            }

            Console.WriteLine(value);
        }
    }
}
