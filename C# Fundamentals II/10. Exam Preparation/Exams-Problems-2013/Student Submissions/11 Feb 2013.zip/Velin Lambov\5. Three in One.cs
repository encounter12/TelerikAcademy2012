using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem5
{
    class Program
    {
        static void Main()
        {
            string input = Console.ReadLine();
            string input2 = Console.ReadLine();
            int f = Int32.Parse(Console.ReadLine());
            string input3 = Console.ReadLine();



            int[] points = new int[50];
            for (int i = 0; i< 50; i++)
                points[i] = 0;
            int j = 0;
            for (int i = 0; i <= input.Length - 1; i++)
            {
                if (Char.IsDigit(input[i]))
                {
                    points[j] *= 10;
                    points[j] += Convert.ToInt32(input[i]) - 48;
                }
                else 
                {
                    j++;
                }

            }
            int max = 0;
            int maxIndex =0;
            for (int i = 0; i < 20; i++) 
            {
                if ((points[i] > max) && (points[i] <= 21))
                {
                    max = points[i];
                    maxIndex = i;
                }
            }
            int check = 0;
            for (int i = 0; i < 20; i++)
            {
                if ((points[i] == max) && (maxIndex!= i))
                {
                    check = 1;
                }
            }
            if (check == 0)
                Console.WriteLine(maxIndex);
            else
                Console.WriteLine("-1");







            int[] sizes = new int[10];
            j = 0; 
            for (int i = 0; i < 10; i++)
                sizes[i] = 0;
            for (int i = 0; i <= input2.Length - 1; i++)
            {
                if (Char.IsDigit(input2[i]))
                {
                    sizes[j] *= 10;
                    sizes[j] += Convert.ToInt32(input2[i]) - 48;
                }
                else
                {
                    j++;
                }

            }
            for (int i = 0; i < 9; i++)
            {
                for (int k = i+1; k < 10; k++)
                {
                    if (sizes[i] < sizes[k])
                    {
                        sizes[k] = sizes[k] + sizes[i];
                        sizes[i] = sizes[k] - sizes[i];
                        sizes[k] = sizes[k] - sizes[i];
                    }
                }
            }
            int value = 0;
            for (int i = 0; i < 10; i = i + f + 1)
            {
                value += sizes[i];
            }
            Console.WriteLine(value);






            int[] coins = new int[6];
            for (int i = 0; i < 6; i++)
                coins[i] = 0;
            j = 0;
            for (int i = 0; i <= input3.Length - 1; i++)
            {
                if (Char.IsDigit(input3[i]))
                {
                    coins[j] *= 10;
                    coins[j] += Convert.ToInt32(input3[i]) - 48;
                }
                else
                {
                    j++;
                }
            }

            int moves = 0;
            while (true)
            {
                if (coins[0] >= coins[3])
                {
                    if (coins[1] >= coins[4])
                    {
                        if (coins[2] >= coins[5])
                        {
                            Console.WriteLine(moves);
                            break;
                        }
                        else
                        {
                            if (coins[1] > coins[4])
                            {
                                coins[1] -= 1;
                                coins[2] += 9;
                                moves++;
                            }
                            else
                            {
                                if (coins[0] > coins[3])
                                {
                                    coins[0] -= 1;
                                    coins[1] += 9;
                                    moves++;
                                }
                                else 
                                {
                                    Console.WriteLine("-1");
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        if (coins[0] > coins[3])
                        {
                            coins[0] -= 1;
                            coins[1] += 9;
                            moves++;
                        }
                        else
                        {
                            if (coins[2] > coins[5])
                            {
                                coins[2] -= 11;
                                coins[1] += 1;
                                moves++;
                            }
                            else 
                            {
                                Console.WriteLine("-1");
                                break;
                            }
                        }
                    }
                }
                else 
                {
                    if (coins[1] > coins[4])
                    {
                        coins[1] -= 11;
                        coins[0] += 1;
                        moves++;
                    }
                    else 
                    {
                        if (coins[2] > coins[5])
                        {
                            coins[2] -= 11;
                            coins[1] += 1;
                            moves++;
                        }
                        else 
                        {
                            Console.WriteLine("-1");
                            break;
                        }
                    }
                } 
                

            }
            

        }
    }
}