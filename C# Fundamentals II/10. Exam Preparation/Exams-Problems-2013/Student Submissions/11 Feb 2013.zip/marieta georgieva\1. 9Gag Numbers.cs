using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class Task01
{
    static void Main()
    {
        string input = Console.ReadLine();
        int digit = 0;
        StringBuilder number = new StringBuilder();
        long result = 0;
        
        for (int i = 0; i <input.Length; i++)
        {
            number = number.Append(input[i]);
            switch (number.ToString())
            {
                case "-!": digit = 0; break;
                case "**": digit = 1; break;
                case "!!!": digit = 2; break;
                case "&&": digit = 3; break;
                case "&-": digit = 4; break;
                case "!-": digit = 5; break;
                case "*!!!": digit = 6; break;
                case "&*!": digit = 7; break;
                case "!!**!-": digit = 8; break;
                default: digit = 9; break;

            }
            if (digit == 9)
            {
                continue;
            }
            else
            {
                result = 9 * result + digit;
                number.Clear();
            }


        }
        Console.WriteLine(result);
    }
}
