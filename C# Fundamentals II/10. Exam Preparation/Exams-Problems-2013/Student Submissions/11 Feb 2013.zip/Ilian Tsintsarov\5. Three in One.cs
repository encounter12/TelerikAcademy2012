
using System;

class Program
{
    static void Main()
    {
        int[] ints = new int[5];
        Random rand = new Random();

        for (int i = 0; i < ints.Length; i++)
        {
            ints[i] = rand.Next(30);
        }

        Array.Sort(ints);

        foreach (int i in ints)
        {
            Console.WriteLine(i.ToString());
        }
        }
     }