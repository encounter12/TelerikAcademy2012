using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kukata
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Square[] cube = new Square[9];
            for (int n = 0; n < cube.Length; n++)
            {
                for (int k = 0; k < 3; k++)
                {
                    for (int l = 0; l < 3; l++)
                    {
                        cube[n] = new Square(l, k);
                    }
                }
            }*/

            Square dancer = new Square(1);
            int lefts=0, rights=0;
            string dancing = Console.ReadLine();
            for (int count = 0; count < dancing.Length; count++)
            {
                if (dancing[count].Equals("L")) lefts++;
                else if (dancing[count].Equals("R")) rights++;
                else if (dancing[count].Equals("M"))
                {
                    if (lefts > rights) { lefts = lefts - rights; dancer = Move(dancer.i, dancer.j, dancer.i, dancer.j + 1, "L", lefts); }
                    else if (rights < lefts) {rights = rights - lefts; dancer = Move(dancer.i, dancer.j, dancer.i, dancer.j + 1, "R", rights); }
                    else dancer = Move(dancer.i, dancer.j, dancer.i, dancer.j+1, "M", 0);
                }
            }

            if (dancer.i == 0 && dancer.j == 0) Console.WriteLine("RED");
            if (dancer.i == 0 && dancer.j == 2) Console.WriteLine("RED");
            if (dancer.i == 2 && dancer.j == 0) Console.WriteLine("RED");
            if (dancer.i == 2 && dancer.j == 2) Console.WriteLine("RED");

            if (dancer.i == 0 && dancer.j == 1) Console.WriteLine("BLUE");
            if (dancer.i == 1 && dancer.j == 0) Console.WriteLine("BLUE");
            if (dancer.i == 0 && dancer.j == 2) Console.WriteLine("BLUE");
            if (dancer.i == 2 && dancer.j == 0) Console.WriteLine("BLUE");

            else Console.WriteLine("GREEN");

        }
    }

    public class Square
    {
        int i;
        int j;

        public Square() { i = 0; j = 0; }
        public Square(int n) { i = n; j = n; }
        public Square(int n1, int n2) { i = n1; j = n2; }

        public Square Move(int i1, int j1, int i2, int j2, string direction, int times)
        {
            
            Square next = new Square();
            if (direction == "R")
            {
                for (int count = 0; count < times; count++) { next = Right(next.i, next.j, i2, j2); }
            }
            else if (direction == "L")
            {
                for (int count = 0; count < times; count++) { next = Left(next.i, next.j, i2, j2); }
            }
            else { next.i = i2; next.j = j2; }
            return next;
        }

        public Square Right(int i1, int j1, int i2, int j2)
        {
            double p;
            if (i1 > i2 && j1 == j2) p = Math.PI / 2;
            else if (i1 == i2 && j1 < j2) p = 0;
            else if (i1 == i2 && j1 > j2) p = Math.PI;
            else p = -(Math.PI / 2);
            i1 = i1 + (int)Math.Cos(p);
            j1 = j1 + (int)Math.Sin(p);
            Square right = new Square(i1, j1);
            return right;
        }

        public Square Left(int i1, int j1, int i2, int j2)
        {
            double p;
            if (i1 > i2 && j1 == j2) p = Math.PI / 2;
            else if (i1 == i2 && j1 < j2) p = 0;
            else if (i1 == i2 && j1 > j2) p = Math.PI;
            else p = -(Math.PI / 2);
            i1 = i1 - (int)Math.Cos(p);
            j1 = j1 - (int)Math.Sin(p);
            Square left = new Square(i1, j1);
            return left;
        }
    }
}
