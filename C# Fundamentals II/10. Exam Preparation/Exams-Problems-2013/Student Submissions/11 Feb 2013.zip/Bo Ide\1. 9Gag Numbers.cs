using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTML
{
    class Program
    {

        public static int strIndexPosition = 0;
        public static int getStringLenght = 0;

        private string MakeUpper(string txtToProcess)
        {
            string txtReady = "";
            while (Program.strIndexPosition < Program.getStringLenght &&
                txtToProcess[Program.strIndexPosition] != '<' &&
                txtToProcess[Program.strIndexPosition + 1] != '/')
            {
                if (Program.strIndexPosition < Program.getStringLenght && txtToProcess[Program.strIndexPosition] == '<' &&
                    txtToProcess[Program.strIndexPosition + 1] != '/')
                {
                    CheckNested(txtToProcess);
                }
                txtReady += txtToProcess[Program.strIndexPosition];
                Program.strIndexPosition++;
            }
            return txtReady.ToUpper();
        }

        private string MakeLower(string txtToProcess)
        {
            string txtReady = "";
            while (Program.strIndexPosition < Program.getStringLenght &&
                txtToProcess[Program.strIndexPosition] != '<' &&
                txtToProcess[Program.strIndexPosition + 1] != '/')
            {
                if (Program.strIndexPosition < Program.getStringLenght && txtToProcess[Program.strIndexPosition] == '<' &&
                    txtToProcess[Program.strIndexPosition + 1] != '/')
                {
                    CheckNested(txtToProcess);
                }
                txtReady += txtToProcess[Program.strIndexPosition];
                Program.strIndexPosition++;
            }
            return txtReady.ToLower();
        }

        private string MakeToggle(string txtToProcess)
        {
            string txtReady = "";
            while (Program.strIndexPosition < Program.getStringLenght &&
                txtToProcess[Program.strIndexPosition] != '<' &&
                txtToProcess[Program.strIndexPosition + 1] != '/')
            {
                if (Program.strIndexPosition < Program.getStringLenght && txtToProcess[Program.strIndexPosition] == '<' &&
                    txtToProcess[Program.strIndexPosition + 1] != '/')
                {
                    CheckNested(txtToProcess);
                }
                if (txtToProcess[Program.strIndexPosition] >= 65 && txtToProcess[Program.strIndexPosition] <= 90)
                    txtReady += txtToProcess[Program.strIndexPosition].ToString().ToLower();
                else if (txtToProcess[Program.strIndexPosition] >= 97 && txtToProcess[Program.strIndexPosition] <= 122)
                {
                    txtReady += txtToProcess[Program.strIndexPosition].ToString().ToUpper();
                }
                Program.strIndexPosition++;
            }
            return txtReady.ToString();
        }

        private void MakeDel(string txtToProcess)
        {
            CheckNested(txtToProcess);
            while (Program.strIndexPosition < Program.getStringLenght &&
                txtToProcess[Program.strIndexPosition] != '<' &&
                txtToProcess[Program.strIndexPosition + 1] != '/')
            {
                if (Program.strIndexPosition < Program.getStringLenght && txtToProcess[Program.strIndexPosition] == '<' &&
                    txtToProcess[Program.strIndexPosition + 1] != '/')
                {
                    CheckNested(txtToProcess);
                }
                Program.strIndexPosition++;
            }
        }

        private string MakeRev(string txtToProcess)
        {
            CheckNested(txtToProcess);
            string txtReady = "";
            while (Program.strIndexPosition < Program.getStringLenght && 
                txtToProcess[Program.strIndexPosition] != '<' &&
                txtToProcess[Program.strIndexPosition + 1] != '/')
            {
                if (Program.strIndexPosition < Program.getStringLenght && txtToProcess[Program.strIndexPosition] == '<' &&
                    txtToProcess[Program.strIndexPosition + 1] != '/')
                {
                    CheckNested(txtToProcess);
                }
                txtReady += txtToProcess[Program.strIndexPosition];
                Program.strIndexPosition++;
            }

            return Reverse(txtReady).ToString();
        }


        private string Reverse(string text)
        {
            char[] cArray = text.ToCharArray();
            string reverse = String.Empty;
            for (int i = cArray.Length - 1; i > -1; i--)
            {
                reverse += cArray[i];
            }
            return reverse;
        }

        private string CheckTag(string tag, string txtToProcess)
        {
            string txtProcessed = "";
            switch (tag)
            {
                case "<upper":
                    if(strIndexPosition<Program.getStringLenght-1)
                    strIndexPosition++;
                    txtProcessed += MakeUpper(txtToProcess);
                    if (strIndexPosition < Program.getStringLenght-7)
                    strIndexPosition += 6;
                    break;
                case "<lower":
                    if (strIndexPosition < Program.getStringLenght-1)
                    strIndexPosition++;
                    txtProcessed += MakeLower(txtToProcess);
                    if (strIndexPosition < Program.getStringLenght - 6)
                    strIndexPosition += 5;
                    break;
                case "<toggle":
                    if (strIndexPosition < Program.getStringLenght-1)
                    strIndexPosition++;
                    txtProcessed += MakeToggle(txtToProcess);
                    if (strIndexPosition < Program.getStringLenght - 7)
                    strIndexPosition += 6;
                    break;
                case "<del":
                    if (strIndexPosition < Program.getStringLenght-1)
                    strIndexPosition++;
                    MakeDel(txtToProcess);
                    if (strIndexPosition < Program.getStringLenght - 4)
                    strIndexPosition += 3;
                    break;
                case "<rev":
                    if (strIndexPosition < Program.getStringLenght-1)
                    strIndexPosition++;
                    txtProcessed += MakeRev(txtToProcess);
                    if (strIndexPosition < Program.getStringLenght - 4)
                    strIndexPosition += 3;
                    break;
                default: Console.WriteLine("wrong tag");
                    break;
            }
            return txtProcessed.ToString();
        }

        private string CheckNested(string inputStr)
        {
            string resultStr = "";
            string getTag = "";
            while (Program.strIndexPosition < Program.getStringLenght)
            {
                if (Program.strIndexPosition < Program.getStringLenght && inputStr[Program.strIndexPosition] == '<')
                {
                    while (Program.strIndexPosition < Program.getStringLenght && inputStr[Program.strIndexPosition] != '>')
                    {
                        getTag += inputStr[Program.strIndexPosition];
                        Program.strIndexPosition++;
                    }
                    resultStr += CheckTag(getTag, inputStr);
                    Console.WriteLine(getTag);
                    getTag = "";
                }
                
                resultStr += inputStr[Program.strIndexPosition];
                    Program.strIndexPosition++;
            } 
            return resultStr.ToString();
        }

        static void Main(string[] args)
        {

            string testStr1 = "So<rev><upper>saw</upper> txet em</rev><lower><upper>here</upper></lower>", testStr2 = "";
            string inputStr = "<upper>borko</upper><lower>BORKOO</lower><del>BORkkkkKOO</del><toggle>bORko</toggle><rev>azz</rev>";
            //inputStr = String.Empty;
            //inputStr = testStr1;

            Program pr = new Program();
            Program.getStringLenght = inputStr.Length;
            Console.WriteLine(pr.CheckNested(inputStr));
        }
    }
}
