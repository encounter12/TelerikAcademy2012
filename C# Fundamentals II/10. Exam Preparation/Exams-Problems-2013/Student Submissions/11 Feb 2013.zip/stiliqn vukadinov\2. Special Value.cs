using System;
using System.Text.RegularExpressions;

namespace Problem2
{
	class Problem2
	{
		static void Main()
		{
			int n = int.Parse(Console.ReadLine());
			int[][] masive = new int[n][];
			bool[][] isVisited = new bool[n][];

			for (int i = 0; i < n; i++)
			{
				string[] s = Regex.Split(Console.ReadLine(), ", ");
				masive[i] = new int[s.Length];
				isVisited[i] = new bool[s.Length];
				for (int j = 0; j < s.Length; j++)
				{
					masive[i][j] = Convert.ToInt32(s[j]);
					isVisited[i][j] = false;
				}
			}

			int row = 0;
			int col = 0;
			int special = int.MinValue;
			int path = 1;

			for (int i = 0; i < masive.GetLength(0) - 1; i++)
			{
				col = i;
				while (masive[row][col] >= 0 && !isVisited[row][col])
				{
					isVisited[row][col] = true;

					col = masive[row][col];

					path++;
					row++;
					if (row > n - 1)
						row = 0;
				}
				if (special < path + Math.Abs(masive[row][col]))
					special = path + Math.Abs(masive[row][col]);
				
				row = 0;
				path = 1;
			}
			Console.WriteLine(special);
		}
	}
}
