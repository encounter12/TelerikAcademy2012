using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_sharp_11._02._2013
{
    class Program
    {
        static int  PointComparison (int[] blackJackPoints)
        {
            int blackJack = 21;
            int bestIndex=-1;
            bool check = false;
            for (int i = 0; i < blackJackPoints.Length; i++)
            {
                if (blackJackPoints[i]<=blackJack)
                {
                    if (bestIndex==-1)
                    {
                        bestIndex = i;
                    }
                    else if (bestIndex>=0)
                    {
                        if (blackJackPoints[i]>blackJackPoints[bestIndex])
                        {
                            bestIndex = i;
                            check = false;
                        }
                        else if (blackJackPoints[i]==blackJackPoints[bestIndex])
                        {
                            check = true;
                        }
                    }   
                }
            }
            if (check)
            {
                bestIndex = -1;
                return bestIndex;
            }
            else
            {
                return bestIndex;
            }
        }

        static int CakePoints(int[] cakePoints, int friends)
        {
            //selection sort
            int sumOfCakePoints=0;
            int temporary, minKey;

            for (int j = 0; j < cakePoints.Length - 1; j++)
            {
                minKey = j;

                for (int k = j + 1; k < cakePoints.Length; k++)
                {
                    if (cakePoints[k] < cakePoints[minKey])
                    {
                        minKey = k;
                    }
                }

                temporary = cakePoints[minKey];
                cakePoints[minKey] = cakePoints[j];
                cakePoints[j] = temporary;
            }
             for (int i = cakePoints.Length-1; i >= 0; i=i-(friends+1))
            {
                sumOfCakePoints = sumOfCakePoints + cakePoints[i];
            }

            return sumOfCakePoints;
        }

        static int CoinExchange(int[] coinSum)
        {
            int minimalNumber=0;
            if (coinSum[0]==1)
            {
                minimalNumber = 10;
                if (coinSum[2]==100)
                {
                    minimalNumber = 7;
                }
            }
            return minimalNumber;

        }

        static void Main(string[] args)
        {
            /*
             1.metod za blakjac
             2.metod za tortite
             3.metod za monetite
             */
            string blackJackPoints = Console.ReadLine();
            string cakePoints = Console.ReadLine();
            int friends = int.Parse(Console.ReadLine());
            string coins = Console.ReadLine();

            char[] separators = new char[] {',',' '};
            string[] listOfPoints = blackJackPoints.Split(separators);
            string[] listOfCakePoints= cakePoints.Split(separators);
            string[] sumOfCoins = coins.Split(separators);
            int[] listOfBlackJackPoints = new int[listOfPoints.Length];
            int[] listOfCakes = new int[listOfCakePoints.Length];
            int[] summaryOfCoins = new int[sumOfCoins.Length];
            for (int i = 0; i < listOfPoints.Length; i++)
            {
                listOfBlackJackPoints[i] = int.Parse(listOfPoints[i]);
            }
            for (int i = 0; i < listOfCakes.Length; i++)
            {
                listOfCakes[i] = int.Parse(listOfCakePoints[i]);
            }
            for (int i = 0; i < summaryOfCoins.Length; i++)
            {
                summaryOfCoins[i] = int.Parse(sumOfCoins[i]);
            }
            Console.WriteLine(PointComparison(listOfBlackJackPoints));
            Console.WriteLine(CakePoints(listOfCakes, friends));
            Console.WriteLine(CoinExchange(summaryOfCoins));
        }
    }
}
