using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3_rd_task
{
    class Program
    {
        static void Dance()
        {
            string Walking = Console.ReadLine();
            int X = 2, Y = 2, look = 0;
            foreach (char step in Walking)
            {
                switch (step)
                {
                    case 'W':
                        {
                            switch ((look + 60)% 4)
                            {
                                case 0: Y--; break;
                                case 1: X++; break;
                                case 2: Y++; break;
                                case 3: X--; break;
                                default:
                                    break;
                            }
                            break;
                        }
                    case 'L': look--; break;
                    case 'R': look++; break;
                    default:
                        break;
                }
            }
            if ((X + 59)%3 + 1 == 2 && (Y + 59)%3 + 1 == 2)
            {
                Console.WriteLine("GREEN");
            }
            else if ((X + 59)%3 + 1 == 2 || (Y + 59)%3 + 1 == 2)
            {
                Console.WriteLine("BLUE");
            }
            else
            {
                Console.WriteLine("RED");
            }
        }
        static void Main(string[] args)
        {
            int numDances = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < numDances; i++)
            {
                Dance();
            }
        }
    }
}
