using System;
using System.Collections.Generic;

class NineGagNumbers
{
    static void Main()
    {
        string[] numberRepresentations = {"-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-"};
        string nineGagNumber = Console.ReadLine();
        var nineGagNumbers = new List<int>();
        string splitedNineGagNumber = "";
        
        foreach (char ch in nineGagNumber)
        {
           splitedNineGagNumber = String.Concat(splitedNineGagNumber, ch.ToString());
           int index = Array.IndexOf(numberRepresentations, splitedNineGagNumber);
           
           if (index > -1)
            {
               nineGagNumbers.Add(index);
               splitedNineGagNumber = "";
            }
        }
        
        int value = 0;

        for (int i = 0, k = nineGagNumbers.Count - 1; i < nineGagNumbers.Count; i++, k--)
        {
            value += nineGagNumbers.ToArray()[i] * (int) Math.Pow(9, k);
        }

        Console.WriteLine(value);
    }
}