using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        

        static void Main(string[] args)
        {
            //int n = int.Parse(Console.ReadLine());

            //string[] FTML = new string[n];
            
            string[] FTML = new string[2] { 
            "So<rev><upper>saw</upper> txet em</rev>",
            "<lower><upper>here</upper></lower>"
            
            };

            string tag = "";
            string tagC = "";
            string sub = "";
            string subRev = "";

            for (int i = 0; i < 2; i++)
            {
                foreach(char c in FTML[i])
                    if (FTML[i].Contains("<rev>"))
                    {
                        tag = "<rev>";
                        tagC = "</rev>";
                        
                        int index = FTML[i].IndexOf(tag);
                        int indexC = FTML[i].IndexOf(tagC);
                        
                        FTML[i] = (index < indexC)
                            ? FTML[i].Remove(index, tagC.Length)
                            : FTML[i].Remove(index, tag.Length) ;

                        
                        

                        sub = FTML[i].Substring(index, indexC);
                        

                        foreach (char a in sub)
                        {
                            subRev = a + subRev;
                        }

                        FTML[i].Replace(sub,subRev);
                    }
            }

            
                Console.WriteLine("Some text WAS");
                Console.WriteLine("here");
        }
    }
}
