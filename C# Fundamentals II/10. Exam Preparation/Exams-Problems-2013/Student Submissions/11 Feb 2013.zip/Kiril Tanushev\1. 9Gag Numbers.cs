using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nineGagNumbers
{
    class nineGagNumbers
    {
        static void Main(string[] args)
        {
            Console.Write("Enter 9Gag numbers:");
            string nineNumber = Console.ReadLine();
            string[] digitOfNineGag = { "!-", "**", "!!!", "&&", "&-", "-!", "*!!!", "&*!", "!!**!-", };
            int index = -1;
            int decimalNum = 0; 
            int suming = 0;
            int countOfList = 0;
            List<string> searchedNumber = new List<string>();

            for (int i = digitOfNineGag.Length-1; i >= 0; i--)              
            {
                int searchIndex = nineNumber.IndexOf(digitOfNineGag[i], index + 1);
                if (searchIndex >= 0)
                {
                    string someIndex = digitOfNineGag[i];
                    nineNumber = nineNumber.Replace(digitOfNineGag[i], new string('@', someIndex.Length));
                    searchedNumber.Add(digitOfNineGag[i]);
                }
            }
            countOfList = searchedNumber.Count;
            for (int j = 0; j <= searchedNumber.Count - 1; j++)
            {

                countOfList--;
                switch (searchedNumber[j])
                {
                    case "-!": decimalNum = 0; break;
                    case "**": decimalNum = 1; break;
                    case "!!!": decimalNum = 2; break;
                    case "&&": decimalNum = 3; break;
                    case "&-": decimalNum = 4; break;
                    case "!-": decimalNum = 5; break;
                    case "*!!!": decimalNum = 6; break;
                    case "&*!": decimalNum = 7; break;
                    case "!!**!-": decimalNum = 8;  break;
                    
                }
                decimalNum *= (int)Math.Pow(9, j);  
                suming += decimalNum;
            }
            Console.WriteLine(suming);
            }
        }
    }
