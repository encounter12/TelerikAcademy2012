using System;
using System.Text.RegularExpressions;
using System.Collections;
using System.Text;
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            String[][] input = new String[n][];
            String line;
            for (int i = 0; i < n; i++)
            {
                line = Console.ReadLine();
                line = line.Replace("<", "#sep#<");
                line = line.Replace(">", ">#sep#");
                line = line.Replace("#sep##sep#", "#sep#");
                input[i] = Regex.Split(line, "#sep#");
            }
            Stack openTags = new Stack();
            for (int i = 0; i < input.Length; i++)
            {
                for (int j = 0; j < input[i].Length; j++)
                {
                    if (input[i][j].Length>0 && input[i][j][0] == '<')
                    {
                        if (input[i][j][1] == '/')
                        {
                            openTags.Pop();
                        }
                        else
                        {
                            openTags.Push(input[i][j]);
                        }
                    }
                    else
                    {
                        foreach (String tag in openTags)
                        {
                            switch (tag)
                            {
                                case "<upper>":
                                    input[i][j] = input[i][j].ToUpper();
                                    break;
                                case "<lower>":
                                    input[i][j] = input[i][j].ToLower();
                                    break;
                                case "<toggle>":
                                    StringBuilder stringBuffer = new StringBuilder();
                                    foreach (char c in input[i][j])
                                    {
                                        stringBuffer.Append(char.IsUpper(c) ? char.ToLower(c) : char.ToUpper(c));
                                    }
                                    input[i][j] = stringBuffer.ToString();
                                    break;
                                case "<del>":
                                    input[i][j] = "";
                                    break;
                                case "<rev>":
                                    char[] charArray = input[i][j].ToCharArray();
                                    Array.Reverse( charArray );
                                    input[i][j] = new string(charArray);
                                    break;
                            }
                        }
                        Console.Write(input[i][j]);
                    }
                }
                Console.WriteLine();
            }
        }
    }
