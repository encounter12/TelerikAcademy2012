using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    
    {
        string input = Console.ReadLine();
        int length = input.Length;
        Console.WriteLine(length);
        int result = 0;

        List<int> list = new List<int>();

        int startIndex = 0;
        
        for (int i = 0; i < length; i=startIndex)
        {

            if (input.Substring(i, 2) == "-!")
            {
                list.Add(0);
                input = input.Remove(i, i + 2);
               length = length - 2;
            
               i = 0;
                
            }
                
            else
                if (input.Substring(i, 2) == "**")
            {
                list.Add(1);
                input = input.Remove(i, i + 2);
                length = length - 2;
               
                i = 0;
               
            }
            else if (input.Substring(i, 2) == "&&")
            {
                list.Add(3);
                input = input.Remove(i, i + 2);
                length = length - 2;
           
                i = 0;
           
            }
            else if (input.Substring(i, 2) == "&-")
            {
                input = input.Remove(i, i + 2);
               length = length - 2;
              
                i =0;
                list.Add(4);
             
            }
            else if (input.Substring(i, 2) == "!-")
            {
                input = input.Remove(i, i + 2);
                length = length - 2;
              
                i = 0;
                list.Add(5);
            }
            else  if (input.Substring(i, 3) == "!!!")
                {
                    input = input.Remove(i, i + 3);
                   length = length - 3;
                    
                    i = 0;
                    list.Add(2);
                }
                else if (input.Substring(i, 3) == "&*!")
                {
                    input = input.Remove(i, i + 3);
                   length = length - 3;
                    i = 0;
                    list.Add(7);
                }
            else if (input.Substring(i, 4) == "*!!!")
                 {
                input = input.Remove(i, i + 4);
               length = length - 4;

                i = 0;
                list.Add(6);
                 }
                else if (input.Substring(i, 5) == "!!**!-")
               {
                input = input.Remove(i, i + 5);
               
                i = 0;
                 list.Add(8);
                }

            }
        foreach (var item in list)
        {
            Console.WriteLine(item);
        }

        for (int j = 0; j < list.Count; j++ )
        {
          int  p = 1;
          for (int i = 1; i <= j; i++)
          {
              int m = 9 * p;
              result = (list[j] * m) + (list[j] * m);
          }
        }
        Console.WriteLine();
        Console.WriteLine(length);
        }
    }

 