using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Task1
{
    class Task1
    {
        static void Main()
        {
            string number = Console.ReadLine();
            string result = "";
            for (int i = 0; i < number.Length; i++)
            {
                if (i + 1 < number.Length && (Convert.ToString(number[i]) + Convert.ToString(number[i + 1])) == "-!")
                {
                    result += "0";
                    i++;
                    continue;
                }
                else if (i + 1 < number.Length && (Convert.ToString(number[i]) + Convert.ToString(number[i + 1])) == "**")
                {
                    result += "1";
                    i++;
                    continue;
                }
                else if (i + 2 < number.Length && (Convert.ToString(number[i]) + Convert.ToString(number[i + 1]) + Convert.ToString(number[i + 2])) == "!!!")
                {
                    result += "2";
                    i++;
                    i++;
                    continue;
                }
                else if (i + 1 < number.Length && (Convert.ToString(number[i]) + Convert.ToString(number[i + 1])) == "&&")
                {
                    result += "3";
                    i++;
                    continue;
                }
                else if (i + 1 < number.Length && (Convert.ToString(number[i]) + Convert.ToString(number[i + 1])) == "&-")
                {
                    result += "4";
                    i++;
                    continue;
                }
                else if (i + 1 < number.Length && (Convert.ToString(number[i]) + Convert.ToString(number[i + 1])) == "!-")
                {
                    result += "5";
                    i++;
                    continue;
                }
                else if (i + 3 < number.Length && (Convert.ToString(number[i]) + Convert.ToString(number[i + 1]) + Convert.ToString(number[i + 2]) + Convert.ToString(number[i + 3])) == "*!!!")
                {
                    result += "6";
                    i++;
                    i++;
                    i++;
                    continue;
                }
                else if (i + 2 < number.Length && (Convert.ToString(number[i]) + Convert.ToString(number[i + 1]) + Convert.ToString(number[i + 2])) == "&*!")
                {
                    result += "7";
                    i++;
                    i++;
                    continue;
                }
                else if (i + 1 < number.Length && (Convert.ToString(number[i]) + Convert.ToString(number[i + 1]) + Convert.ToString(number[i + 2]) + Convert.ToString(number[i + 3]) + Convert.ToString(number[i + 4]) + Convert.ToString(number[i + 5])) == "!!**!-")
                {
                    result += "8"; 
                    i++;
                    i++;
                    i++;
                    i++;
                    i++;
                    continue;
                }
            }
            int counter = result.Length - 1;
            BigInteger sum = 0;
            for (int i = 0; i < result.Length; i++)
            {
                BigInteger num = result[i] - 48;
                sum += num * (BigInteger)Math.Pow(9, counter);
                counter--;
            }
            Console.WriteLine(sum);
        }
    }
}
