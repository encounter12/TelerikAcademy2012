using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.KukataIsDancing
{
    class Program
    {
        static void Main()
        {
            char[, ,] danceFloor = new char[3, 3, 3];
            for (int i = 0; i < 3; i++)
            {
                if (i % 2 == 0)
                {
                    int counter = 0;
                    for (int j = 0; j < 3; j++)
                    {
                        for (int k = 0; k < 3; k++)
                        {
                            if (counter % 2 == 0 && counter != 4)
                                danceFloor[i, j, k] = 'R';
                            if (counter % 2 == 1)
                                danceFloor[i, j, k] = 'B';
                            if (counter % 2 == 0 && counter == 4)
                                danceFloor[i, j, k] = 'G';
                            counter++;
                        }
                    }
                }
                else
                {
                    int counter = 0;
                    for (int j = 0; j < 3; j++)
                    {
                        for (int k = 0; k < 3; k++)
                        {
                            if (counter % 2 == 0)
                                danceFloor[i, j, k] = 'B';
                            if (counter % 2 == 1)
                                danceFloor[i, j, k] = 'G';
                            counter++;
                        }
                    }
                }
            }
            int nLines = int.Parse(Console.ReadLine());
            
            int left = 0;
            int forward = 0;
            for (int numberOfLine = 0; numberOfLine < nLines; numberOfLine++)
            {
                int currI = 1;
                int currJ = 0;
                int currK = 1;
                string pathDirection = Console.ReadLine();
                int path = 0;
                while (path < pathDirection.Length)
                {
                    for (int i = currI; i < 3; i++)
                    {
                        if (path >= pathDirection.Length)
                            break;
                        for (int j = currJ; j < 3; j++)
                        {
                            if (path >= pathDirection.Length)
                                break;
                            for (int k = currK; k < 3; k++)
                            {
                                //Console.WriteLine(danceFloor[currI, currJ, currK]);
                                if (path >= pathDirection.Length)
                                    break;
                                char directon = pathDirection[path];

                                if (directon=='L'||directon=='R')
                                {
                                    switch (left)
                                    {
                                        case 0:
                                            if (directon == 'L')
                                                left++;
                                            else
                                                left--;
                                            break;
                                        case 1:
                                            if (directon == 'L')
                                                left++;
                                            else
                                                left--;
                                            break;
                                        case 2:
                                            if (directon == 'L')
                                                left++;
                                            else
                                                left--;
                                            break;
                                        case 3:
                                            if (directon == 'L')
                                                left++;
                                            else
                                                left--;
                                            break;
                                        default:
                                            break;
                                    }

                                    if (left > 3)
                                        left = 0;
                                    if (left < 0)
                                        left = 3;

                                    if (left == 0)
                                        forward = 0;
                                    else if (left == 1)
                                        forward = 1;
                                    else if (left == 2)
                                        forward = 2;
                                    else if (left == 3)
                                        forward = 3;
                                }
                                if (directon=='W')
                                {
                                    switch (forward)
                                    {
                                        case 0:
                                            if ((currI + 1) > 2)
                                                currI = 0;
                                            else
                                                currI++;
                                            break;
                                        case 1:
                                            if ((currK + 1) > 2)
                                                currK = 0;
                                            else
                                                currK++;
                                            break;
                                        case 2:
                                            if ((currI - 1) < 0)
                                                currI = 2;
                                            else
                                                currI--;
                                            break;
                                        case 3:
                                               if ((currK - 1) < 0)
                                                currK = 2;
                                            else
                                                currK--;
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                path++;
                            }
                        }
                    }
                }
                if (danceFloor[currI, currJ, currK] == 'G')
                    Console.WriteLine("GREEN");
                else if (danceFloor[currI, currJ, currK] == 'B')
                    Console.WriteLine("BLUE");
                else if (danceFloor[currI, currJ, currK] == 'R')
                    Console.WriteLine("RED");
            }
        }
    }
}
