using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace GagNumbers9
{
    class GagNumbers9
    {
        static void Main(string[] args)
        {
            string cipher = Console.ReadLine();
            List<int> numbers = new List<int>();
            int i = 0;
            int n = cipher.Length;
            BigInteger result = 0;
            int offset = 1;
            while (i < n)
            {
                string compare = cipher.Substring(i, 2);
                if (compare == "-!")
                {
                    numbers.Add(0); offset = 2;
                }
                else
                {
                    if (compare == "**")
                    {
                        numbers.Add(1); offset = 2;
                    }
                    else
                    {
                        if ((i < n - 2) && (cipher.Substring(i, 3) == "!!!"))
                        {
                            numbers.Add(2); offset = 3;
                        }
                        else
                        {
                            if (compare == "&&")
                            {
                                numbers.Add(3); offset = 2;
                            }
                            else
                            {
                                if (compare == "&-")
                                {
                                    numbers.Add(4); offset = 2;
                                }
                                else
                                {
                                    if (compare == "!-")
                                    {
                                        numbers.Add(5); offset = 2;
                                    }
                                    else
                                    {
                                        if ((i < n - 3) && (cipher.Substring(i, 4) == "*!!!"))
                                        {
                                            numbers.Add(6); offset = 4;
                                        }
                                        else
                                        {
                                            if ((i < n - 2) && (cipher.Substring(i, 3) == "&*!"))
                                            {
                                                numbers.Add(7); offset = 3;
                                            }
                                            else if ((i < n - 5) && (cipher.Substring(i, 6) == "!!**!-"))
                                            {
                                                numbers.Add(8); offset = 6;
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                i = i + offset;
            }
            int count = 0;
            int k = numbers.Count - 1;
            while (k >= 0)
            {
                result = result + numbers[k] * Pow(9, count);
                count++;
                k--;
            }

            Console.WriteLine(result);
        }
        public static BigInteger Pow(int a, int b)
        {
            BigInteger result = 1;
            for (int i = 0; i < b; i++)
            {
                result = result * 9;
            }
            if (b < 1) result = 1;
            {
                return result;
            }
        }
    }
}
