using System;
using System.Collections.Generic;

class Program
{

    static void Main()
    {
        //Console.WriteLine(Decode("*!!!"));
        string strGagNumber = Console.ReadLine();
        Console.WriteLine(Decode(strGagNumber));
        //Console.WriteLine(Decode("***!!!"));
       //Console.ReadLine();
        //Console.WriteLine(Decode("!!!**!-"));
        //Console.WriteLine(Decode("!!!**!-"));
    }
    private static readonly Dictionary<string, int> GagNumbers = new Dictionary<string, int>
    {
        {"-!", 0},
        {"**", 1},
        {"!!!", 2},
        {"&&", 3},
        {"&-", 4},
        {"!-", 5},
        {"*!!!", 6},
        {"&*!", 7},
        {"!!**!-", 8},
    };
    private static int Decode(string strGagNumber)
    {
        int retVal = 0;
        int temp = 0;
        foreach (KeyValuePair<string, int> pair in GagNumbers)
        {
            while (strGagNumber.IndexOf(pair.Key.ToString()) == 0)
            {
                retVal += int.Parse(pair.Value.ToString());
                strGagNumber = strGagNumber.Substring(pair.Key.ToString().Length);
                temp = retVal;
                if (temp > 0) { retVal= retVal * 9; }
            }
        }
        retVal = temp;
        return retVal;

    }

}