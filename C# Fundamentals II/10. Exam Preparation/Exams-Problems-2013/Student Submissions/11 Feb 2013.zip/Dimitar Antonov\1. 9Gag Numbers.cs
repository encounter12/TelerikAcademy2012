using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace P1
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            BigInteger result = 0;
            int offset = 1;
            List<int> digits = new List<int>();
            int i=0;
            int n = input.Length;
            while (i < n)
            {
                string sub2 = input.Substring(i, 2);
                if ((i < n-5) && (input.Substring(i, 6) == "!!**!-")) { digits.Add(8); offset = 6; }
                else 
                {
                    if ((i <n-2) && (input.Substring(i, 3) == "&*!")) { digits.Add(7); offset = 3; }
                    else
                    {
                        if ((i <n-3) && (input.Substring(i, 4) == "*!!!")) { digits.Add(6); offset = 4; }
                        else
                        {
                            if (sub2 == "!-") { digits.Add(5); offset = 2; }
                            else
                            {
                                if (sub2 == "&-") { digits.Add(4); offset = 2; }
                                else
                                {
                                    if (sub2 == "&&") { digits.Add(3); offset = 2; }
                                    else
                                    {
                                        if ((i <n-2) && (input.Substring(i, 3) == "!!!")) { digits.Add(2); offset = 3; }
                                        else
                                        {
                                            if (sub2 == "**") { digits.Add(1); offset = 2; }
                                            else if (sub2 == "-!") { digits.Add(0); offset = 2; }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                i = i + offset;
            }
            int k = 0;
            for (int j = digits.Count-1; j >=0; j--)
            {
                result = result + digits[j] * Power(9, k);
                k++;
            }
            Console.WriteLine(result);
        }
        public static BigInteger Power(int a, int b)
        {
            BigInteger result = 1;
            for (int i = 0; i < b; i++)
            {
                result = result * 9;
            }
            if (b < 1) result = 1;
            return result;
        }
        public static string Test()
        {
            int n = int.Parse(Console.ReadLine());
            List<int> digits = new List<int>();
            for (int i = 0; i < n; i++)
            {
                digits.Add(int.Parse(Console.ReadLine()));
            }
            int result=0;
            int k = 0;
            for (int j = digits.Count - 1; j >= 0; j--)
            {
                result = result + digits[j] * (int)Math.Pow(9, k);
                k++;
            }
            Console.WriteLine(result);
            StringBuilder test = new StringBuilder();
            for (int i = 0; i < digits.Count; i++)
            {
                string x = "";
                switch (digits[i])
                {
                    case 0: x = "-!"; break;
                    case 1: x = "**"; break;
                    case 2: x = "!!!"; break;
                    case 3: x = "&&"; break;
                    case 4: x = "&-"; break;
                    case 5: x = "!-"; break;
                    case 6: x = "*!!!"; break;
                    case 7: x = "&*!"; break;
                    case 8: x = "!!**!-"; break;
                }
                test.Append(x);
            }
            return test.ToString();
        }
    }
}
