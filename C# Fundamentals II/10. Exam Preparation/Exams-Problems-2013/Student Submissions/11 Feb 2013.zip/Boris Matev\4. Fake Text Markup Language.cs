using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace _4.FTML
{
    class Program
    {
        static string[] code;
        static List<string> tagOrder = new List<string>();
        static StringBuilder output = new StringBuilder();
        static void Main(string[] args)
        {
            initCode();
            performCode();
            Console.WriteLine(output.ToString());
        }
        static void performCode()
        {
            for (int i = 0; i < code.Length; i++)
            {
                performLine(code[i]);
                if (i != code.Length - 1)
                {
                    output.AppendLine();
                }
            }
        }
        static void performLine(string line)
        {
            StringBuilder formatted = new StringBuilder();
            for (int i = 0; i < line.Length; i++)
            {
                if (line[i] == '<' && line[i + 1] != '/')
                {
                    string tag = line.Substring(i, line.IndexOf(">", i + 1) - i + 1);
                    switch (tag)
                    {
                        case "<upper>":
                            tagOrder.Add("upper"); break;
                        case "<lower>":
                            tagOrder.Add("lower"); break;
                        case "<toggle>":
                            tagOrder.Add("toggle"); break;
                        case "<del>":
                            tagOrder.Add("del"); break;
                        case "<rev>":
                            tagOrder.Add("rev"); break;
                        default:
                            break;
                    }
                    i += tag.Length - 1;
                }
                else if (line[i] == '<' && line[i + 1] == '/')
                {
                    i = line.IndexOf(">", i + 1);
                }
                else
                {
                    
                    if (tagOrder.Count() > 0)
                    {
                        string tag = tagOrder.Last();
                        string text = line.Substring(i, line.IndexOf("</" + tag, i) - i);
                        formatted.Append(text);
                        text = formatted.ToString();
                        formatted.Clear();
                        bool isDel = false;
                        while (tagOrder.Count() > 0)
                        {
                            tag = tagOrder.Last();
                            if (isDel)
                            {
                                break;
                            }
                            switch (tag)
                            {
                                case "upper":
                                    text = text.ToUpper(); break;
                                case "lower":
                                    text = text.ToLower(); break;
                                case "toggle":
                                    text = performToggle(text); break;
                                case "del":
                                    isDel = true;
                                    i = line.IndexOf("</" + tag, i); break;
                                case "rev":
                                    char[] bla = text.ToCharArray();
                                    bla = bla.Reverse().ToArray();
                                    text = new string(bla);
                                    break;
                                default:
                                    break;
                            }
                            formatted.Append(text);
                            tagOrder.RemoveAt(tagOrder.Count() - 1);
                            i = line.IndexOf(">", i);
                            if (tagOrder.Count == 0)
                            {
                                output.Append(formatted);
                                formatted.Clear();
                            }
                            else if ((i < line.Length - 1 && line[i + 1] != '<'))
                            {
                                break;
                            }
                            else
                            {
                                formatted.Clear();
                            }
                        }
                    }
                    else
                    {
                        output.Append(line[i]);
                    }
                }
            }
        }
        static string performToggle(string text)
        {
            StringBuilder textBuild = new StringBuilder();
            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] >= 'A' && text[i] <= 'Z')
                {
                    textBuild.Append((char)(text[i] + 32));
                }
                else if (text[i] >= 'a' && text[i] <= 'z')
                {
                    textBuild.Append((char)(text[i] - 32));
                }
            }
            return textBuild.ToString();
        }
        static void initCode()
        {
            int limit = int.Parse(Console.ReadLine());
            code = new string[limit];
            for (int i = 0; i < limit; i++)
            {
                code[i] = Console.ReadLine();
            }
        }
    }
}
