using System;
using System.Collections.Generic;

class KukataIsDancing
{
    static int n;
    static string[] moves;
    static char[,] floorColors = { {'R','B','R',},
                                   {'B','G','B',},
                                   {'R','B','R',},};
    static int direction = 0; //0 - up, 1 - right, 2 - down, 3 - left

    class Position
    {
        public static int XCoord { get; set; }
        public static int YCoord { get; set; }
    }

    static void Main()
    {
        InputData();
        PlayMoves();
    }

    private static void PlayMoves()
    {
        for (int dance = 0; dance < moves.Length; dance++)
        {
            for (int i = 0; i < moves[dance].Length; i++)
            {
                if (moves[dance][i] == 'L')
                {
                    direction--;
                    if (direction < 0)
                    {
                        direction = 3;
                    }
                }
                else if (moves[dance][i] == 'R')
                {
                    direction++;
                    if (direction > 3)
                    {
                        direction = 0;
                    }
                }
                else if (moves[dance][i] == 'W')
                {
                    switch (direction)
                    {
                        case 0:
                            Position.YCoord++;
                            if (Position.YCoord > 2)
                            {
                                Position.YCoord = 0;
                            }
                            break;
                        case 1:
                            Position.XCoord++;
                            if (Position.XCoord > 2)
                            {
                                Position.XCoord = 0;
                            }
                            break;
                        case 2:
                            Position.YCoord--;
                            if (Position.YCoord < 0)
                            {
                                Position.YCoord = 2;
                            }
                            break;
                        case 3:
                            Position.XCoord--;
                            if (Position.XCoord < 0)
                            {
                                Position.XCoord = 2;
                            }
                            break;
                    }
                }
            }
            char color = floorColors[Position.XCoord, Position.YCoord];
            switch (color)
            {
                case 'R': Console.WriteLine("RED");
                    break;
                case 'G': Console.WriteLine("GREEN");
                    break;
                case 'B': Console.WriteLine("BLUE");
                    break;
            }
            Position.XCoord = 1;
            Position.YCoord = 1;
        }
    }

    private static void InputData()
    {
        n = int.Parse(Console.ReadLine());
        moves = new string[n];
        for (int i = 0; i < n; i++)
        {
            moves[i] = Console.ReadLine();
        }

        Position.XCoord = 1;
        Position.YCoord = 1;
    }
}
