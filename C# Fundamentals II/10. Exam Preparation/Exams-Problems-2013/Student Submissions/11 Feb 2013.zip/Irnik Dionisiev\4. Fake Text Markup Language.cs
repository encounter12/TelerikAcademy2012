using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _4_th_task
{
    class Program
    {
        static void Print(char[] text)
        {
            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] != '>')
                {
                    Console.Write(text[i]);
                }
            }
            Console.WriteLine();
        }
        static void lower(char[] input, int begin, int end)
        {
            for (int i = begin; i < end + 1; i++)
            {
                if (input[i] >='A' && input[i] <='Z')
                {
                    input[i] = Convert.ToChar(input[i] - 'A' + 'a');
                }
            }
        }
        static void upper(char[] input, int begin, int end)
        {
            for (int i = begin; i < end + 1; i++)
            {
                if (input[i] >= 'a' && input[i] <= 'z')
                {
                    input[i] = Convert.ToChar(input[i] - 'a' + 'A');
                }
            }
        }
        static void toggle(char[] input, int begin, int end)
        {
            for (int i = begin; i < end + 1; i++)
            {
                if (input[i] >= 'a' && input[i] <= 'z')
                {
                    input[i] = Convert.ToChar(input[i] - 'a' + 'A');
                }
                else if (input[i] >= 'A' && input[i] <= 'Z')
                {
                    input[i] = Convert.ToChar(input[i] - 'A' + 'a');
                }
			}
        }
        static void rev(char[] input, int begin, int end)
        {
            char reverser;
            for (int i = begin; i < begin + (end - begin)/2 + 1; i++)
            {
                reverser = input[i];
                input[i] = input[(end  - (i - begin))];
                input[(end - (i - begin))] = reverser;
            }
        }
        static void del(char[] input, int begin, int end)
        {
            for (int i = begin; i < end + 1; i++)
            {
                input[i] = '>';
            }
        }
        static void FTMLConvertor(char[] input)
        {
            char tagName;
            for (int i = 0; i < input.Length - 1; i++)//search closed tag
            {
                if (input[i] == '<' & input[i + 1] == '/')
                {
                    tagName = input[i + 2];
                    for (int j = i; j >= 0; j--)
                    {
                        if (input[j] == '<' && input[j + 1] == tagName)
                        {
                            switch (tagName)
                            {
                                case 'l': lower(input, j + 7, i - 1); del(input, j, j + 6); del(input, i, i + 6); break;
                                case 'u': upper(input, j + 7, i - 1); del(input, j, j + 6); del(input, i, i + 6); break;
                                case 't': toggle(input, j + 8, i - 1); del(input, j, j + 7); del(input, i, i + 7); break;
                                case 'd': del(input, j, i + 4); break;
                                case 'r': rev(input, j + 5, i - 1); del(input, j, j + 4); del(input, i, i + 5); break;
                                default:
                                    break;
                            }
                            break;
                        }
                    }
                }
            }
            Print(input);
        }
        static void Main(string[] args)
        {
            int numRows = Convert.ToInt32(Console.ReadLine());
            string[] input = new string[numRows];
            for (int i = 0; i < numRows; i++)
            {
                input[i] = Console.ReadLine();
                FTMLConvertor(input[i].ToCharArray());
            }
        }
    }
}
