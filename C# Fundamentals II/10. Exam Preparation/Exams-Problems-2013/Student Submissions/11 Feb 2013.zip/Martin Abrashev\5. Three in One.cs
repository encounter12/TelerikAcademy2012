using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeTasks
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] points = input.Split(',');

            input = Console.ReadLine();
            string[] cakes = input.Split(',');
            input = Console.ReadLine();
            int friends = int.Parse(input);

            input = Console.ReadLine();
            string[] sCoins = input.Split(' ');
            int G1 = int.Parse(sCoins[0]);
            int S1 = int.Parse(sCoins[1]);
            int B1 = int.Parse(sCoins[2]);
            int G2 = int.Parse(sCoins[3]);
            int S2 = int.Parse(sCoins[4]);
            int B2 = int.Parse(sCoins[5]);

            Console.WriteLine(firstTask(points));
            Console.WriteLine(MyCakes(cakes,friends));
            Console.WriteLine(coins(G1, S1, B1, G2, S2, B2));
        }

        static int firstTask(string[] points)
        {
            int max = int.Parse(points[0]);
            int index = 0;

            for (int i = 1; i < points.Length; i++)
            {
                int current = int.Parse(points[i]);
                if (current > max)
                {
                    max = current;
                    index = i;
                }
            }

            for (int i = 0; i < points.Length; i++)
            {
                if (i != index && int.Parse(points[i]) == max)
                {
                    return -1;
                }
            }

            return index;
        }

        static int MyCakes(string[] cakes,int friends)
        {
            Array.Sort(cakes, (a,b) => b.CompareTo(a));
            int myCakes = 0;

            for (int i = 0; i < cakes.Length; i+= friends + 1)
            {
                myCakes += int.Parse(cakes[i]);
            }

            return myCakes;
        }

        static int coins(int G1, int S1, int B1, int G2, int S2, int B2)
        {
            int result = 0;
            result += Math.Abs(G1 - G2);
            result += Math.Abs(S1 - S2);
            result += Math.Abs(B1 - B2);

            if (result % 11 > 0)
            {
                return (result % 11) + 1;
            }
            else
            {
                return result % 11;
            }
        }
    }
}
