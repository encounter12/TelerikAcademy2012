using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2_nd_task
{
    class Program
    {
        static void Clear(int[] array, int len)
        {
            for (int i = 0; i < len; i++)
            {
                array[i] = 0;
            }
        }
        private static bool notWolkedTrue(int[] WalkedTrue, int pathLen)
        {
            for (int i = 0; i < pathLen; i++)
            {
                if (WalkedTrue[i] == WalkedTrue[pathLen])
                {
                    return false;
                }
            }
            return true;
        }
        static void Main(string[] args)
        {
            int numRows = Convert.ToInt32(Console.ReadLine());
            int[,] table = new int[numRows, 1000];
            bool FirstRow = true;
            int lenFirstRow = 0;
            for (int i = 0, j = 0; i < numRows; i++)
            {
                foreach (var item in Console.ReadLine().Split(','))
	            {
		            table[i, j] = Convert.ToInt32(item.TrimStart(' '));
                    j++;
	            }
                if (FirstRow)
	            {
		             lenFirstRow = j;
                     FirstRow = false;
	            }
                j = 0;
            }
            int maxSum = 0, path = 0;
            int[] WalkedTrue = new int[1000 * numRows];
            for (int i = 0; i < lenFirstRow; i++)
            {
                Clear(WalkedTrue, path);
                WalkedTrue[0] = i;
                path = 0;
                while (notWolkedTrue(WalkedTrue, path) && table[path%numRows, WalkedTrue[path]] >= 0)
                {
                    path++;
                    WalkedTrue[path] = table[(path - 1) % numRows, WalkedTrue[path - 1]];
                }
                path++;
                if (maxSum < path + Math.Abs(table[(path - 1)%numRows, WalkedTrue[path - 1]]))
                {
                    maxSum = path + Math.Abs(table[(path - 1) % numRows, WalkedTrue[path - 1]]);
                }
            }
            Console.WriteLine(maxSum);
        }
    }
}
