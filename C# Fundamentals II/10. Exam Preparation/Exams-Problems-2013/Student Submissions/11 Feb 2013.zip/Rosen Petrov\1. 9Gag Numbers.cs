using System;
using System.Numerics;
using System.Text;

class Program
{
    static void Main()
    {
        StringBuilder inputSb = new StringBuilder();
        string input = Console.ReadLine();
        for (int i = 0; i < input.Length; i++)
        {
            inputSb.Append(input[i]);
        }
        Transform(Convert(inputSb));
    }

    static StringBuilder Convert(StringBuilder toConvert)
    {
        StringBuilder temp = new StringBuilder();
        StringBuilder toReturn = new StringBuilder();
        for (int i = 0; i < toConvert.Length  ; i++)
        {
            temp.Append(toConvert[i]);
            switch (temp.ToString())
            {
                case "-!":
                    toReturn.Append(0);
                    temp.Clear();
                    break;
                case "**":
                    toReturn.Append(1);
                    temp.Clear();
                    break;
                case "!!!":
                    toReturn.Append(2);
                    temp.Clear();
                    break;
                case "&&":
                    toReturn.Append(3);
                    temp.Clear();
                    break;
                case "&-":
                    toReturn.Append(4);                    
                    temp.Clear();
                    break;
                case "!-":
                    toReturn.Append(5);                    
                    temp.Clear();
                    break;
                case "*!!!":
                    toReturn.Append(6);
                    temp.Clear();
                    break;
                case "&*!":
                    toReturn.Append(7);
                    temp.Clear();
                    break;
                case "!!**!-":
                    toReturn.Append(8);
                    temp.Clear();
                    break;
                default:
                    break;
            }
        }
        
        return toReturn;
    }

    static void Transform(StringBuilder transform)
    {
        int stepen = 0;
        BigInteger final = 0;
        for (int i = transform.Length - 1; i >= 0; i--)
        {

            final += (transform[i] - '0') * BigInteger.Pow(9, stepen);
            stepen++;
        }
        Console.WriteLine(final);
    }
}
