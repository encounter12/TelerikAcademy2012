using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class threeinone
    {
        static void Main(string[] args)
        {
            string number = Console.ReadLine();
           
            string cakes = Console.ReadLine();
            int friends = int.Parse(Console.ReadLine());
            string[] numcaces = cakes.Split(',');

            int bytesss = numcaces.Length;
            int[] points = new int[bytesss];
            for (int i = 0; i < bytesss; i++)
            {
                points[i] = int.Parse(numcaces[i]);
            }
            Array.Sort(points);
            friends++;
            int totalbytes = 0;
            for (int i = bytesss - 1; i > -1; i = i - friends)
            {
                totalbytes += points[i];
            }

            string coins = Console.ReadLine();
            string[] valuesstr = coins.Split(' ');
            int lenghhhhh = valuesstr.Length;
            int[] values = new int[lenghhhhh];
            for (int i = 0; i < lenghhhhh; i++)
            {
                values[i] = int.Parse(valuesstr[i]);
            }
            int tempbronze = 0;
            int tempsilver = 0;
            int tempgold = 0;
            tempbronze = values[2] - values[5];
            tempsilver = values[1] - values[4];
            tempgold = values[0] - values[3];
            int bankgive = 11;
            int banktake = 9;
            int count = 0;
            int none = 0;


            NewMethod21(number);
            Console.WriteLine(totalbytes);

            if (values[0] < values[3] && values[1] < values[4] && values[2] < values[5])
            {
                Console.WriteLine("-1");
            }
            if (values[0] == values[3] && values[1] == values[4] && values[2] == values[5])
            {
                Console.WriteLine("0");
            }
            while (tempgold < 0)
            {
                if (tempsilver > 0)
                {
                    tempsilver = tempsilver - bankgive;
                    count++;
                    tempgold++;
                    continue;
                }
                if (tempbronze > 0)
                {
                    tempbronze = tempbronze - bankgive * 11;
                    count += 12;
                    tempgold++;
                }
                if (tempsilver <= 0 && tempbronze <= 0 && tempbronze <= 0)
                {
                    Console.WriteLine("-1");
                    break;
                }

            }
            while (tempsilver < 0)
            {
                if (tempgold > 0)
                {
                    tempsilver = tempsilver + banktake;
                    count++;
                    tempgold--;
                    continue;
                }
                if (tempbronze > 0)
                {
                    tempbronze = tempbronze - bankgive;
                    count++;
                    tempsilver++;
                }
                if (tempgold <= 0 && tempbronze <= 0 && tempbronze <= 0)
                {
                    Console.WriteLine("-1");
                    break;
                }

            }
            while (tempbronze < 0)
            {
                if (tempgold > 0)
                {
                    tempgold--;
                    count++;
                    int temp = 9;
                    while (temp > 0 || tempbronze > 0)
                    {
                        tempbronze = tempbronze + banktake;
                        count++;
                        temp--;
                    }
                    continue;
                }
                if (tempsilver > 0)
                {
                    tempbronze = tempbronze + banktake;
                    count++;
                    tempsilver--;
                }
                if (tempgold <= 0 && tempsilver <= 0 && tempbronze <= 0)
                {
                    Console.WriteLine("-1");
                    break;
                }

            }
            Console.WriteLine(count);


        }     
        
        
        
        
        
        
        
        
        
        
        private static void NewMethod21(string number)
        {
            string[] nums = number.Split(',');
            int[] points = new int[nums.Length];
            int lenghttt = nums.Length;
            for (int i = 0; i < lenghttt; i++)
            {
                points[i] = int.Parse(nums[i]);
            }
            int count = 0;
            int max = 0;
            int poitpress = 0;
            int poitpressmax = 0;
            for (int i = 0; i < lenghttt; i++)
            {
                if (points[i] > 21)
                {
                    continue;
                }
                if (points[i] == 21)
                {
                    if (count != 0)
                    {
                        poitpressmax = -1;
                        count = 0;
                    }
                    else
                        count = i + 1;                              
                }
                if (points[i] < 21)
                {
                    if (points[i] == max)
                    {
                        poitpress = -1;
                    }
                    if (points[i] > max)
                    {
                        max = points[i];
                        poitpress = i;
                    }
                }
            }
            if (poitpressmax == -1)
            {
                Console.WriteLine("-1");
            }
            else if (count != 0)
            {
                Console.WriteLine(count - 1);
            }
            else if (poitpress == -1)
            {
                {
                    Console.WriteLine("-1");
                }
            }
            else if (poitpress > 0)
            {
                Console.WriteLine(poitpress);
            }
            else
                Console.WriteLine("-1");
        }
    }
}
