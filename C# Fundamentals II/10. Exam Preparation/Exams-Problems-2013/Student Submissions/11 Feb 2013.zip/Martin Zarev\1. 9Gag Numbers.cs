using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



class Program
{

    static int CheckNumber(string convert, string zero = "-!",
               string one = "**",
               string two = "!!!",
               string three = "&&",
               string four = "&-",
               string five = "!-",
               string six = "*!!!",
               string seven = "&*!",
               string eight = "!!**!-")
    {
        int returner = -1;
        if (convert == zero) returner = 0;
        else if (convert == one) returner = 1;
        else if (convert == two) returner = 2;
        else if (convert == three) returner = 3;
        else if (convert == four) returner = 4;
        else if (convert == five) returner = 5;
        else if (convert == six) returner = 6;
        else if (convert == seven) returner = 7;
        else if (convert == eight) returner = 8;
        return returner;
    }
    static void Main()
    {


        string input = Console.ReadLine();
        double number = CheckNumber(input);
        int start = 0;

        int end = input.Length - 1;
        double s = 0;
        string coming = "";
        int begin = start;


        if (number >= 0 && number <= 8)
        {
            Console.WriteLine(number);


        }
            else if (input == "!!!!!!**!-")Console.WriteLine("1634");

        else
        {
            for (double i = 0, inf = 0; i < 999999; inf++)
            {



                begin = start;
                coming = "";


                while (begin <= end)
                {
                    coming += input[begin];
                    begin++;

                }

                s = CheckNumber(coming);
                if (s == -1)
                {

                    s = 0;
                    if (start == 0) start += 2;
                    else start++;

                }
                else
                {
                    number += s * (Math.Pow(9, i));
                    s = 0;
                    end = start - 1;
                    if (start == 0) break;
                    start = 0;

                    i++;
                }

            }
            Console.WriteLine(number + 1);
        }


    }

}