using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kukata_IsDancing
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberOfDances = Int32.Parse(Console.ReadLine());
            string[] dances = new string[numberOfDances];

            //string[] directions = { "left", "right", "up", "down" };
            Dictionary <String ,String > combinations = new Dictionary <string,string >();
            combinations.Add("left+L", "down");
            combinations.Add("left+R", "up");
            combinations.Add("right+L", "up");
            combinations.Add("right+R", "down");
            combinations.Add("up+L", "left");
            combinations.Add("up+R", "right");
            combinations.Add("down+L", "right");
            combinations.Add("down+R", "left");

            for (int i = 0; i < dances.Length; i++)
            {
                dances[i] = Console.ReadLine();
            }

            string[,] danceFloor = new string[3,3] { {"RED","BLUE","RED"},
                                                     {"BLUE","GREEN","BLUE"},
                                                     {"RED","BLUE","RED"} };
            
            for (int i = 0; i < dances.Length; i++)
            {
                int danceFloor_i = 1,
                    danceFloor_j = 1;
                string direction="right";
                for (int j = 0; j < dances[i].Length; j++)
                {
                    if (dances[i][j] == 'L' || dances[i][j]=='R')
                    {
                        if(combinations .Keys .Contains (direction + "+" + dances[i][j]))
                        {
                            direction = combinations [direction + "+" + dances[i][j]];
                        }
                    }
                    else
                    {
                        if(direction=="right")
                        {
                            danceFloor_j = (danceFloor_j +1)%3;
                        }
                        if(direction=="left")
                        {
                            danceFloor_j = (danceFloor_j -1)>=0?danceFloor_j - 1:2;
                        }
                        if(direction=="down")
                        {
                            danceFloor_i = (danceFloor_i +1)%3;
                        }
                        if (direction == "up")
                        {
                            danceFloor_i = (danceFloor_i -1)>=0?danceFloor_i - 1:2;
                        }

                    }
                }
                Console .WriteLine (danceFloor [danceFloor_i ,danceFloor_j ]);
            }
        }
    }
}
