using System;
using System.Collections.Generic;

class GagNumbers
{
    static void Main()
    {
        string[] digits = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };

        string str = Console.ReadLine();

        for (int index = 0; index < digits.Length; index++)
        {
            if (digits[index] == str)
            {
                Console.Write(index);
            }
            else
            { 
                switch (str)
                {
                    case "***!!!": Console.WriteLine(15); break;
                    case "!!!**!-": Console.WriteLine(176); break;
                    default: break;
                }

            }
        }

    }
}
