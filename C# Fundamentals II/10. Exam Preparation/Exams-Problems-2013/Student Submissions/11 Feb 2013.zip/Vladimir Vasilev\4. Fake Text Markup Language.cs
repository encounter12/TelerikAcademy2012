using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());
            string input = Console.ReadLine();
//            string input = @"We <rev>are</rev> <upper>living</upper> <lower>IN</lower> a <upper>yellow submarine</upper>.
//                        <upper>We</upper> don't <del>have</del> <upper>anything</upper> else.";

            string deleted = Regex.Replace(input, "<del>(.*?)</del>", String.Empty);

            string reversed = Regex.Replace(deleted, "<rev>(.*?)</rev>", "");
           
            string changeUp = Regex.Replace(reversed, "<upper>(.*?)</upper>", m => m.Groups[1].Value.ToUpper());

            string changeLow = Regex.Replace(changeUp, "<lower>(.*?)</lower>", m => m.Groups[1].Value.ToLower());
            
            string output = changeLow;
            Regex trimmer = new Regex(@"\s\s+");

            output = trimmer.Replace(output, " ");
            
            int counter = 1;
            foreach (char element in output)
            {                
                Console.Write(element);
                counter++;

                if ((counter > output.Length / lines) && (element == ' '))
                {
                    Console.WriteLine();
                    counter = 1;
                }             
            }

            Console.WriteLine();
        }
    }
}
