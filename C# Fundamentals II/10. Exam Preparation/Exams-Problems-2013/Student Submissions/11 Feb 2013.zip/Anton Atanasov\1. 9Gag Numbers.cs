using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cmonAlready
{
    class Program
    {
        static void Main()
        {
            string input = Console.ReadLine();
            int final = 0;
            StringBuilder builder = new StringBuilder();
            char[] result = input.ToArray();
            int count = 0;
            Array.Reverse(result);

            Dictionary<string, int> dict = new Dictionary<string, int>()
	{
	     {"!-", 0},
	    {"**", 1},
	    {"!!!", 2},
	    {"&&", 3},
        {"-&", 4},
        {"-!", 5},
        {"!!!*", 6},
        {"!*&", 7},
        {"-!**!!", 8}
  
	};
            foreach (var item in result)
            {

                builder.Append(item);
                string rofl = builder.ToString();
                if (dict.ContainsKey(rofl))
                {

                    ++count;
                    if (count > 1)
                    {
                        final += dict[rofl] * 9;
                    }
                    else
                    {
                        final += dict[rofl];
                    }

                    builder.Clear();
                }
            }
            Console.WriteLine(final);
        }
    }
}
