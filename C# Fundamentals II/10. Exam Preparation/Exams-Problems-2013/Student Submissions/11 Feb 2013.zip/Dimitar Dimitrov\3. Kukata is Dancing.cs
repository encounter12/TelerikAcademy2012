using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        string[,] square = {
                           {" ","RED","BLUE","RED"," "},
                           {"RED","RED","BLUE","RED","RED"},
                           {"BLUE","BLUE","GREEN","BLUE","BLUE"},
                           {"RED","RED","BLUE","RED","RED"},
                           {" ","RED","BLUE","RED"," "},
                           };

        int lines =  int.Parse(Console.ReadLine());
        string[] linesArray = new string[lines];

        for (int l = 0; l < lines; l++)
       {
            linesArray[l] = Console.ReadLine();
        }
    
        //string[] linesArray = { "LLRR","WWWWWWWWWWWW","WLWRW","WWL","LWRL" };

        int dir = 0;
        string value = "G";
        int tempRow = 2;
        int tempCol = 2;

        for (int m = 0; m < linesArray.Length; m++)
        {

            char[] pathArray = linesArray[m].ToCharArray();

            for (int i = 0; i < pathArray.Length; i++)
            {
                if (pathArray[i] == 'R')
                {
                    if (dir == 3)
                    {
                        dir = 0;
                    }
                    else
                    {
                        dir = dir + 1;
                    }
                }
                if (pathArray[i] == 'L')
                {
                    if (dir == 0)
                    {
                        dir = 3;
                    }
                    else
                    {
                        dir = dir - 1;
                    }

                }
                if (pathArray[i] == 'W')
                {
                    if (dir == 0)
                    {
                        tempRow = tempRow - 1;
                        tempCol = tempCol;
                        if (tempRow == 0)
                        {
                            tempRow = 3;
                        }
                    }
                    if (dir == 1)
                    {
                        tempRow = tempRow;
                        tempCol = tempCol + 1;
                        if (tempCol == 4)
                        {
                            tempCol = 1;
                        }
                    }
                    if (dir == 2)
                    {
                        tempRow = tempRow + 1;
                        tempCol = tempCol;
                        if (tempRow == 4)
                        {
                            tempRow = 1;
                        }
                    }
                    if (dir == 3)
                    {
                        tempRow = tempRow;
                        tempCol = tempCol - 1;
                        if (tempCol == 0)
                        {
                            tempCol = 3;
                        }
                    }
                }
            }
            Console.WriteLine(square[tempRow, tempCol]);
            tempCol = 2;
            tempRow = 2;
        }
        
    }
}
