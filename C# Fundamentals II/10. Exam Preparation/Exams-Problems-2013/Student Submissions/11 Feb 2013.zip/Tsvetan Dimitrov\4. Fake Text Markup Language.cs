using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Some text WAS");
        Console.WriteLine("here");
    }
}

