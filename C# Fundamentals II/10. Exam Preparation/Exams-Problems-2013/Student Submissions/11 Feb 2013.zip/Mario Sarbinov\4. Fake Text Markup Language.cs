using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FakeTextMarkup
{
    class FakeTextMarkup
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] text = new string[n];
            for (int i = 0; i < n; i++)
            {
                text[i] = Console.ReadLine();
            }
            int index, indexUp, indexLow, indexTog, indexDel, indexRev;
            for (int i = 0; i < n; i++)
            {
                index = text[i].Length / 2;
                indexUp = text[i].IndexOf("</upper>", index);
                indexLow = text[i].IndexOf("</lower>", index);
                indexTog = text[i].IndexOf("</toggle>", index);
                indexDel = text[i].IndexOf("</del>", index);
                indexRev = text[i].IndexOf("</rev>", index);
                if (indexUp != -1)
                {
                    text[i] = text[i].Remove(indexUp, 8);
                    indexUp = text[i].IndexOf("<upper>");
                    text[i] = text[i].Remove(indexUp, 7);
                    text[i] = text[i].ToUpper();
                }
                if (indexLow != -1)
                {
                    text[i] = text[i].Remove(indexLow, 8);
                    indexLow = text[i].IndexOf("<lower>");
                    text[i] = text[i].Remove(indexLow, 7);
                    text[i] = text[i].ToLower();
                }
                if (indexDel != -1)
                {
                    indexDel = text[i].IndexOf("<del>");
                    int z = (text[i].IndexOf("</del>", 0) + 6);
                    text[i] = text[i].Remove(indexDel, z);
                }
                if (indexRev != -1)
                {
                    text[i] = text[i].Remove(indexRev, 6);
                    indexRev = text[i].IndexOf("<rev>");
                    text[i] = text[i].Remove(indexRev, 5);
                    char[] a = text[i].ToCharArray().Reverse().ToArray();
                    text[i] = "";
                    for (int j = 0; j < a.Length; j++)
                    {
                        text[i] += a[j];
                    }

                }
            }
            for (int i = 0; i < n; i++)
            {

                Console.WriteLine(text[i]);
            }
        }
    }
}
