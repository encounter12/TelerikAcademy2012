using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam11._02
{
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            char[,] dancingCube = new char[,]{{'R','B','R'},{'B','G','B'},{'R','B','R'}};
            //int[,] position = new int[3,3]{{ 0, 0, 0 },{ 0, 1, 0 },{ 0, 0, 0 }};
            //int direction = 1; //forward 1 right 2 left 3 backwards 4
            //int n = 5;
            string[] dance = new string[n];
            //{
            //"WLWRW",
            //"WWL",
            //"LWRL",
            //"LLRR",
            //"WWWWWWWWWWWW",
            
            //};

            bool changed = false;

            for (int i = 0; i < n; i++)
            {
                dance[i] = Console.ReadLine();
            }

            for (int i = 0; i < n; i++)

            {
                int[,] position = new int[3, 3] { { 0, 0, 0 }, { 0, 1, 0 }, { 0, 0, 0 } };
                int direction = 1;
                foreach (char c in dance[i])
                {

                    if (c == 'W')
                    {
                        changed = false;
                        for (int m = 0; m < 3; m++)
                            for (int o = 0; o < 3; o++)
                            {
                                if (position[m, o] == 1)
                                {
                                    if (changed == false) position[m, o] = 0;
                                    if (direction == 1)
                                    {
                                        if (m != 0)
                                        {

                                            if (changed == false) position[m - 1, o] = 1; changed = true;
                                        }
                                        else
                                        {
                                            if (changed == false) position[2, o] = 1; changed = true;
                                        }
                                    }
                                    if (direction == 2)
                                    {
                                        if (o != 2)
                                        {
                                            if (changed == false) position[m, o + 1] = 1; changed = true;
                                        }
                                        else
                                        {
                                            if (changed == false) position[m, 0] = 1; changed = true;
                                        }
                                    }
                                    if (direction == 3)
                                    {
                                        if (o != 0)
                                        {
                                            if (changed == false) position[m, o - 1] = 1; changed = true;
                                        }
                                        else
                                        {
                                            if (changed == false) position[m, 2] = 1; changed = true;
                                        }
                                    }
                                    if (direction == 4)
                                    {
                                        if (m != 2)
                                        {
                                            if (changed == false) position[m + 1, o] = 1; changed = true;
                                        }
                                        else
                                        {
                                            if (changed == false) position[0, o] = 1; changed = true;
                                        }
                                    }

                                }
                            }
                    }

                    if (c == 'L')
                        {
                            if (direction == 1)
                                direction = 3;
                            else if  (direction == 2)
                                direction = 1;
                            else if  (direction == 3)
                                direction = 4;
                            else if  (direction == 4)
                                direction = 2;
                        }

                    if (c == 'R')
                        {
                            if (direction == 1)
                                direction = 2;
                            else if (direction == 2)
                                direction = 4;
                            else if (direction == 3)
                                direction = 1;
                            else if (direction == 4)
                                direction = 3;
                        }
                }

                for (int k = 0; k < 3; k++)
                    for (int l = 0; l < 3; l++)
                    {
                        if(position[k, l] == 1)
                        {
                            if(dancingCube[k, l] == 'R')
                                Console.WriteLine("RED");
                            if(dancingCube[k, l] == 'G')
                                Console.WriteLine("GREEN");
                            if(dancingCube[k, l] == 'B')
                                Console.WriteLine("BLUE");
                        }
                    }
            }

        }
    }
}
