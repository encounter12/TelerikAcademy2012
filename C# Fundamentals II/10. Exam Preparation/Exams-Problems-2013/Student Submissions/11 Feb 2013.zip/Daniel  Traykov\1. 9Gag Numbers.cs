using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            string gagNumbers = Console.ReadLine();

            StringBuilder gag = new StringBuilder();
            StringBuilder curGag = new StringBuilder();

            for (int i = 0; i < gagNumbers.Length; i++)
            {
                curGag.Append(gagNumbers[i]);

                switch (curGag.ToString())
                {
                    case "-!": gag.Append(0); curGag.Clear(); break;
                    case "**": gag.Append(1); curGag.Clear(); break;
                    case "!!!": gag.Append(2); curGag.Clear(); break;
                    case "&&": gag.Append(3); curGag.Clear(); break;
                    case "&-": gag.Append(4); curGag.Clear(); break;
                    case "!-": gag.Append(5); curGag.Clear(); break;
                    case "*!!!": gag.Append(6); curGag.Clear(); break;
                    case "&*!": gag.Append(7); curGag.Clear(); break;
                    case "!!**!-": gag.Append(8); curGag.Clear(); break;
                }
            }

            //Console.WriteLine(gag.ToString());

            string number = gag.ToString();
            List<int> array = new List<int>();
            ////Convert to decimal number
            for (int i = 0; i < number.Length; i++)
            {
               
                    array.Add(number[i] - '0');
                
            }

            array.Reverse();
            int decimalNumber = 0;
            for (int i = 0; i < array.Count; i++)
            {
                decimalNumber += array[i] * (int)Math.Pow(9, i);
            }

            array.Clear();
            if (decimalNumber == 0)
            {
                array.Add(0);
            }

            while (decimalNumber > 0)
            {
                array.Add(decimalNumber % 10);
                decimalNumber /= 10;
            }

            array.Reverse();
            char[] hex = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
          //  Console.Write("This {0} base number convertet in {1} base is ", 9, 10);
            foreach (var item in array)
            {
                Console.Write(hex[item]);
            }

            Console.WriteLine();
        }
    }
}
