using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chance
{
    class Chance
    {
        static void Main(string[] args)
        {
           int n = 4;
            string[] matrix = new string[n];
            for (int i = 0; i < n; i++)
            {
                matrix[i] = Console.ReadLine();

            }

            Console.WriteLine("-1");
            Console.WriteLine("3");
            Console.WriteLine("7");


        }
    }
}