using System;
using System.Collections.Generic;

    class SpecialValue
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int[][] matrix = new int[n][];

        }
    }