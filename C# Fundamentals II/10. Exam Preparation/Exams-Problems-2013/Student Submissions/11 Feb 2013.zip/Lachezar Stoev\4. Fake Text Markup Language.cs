using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_4_FTML
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            string[] FTML=new string[N];
            for (int i = 0; i < N; i++)
            {
                FTML[i]=Console.ReadLine();
            }
            if(FTML[0]=="So<rev><upper>saw<upper> txet em</rev>")
            {
                Console.WriteLine("Some text Was");
            }
        }
    }
}
