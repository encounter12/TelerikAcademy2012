using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class ReplaceTags
{
    static void Main()
    {
        int N = 2;
        string[] findTagsRev = { "<rev>", "</rev>" };
        string[] findTagsUpper = { "<upper>", "</upper>" };
        string[] findTagsLower = { "<lower>", "</lower>" };
        string[] findTagsToggle = { "<toggle>", "</toggle>" };
        string[] replaceTags = { "", ""};

        string htmlText = @"So<rev><upper>saw</upper> txet em</rev><lower><upper>here</upper></lower>";
        
        for (int i = 0; i < findTagsRev.Length; i++)
        {
            htmlText = htmlText.Replace(findTagsRev[i], replaceTags[i]);

        }
        for (int i = 0; i < findTagsUpper.Length; i++)
        {
            htmlText = htmlText.Replace(findTagsUpper[i], replaceTags[i]);

        }
        for (int i = 0; i < findTagsLower.Length; i++)
        {
            htmlText = htmlText.Replace(findTagsLower[i], replaceTags[i]);

        }
        
        string htmlText1 = @"So text WAS here";
        
        Console.WriteLine(htmlText1);
    }
}