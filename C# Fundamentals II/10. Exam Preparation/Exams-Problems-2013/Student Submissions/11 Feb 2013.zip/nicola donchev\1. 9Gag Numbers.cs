using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class Program
{
    static string[] num ={"-!","**","!!!",
                          "&&","&-","!-",
                          "*!!!","&*!","!!**!-"};
    static int[] end = new int[20];
    static int count=0;//all founds
    
    static void Main()
    { 
        
        string input = Console.ReadLine();
        
       // PrintResultString(input);
        RecognizeNumber(input);
        //PrintResultNumber(input);
        PrintResultNumber1(input);
    }

    public static void PrintResultString(string input)
    {
        Console.WriteLine(input);    
    }

    public static void PrintResultNumber(string input)
    {
        for (int i = 0; i < 20; i++)
        {
            Console.WriteLine(end[i]);
        }
        Console.WriteLine("count{0} ",count);
        
   
    }
    
    public static void PrintResultNumber1(string input)
    {
        BigInteger result=0;//first edit<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        BigInteger multi=1;//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        for (int i = count-1; i >=0; i--)
        {
            //Console.WriteLine(end[i]);
            
            result = result + (end[i] * multi);
            multi = multi * 9;
        }
        //Console.WriteLine("count {0} ", count);
        Console.WriteLine(result);

    }    
    public static void RecognizeNumber(string input)
    {
        int res = 0;
        int ind = 0;
        StringBuilder sb = new StringBuilder();
        for (int i =0; i < input.Length; i++)
        {
           
            sb.Append(input[i]);
            res=CheckNumber(sb);
            if (res >= 0)//match
            {
                 sb = new StringBuilder();
                 end[ind] = res;
                 ind++;
            }
        
        }
        
        
        //Console.WriteLine();//empty row
    }
    public static int CheckNumber(StringBuilder sb)
    {
        //Console.WriteLine(sb.ToString());
        
        for (int i = 0; i < 9; i++)
			{
                
                if (sb.ToString() == num[i])
                {

                    count++;
                    return i;
                
                }
			}
        
        
        
        
        return -1;
    }   
}


