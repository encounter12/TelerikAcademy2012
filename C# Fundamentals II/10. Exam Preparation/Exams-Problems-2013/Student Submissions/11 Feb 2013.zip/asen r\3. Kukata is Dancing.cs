
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
 
class KukataIsDancing
{
    static string GetNames(char letter)
    {
        string output = "";
        switch (letter)
        {
            case 'R': output = "RED"; break;
            case 'B': output = "BLUE"; break;
            case 'G': output = "GREEN"; break;
        }
        return output;
    }
    static void Main()
    {
         
        int rows = int.Parse(Console.ReadLine());
        string[] movements = new string[rows];
        for (int i = 0; i < rows; i++)
        {        //for (int i = 0; i < rows; i++)
        //{
        //    Console.WriteLine(movements[i]);
        //}
            movements[i] = Console.ReadLine();
        }
 
        char[,] matrix = {
                      {'R','B','R'},
                      {'B','G','B'},
                      {'R','B','R'}
                         };
        int x = 0,
            y = -1;
        int startx = 1,
            starty = 1;

        int temp =0;
 
        for (int i = 0; i < movements.Length; i++)
        {
            for (int j = 0; j < movements[i].Length; j++)
            {

                //if (movements[i][j] == 'W') { y--; if (y < 0) { y = 2; } }
                if (movements[i][j] == 'W') { startx += x; starty = +y;
                if (starty < 0) { starty = 2; }
                if (starty > 2) { starty = 0; }
                if (startx < 0) { startx = 2; }
                if (startx < 0) { startx = 0; }
                }

                if (movements[i][j] == 'L') { temp = x; x = y; y = temp; }
                if (movements[i][j] == 'R') { temp = x; x = y; y = temp; }

            }
            //Console.WriteLine(startx+" "+starty);
            Console.WriteLine(GetNames(matrix[startx, starty]));
            startx = 1;
            starty = 1;
        }
         
 
    }
}
