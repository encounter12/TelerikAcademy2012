using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
class FTML
{
    public static string UpperTag(string input)
    {
        if (input.IndexOf("<upper>") != -1)
        {
            int startIndex = input.IndexOf("<upper>");
            startIndex += 7;
            int lastIndex = input.IndexOf("</upper>", startIndex);
            string targetedText = input.Substring(startIndex, lastIndex - startIndex);
            return input.Replace(targetedText, targetedText.ToUpper());
        }
        else
        {
            return input;
        }
    }
 
    public static string LowerTag(string input)
    {
        if (input.IndexOf("<lower>") != -1)
        {
            int startIndex = input.IndexOf("<lower>");
            startIndex += 7;
            int lastIndex = input.IndexOf("</lower>", startIndex);
            string targetedText = input.Substring(startIndex, lastIndex - startIndex);
            return input.Replace(targetedText, targetedText.ToLower());
        }
        else
        {
            return input;
        }
    }
 
    public static string ToggleTag(string input)
    {
        if (input.IndexOf("<toggle>") != -1)
        {
            int startIndex = input.IndexOf("<toggle>");
            startIndex += 8;
            int lastIndex = input.IndexOf("</toggle>", startIndex);
            string targetedText = input.Substring(startIndex, lastIndex - startIndex);
            char[] substringByChar = targetedText.ToCharArray();
            StringBuilder toggledText = new StringBuilder();
 
            for (int i = 0; i < substringByChar.Length; i++)
            {
                if (char.IsLower(substringByChar[i]))
                {
                    toggledText.Append(substringByChar[i].ToString().ToUpper());
                }
                else if (char.IsUpper(substringByChar[i]))
                {
                    toggledText.Append(substringByChar[i].ToString().ToLower());
                }
                else
                {
                    toggledText.Append(substringByChar[i]);
                }
            }
            return input.Replace(targetedText, toggledText.ToString());
        }
        else
        {
            return input;
        }
    }
 
    public static string RevTag(string input)
    {
        if (input.IndexOf("<rev>") != -1)
        {
            int startIndex = input.IndexOf("<rev>");
            startIndex += 5;
            int lastIndex = input.IndexOf("</rev>", startIndex);
            string targetedText = input.Substring(startIndex, lastIndex - startIndex);
            char[] substringByChar = targetedText.ToCharArray();
            StringBuilder reversedText = new StringBuilder();
 
            for (int i = substringByChar.Length - 1; i >= 0; i--)
            {
                reversedText.Append(substringByChar[i]);
            }
            return input.Replace(targetedText, reversedText.ToString());
        }
        else
        {
            return input;
        }
    }
 
    public static string DelTag(string input)
    {
        if (input.IndexOf("<del>") != -1)
        {
            int startIndex = input.IndexOf("<del>");
            startIndex += 5;
            int lastIndex = input.IndexOf("</del>", startIndex);
            string targetedText = input.Substring(startIndex, lastIndex - startIndex);
            return input.Replace(targetedText, "");
        }
        else
        {
            return input;
        }
    }
 
    static void Main()
    {
        int nLines = int.Parse(Console.ReadLine());
 
        string[] inputByLine = new string[nLines];
 
        for (int i = 0; i < inputByLine.Length; i++)
        {
            inputByLine[i] = Console.ReadLine();
        }
 
        //Console.WriteLine(DelTag("So <del>TEST test</del> bla bla"));
 
        for (int i = 0; i < inputByLine.Length; i++)
        {
            inputByLine[i] = UpperTag(inputByLine[i]);
            inputByLine[i] = inputByLine[i].Replace("<upper>", "");
            inputByLine[i] = inputByLine[i].Replace("</upper>", "");
 
            inputByLine[i] = LowerTag(inputByLine[i]);
            inputByLine[i] = inputByLine[i].Replace("<lower>", "");
            inputByLine[i] = inputByLine[i].Replace("</lower>", "");
 
            inputByLine[i] = ToggleTag(inputByLine[i]);
            inputByLine[i] = inputByLine[i].Replace("<toggle>", "");
            inputByLine[i] = inputByLine[i].Replace("</toggle>", "");
 
            inputByLine[i] = RevTag(inputByLine[i]);
            inputByLine[i] = inputByLine[i].Replace("<rev>", "");
            inputByLine[i] = inputByLine[i].Replace("</rev>", "");
 
            inputByLine[i] = DelTag(inputByLine[i]);
            inputByLine[i] = inputByLine[i].Replace("<del>", "");
            inputByLine[i] = inputByLine[i].Replace("</del>", "");
        }
 
        foreach (var item in inputByLine)
        {
            Console.WriteLine(item);
        }
    }
}