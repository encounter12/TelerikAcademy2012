using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kukata
{
    class kukata
    {
        static void Main(string[] args)
        {
            
                
            int N = int.Parse(Console.ReadLine());
            string[] input = new string[N];
            for (int i = 0; i < N; i++)
			{
                string inp = Console.ReadLine();
                input[i] = inp;
			}

            string[,] str = new string[3, 3];
            str[0, 0] = "R";
            str[0, 1] = "B";
            str[0, 2] = "R";
            str[1, 0] = "B";
            str[1, 1] = "G";
            str[1, 2] = "B";
            str[2, 0] = "R";
            str[2, 1] = "B";
            str[2, 2] = "R";

            int w = 1;
            int h = 1;
            bool l = false;
            bool r = true;
            bool t = false;
            bool b = false;
            for (int i = 0; i < N; i++)
            {
                string line = input[i];
                for (int j = 0;j < line.Length; j++)
                {
                    if (line[j]=='L' && l)
                    {
                        l = false;
                        r = false;
                        t = false;
                        b = true;
                    }
                    if (line[j] == 'L' && r)
                    {
                        l = false;
                        r = false;
                        t = true;
                        b = false;
                    }
                    if (line[j] == 'L' && t)
                    {
                        l = true;
                        r = false;
                        t = false;
                        b = false;
                    }
                    if (line[j] == 'L' && b)
                    {
                        l = false;
                        r = true;
                        t = false;
                        b = false;
                    }
                    if (line[j] == 'R' && l)
                    {
                        l = false;
                        r = false;
                        t = true;
                        b = false;
                    }
                    if (line[j] == 'R' && r)
                    {
                        l = false;
                        r = false;
                        t = false;
                        b = true;
                    }
                    if (line[j] == 'R' && t)
                    {
                        l = false;
                        r = true;
                        t = false;
                        b = false;
                    }
                    if (line[j] == 'R' && b)
                    {
                        l = true;
                        r = false;
                        t = false;
                        b = false;
                    }
                    if (line[j] == 'W' && l)
                    {
                        w--;
                        if (w< 0)
                        {
                            w = N - 1;
                        }
                    }
                    if (line[j] == 'W' && r)
                    {
                        w++;
                        if (w > N-1)
                        {
                            w = 0;
                        }
                    }
                    if (line[j] == 'W' && t)
                    {
                        h--;
                        if (h < 0)
                        {
                            h = N - 1;
                        }
                    }
                    if (line[j] == 'W' && b)
                    {
                        h++;
                        if (h > N-1)
                        {
                            h = 0;
                        }
                    }
                    
                }
                if (str[w, h] == "R")
                {
                    Console.WriteLine("RED");
                }
                if (str[w, h] == "G")
                {
                    Console.WriteLine("GREEN");
                }
                if (str[w, h] == "B")
                {
                    Console.WriteLine("BLUE");
                }
            }
        }
    }
}
