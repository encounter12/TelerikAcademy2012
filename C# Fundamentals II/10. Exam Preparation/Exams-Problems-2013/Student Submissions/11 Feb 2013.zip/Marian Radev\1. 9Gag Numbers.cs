using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;


namespace Problem1
{
    class Program
    {
        static void Main()
        {
            string input = Console.ReadLine();

            char[] gagNumber = input.ToCharArray();
            string temp = "";
            string translated = "";

            for (int i = 0; i < gagNumber.Length; i++)
            {
                temp += gagNumber[i];

                if (temp == "-!")
                {
                    translated += 0;
                    temp = "";
                }
                else if (temp == "**")
                {
                    translated += 1;
                    temp = "";
                }
                else if (temp == "!!!")
                {
                    translated += 2;
                    temp = "";
                }
                else if (temp == "&&")
                {
                    translated += 3;
                    temp = "";
                }
                else if (temp == "&-")
                {
                    translated += 4;
                    temp = "";
                }
                else if (temp == "!-")
                {
                    translated += 5;
                    temp = "";
                }
                else if (temp == "*!!!")
                {
                    translated += 6;
                    temp = "";
                }
                else if (temp == "&*!")
                {
                    translated += 7;
                    temp = "";
                }
                else if (temp == "!!**!-")
                {
                    translated += 8;
                    temp = "";
                }
            }
            List<BigInteger> listOfInt = new List<BigInteger>();
            translated.ToList().ForEach(v => listOfInt.Add(int.Parse(v.ToString())));
            BigInteger[] numberArray = listOfInt.ToArray();




            Array.Reverse(numberArray);
            BigInteger result = 0;
            BigInteger muliplier = 9;

            for (int i = 1; i < numberArray.Length; i++)
            {
                numberArray[i] *= muliplier;
                muliplier *= 9;
            }

            foreach (var item in numberArray)
            {
                result += item;
            }

            Console.WriteLine(result);

        }
    }
}
