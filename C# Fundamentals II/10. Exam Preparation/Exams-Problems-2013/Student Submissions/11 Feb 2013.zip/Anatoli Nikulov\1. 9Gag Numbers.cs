using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace _01._9gagNumbers
{
    class Program
    {
        static string[] numbers = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
        static List<int> numbersToSum = new List<int>();

        static void Main()
        {
            string number = Console.ReadLine();
            symbolOfNumber(number);
            Console.WriteLine(sum());

        }
        static BigInteger sum()
        {
           // ulong sum = 0;
            BigInteger result = new BigInteger { };
            result = 0;
            int conterNumber = 0;
            for (int i = numbersToSum.Count - 1; i >= 0; i--)
            {
                result =result + (numbersToSum[conterNumber] * pow(i));
                conterNumber++;
            }
            //result = sum;
            return result;
        }

        static void symbolOfNumber(string number)
        {
            for (int j = 0; j < numbers.GetLength(0); j++)
            {
                if (numbers[j] == number)
                {
                    numbersToSum.Add(j);
                    return;
                }
            }
            int length = number.Length;
            for (int i = 1; i < length; i++)
            {
                string symbol = number.Substring(0, i);
                for (int j = 0; j < numbers.GetLength(0); j++)
                {
                    if (numbers[j] == symbol)
                    {
                        numbersToSum.Add(j);
                        number = number.Remove(0, i);
                        i = 0;
                        if (number == "")
                        {
                            return;
                        }
                    }
                }
            }
        }
        static BigInteger pow(int num)
        {
            BigInteger pow = new BigInteger { };
            pow = 9;
            if (num == 0)
            {
                return 1;
            }
            for (int i = 1; i < num; i++)
            {
                pow = pow * 9;
            }
            return pow;
        }
    }
}
