using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Telerik
{
    class GagStyle
    {
        static private string[] numbers = new string[] { "!-", "**", "!!!", "&&", "-&", "-!", "!!!*", "!*&", "-!**!!" };
        static void Main(string[] args)
        {
            var input = new string(Console.ReadLine().Reverse().ToArray());
            Console.WriteLine(Parse(input, 0, 1, 0));
        }
 
        static int Parse(string number9, int startIndex, int multyBy, int current)
        {
            var sb = new StringBuilder();
            for (int i = startIndex; i < number9.Length; i++)
            {
                sb.Append(number9[i]);
                var index = IndexOf(numbers, sb.ToString());
                if (index != -1)
                {
                    var innerResult = Parse(number9, i + 1, multyBy * 9, current);
                    if (innerResult != int.MinValue)
                    {
                        return multyBy * index + innerResult;
                    }
                }
            }
            if (sb.Length != 0) return int.MinValue;
            return current;
        }
 
        private static int IndexOf(string[] strings, string element)
        {
            for (int i = 0; i < strings.Length; i++)
            {
                if (strings[i] == element) return i;
            }
            return -1;
        }
    }
}