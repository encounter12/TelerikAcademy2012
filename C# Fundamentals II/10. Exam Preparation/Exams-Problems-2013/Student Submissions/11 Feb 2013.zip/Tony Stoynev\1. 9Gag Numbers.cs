using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9GagNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            if (input == "-!")
            {
                Console.WriteLine("{0}", 0);
            }
            else if (input == "**")
            {
                Console.WriteLine("{0}", 1);
            }
            else if (input == "!!!")
            {
                Console.WriteLine("{0}", 2);
            }
            else if (input == "&&")
            {
                Console.WriteLine("{0}", 3);
            }
            else if (input == "&-")
            {
                Console.WriteLine("{0}", 4);
            }
            else if (input == "*!-")
            {
                Console.WriteLine("{0}", 5);
            }
            else if (input == "*!!!")
            {
                Console.WriteLine("{0}", 6);
            }
            else if (input == "&*!")
            {
                Console.WriteLine("{0}", 7);
            }
            else if (input == "!!**!-")
            {
                Console.WriteLine("{0}", 8);
            }
        }
    }
}
