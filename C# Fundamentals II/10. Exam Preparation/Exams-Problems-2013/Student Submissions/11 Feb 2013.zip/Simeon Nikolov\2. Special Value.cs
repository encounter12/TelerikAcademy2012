using System;
using System.Collections.Generic;

class SpecialValue
{
    static int rows;
    static int[] paths;
    static long[] specialValues;
    static int[][] jaggedMatrix;
    static int[][] visitedJaggedMatrix;

    static void Main()
    {
        InputData();
        InitSpecialValues();
        WalkPaths();
        Console.WriteLine(FindMax());
    }

    private static long FindMax()
    {
        long max = int.MinValue;
        for (int i = 0; i < specialValues.Length; i++)
        {
            if (specialValues[i] > max)
            {
                max = specialValues[i];
            }
        }
        return max;
    }

    private static void WalkPaths()
    {
        for (int path = 0; path < paths.Length; path++)
        {
            InitVisited();
            paths[path] = jaggedMatrix[0][path];
            for (int row = 0; row < rows; row++)
            {
                if (paths[path] < 0)
                {
                    specialValues[path] += ((-1) * paths[path]);
                    break;
                }

                specialValues[path]++;
                int nextRow = row + 1;
                if (nextRow >= rows)
                {
                    nextRow = 0;
                    row = -1;
                }

                try
                {
                    if (paths[path] >= 0 && paths[path] < jaggedMatrix[nextRow].GetLength(0))
                    {
                        if (!(visitedJaggedMatrix[nextRow][paths[path]] == 1))
                        {
                            paths[path] = jaggedMatrix[nextRow][paths[path]];
                            if (paths[path] < 0)
                            {
                                specialValues[path] += ((-1) * paths[path]);
                                break;
                            }
                            visitedJaggedMatrix[nextRow][paths[path]] = 1;
                        }
                        else
                        {
                            specialValues[path] = -1;
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
                catch (Exception)
                {
                    break;
                }
            }
        }
    }

    private static void InitVisited()
    {
        for (int row = 0; row < visitedJaggedMatrix.GetLength(0); row++)
        {
            for (int col = 0; col < visitedJaggedMatrix[row].GetLength(0); col++)
            {
                visitedJaggedMatrix[row][col] = 0;
            }
        }
    }

    private static void InitSpecialValues()
    {
        for (int i = 0; i < specialValues.Length; i++)
        {
            specialValues[i] = 1;
        }
    }

    private static void InputData()
    {
        rows = int.Parse(Console.ReadLine());
        jaggedMatrix = new int[rows][];
        visitedJaggedMatrix = new int[rows][];

        for (int i = 0; i < rows; i++)
        {
            string line = Console.ReadLine();
            string[] numbers = line.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            jaggedMatrix[i] = new int[numbers.Length];
            visitedJaggedMatrix[i] = new int[numbers.Length];

            for (int j = 0; j < numbers.Length; j++)
            {
                jaggedMatrix[i][j] = int.Parse(numbers[j]);
            }
        }

        paths = new int[jaggedMatrix[0].GetLength(0)];
        specialValues = new long[jaggedMatrix[0].GetLength(0)];
    }
}
