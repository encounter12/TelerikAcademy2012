using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9GagNumbers_Problem1
{
    class Program
    {
        static void Main()
        {
            string gag_number = Console.ReadLine();
            int i = 0;
         
            string two = "";
            string three = "";
            string four = "";
            string six = "";
            List<string> list = new List<string>();
            int length = gag_number.Length;
            while(i < length)
            {
                if (i + 2 <= length)
                {
                    two = gag_number.Substring(i, 2);
                }
                if (i + 3 <= length)
                {
                    three = gag_number.Substring(i, 3);
                }
                if (i + 4 <= length)
                {
                    four = gag_number.Substring(i, 4);
                }
                if (i + 6 <= length)
                {
                    six = gag_number.Substring(i, 6);
                }
              
                if(two == "-!" || two == "**" || two == "&&" || two == "&-" || two == "!-")
                {
                    i += 2;
                    list.Add(two);
                    two = "";
                }
                else if(three == "!!!" || three == "&*!")
                {
                    i += 3;
                    list.Add(three);
                    three = "";
                }
                else if (four == "*!!!")
                {
                    i += 4;
                    list.Add(four);
                    four = "";
                }
                else if (six == "!!**!-")
                {
                    i += 6;
                    list.Add(six);
                    six = "";
                }
            }
       
            int sum = 0;
            for(int j = 0, l = list.Count-1; l >= 0; j++, l--)
            {
               if(list[l] == "**")
               {
                   sum += 1 * Power(9, j);
               }
               else if (list[l] == "!!!")
               {
                   sum += 2 * Power(9, j);
               }
               else if (list[l] == "&&")
               {
                   sum += 3 * Power(9, j);
               }
               else if (list[l] == "&-")
               {
                   sum += 4 * Power(9, j);
               }
               else if (list[l] == "!-")
               {
                   sum += 5 * Power(9, j);
               }
               else if (list[l] == "*!!!")
               {
                   sum += 6 * Power(9, j);
               }
               else if (list[l] == "&*!")
               {
                   sum += 7 * Power(9, j);
               }
               else if (list[l] == "!!**!-")
               {
                   sum += 8 * Power(9, j);
               }
            }
            Console.WriteLine(sum);
        }
        static int Power(int a, int b)
        {
            if (b < 0)
            {
                throw new ApplicationException("B must be a positive integer or zero");
            }
            if (b == 0) return 1;
            if (a == 0) return 0;
            if (b % 2 == 0)
            {
                return Power(a * a, b / 2);
            }
            else if (b % 2 == 1)
            {
                return a * Power(a * a, b / 2);
            }
            return 0;
        } 
    }
}
