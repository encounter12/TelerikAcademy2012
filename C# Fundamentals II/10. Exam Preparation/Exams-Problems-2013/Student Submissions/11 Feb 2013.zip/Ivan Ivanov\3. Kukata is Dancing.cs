using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kukata
{
    class Kukata
    {
        //LLRR
        //WWWWWWWWWWW
        //WLWRW
        //WWL
        //LWRL
        static void Main(string[] args)
        {

            int dances = int.Parse(Console.ReadLine());
            bool hasNoW = true;
            bool hasOnlyW = true;
            string[] moves  = new string[dances];
            int count = 0;

            for (int i = 0; i < dances; i++)
            {
                moves[i] = Console.ReadLine();
                                
            }
            
            for (int i = 0; i < moves.Length; i++)
            {
                string[] steps = moves[i].Split();
                for (int j = 0; j < steps.Length; j++)
                {

                    if (moves[j] == "W")
                    {
                        hasNoW = false;
                    }


                    if (moves[j] == "R" || moves[i] == "L")
                    {
                        count++;
                        hasOnlyW = false;
                    }
                   

                    
                }

                

            }

            if (hasNoW)
            {
                Console.WriteLine("GREEN");
            }
            if (hasOnlyW)
            {
                if (count % 3 != 0)
                {
                    Console.WriteLine("BLUE");
                }
                else
                {

                    Console.WriteLine("GREEN");
                }
            }
        }
    }
}
