using System;

    class Program
    {
        static void Main()
        {
            string[,] cube=new string[3,3];
            cube[0, 0] = "RED";
            cube[0, 1] = "BLUE";
            cube[0, 2] = "RED";
            cube[1, 0] = "BLUE";
            cube[1, 1] = "GREEN";
            cube[1, 2] = "BLUE";
            cube[2, 0] = "RED";
            cube[2, 1] = "BLUE";
            cube[2, 2] = "RED";

            int max;
            string L="L";
            string R="R";
            string W="W";
            int rtest=0;
            int ctest=0;
            int w=0;
            int redway = 0;
            int Nrow=0;
            int Ncol=1;
            int row = 1;
            int col = 1;
            int N = int.Parse(Console.ReadLine());
            string[] Lines = new string[N];
            for (int i = 0; i < N; i++)
            {
                Lines[i] = Console.ReadLine();
            }
            for (int counter = 0; counter < Lines.Length; counter++)
            {
                for (int counterin = 0; counterin < Lines[counter].Length; counterin++)
                {
                    if (Lines[counter][counterin] == L[0])
                    {

                        Nrow++;
                        Ncol--;
                        if (((redway == 2) && (redway % 4 == 2)) || ((redway % -4 == 1) && (redway == -2)))
                        redway -= 1;
                    }
                    if (Lines[counter][counterin] == R[0])
                    {
                        if (((redway == 2) && (redway % 4 == 2)) || ((redway % -4 == 1) && (redway == -2)))
                        Nrow++;
                        Ncol++;
                        redway += 1;
                    }
                    if (Lines[counter][counterin] == W[0])
                    {
                        if ((((redway == 0) && (redway % 4 == 0))) || ((redway % -4 == 1)) && (redway == -0))
                            Ncol++;
                        else if (((redway == 1) && (redway % 4 == 1)) || ((redway % -4 == 1) && (redway == -1)))
                            Nrow++;
                        if (((redway == 2) && (redway % 4 == 2)) || ((redway % -4 == 1) && (redway == -2)))
                            Ncol--;
                        else if (((redway == 3) && (redway % 4 == 3)) || ((redway % -4 == 1) && (redway == -3)))
                            Nrow--;
                        if (Math.Max(Ncol, Nrow) > Math.Min(Ncol, Nrow)+1)
                        {
                            max=Math.Max(Ncol, Nrow);
                            if (max == Ncol)
                                Ncol--;
                            if (max == Nrow)
                                Nrow--;
                        }
                        col = Ncol;
                        row = Nrow;
                    }
                    if (row >= 3)
                        row = 0;
                    if (row < 0)
                        row = 2;
                    if (col >= 3)
                        col = 0;
                    if (col < 0)
                        col = 2;

                    if (Nrow >=3)
                    {
                        Nrow = 0;
                    }
                    if (Nrow > 2)
                    {
                        rtest = 0;
                    }
                    if (Nrow < 0)
                        Nrow=2;
                    if (rtest > 0)
                        Nrow++;

                    if (rtest < 0)
                        Nrow--;
                    if (Ncol >= 3)
                    {
                        Ncol = 0;
                    }
                    if (Ncol > 0)
                    {
                        ctest = 0;
                    }
                    if (Ncol < 0)
                        Ncol=2;


                    
                }
                Console.WriteLine(cube[row, col]);
                
            }
        }
    }
