using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Number9Gags
    {
  
    static string[] digitsBaseS = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
    //static ring[] digitsBaseS = { "0",  "1",  "2",   "3",  "4",  "5",  "6",    "7",   "8",  };

    static void Main()
    {
        string[] digitsBaseS2 = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
        int[] decDigit = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };
        //static ring[] digitsBaseS = { 0",  "1",  "2",   "3",  "4",  "5",  "6",    "7",   "8",  };
        
        //Array.Sort(digitsBaseS2, (x, y) =>
        //{
        //    if (x.Length <= y.Length)
        //    {
        //        return 1;
        //    }
        //    else
        //    {
        //        return -1;
        //    }
        //});

        for (int i = 0; i < digitsBaseS2.Length; i++)
        {
            for (int k = 0; k < digitsBaseS.Length; k++)
            {
                if (digitsBaseS[k] == digitsBaseS2[i])
                {
                    decDigit[i] = k;
                    break;
                }
            }
        }
        string inputData = Console.ReadLine();
        int baseS = 9;
        //inputData = "***!!!";
        //inputData = "!!!**!-";
        //inputData = "*!!!";
        int currentPosition = 0;
        int powS = 1;
        int resultTemp = 0;
        string resultString = "";
        while (currentPosition < inputData.Length)
        {
            for(int i = 0; i < digitsBaseS2.Length; i++)
            {

                if (inputData.Substring(currentPosition).StartsWith(digitsBaseS2[i]))
                {
                    resultString = resultString + decDigit[i];
                    currentPosition = currentPosition + digitsBaseS2[i].Length;
                    break;
                }
               
            }  
        
        }
        
         resultTemp = 0;
         for (int i = resultString.Length - 1; i >= 0; i--)
            {
                int digit = resultString[i] - '0';
                resultTemp = resultTemp + digit * powS;
                powS = powS * baseS;
           }

        Console.WriteLine(resultTemp);
        return;
     
    }


    }
