using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
      // int n = int.Parse(Console.ReadLine());
      // int[] arr = new int[n];
      // for (int i = 0; i < n; i++)
      // {
      //     arr[i] = int.Parse(Console.ReadLine());
      // }
      // for (int i = 0; i < n; i++)
      // {
      //     Console.WriteLine(" " + arr[i]);
      // }


        int NumPlayer;
        
        
           NumPlayer = int.Parse(Console.ReadLine());
         
        int[] points = new int[NumPlayer];
        for (int i = 0; i < NumPlayer; i++)
        {
            
                points[i] = int.Parse(Console.ReadLine());  
             

        }
        for (int i = 0; i < NumPlayer; i++)
        {
            Console.WriteLine("The points of player{0} are {1} ", i+1, points[i]);
        }
        for (int i = 0; i < NumPlayer; i++)
        {
            while (points[i]<21)
            {
                Array.Sort(points);
                int a=points.Max();
                Console.WriteLine("The winner is player {0}", a); break;
            }
            
        }
        



    }

}
