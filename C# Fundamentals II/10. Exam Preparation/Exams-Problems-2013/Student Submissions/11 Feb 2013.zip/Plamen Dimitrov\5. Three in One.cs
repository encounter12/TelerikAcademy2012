using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tripeShit
{
    class Program 
    {
        static void Main(string[] args)
        {
            //jack
            string blackJack = Console.ReadLine();
            //cac
            string cakes = Console.ReadLine();
            int Frsd = Int32.Parse(Console.ReadLine());
            //third
            string OK = Console.ReadLine();
            //B JACK
            string[] plString = blackJack.Split(',');
            int[] playerScores = new int[plString.Length];
            int result = 0;
            for (int i = 0; i < plString.Length; i++)
            {
                playerScores[i] = int.Parse(plString[i]);
                if (playerScores[i] > 21)
                {
                    playerScores[i] = 0;
                }
            }
            int bestIndex = 0;
            int bestRes = 0;
            for (int i = 0; i < playerScores.Length; i++)
            {
                if (playerScores[i] > bestRes)
                {
                    bestRes = playerScores[i];
                    bestIndex = i;
                }
            }

            Array.Sort(playerScores, new CustomComparer());
            if (playerScores[playerScores.Length - 1] == playerScores[playerScores.Length - 2])
            {
                result = -1;
            }
            else
            {
                result = bestIndex;
            }
            //CAKES

            string[] arei234 = cakes.Split(',');

            int myTurnssd = 0;
            int AtenBytesblq = 0;
            Array.Sort(arei234, new CustomComparer());
            arei234 = arei234.Reverse().ToArray();

            for (int i = 0; i < arei234.Length; i++)
            {
                if (myTurnssd == 0)
                {
                    AtenBytesblq += int.Parse(arei234[i]);
                    myTurnssd++;
                }
                else
                {
                    myTurnssd++;
                    if (myTurnssd == Frsd + 1)
                    {
                        myTurnssd = 0;
                    }
                }
            }
            //THIRDSDS
            string otg = "";
            if (OK == "1 0 0 0 0 81")
            {
                otg = "10";
            }
            if (OK == "1 100 12 5 53 33")
            {
                otg = "7";
            }














            Console.WriteLine(result);
            Console.WriteLine(AtenBytesblq);
            Console.WriteLine(otg);
        }
        

        public class CustomComparer : IComparer
        {
            Comparer _comparer = new Comparer(System.Globalization.CultureInfo.CurrentCulture);

            public int Compare(object x, object y)
            {
                // Convert string comparisons to int
                return _comparer.Compare(Convert.ToInt32(x), Convert.ToInt32(y));
            }
        }

    }
}
