using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3
{
    struct Kuka
    {
        public int direction;
        public int x;
        public int y;
    }

    class Program
    {
        static void Main(string[] args)
        {
            string[,] arr = new string[3, 3]
            {
                {"RED","BLUE","RED"},
                {"BLUE","GREEN","BLUE"},
                {"RED","BLUE","RED"}
            };

            int dances = int.Parse(Console.ReadLine());
            string[,] moves = new string[dances, 1];

            Kuka kukata = new Kuka();
            kukata.direction = 1;
            kukata.x = 1;
            kukata.y = 1;

            for (int i = 0; i < dances; i++)
            {
                moves[i, 0] = Console.ReadLine();
            }

            for (int j = 0; j < dances; j++)
            {
                for (int k = 0; k < moves[j, 0].Length; k++)
                {
                    if (moves[j,0][k]=='W' && kukata.direction == 1)
                    {
                        kukata.y -= 1;
                        if (kukata.y < 0)
                        {
                            kukata.y = 2;
                            kukata.direction = 3;
                        }
                    }
                    else if (moves[j,0][k]=='W' && kukata.direction == 3)
                    {
                        kukata.y += 1;
                        if (kukata.y > 2)
                        {
                            kukata.y = 0;
                            kukata.direction = 3;
                        }
                    }
                    else if (moves[j, 0][k] == 'W' && kukata.direction == 2)
                    {
                        kukata.x -= 1;
                        if (kukata.x < 0)
                        {
                            kukata.x = 2;
                            kukata.direction = 4;
                        }
                    }
                    else if (moves[j, 0][k] == 'W' && kukata.direction == 4)
                    {
                        kukata.x += 1;
                        if (kukata.x > 2)
                        {
                            kukata.x = 0;
                            kukata.direction = 4;
                        }
                    }
                    else if (moves[j, 0][k] == 'L')
                    {
                        if (kukata.direction == 4)
                        {
                            kukata.direction = 1;
                        }
                        kukata.direction += 1;
                    }
                    else if (moves[j, 0][k] == 'R')
                    {
                        if (kukata.direction == 1)
                        {
                            kukata.direction = 4;
                        }
                        kukata.direction--;
                    }
                }
                Console.WriteLine(arr[kukata.y, kukata.x]);
            }
        }
    }
}
