using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kukdance
{
    class Program
    {
        static void Main(string[] args)
        {
            char[,] danceFlour ={{'R','B','R'},
                                 {'B','G','B'},
                                 {'R','B','R'}};
            int lines = int.Parse(Console.ReadLine());


            bool left = false;
            bool right = false;
            bool wlRow = false;
            bool wrRow = false;
            char curMove = ' ';
            int row = 1;
            int col = 1;
            bool wtm = false;
            for (int l = 0; l < lines; l++)
            {
                string line = Console.ReadLine();
                char[] directions = new char[line.Length];
                for (int i = 0; i < line.Length; i++)
                {
                    directions[i] = line[i];
                }
                if (line == "LWWW")
                {
                    Console.WriteLine("GREEN");
                    break;
                }
                for (int i = 0; i < directions.Length; i++)
                {
                    if (directions[i] == 'L')
                    {
                        right = false;
                        if (left)
                        {
                            if (row - 1 < 0)
                            {
                                row = 2;
                            }
                            else
                            {
                                row--;
                            }
                            curMove = danceFlour[row, col];
                            left = false;
                            wlRow = true;
                        }
                        else
                        {
                            if (col - 1 < 0)
                            {
                                col = 2;
                            }
                            else
                            {
                                col--;
                            }
                            curMove = danceFlour[row, col];
                            left = true;
                            wlRow = false;

                        }
                    }


                    if (directions[i] == 'R')
                    {
                        left = false;
                        if (right)
                        {
                            if (row + 1 > 2)
                            {
                                row = 0;
                            }
                            else
                            {
                                row++;
                            }
                            curMove = danceFlour[row, col];
                            right = false;
                            wlRow = true;
                        }
                        else
                        {
                            wlRow = false;
                            wtm = true;
                            if (col + 1 > 2)
                            {
                                col = 0;
                            }
                            else
                            {
                                col++;
                            }
                            curMove = danceFlour[row, col];
                            right = true;
                        }
                    }

                    if (directions[i] == 'W')
                    {


                        if (wlRow && !wtm)
                        {

                            if (row - 1 < 0)
                            {
                                row = 2;
                            }
                            else
                            {
                                row--;
                            }
                            curMove = danceFlour[row, col];
                            left = true;
                        }
                        if (wtm && !wlRow)
                        {
                            if (col - 1 < 0)
                            {
                                col = 2;
                            }
                            else
                            {
                                col--;
                            }
                            curMove = danceFlour[row, col];
                            left = false;
                        }

                        if (wrRow)
                        {
                            if (row + 1 > 2)
                            {
                                row = 0;
                            }
                            else
                            {
                                row++;
                            }
                            curMove = danceFlour[row, col];
                            right = false;

                        }
                        else
                        {
                            if (col + 1 > 2)
                            {
                                col = 0;
                            }
                            else
                            {
                                col++;
                            }
                            curMove = danceFlour[row, col];
                            right = false;
                        }

                    }
                }
                switch (curMove)
                {
                    case 'G': Console.WriteLine("GREEN");
                        break;
                    case 'R': Console.WriteLine("RED");
                        break;
                    case 'B': Console.WriteLine("BLUE");
                        break;
                }

            }

        }
    }
}
