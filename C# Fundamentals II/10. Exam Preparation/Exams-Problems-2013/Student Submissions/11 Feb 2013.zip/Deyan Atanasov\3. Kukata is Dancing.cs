using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        byte N = byte.Parse(Console.ReadLine());
        string[] moves = new string[N];
        sbyte dir = 0;
        sbyte x = 1;
        sbyte y = 1;

        string[,] floor = { { "RED", "BLUE", "RED" }, { "BLUE", "GREEN", "BLUE" }, { "RED", "BLUE", "RED" } };

        for (int i = 0; i < N; i++)
        {
            moves[i] = Console.ReadLine().ToUpper();
        }

        for (int i = 0; i < N; i++)
        {
            x = 1;
            y = 1;
            dir = 0;
            foreach (char move in moves[i])
            {
                switch (move)
                {
                    case 'L': dir--;
                        break;
                    case 'R': dir++;
                        break;
                    case 'W':
                        switch (Math.Abs(dir) % 4)
                        {
                            case 0:
                                y--;
                                if (y < 0) y = 2;
                                break;
                            case 1:
                                x--;
                                if (x < 0) x = 2;
                                break;
                            case 2:
                                y++;
                                if (y > 2) y = 0;
                                break;
                            case 3:
                                x++;
                                if (x > 2) x = 2;
                                break;
                        }
                        break;
                    default:
                        break;
                }
            }
            Console.WriteLine(floor[x, y]);
        }
    }
}
