using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class NineGag
{
    public static int FindLeftDigitSequence(string input)
    {                        // 0    1       2    3     4     5       6     7       8   
        string[] allDigits = {"-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };

        int resultToReturn = -1;

        for (int i = 0; i < allDigits.Length; i++)
        {
            //Console.WriteLine(input.IndexOf(allDigits[i]));
            if (input.IndexOf(allDigits[i]) == 0)
            {
                resultToReturn = i;
                break;
            }

        }
        return resultToReturn;
    }

    public static string TrimLeftDigitSequence(int digitToTrim, string strToTrim)
    {                        // 0    1       2    3     4     5       6     7       8   
        string[] allDigits = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };

        return strToTrim.Remove(0, allDigits[digitToTrim].Length);
    }

    static void Main()
    {
        string mainInput = Console.ReadLine();

        int toTrim = FindLeftDigitSequence(mainInput);
        string trimmed = TrimLeftDigitSequence(toTrim, mainInput);

        List<int> outputBySingleDigit = new List<int>();
        outputBySingleDigit.Add(toTrim);

        while (trimmed != "")
        {
            toTrim = FindLeftDigitSequence(trimmed);
            trimmed = TrimLeftDigitSequence(toTrim, trimmed);
            outputBySingleDigit.Add(toTrim);
        }

        outputBySingleDigit.Reverse();

        BigInteger total = 0;

        for (int i = 0; i < outputBySingleDigit.Count; i++)
        {
            total += outputBySingleDigit[i] * (long)Math.Pow(9, i);
        }
        Console.WriteLine(total);

    }
}
