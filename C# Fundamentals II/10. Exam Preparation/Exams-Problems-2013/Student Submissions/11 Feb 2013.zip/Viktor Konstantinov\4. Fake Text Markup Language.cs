using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs2
{
    class Program //note: endl may be two symbols. when rev'ing it, don't swap them.
    {
        static String fmt(String s, int start, ref int end, int depth)
        {
            //""WriteLine("--- BEGIN");
            //""WriteLine(depth);
            //""WriteLine(s.Substring(start));
            if (s.Length - start < 2)
            {
                end = s.Length;
                //""WriteLine("--- SMALL");
                return s.Substring(start, end - start);
            }
            if (s[start] != '<')
            {
                end = s.IndexOf('<', start);
                if (end < 0) end = s.Length;
                //""WriteLine("--- BEFORE TAG");
                return s.Substring(start, end - start);
            }
            if (s[start + 1] == '/')
            {
                end = s.IndexOf('>', start) + 1;
                //""WriteLine("--- CLOSING");
                return "";
            }
            int i = s.IndexOf('>', start) + 1;
            String tag = s.Substring(start, i - start);
            //""WriteLine("TAG");
            //""WriteLine(tag);
            //""WriteLine(i);
            String content = "";
            while (true)
            {
                /*""WriteLine("--- BEGIN ITER");
                ""WriteLine(depth);
                ""WriteLine("--- I");
                ""WriteLine(i);*/
                String newcontent = fmt(s, i, ref i, depth + 1);
                /*""WriteLine("--- CHUNK");
                ""WriteLine(depth);
                ""WriteLine(newcontent);*/
                content += newcontent;
                /*""WriteLine("--- END ITER");
                ""WriteLine(depth);
                ""WriteLine("--- I");
                ""WriteLine(i);*/
                if (newcontent == "") break;
            }
            // do stuff to content
            if (tag == "<upper>")
                content = content.ToUpper();
            else if (tag == "<lower>")
                content = content.ToLower();
            else if (tag == "<toggle>")
            {
                String newcont = "";
                for (int z = 0; z < content.Length; z++)
                {
                    char c = content[z];
                    if ((int)c > 95)
                        newcont += (char)(content[z] - (char)32);
                    else newcont += (char)(content[z] + (char)32);
                }
                content = newcont;
            }
            else if (tag == "<rev>")
            {
                char[] charArray = content.ToCharArray();
                Array.Reverse(charArray);
                content = new string(charArray);
            }


            end = i;// s.IndexOf('>', i);
            return content;
        }

        static void Main(string[] args)
        {
            int n;
            int.TryParse(Console.ReadLine(), out n);
            for (int i = 0; i < n; i++)
            {
                String s = Console.ReadLine();
                String content = "";
                int start = 0;
                while (true)
                {
                    String newcontent = "";
                    newcontent = fmt(s, start, ref start, 0);
                    //""WriteLine("MAIN CHUNK");
                    //""WriteLine(newcontent);
                    content += newcontent;
                    if (newcontent == "") break;
                }
                Console.WriteLine(content);
            }
        }
    }
}
