using System;
using System.Collections.Generic;
using System.Text;

class ProblemOne
{
    static void Main()
    {
        string gagNum = Console.ReadLine();
        string[] dict = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
        StringBuilder number = new StringBuilder();
        int sum = 0;
        List<int> seq = new List<int>();

        foreach (char symbol in gagNum)
        {
            number.Append(symbol);
            for (int counter = 0; counter < dict.Length; counter++)
            {
                if (number.ToString().Equals(dict[counter]))
                {
                    seq.Add(counter);
                    number.Clear();
                    break;
                }
            }
        }

        int numLenght = seq.Count;

        foreach (int num in seq)
        {
            sum += num * getCoef(numLenght);
            numLenght--;
        }

        Console.WriteLine(sum);
    }

    static int getCoef(int times)
    {
        int coef = 1;
        for (int counter = 1; counter < times; counter++)
        {
            coef *= 9;
        }

        return coef;
    }
}
