using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Program
    {
        static void Main()
        {
            string n = Console.ReadLine();
            char[] arr = n.ToCharArray();

            //string[] gagStyleNumbers = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
        }

        static int Base9ToBase10(char[] arr)
    {
        int d = 0;

        for (int i = arr.Length - 1, p = 1; i >= 0; i--, p *= 9)
        {
            d += GetNumber(char[] arr,i) * p;
        }

        return d;
        
    }
        static int GetNumber(char[] arr, int i)
    {
        if ((arr[i] == '-')&&(arr[i+1] == '!')) return 0;
        if ((arr[i] == '*')&&(arr[i+1] =='*')) return 1;
        if ((arr[i] == '!')&&(arr[i+1] =='!')&&(arr[i+2]=='!')) return 2;
        if ((arr[i] == '&')&&(arr[i+1] =='&')) return 3;
        if ((arr[i] == '&')&&(arr[i+1] == '-')) return 4;
        if ((arr[i] == '!')&&(arr[i+1] =='-')) return 5;
        if ((arr[i] == '*')&&(arr[i+1] == '!')&&(arr[i+2]=='!')&&(arr[i+3]=='!')) return 6;
        if ((arr[i] == '&')&&(arr[i+1] == '*')&&(arr[i+2]=='!')) return 7;
        if ((arr[i] == '!')&&(arr[i+1] == '!')&&(arr[i+2]=='*')&&(arr[i+3]=='*')&&(arr[i+4]=='-')) return 8;
    }
}