using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

class FTML
{
    static void Main()
    {
        StringBuilder input = new StringBuilder();

        int rows = int.Parse(Console.ReadLine());
        for (int i = 0; i < rows; i++)
        {
            input.AppendLine(Console.ReadLine());
        }

        // Parse <del> tags
        //string ftml = Regex.Replace(input.ToString(), @"<del>(.|\s)*</del>", "");
        string ftml = input.ToString();

        // Parse tags
        int index = 0;

        while ((index = ftml.IndexOf("</")) > 0)
        {
            string tag = ftml.Substring(index+2, ftml.IndexOf(">", index) - index - 2);
            
            int textStart = ftml.LastIndexOf(">", index) + 1;
            string text = ftml.Substring(textStart, index - textStart);

            string pattern = String.Format("<{0}>{1}</{0}>", tag, text);
            ftml = ftml.Replace(pattern, FormatText(tag, text));

            //Console.WriteLine(ftml);
            //Environment.Exit(Environment.ExitCode);
        }

        // Print 
        StringReader reader = new StringReader(ftml);
        for (string line; (line = reader.ReadLine()) != null; )
        {
            Console.WriteLine(line);
        }
        
    }

    //
    static string FormatText(string tag, string text)
    {
        switch (tag.ToLower())
        {
            case "upper":
                return text.ToUpper();
                break;
            case "lower":
                return text.ToLower();
                break;
            case "toggle":
                return ToggleCase(text);
                break;
            case "rev":
                char[] arr = text.ToArray();
                Array.Reverse(arr);
                StringBuilder newtext = new StringBuilder(arr.Length);
                foreach (var item in arr)
                {
                    if (item == '\r')
                        continue;
                    newtext.Append(item);
                }
                return newtext.ToString();
                break;
            case "del":
                return String.Empty;
                break;
        }

        return text;
    }

    //
    static string ToggleCase(string input)
    {
        StringBuilder result = new StringBuilder(input.Length);
        char[] inputArray = input.ToCharArray();

        foreach (char c in inputArray)
        {
            if (char.IsLower(c))
                result.Append(c.ToString().ToUpper());
            else if (char.IsUpper(c))
                result.Append(c.ToString().ToLower());
            else
                result.Append(c);
        }

        return result.ToString();
    }
}
