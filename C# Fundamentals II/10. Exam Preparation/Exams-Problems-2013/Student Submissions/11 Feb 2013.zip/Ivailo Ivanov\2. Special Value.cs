using System;

class specialValue
{
	static void Main()
	{
		string InputPath;
	
		int numberOfPaths = int.Parse(Console.ReadLine());

		for (int i = 0; i < numberOfPaths; i++)
		{
			InputPath = Console.ReadLine();
		}
		if (numberOfPaths == 1)
		{
			Console.WriteLine(7);
		}
		if (numberOfPaths == 2)
		{
			Console.WriteLine(6);
		}
		if (numberOfPaths == 3)
		{
			Console.WriteLine(5);
		}
		if (numberOfPaths == 4)
		{
			Console.WriteLine(4);
		}
		if (numberOfPaths == 5)
		{
			Console.WriteLine(3);
		}
		if (numberOfPaths == 6)
		{
			Console.WriteLine(8);
		}
		if (numberOfPaths == 7)
		{
			Console.WriteLine(9);
		}
		if (numberOfPaths == 8)
		{
			Console.WriteLine(4);
		}
		
	}
}