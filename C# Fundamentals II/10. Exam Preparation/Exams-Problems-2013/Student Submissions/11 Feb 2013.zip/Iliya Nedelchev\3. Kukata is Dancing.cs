using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kuka
{
    class Program
    {
        static void Main(string[] args)
        {
            string [,] arr={{"RED","BLUE","RED"},{"BLUE","GREEN","BLUE"},{"RED","BLUE","RED"}};
            int n=int.Parse(Console.ReadLine());
            string[] moves = new string[n];
            for(int i=0;i<n;i++)
                moves[i]=Console.ReadLine();
            
            for(int i=0;i<n;i++)
            {
                int indexCol = 1;
                int indexRow = 1;
                bool right = false;
                bool left = false;
                bool turnBack = false;
                int count=0;
                while(count<moves[i].Length)
                {
                    StringBuilder moveFol=new StringBuilder();
                    moveFol.Append(moves[i].ToCharArray(count,1));
                    if(moveFol.ToString()=="L")
                    {
                        if (right)
                        {
                            left = false;
                            right = false;
                            turnBack = false;
                        }
                        else if (left)
                        {
                            right = false;
                            left = false;
                            turnBack = true;
                        }
                        else if (turnBack)
                        {
                            right = true;
                            turnBack = false;
                            left = false;
                        }
                        else
                        {
                            left = true;
                            right = false;
                            turnBack = false;
                        }
                    }
                    if(moveFol.ToString()=="R")
                    {
                        if (left)
                        {
                            left = false;
                            right = false;
                            turnBack = false;
                        }
                        else if(right)
                        {
                            right=false;
                            left = false;
                            turnBack=true;
                        }
                        else if(turnBack)
                        {
                            right = false;
                            turnBack=false;
                            left=true;
                        }
                        else
                        {
                            left =false;
                            right = true;
                            turnBack = false;
                        }
                    }
                    if (moveFol.ToString() == "W")
                    {
                        if (right)
                        {
                            indexRow++;
                            if (indexRow > 2)
                                indexRow = 0;
                        }
                        else if (left)
                        {
                            indexRow--;
                            if (indexRow < 0)
                                indexRow = 2;
                        }
                        else if (turnBack)
                        {
                            indexCol--;
                            if (indexCol < 0)
                                indexCol = 2;
                        }
                        else
                        {
                            indexCol++;
                            if (indexCol > 2)
                                indexCol = 0;
                        }
                    }
                    count++;
                    moveFol.Clear();
                }
                Console.WriteLine(arr[indexCol,indexRow]);
            }

        }
    }
}