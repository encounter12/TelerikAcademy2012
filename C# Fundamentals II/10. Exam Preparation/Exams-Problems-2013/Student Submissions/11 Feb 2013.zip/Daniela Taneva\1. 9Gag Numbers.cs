using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        string zero = "-!";
        string one = "**";
        string two = "!!!";
        string three = "&&";
        string four = "&-";
        string five = "!-";
        string six = "*!!!";
        string seven = "&*!";
        string eight = "!!**!-";

        List<int> numbers=new List<int>();
        int digit = 0;
        int count = 0;
        double result = 0;
        int position=0;

        Console.WriteLine("Enter the input string:");
        string input = Console.ReadLine();

            for (int i = 0; i <input.Length; i++)
            {
                if (i + 6 <= input.Length && input.Substring(i, 6) == eight)
                {
                    digit = 8;
                    count++;
                    position =eight.Length;
                }
                else if (i + 3 <= input.Length &&input.Substring(i, 3) == seven)
                {
                    digit = 7;
                    count++;
                    position =seven.Length;
                }
                else if (i + 4 <= input.Length &&input.Substring(i, 4) == six)
                {
                    digit = 6;
                    count++;
                    position =six.Length;
                }
                else if (i + 2 <= input.Length && input.Substring(i, 2) == five)
                {
                    digit = 5;
                    count++;
                    position =five.Length;
                }
                else if (i + 2 <= input.Length &&input.Substring(i, 2) == four)
                {
                    digit = 4;
                    count++;
                    position =four.Length;
                }
                else if (i + 2 <= input.Length &&input.Substring(i, 2) == three)
                {
                    digit = 3;
                    count++;
                    position = three.Length;
                }
                else if (i + 3 <= input.Length &&input.Substring(i, 3) == two)
                {
                    digit = 2;
                    count++;
                    position = two.Length;
                }
                else if (i + 2 <= input.Length && input.Substring(i, 2) == one)
                {
                    digit = 1;
                    count++;
                    position =one.Length + 1;
                }
                else if (i + 2 <= input.Length &&input.Substring(i, 2) == zero)
                {
                    digit = 0;
                    count++;
                    position =zero.Length;
                }
                if(count>=1)
                {
                    numbers.Add(digit);
                    i =i+ position-1;
                }
            }

        for (int i = count; i >0; i--)
			{
			 result+= numbers[count-i]*(Math.Pow(9,i-1));
			}
            Console.WriteLine(result);
        }
    }
