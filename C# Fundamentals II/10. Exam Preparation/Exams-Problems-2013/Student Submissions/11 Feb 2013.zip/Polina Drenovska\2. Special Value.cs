using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpecialValue
{
    class Program
    {
        static void Main()
        {
            
            int n = int.Parse(Console.ReadLine());
            int[][] ne6tosi = new int[n][];
            for (int i = 0; i < n; i++)
            {
                string rowConsole = Console.ReadLine();
                string[] values = rowConsole.Split(',');
                ne6tosi[i] = new int[values.Length];
                for (int j = 0; j < values.Length; j++)
                {
                    ne6tosi[i][j] = int.Parse(values[j].Trim());
                }
            }
            int step = 0;
            int currentSum = 0;
            int bestSum = 0;
            int row = 0;
            for (int i = 0; i <  ne6tosi[0].Length; i++)
            {
                step++;
                int currElement = ne6tosi[0][i];
                if (currElement < 0)
                {
                    currentSum = step + Math.Abs(currElement);
                    if (currentSum > bestSum)
                        bestSum = currentSum;
                    currentSum = 0;
                    step = 0;
                }
                else
                {
                    step++;
                    currElement = ne6tosi[1][currElement];
                    if (currElement < 0)
                    {
                        currentSum = step + Math.Abs(currElement);
                        if (currentSum > bestSum)
                            bestSum = currentSum;
                        step = 0;
                    }
                }
            }
            Console.WriteLine(bestSum);
        }
    }
}
