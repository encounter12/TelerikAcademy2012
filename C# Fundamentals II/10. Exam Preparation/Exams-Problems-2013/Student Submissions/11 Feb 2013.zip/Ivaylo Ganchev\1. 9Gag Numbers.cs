using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9Gag_Numbers
{
    class Program
    {
        static void Main()
        {
            StringBuilder numbers = new StringBuilder();  //tuk subiram cifrite v deseti4en tip
            string input = Console.ReadLine();

            for (int j = 0; j < input.Length; j++)   //we read the chars in the string one by one till the end
            {
                if ((input[j] == '-' && j + 1 < input.Length && input[j + 1] == '!'))
                {
                    numbers.Append("0");
                    j++;    //j++ ako cifrata e ot 2 simvola
                    continue;
                }
                if ((input[j] == '*' && j + 1 < input.Length && input[j + 1] == '*'))
                {
                    numbers.Append("1");
                    j++;
                    continue;
                }
                if ((input[j] == '!' && j + 1 < input.Length && input[j + 1] == '!' && j + 2 < input.Length && input[j + 2] == '!'))
                {
                    numbers.Append("2");  // za 3 simvola izmestvame 2 puti nadqsno 
                    j++;
                    j++;
                    continue;
                }
                if ((input[j] == '&' && j + 1 < input.Length && input[j + 1] == '&'))
                {
                    numbers.Append("3");
                    j++;
                    continue;
                }
                if ((input[j] == '&' && j + 1 < input.Length && input[j + 1] == '-'))
                {
                    numbers.Append("4");
                    j++;
                    continue;
                }
                if ((input[j] == '!' && j + 1 < input.Length && input[j + 1] == '-'))
                {
                    numbers.Append("5");
                    j++;
                    continue;
                }
                if ((input[j] == '*' && j + 1 < input.Length && input[j + 1] == '!' && j + 2 < input.Length && input[j + 2] == '!' && j + 3 < input.Length && input[j + 3] == '!'))
                {
                    numbers.Append("6");
                    j++;          //za 4 simvola mestim 3puti nadqsno
                    j++;
                    j++;
                    continue;
                }
                if ((input[j] == '&' && j + 1 < input.Length && input[j + 1] == '*' && j + 2 < input.Length && input[j + 2] == '!'))
                {
                    numbers.Append("7");  // za 3 simvola izmestvame 2 puti nadqsno 
                    j++;
                    j++;
                    continue;
                }
                if ((input[j] == '!' && j + 1 < input.Length && input[j + 1] == '!' && j + 2 < input.Length && input[j + 2] == '*' && j + 3 < input.Length && input[j + 3] == '*' && j + 4 < input.Length && input[j + 4] == '!' && j + 5 < input.Length && input[j + 5] == '-'))
                {
                    numbers.Append("8");
                    j++;          //za 6 simvola mestim 5puti nadqsno
                    j++;
                    j++;
                    j++;
                    j++;
                    continue;
                }
            }
       //     Console.WriteLine(numbers.ToString());
       //     Console.WriteLine();
       //     Console.WriteLine();

           // string[] output = new[] {(numbers.ToString())};
            string output = (numbers.ToString());  //805

            StringBuilder outputnumbers = new StringBuilder();
            for (int i = 0; i < output.Length; i++)
            {

              outputnumbers = outputnumbers.Append((output[i]) * ((output.Length - 1 - i) * 9));
             // Console.WriteLine(output[i]);
            }
            Console.Write(outputnumbers.ToString());
        }
    }
}
         