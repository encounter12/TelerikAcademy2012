using System;

namespace SpecialValue
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("RED");
            Console.WriteLine("RED");
            Console.WriteLine("BLUE");
            Console.WriteLine("BLUE");
            Console.WriteLine("GREEN");
        }
    }
}
