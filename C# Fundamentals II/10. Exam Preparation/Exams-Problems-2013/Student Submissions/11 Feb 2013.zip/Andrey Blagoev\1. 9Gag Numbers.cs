using System;
using System.Collections.Generic;
using System.Numerics;

class ex01
{
    static int Convert(string code)
    {
        int digit;
        if (code == "-!")
            digit = 0;
        else if (code == "**")
            digit = 1;
        else if (code == "!!!")
            digit = 2;
        else if (code == "&&")
            digit = 3;
        else if (code == "&-")
            digit = 4;
        else if (code == "!-")
            digit = 5;
        else if (code == "*!!!")
            digit = 6;
        else if (code == "&*!")
            digit = 7;
        else if (code == "!!**!-")
            digit = 8;
        else
            digit = 9;

        return digit;
    }
    
    static void Main(string[] args)
    {

        string str = Console.ReadLine();
       // string str = "-!-!-!";
        string code;
        int startIndex = 0;        
        int move = 2;        
        BigInteger sum = 0;
        List<int> list = new List<int>();
        
        while (startIndex < str.Length)
        {
            code = str.Substring(startIndex, move);
            if (Convert(code) != 9)
            {               
                list.Add(Convert(code));
                startIndex = startIndex + move;
                move = 2;
            }
            else
            {               
                move++;                
            }
        }
        
        BigInteger multi = 1;
        for (int i = 0; i < list.Count; i++)
        {
            sum = sum + multi * list[list.Count - i - 1];
            multi = multi * 9;
        }

        Console.WriteLine(sum);


    }
}
