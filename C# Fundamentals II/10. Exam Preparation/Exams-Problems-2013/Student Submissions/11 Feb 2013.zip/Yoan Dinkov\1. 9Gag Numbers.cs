using System;
using System.Collections.Generic;
using System.Text;

class ConvertTo9gag
{
    static void Main()
    {

        string Input = Console.ReadLine();
        for (int i = 0; i < Input.Length; i++)
        {
            if (!(Input[i] == '!' || Input[i] == '-' || Input[i] == '*' || Input[i] == '&'  ))
            {
                Main();
            }
        }
        if (Input.Length > 20 && Input.Length < 1)
        {
            Main();
        }
        Console.WriteLine(ConvertTo9gagNumber(Input));
    }

    static int ConvertTo9gagNumber(string input)
    {
        int OutputNumber = 0;
        char[] symbols = input.ToCharArray();
        string currentString = "";
        StringBuilder Result = new StringBuilder();
        List<int> diggits = new List<int>();
        for (int i = 0; i < symbols.Length; i++)
        {
            Result.Append(symbols[i]);
            currentString = Result.ToString();
            if (currentString == "-!" || currentString == "**" || currentString == "!!!" || currentString == "&&" || currentString == "&-" || currentString == "!-" || currentString == "*!!!" || currentString == "&*!" || currentString == "!!**!-")
            {
                diggits.Add(Converting(currentString));
                Result = new StringBuilder();
            }
        }

        for (int i = 0 ; i < diggits.Count; i++)
        {
           OutputNumber += (diggits[i] * (int)(Math.Pow(9, diggits.Count-i-1)));
        }
        return OutputNumber;
    }

    static int Converting(string input)
    {
        switch (input)
        {
            case "-!":
                return 0;
            case "**":
                return 1;
            case "!!!":
                return 2;
            case "&&":
                return 3;
            case "&-":
                return 4 ;
            case "!-":
                return 5;
            case "*!!!":
                return 6;
            case "&*!":
                return 7;
            case "!!**!-":
                return 8 ;
            default :
                return -1;
        }
    }


}
