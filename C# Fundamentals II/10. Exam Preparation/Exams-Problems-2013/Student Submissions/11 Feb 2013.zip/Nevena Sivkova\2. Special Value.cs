using System;
using System.Collections.Generic;
using System.Text;

class SpecialValue
{
    static int rows;
    static int[][] numbers;
    static int[][] visited;
    static int[] results;
    static int row, col, maxCol;
    static int pathLength = 0;
    static int pathEnd = 0;
    static bool findSpecialValue;
    static bool getEnd = false;

    static void Main()
    {
        ReadInput();
        Console.WriteLine(GetMaxSpecialValue());
    }

    static void ReadInput()
    {
        rows = int.Parse(Console.ReadLine());
        numbers = new int[rows][];
        visited = new int[rows][];
        for (int i = 0; i < rows; i++)
        {
            string text = Console.ReadLine();
            string[] numbersInRow = text.Split(new string[] {", "}, StringSplitOptions.RemoveEmptyEntries);
            int cols = numbersInRow.Length;
            numbers[i] = new int[cols];
            visited[i] = new int[cols];

            for (int j = 0; j < cols; j++)
            {
                numbers[i][j] = int.Parse(numbersInRow[j]);
                if (numbers[i][j] < 0)
                    getEnd = true;
            }
        }

        results = new int[numbers[0].Length];
    }

    static void ClearVisited()
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < visited[i].Length; j++)
            {
                visited[i][j] = 0;
            }
        }
    }

    static void FindNext()
    {
        if (visited[row][col] == 1)
        {
            pathEnd = 0;
            return;
        }

        if ((row == 0) && (col > maxCol))
        {
            findSpecialValue = (results[col] > 0);
            pathLength = results[col] + pathLength;
            return;
        }

        pathLength++;
        visited[row][col] = 1;

        if (numbers[row][col] < 0)
        {
            pathEnd = Math.Abs(numbers[row][col]);
            findSpecialValue = true;
            return;
        }

        col = numbers[row][col];
        row++;
        if (row >= rows)
            row = 0;
        FindNext();
    }


    static int GetMaxSpecialValue()
    {
        if (!getEnd)
            return 0;

        int specialValue = 0;
        for (int i = 0; i < numbers[0].Length; i++)
        {
            row = 0;
            col = i;
            maxCol = i;
            findSpecialValue = false;
            pathEnd = 0;
            pathLength = 0;
            ClearVisited();

            FindNext();

            if (findSpecialValue)
                results[i] = pathLength + pathEnd;
            else
                results[i] = -1;

            if (findSpecialValue && pathLength + pathEnd > specialValue)
                specialValue = pathLength + pathEnd;
        }

        return specialValue;
    }

}