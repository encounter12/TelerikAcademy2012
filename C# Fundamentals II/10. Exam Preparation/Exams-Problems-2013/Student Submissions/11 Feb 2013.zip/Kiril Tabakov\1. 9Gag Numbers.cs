using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class Program
{   //                                        0     1      2     3      4   5       6       7       8                              
    //static string[] numbers = new string[] { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
    static Dictionary<string, int> numbers = new Dictionary<string, int>()
    {
    { "-!", 0 },
    { "**",1 },
    { "!!!", 2},
    { "&&", 3},
    { "&-", 4},
    { "!-", 5},
    { "*!!!", 6},
    { "&*!", 7},
    { "!!**!-", 8}
    };
    static string input;

    static void Main()
    {
        input = Console.ReadLine();
        StringBuilder tmp = new StringBuilder();
        StringBuilder result = new StringBuilder();
        BigInteger res = 0;
        BigInteger curPow = 1;

        for (int i = 0; i < input.Length; i++)
        {
            tmp.Append(input[i]);
            if (numbers.ContainsKey(tmp.ToString()))
            {
                result.Append(numbers[tmp.ToString()]);
                tmp = new StringBuilder();
            }
        }
        string toParse = result.ToString();
        for (int i = toParse.Length-1; i >= 0; i--)
        {
            res += (curPow * (toParse[i] - '0'));
            curPow *= 9;
        }
        Console.WriteLine(res);
    }
}