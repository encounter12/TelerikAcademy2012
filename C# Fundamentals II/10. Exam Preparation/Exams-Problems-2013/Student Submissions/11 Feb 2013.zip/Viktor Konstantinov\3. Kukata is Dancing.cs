using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            int.TryParse(Console.ReadLine(), out n);
            for (int i = 0; i < n; i++)
            {
                String s = Console.ReadLine();
                int[,] map = new int[3, 3];
                int x = 1, y = 1, d = 0;
                foreach (char c in s)
                {
                    switch (c)
                    {
                        case 'L':
                            d = (d + 3) % 4;
                            break;
                        case 'R':
                            d = (d + 1) % 4;
                            break;
                        case 'W':
                            switch (d)
                            {
                                case 0:
                                    y = (y + 2) % 3;
                                    break;
                                case 1:
                                    x = (x + 1) % 3;
                                    break;
                                case 2:
                                    y = (y + 1) % 3;
                                    break;
                                case 3:
                                    x = (x + 2) % 3;
                                    break;
                            }
                            break;
                    }
                    /*Console.WriteLine("---");
                    Console.WriteLine(x);
                    Console.WriteLine(y);
                    Console.WriteLine(d);*/

                }
                if (x == 1 && y == 1)
                {
                    Console.WriteLine("GREEN");
                    continue;
                }
                if((x+y)%2==0)
                {
                    Console.WriteLine("RED");
                    continue;
                }
                Console.WriteLine("BLUE");
            }
        }
    }
}
