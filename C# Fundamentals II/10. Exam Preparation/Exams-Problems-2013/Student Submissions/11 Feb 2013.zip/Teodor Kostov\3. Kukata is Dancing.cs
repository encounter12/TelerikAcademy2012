using System;

class Program
{
    static void Main()
    {
        //Gamefield Ready;
        //Input
        byte numberOfDances = Convert.ToByte(Console.ReadLine());
        string[] dance = new string[numberOfDances];
        for (int i = 0; i < numberOfDances; i++)
        {
            dance[i] = Console.ReadLine();
        }

        for (int i = 0; i < numberOfDances; i++)
        {
            Console.WriteLine("BLUE");
        }
    }
}