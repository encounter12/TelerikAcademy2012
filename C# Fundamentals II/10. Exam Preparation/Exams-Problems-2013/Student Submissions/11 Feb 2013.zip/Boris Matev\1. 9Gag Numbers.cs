using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1.NineGag
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> numbersList = new List<int>();
            string input = Console.ReadLine();
            StringBuilder numbBuild = new StringBuilder();
            for (int i = 0; i < input.Length; i++)
            {
                numbBuild.Append(input[i]);
                switch (numbBuild.ToString())
                {   case "-!":
                        numbersList.Add(0);
                        numbBuild.Clear();
                        break;
                    case "**":
                        numbersList.Add(1);
                        numbBuild.Clear();
                        break;
                    case "!!!":
                        numbersList.Add(2);
                        numbBuild.Clear();
                        break;
                    case "&&":
                        numbersList.Add(3);
                        numbBuild.Clear();
                        break;
                    case "&-":
                        numbersList.Add(4);
                        numbBuild.Clear();
                        break;
                    case "!-":
                        numbersList.Add(5);
                        numbBuild.Clear();
                        break;
                    case "*!!!":
                        numbersList.Add(6);
                        numbBuild.Clear();
                        break;
                    case "&*!":
                        numbersList.Add(7);
                        numbBuild.Clear();
                        break;
                    case "!!**!-":
                        numbersList.Add(8);
                        numbBuild.Clear();
                        break;
                    default:
                        break;
                }
            }
            int[] numbers = numbersList.ToArray();
            long answer = 0;
            long multiply = 1;
            for (int i = numbers.Length - 1; i >= 0; i--)
            {
                answer += numbers[i] * multiply;
                multiply *= 9;
            }
            Console.WriteLine(answer);
        }
    }
}
