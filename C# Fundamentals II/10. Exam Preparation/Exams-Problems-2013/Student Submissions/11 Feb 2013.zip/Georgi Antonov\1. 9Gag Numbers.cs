using System;
class Program
{
    static void Main()
    {
        String input = Console.ReadLine();
        ulong number = 0;
        int i = 0;
        while(i<input.Length)
        {
            number = number*9;
            switch (input[i])
            {
                case '-':
                    i+=2;
                    break;
                case '*':
                    if (input[i + 1] == '*')
                    {
                        number += 1;
                        i += 2;
                    }
                    else if (input[i + 1] == '!')
                    {
                        number += 6;
                        i += 4;
                    }
                    break;
                case '&':
                    if (input[i + 1] == '&')
                    {
                        number += 3;
                        i += 2;
                    }
                    else if (input[i + 1] == '-')
                    {
                        number += 4;
                        i += 2;
                    }
                    else if(input[i + 1] == '*')
                    {
                        number += 7;
                        i += 3;
                    }
                    break;
                case '!':
                    if (input[i + 1] == '-')
                    {
                        number += 5;
                        i += 2;
                    }
                    else if (input[i + 2] == '!')
                    {
                        number += 2;
                        i += 3;
                    }
                    else if (input[i + 2] == '*')
                    {
                        number += 8;
                        i += 6;
                    }
                    break;
            }
        }
        Console.WriteLine(number);
    }
}
