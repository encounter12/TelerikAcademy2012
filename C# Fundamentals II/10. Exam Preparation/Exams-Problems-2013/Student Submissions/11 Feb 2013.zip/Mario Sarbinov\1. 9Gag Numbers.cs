using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class Program
{
    static void Main(string[] args)
    {
        string number = Console.ReadLine();
        int index = 0, position = -1, umnojenie = 1;
        double result = 0;
        int[] digits = new int[30];
        while (index < number.Length - 1)
        {
            position++;
            if (index + 6 <= number.Length)
            {
                if (number.IndexOf("!!**!-", index, 6) != -1)
                {
                    digits[position] = 8;
                    index += 6;
                    continue;
                }
            }
            if (index + 3 <= number.Length)
            {
                if (number.IndexOf("&*!", index, 3) != -1)
                {
                    digits[position] = 7;
                    index += 3;
                    continue;
                }
            } if (index + 4 <= number.Length)
            {
                if (number.IndexOf("*!!!", index, 4) != -1)
                {
                    digits[position] = 6;
                    index += 4;
                    continue;
                }
            }
            if (number.IndexOf("!-", index, 2) != -1)
            {
                digits[position] = 5;
                index += 2;
                continue;
            }
            if (number.IndexOf("&-", index, 2) != -1)
            {
                digits[position] = 4;
                index += 2;
                continue;
            }
            if (number.IndexOf("&&", index, 2) != -1)
            {
                digits[position] = 3;
                index += 2;
                continue;
            } if (index + 3 <= number.Length)
            {
                if (number.IndexOf("!!!", index, 3) != -1)
                {
                    digits[position] = 2;
                    index += 3;
                    continue;
                }
            }
            if (number.IndexOf("**", index, 2) != -1)
            {
                digits[position] = 1;
                index += 2;
                continue;
            }
            if (number.IndexOf("-!", index, 2) != -1)
            {
                digits[position] = -1;
                index += 2;
                continue;
            }
        }

        for (int i = 29; i >= 0; i--)
        {
            if (digits[i] != 0)
            {
                if (digits[i] == -1)
                {
                    umnojenie *= 9;
                    continue;
                }
                result += (digits[i] * umnojenie);
                umnojenie *= 9;
            }
        }
        Console.WriteLine(result);
    }
}
