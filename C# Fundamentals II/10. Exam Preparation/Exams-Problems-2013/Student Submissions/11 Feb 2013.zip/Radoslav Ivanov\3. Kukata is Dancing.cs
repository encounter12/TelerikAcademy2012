using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace value
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[, ,] cube = new string[3, 3, 3];
            string direction = Console.ReadLine();
            int evenBlue = 0;
            int evenGreen = 0;
            int evenRed = 0;
            int dir = 0;//0 up,1 right, 2 down, 3 left
            string currPos ="green";
            string[] positions = new string[n];
            for (int j = 0; j < n; j++)
            {


                for (int i = 0; i < direction.Length; i++)
                {
                    char nextChar = direction[i];
                    if (nextChar == 'L' && currPos == "green")
                    {
                        if (dir == 0) dir = 3;
                        if (dir == 1) dir = 2;
                        if (dir == 2) dir = 1;
                        if (dir == 3) dir = 0;
                        currPos = "blue";
                        dir = 3;

                    }
                    else if (nextChar == 'L' && currPos == "blue")
                    {

                        currPos = "red";
                        evenRed++;
                    }
                    else if (nextChar == 'L' && currPos == "red")
                    {
                        evenBlue++;
                        currPos = "blue";
                    }
                    else if (nextChar == 'R' && currPos == "green")
                    {
                        evenBlue++;
                        currPos = "blue";
                    }
                    else if (nextChar == 'R' && currPos == "blue")
                    {
                        evenRed++;
                        currPos = "green";
                    }
                    else if (nextChar == 'R' && currPos == "red")
                    {

                        currPos = "blue";
                    }
                    else if (nextChar == 'W' && currPos == "red")
                    {

                        if (evenRed % 2 == 0)
                        {
                            currPos = "blue";
                            evenRed = 0;
                        }
                        else
                        {
                            currPos = "red";
                            evenRed++;
                        }
                    }
                    else if (nextChar == 'W' && currPos == "blue")
                    {
                        if (evenBlue % 2 == 0)
                        {
                            currPos = "green";
                            evenRed = 0;
                        }
                        else
                        {
                            currPos = "blue";
                            evenBlue++;
                        }

                    }
                    else if (nextChar == 'W' && currPos == "green")
                    {

                        currPos = "blue";
                    }
                }

                positions[j] = currPos;
            }
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(positions[i]);
            }
        }
    }
}
