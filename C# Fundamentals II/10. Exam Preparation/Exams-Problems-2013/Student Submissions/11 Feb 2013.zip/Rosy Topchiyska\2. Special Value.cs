using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem2
{
  class Program
  {
    public static bool IsTraversible(long[][] arr, bool[][] visited, long row, long col) {
      if(arr[row][col] < 0) {
        return false;
      }     
      if(visited[row][col]) {
        return false;
      }
      visited[row][col] = true;
      return true;
    }

     static void Main()
    {
      long rows = long.Parse(Console.ReadLine());
      long[][]  array   = new long[rows][];
      
      bool[][] visited0 = new bool[rows][];
      long i;
      long sum = 0;
      long pathLength = 1;
      long maxSum = 0;
      for(i = 0; i < rows; i++) {
        array[i] = Console.ReadLine().Trim().Split(',').Select(x => long.Parse(x)).ToArray();
        visited0[i] = new bool[array[i].Length];
      }
      bool[][] visited = visited0;
      long row, col;
      bool negative = false;

      for(int j = 0; j < array[0].Length; j++) {
        row = 0;
        col = j;
        negative = (array[0][j] < 0);
        sum = negative ? array[row][col] : 0;
        pathLength = 1;
        while(!negative) {
          visited[row][col] = true;
          //move to next
          col = array[row][col];
          row = (row == array.Length - 1) ? 0 : row + 1;
          if (visited[row][col]) {
            sum = 0;
            pathLength = 0;
            break; //-->
          }
          negative = (array[row][col] < 0);
          sum = negative ? array[row][col] : 0;
          pathLength++;
        }
        if( pathLength - sum > maxSum) {
          maxSum = pathLength - sum;
        }
        visited = visited0;
      }
      Console.WriteLine(maxSum);
    }
     
  }
}
