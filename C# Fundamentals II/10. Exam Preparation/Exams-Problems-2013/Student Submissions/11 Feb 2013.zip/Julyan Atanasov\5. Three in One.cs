using System;
using System.Collections.Generic;

class ThreeInOne
{
     static int[] Sort(params int[] numbers)
        {
            for (int i = 0; i < numbers.Length - 1; i++)
            {
                for (int j = i + 1; j < numbers.Length; j++)
                {
                    if (numbers[i] > numbers[j])
                    {
                        int OldNum = numbers[i];
                        numbers[i] = numbers[j];
                        numbers[j] = OldNum;
                    }
                }
            }
            return numbers;
        }

    static void Main()
    {
        //Enter points
        string results = Console.ReadLine();
        char[] separators = new char[] { ',' };
        string[] splitresult = results.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                
        int pointslenght = splitresult.Length;
        int[] points = new int[pointslenght];

        //Convert to int
        int i = 0;

        foreach(String text in splitresult)
        {
        int.TryParse(text, out points[i]);
        ++i;
        }
        
       
        //Find the winner

        bool uniqueValue = true;

        for (int j = 0; j < points.Length; j++)
        {
            for (int k = 0; k < j; k++)
            {
                if (points[j] == points[k])
                {
                    uniqueValue = false;
                }
            }
        }
            


            string sizesString = Console.ReadLine();
            int F = int.Parse(Console.ReadLine());
            string[] splitSizes = sizesString.Split(separators, StringSplitOptions.RemoveEmptyEntries);

            int sizeslenght = splitSizes.Length;
            int[] sizes = new int[sizeslenght];

            int NewNumberOfElement = 0;

            foreach (String text in splitSizes)
            {
                int.TryParse(text, out sizes[NewNumberOfElement]);
                ++NewNumberOfElement;
            }
            
                        
            int[] numbers = Sort(sizes);
            int bites = 0;
            for (int overloads = numbers.Length-1; overloads>=0; overloads=overloads-F-1)
            {
                bites += numbers[overloads];
            }
        

        //Print
            if (uniqueValue == true)
            {
                Console.WriteLine(0);
            }
            else
            {
                Console.WriteLine(-1);
            }
            Console.WriteLine(bites);
        }
    }


