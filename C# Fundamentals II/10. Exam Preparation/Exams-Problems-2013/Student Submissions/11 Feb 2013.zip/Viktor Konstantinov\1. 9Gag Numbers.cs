using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
  
namespace cs2
{
    class Program
    {
        static void Main(string[] args)
        {
            String input;
            input = Console.ReadLine();
            int i = 0;
            List<long> nd=new List<long>();
            String[] d = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
            while (i < input.Length)
            {
                for (int j = 2; j <= 6; j++)
                {
                    String s = input.Substring(i, j);
                    for (int k = 0; k < 9; k++)
                    {
                        if (d[k] == s)
                        {
                            nd.Add(k);
                            i += j;
                            goto l1;
                        }
                    }
                }
                Console.WriteLine(i);
                int a = 4;
                int b = 1 / (a - a);
            l1: ;
            }
            ulong num = 0;
            ulong m = 1;
            for (i = nd.Count - 1; i >= 0; i--)
            {
                num += (ulong)nd[i] * m;
                m *= 9;
            }
            Console.WriteLine(num);
        }
    }
}