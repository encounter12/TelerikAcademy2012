using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Kukata
{
    public static int ChangeDirection(char direction, int currentDirection)
    {
        int newDirection = 0;
        if (direction == 'L')
        {
            if (currentDirection == 4)
            {
                newDirection = 1;
            }
            else
            {
                newDirection = currentDirection + 1;   
            }
        }
        if (direction == 'R')
        {
            if (currentDirection == 1)
            {
                newDirection = 4;
            }
            else
            {
                newDirection = currentDirection - 1;
            }
        }
        return newDirection;
    }

    public static int[] ExecuteWalk(int currDirection, int[] currPosition)
    {
        if (currDirection == 1)
        {
            currPosition[1] = currPosition[1] - 1;
        }
        else if (currDirection == 2)
        {
            currPosition[0] = currPosition[0] - 1;
        }
        else if (currDirection == 3)
        {
            currPosition[1] = currPosition[1] + 1;
        }
        else // here currDirection can be only 4
        {
            currPosition[0] = currPosition[0] + 1;
        }

        if (currPosition[0] == -1)
        {
            currPosition[0] = 2;
        }
        if (currPosition[0] == 3)
        {
            currPosition[0] = 0;
        }

        if (currPosition[1] == -1)
        {
            currPosition[1] = 2;
        }
        if (currPosition[1] == 3)
        {
            currPosition[1] = 0;
        }
        return currPosition;
    }

    static void Main()
    {
        int nLines = int.Parse(Console.ReadLine());

        string[,] danceMatrix = new string[3, 3];
        danceMatrix[0,0] = "RED";
        danceMatrix[0,1] = "BLUE";
        danceMatrix[0,2] = "RED";
        danceMatrix[1,0] = "BLUE";
        danceMatrix[1,1] = "GREEN";
        danceMatrix[1,2] = "BLUE";
        danceMatrix[2,0] = "RED";
        danceMatrix[2,1] = "BLUE";
        danceMatrix[2,2] = "RED";

        string[] inputByLine = new string[nLines];

        for (int i = 0; i < inputByLine.Length; i++)
        {
            inputByLine[i] = Console.ReadLine();
        }

        int currentDirection = 1;
        int[] currentPosition = {1, 1};
        // currentPosition[0] -> width OR X
        // currentPosition[1] -> height OR Y
        //currentPosition = ExecuteWalk(currentDirection, currentPosition);

        for (int i = 0; i < inputByLine.Length; i++)
        {
            char[] currLineByChars = inputByLine[i].ToCharArray();
            foreach (var elem in currLineByChars)
            {
                if (elem == 'W')
                {
                    currentPosition = ExecuteWalk(currentDirection, currentPosition);
                }
                if (elem == 'R' || elem == 'L')
                {
                    currentDirection = ChangeDirection(elem, currentDirection);
                }
            }
            //Console.Write(currentPosition[0]);
            //Console.Write(" ");
            //Console.WriteLine(currentPosition[1]);

            Console.WriteLine(danceMatrix[currentPosition[0], currentPosition[1]]);

            currentPosition[0] = 1;
            currentPosition[1] = 1;
        }
        
    }
}
