using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Telerik
{
    class KukataBrato
    {
        static void Main(string[] args)
        {

#if DEBUG
            Console.SetIn(new StreamReader("kukata1.txt"));
#endif

            var xA = 2;
            var yA = 2;
            var dir = 0;
            var dirs = new[] { new[] { 1, 0 }, new[] { 0, 1 }, new[] { -1, 0 }, new[] { 0, -1 } };
            var n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                bool stay;
                do
                {
                    stay = true;
                    var ch = Console.Read();
                    switch (ch)
                    {
                        case 'L':
                            dir++;
                            break;
                        case 'R':
                            dir--;
                            break;
                        case 'W':
                            var dirA = dirs[dir];
                            xA += dirA[0];
                            yA += dirA[1];
                            if (xA > 3)
                                xA = 1;
                            else if (xA < 1)
                                xA = 3;
                            if (yA > 3)
                                yA = 1;
                            else if (yA < 1)
                                yA = 3;
                            break;
                        default:
                            stay = false;
                    var k=        Console.Read();
                            if (xA == 1 && (yA == 1 || yA == 3) || xA == 3 && (yA == 1 || yA == 3))
                                Console.WriteLine("RED");
                            else if (xA == 2 && yA == 2)
                                Console.WriteLine("GREEN");
                            else
                                Console.WriteLine("BLUE");
                            break;
                    }
                    dir = dir % 4;
                } while (stay);
            }
        }
    }
}
