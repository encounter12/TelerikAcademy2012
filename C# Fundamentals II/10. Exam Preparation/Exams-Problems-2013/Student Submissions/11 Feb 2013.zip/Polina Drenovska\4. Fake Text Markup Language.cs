using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace FTML2
{
    class FTML2
    {
        static List<StringBuilder> allText = new List<StringBuilder>();

        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string row = Console.ReadLine();
                StringBuilder ftext = new StringBuilder();
                while (true)
                {
                    ftext.Append(Regex.Replace(row, "<upper>(.*?)</upper>", m => UpperMode(m.Groups[1].Value)));
                    ftext = new StringBuilder(Regex.Replace(ftext.ToString(), "<lower>(.*?)</lower>", m => LowerMode(m.Groups[1].Value)));
                    ftext = new StringBuilder(Regex.Replace(ftext.ToString(), "<rev>(.*?)</rev>", m => ReverseMode(m.Groups[1].Value)));
                    ftext = new StringBuilder(Regex.Replace(ftext.ToString(), "<toggle>(.*?)</toggle>", m => ToggleMode(m.Groups[1].Value)));
                    ftext = new StringBuilder(Regex.Replace(ftext.ToString(), "<del>(.*?)</del>", String.Empty));
                    break;
                }
               allText.Add(ftext);
              
            }
                 foreach(var row in allText)
          Console.WriteLine(row);
          
        }
        static string UpperMode(string text)
        {
            return text.ToUpper();
        }
        static string LowerMode(string text)
        {
            return text.ToLower();
        }
        static string ToggleMode(string text)
        {
            StringBuilder mystring = new StringBuilder(text);
            for (int i = 0; i < mystring.Length; i++)
            {
                char c = mystring[i];
                mystring[i] = Char.IsLower(c) ? Char.ToUpper(c) : Char.ToLower(c);
            }
            return mystring.ToString();
        }
        static string ReverseMode(string text)
        {
            StringBuilder mystring = new StringBuilder();
            for (int i = text.Length - 1; i >= 0; i--)
            {
                mystring.Append(text[i]);
            }
            return mystring.ToString();
        }
    }
}
