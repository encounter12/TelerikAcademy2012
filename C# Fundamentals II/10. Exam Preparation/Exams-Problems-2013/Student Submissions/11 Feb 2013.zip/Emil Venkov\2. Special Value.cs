using System;
using System.Collections.Generic;
using System.Diagnostics;

class SpecialValue
{
    static void Main()
    {
        //Stopwatch sw = new Stopwatch();
        //sw.Start();

        //List<int> chekck = new List<int>();
        //for (int i = 0; i < 1000000; i++)
        //{
        //    chekck.Add(i);
        //}
        ////if (chekck.Contains(1000000))
        ////{
            
        ////}
        //sw.Stop();
        //Console.WriteLine(sw.Elapsed);
        int rowCount = int.Parse(Console.ReadLine());
        bool[][] visitedCells = new bool[rowCount][];
        int[][] jaggedArray = new int[rowCount][];
        string[] numbers;
        for (int i = 0; i < rowCount; i++)
        {
            numbers = Console.ReadLine().Split(new char[] {' ', ','},StringSplitOptions.RemoveEmptyEntries);
            jaggedArray[i] = new int[numbers.Length];
            visitedCells[i] = new bool[numbers.Length];
            for (int j = 0; j < numbers.Length; j++)
            {
                jaggedArray[i][j] = int.Parse(numbers[j]);
            }
        }

        int row = 0, next = 0, path = 1, maxSpecValue = 0, tempSpecValue = 0;
        bool[][] tempVisited = (bool[][])visitedCells.Clone();

        for (int col = 0; col < jaggedArray[row].Length; col++)
        {
            next = jaggedArray[row][col];
            path = 1;
            row++;
            while ((next >= 0) && (!tempVisited[row][next]))
            {
                
                tempVisited[row][next] = true;
                //row++;
                
                next = jaggedArray[row][next];
                path++;
                row++;
                if (row >= rowCount)
                {
                    row = 0;
                }
            }
            if (next < 0)
            {
                tempSpecValue = path + Math.Abs(next);
                maxSpecValue = Math.Max(tempSpecValue, maxSpecValue);
            }
            tempVisited = (bool[][])visitedCells.Clone();
            row = 0;
        }
        Console.WriteLine(maxSpecValue);
        //for (int i = 0; i < rowCount; i++)
        //{
        //    for (int j = 0; j < jaggedArray[i].Length; j++)
        //    {
        //        Console.Write("{0} ", visitedCells[i][j]);
        //    }
        //    Console.WriteLine();
        //}
    }
}