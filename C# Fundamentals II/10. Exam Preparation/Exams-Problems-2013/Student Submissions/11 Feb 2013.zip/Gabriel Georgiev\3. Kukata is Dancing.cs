using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.KukataIsDancing
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] array = { { 1, 2, 1 }, { 2, 3, 2 }, { 1, 2, 1 } };
            
            int N = int.Parse(Console.ReadLine());
            string[] output=new string[N];

            for (int counter = 0; counter < N; counter++)
            {
                string sequence = Console.ReadLine();
                int turn = 50, row = 1, column = 1;

                for (int i = 0; i < sequence.Length; i++)
                {
                    switch (sequence[i])
                    {
                        case 'R': turn++; break;
                        case 'L': turn--; break;
                        case 'W':
                            switch (turn % 4)
                            {
                                case 0: if (row == 0) row = 2; else row--; break;
                                case 1: if (column == 2) column = 0; else column++; break;
                                case 2: if (row == 2) row = 0; else row++; break;
                                case 3: if (column == 0) column = 2; else column--; break;
                            }
                            break;
                    }
                }

                switch (array[row, column])
                {
                    case 1: output[counter]="RED"; break;
                    case 2: output[counter]="BLUE"; break;
                    case 3: output[counter] = "GREEN"; break;
                }
            }

            for (int counter = 0; counter < N; counter++)
            {
                Console.WriteLine(output[counter]);
            }
        }
    }
}
