using System;

class HexaToDec
{
	static void Main()
	{
		string gagString = Console.ReadLine();
		double DecNumber = 0;
		int Size = gagString.Length / 2;
		double digit = 0;
		int count = 0;
		
		
		for (int i = 0; i < gagString.Length/2; i++)
		{
			//if (gagString.Substring(3) == "!!!" || gagString.Substring(3) == "&*!")
			//{
			//	
			//}
			if (gagString == "!!!")
			{
				digit = DecNumber = 2; break;
			}
			else if (gagString == "&*!")
			{
				digit = DecNumber = 7; break;
			}
			else if (gagString == "*!!!")
			{
				digit = DecNumber = 6; break;
			}
			else if (gagString == "!!**!-")
			{
				digit = DecNumber = 8; break;
			}
			switch (gagString.Substring(count*2,2))
			{
				case "-!":
					digit = 0; break;
				case "**":
					digit = 1; break;
				case "!!!":
					digit = 2; break;
				case "&&":
					digit = 3; break;
				case "&-":
					digit = 4; break;
				case "!-":
					digit = 5; break;
				case "*!!!":
					digit = 6; break;
				case "&*!":
					digit = 7; break;
				case "!!**!-":
					digit = 8; break;
				default: 
					if (gagString == "!!!")
					{
						digit = 2;
					}
					else if (gagString == "&*!")
					{
						 digit = 7;
					}
					else if (gagString == "*!!!")
					{
						digit = 6;
					}
					else if (gagString == "!!**!-")
					{
						digit = 8;
					}
					 break;
			}
			//double num = double.Parse(binNumber[i].ToString());
			DecNumber += digit * (Math.Pow(9, (double)Size - 1));
			Size--;
			count++;
		}
		Console.WriteLine(DecNumber);
	}
}
