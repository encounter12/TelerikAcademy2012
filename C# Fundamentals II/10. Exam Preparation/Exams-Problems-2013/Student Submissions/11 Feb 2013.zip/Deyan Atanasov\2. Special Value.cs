using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecialValue
{
    class Program
    {
        static void Main(string[] args)
        {
            short N = short.Parse(Console.ReadLine());
            short[][] rows = new short[N][];
            char[] delimiters = { ',', ' ' };
            string[] line;
            for (int i = 0; i < N; i++)
            {
                line = Console.ReadLine().Split(delimiters,StringSplitOptions.RemoveEmptyEntries);
                rows[i] = new short[line.Length];

                short j = 0;
                foreach (var item in line)
                {
                    rows[i][j] = short.Parse(item);
                    j++;
                }
            }

            short[] sv = new short[rows[0].Length];
            for (short i = 0; i < rows[0].Length; i++)
            {
                short path = 0;
                short col = i;
                short row = 0;
                short oldcol = 0;
                while (rows[row][col] >= 0 && rows[row][col] < 1001)
                {
                    oldcol = col;
                    col = rows[row][col];
                    rows[row][oldcol] = 1001;
                    path++;
                    row++;
                    if (row >= rows.Length) row = 0;
                }
                sv[i] = path;
                if (rows[row][col] < 0)
                {
                    sv[i] -= rows[row][col];
                }
            }
            short maxsv = 0;
            for (short i = 0; i < sv.Length; i++)
            {
                if (sv[i] > maxsv)
                {
                    maxsv = sv[i];
                }
            }
            Console.WriteLine(maxsv);
        }
    }
}
