using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ThreeInOne
{
    class ThreeInOne
    {
        static string pointText;
        static int[,] points;
        static string sizesText;
        static int[] sizes;
        static int friends;
        static string coinsText;
        static int G1, S1, B1, G2, S2, B2;

        static void Main(string[] args)
        {
            ReadInput();
            Console.WriteLine(Blackjack());
            Console.WriteLine(Cackes());
            Console.WriteLine(Coins());

        }

        static void ReadInput()
        {
            pointText = Console.ReadLine();
            sizesText = Console.ReadLine();
            friends = int.Parse(Console.ReadLine());
            coinsText = Console.ReadLine();

            string[] poinsArr = pointText.Split(',');
            points = new int[2, poinsArr.Length];
            for (int i = 0; i < poinsArr.Length; i++)
            {
                points[0, i] = int.Parse(poinsArr[i]);  
            }

            string[] sizesArr = sizesText.Split(',');
            sizes = new int[sizesArr.Length];
            for (int i = 0; i < sizesArr.Length; i++)
            {
                sizes[i] = int.Parse(sizesArr[i]);
            }

            string[] coinsArr = coinsText.Split(' ');
            G1 = int.Parse(coinsArr[0]);
            S1 = int.Parse(coinsArr[1]);
            B1 = int.Parse(coinsArr[2]);
            G2 = int.Parse(coinsArr[3]);
            S2 = int.Parse(coinsArr[4]);
            B2 = int.Parse(coinsArr[5]);
        }

        static int Blackjack()
        {
            int maxValue = -1;

            for (int i = 0; i < points.Length/2; i++)
            {
                if (points[0, i] >= maxValue && points[0, i] <= 21)
                {
                    maxValue = points[0, i];
                    points[1, i] = 1;

                    for (int j = 0; j < i; j++)
                    {
                        if (points[0, i] < maxValue)
                            points[1, i] = 0;  
                    }
                }
            }

            int index = -1;
            int count = 0;
            for (int i = 0; i < points.Length / 2; i++)
            {
                if (points[1, i] == 1)
                {
                    index = i;
                    count++;
                }
            }

            if (count == 1)
                return index;
            else
                return -1;
        }

        static int Cackes()
        {
            Array.Sort(sizes);
            int total = 0;
            for (int i = sizes.Length - 1; i >= 0; i -= friends + 1)
            {
                total += sizes[i];
            }

            return total;
        }

        static int Coins()
        {
            int exchanges = 0;

            while (G1 != G2 || S1 != S2 )
            {
                // повече злато
                if (G1 > G2)
                {
                    int GtoS = (G1 - G2);
                    S1 = S1 + GtoS * 9;
                    G1 = G1 - GtoS;
                    exchanges += GtoS;

                    continue;
                }

                // повече бронз
                if (B1 > B2 && (B2 - B1 > 11))
                {
                    int BtoS = (B1 - B2)/11;
                    S1 = S1 + BtoS;
                    B1 = B1 - BtoS * 11;
                    exchanges += BtoS;

                    continue;
                }

                // повече сребро
                if (S1 > S2)
                {
                    // преобразуване от сребро към злато
                    int StoG = (G2 - G1);
                    G1 = G1 + StoG;
                    S1 = S1 - StoG * 11;
                    exchanges += StoG;

                    int StoB = (S1 - S2);
                    B1 = B1 + StoB * 9;
                    S1 = S1 - StoB;
                    exchanges += StoB;

                    continue;
                }
            }

            return exchanges;
        }

    }
}
