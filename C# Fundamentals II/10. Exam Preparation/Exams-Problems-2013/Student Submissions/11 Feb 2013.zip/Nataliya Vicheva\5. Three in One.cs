using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string BlackjackPoints =Console.ReadLine();
            string BitesCake = Console.ReadLine();
            int F = int.Parse(Console.ReadLine());
            string Coins =Console.ReadLine();
            int indexWinner = 0;
            int sum = 0;
            for (int i = 0; i < BlackjackPoints.Length; i++)
            {

                if (BlackjackPoints[i] < 22 && BlackjackPoints[i] > BlackjackPoints[indexWinner])
                {
                    indexWinner = i;
                }
            }
            Console.WriteLine("The index of the winner is {0}.", indexWinner);
            //Array.Sort(BitesCake);
            for (int index = BitesCake.Length - 1; index >= 0; index = index - F)
            {
                sum += BitesCake[index];
            }
            Console.WriteLine("The total bites of cake I will get is {0}", sum);
            Console.WriteLine("I can't find the answer of the thirth task.");
        }
    }
}
