using System;
using System.Text;
//9Gag
class Program
{
    static void Main()
    {

        Console.WriteLine(-1);
        Console.WriteLine(42);
        Console.WriteLine(-1);
    }
}
