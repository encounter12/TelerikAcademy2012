using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Two
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());

        char[] separators = new char[] { ',', ' ' };

        int[][] jagged = new int[n][];
        bool[][] visited = new bool[1000][];

        for (int i = 0; i < n; i++)
        {
            string lineString = Console.ReadLine();

            string[] inputRow = lineString.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            int[] line = new int[inputRow.Length];

            for (int num = 0; num < inputRow.Length; num++)
            {
                line[num] = int.Parse(inputRow[num]);
            }
            visited[i] = new bool[inputRow.Length];
            jagged[i] = line;
        }

        int specialVal = 0;

        for (int i = 0; i < jagged[0].Length; i++)
        {
            int rowCount = 0;
            int col = i,

                maxSpecialVal = 0,
                steps = 0;
            specialVal = 0;


            while (true)
            {
                if (rowCount == jagged.Length)
                    rowCount = 0;

                if (jagged[rowCount][col] < 0)
                {
                    steps++;
                    specialVal = steps + Math.Abs(jagged[rowCount][col]);
                    break;
                }
                if (jagged[rowCount][jagged[rowCount][col]] < 0 & visited[rowCount][jagged[rowCount][col]] != true)
                {
                    specialVal = steps + Math.Abs(jagged[rowCount][jagged[rowCount][col]]) + 1;
                    break;
                }
                else if (visited[rowCount][jagged[rowCount][col]] == true)
                {
                    specialVal = steps + 1;
                    break;
                }
                else
                {
                    steps++;
                    col = jagged[rowCount][jagged[rowCount][col]];
                    break;
                }


                rowCount++;
            }
            if (specialVal > maxSpecialVal)
            {
                maxSpecialVal = specialVal;
            }
        }
        Console.WriteLine(specialVal + 1);







        //PrintJagg(n, jagged);


    }

    private static void PrintJagg(int n, int[][] jagged)
    {
        for (int row = 0; row < n; row++)
        {
            for (int col = 0; col < jagged[row].Length; col++)
            {
                Console.Write("{0} ", jagged[row][col]);
            }
            Console.WriteLine();
        }
    }
}