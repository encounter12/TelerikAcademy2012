using System;

class Program
{
    static void Sort(int[] array)
    {
        
        
    }
    static void Main()
    {
        //First Task input...
        string pointList = Console.ReadLine();
        //Second Task input...
        string cakeSizes = Console.ReadLine();
        int friends = int.Parse(Console.ReadLine());
        //Third Task input...
        string resourses = Console.ReadLine();

        //First Task Solution...

        string[] pointsArr = pointList.Split(',');
        int maxPoints = 0;
        int index = 0;
        if (pointsArr.Length < 50)
        {
            for (int i = 0; i < pointsArr.Length; i++)
            {
                if (int.Parse(pointsArr[i]) > 21 || int.Parse(pointsArr[i]) < 0)
                {
                    continue;
                }
                else
                {
                    if (int.Parse(pointsArr[i]) > maxPoints)
                    {
                        maxPoints = int.Parse(pointsArr[i]);
                        index = i;
                    }
                    else
                    {
                        if (int.Parse(pointsArr[i]) == maxPoints)
                        {
                            index = -1;
                        }
                    }
                }
            }
        }
        else
        {
            return;
        }
        Console.WriteLine(index);

        //Second Task Solution...

        string[] cakeSizesArr = cakeSizes.Split(',');
        int[] cakeSizesInt = new int[cakeSizesArr.Length];
        for (int i = 0; i < cakeSizesInt.Length; i++)
        {
            cakeSizesInt[i] = int.Parse(cakeSizesArr[i]);
        }
        //Sorting the array...
        for (int i = 0; i < cakeSizesInt.Length - 1; i++)
        {
            if (cakeSizesInt[i] > cakeSizesInt[i + 1])
            {
                cakeSizesInt[i + 1] = cakeSizesInt[i] + cakeSizesInt[i + 1];
                cakeSizesInt[i] = cakeSizesInt[i + 1] - cakeSizesInt[i];
                cakeSizesInt[i + 1] = cakeSizesInt[i + 1] - cakeSizesInt[i];

                if (i != 0)
                {
                    if (cakeSizesInt[i - 1] > cakeSizesInt[i])
                    {
                        i -= 2;

                    }
                }
                else
                {
                    continue;
                }
            }
            else
            {
                continue;
            }
        }
        int me = 0;
        for (int i = 0; i < cakeSizesInt.Length; i++)
        {
            if (friends < cakeSizesInt.Length)
            {
                me += cakeSizesInt[cakeSizesInt.Length - i - 1];
                i += friends;
            }
            else
            {
                me += cakeSizesInt[cakeSizesInt.Length - i - 1];
            }
        }
        Console.WriteLine(me);

        ////Third Task Solution...

        string[] resArr = resourses.Split(' ');
        int[] valuesInt = new int[resArr.Length];
        for (int i = 0; i < resArr.Length; i++)
        {
            valuesInt[i] = int.Parse(resArr[i]);
        }
        for (int i = 0; i < valuesInt.Length; i++)
        {
            if (valuesInt[0] < valuesInt[3])
            {
                while (valuesInt[0] < valuesInt[3])
                {
                    valuesInt[0] += 1;
                    valuesInt[1] -= 9;
                }
            }
            else if (valuesInt[1] < valuesInt[4])
            {
                while (valuesInt[1] < valuesInt[4])
                {
                    valuesInt[1] += 1;
                    valuesInt[2] -= 9;
                }
            }
            Console.WriteLine(i);
        }
    }
}