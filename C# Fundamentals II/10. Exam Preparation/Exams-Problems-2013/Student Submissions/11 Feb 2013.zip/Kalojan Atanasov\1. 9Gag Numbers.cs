using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            string number = Console.ReadLine();
           List< char> never = new List<char>(number.ToCharArray());
           List< int> ncounted = new List<int>();
            
           
           int count = 0;
           BigInteger sum=0;
            SortMethod(never, ncounted, number, count,ref sum);
            Console.WriteLine(sum);
        }

        private static BigInteger SortMethod(List<char> never, List<int> ncounted, string number, int count, ref BigInteger sum)
        {
            int i;
            for (i = number.Length; i > 0.1; )
            {
                
            
            if (never[0] == '-' && never[1] == '!')
            {
                ncounted.Add(0);
                never.Remove('-');
                never.Remove('!');
                i--;
                i--;
                count++;
                continue;
                
            }
            if (never[0] == '*' && never[1] == '*')
            {
                ncounted.Add(1);
                never.Remove('*');
                never.Remove('*');
                i--;
                i--;
                count++;
                continue;
               
            }
              
            if (never[0] == '!' && never[1] == '!' && never[2] == '!')
            {
                ncounted.Add(2);
                never.Remove('!');
                never.Remove('!');
                never.Remove('!');
                i--;
                i--;
                i--;
                count++;
                continue;
                
            }
            if (never[0] == '&' && never[1] == '&')
            {
                ncounted.Add(3);
                never.Remove('&');
                never.Remove('&');
                i--;
                i--;
                count++;
                continue;
               
            }
            if (never[0] == '&' && never[1] == '-')
            {
                ncounted.Add(4);
                never.Remove('&');
                never.Remove('-');
                i--;
                i--;
                count++;
                continue;
               
            }
            if (never[0] == '!' && never[1] == '-')
            {
                ncounted.Add(5);
                never.Remove('!');
                never.Remove('-');
                i--;
                i--;
                count++;
                continue;
                
            }
            if (never[0] == '*' && never[1] == '!' && never[2] == '!' && never[3] == '!')
            {
                ncounted.Add(6);
                never.Remove('*');
                never.Remove('!');
                never.Remove('!');
                never.Remove('!');
                i--;
                i--;
                i--;
                i--;
                count++;
                continue;
           
            }
            if (never[0] == '&' && never[1] == '*' && never[2] == '!')
            {
                ncounted.Add(7);
                never.Remove('&');
                never.Remove('*');
                never.Remove('!');
                i--;
                i--;
                i--;
                count++;
                continue;
                
            }
            if (never[0] == '!' && never[1] == '!' && never[2] == '*' && never[3] == '*' && never[4] == '!' && never[5] == '-')
            {
                ncounted.Add(8);
                never.Remove('!');
                never.Remove('!');
                never.Remove('*');
                never.Remove('*');
                never.Remove('!');
                never.Remove('-');
                i--;
                i--;
                i--;
                i--;
                i--;
                i--;
                count++;
                continue;
               
            }
                }

            BigInteger power = 1;
            for (int j = 0; j < count-1; j++)
            {
                power *= 9;
            }


          //  for (int j = 0; j < count; j++)
          //  {
          //     sum = sum + ncounted[j] * (BigInteger)Math.Pow(9, count-j-1);
          //  }
            for (int j = 0; j < count; j++)
                 {
                     if (count - j == 1)
                     { sum = sum + ncounted[j];
                     continue;
                     }
                   sum = sum + ncounted[j] * power;
                   power = power / 9;
                 }


            return sum; 
           
        }
                
         

			}
            
            
 
    

}
