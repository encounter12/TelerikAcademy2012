using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarkupLanguage
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] matrix = new string[n];
            for (int i = 0; i < n; i++)
            {
                matrix[i] = Console.ReadLine();
                string line = matrix[i];
                String line2 = line.Replace("<rev>", string.Empty);
                String line3 = line2.Replace("<rev/>", string.Empty);
                String line4 = line3.Replace("<lower>", string.Empty);
                String line5 = line4.Replace("<lower/>", string.Empty);
                matrix[i] = line5;
               
            }
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(matrix[i]);
            }
            
         


        }
    }
}
