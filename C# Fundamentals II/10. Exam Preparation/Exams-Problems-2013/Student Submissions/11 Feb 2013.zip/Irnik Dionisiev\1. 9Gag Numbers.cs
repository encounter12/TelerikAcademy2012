using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_st_task
{
    class Program
    {
        private static void numConverter(int[] numberAnswer, int[] numberBeforeConvert)
        {
            int[] oneDigitCalculateBefore = new int[numberAnswer.Length + 1];
            int[] oneDigitCalculateAfter = new int[numberAnswer.Length];
            for (int i = 0; i < numberAnswer.Length; i++)
            {
                oneDigitCalculateBefore[0] = numberBeforeConvert[i];
                for (int j = 0; j < numberAnswer.Length - (i + 1); j++)
                {
                    for (int k = 0; k < j + 1; k++)
                    {
                        oneDigitCalculateAfter[k + 1] += oneDigitCalculateBefore[k] - 1;
                        oneDigitCalculateBefore[k] = 10 - oneDigitCalculateBefore[k];
                    }
                    for (int k = 0; k < j + 2; k++)
                    {
                        oneDigitCalculateBefore[k] += oneDigitCalculateAfter[k];
                        oneDigitCalculateAfter[k] = 0;
                        oneDigitCalculateBefore[k + 1] += oneDigitCalculateBefore[k] / 10;
                        oneDigitCalculateBefore[k] %= 10;
                    }
                }
                for (int j = 0; j < numberAnswer.Length - 1; j++)
                {
                    numberAnswer[j] += oneDigitCalculateBefore[j];
                    oneDigitCalculateBefore[j] = 0;
                    numberAnswer[j + 1] += numberAnswer[j] / 10;
                    numberAnswer[j] %= 10;
                }
                numberAnswer[numberAnswer.Length - 1] += oneDigitCalculateBefore[numberAnswer.Length - 1];
                oneDigitCalculateBefore[numberAnswer.Length - 1] = 0;
            }
        }
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int[] numberBeforeConvert = new int[50];
            int numLen = 0;
            int iAdd = 1;
            for (int i = 0; i < input.Length; i+=iAdd)
            {
                iAdd = 2;
                switch (""+input[i]+input[i+1])
                {
                    case "-!": numberBeforeConvert[numLen] = 0; numLen++; break;
                    case "**": numberBeforeConvert[numLen] = 1; numLen++; break;
                    case "!!":
                        {
                            if (input[i + 2] == '!')
                            {
                                numberBeforeConvert[numLen] = 2; numLen++; iAdd = 3; break;
                            }
                            else if (input[i + 2] == '*')
                            {
                                numberBeforeConvert[numLen] = 8; numLen++; iAdd = 6; break;
                            }
                            break;
                        }
                    case "&&": numberBeforeConvert[numLen] = 3; numLen++; break;
                    case "&-": numberBeforeConvert[numLen] = 4; numLen++; break;
                    case "!-": numberBeforeConvert[numLen] = 5; numLen++; break;
                    case "*!": numberBeforeConvert[numLen] = 6; numLen++; iAdd = 4; break;
                    case "&*": numberBeforeConvert[numLen] = 7; numLen++; iAdd = 3; break;
                    default:
                        break;
                }
            }
            int[] numberAnswer = new int[numLen];
            numConverter(numberAnswer, numberBeforeConvert);
            bool isNotFirstTime = false;
            for (int i = numberAnswer.Length - 1; i >= 0; i--)
            {
                if (numberAnswer[i] != 0 || isNotFirstTime)
                {
                    Console.Write(numberAnswer[i]);
                    isNotFirstTime = true;
                }
            }
        }

    }
}