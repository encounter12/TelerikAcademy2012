using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kukata
{
    class Kukata
    {
        static void Main()
        {
            int[,] arr = {
                             {1, 2, 1},
                             {2, 0, 2}, 
                             {1, 2, 1}
                         };//new int[3, 3];

            int N = int.Parse(Console.ReadLine());
            int[] result = new int[N];
            

            for (int i = 0; i < N; i++)
            {
                string line = Console.ReadLine();
                int walk = 0;
                int x = 1;
                int y = 1;

                for (int j = 0; j < line.Length; j++)
                {
                    if (line[j] == 'W')
                    {
                        if (walk == 0)
                        {
                            y--;
                            if (y < 0)
                            {
                                y = 2;
                            }
                        }
                        else if (walk == 1)
                        {
                            x++;
                            if (x > 2)
                            {
                                x = 0;
                            }
                        }
                        else if (walk == 3)
                        {
                            x--;
                            if (x < 0)
                            {
                                x = 2;
                            }
                        }
                        else if (walk == 2)
                        {
                            y++;
                            if (y > 2)
                            {
                                y = 0;
                            }
                        }
                    }
                    else if (line[j] == 'L')
                    {
                        if (walk == 0)
                        {
                            
                            walk = 3;
                        }
                        else if (walk == 1)
                        {
                           
                            walk = 0;
                        }
                        else if (walk == 3)
                        {
                           
                            walk = 2;
                        }
                        else if (walk == 2)
                        {
                            
                            walk = 1;
                        }
                    }
                    else if (line[j] == 'R')
                    {
                        if (walk == 2)
                        {
                            
                            walk = 3;
                        }
                        else if (walk == 3)
                        {
                            
                            walk = 0;
                        }
                        else if (walk == 1)
                        {
                            
                            walk = 2;
                        }
                        else if (walk == 0)
                        {
                            
                            walk = 1;
                        }
                    }
                }
                //Console.WriteLine(line + "****" + x + "----" + y);
                result[i] = arr[x, y];
            }
           // Console.WriteLine();

            foreach (var item in result)
            {
                if (item == 0)
                {
                    Console.WriteLine("GREEN");
                }
                else if (item == 1)
                {
                    Console.WriteLine("RED");
                }
                else if (item == 2)
                {
                    Console.WriteLine("BLUE");
                }
            }
        }
    }
}
