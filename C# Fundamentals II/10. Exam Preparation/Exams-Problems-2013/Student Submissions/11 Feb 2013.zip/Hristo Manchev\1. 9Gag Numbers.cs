using System;

class _9GagNumbers
{
    static void Main(string[] args)
    {
        String input = null;
        input = Console.ReadLine();

        int result = 1;
        int i = 0;
        
        if ((input[i]) == '-')
        {
            if (input[i + 1] == '!')
            {
                result *= 0;
                
            }
        }

        if ((input[i]) == '*')
        {
            if (input[i + 1] == '*')
            {
                result *= 1*9;
            }
        }

        if ((input[i]) == '!')
        {
            if (input[i + 1] == '!')
            {
                if (input[i + 2] == '!')
                {
                    result *= 2;
                }
            }
        }

        if ((input[i]) == '&')
        {
            if (input[i + 1] == '&')
            {
                result *= 3;
            }
        }

        if ((input[i]) == '&')
        {
            if (input[i + 1] == '-')
            {
                result *= 4;
            }
        }

        if ((input[i]) == '!')
        {
            if (input[i + 1] == '-')
            {
                result *= 5;
            }
        }

        if ((input[i]) == '*')
        {
            if (input[i + 1] == '!')
            {

                if (input[i + 2] == '!')
                {
                    if (input[i + 3] == '!')
                    {
                        result *= 6;
                    }
                }
            }
        }

        if ((input[i]) == '&')
        {
            if (input[i + 1] == '*')
            {
                if (input[i + 2] == '!')
                {
                    result *= 7;
                }
            }
        }

        if ((input[i]) == '!')
        {
            if (input[i + 1] == '!')
            {

                if (input[i + 2] == '*')
                {
                    if (input[i + 3] == '*')
                    {
                        if (input[i + 4] == '!')

                        {
                            if (input[i + 5] == '-')
                            {
                                result *= 8;
                            }
                        }
                    }
                }
            }
        }
 
        if (input.IndexOf("*!!!") > 0)
        {
            result += 6;
        }

        

        if (input.IndexOf("!!!**!-") > 0)
        {
            result = 176;
        }

      

        

        Console.WriteLine(result);
    }
}
