using System.Text.RegularExpressions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace FakeTextMarkupLanguage
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number of lines");
            int lines = Console.Read();
            Console.WriteLine("Enter your text");
            string text = Console.ReadLine();

        }
    }
}
