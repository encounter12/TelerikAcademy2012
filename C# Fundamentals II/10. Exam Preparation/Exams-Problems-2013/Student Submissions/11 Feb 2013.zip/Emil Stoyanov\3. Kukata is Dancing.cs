using System;

class KukataIsDancing
{

    static char[,] Grid = new char[3, 3] { { 'R', 'B', 'R' }, { 'B', 'G', 'B' }, { 'R', 'B', 'R' } };

    enum Direction { UP, DOWN, LEFT, RIGHT };
    enum Turn { LEFT, RIGHT };

    static void Main()
    {
        int N = int.Parse(Console.ReadLine());

        for (int i = 0; i < N; i++)
        {
            Direction dir = Direction.UP;

            int x = 1;
            int y = 1;

            // Read sequence
            string line = Console.ReadLine();

            foreach (char ch in line)
            {
                switch (ch)
                {
                    case 'L':
                        dir = GetNextDirection(dir, Turn.LEFT);
                        break;
                    case 'R':
                        dir = GetNextDirection(dir, Turn.RIGHT);
                        break;
                    case 'W':
                        x = GetNextX(x, dir);
                        y = GetNextY(y, dir);
                        break;
                }
            }

            switch (Grid[x, y])
            {
                case 'R':
                    Console.WriteLine("RED");
                    break;
                case 'G':
                    Console.WriteLine("GREEN");
                    break;
                case 'B':
                    Console.WriteLine("BLUE");
                    break;
            }

        }
    }

    //
    static Direction GetNextDirection(Direction direction, Turn turn)
    {
        switch (direction)
        {
            case Direction.UP:
                return turn == Turn.LEFT ? Direction.LEFT : Direction.RIGHT;
                break;
            case Direction.DOWN:
                return turn == Turn.LEFT ? Direction.RIGHT : Direction.LEFT;
                break;
            case Direction.LEFT:
                return turn == Turn.LEFT ? Direction.DOWN : Direction.UP;
                break;
            case Direction.RIGHT:
                return turn == Turn.LEFT ? Direction.UP : Direction.DOWN;
                break;
        }
        return Direction.UP;
    }

    //
    static int GetNextX(int x, Direction direction)
    {
        switch (direction)
        {
            case Direction.LEFT:
                x = x == 0 ? 2 : x - 1;
                break;
            case Direction.RIGHT:
                x = x == 2 ? 0 : x + 1;
                break;
        }
        return x;
    }

    //
    static int GetNextY(int y, Direction direction)
    {
        switch (direction)
        {
            case Direction.UP:
                y = y == 0 ? 2 : y - 1;
                break;
            case Direction.DOWN:
                y = y == 2 ? 0 : y + 1;
                break;
        }
        return y;
    }

}
