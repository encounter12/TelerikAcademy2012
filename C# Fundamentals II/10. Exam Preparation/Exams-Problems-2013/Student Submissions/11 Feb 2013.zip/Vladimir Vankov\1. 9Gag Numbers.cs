using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskOne
{
    class TaskOne
    {
        static int NineDegree(int degreeIndicator)
        {
            int degreeSum = 1;
            for (int i = 1; i <= degreeIndicator; i++)
            {
                degreeSum = degreeSum * 9;
            }
            return degreeSum;
        }
        static int CalculatingRealNumber(List<int> normalNumbers)
        {
            int sum = 0;
            int counterAll = 0;
            int counter = 0;
            foreach (int i in normalNumbers)
            {
                counterAll++;
            }
            if (counterAll==1)
            {
                foreach (int i in normalNumbers)
                {
                    sum = sum + i;
                }
            }
            else
            {
                
                foreach (int i in normalNumbers)
                {
                    counter++;
                    sum = sum + i * NineDegree(counterAll - counter);
                    
                }
            }
            return sum;
        }
        static int RealNumber(string myString,string[] gagStyle)
        {
            string substring;
            string smallerString = myString;
            List<int> normalNumbers = new List<int>();
            int indexOfSubstring = 0;
            int length = myString.Length;
            
            for (int i = 0; i < gagStyle.Length; i++)
            {
                substring = gagStyle[i];
                int index=0;
                for (int j = 0; j < length; j++)
                {

                    int aqureanceOfNumber = smallerString.IndexOf(substring);
                    if (j == 0 && aqureanceOfNumber == 0)
                    {
                        if (substring.Length != smallerString.Length)
                        {
                            normalNumbers.Add(i);
                            index = substring.Length;
                            smallerString = smallerString.Substring(index, smallerString.Length - substring.Length);
                            length = smallerString.Length;
                            i = -1;
                            break;
                        }
                        else
                        {
                            normalNumbers.Add(i);
                            break;
                        }
                    }
                    
                }
               }
            int number = CalculatingRealNumber(normalNumbers);
            return number;
        }
        static void Main(string[] args)
        {

            string gagStyleNumber = Console.ReadLine();
            string[] gagStyle = new string[9] { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };
            int number = RealNumber(gagStyleNumber, gagStyle);
            Console.WriteLine(number);
        }
    }
}
