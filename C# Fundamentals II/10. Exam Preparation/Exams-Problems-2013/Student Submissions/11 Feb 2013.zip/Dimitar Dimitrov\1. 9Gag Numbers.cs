using System;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        // 1. 9Gag Numbers

        // Input
        string input = Console.ReadLine();

        // Solution
        string[] numbers9Gag = { "-!", "**", "!!!", "&&", "&-", "!-", "*!!!", "&*!", "!!**!-" };

        StringBuilder numberIn9 = new StringBuilder();
        for (int i = 0; i < input.Length; i++)
        {
            for (int j = 0; j < numbers9Gag.Length; j++)
            {
                if (input.IndexOf(numbers9Gag[j]) == 0)
                {
                    input = input.Substring(numbers9Gag[j].Length);
                    numberIn9.Append(j);
                    i = 0;
                    break;
                }
            } 
        }

        string finalNumberIn9 = numberIn9.ToString();
        long result = ConvertFromXToDec(finalNumberIn9, 9);
        Console.WriteLine(result);
    }

    private static long ConvertFromXToDec(string number, int baseFrom)
    {
        long result = 0;
        int power = 0;
        for (int i = number.Length - 1; i >= 0; i--)
        {
            long temp = ConvertCharToInt(number[i]);
            for (int j = 0; j < power; j++)
            {
                temp *= baseFrom;
            }
            result += temp;
            power++;
        }

        return result;
    }

    private static long ConvertCharToInt(char ch)
    {
        long result = 0;
        if (ch >= 'A')
        {
            result = ch - 'A' + 10;
        }
        else
        {
            result = long.Parse(ch.ToString());
        }

        return result;
    }
}