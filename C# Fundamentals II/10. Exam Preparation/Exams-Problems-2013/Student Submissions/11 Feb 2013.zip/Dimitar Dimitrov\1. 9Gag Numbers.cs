using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
class Program
{
    static void Main(string[] args)
    {
        string input =  Console.ReadLine();
        char[] inputArray = input.ToCharArray();
        string value ;
        string num = null ;

        StringBuilder digits = new StringBuilder();

        List<string> number = new List<string>();
        for (int i = 0; i < inputArray.Length; i++)
        {
            digits.Append(inputArray[i]);
            value = digits.ToString();
            if (value == "-!" || value == "**" || value == "!!!" || 
                value == "&&" || value == "&-" || value == "!-" || value == "*!!!" || value == "&*!" || value == "!!**!-")
            {
                if (value == "-!")
                {
                    num = "0";
                }
                if(value == "**")
                {
                    num = "1";
                }
                if(value == "!!!")
                {
                    num = "2";
                }
                if( value == "&&")
                {
                    num = "3";
                }
                if(value == "&-")
                {
                    num = "4";
                }
                if(value == "!-")
                {
                    num = "5";
                }
                if (value == "*!!!")
                {
                    num = "6";
                }
                if (value == "&*!")
                {
                    num = "7";
                }
                if (value == "!!**!-")
                {
                    num = "8";
                }

                number.Add(num);
                digits.Clear();
            }
        }

        BigInteger sum = 0;

        for (int j = 0; j < number.Count; j++)
        {
            sum = sum + BigInteger.Parse(number[j]) * (BigInteger)Math.Pow(9, (number.Count - 1) - j);
        }
        Console.WriteLine(sum);
    }
}