using System;

class KukataIsDancing
{
    static void Main()
    {
        int cubeSize = 3;
        string[,] cube = new string[cubeSize, cubeSize];
        cube[0, 0] = "RED";
        cube[0, 1] = "BLUE";
        cube[0, 2] = "RED";
        cube[1, 0] = "BLUE";
        cube[1, 1] = "GREEN";
        cube[1, 2] = "BLUE";
        cube[2, 0] = "RED";
        cube[2, 1] = "BLUE";
        cube[2, 2] = "RED";

        int dancesCount = int.Parse(Console.ReadLine());
        string[] dances = new string[dancesCount];
        for (int i = 0; i < dancesCount; i++)
        {
            dances[i] = Console.ReadLine();
        }
        for (int i = 0; i < dancesCount; i++)
        {
            Console.WriteLine(GetLastSquare(dances[i], cube));
        }

    }

    private static string GetLastSquare(string danceMoves, string[,] cube)
    {
        
        //for (int i = 0; i < cubeSize; i++)
        //{
        //    for (int j = 0; j < cubeSize; j++)
        //    {
        //        Console.Write("{0} ", cube[i,j]);
        //    }
        //    Console.WriteLine();
        //}
        const int up = 0;
        const int left = 1;
        const int right = 3;
        const int down = 2;
        int currX = 1, currY = 1;
        int direction = up;
        for (int i = 0; i < danceMoves.Length; i++)
        {
            if (danceMoves[i] == 'L')
            {
                direction++;
                if (direction > 3)
                {
                    direction = 0;
                }
            }
            else if (danceMoves[i] == 'R')
            {
                direction--;
                if (direction < 0)
                {
                    direction = 3;
                }
            }
            else
            {
                if (direction == up)
                {
                    currX--;
                    if (currX < 0)
                    {
                        currX = cube.GetLength(0) - 1;
                    }
                }
                else if (direction == left)
                {
                    currY--;
                    if (currY < 0)
                    {
                        currY = cube.GetLength(0) - 1;
                    }
                }
                else if (direction == down)
                {
                    currX++;
                    if (currX > cube.GetLength(0) - 1)
                    {
                        currX = 0;
                    }
                }
                else if (direction == right)
                {
                    currY++;
                    if (currY > cube.GetLength(0) - 1)
                    {
                        currY = 0;
                    }
                }
            }
        }
        return cube[currX, currY];
    }
}