using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task3
{
    class Program
    {
        static string Dancing(string moves)
        {
            string position = "GREEN";
            return position;  
        }
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            string[] dancingMoves = new string[N];
            for (int i = 0; i <dancingMoves.Length; i++)
            {
                dancingMoves[i] = Console.ReadLine();
            }

            string[,,] theCube =
                            {
                                  {
                                      {"RED","BLUE","RED"},
                                      {"BLUE","GREEN","BLUE"},
                                      {"RED","BLUE","RED"},
                                  },
                                  {
                                        {"BLUE","GREEN","BLUE"},
                                        {"GREEN","BLUE","GREEN"},
                                        {"BLUE","GREEN","BLUE"},
                                  },
                                  {
                                      {"RED","BLUE","RED"},
                                      {"BLUE","GREEN","BLUE"},
                                      {"RED","BLUE","RED"},
                                  },
                            };
            //Console.WriteLine("Starting position: {0}",theCube[0,1,1]);


            for (int i = 0; i < dancingMoves.Length; i++)
            {
                Console.WriteLine(Dancing(dancingMoves[i]));
            }
        }
    }
}
