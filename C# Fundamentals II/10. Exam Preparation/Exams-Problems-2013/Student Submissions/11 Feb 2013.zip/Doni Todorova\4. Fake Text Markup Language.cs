using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;


class Problem4_FTML
{

    public static string ReverseString(string s)
    {
        char[] arr = s.ToCharArray();
        Array.Reverse(arr);
        return new string(arr);
    }

    public static string ReverseChars(string s)
    {
        char[] arr = s.ToCharArray();
        foreach (var ch in arr)
        {
            if (char.IsLower(ch))
            {
                char.ToUpper(ch);
            }
            else
            {
                char.ToLower(ch);
            }
        }
        return new string(arr);
    }

    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string[] givenText = new string[n];
        for (int i = 0; i < n; i++)
        {
            givenText[i] = Console.ReadLine();
        }
        ;
        Console.WriteLine();

        //string[] givenText = {
        //                         "So<rev><upper>saw</upper> txet em</rev>", 
        //                         "<lower><upper>here</upper></lower>"

        //};

        string formatted = null;
        List<string> formattedText = new List<string>(givenText.Length);

        for (int i = 0; i < givenText.Length; i++)
        {
            if (givenText[i].IndexOf("<upper>") > 0)
            {
                if (givenText[i].IndexOf("<lower>") < 0)
                {
                    givenText[i] = Regex.Replace(givenText[i],
                        @"<upper>(.+?)</upper>",
                        m => m.Groups[1].Value.ToUpper());

                }

                if (givenText[i].IndexOf("<lower>") > 0)
                {
                    if (givenText[i].IndexOf("<upper>") < givenText[i].IndexOf("<lower>"))
                    {
                        givenText[i] = Regex.Replace(givenText[i],
                    @"<lower>(.+?)</lower>",
                    m => m.Groups[1].Value.ToLower());
                        givenText[i] = Regex.Replace(givenText[i],
        @"<upper>(.+?)</upper>",
        m => m.Groups[1].Value.ToUpper());
                    }
                    else
                    {
                        givenText[i] = Regex.Replace(givenText[i],
                        @"<upper>(.+?)</upper>",
                        m => m.Groups[1].Value.ToUpper());
                        givenText[i] = Regex.Replace(givenText[i],
                        @"<lower>(.+?)</lower>",
                        m => m.Groups[1].Value.ToLower());
                    }

                }
                else
                {
                    givenText[i] = Regex.Replace(givenText[i],
@"<upper>(.+?)</upper>",
m => m.Groups[1].Value.ToUpper());
                    givenText[i] = Regex.Replace(givenText[i],
                                         @"<lower>(.+?)</lower>",
                                         m => m.Groups[1].Value.ToLower());
                }

            }
            if (givenText[i].IndexOf("<rev>") > 0)
            {
                int start = givenText[i].IndexOf("<rev>");
                int end = givenText[i].IndexOf("</rev>");
                givenText[i] = Regex.Replace(givenText[i],
                 @"<rev>(.+?)</rev>",
                 m => m.Groups[1].Value);
                string rev = givenText[i].Substring(start, end - start - 5);
                //rev = givenText[i].Remove(start, end - start - 5);

                string ready = givenText[i].Replace(rev, ReverseString(rev));
                formattedText.Add(ready);

                givenText[i] = ready;
            }

            
            if (givenText[i].IndexOf("<toggle>") > 0)
            {
                int start = givenText[i].IndexOf("<toggle>");
                int end = givenText[i].IndexOf("</toggle>");
                givenText[i] = Regex.Replace(givenText[i],
                 @"<toggle>(.+?)</toggle>",
                 m => m.Groups[1].Value);
                string rev = givenText[i].Substring(start, end - start - 8);
                //rev = givenText[i].Remove(start, end - start - 5);

                string ready = givenText[i].Replace(rev, ReverseChars(rev));
            }



            else
            {

                formattedText.Add(givenText[i]);
            }
                

        }
        foreach (var item in formattedText)
        {
            Console.WriteLine(item);
        }
    }
}