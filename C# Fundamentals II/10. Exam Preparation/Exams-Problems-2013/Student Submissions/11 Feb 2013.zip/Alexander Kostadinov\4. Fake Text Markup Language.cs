using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

namespace Fake_Text_Markup_Language
{
    class Program
    {
        static void Main(string[] args)
        {
            int linesCount = int.Parse(Console.ReadLine());
            StringBuilder code = new StringBuilder();

            for (int i = 1; i <= linesCount; i++)
            {
                string line = Console.ReadLine();
                for (int j = 0; j < line.Length; j++)
                {

                    Console.WriteLine(Regex.Replace(line, "<upper>(.*?)</upper>", m => m.Groups[1].Value.ToUpper()));
                    Console.WriteLine(Regex.Replace(line, "<lower>(.*?)</lower>", m => m.Groups[1].Value.ToUpper()));

                    string matchCodeTagDel = @"\<del\>(.*?)\</del\>";
                    string replaceWith = "";
                    string output = Regex.Replace(line, matchCodeTagDel, replaceWith);
                    Console.WriteLine(output);
                

                    
                }
            }
        }
    }
}
