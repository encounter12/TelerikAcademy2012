using System;

class TheHook
{
    static string Moves(char[] dance_moves)
    {
        char W = 'W';
        char L = 'L';
        char R = 'R';
        string[,] cube_side = { 
                                  {"RED" , "BLUE" , "RED"},
                                  {"BLUE", "GREEN", "BLUE"},
                                  {"RED" , "BLUE" , "RED"}
                              };
        int positionX = 1;
        int positionY = 1;
        int rotation = 0; 
        for (int i = 0; i < dance_moves.Length; i++)
        {
            ///////////////////////////////////// movement
            if (dance_moves[i] == W)
            {
                //////////////////////back forward
                if (rotation == 0 )
                {
                    positionX += 1;
                }
                if (rotation == 1 || rotation == -3)
                {
                    positionY += 1;
                }
                if (rotation == 2 || rotation == -2)
                {
                    positionX += -1 ; 
                }
                if (rotation == 3 || rotation == -1)
                {
                    positionY += -1 ; 
                }

                ///////////////////////edge of cube
                if (positionX != 0 && positionX !=1 && positionX != 2)
                {
                    if (positionX == 3)
                    {
                        positionX = 0;
                    }
                    else
                    {
                        positionX = 2;
                    }
                }
                if (positionY != 0 && positionY != 1 && positionY != 2)
                {
                    if (positionY == 3)
                    {
                        positionY = 0;
                    }
                    else
                    {
                        positionY = 2;
                    }
                }
            }
            ////////////////////////////////////////////////rotation
            if (dance_moves[i] == L)
            {
                rotation += 1;
                if (rotation == 4)
                    rotation = 0;
            }
            if (dance_moves[i] == R)
            {
                rotation += -1;
                if (rotation == -4)
                    rotation = 0;
            }
        }

        return cube_side[positionX,positionY] ;
        
    }



    static char[] InPutMoves()
    {
        string moves = Console.ReadLine();
        char[] dance_moves = new char[50];
        dance_moves = moves.ToCharArray();
        return dance_moves; 
    }
    static void Main()
    {
        int dances = int.Parse(Console.ReadLine());
        string[] finishes = new string[10];

        for (int i = 0; i < dances; i++)
        {
            char[] dance_moves= InPutMoves();
            finishes[i] = Moves(dance_moves);
        }
        for (int i = 0; i < dances; i++)
        {
            Console.WriteLine(finishes[i]);
        }
        
    }
}