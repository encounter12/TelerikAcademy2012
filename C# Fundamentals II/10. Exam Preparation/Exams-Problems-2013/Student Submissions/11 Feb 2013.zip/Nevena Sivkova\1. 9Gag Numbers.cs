using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

class Program
{
    static string input;
    static List<int> digits = new List<int>();

    static void Main()
    {
        ReadInput();
        TextToDigits(input);
        WriteOutput();
    }

    static void ReadInput()
    {
        input = Console.ReadLine();
    }

    static void WriteOutput()
    {
        if (input.Length == 0)
        {
            Console.WriteLine("");
            return;
        }

        long result = 0;
        long numberBase = 1;
        for (int index = digits.Count - 1; index >= 0 ; index--)
        {
            result += digits[index] * numberBase;
            numberBase *= 9;
        }

        Console.WriteLine(result);
    }

    static string DigitAsString(int pDigit)
    {
        switch (pDigit)
        {
            case 0: return "-!";
            case 1: return "**";
            case 2: return "!!!";
            case 3: return "&&";
            case 4: return "&-";
            case 5: return "!-";
            case 6: return "*!!!";
            case 7: return "&*!";
            case 8: return "!!**!-";
            default: throw new ArgumentException("Invalid Digit");
        }
    }

    static void TextToDigits(string text)
    {
        StringBuilder gagNumbers = new StringBuilder(text);
        int startIndex = 0;
        while (gagNumbers.Length > 0)
        {
            for (int i = 0; i < 9; i++)
            {
                string gagNumber = DigitAsString(i);
                if (text.IndexOf(gagNumber, startIndex) == startIndex)
                {
                    digits.Add(i);
                    gagNumbers.Remove(0, gagNumber.Length);
                    startIndex += gagNumber.Length;
                    break;
                }
            }
        }
    }
}

