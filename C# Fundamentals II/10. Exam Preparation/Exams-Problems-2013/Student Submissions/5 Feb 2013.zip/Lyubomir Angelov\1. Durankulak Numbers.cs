using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// The name of the task is: Durankulak numbers
class Problem1
{
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("input"));
#endif
        string input = Console.ReadLine();
        ulong number = CalcDuranNUmber(DurnakNumberSeries(PlainDurNumber(input)));
        Console.WriteLine(number);
    }
    static List<ulong> PlainDurNumber(string source)
    {
        List<ulong> plainDurNumbers = new List<ulong>();

        for (int i = 0; i < source.Length; i++)
        {
            if (i == 0 && ((int)source[0] >= 65 && (int)source[0] <= 90))
            {
                plainDurNumbers.Add((ulong)((int)source[i] - 65));
            }
            else if ((int)source[i] >= 65 && (int)source[i] <= 90)
            {
                plainDurNumbers.Add((ulong)((int)source[i] - 65));
            }
            else
            {
                ulong bignum = 0;
                switch ((int)source[i])
                {
                    case 97:
                        bignum = 26;
                        break;
                    case 98:
                        bignum = 52;
                        break;
                    case 99:
                        bignum = 78;
                        break;
                    case 100:
                        bignum = 104;
                        break;
                    case 101:
                        bignum = 130;
                        break;
                    case 102:
                        bignum = 156;
                        break;

                    default:
                        break;
                }
                plainDurNumbers.Add((ulong)((ulong)bignum + (ulong)((int)source[i+1] - 65)));
                i++;
            }
        }
        return plainDurNumbers;
    }
    static List<ulong> DurnakNumberSeries(List<ulong> input)
    {
        ulong multiply = 1;
        for (int i = input.Count - 1; i >= 0; i--)
        {
            input[i] = input[i] * multiply;
            multiply = multiply * 168;
        }
        return input;
    }
    static ulong CalcDuranNUmber(List<ulong> number)
    {
        ulong result = 0;
        for (int i = 0; i < number.Count; i++)
        {
            result = result + number[i];
        }
        return result;
    }
}
