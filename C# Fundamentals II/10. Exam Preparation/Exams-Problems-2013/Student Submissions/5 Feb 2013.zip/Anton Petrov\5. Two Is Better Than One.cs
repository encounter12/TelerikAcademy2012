using System;
using System.Numerics;

class TwoIsBetterThanOne
{
    static void Main()
    {
        //first task
        BigInteger startLucky;
        BigInteger endLucky;
        string inputStr = Console.ReadLine();
        string[] numbers = inputStr.Split(' ');
        startLucky = BigInteger.Parse(numbers[0]);
        endLucky = BigInteger.Parse(numbers[1]);
        int countLucky = 0;
        for (BigInteger tempNumber = startLucky; tempNumber <= endLucky; tempNumber++)
        {
            if (tempNumber.ToString()[0] == '3' || tempNumber.ToString()[0] == '5')
            {
                if (IsLuckyPalindrome(tempNumber)) countLucky++;
            }
            
        }
        //second task
        string[] inputStr2 = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
        int[] numbers2 = new int[inputStr2.Length];
        for (int i = 0; i < inputStr2.Length; i++)
        {
            numbers2[i] = int.Parse(inputStr2[i]);
        }
        Array.Sort(numbers2);
        int percentile = int.Parse(Console.ReadLine());
        double percCalc = ((double)(numbers2.Length * (double)percentile) / 100);
        int limit = ((percCalc - (int)(percCalc)) > 0) ? (int)(percCalc) + 1 : (int)(percCalc);

        //print first task result
        Console.WriteLine(countLucky);

        //print second task result
        Console.WriteLine(numbers2[limit - 1]);
    }

    private static bool IsLuckyPalindrome(BigInteger tempNumber)
    {
        string tempStr = tempNumber.ToString();
        for (int i = 0; i < tempStr.Length; i++)
        {
            if (!(tempStr[i] == '3' || (tempStr[i] == '5')))
            {
                return false;
            }
            if (tempStr[i] != tempStr[tempStr.Length - i -1])
            {
                return false;
            }
            
        }        
        return true;           
        
        //if (tempNumber == 0) return false;
        //while (tempNumber > 0)
        //{
        //    if (!(tempNumber % 10 == 3 || tempNumber % 10 == 5))
        //    {
        //        return false;
        //    }
        //    else tempNumber /= 10;
        //}
        //return true;
    }
    //private static bool IsPalindrome(BigInteger tempNumber)
    //{
    //    BigInteger reverse = BigInteger.Parse(ReverseString(tempNumber.ToString()));
    //    if ((tempNumber ^ reverse) == 0) return true;
    //    else return false;
    //}
    //public static string ReverseString(string s)
    //{
    //    char[] arr = s.ToCharArray();
    //    Array.Reverse(arr);
    //    return new string(arr);
    //}
}