using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class DurankulakNumbers
{
    
    static char[] alphabet = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
    private static char[] delim = { ' ', '.', ',' };

    static long PowerNum(int pow) 
    {
        long result = 1;
        for (int i = 0; i < pow; i++)
        {
            result *= 168;
        }
        return result;
    }

    static void Main(string[] args)
    {
        StringBuilder str = new StringBuilder();
        List<string> list = new List<string>();
        Array.Sort(alphabet);
        String txt = Console.ReadLine().Trim();

        string[] array = txt.Split(delim, StringSplitOptions.RemoveEmptyEntries);
        
        for (int i = 0; i < array.Length; i++)
        {
            str.Append(array[i]);
        }
        txt = str.ToString();
        long sum = 0;
        int pow = 0;
        
        if (txt.Length == 1) Console.WriteLine(Array.BinarySearch(alphabet, char.ToLower(txt[0])));
        else
        {
            for (int i = 0; i < txt.Length; i++)
            {
                if (char.IsLower(txt[i]))
                {
                    list.Add(txt[i] + "" + txt[i + 1]);
                    i++;
                }
                else if (char.IsUpper(txt[i])) list.Add(txt[i].ToString());
            }

            for (int i = list.Count - 1; i >= 0; i--)
            {

                if (list[i].Length == 2)
                {
                    char ch = list[i][0];
                    char cha = char.ToLower(list[i][1]);
                    int ll = (((Array.BinarySearch(alphabet, ch) + 1) * 26)) + Array.BinarySearch(alphabet, cha);
                    sum += (PowerNum(pow) * (long)ll);
                    pow++;
                }
                else if (list[i].Length == 1)
                {
                    char ch = char.ToLower(list[i][0]);
                    sum += (PowerNum(pow) * (long)(Array.BinarySearch(alphabet, ch)));
                    pow++;
                }

            }
            Console.WriteLine(sum);
        }
    }
}
