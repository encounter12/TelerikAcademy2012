using System;

namespace _5.Lucky_Numbers
{
    class Program
    {
        static void Main()
        {
            string inputLucky = Console.ReadLine();
            string[] inputLuckyToNums = inputLucky.Split(' ');
            int A = int.Parse(inputLuckyToNums[0]);
            int B = int.Parse(inputLuckyToNums[1]);

            string input = Console.ReadLine();
            string[] inputToString = input.Split(' ', ',');
            int[] inputToNums = new int[inputToString.Length];
            decimal percentile = decimal.Parse(Console.ReadLine());
            decimal percentage_double = (percentile / 100) * (decimal)inputToNums.Length;

            int percentage = (int)(Math.Round(percentage_double));

            for (int i = 0; i < inputToString.Length; i++)
            {
                inputToNums[i] = int.Parse(inputToString[i]);
            }

            Array.Sort(inputToNums);

            int counter = 0;
            for (int Number = A; Number <= B; Number++)
            {
                string numberToString = Number.ToString();
                char[] numberToCharArray = numberToString.ToCharArray();
                bool result = false;
                for (int i = 0; i <= (numberToCharArray.Length - 1) / 2; i++)
                {
                    if (numberToCharArray[i] == numberToCharArray[numberToCharArray.Length - 1 - i] && (numberToCharArray[i] == '3' || numberToCharArray[i] == '5'))
                    {
                        result = true;
                        continue;
                    }
                    else
                    {
                        result = false;
                        break;
                    }
                }
                if (result == true)
                {
                    counter++;
                }
                else
                {
                    continue;
                }
            }
            Console.WriteLine(counter);
            Console.WriteLine(inputToNums[percentage - 1]);
        }
    }
}
  