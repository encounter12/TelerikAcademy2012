using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main()
    {
        string AandB = Console.ReadLine();
        string List = Console.ReadLine();
        int P = int.Parse(Console.ReadLine());
        if (P % 10 > 0)
        {
            P = ((P / 10) + 1) * 10;
        }
        string[] AB = AandB.Split(' ');
        int A = int.Parse(AB[0]);
        long B = long.Parse(AB[1]);
        string[] listNumbers = List.Split(',');
        int[] array = new int[listNumbers.Length];
        int minValue = int.MaxValue;
        int maxValue = int.MinValue;
        for (int i = 0; i < listNumbers.Length; i++)
        {
            array[i] = int.Parse(listNumbers[i]);
            if (array[i] > maxValue)
            {
                maxValue = array[i];
            }
            if (array[i] < minValue)
            {
                minValue = array[i];
            }
        }
        
        int counterLucky = 0;
        for (int i = A; i <= B; i++)
        {
            bool IsLucky = true;
            long number = i;
            int digit = 0;
            while (IsLucky)
            { 
                digit = (int)(number % 10);
                if (digit != 3 && digit != 5)
                {
                    IsLucky = false;
                    break;
                }
                number /= 10;
                if (number < 1)
                {
                    break;
                }
            }
            if (IsLucky)
            {
                for (int j = 0; j < i.ToString().Length; j++)
                {
                    number = i;
                    digit = (int)(number % 10);
                    number = number / 10 + (long)(digit * Math.Pow(10, (i.ToString().Length - 1)));

                }
                if (number == i || i < 10)
                {
                    counterLucky++;
                }
            }
        }

        int E = (listNumbers.Length * P) / 100;
        Array.Sort(array);
        int middle = (minValue + maxValue) / 2;
        int element = 0;
        while (true)
        {
            element = array[Array.BinarySearch(array, middle)];
            int elementsCounter = 0;
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == element)
                {
                    elementsCounter++;
                    break;
                }
                else
                {
                    elementsCounter++;
                }
            }
            if (elementsCounter == E)
            {
                break;
            }
            else if(elementsCounter > E)
            {
                middle = (element + minValue) / 2;
                maxValue = element;
            }
            else 
            {
                middle = (element + maxValue) / 2;
                minValue = element;
            }
        }
        Console.WriteLine(counterLucky);
        Console.WriteLine(element);
    }
}
