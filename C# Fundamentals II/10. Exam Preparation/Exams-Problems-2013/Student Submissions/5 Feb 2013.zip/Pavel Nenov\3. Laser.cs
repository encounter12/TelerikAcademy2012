using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laser
{
    class Program
    {
        static int width, height, depth;

        static void Main()
        {

            string[] dimentions = Console.ReadLine().Split(' ');
            width = int.Parse(dimentions[0]);
            height = int.Parse(dimentions[1]);
            depth = int.Parse(dimentions[2]);
            int[, ,] cube = new int[width, height, depth];
            bool[, ,] isVisited = new bool[width, height, depth];
            string[] startPosition = Console.ReadLine().Split(' ');
            int startW = int.Parse(startPosition[0]);
            int startH = int.Parse(startPosition[1]);
            int startD = int.Parse(startPosition[2]);
            string[] startDirection = Console.ReadLine().Split(' ');
            int dirW = int.Parse(startDirection[0]);
            int dirH = int.Parse(startDirection[1]);
            int dirD = int.Parse(startDirection[2]);

            int curPosition = cube[startW, startH, startD];
            int curWidth = startW;
            int curHeight = startH;
            int curDepth = startD;

                while (true)
                {
                    //if (isVisited[curWidth, curHeight, curDepth] == true || curWidth == 0 ||
                    //     curHeight == 0 || curDepth == 0 || curWidth == cube.GetLength(0) ||
                    //    curHeight == cube.GetLength(1) || curDepth == cube.GetLength(2))
                    if (isVisited[curWidth, curHeight, curDepth] == true)
                    {
                        Console.WriteLine("{0} {1} {2}",curWidth,curHeight,curDepth);
                        break;
                    }
                    else 
                    {
                        isVisited[curWidth, curHeight, curDepth] = true;
                        curWidth += dirW;
                        curHeight += dirH;
                        curDepth += dirD;
                        if (curWidth == cube.GetLength(0) - 1)
                        {
                            dirW = -1;
                        }
                        if (curWidth == 1)
                        {
                            dirW = 1;
                        }
                        if (curHeight == cube.GetLength(1) - 1)
                        {
                            dirH = -1;
                        }
                        if (curHeight == 1)
                        {
                            dirH = 1;
                        }
                        if (curDepth == cube.GetLength(2) - 1)
                        {
                            dirD = -1;
                        }
                            if (curDepth == 1)
                        {
                            dirD = 1;
                        }
                    }
                }                        
   

        }
    }
}
