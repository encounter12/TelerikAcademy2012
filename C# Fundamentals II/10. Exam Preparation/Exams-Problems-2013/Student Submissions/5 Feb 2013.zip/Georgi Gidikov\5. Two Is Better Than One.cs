using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        int A = int.Parse(Console.Readline());
        int B = int.Parse(Console.Readline());
        int rev = 0;
        int digit = 0;
        for (int i = A; i < B; i++)
        {

            digit = i % 10;
            rev = rev * 10 + digit;
            i /= 10;

            if (i == rev)
            {
                Console.WriteLine(rev);
            }
        }
    }
}


 