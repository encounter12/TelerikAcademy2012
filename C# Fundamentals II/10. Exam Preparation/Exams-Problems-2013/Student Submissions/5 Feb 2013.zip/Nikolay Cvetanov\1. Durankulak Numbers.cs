using System;

class Durankulak
{
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
#endif

        string input = Console.ReadLine();
        int len = input.Length;
        int[] values = new int[len];
        for (int i = 0; i < len; i++)
        {
            values[i] = -1;
        }

        int counter = 0;
        for (int i = 0; i < len; i++)
        {
            
            if (input[i] - 96 >=1 && input[i] - 96 <=26)
            {
                values[counter] = ConvertToTable(input[i], input[i+1]);
                i++;
                counter++;
            }
            else
            {
                values[counter] = ConvertUpper(input[i]);
                counter++;
            }    
        }

        int newLen = 0;
        for (int i = 0; values[i] != -1; i++)
        {
            newLen++;
            if (i == values.Length - 1)
            {
                break;
            }
        }
        int[] clearJob = new int[newLen];


        for (int i = 0; i < newLen; i++)
        {
            clearJob[i] = values[i];
        }

        long finalSum = 0;
        int wtfCountr = newLen - 1;
        for (int i = 0; i < newLen; i++)
        {
            if (wtfCountr < 0)
            {
                break;
            }
            finalSum += Power(168, i) * clearJob[wtfCountr];
            wtfCountr--;

        }

        Console.WriteLine(finalSum);
    }

    static long Power(int number, int power)
    {
        long result = number;
        if (power == 0)
        {
            return 1;
        }
        for (int i = 1; i < power; i++)
        {
            result *= number;
        }
        return result;
    }

    static int ConvertToTable(char lowerCase, char upperCase)
    {
        int result = 0;
        int intLowerCase;
        int intUpperCase;

        intUpperCase = upperCase - 65;
        intLowerCase = lowerCase - 96;

        result += (int)Power(26, 0) * intUpperCase;
        result += (int)Power(26, 1) * intLowerCase;

        return result;
    }

    static int ConvertUpper(char upperCase)
    {
        int result = 0;
        int intUpperCase;
        intUpperCase = upperCase - 65;
        result += (int)Power(26, 0) * intUpperCase;
        return result;
    }
}
