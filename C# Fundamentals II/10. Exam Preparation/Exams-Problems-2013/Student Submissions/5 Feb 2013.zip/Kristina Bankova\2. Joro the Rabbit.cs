using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Jumps
{
    public int index { get;set; }
    public int value { get; set; }
}

class JoroTheRabbit
{
    static void Main()
    {
        string numbersStr = Console.ReadLine();
        string[] numbersSplit = numbersStr.Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
        int[] num = new int[numbersSplit.Length];
        int[,] numMatrix=new int[num.Length,num.Length];
        int[] sorted = num.Clone() as int[];
        int min = int.MaxValue;
        int indexMin = -1;
        int countJumps = 0;
        int countBigger = 0;
        bool[] isVisited = new bool[num.Length];


        for (int i = 0; i < num.Length; i++)
        {
            num[i] = int.Parse(numbersSplit[i]);

        }
        for (int i = 0; i < num.Length; i++)
        {
            if (i+1<num.Length&&num[i]>num[i+1])
            {
                countJumps++;
            }
        }

        Console.WriteLine(countJumps);
    }
}

