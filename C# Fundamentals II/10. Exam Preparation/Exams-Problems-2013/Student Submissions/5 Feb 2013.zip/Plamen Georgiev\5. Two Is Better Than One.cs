using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    public static string Reverse(string text)
    {
        char[] cArray = text.ToCharArray();
        string reverse = String.Empty;
        for (int i = cArray.Length - 1; i > -1; i--)
        {
            reverse += cArray[i];
        }
        return reverse;
    }
    static void Main()
    {
        string numberAandB = Console.ReadLine();
        string listOfNums = Console.ReadLine();
        double percentile = double.Parse(Console.ReadLine());
        string[] AandB = numberAandB.Split(' ');
        int a = int.Parse(AandB[0]);
        int b = int.Parse(AandB[1]);
        string temp = "";
        int count = 0;
        bool isTrue = true;
        for (int i = a; i <= b; i++)
        {
            temp = i.ToString();
            string temp1 = Reverse(temp);
            for (int j = 0; j < temp.Length; j++)
            {
                isTrue = true;
                if ((temp[j] == temp1[j]) && ((temp[j] == '3') || (temp[j] == '5')))
                {
                    continue;
                }
                else
                {
                    isTrue = false;
                }
            }
            if (isTrue == true)
            {
                count++;
            }

        }
        Console.WriteLine(count);
        string[] elements = listOfNums.Split(',');
        int[] numbers = new int[elements.Length];
        for (int i = 0; i < elements.Length; i++)
        {
            numbers[i] = int.Parse(elements[i]);
        }
        int lesser = 0;
        List<int> myList = new List<int>();
        for (int i = 0; i < numbers.Length; i++)
        {
            for (int j = 0; j < numbers.Length; j++)
            {
                if (numbers[j]<=numbers[i])
	            {
                    lesser++; 
	            }

            }
            if (lesser>=(numbers.Length*(percentile/100)))
            {
                myList.Add(numbers[i]);
            }
            lesser = 0;
        }
        int min = myList.Min();
        Console.WriteLine(min);
    }
}
