using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TESTS
{
    class Program
    {
        static int[] inputInt;
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split();
            int w = int.Parse(input[0].Trim());
            int h = int.Parse(input[1].Trim());
            int d = int.Parse(input[2].Trim());

            Console.WriteLine("{0} {1} {2}", w - 1, h - 1, d - 1);
        }
    }
}
