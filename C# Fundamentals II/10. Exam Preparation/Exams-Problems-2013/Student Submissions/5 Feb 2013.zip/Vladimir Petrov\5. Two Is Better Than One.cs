using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
class TwoIsBetter
{
   static void Main(string[] args)
    {
        string input = Console.ReadLine();
        Console.WriteLine(GetLuckyNumbers(input));
        string percentileCalculation = Console.ReadLine();
        int percentage = int.Parse(Console.ReadLine());
        Console.WriteLine(GetLowestElementByGivenPercentage(percentileCalculation, percentage));
   
        }
   
   private static int GetLowestElementByGivenPercentage(string percentileCalculation, int percentage)
   {
       string[] ArrayToFindAverage = percentileCalculation.Split(',');
       int[] ArrayToFindAverageInt = new int[ArrayToFindAverage.Length];
       for (int i = 0; i < ArrayToFindAverage.Length; i++)
       {
           ArrayToFindAverageInt[i] = int.Parse(ArrayToFindAverage[i]);
       }
       int length = ArrayToFindAverageInt.Length;
       int count = (int)Math.Round((double)(length * percentage) / 100);
       Array.Sort(ArrayToFindAverageInt);
       return ArrayToFindAverageInt[count-1];
   }
   public static string ReverseString(string s)
   {
       char[] arr = s.ToCharArray();
       Array.Reverse(arr);
       return new string(arr);
   }
    private static int GetLuckyNumbers(string input)
    {
           
        string[] splitInput = input.Split(' ');
        BigInteger startValue = BigInteger.Parse(splitInput[0]);
        BigInteger endValue = BigInteger.Parse(splitInput[1]);
        int count = 0;
        for (BigInteger i = startValue; i <= endValue; i++)
        {
            string j = i.ToString();
            if (j.StartsWith("3") && j == ReverseString(j))
                {
                count++;
                }
            if (j.StartsWith("5") && j == ReverseString(j))
                {
                count++;
                }
        }
        return count;
    }
    }