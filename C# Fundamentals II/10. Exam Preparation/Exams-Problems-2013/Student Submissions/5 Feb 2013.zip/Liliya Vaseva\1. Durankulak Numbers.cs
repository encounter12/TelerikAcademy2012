using System;
using System.Text;
using System.Text.RegularExpressions;

class DurankulakNum
{
    static void Main()
    {
        Console.WriteLine("Enter a Durankulak-style \"number\":");
        string columnName = Console.ReadLine();

        Split(columnName);
    }

    private const string letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";


    public static int Parse(string s)
    {
        int result;
        if (!TryParse(s, out result))
            throw new ArgumentException();
        return result;
    }
    public static bool TryParse(string s, out int result)
    {
      
        s = s.Trim().ToUpper();

        int pos = 0;
        result = 0;

       
        while (pos < s.Length && !Char.IsWhiteSpace(s[pos]))
        {
            if (pos > 0)
                result++;

            string digit = s.Substring(pos, 1);
            int i = letters.IndexOf(digit);
            if (i >= 0)
            {
                result *= letters.Length;
                result += i;
                pos++;
            }
            else
            {
               
                return false;
            }
        }
      
        return (pos > 0);
    }
    static void Split(string cn)
    {
        string number;

        Regex regex = new Regex("");
        string[] substring = regex.Split(cn);
        for (int i = 0; i < 2 ; i++)
        {
            number = substring[i];
           Console.WriteLine(number);
            
        }
        
    }

}