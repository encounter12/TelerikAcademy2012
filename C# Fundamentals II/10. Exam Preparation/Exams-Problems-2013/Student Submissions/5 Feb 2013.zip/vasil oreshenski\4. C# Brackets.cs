using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main()
        {
            int n;
            string format;

            string format2=string.Empty;

            n=int.Parse(Console.ReadLine());
            format = Console.ReadLine();
            string[] input = new string[n];
            List<string> final = new List<string>();
            List<string> finalFinal = new List<string>();
            string sentance;
            int empty = 0;
            int y = 0;
            bool mali = true;
            bool eh = true;
            int dali = 0;
            int countFormat = 0;
            bool dabe = false;
            int stiga = 0;
            bool nevqrvam = false;


            StringBuilder inputNoMore = new StringBuilder();

            for (int i = 0; i < n; i++)
            {
                input[i]=Console.ReadLine();
            }


            for (int i = 0; i < input.Length; i++)
            {
                //Console.WriteLine(i);
                if (mali)
                {
                    y = 0;
                   // mali = true;
                }
                sentance = input[i].Trim();
                for (; y < sentance.Length; y++)
                {
                    if (sentance[y] == ' ')
                    {
                        empty++;
                    }
                    else
                    {
                        empty = 0;
                    }
                    if (empty <= 1)
                    {
                        for (int z = 0; z < countFormat; z++)
                        {
                            if(y>=1)
                            if (eh && sentance[y-1] != '}')
                            {

                                inputNoMore.Append(format);
                            }
                            if (y >= 1 && y <= sentance.Length - 2)
                                if (sentance[y] == '{' && sentance[y - 1] > ' ' && sentance[y + 1] > ' ')
                                {

                                    dabe = true;
                                    stiga++;
                                }


                            if (y >= 1)
                                if (sentance[y] == '}' && sentance[y - 1] > ' ')
                                {

                                    nevqrvam = true;
                                    stiga++;
                                }


                        }
                        //if(y>=1)
                        //if (sentance[y-1]>' ')
                        {
                            if (y >= 1)
                            {
                                if (sentance[y] != '{' && sentance[y]!='}')
                                    inputNoMore.Append(sentance[y]);

                            }

                            else
                            {
                                if (y == 0)
                                {
                                    if (sentance[y] == '{')
                                        if (y == 0)
                                        {
                                            for (int k = 0; k < countFormat; k++)
                                            {
                                                inputNoMore.Append(format);
                                            }

                                        }
                                    if (sentance[y] == '}')
                                        if (y == 0)
                                        {
                                            for (int k = 0; k < countFormat-1; k++)
                                            {
                                                inputNoMore.Append(format);
                                            }

                                        }
                                        inputNoMore.Append(sentance[y]);
                                }
                            }
                        }

                        eh = false;
                        if (sentance[y] == '{' || sentance[y] == '}')
                        {
                            if (sentance[y] == '{')
                            {
                                countFormat++;
                               
                                
                            }
                            if (sentance[y] == '}')
                            {
                                countFormat--;
                                if (y == 0)
                                {
                                    //for (int k = 0; k < countFormat; k++)
                                    {
                                        //inputNoMore.Append(format);
                                    }

                                }
                                
                                //inputNoMore.Append(sentance[y]);
                            }
                            dali = 0;
                            i--;
                            mali = false;
                            y++;
                            dali++;
                            break;

                        }


                    }
                }
                if (dali == 2)
                {
                    mali = true;
                    
                }

               
                final.Add(inputNoMore.ToString());
                if (dabe)
                {
                    for (int h = 0; h < countFormat-1; h++)
                    {
                        format2 = format2 + format;
                    }
                    final.Add(format2+"{");
                    format2 = string.Empty;

                }


                if (nevqrvam)
                {
                    for (int h = 0; h < countFormat; h++)
                    {
                        format2 = format2 + format;
                    }
                    final.Add(format2 + "}");
                    format2 = string.Empty;

                }

                inputNoMore.Clear();
                eh = true;
                dabe = false;
                dali++;
                nevqrvam = false;
               
                
               
            }
            final.Remove(string.Empty);
           

            
            for (int i = 0; i < final.Count; i++)
            {
                if(!(final[i]==string.Empty));
                Console.WriteLine(final[i]);
            }
        }
    }
