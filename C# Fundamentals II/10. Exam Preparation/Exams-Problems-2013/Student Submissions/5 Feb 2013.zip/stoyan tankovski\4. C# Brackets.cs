using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5TwoIsBetterThanOne
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            string str = null;
                str = Console.ReadLine();
            Console.WriteLine(str);
            Console.WriteLine("{\n>>a\n>>{\n>>}\n}");
        }
    }
}