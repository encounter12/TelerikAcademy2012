using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// using System.Numerics;

class Program
{
    static void Main(string[] args)
        {
           
          string numberchars = Console.ReadLine();
          char[] original = numberchars.ToCharArray();
            List<int> final = new List<int>();
            if ( original[0] <= 'Z')
            {
              final.Add(Convert.ToInt32(original[0]- 'A'));
            }
           

            for (int i = 1; i < original.Length; i++)
            {
                if ( original[i] <= 'Z')
                {
                    if (original[i - 1] <= 'Z')
                    {
                        final.Add(Convert.ToInt32(original[i] - 'A'));
                    }
                    else
                    {
                        switch (original[i-1])
                        {
                            case 'a': final.Add(26 + Convert.ToInt32(original[i] - 'A')); break;
                            case 'b': final.Add(52 + Convert.ToInt32(original[i] - 'A')); break;
                            case 'c': final.Add(78 + Convert.ToInt32(original[i] - 'A')); break;
                            case 'd': final.Add(104 + Convert.ToInt32(original[i] - 'A')); break;
                            case 'e': final.Add(130 + Convert.ToInt32(original[i] - 'A')); break;
                            case 'f': final.Add(156 + Convert.ToInt32(original[i] - 'A')); break;
                        }                        
                    }                  

                }
            }
            int[] ftry = new int[final.Count];
            ftry = final.ToArray();
            int length = ftry.Length;
        int[] reversed = new int[length];
       
        for (int j = 0; j < length; j++)
        {
            reversed[length - j - 1] = ftry[j];
        }
        int next = 0;
        int sum = 0;
        for (int m = 0; m < length; m++)
        {
            next = reversed[m] * 168 ^ m;
            sum = sum + next;
        }
        
        Console.WriteLine(sum);   
}
}