using System;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Numerics;

class TwoIsBetterThanOne
{
    static void Main()
    {
        string range = Console.ReadLine();
        BigInteger A = BigInteger.Parse(range.Split(' ')[0]);
        BigInteger B = BigInteger.Parse(range.Split(' ')[1]);
        //string A = "100000000";
        //string B = "100000000000000";
        //int diff = B.Length - A.Length + 1;
        int count = 0;

        for (BigInteger i = A; i <= B; i++)
        {
            string number = i.ToString();
            //  Match match = Regex.Match(number,@"[0-246-9]*");
            //MatchCollection matches = Regex.Matches(number, @"[01246789]*");
            if (number.IndexOf("1") > -1 || number.IndexOf("2") > -1 || number.IndexOf("4") > -1 || number.IndexOf("6") > -1 ||
                number.IndexOf("7") > -1 || number.IndexOf("8") > -1 || number.IndexOf("9") > -1 || number.IndexOf("0") > -1)
            {
                continue;
            }
            else
            {
                if (CheckPalindrone(number))
                {
                    count++;
                   // Console.WriteLine(number);
                }
            }

        }
        

       // int[] arr = { -2, -1, -4, -3 };
       // int p = 50;
        //int[] arr = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
        //int p = 39;
        //int[] arr = { -8,-6, -1,  4,6,9,28,100};


        string input = Console.ReadLine();
        List<int> aList = new List<int>();
        foreach (string num in input.Split(','))
        {
            aList.Add(int.Parse(num));
        }
        int p = int.Parse(Console.ReadLine());

        aList.Sort();
        double pNum = p * aList.Count / 100.0;
        int index = (int)Math.Round(pNum - 1);
        if (index < 0)
        {
            index = 0;
        }

        
        Console.WriteLine(count);
        Console.WriteLine(aList[index]);
     }

    private static bool CheckPalindrone(string sNum)
    {
        int len = sNum.Length;
        bool isPalindrome = true;
        for (int i = 0; i < len / 2; i++)
        {
            if (sNum[i] != sNum[len - 1 - i])
            {
                isPalindrome = false;
                break;
            }
        }
        return isPalindrome;
    }
}
