using System;
using System.Text;
using System.Collections.Generic;
using System.Numerics;

class Durankulak
{
    static void Main()
    {
        string consoleInput = Console.ReadLine();
        string[] durDigits = new string[16];

        durDigits = GetAllDigits(consoleInput);

        Console.WriteLine(DurankulakToDecimal(durDigits));
    }

    private static string[] GetAllDigits(string consoleInput)
    {
        string[] durDigits = new string[16];

        for (int i = 0, index = 0; i < consoleInput.Length; i++, index++)
        {
            char ch = consoleInput[i];

            if (ch >= 'a' && ch <= 'z')
            {
                durDigits[index] = consoleInput[i].ToString() + consoleInput[++i].ToString();
            }
            else if (ch >= 'A' && ch <= 'Z')
            {
                durDigits[index] = consoleInput[i].ToString();
            }
        }

        return durDigits;
    }

    private static BigInteger DurankulakToDecimal(string[] durDigits)
    {
        BigInteger deciNum = 0;
        int numBase = 168;
        int len = 0;

        // Gete length
        for (int i = 0; i < durDigits.Length; i++)
        {
            if (durDigits[i] != null)
            {
                len++;
            }
            else
            {
                break;
            }
        }

        for (int i = 0; i < len; i++)
        {
            char ch = durDigits[i][0];

            if ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z'))
            {
                int digit = 0;

                if (ch >= 'a' && ch <= 'z')
                {
                    digit += (ch - 'a' + 1) * 26;
                    digit += durDigits[i][1] - 'A';
                }
                else
                {
                    digit = ch - 'A';
                }
                                
                deciNum += digit * (BigInteger)Math.Pow(numBase, len - i - 1);
            }
            else
            {
                break;
            }
        }

        return deciNum;
    }
}