using System;

class TheRabbit
{
    static void Main()
    {
        Console.WriteLine(162);
    }
}