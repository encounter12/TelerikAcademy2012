using System;
class TwoIsBetterThanOne
{
    static int[] userArray;
    static int[] tempArray;
    static void MergeSortSplit(int left, int right)
    {
        if (left < right)
        {
            int middle = (left + right) / 2;

            MergeSortSplit(left, middle);

            MergeSortSplit(middle + 1, right);

            MergeSortMerge(left, middle, right);
        }
    }
    static void MergeSortMerge(int left, int middle, int right)
    {
        int pointerLeftTempArray, pointerRightTempArray, pointerUserArray;
        for (int index = left; index <= right; index++)
        {
            tempArray[index] = userArray[index];
        }

        pointerLeftTempArray = left;
        pointerRightTempArray = middle + 1;
        pointerUserArray = left;

        while (pointerLeftTempArray <= middle && pointerRightTempArray <= right)
        {
            //Comparing the current elements from left and right part of tempArray (the smaller will be copied to userArray)
            //if the element from left part of tempArray is smaller, then it is copied to userArray on position [pointerUserArray]
            //else it is copied the element from right part
            if (tempArray[pointerLeftTempArray] <= tempArray[pointerRightTempArray])
            {
                userArray[pointerUserArray] = tempArray[pointerLeftTempArray];
                pointerUserArray++;
                pointerLeftTempArray++;
            }
            else
            {
                userArray[pointerUserArray] = tempArray[pointerRightTempArray];
                pointerUserArray++; pointerRightTempArray++;
            }
        }
        while (pointerLeftTempArray <= middle)
        {
            userArray[pointerUserArray] = tempArray[pointerLeftTempArray];
            pointerUserArray++; pointerLeftTempArray++;
        }
    }

    static void Main()
    {
        string[] input = Console.ReadLine().Split();
        long B = long.Parse(input[1]);
        int left;
        int right;
        string stringedNumber;
        int luckyNumbersFound = 0;
        for (long counter = long.Parse(input[0]); counter <= B; counter++)
        {
            stringedNumber = counter.ToString();
            left = 0;
            right = stringedNumber.Length - 1;
            while (left <= right)
            {
                if (stringedNumber[left] != stringedNumber[right]) break;
                else if (stringedNumber[left] != '3' && stringedNumber[left] != '5') break;
                else if (stringedNumber[right] != '3' && stringedNumber[right] != '5') break;
                left++;
                right--;
                luckyNumbersFound++;
            }
        }
        
        string[] inputSecond = Console.ReadLine().Split(',');
        int P = int.Parse(Console.ReadLine());
        userArray = new int[inputSecond.Length];
        int pointer = ((userArray.Length * P) / 100);
        for (int index = 0, inputLength = input.Length; index < inputLength; index++)
        {
            userArray[index] = int.Parse(input[index]);
        }
        //Array.Sort(userArray);
        MergeSortSplit(0, userArray.Length-1);
        Console.WriteLine(luckyNumbersFound);
        Console.WriteLine(userArray[pointer]);
    }
}

