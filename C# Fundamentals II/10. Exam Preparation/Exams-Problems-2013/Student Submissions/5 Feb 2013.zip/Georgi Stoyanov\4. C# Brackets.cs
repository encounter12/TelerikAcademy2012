using System;
using System.Text;
using System.Text.RegularExpressions;

class Problem4
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string tab = Console.ReadLine();
        StringBuilder input = new StringBuilder();
        for (int i = 0; i < n; i++)
        {
            input.Append(System.Text.RegularExpressions.Regex.Replace(Console.ReadLine(), @"\s+", " "));
            input.Append("\n");
        }

        input = new StringBuilder((System.Text.RegularExpressions.Regex.Replace(input.ToString(), @"{ {", "{{")));
        input = new StringBuilder((System.Text.RegularExpressions.Regex.Replace(input.ToString(), @"{ }", "{}")));
        input = new StringBuilder((System.Text.RegularExpressions.Regex.Replace(input.ToString(), @"} {", "}{")));
        input = new StringBuilder((System.Text.RegularExpressions.Regex.Replace(input.ToString(), @"} }", "}}")));
        bool newLine = false;
        int level = 0;
        StringBuilder output = new StringBuilder();

        for (int i = 0; i < input.Length; i++)
        {
            output = new StringBuilder(Regex.Replace(output.ToString(), @"^\s*$[\r\n]*", string.Empty, RegexOptions.Multiline));
            if (input[i] == '{')
            {
                output = new StringBuilder(Regex.Replace(output.ToString(), @"^\s*$[\r\n]*", string.Empty, RegexOptions.Multiline));
                output.Append("\n");
                for (int f = 0; f < level; f++)
                {
                    output.Append(tab);
                }

                output.Append(input[i]);

                level++;
                output.Append("\n");
                newLine = true;
            }

            else if (input[i] == '}')
            {
                output = new StringBuilder(Regex.Replace(output.ToString(), @"^\s*$[\r\n]*", string.Empty, RegexOptions.Multiline));
                level--;
                output.Append("\n");
                for (int f = 0; f < level; f++)
                {
                    output.Append(tab);
                }

                output.Append(input[i]);

                
                output.Append("\n");
                newLine = true;
            }

            else if (input[i] == '\n')
            {
                output = new StringBuilder(Regex.Replace(output.ToString(), @"^\s*$[\r\n]*", string.Empty, RegexOptions.Multiline));
                output.Append(input[i]);
                newLine = true;
            }
            else
            {
                output = new StringBuilder(Regex.Replace(output.ToString(), @"^\s*$[\r\n]*", string.Empty, RegexOptions.Multiline));
                if (newLine)
                {
                    
                    for (int f = 0; f < level; f++)
                    {
                        output.Append(tab);
                    }
                    
                }

                if (input[i] == ' ' && newLine)
                {
                    
                }
                else
                {
                    output.Append(input[i]);
                }
                newLine = false;
            }
            
        }

        string[] outputStr = output.ToString().Split(new char[]{'\n'}, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < outputStr.Length; i++)
        {
            Console.WriteLine(outputStr[i].Trim());
        }

    }
}