using System;
using System.Numerics;
using System.Collections.Generic;
using System.Text;



class Program
{
    private static int CountCapital(string input)
    {
        int count = 0;
        foreach (char c in input)
        {
            if (c >= 65 && c <= 90)//if current char is capital letter
            {
                count++;
            }
        }
        return count;
    }

    static void Main(string[] args)
    {
        string input = Console.ReadLine();

        BigInteger smallLetterVal = 0;
        BigInteger capitalLetterVal = 0;
        BigInteger result = 0;
        double power = CountCapital(input) - 1;
        //input = ReverseString(input);
        for (int i = 0/*input.Length-1*/; i < input.Length/*i>=0*/; i++)
        {
            char c = input[i];
            if (c >= 65 && c <= 90)//if current char is capital letter
            {
                capitalLetterVal = c - 65;
                BigInteger zzz = (BigInteger)Math.Pow(168D, power);
                BigInteger temp = (smallLetterVal * 26 + (c - 65)) * zzz;
                result = result + temp;
                smallLetterVal = 0;
                power--;
            }
            else if (c >= 97 && c <= 122)
            {
                smallLetterVal = c - 96;
            }
            //power++;
        }

        Console.WriteLine(result);
    }

    //private static string ReverseString(string input)
    //{
    //    StringBuilder result = new StringBuilder();

    //    for (int i = 0; i < input.Length; i++)
    //    {
    //        result.Append(input[input.Length-1-i]);
    //    }

    //    return result.ToString();
    //}
}

