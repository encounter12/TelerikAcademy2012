using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoroRabit
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] numbersStr = input.Split(',');
            int[] numbers = new int[numbersStr.Length];
            
            bool bValue = true;
            for (int i = 0; i < numbersStr.Length; i++)
            {
                numbers[i] = int.Parse(numbersStr[i]);
            }
            long count = 0;
            long bestCount = 0;
            int pos = 0;
            for (int i = 1; i < numbers.Length; i++)
            {
                for (int j = 0; j < numbers.Length; j++)
                {
                    bool[] visits = new bool[numbersStr.Length];
                    int oldValue=numbers[j];
                    count = 0;
                    int z = (j + i)%numbers.Length;
                    while (true)
                    {
                       if (!visits[z])
                       {
                                if (numbers[z] > oldValue)
                                {
                                    count++;
                                    oldValue = numbers[z];
                                    visits[z] = true;
                                    z = (z + i) % numbers.Length;
                                }
                            else
                            {
                                break;
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                    if (count > bestCount)
                    {
                        bestCount = count;
                    }
                }
            }
            Console.WriteLine(bestCount+1);
        }
    }
}
