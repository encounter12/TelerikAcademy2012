using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace durankulak
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            char[] arrayChars = input.ToCharArray();
            int sum = 0;
            int count = 1;
            if (arrayChars.Length <= 2)
            {
                for (int i = arrayChars.Length - 1; i >= 0; i--)
                {
                    int number = FindNumber(arrayChars[i]);
                    sum += number;
                }
            }
            else
            {
                for (int i = arrayChars.Length - 1; i >= arrayChars.Length - 2; i--)
                {
                    int number = FindNumber(arrayChars[i]);
                    sum += number;
                }

                for (int i = arrayChars.Length - 3; i >= 0; i--)
                {
                    count = 168 * FindNumber(arrayChars[i]);
                    sum += count;
                }

            }

            Console.WriteLine(sum);
        }
        private static int FindNumber(char newChar)
        {
            StringBuilder list = new StringBuilder();
            list.Append(newChar);
            string text = list.ToString();
            switch (text)
            {
                case "A": return 0;
                case "B": return 1;
                case "C": return 2;
                case "D": return 3;
                case "E": return 4;
                case "F": return 5;
                case "G": return 6;
                case "H": return 7;
                case "I": return 8;
                case "J": return 9;
                case "K": return 10;
                case "L": return 11;
                case "M": return 12;
                case "N": return 13;
                case "O": return 14;
                case "P": return 15;
                case "Q": return 16;
                case "R": return 17;
                case "S": return 18;
                case "T": return 19;
                case "U": return 20;
                case "V": return 21;
                case "W": return 22;
                case "X": return 23;
                case "Y": return 24;
                case "Z": return 25;
                case "a": return 26;
                case "b": return 52;
                case "c": return 78;
                case "d": return 104;
                case "e": return 130;
                case "f": return 156;

                default:
                    break;
            }
            return -1;
        }
    }
}