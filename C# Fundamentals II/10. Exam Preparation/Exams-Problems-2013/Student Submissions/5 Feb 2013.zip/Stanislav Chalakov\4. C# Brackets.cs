using System;
using System.Text;

class CSharpBrackets
{
    static void Main()
    {
        int N = int.Parse(Console.ReadLine());
        string S = Console.ReadLine();
        string[] lines = new string[N];
        for (int i = 0; i < N; i++)
        {
            lines[i] = Console.ReadLine();
        }
        char[] charArray = string.Join(string.Empty, lines).ToCharArray();
        int sCounter = 0;
        int lCounter = 0;
        for (int j = 0; j < charArray.Length; j++)
        {
            if (charArray[j] != '{' && charArray[j] != '}')
            {
                if (sCounter > 0 && lCounter > 0)
                {
                    for (int l = 0; l < sCounter; l++)
                    {
                        Console.Write(S);
                    }
           
                }
                Console.Write(charArray[j]);
            }
            if (charArray[j] == '{')
            {
                if (sCounter > 0 && lCounter > 0 && charArray[1] != '{')
                {
                    Console.WriteLine();
                }
                for (int k = 0; k < sCounter; k++)
                {
                    Console.Write(S);
                }
                Console.WriteLine(charArray[j]);
                sCounter++;
                lCounter++;
            }
            if (charArray[j] == '}')
            {
                sCounter--;
                lCounter--;
                for (int k = 0; k < sCounter; k++)
                {
                    Console.Write(S);
                }
                Console.WriteLine(charArray[j]);
            }   
        }
    }
}
