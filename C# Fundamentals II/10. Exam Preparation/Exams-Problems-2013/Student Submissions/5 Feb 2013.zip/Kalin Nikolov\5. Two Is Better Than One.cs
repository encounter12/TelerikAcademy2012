using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace TwoIsBetterThanOne
{
    class TwoIsBetterThanOne
    {
        static void Main(string[] args)
        {
                BigInteger A;
                BigInteger B;
                int P;
                int[] list;

                string line = Console.ReadLine().Trim();
                char[] separator = { ' ' };

                A = BigInteger.Parse(line.Split(separator)[0]);
                B = BigInteger.Parse(line.Split(separator)[1]);

                line = Console.ReadLine().Trim();
                separator[0] = ',';
                string[] numsStr = line.Split(separator);
                list = new int[numsStr.Length];

                for (int i = 0; i < numsStr.Length; i++)
                {
                    list[i] = int.Parse(numsStr[i].Trim());
                }

                P = int.Parse(Console.ReadLine().Trim());

                BigInteger E = getNum(list, P);

                Console.WriteLine(getLuckyNumberCount(A, B));
                Console.WriteLine(getNum(list, P));

        }

        static BigInteger getLuckyNumberCount(BigInteger A, BigInteger B)
        {
            int luckyCount = 0;

            for (BigInteger i = A; i <= B; i++)
            {
                if (containsOnlyLucky(i) && isPalindrome(i))
                    luckyCount++;
            }

            return luckyCount;
        }

        static bool containsOnlyLucky(BigInteger num)
        {
            string numStr = "" + num;

            for (int i = 0; i < numStr.Length; i++)
                if (numStr[i] != '3' && numStr[i] != '5')
                    return false;

            return true;
        }

        static bool isPalindrome(BigInteger num)
        {
            string numStr = "" + num;

            for (int i = 0; i < (numStr.Length / 2); i++)
            {
                if (numStr[i] != numStr[(numStr.Length - 1) - i])
                    return false;
            }

            return true;
        }

        static int getNum(int[] list, int P)
        {
            int E = findMax(list);

            for (int i = 0; i < list.Length; i++)
            {
                if (getElemPerc(list[i], list) >= P && list[i] < E)
                    E = list[i];
            }

            return E;
        }

        static int getElemPerc(int num, int[] list)
        {
            int count = 0;
            int i = 0;

            for (i = 0; i < list.Length; i++)
            {
                if (list[i] <= num)
                    count++;
            }

            return ((count * 100)) / list.Length;
        }

        static int findMax(int[] list)
        {
            int max = int.MinValue;
            for (int i = 0; i < list.Length; i++)
            {
                if (list[i] > max)
                    max = list[i];
            }

            return max;
        }
    }
}
