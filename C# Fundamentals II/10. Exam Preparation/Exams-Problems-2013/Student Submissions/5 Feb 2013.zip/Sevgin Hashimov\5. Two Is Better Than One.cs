using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace _5.TwoTasks
{
    class Program
    {
        static void Main()
        {
            bool skip = false;
            string[] firstLine = Console.ReadLine().Split(' ');
            long a = long.Parse(firstLine[0]);
            long b = long.Parse(firstLine[1]);
            string[] secondLine = Console.ReadLine().Split(',');
            double percent = double.Parse(Console.ReadLine()) / 100;
            int count = 0;
            for (long i = a; i <= b; i++)
            {
                long temp = i;
                skip = false;
                while (temp > 0)
                {
                    if (temp % 10 != 3 && temp % 10 != 5)
                    {
                        skip = true;
                    }
                    temp /= 10;
                }

                if (!skip)
                {
                    count += Polindrom(i.ToString());
                }
 
            }
 
            
            int[] numbers = new int[secondLine.Length];
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = int.Parse(secondLine[i]);
            }
            
            int minNumbers = (int)Math.Ceiling((double)numbers.Length * percent);

            Array.Sort(numbers);

            Console.WriteLine(count);
            int min = int.MaxValue;

            for (int i = 0; i < numbers.Length; i++)
            {
                int current = numbers[i];
                int smallerCount = 0;
                for (int j = 0; j < numbers.Length; j++)
                {
                    if (current >= numbers[j])
                    {
                        smallerCount++;
                    }
                    else
                    {
                        break;
                    }

                    if (smallerCount >= minNumbers && current < min)
                    {
                        Console.WriteLine(current);
                        return;  
                    }
                    //else if (smallerCount >= minNumbers && current > min)
                    //{
                    //    Console.WriteLine(min);
                    //    return;                        
                    //}
                }                
            }

            //Console.WriteLine(min);
        }

        private static int Polindrom(string text)
        {
            bool polindrom = true;
            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] != text[text.Length - i - 1])
                {
                    polindrom = false;
                    break;
                }
            }

            if (polindrom)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }
}
