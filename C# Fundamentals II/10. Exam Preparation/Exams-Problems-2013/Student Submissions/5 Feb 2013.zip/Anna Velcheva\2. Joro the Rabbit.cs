using System;

class JoroTheRabbit
{
    static void Main(string[] args)
    {
        string input = Console.ReadLine();
        string[] splitInput = input.Split(new string[] {", "}, StringSplitOptions.RemoveEmptyEntries);

        int[] terrain = new int[splitInput.Length];
        for (int i = 0; i < splitInput.Length; i++)
        {
            terrain[i] = Int32.Parse(splitInput[i]);
        }

        int bestResult = -1;
        for (int step = 1; step < terrain.Length; step++)
        {
            for (int entrance = 0; entrance < terrain.Length; entrance++)
            {
                int result = 1;
                bool[] visited = new bool[terrain.Length];
                visited[entrance] = true;
                int currentIndex = entrance + step;
                if (currentIndex > terrain.Length - 1)
                {
                    currentIndex -= terrain.Length;
                }
                int previousIndex = entrance;
                while (visited[currentIndex] == false && terrain[previousIndex] < terrain[currentIndex])
                {
                    result++;
                    previousIndex = currentIndex;
                    currentIndex += step;
                    if (currentIndex > terrain.Length - 1)
                    {
                        currentIndex -= terrain.Length;
                    }
                }

                if (bestResult < result)
                {
                    bestResult = result;
                }
            }
        }

        if (terrain.Length == 1)
        {
            Console.WriteLine(1);
        }
        else
        {
            Console.WriteLine(bestResult);
        }
    }
}
