using System;
using System.Collections.Generic;
using System.Text;

class JoroTheRabbit
{
    public class PositionStep
    {
        public int position;
        public int step;

        public PositionStep(int position, int step)
        {
            this.position = position;
            this.step = step;
        }

        public override bool Equals(object obj)
        {
            if (this == obj)
                return true;
            PositionStep other = obj as PositionStep;
            if (other == null)
                return false;
            if (!this.position.Equals(other.position))
                return false;
            if (!this.step.Equals(other.step))
                return false;
            return true;
        }

        public override int GetHashCode()
        {
            int prime = 83;
            int result = 1;
            unchecked
            {
                result = result * prime + this.position.GetHashCode();
                result = result * prime + this.step.GetHashCode();
            }
            return result;
        }

        public override string ToString()
        {
            return String.Format("(Position: {0}, Step: {1})", this.position, this.step);
        }
    }
    static void Main()
    {
        Dictionary<PositionStep, int> triedPositionSteps = new Dictionary<PositionStep,int>();
        string[] input = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
        int[] fields = new int[input.Length];
        for (int i = 0; i < input.Length; i++)
        {
            fields[i] = int.Parse(input[i]);
        }

        int bestResult = 1;

        for (int i = 0; i < fields.Length; i++)
        {
            for (int j = 1; j < fields.Length; j++)
            {
                SecondPlayPositionStep(i, j, 1, ref fields, ref bestResult, ref triedPositionSteps);
            }
        }
        Console.WriteLine(bestResult);

    }


    private static void SecondPlayPositionStep(int position, int step, int currentResult, ref int[] fields, ref int bestResult,
     ref Dictionary<PositionStep, int> triedPositionSteps)
    {
        //Console.WriteLine("position: {0}, value: {1}, step: {2}", position, fields[position], step);

        if (triedPositionSteps.ContainsKey(new PositionStep(position, step))) return;

        PositionStep testPosition = new PositionStep(CalculateNextPosition(position, step, fields.Length), step);

        if (fields[testPosition.position] <= fields[position])
        {
            triedPositionSteps.Add(new PositionStep(position, step), currentResult);
            return;
        }

        if (triedPositionSteps.ContainsKey(testPosition))
        {
            triedPositionSteps.Add(new PositionStep(position, step), currentResult + triedPositionSteps[testPosition]);
            if (currentResult + triedPositionSteps[testPosition] > bestResult)
            {
                bestResult = currentResult + triedPositionSteps[testPosition];
            }
            return;
        }

        SecondPlayPositionStep(testPosition.position, step, 1, ref fields, ref bestResult, ref triedPositionSteps);

        SecondPlayPositionStep(position, step, 1, ref fields, ref bestResult, ref triedPositionSteps);

    }

    private static int CalculateNextPosition(int position, int step, int fieldsCount)
    {
        return (position + step) % fieldsCount;
    }
}
