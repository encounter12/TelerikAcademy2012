using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class Five
{
    static string ReverseDigit(string a)
    {

        string r = "";
        for (int i = a.Length-1; i >= 0; i--)
        {
            r += a[i];
        }
        return r.ToString();
    }

    static bool isPalindrome(BigInteger a)
    {
        string p = a + "";
        bool flag = true;
        for (int i = 0; i < p.Length; i++)
        {
            if (p[i] == '5' || p[i] == '3')
            {
                flag = true;
            }
            else { flag = false; return false; }
        }
        return flag;
    }

    static void Main()
    {
        string line = Console.ReadLine();
        string[] iline = line.Split(' ');
        BigInteger start = BigInteger.Parse(iline[0]);
        BigInteger end = BigInteger.Parse(iline[1]);
        int sum = 0;
        for (BigInteger i = start; i <= end; i++)
        {
            if (isPalindrome(i) && ReverseDigit(Convert.ToString(i)) == Convert.ToString(i))
            {
                sum++;
            }
        }
        Console.WriteLine(sum);


        line = Console.ReadLine();
        iline = line.Split(',');

        int p = int.Parse(Console.ReadLine());

        int[] nums = new int[iline.Length];
        for (int i = 0; i < iline.Length; i++)
        {
            nums[i] = int.Parse(iline[i]);
        }

        Array.Sort(nums);
        decimal f = ((decimal)p / 100 * nums.Length) + 0.5m;
        decimal percentile = Math.Round(f, 1, MidpointRounding.ToEven);
        int result = 0;
        if ((percentile * 10) % 10 == 5)
        {
            result = (int)percentile + 1;
        }
        else result = (int)percentile;
        Console.WriteLine(nums[result-1]);

     }
}