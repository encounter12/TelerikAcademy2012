using System;
using System.Collections.Generic;

class Jorro
{
    static void Main()
    {
        //string list = Console.ReadLine();
      

        //foreach (var item in list.Split(','))
        //{
        //    parsed.Add(int.Parse(item.TrimStart()));

        //}
        int start = 0;
        int[] number = {1, -2, -3, 4, -5, 6, -7, -8};//parsed.ToArray();
        int lenght = 0;
        int maxLenght = 0;
        int step = 0;
        int j = 0;
        bool isLonger = false;
        for (int i = 0; i < number.Length; i++)
        {
          
           j = i;
           step = 1;
                while (true)
                {
                    if (j < number.Length - 1)
                    {
                        if (number[j + 1] > number[i])
                        {
                            step++;
                            j++;
                            break;
                        }
                        else
                        {
                            step++;
                            j++;                           
                        }                       
                    }
                    else if(j == number.Length -1) 
                    {
                        if (number[0] > number[i])
                        {
                            step++;
                            j++;
                            break;
                        }
                        else
                        {
                            step++;
                            j = 0;                            
                        }                       
                    }
                    if (step == number.Length)
                    {
                        isLonger = true;
                        break;
                    }
                }
                //if (isLonger)
                //{
                //    continue;
                //}
                //isLonger = false;
           lenght = 1;
           //j++;
           if (j == number.Length)
           {
               j--;
           }
            while (true)
            {
                int newIndex = new int();
                if (j + step <= number.Length - 1)
                {
                    newIndex = j + step;
                }
                else 
                {
                   newIndex = (step - (number.Length - j));
                   if (newIndex == number.Length)
                   {
                       newIndex -= 1;
                   }
                }
                if (number[newIndex] > number[j])
                {
                    lenght++;
                }
                else
                {
                    break;
                }
                j = newIndex;
            }
            if (maxLenght < lenght)
            {
                maxLenght = lenght;
            }
            
        }
        Console.WriteLine(maxLenght);
        //Console.WriteLine(j);
    }
}
