using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX02JoroTheRabbit
{
	class EX02JoroTheRabbit
	{
		static void Main()
		{
			//string inputText = "-7, -8, 1, -2, -3, 4, -5, 6";
			//string inputText = "1, 1, 1";
			//StringReader input = new StringReader(inputText);
			//Console.SetIn(input);
			//int[] terrain = Console.ReadLine()
			//					   .Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
			//					   .Select(n => Convert.ToInt32(n))
			//					   .ToArray();
			string[] terrainString = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
			
			int[] terrain = new int[terrainString.Length];

			for (int i = 0; i < terrainString.Length; i++)
			{
				terrain[i] = int.Parse(terrainString[i]);
			}

			int terrainLength = terrain.Length;
						
			int max = 0;
			bool[] terrainMap = new bool[terrainLength];
			int numberOfJumps;
			int lastPositionNumber;
			int currentPosition;

			for (int startPosition = 0; startPosition < terrainLength; startPosition++)
			{
				for (int step = 1; step < terrainLength; step++)
				{
					numberOfJumps = 0;
					lastPositionNumber = terrain[startPosition];
					currentPosition = (startPosition + step) % terrainLength;
					
					while (!terrainMap[currentPosition] && terrain[currentPosition] > lastPositionNumber)
					{
						numberOfJumps++;
						terrainMap[currentPosition] = true;
						lastPositionNumber = terrain[currentPosition];
						currentPosition = (currentPosition + step) % terrainLength;						
					}

					Array.Clear(terrainMap, 0, terrainMap.Length);

					if (numberOfJumps > max)
					{
						max = numberOfJumps;
					}
				}
			}
			Console.WriteLine(max + 1);
		}
	}
}