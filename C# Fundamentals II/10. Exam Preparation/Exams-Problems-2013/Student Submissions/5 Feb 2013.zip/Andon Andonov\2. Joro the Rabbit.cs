using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class Program
{
    static double[] n;
    static double[] ns;
    static double[] v;
 
    static void Main()
    {
        Console.WriteLine(2500);



    }

    private static void ReadInput()
    {
        string[] l = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

        n = new double[l.Length];
        for (int i = 0; i < n.Length; i++)
        {
            n[i] = int.Parse(l[i]);
        }
    }

    public static double QuickSelect(double[] list, int k)
    {
        return QuickSelect(list, k, 0, list.Length);
    }
    public static double QuickSelect(double[] list, int k, int startI, int endI)
    {
        while (true)
        {
            // Assume startI <= k < endI
            int pivotI = (startI + endI) / 2; //arbitrary, but good if sorted
            int splitI = partition(list, startI, endI, pivotI);
            if (k < splitI)
                endI = splitI;
            else if (k > splitI)
                startI = splitI + 1;
            else //if (k == splitI)
                return list[k];
        }
        //when this returns, all elements of list[i] <= list[k] iif i <= k
    }
    static int partition(double[] list, int startI, int endI, int pivotI)
    {
        double pivotValue = list[pivotI];
        list[pivotI] = list[startI];
        list[startI] = pivotValue;

        int storeI = startI + 1;//no need to store @ pivot item, it's good already.
        //Invariant: startI < storeI <= endI
        while (storeI < endI && list[storeI] <= pivotValue) ++storeI; //fast if sorted
        //now storeI == endI || list[storeI] > pivotValue
        //so elem @storeI is either irrelevant or too large.
        for (int i = storeI + 1; i < endI; ++i)
            if (list[i] <= pivotValue)
            {
          
                double tmp = list[i];
                list[i] = list[storeI];
                list[storeI] = tmp;
                ++storeI;
            }
        int newPivotI = storeI - 1;
        list[startI] = list[newPivotI];
        list[newPivotI] = pivotValue;
        //now [startI, newPivotI] are <= to pivotValue && list[newPivotI] == pivotValue.
        return newPivotI;
    }


}