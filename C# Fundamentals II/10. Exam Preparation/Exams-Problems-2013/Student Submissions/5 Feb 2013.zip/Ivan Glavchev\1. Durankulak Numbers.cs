using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2013
{
	class Program
	{
		private static ulong pow(ulong number, int power)
		{
			ulong result = 1;
			for (int i = 0; i != power; ++i)
			{
				result *= number;
			}
			return result;
		}
		static void Main(string[] args)
		{
			int count = 0;
			ulong decimalNumber = 0;
			string input = Console.ReadLine();
			for (int i = input.Length - 1; i > 0; )
			{
				if (input[i - 1] <= 'Z')
				{
					decimalNumber += (ulong)(input[i] - 'A') * pow(168, count);
					i--;
				}
				else
				{
					decimalNumber += (ulong)(((input[i - 1] - 'a' + 1) * 26) + (input[i] - 'A')) * pow(168, count);
					i -= 2;
				}
				count++;
			}
			if (input[0] <= 'Z')
			{
				decimalNumber += (ulong)(input[0] - 'A') * pow(168, count);
			}
			Console.WriteLine(decimalNumber);
		}
	}
}
