using System;

class JoroTheRabbit
{
    static void Main()
    {
        // Reading input
        string input = Console.ReadLine();
        char[] separators = { ',', ' ' };
        string[] str = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        int arrLength = str.Length;
        int[] numbers = new int[arrLength];
        for (int i = 0; i < arrLength; i++)
        {
            numbers[i] = int.Parse(str[i]);
        }

        int result = 0;
        int tempResult = 0;
        int nextPosition = 0;
        for (int startPosition = 0; startPosition < arrLength; startPosition++)
        {
            for (int step = 1; step <= arrLength; step++)
            {
                tempResult = 1;
                bool[] used = new bool[arrLength];
                nextPosition = startPosition;
                while (true)
                {
                    int i = nextPosition;
                    if (i + step >= arrLength)
                    {
                        nextPosition = step + i - arrLength;
                    }
                    else
                    {
                        nextPosition = i + step;
                    }

                    if (used[i] == true)
                    {
                        break;
                    }
                    else if (numbers[i] <= numbers[nextPosition])
                    {
                        break;
                    }
                    else
                    {
                        used[i] = true;
                        tempResult++;
                    }
                }
                if (tempResult > result)
                {
                    result = tempResult;
                }
            }
        }
        Console.WriteLine(result);
    }
}
