using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02.Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            int allLines = int.Parse(Console.ReadLine());
            string stringToAdd = Console.ReadLine();

            StringBuilder getInput = new StringBuilder();
            List<string> getInputText = new List<string>();

            for (int i = 0; i < allLines; i++)
            {
                string line = Console.ReadLine();
                getInputText.Add(line);
            }

            string allText = String.Empty;
            for (int i = 0; i < getInputText.Count; i++)
			{
			    allText += getInputText[i];
			}

            StringBuilder formatedCode = new StringBuilder();
            char[] textChar = allText.ToCharArray();
            bool isInBrackets = false;
            bool isOutBrakets = false;
            int depth = 0;
            for (int i = 0; i < textChar.Length; i++)
            {
                if (textChar[i] == '{')
                {
                    if (depth == 0)
                    {
                        formatedCode.Append("\n");
                        formatedCode.Append(textChar[i]);
                        formatedCode.Append("\n");
                        formatedCode.Append(stringToAdd);
                    }
                    else
                    {
                        if (!isInBrackets)
                        {
                            depth++;
                        }
                        
                        isInBrackets = true;
                        formatedCode.Append("\n");
                        for (int j = 0; j < depth; j++)
                        {
                            formatedCode.Append(stringToAdd);
                        }
                        formatedCode.Append(textChar[i]);
                        formatedCode.Append("\n");

                        for (int j = 0; j < depth; j++)
                        {
                            formatedCode.Append(stringToAdd);
                        }
                    }
                    
                    //formatedCode.Append("\n");
                    
                }
                else if (textChar[i] == '}')
                {
                    isInBrackets = false;
                    if (depth == 0)
                    {
                        formatedCode.Append("\n");
                        formatedCode.Append(textChar[i]);
                        formatedCode.Append("\n");
                        formatedCode.Append(stringToAdd);
                    }
                    else
                    {
                        formatedCode.Append("\n");
                        for (int j = 0; j < depth; j++)
                        {
                            formatedCode.Append(stringToAdd);
                        }
                        formatedCode.Append(textChar[i]);
                        formatedCode.Append("\n");

                        for (int j = 0; j < depth; j++)
                        {
                            formatedCode.Append(stringToAdd);
                        }
                    }

                    //formatedCode.Append("\n");
                    depth--;
                }
                else
                {
                    formatedCode.Append(textChar[i]);
                }
                    
                
            }



            Console.WriteLine(formatedCode);
            
            


            int count = 0;

            int index = -1;
            
            
            while (true)
            {
                index = getInput.ToString().IndexOf("{", index + 1);
                if (index == -1)
                {
                    break;
                }
                if (count > 0)
                {
                    getInput = getInput.Replace("{", "\n" + stringToAdd + "{");
                }
                count++;
            }
            Console.WriteLine(getInput);
            //string[] inputStr = line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

        }
    }
}
