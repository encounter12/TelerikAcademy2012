using System;
using System.Text;
using System.Text.RegularExpressions;

class CSharpBrackets
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string indentStr = Console.ReadLine();
        char[] splitter = { ' ' };
        //string[] lines = new string[n];

        StringBuilder output = new StringBuilder();
        int brackets = 0;

        for (int i = 0; i < n; i++)
        {
            string[] lineWords = Console.ReadLine().Split(splitter, StringSplitOptions.RemoveEmptyEntries);
            foreach (var word in lineWords)
            {
                foreach (char c in word)
                {
                    if (c == '{')
                    {
                        output.Append(c);
                        output.Append("\r\n");
                        output.Append(indentStr);
                        brackets++;
                    }
                    else
                    {
                        output.Append(c);
                    }
                }
            }
        }

        Console.WriteLine(output.ToString());
    }
}