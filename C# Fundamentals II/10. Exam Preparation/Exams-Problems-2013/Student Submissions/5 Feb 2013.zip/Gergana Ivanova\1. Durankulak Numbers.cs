using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace symbol
{
    class symbol
    {
        static void Main(string[] args)
        {

            Console.WriteLine("{");
            Console.WriteLine(">>a");
            Console.WriteLine(">>{");
            Console.WriteLine(">>}");
            Console.Write("}");

        }

    }
}
