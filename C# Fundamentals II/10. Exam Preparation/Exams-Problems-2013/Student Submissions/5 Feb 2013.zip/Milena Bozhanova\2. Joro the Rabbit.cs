using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        string input = Console.ReadLine();
        char[] separators = { ' ', ',' };

        string[] inputArr = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);

        int[] arr = new int[inputArr.Length];

        for (int i = 0; i < inputArr.Length; i++)
        {
            arr[i] = int.Parse(inputArr[i]);
        }

        int avarage = (int)arr.Average();

        int step = 1;
        int maxVisitedCellsCount = 0;
        int VisitedCellsCount = 1;
        int[] VisitedCells = new int[arr.Length];

        while (step < arr.Length)
        {
            for (int cellInx = 0; cellInx < arr.Length; cellInx++)
            {
                if (arr[cellInx] > avarage)
                {
                    continue;
                }
                for (int currCellInx = cellInx; currCellInx < arr.Length; currCellInx++)
                {
                    if (currCellInx + step >= arr.Length)
                    {
                        int nextCellInd = (currCellInx + step) - arr.Length;
                        if (arr[nextCellInd] > arr[currCellInx] && VisitedCells[nextCellInd] == 0)
                        {
                            VisitedCellsCount++;
                            VisitedCells[currCellInx] += 1;
                            currCellInx = nextCellInd-1;

                        }

                        else
                        {
                            if (VisitedCellsCount > maxVisitedCellsCount)
                            {
                                maxVisitedCellsCount = VisitedCellsCount;
                                VisitedCellsCount = 1;
                            }
                            Array.Clear(VisitedCells, 0, arr.Length);
                            break;
                        }
                    }

                    else
                    {
                        int nextCellInd = currCellInx + step;
                        if (arr[nextCellInd] > arr[currCellInx] && VisitedCells[nextCellInd] == 0)
                        {
                            VisitedCellsCount++;
                            VisitedCells[currCellInx] += 1;
                            currCellInx = nextCellInd-1;

                        }

                        else
                        {
                            if (VisitedCellsCount > maxVisitedCellsCount)
                            {
                                maxVisitedCellsCount = VisitedCellsCount;
                                VisitedCellsCount = 1;
                            }
                            Array.Clear(VisitedCells, 0, arr.Length);
                            break;
                        }                   
                    }                   
                }
                VisitedCellsCount = 1;
            }
            step++;
        }

        if (VisitedCellsCount > maxVisitedCellsCount)
        {
            maxVisitedCellsCount = VisitedCellsCount;
        }

        Console.WriteLine(maxVisitedCellsCount);
    }
}
