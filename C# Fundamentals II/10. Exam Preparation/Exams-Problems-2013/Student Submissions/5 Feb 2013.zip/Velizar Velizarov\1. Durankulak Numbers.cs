using System;
using System.Numerics;

class DurankulakNumbers
{
    static BigInteger IntPow(int a, int b)
    {
        BigInteger result = 1;
        for (int i = 0; i < b; i++)
        {
            result *= a;
        }
        return result;
    }

    static void Main()
    {
        string number = Console.ReadLine();
        int countPow = -1;
        BigInteger result = 0;
        for (int i = number.Length- 1; i >= 0; i--)
        {
            if (number[i] >= 'A' && number[i] <= 'Z')
            {
                countPow++;
                result += (number[i] - 'A') * IntPow(168, countPow);
            }
            else if (number[i] >= 'a' && number[i] <= 'z')
            {
                result += (26 * (number[i] - 'a' + 1)) * IntPow(168, countPow);
            }
        }
        Console.WriteLine(result);
    }
}