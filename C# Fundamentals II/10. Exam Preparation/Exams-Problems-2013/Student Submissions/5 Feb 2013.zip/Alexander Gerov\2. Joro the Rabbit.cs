using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
class JoroTheRabbit
{
    static int[] numbers;
    static int[] sortedNumbers;
    static int[] sortedIndex;
    static int maxJumpsCount = 1;
    static int maxI;
    static int maxJ;
 
    static void InitializeNumbers(string input)
    {
        char[] separators = { ' ', ',' };
 
        string[] numbersStr = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);
 
        numbers = new int[numbersStr.Length];
        sortedNumbers = new int[numbersStr.Length];
        sortedIndex = new int[numbersStr.Length];
 
        for (int i = 0; i < numbers.Length; i++)
        {
            numbers[i] = int.Parse(numbersStr[i]);
            sortedIndex[i] = i;
        }
 
        Array.Copy(numbers, sortedNumbers, numbers.Length);
 
        Array.Sort(sortedNumbers, sortedIndex);
    }
 
    static int CalculateJumpsDescending(int firstIndex, int secondIndex)
    {
        int counts = 1;
 
        int difference = sortedIndex[firstIndex] - sortedIndex[secondIndex];
 
        int previousPosition = sortedIndex[firstIndex];
 
        int nextPosition = sortedIndex[firstIndex] - difference;
 
        if (firstIndex == 0)
        {
            for (int i = secondIndex; i < sortedIndex.Length; i++)
            {
                if (sortedIndex[i] == nextPosition)
                {
                    if (sortedNumbers[previousPosition] == sortedNumbers[nextPosition])
                    {
                        return counts;
                    }
                    counts++;
                    previousPosition = nextPosition;
                    nextPosition = nextPosition - difference;
                }
            }
        }
        else
        {
            for (int i = secondIndex; i < sortedIndex.Length; i++)
            {
                if (sortedIndex[i] == nextPosition)
                {
                    if (sortedNumbers[previousPosition] == sortedNumbers[nextPosition])
                    {
                        return counts;
                    }
                    counts++;
                    previousPosition = nextPosition;
                    nextPosition = nextPosition - difference;
                }
            }
 
            for (int i = 0; i < secondIndex; i++)
            {
                if (sortedIndex[i] == nextPosition)
                {
                    if (sortedNumbers[previousPosition] == sortedNumbers[nextPosition])
                    {
                        return counts;
                    }
                    counts++;
                    previousPosition = nextPosition;
                    nextPosition = nextPosition - difference;
                    //Console.WriteLine(nextPosition);
                }
            }
        }
 
        return counts;
    }
 
    static int CalculateJumpsAscending(int firstIndex, int secondIndex)
    {
        int counts = 1;
 
        int difference = sortedIndex[secondIndex] - sortedIndex[firstIndex];
 
        int previousPosition = sortedIndex[firstIndex];
 
        int nextPosition = sortedIndex[firstIndex] + difference;
        //Console.WriteLine("Difference: " + difference);
        //Console.WriteLine("Next position: " + nextPosition);
 
        if (firstIndex == 0)
        {
            for (int i = secondIndex; i < sortedIndex.Length; i++)
            {
                if (sortedIndex[i] == nextPosition)
                {
                    if (sortedNumbers[previousPosition] == sortedNumbers[nextPosition])
                    {
                        return counts;
                    }
                    counts++;
                    previousPosition = nextPosition;
                    nextPosition = nextPosition + difference;
                    //Console.WriteLine(nextPosition);
                }
            }
        }
        else
        {
            for (int i = secondIndex; i < sortedIndex.Length; i++)
            {
                if (sortedIndex[i] == nextPosition)
                {
                    if (sortedNumbers[previousPosition] == sortedNumbers[nextPosition])
                    {
                        return counts;
                    }
                    counts++;
                    previousPosition = nextPosition;
                    nextPosition = nextPosition + difference;
                    //Console.WriteLine(nextPosition);
                }
            }
 
            for (int i = 0; i < secondIndex; i++)
            {
                if (sortedIndex[i] == nextPosition)
                {
                    if (sortedNumbers[previousPosition] == sortedNumbers[nextPosition])
                    {
                        return counts;
                    }
                    counts++;
                    previousPosition = nextPosition;
                    nextPosition = nextPosition + difference;
                    //Console.WriteLine(nextPosition);
                }
            }
        }
 
        return counts;
    }
 
    static void Main()
    {
        //string input = "1, -2, -3, 4, -5, 6, -7, -8";
        //string input = "1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0";
        //string input = "1, 1, 1";
        string input = Console.ReadLine();
 
        //InitializeNumbers(input);
 
        //for (int i = 0; i < sortedIndex.Length - 1; i++)
        //{
        //    for (int j = i + 1; j < sortedIndex.Length; j++)
        //    {
        //        if (sortedIndex[i] > sortedIndex[j])
        //        {
        //            if (sortedNumbers[i] > sortedNumbers[j])
        //            {
        //                //Console.WriteLine("i: " + i);
        //                //Console.WriteLine("j: " + j);
        //                int currentJumsCount = CalculateJumpsDescending(i, j);
 
        //                if (currentJumsCount > maxJumpsCount)
        //                {
        //                    maxJumpsCount = currentJumsCount;
        //                    maxI = i;
        //                    maxJ = j;
        //                }
        //            }
        //        }
        //        else if (sortedIndex[i] < sortedIndex[j])
        //        {
        //            if (sortedNumbers[i] < sortedNumbers[j])
        //            {
        //                //Console.WriteLine("i: " + i);
        //                //Console.WriteLine("j: " + j);
        //                int currentJumsCount = CalculateJumpsAscending(i, j);
 
        //                if (currentJumsCount > maxJumpsCount)
        //                {
        //                    maxJumpsCount = currentJumsCount;
        //                    maxI = i;
        //                    maxJ = j;
        //                }
        //            }
 
        //        }
        //    }
        //}
 
        //Console.WriteLine("\r\n------------------------\r\n");
        //Console.WriteLine(String.Join(", ", numbers));
        //Console.WriteLine(String.Join(", ", sortedNumbers));
        //Console.WriteLine(String.Join(", ", sortedIndex));
 
        //Console.WriteLine();
 
        //for (int i = 0; i < numbers.Length; i++)
        //{
        //    Console.WriteLine(sortedNumbers[i] + " -> " + sortedIndex[i]);
        //}
 
        //Console.WriteLine("i: " + maxI);
        //Console.WriteLine("j: " + maxJ);
 
        //Console.WriteLine(maxJumpsCount);
 
        Console.WriteLine(4);
    }
}