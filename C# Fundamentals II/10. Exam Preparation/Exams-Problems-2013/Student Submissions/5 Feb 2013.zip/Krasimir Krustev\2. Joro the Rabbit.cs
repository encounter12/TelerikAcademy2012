using System;
using System.Collections.Generic;

class JoroTheRabit
{
    static void Main(string[] args)
    {
        string numbersAsStr = Console.ReadLine();
        string[] numbers = numbersAsStr.Split(new string[] {", "}, StringSplitOptions.None);
        int[] numbersInt = new int[numbers.Length];
        for (int i = 0; i < numbers.Length; i++)
        {
            numbersInt[i] = int.Parse(numbers[i]);
        }
        
        int maxRangeOfSteps = numbersInt.Length;
        int maxLength = 0;

        for (int i = 0; i < numbersInt.Length; i++)
        {
            for (int k = 1; k < maxRangeOfSteps; k++)
            {
                int length = 1;
                bool[] visited = new bool[numbers.Length];
                //List<int> nums = new List<int>();
                //nums.Add(numbersInt[i]);
                for (int j = i + k, p = i; ; p++, j += k)
                {
                    if (j > numbers.Length - 1)
                    {
                        j = numbers.Length - 1 - numbers.Length + k;
                    }

                    if (p > numbers.Length - 1)
                    {
                        p = numbers.Length - 1 - numbers.Length + k;
                    }

                    if (visited[p] == true)
                    {
                        break;   
                    }

                    if (numbersInt[j] > numbersInt[p])
                    {
                        visited[p] = true;
                        length++;
                        //nums.Add(numbersInt[j]);
                    }
                    else
                    {
                        break;
                    }
                    
                }

                if (length > maxLength)
                {
                    maxLength = length;
                }
            }
        }
        Console.WriteLine(maxLength);
    }
}