using System;
using System.Collections.Generic;

class Program
{
    static int[] inputArray = null;

    static int sizeN; 

    static void Main(string[] args)
    {
        string[] inputNumbers = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

        sizeN = inputNumbers.Length;
        /*
        inputArray = new int[sizeN];

        for (int i = 0; i < inputNumbers.Length; ++i)
        {
            inputArray[i] = int.Parse(inputNumbers[i]);

            inputArray[i + inputNumbers.Length] = inputArray[i];
        }

        

        int result = FindLongestGrowing();
        */
        Console.WriteLine(sizeN);
    }

    private static int FindLongestGrowing()
    {
        List<Tuple<int,int>>[] helpArray = new List<Tuple<int,int>>[sizeN];

        for (int i = 0; i < sizeN; i++)
        {
            helpArray[i] = new List<Tuple<int,int>>();
        }

        int maxLength = 1;

        int distance = 0;

        int tempLength = 0;

        for (int i = 0; i < sizeN; ++i)
        {
            for (int j = 0; j < i; ++j)
            {
                if (inputArray[i] > inputArray[j])
                {
                    distance = i - j;

                    for (int k = 0; k < helpArray[j].Count; k++)
			        {
			            if (distance == helpArray[j][k].Item2)
                        {
                            tempLength = helpArray[j][k].Item1+1;

                            helpArray[i].Add(new Tuple<int, int>(tempLength, distance));

                            if (tempLength > maxLength)
                            {
                                maxLength = tempLength;
                            }
                        }
			        }

                    helpArray[i].Add(new Tuple<int,int>(2, distance));

                    if (2 > maxLength)
                    {
                        maxLength = 2;
                    }
                }
            }

            for (int j = i + 1; j < sizeN; ++j)
            {
                if (inputArray[i] > inputArray[j])
                {
                    distance = sizeN - j;

                    for (int k = 0; k < helpArray[j].Count; k++)
                    {
                        if (distance == helpArray[j][k].Item2)
                        {
                            tempLength = helpArray[j][k].Item1 + 1;

                            helpArray[i].Add(new Tuple<int, int>(tempLength, distance));

                            if (tempLength > maxLength)
                            {
                                maxLength = tempLength;
                            }
                        }
                    }

                    helpArray[i].Add(new Tuple<int, int>(2, distance));

                    if (2 > maxLength)
                    {
                        maxLength = 2;
                    }
                }
            }

            //
        }

        return maxLength;
    }
}
