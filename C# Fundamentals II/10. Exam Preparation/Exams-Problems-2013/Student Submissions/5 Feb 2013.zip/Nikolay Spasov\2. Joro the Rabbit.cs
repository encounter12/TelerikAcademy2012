using System;

class JoroTheRabbit
{
    //static int[] arr = { 1, -2, -3, 4, -5, 6, -7, -8 };
    //static int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0 };
    static int[] arr;

    static void Main()
    {
        ////int s = Jump(0, 1);
        //int a = Jump(arr.Length - 1, 1);
        //Console.WriteLine(a);

        string line = Console.ReadLine();
        string[] spl = line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        arr = new int[spl.Length];

        for (int i = 0; i < spl.Length; i++)
        {
            arr[i] = int.Parse(spl[i]);
        }

        int best = 0;
        for (int start = 0; start < arr.Length; start++)
        {
            for (int hop = 1; hop < arr.Length; hop++)
            {
                int current = Jump(start, hop);

                if (best < current)
                {
                    best = current;
                }
            }
        }

        Console.WriteLine(best);
    }

    static int Jump(int start, int hop)
    {
        int index = start;
        int count = 1;

        bool[] visited = new bool[arr.Length];

        while (!visited[index])
        {
            int oldValue = arr[index];
            visited[index] = true;

            index = (index + hop) % arr.Length;

            if (arr[index] > oldValue)
            {
                count++;
            }
            else
            {
                break;
            }
        }

        return count;
    }
}

