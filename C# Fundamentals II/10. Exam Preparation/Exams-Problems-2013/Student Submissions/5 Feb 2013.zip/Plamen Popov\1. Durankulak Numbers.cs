using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Problem1DurankilakNumbers
{
    class Durankulak
    {

        static char[] Digits = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
                                 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j' };

    

        private static int[] ConvertToDigits(char[] NumberInArrayOfStrings)
        {
            int[] ArrayOfDigits = new int[NumberInArrayOfStrings.Length];
            for (int position = 0; position < NumberInArrayOfStrings.Length; position++)
            {
                ArrayOfDigits[position] = Array.BinarySearch(Digits, NumberInArrayOfStrings[position]);
                if (ArrayOfDigits[position] > 25)
                {
                    ArrayOfDigits[position] = (26 * (ArrayOfDigits[position] - 25));
                }
                
            }
            return ArrayOfDigits;
        }

        static void Main(string[] args)
        {
            string duranNumber = Console.ReadLine();
            char[] duranNumberInChars = duranNumber.ToCharArray();
            
            BigInteger Number = 0;
            int[] NumberInBytes = ConvertToDigits(duranNumberInChars);
            for (int i = 0; i < NumberInBytes.Length / 2; i++)
            {
                
                int temp = NumberInBytes[i];
                NumberInBytes[i] = NumberInBytes[NumberInBytes.Length - i - 1];
                NumberInBytes[NumberInBytes.Length - i - 1] = temp;
               
            }
            int pow = 0;
            for (int digit = 0; digit < NumberInBytes.Length; digit++)
            {
                
                BigInteger singleDigit = 0;
                if (NumberInBytes.Length%2 != 0 && digit == NumberInBytes.Length - 1)
                {
                    singleDigit = (NumberInBytes[digit] * (BigInteger)Math.Pow(168, pow));
                }
                else
	            {
                    BigInteger tempNumber = NumberInBytes[digit] + NumberInBytes[digit + 1];
                    singleDigit = (tempNumber * (BigInteger)Math.Pow(168, pow));
                    digit++;
	            }
                
                Number += singleDigit;
                pow ++;
            }
            Console.WriteLine(Number);
        }
    }
}