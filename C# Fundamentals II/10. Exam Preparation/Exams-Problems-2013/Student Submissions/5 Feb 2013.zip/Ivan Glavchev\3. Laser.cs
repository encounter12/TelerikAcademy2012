using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheCube
{
	class Program
	{
		static void Main(string[] args)
		{
			string[] dimensions = Console.ReadLine().Split(' ');
			int Width = int.Parse(dimensions[0]);
			int Height = int.Parse(dimensions[1]);
			int Depth = int.Parse(dimensions[2]);
			bool[, ,] cube = new bool[Width, Height, Depth];
			initializeCube(ref cube, Width, Height, Depth);

			string[] laserPosition = Console.ReadLine().Split(' ');
			int startW = int.Parse(laserPosition[0]) - 1;
			int startH = int.Parse(laserPosition[1]) - 1;
			int startD = int.Parse(laserPosition[2]) - 1;

			string[] laserDirection = Console.ReadLine().Split(' ');
			int dirW = int.Parse(laserDirection[0]);
			int dirH = int.Parse(laserDirection[1]);
			int dirD = int.Parse(laserDirection[2]);

			int currentW = startW;
			int currentH = startH;
			int currentD = startD;
			//cube[currentW, currentH, currentD] = true;

			while (true)
			{
				if (cube[currentW, currentH, currentD]) break;
				cube[currentW, currentH, currentD] = true;
				currentD += dirD;
				currentH += dirH;
				currentW += dirW;
				
				if (currentD == 0 || currentD == Depth - 1)
				{
					dirD = -dirD;
				}
				if (currentW== 0 || currentW == Width - 1)
				{
					dirW = -dirW;
				}
				if (currentH == 0 || currentH == Height - 1)
				{
					dirH = -dirH;
				}
			}
			Console.WriteLine((currentW + 1 - dirW) + " " + (currentH + 1 - dirH) + " " + (currentD + 1 - dirD));
		}

		

		private static void initializeCube(ref bool[, ,] cube, int Width, int Height, int Depth)
		{
			for (int h = 0; h != Height; ++h)
			{
				for (int d = 0; d != Depth; ++d)
				{
					for (int w = 0; w != Width; ++w)
					{
						if (!isEdge(w, h, d, Width, Height, Depth))
						{
							cube[w, h, d] = false; // not burned
						}
						else cube[w, h, d] = true; // burned
					}
				}
			}
		}

		private static bool isEdge(int w, int h, int d, int Width, int Height, int Depth)
		{
			return (w == 0 && h == 0) ||
				(w == 0 && d == 0) ||
				(d == 0 && h == 0) ||
				(w == Width - 1 && h == 0) ||
				(w == Width - 1 && h == Height - 1) ||
				(w == 0 && h == Height - 1) ||
				(w == Width - 1 && d == 0) ||
				(d == 0 && h == Height - 1) ||
				(h == 0 && d == Depth - 1) ||
				(w == 0 && d == Depth - 1) ||
				(w == Width - 1 && d == Depth - 1) ||
				(h == Height - 1 && d == Depth - 1);
		}
	}
}
