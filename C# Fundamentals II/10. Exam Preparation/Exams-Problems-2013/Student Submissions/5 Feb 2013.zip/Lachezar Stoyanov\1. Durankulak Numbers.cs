class Durankulak
{
    static void Main()
    {
        //switch (ch)
        //{
        //    case 'A' = 0 : break;
        //    case 'B' = 1: break;
        //    case 'C' = 2: break;
        //    case 'D' = 3: break;
        //    case 'E' = 4: break;
        //    case 'F' = 5: break;
        //    case 'J' = 6: break;
        //    default: Console.WriteLine("Wrong input!");  break;
        //}
        int counter = 0;
        string input = Console.ReadLine();
        char [] inputArr = input.ToCharArray();
        Array.Reverse(inputArr);
        string output = new string(inputArr);
        Console.WriteLine(inputArr);
        for (int i = 0; i < length; i++)
        {
            
        }
    }
}
