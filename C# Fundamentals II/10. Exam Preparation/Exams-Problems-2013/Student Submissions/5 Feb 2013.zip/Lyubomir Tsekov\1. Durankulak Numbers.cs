using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

class HexadecimalToDecimal4
{


    static int ConvertToInteger(string symbol)
    {
        int n = 0;
        switch (symbol)
        {
            case "A": n = 0; break;
            case "B": n = 1; break;
            case "C": n = 2; break;
            case "D": n = 3; break;
            case "E": n = 4; break;
            case "F": n = 5; break;
            case "G": n = 6; break;
            case "H": n = 7; break;
            case "I": n = 8; break;
            case "J": n = 9; break;
            case "K": n = 10; break;
            case "L": n = 11; break;
            case "M": n = 12; break;
            case "N": n = 13; break;
            case "O": n = 14; break;
            case "P": n = 15; break;
            case "Q": n = 16; break;
            case "R": n = 17; break;
            case "S": n = 18; break;
            case "T": n = 19; break;
            case "U": n = 20; break;
            case "V": n = 21; break;
            case "W": n = 22; break;
            case "X": n = 23; break;
            case "Y": n = 24; break;
            case "Z": n = 25; break;
            case "aA": n = 26; break;
            case "aB": n = 27; break;
            case "aC": n = 28; break;
            case "aD": n = 29; break;
            case "aE": n = 30; break;
            case "aF": n = 31; break;
            case "aG": n = 32; break;
            case "aH": n = 33; break;
            case "aI": n = 34; break;
            case "aJ": n = 35; break;
            case "aK": n = 36; break;
            case "aL": n = 37; break;
            case "aM": n = 38; break;
            case "aN": n = 39; break;
            case "aO": n = 40; break;
            case "aP": n = 41; break;
            case "aQ": n = 42; break;
            case "aR": n = 43; break;
            case "aS": n = 44; break;
            case "aT": n = 45; break;
            case "aU": n = 46; break;
            case "aV": n = 47; break;
            case "aW": n = 48; break;
            case "aX": n = 49; break;
            case "aY": n = 50; break;
            case "aZ": n = 51; break;
            case "bA": n = 52; break;
            case "bB": n = 53; break;
            case "bC": n = 54; break;
            case "bD": n = 55; break;
            case "bE": n = 56; break;
            case "bF": n = 57; break;
            case "bG": n = 58; break;
            case "bH": n = 59; break;
            case "bI": n = 60; break;
            case "bJ": n = 61; break;
            case "bK": n = 62; break;
            case "bL": n = 63; break;
            case "bM": n = 64; break;
            case "bN": n = 65; break;
            case "bO": n = 66; break;
            case "bP": n = 67; break;
            case "bQ": n = 68; break;
            case "bR": n = 69; break;
            case "bS": n = 70; break;
            case "bT": n = 71; break;
            case "bU": n = 72; break;
            case "bV": n = 73; break;
            case "bW": n = 74; break;
            case "bX": n = 75; break;
            case "bY": n = 76; break;
            case "bZ": n = 77; break;
            case "cA": n = 78; break;
            case "cB": n = 79; break;
            case "cC": n = 80; break;
            case "cD": n = 81; break;
            case "cE": n = 82; break;
            case "cF": n = 83; break;
            case "cG": n = 84; break;
            case "cH": n = 85; break;
            case "cI": n = 86; break;
            case "cJ": n = 87; break;
            case "cK": n = 88; break;
            case "cL": n = 89; break;
            case "cM": n = 90; break;
            case "cN": n = 91; break;
            case "cO": n = 92; break;
            case "cP": n = 93; break;
            case "cQ": n = 94; break;
            case "cR": n = 95; break;
            case "cS": n = 96; break;
            case "cT": n = 97; break;
            case "cU": n = 98; break;
            case "cV": n = 99; break;
            case "cW": n = 100; break;
            case "cX": n = 101; break;
            case "cY": n = 102; break;
            case "cZ": n = 103; break;
            case "dA": n = 104; break;
            case "dB": n = 105; break;
            case "dC": n = 106; break;
            case "dD": n = 107; break;
            case "dE": n = 108; break;
            case "dF": n = 109; break;
            case "dG": n = 110; break;
            case "dH": n = 111; break;
            case "dI": n = 112; break;
            case "dJ": n = 113; break;
            case "dK": n = 114; break;
            case "dL": n = 115; break;
            case "dM": n = 116; break;
            case "dN": n = 117; break;
            case "dO": n = 118; break;
            case "dP": n = 119; break;
            case "dQ": n = 120; break;
            case "dR": n = 121; break;
            case "dS": n = 122; break;
            case "dT": n = 123; break;
            case "dU": n = 124; break;
            case "dV": n = 125; break;
            case "dW": n = 126; break;
            case "dX": n = 127; break;
            case "dY": n = 128; break;
            case "dZ": n = 129; break;
            case "eA": n = 130; break;
            case "eB": n = 131; break;
            case "eC": n = 132; break;
            case "eD": n = 133; break;
            case "eE": n = 134; break;
            case "eF": n = 135; break;
            case "eG": n = 136; break;
            case "eH": n = 137; break;
            case "eI": n = 138; break;
            case "eJ": n = 139; break;
            case "eK": n = 140; break;
            case "eL": n = 141; break;
            case "eM": n = 142; break;
            case "eN": n = 143; break;
            case "eO": n = 144; break;
            case "eP": n = 145; break;
            case "eQ": n = 146; break;
            case "eR": n = 147; break;
            case "eS": n = 148; break;
            case "eT": n = 149; break;
            case "eU": n = 150; break;
            case "eV": n = 151; break;
            case "eW": n = 152; break;
            case "eX": n = 153; break;
            case "eY": n = 154; break;
            case "eZ": n = 155; break;
            case "fA": n = 156; break;
            case "fB": n = 157; break;
            case "fC": n = 158; break;
            case "fD": n = 159; break;
            case "fE": n = 160; break;
            case "fF": n = 161; break;
            case "fG": n = 162; break;
            case "fH": n = 163; break;
            case "fI": n = 164; break;
            case "fJ": n = 165; break;
            case "fK": n = 166; break;
            case "fL": n = 167; break;
        }
        return n;
    }

    static void Main()
    {
        string text = Console.ReadLine();
        List<int> array = new List<int>();
        for (int i = text.Length - 1; i >= 0;)
        {
            if (i>0)
            {
                if (char.IsUpper(text[i - 1]))
                {
                    StringBuilder a = new StringBuilder();
                    a.Append(text[i]);                    
                    array.Add(ConvertToInteger(a.ToString()));
                    i--;
                }
                else
                {
                    StringBuilder a = new StringBuilder();
                    a.Append(text[i - 1]);
                    a.Append(text[i]);                    
                    array.Add(ConvertToInteger(a.ToString()));
                    i = i - 2;
                }
            }
            else
            {
                StringBuilder a = new StringBuilder();                
                a.Append(text[i]);
                array.Add(ConvertToInteger(a.ToString()));
                i--;
            }
        }
        BigInteger result = 0;
        for (int i = 0; i < array.Count; i++)
        {
            result += array[i] * (BigInteger)(Math.Pow(168, i));
        }
        Console.WriteLine(result);
    }
}