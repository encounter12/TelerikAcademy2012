using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02.Rabbit
{
    class Program
    {
        static void Main(string[] args)
        {
            string pattern = Console.ReadLine();
            string[] options = pattern.Split(new char[] {' ',','},StringSplitOptions.RemoveEmptyEntries);
            int[] numbers = new int[options.Length];
            bool[] visited = new bool[options.Length];
            for (int i = 0; i < options.Length; i++)
            {
                numbers[i] = int.Parse(options[i]);
            }


            int maxJump = 0;
            int jumps = 0;
            for (int steps = 1; steps < options.Length; steps++)
            {
                jumps = 1;
                for (int cells = 0; cells < options.Length; cells++)
                {
                    int currentCell = cells;
                    int oldCell;
                    
                    while (true)
                    {
                        oldCell = currentCell;
                        if (currentCell+steps > options.Length-1)
                        {
                            currentCell = steps-(options.Length-1 - currentCell)-1;
                            
                        }
                        else
                        {
                            currentCell = steps + currentCell;
                        }
                        if (numbers[currentCell] > numbers[oldCell] && visited[currentCell] == false)
                        {
                            jumps++;
                            visited[currentCell] = true;
                        }
                        else break;
                    }

                    if (jumps>maxJump)
                    {
                        maxJump = jumps;
                    }
                }
            }
            Console.WriteLine(maxJump);
        }
    }
}
