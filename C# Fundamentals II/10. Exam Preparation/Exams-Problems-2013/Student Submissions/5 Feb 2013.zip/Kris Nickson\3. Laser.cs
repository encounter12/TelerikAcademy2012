using System;
using System.Collections.Generic;
using System.Text;


class Program
{
    static void Main()
    {
        int width = 0;
        int height = 0;
        int depth = 0;
        string dimensionsInput = Console.ReadLine();
        string[] dimensionsTemp = dimensionsInput.Split(' ');
        width = int.Parse(dimensionsTemp[0]);
        height = int.Parse(dimensionsTemp[1]);
        depth = int.Parse(dimensionsTemp[2]);

        bool[,,] visited = new bool[height, width, depth];

        int startW = 0;
        int startH = 0;
        int startD = 0;
        string startInput = Console.ReadLine();
        string[] startTemp = startInput.Split(' ');
        startW = int.Parse(startTemp[0]);
        startH = int.Parse(startTemp[1]);
        startD = int.Parse(startTemp[2]);

        int dirW = 0;
        int dirH = 0;
        int dirD = 0;
        string dirInput = Console.ReadLine();
        string[] dirTemp = dirInput.Split(' ');
        dirW = int.Parse(dirTemp[0]);
        dirH = int.Parse(dirTemp[1]);
        dirD = int.Parse(dirTemp[2]);

        Console.Write(0 + " " + 0 + " " + 0);
        int currentW = startW;
        int currentH = startH;
        int currentD = startD;
        visited[currentH, currentW, currentD] = true;
        while (true)
        {
            int tempD = currentD + dirD;
            int tempW = currentW + dirW;
            int tempH = currentH + dirH;
            if (tempD < depth && tempW < width && tempH < height && visited[currentH + dirH, currentW + dirW, currentD + dirD] != true)
            {
                if ((tempD == depth - 1 || tempD == 0))
                {
                    if ((tempH == 1 || tempH == height - 1 || tempW == 0 || tempW == width - 1))
                    {
                        break;
                    }
                    else
                    {
                        if (tempD == 0)
                        {
                            //burn the cube
                            currentD = tempD;
                            currentW = tempW;
                            currentH = tempH;
                            visited[currentH, currentW, currentD] = true;//mark it
                            dirD = 1;//change direction
                            continue;//go to the next
                        }
                        else
                        {
                            //burn the cube
                            currentD = tempD;
                            currentW = tempW;
                            currentH = tempH;
                            visited[currentH, currentW, currentD] = true;//mark it
                            dirD = -1;//change direction
                            continue;//go to the next
                        }
                    }

                }
                else if ((tempW == 0 || tempW == width - 1))
                {
                    if (tempH == 1 || tempH == height - 1 || tempD == 0 || tempD == depth - 1)
                    {
                        break;
                    }
                    else
                    {
                        if (tempW == 0)
                        {
                            currentD = tempD;
                            currentW = tempW;
                            currentH = tempH;
                            visited[currentH, currentW, currentD] = true;//mark it
                            dirW = 1;//change direction
                            continue;//go to the next
                        }
                        else
                        {
                            currentD = tempD;
                            currentW = tempW;
                            currentH = tempH;
                            visited[currentH, currentW, currentD] = true;//mark it
                            dirW = -1;//change direction
                            continue;//go to the next
                        }
                    }

                }
                else if ((tempH == 0 || tempH == height - 1))
                {
                    if (tempW == 1 || tempW == width - 1 || tempD == 0 || tempD == depth - 1)
                    {
                        break;
                    }
                    else
                    {
                        if (tempH == 0)
                        {
                            currentD = tempD;
                            currentW = tempW;
                            currentH = tempH;
                            visited[currentH, currentW, currentD] = true;//mark it
                            dirH = 1;//change direction
                            continue;//go to the next
                        }
                        else
                        {
                            currentD = tempD;
                            currentW = tempW;
                            currentH = tempH;
                            visited[currentH, currentW, currentD] = true;//mark it
                            dirH = -1;//change direction
                            continue;//go to the next
                        }
                    }
                }
                else
                {
                    //we are somewhere in the cube and dont need to cahnge directions or leave
                    currentD = tempD;
                    currentW = tempW;
                    currentH = tempH;
                    visited[currentH, currentW, currentD] = true;//mark it
                }
            }
            else
            {
                break;
            }
        }


        Console.Write(currentW + " " + currentH + " " + currentW);
    }
}

