using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;

namespace DuranculakNumbers
{
    class Program
    {
        public static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }
        static void Main(string[] args)
        {
            char[] az = Enumerable.Range('A', 'Z' - 'A' + 1).Select(i => (Char)i).ToArray();
            
            string word = Console.ReadLine();
            if (word.Length <= 16 && word.Length >= 1)
            {
                word = word.ToUpper();

                word = ReverseString(word);
                int end = 0;
                BigInteger sum = 0;
                word.ToUpper();
                int count = 0;
                for (int i = 0, index = 0; i < word.Length; i++, index++)
                {
                    for (int j = 0; j < az.Length; j++)
                    {
                        if (word[i] == az[j])
                        {
                            if (i % 2 == 0 && i > 0)
                            {

                                count++;
                                index = 0;
                            }


                            BigInteger a = j + index;
                            //if (a == 0 && i != 0) a = 1;
                            BigInteger b = (BigInteger)(Math.Pow(az.Length, index) * Math.Pow(168, count));

                            sum += a * b;




                        }

                    }
                }

                Console.WriteLine(sum);
            }
        }
    }
}