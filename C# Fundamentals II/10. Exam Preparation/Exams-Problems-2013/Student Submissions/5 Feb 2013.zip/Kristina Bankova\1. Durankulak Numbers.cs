using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;


class DurankulakNumbers
{
    static void Main()
    {
        string[] DurankulakAlphabet = new string[168];
        string DuranKulakNum = Console.ReadLine();
        
        BigInteger decimalNum = 0;
        GenerateDuranAlphabet(DurankulakAlphabet);

        if (DuranKulakNum.Length == 1)
        {
            decimalNum = ((int)DuranKulakNum[0] - 65);
        }
        else
        {
            int power = 1;

            for (int currCharIndex = DuranKulakNum.Length - 1; currCharIndex >= 0; currCharIndex--)
            {
                for (int i = 0; i < DurankulakAlphabet.Length; i++)
                {
                    if (currCharIndex - 1 >= 0 && ((int)DuranKulakNum[currCharIndex - 1] >= (int)'a' &&
                       (int)DuranKulakNum[currCharIndex - 1] <= (int)'f'))
                    {
                        if (DuranKulakNum.Substring(currCharIndex - 1, 2) == DurankulakAlphabet[i])
                        {
                            decimalNum = decimalNum + power * i;
                            power = power * 168;
                            break;
                        }
                    }
                    else if ((DuranKulakNum[currCharIndex].ToString() == DurankulakAlphabet[i]))
                    {
                        decimalNum = decimalNum + power * i;
                        power = power * 168;
                    }
                }
            }
        }
        Console.WriteLine(decimalNum);
    }

    private static void GenerateDuranAlphabet(string[] DurankulakAlphabet)
    {
        for (int i = 0; i <= 25; i++)
        {
            DurankulakAlphabet[i] = ((char)(65 + i)).ToString();
        }
        for (int i = 26; i <= 51; i++)
        {
            DurankulakAlphabet[i] = ("a" + DurankulakAlphabet[i - 26]);
        }
        for (int i = 52; i <= 77; i++)
        {
            DurankulakAlphabet[i] = ("b" + DurankulakAlphabet[i - 52]);
        }
        for (int i = 78; i <= 103; i++)
        {
            DurankulakAlphabet[i] = ("c" + DurankulakAlphabet[i - 78]);
        }
        for (int i = 104; i <= 129; i++)
        {
            DurankulakAlphabet[i] = ("d" + DurankulakAlphabet[i - 104]);
        }
        for (int i = 130; i <= 155; i++)
        {
            DurankulakAlphabet[i] = ("e" + DurankulakAlphabet[i - 130]);
        }
        for (int i = 156; i <= 167; i++)
        {
            DurankulakAlphabet[i] = ("f" + DurankulakAlphabet[i - 156]);
        }
    }
}