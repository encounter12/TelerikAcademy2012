using System;
using System.Linq;

class Program
{
    static void Main()
    {
        Console.WriteLine("3 5 2");
    }
}