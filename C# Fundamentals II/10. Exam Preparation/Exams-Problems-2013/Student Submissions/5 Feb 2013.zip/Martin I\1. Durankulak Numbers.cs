using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Numerics;

namespace exam
{
    class Durankulak
    {   
        static void Main(string[] args)
        {
           
            string input = Console.ReadLine();
            BigInteger uppersCount = 0;

            int power = 0;

            List<string> upCase = new List<string>();
            List<string> lowCase = new List<string>();

            Match matchLower = Regex.Match(input, "[a-z]*");
            Match matchUpper = Regex.Match(input, "[A-Z]");
            while (matchUpper.Success)
            {
                upCase.Add(matchUpper.Value);
                matchUpper = matchUpper.NextMatch();
            }

            while (matchLower.Success)
            {
                lowCase.Add(matchLower.Value);
                matchLower = matchLower.NextMatch();
            }

            upCase.Reverse();

            BigInteger upperSum = 0;
            for (int i = 0; i < upCase.Count; i++)
            {
                 char currentWord = char.Parse(upCase[i]);
                 upperSum += ((int)currentWord - 65) * (int)Math.Pow(168, power);
                 power++;
            }

            BigInteger lowerSum = 0;
            int powerLower = 0;
            for (int i = 0; i < lowCase.Count; i++)
            {
                string currentWord = lowCase[i];
                if (currentWord != "")
                {
                    BigInteger currentSum = 0;
                    power = 1;

                    for (int j = 0; j < currentWord.Length; j++)
                    {
                        currentSum = (BigInteger)Math.Pow(168, powerLower) * ((BigInteger)currentWord[currentWord.Length - j - 1] - 96) * (BigInteger)Math.Pow(25, power) + (BigInteger)currentWord[currentWord.Length - j - 1] - 96;
                        power++;
                    }
                    powerLower++;
                    lowerSum += currentSum;
                }
                
            }
            Console.WriteLine(lowerSum + upperSum);
            
            
        }
    }
}
