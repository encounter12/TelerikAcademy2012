using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoroTheRabbit
{
    class JoroTheRabbit
    {
        static void Main()
        {
            string inputLine = Console.ReadLine();
            string[] strTerrain = inputLine.Split(',');
            int[] terrain=new int[strTerrain.Length];
            int max = 0;
            for (int index = 0; index < strTerrain.Length; index++)
            {
                terrain[index] = int.Parse(strTerrain[index]);
            }
            bool[] visited=new bool[terrain.Length];
            if (terrain.Length == 1)
            {
                max = 1;
            }
            else
            {
                for (int startInd = 0; startInd < terrain.Length; startInd++)
                {

                    for (int step = terrain.Length - 1; step >= 1; step--)
                    {
                        int start = startInd;
                        visited[start] = true;
                        int countCells = 1;
                        int nextIndex = start + step;
                        if (nextIndex > terrain.Length - 1)
                        {
                            nextIndex = step - (terrain.Length - 1 - start) - 1;
                        }
                        while ((visited[nextIndex] == false) && (terrain[nextIndex]) > terrain[start])
                        {
                            countCells++;
                            visited[nextIndex] = true;
                            start = nextIndex;
                            nextIndex = start + step;
                            if (nextIndex > terrain.Length - 1)
                            {
                                nextIndex = step - (terrain.Length - 1 - start) - 1;
                            }
                        }
                        if (countCells > max)
                        {
                            max = countCells;
                        }
                        Array.Clear(visited, 0, visited.Length);
                    }
                }
            }
            Console.WriteLine(max);
        }
    }
}
