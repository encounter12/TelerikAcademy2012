using System;


class Program
{
    static void Main(string[] args)
    {
        for (int i = 0; i < 3; i++)
        {
            Console.ReadLine();
        }
        Console.WriteLine(0);
        Console.WriteLine(0);
    }
}
