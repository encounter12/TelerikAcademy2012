using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class CSharpBrackets
{
    static void Main()
    {
        int lines = int.Parse(Console.ReadLine());
        string tabString = Console.ReadLine();
        int tabCount = 0;
        bool flag = false;
        bool ignoreWhitespace = false;
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < lines; i++)
        {
            string line = Console.ReadLine();
            if (line == Environment.NewLine)
            {
                continue;
            }
            flag = false;
            line = line.Trim();
            result.Append(Environment.NewLine);
            if (line[0] != '}')
            {
                for (int tabs = 0; tabs < tabCount; tabs++)
                {
                    result.Append(tabString);
                }
            }

            for (int j = 0; j < line.Length; j++)
            {
                if (line[j] == '{')
                {
                    if (j != 0)
                    {
                        result.Append(Environment.NewLine);
                    }
                    for (int tabs = 0; tabs < tabCount; tabs++)
                    {
                        result.Append(tabString);
                    }
                    result.Append("{");
                    tabCount++;
                    if (j != line.Length - 1)
                    {
                        result.Append(Environment.NewLine);
                    }
                    flag = true;
                    continue;
                }
                if (line[j] == '}')
                {
                    tabCount--;
                    if (j != 0)
                    {
                        result.Append(Environment.NewLine);
                    }
                    for (int tabs = 0; tabs < tabCount; tabs++)
                    {
                        result.Append(tabString);
                    }
                    result.Append("}");
                    if (j < line.Length - 1)
                    {
                        result.Append(Environment.NewLine);
                    }
                    flag = true;
                    continue;
                }
                if (flag)
                {
                    for (int tabss = 0; tabss < tabCount; tabss++)
                    {
                        result.Append(tabString);
                    }
                    flag = false;
                }
                if (j > 0 && Char.IsWhiteSpace(line[j]) && char.IsWhiteSpace(line[j - 1]))
                {
                    continue;
                }
                result.Append(line[j]);
            }
        }
        Console.WriteLine(result.ToString().Trim());
    }
}