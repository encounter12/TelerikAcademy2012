using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

class Problem2
{
    static void Main()
    {
        string line = Console.ReadLine(); //"1,-2,-3,4,-5,6,-7,-8"; //Console.ReadLine();
        string[] rawNumbers = line.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        int[] terrain = new int[rawNumbers.Length];
        for (int i = 0; i < rawNumbers.Length; i++)
        {
            terrain[i] = int.Parse(rawNumbers[i]);
        }

        int maxJumps = 0;
        int tempJumps = 0;
        for (int startIndex = 0; startIndex < rawNumbers.Length; startIndex++)
        {
            for (int step = 1; step < rawNumbers.Length; step++)
            {
                tempJumps = CountSteps(terrain, startIndex, step);
                if (tempJumps > maxJumps)
                {
                    maxJumps = tempJumps;
                }
            }
        }
        Console.WriteLine(maxJumps);
    }
    static int CountSteps(int[] terrain, int start, int step)
    {
        int[] visited = new int[terrain.Length];
        visited[start] = 1;
        int prevStepIndex = start;
        int count = 1;
        while (true)
        {
            int nextStepIndex = prevStepIndex + step;
            if (nextStepIndex > terrain.Length-1)
            {
                nextStepIndex -= terrain.Length;
            }
            if (terrain[nextStepIndex] <= terrain[prevStepIndex] || visited[nextStepIndex] == 1)
            {
                break;
            }
            count++;
            visited[nextStepIndex] = 1;
            prevStepIndex = nextStepIndex;
        }
        return count;
    }
}