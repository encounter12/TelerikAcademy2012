using System;
using System.Collections.Generic;
using System.Text;


class Brackets
{
    static void Main()
    {
        int N = int.Parse(Console.ReadLine());
        string S = Console.ReadLine();
        string[] code = new string[N];
        for (int i = 0; i < N; i++)
        {
            code[i] = Console.ReadLine();
        }
        string wholeCode = "";
        for (int i = 0; i < N; i++)
        {
            string[] arr = code[i].Split(' ');
            for (int j = 0; j < arr.Length; j++)
            {
                if (arr[j] == "")
                {
                    continue;
                }
                else
                {
                    wholeCode += arr[j] + " ";
                }
            }

        }
        wholeCode.Trim();
        int indentCounter = 0;
        int bracketCounter = 0;
        StringBuilder line = new StringBuilder();
        for (int i = 0; i < wholeCode.Length; i++)
        {
            if (wholeCode[i] == '{')
            {
                if (line.Length > 0)
                {
                    for (int j = 0; j < indentCounter; j++)
                    {
                        Console.Write(S);
                    }
                    Console.WriteLine(line);
                    line.Clear();
                }
                bracketCounter++;
                indentCounter++;
                if (bracketCounter > 1)
                {
                    for (int j = 0; j < bracketCounter - 1; j++)
                    {

                        Console.Write(S);
                    }
                }
                Console.WriteLine(wholeCode[i]);
                continue;
            }
            if (wholeCode[i] == '}')
            {
                indentCounter--;
                for (int j = 0; j < indentCounter; j++)
                {
                    Console.Write(S);
                }
                Console.WriteLine(wholeCode[i]);
                continue;
            }
            if (wholeCode[i] == '\n')
            {
                for (int j = 0; j < indentCounter; j++)
                {
                    Console.Write(S);
                }
                Console.WriteLine(line);
            }
            else
            {
                line.Append(wholeCode[i]);
            }
        }
    }
}
