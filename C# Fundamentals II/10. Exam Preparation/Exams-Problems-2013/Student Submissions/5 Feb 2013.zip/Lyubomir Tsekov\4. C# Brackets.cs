using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Exam2
{
    class Exam2
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string indent = Console.ReadLine();
            int bracketCounter = 0;
            StringBuilder answer = new StringBuilder();
            int emptySpaceCounter = 0;
            int newLineCounter = 0;
            string[] array = new string[n];
            for (int i = 0; i < n; i++)
            {
                array[i] = Console.ReadLine();
            }
            for (int j = 0; j < array.Length; j++)
            {                
                string red = array[j].Trim();
                if (answer.Length>indent.Length)
                {
                    int a = answer.Length - indent.Length;
                    string check = answer.ToString().Substring(a);
                    if (check != indent)
                    {
                        StringBuilder indents2 = new StringBuilder();
                        for (int k = 0; k < bracketCounter; k++)
                        {
                            indents2.Append(indent);
                        }
                        answer.Append("\n" + indents2.ToString());
                    }
                }
                
                for (int i = 0; i < red.Length; i++)
                {
                    char symbol = (red[i]);
                    if (symbol == '{')
                    {
                        StringBuilder indents = new StringBuilder();
                        for (int k = 0; k < bracketCounter; k++)
                        {
                            indents.Append(indent);
                        }
                        answer.Append("\n" + indents.ToString() + "{");
                        bracketCounter++;
                        StringBuilder indents1 = new StringBuilder();
                        for (int k = 0; k < bracketCounter; k++)
                        {
                            indents1.Append(indent);
                        }
                        answer.Append("\n" + indents1.ToString());

                    }

                    else if (symbol == '}')
                    {
                        bracketCounter--;
                        StringBuilder indents = new StringBuilder();
                        for (int k = 0; k < bracketCounter; k++)
                        {
                            indents.Append(indent);
                        }
                        answer.Append("\n" + indents.ToString() + "}");
                        StringBuilder indents3 = new StringBuilder();
                        for (int k = 0; k < bracketCounter; k++)
                        {
                            indents3.Append(indent);
                        }
                        answer.Append("\n" + indents3.ToString());
                    }

                    else
                    {
                        if (symbol==' ')
                        {
                            emptySpaceCounter++;
                        }
                        if (emptySpaceCounter>1&&symbol==' ')
                        {
                            
                        }
                        else
                        {
                            if (symbol!=' ')
                            {
                                emptySpaceCounter = 0;
                            }
                            answer.Append(symbol);
                        }
                    }
                }
            }
            
            
            Console.WriteLine(answer);
        }
    }
}
