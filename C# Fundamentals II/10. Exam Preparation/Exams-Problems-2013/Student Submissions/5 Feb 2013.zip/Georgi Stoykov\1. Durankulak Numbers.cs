using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class Durankulak
{
    static void Main(string[] args)
    {
        string str = Console.ReadLine();
        List<string> digit = new List<string>();
        StringBuilder build = new StringBuilder();

        for (int i = 0; i < str.Length; i++)
        {
            build.Append(str[i]);
            if (char.IsUpper(str[i]))
            {
                digit.Add(build.ToString());
                build.Clear();
            }
        }
        List<string> reversed = new List<string>();
        for (int i = 0; i < digit.Count; i++)
        {
            reversed.Add(digit[digit.Count - i - 1]);
        }

        BigInteger number = 0;
        for (int i = 0; i < reversed.Count; i++)
        {
            number += DigitNumber(reversed[i]) * (int)Math.Pow(168, i);

        }

        Console.WriteLine(number);
    }

    static BigInteger DigitNumber(string str)
    {
        // a    b   c   d   e   f   g   h   i   j   k   l   m   n   o   p   q   r   s   t   u   v   w   x   y   z

        BigInteger digitSum = 0;
        for (int i = 0; i < str.Length; i++)
        {
            if (char.IsUpper(str[i]))
            {
                switch (str[i])
                {
                    case 'B': digitSum += 1; break;
                    case 'C': digitSum += 2; break;
                    case 'D': digitSum += 3; break;
                    case 'E': digitSum += 4; break;
                    case 'F': digitSum += 5; break;
                    case 'G': digitSum += 6; break;
                    case 'H': digitSum += 7; break;
                    case 'I': digitSum += 8; break;
                    case 'J': digitSum += 9; break;
                    case 'K': digitSum += 10; break;
                    case 'L': digitSum += 11; break;
                    case 'M': digitSum += 12; break;
                    case 'N': digitSum += 13; break;
                    case 'O': digitSum += 14; break;
                    case 'P': digitSum += 15; break;
                    case 'Q': digitSum += 16; break;
                    case 'R': digitSum += 17; break;
                    case 'S': digitSum += 18; break;
                    case 'T': digitSum += 19; break;
                    case 'U': digitSum += 20; break;
                    case 'V': digitSum += 21; break;
                    case 'W': digitSum += 22; break;
                    case 'X': digitSum += 23; break;
                    case 'Y': digitSum += 24; break;
                    case 'Z': digitSum += 25; break;
                    default:
                        break;
                }
            }
            else if (char.IsLower(str[i]))
            {
                switch (str[i])
                {
                    case 'a': digitSum += 26; break;
                    case 'b': digitSum += 52; break;
                    case 'c': digitSum += 78; break;
                    case 'd': digitSum += 104; break;
                    case 'e': digitSum += 130; break;
                    case 'f': digitSum += 156; break;
                    case 'g': digitSum += 182; break;
                    case 'h': digitSum += 208; break;
                    case 'i': digitSum += 234; break;
                    case 'j': digitSum += 260; break;
                    case 'k': digitSum += 286; break;
                    case 'l': digitSum += 312; break;
                    case 'm': digitSum += 338; break;
                    case 'n': digitSum += 364; break;
                    case 'o': digitSum += 390; break;
                    case 'p': digitSum += 416; break;
                    case 'q': digitSum += 442; break;
                    case 'r': digitSum += 468; break;
                    case 's': digitSum += 494; break;
                    case 't': digitSum += 520; break;
                    case 'u': digitSum += 546; break;
                    case 'v': digitSum += 572; break;
                    case 'w': digitSum += 598; break;
                    case 'x': digitSum += 624; break;
                    case 'y': digitSum += 650; break;
                    case 'z': digitSum += 676; break;
                    default:
                        break;
                }
            }
        }
        return digitSum;
    }


}