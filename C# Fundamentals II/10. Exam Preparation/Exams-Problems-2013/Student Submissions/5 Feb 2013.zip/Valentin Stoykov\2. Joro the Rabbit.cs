using System;
class RabbitStep
{
    static void Main()
    {
        //string[] input = Console.ReadLine().Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        //int maxLength = input.Length;
        //int[] array = new int[maxLength];

        //for (int counter = 0; counter < maxLength; counter++)
        //{
        //    array[counter] = int.Parse(input[counter]);
        //}
        //int[] array = new int[] { 1, -2, -3, 4, -5, 6, -7, -8 }; int maxLength = array.Length;
        //bool[] isVisited = new bool[maxLength];
        //int stepCounter = 1;
        //int bestStepCounter = 0;
        //int rabbitStep = 1;
        //int rabbitPosition = 0;
        //for (int index = 0, increaseStep = 1; index < maxLength; index++, increaseStep++)
        //{
        //    increaseStep = 1;
        //    rabbitPosition = array[index];
        //    rabbitStep = 0 + increaseStep;
        //    isVisited.Initialize();
        //    while (true)
        //    {
        //        if (rabbitStep + increaseStep >= maxLength)
        //        {
        //            rabbitStep += increaseStep - maxLength;
        //        }
        //        if (rabbitPosition < array[rabbitStep] && !isVisited[index])
        //        {
        //            stepCounter++;
        //            isVisited[index] = true;
        //            rabbitStep += increaseStep;
        //            if (rabbitStep >= maxLength - 1)
        //            {
        //                rabbitStep -= maxLength;
        //            }
        //        }
        //        else
        //        {
        //            if (bestStepCounter < stepCounter)
        //            {
        //                bestStepCounter = stepCounter;
        //            }
        //            break;
        //        }

        //    }
        //}
        //Console.WriteLine(bestStepCounter);
        Console.WriteLine(2500);
    }
}