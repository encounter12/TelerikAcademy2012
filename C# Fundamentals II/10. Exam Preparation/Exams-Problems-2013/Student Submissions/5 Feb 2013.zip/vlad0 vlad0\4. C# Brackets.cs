using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace _04.IntelliSense
{
    class Program
    {
        static void Main(string[] args)
        {
            //string linesString = "5";

            //string indent = "....";
            string linesString = Console.ReadLine();
            string indent = Console.ReadLine();

            int lines = int.Parse(linesString);
            StringBuilder source = new StringBuilder();
            string[] test = new string[lines];
            for (int i = 0; i < lines; i++)
            {
                //source.Append(Console.ReadLine());
                //source.Append('\n');
               test[i] = Console.ReadLine();
               foreach (Match match in Regex.Matches(test[i], @"\s{2,}"))
               {
                   test[i] = test[i].Replace(match.ToString(), " ");
               }
            }
            string text = source.ToString();
            //remove white space
            //foreach (Match match in Regex.Matches(text, @"\s{2,}"))
            //{
            //    text = text.Replace(match.ToString(), " ");
            //}

            FeelIt(test, indent);
        }

        private static void FeelIt(string[] text, string indent)
        {
            int countIndent = 0;
            StringBuilder sorted = new StringBuilder();
            char previousItem=' ';
            bool isNewLine = true;
            foreach (string LINE in text)
            {

                foreach (char item in LINE)
                {

                    if (item == '{')
                    {
                        if (previousItem != '\n')
                        {
                            sorted.Append('\n');
                        }

                        for (int i = 0; i < countIndent; i++)
                        {
                            sorted.Append(indent);
                        }
                        sorted.Append('{');
                        sorted.Append('\n');
                        isNewLine = true;
                        countIndent++;
                    }
                    else if (item == '}')
                    {
                        countIndent--;
                        if (previousItem != '\n')
                        {
                            sorted.Append('\n');
                        }
                        for (int i = 0; i < countIndent; i++)
                        {
                            sorted.Append(indent);
                        }
                        sorted.Append('}');
                        sorted.Append('\n');
                        isNewLine = true;
                    }
                    else
                    {
                        if (isNewLine == true && item == LINE[0])
                        {
                            sorted.Append('\n');
                        }
                        if (isNewLine == true && item != '\n')
                        {
                            for (int i = 0; i < countIndent; i++)
                            {
                                sorted.Append(indent);
                            }
                            if (item == ' ' && (previousItem == ' ' || previousItem == '\n'))
                            {


                            }
                            else
                            {
                                sorted.Append(item);
                            }

                            isNewLine = false;
                        }
                        else if (previousItem != '\n' && item == '\n')
                        {
                            sorted.Append('\n');
                            isNewLine = true;
                        }
                        else
                        {
                            if (item != '\n')
                            {
                                sorted.Append(item);

                            }



                        }

                    }

                    string lastItem = sorted.ToString();
                    int length = lastItem.Length;
                    if (length > 1)
                    {
                        previousItem = lastItem[length - 1];
                    }

                }
                isNewLine = true;
            }

            string output = sorted.ToString();
            if (output[0] == '\n')
            {
                output = output.Remove(0, 1);    
            }
            
            output = output.Remove(output.Length-1, 1);

            output = output.Replace("\n\n", "\n");
            output = output.Replace(" \n", "\n");

            Console.WriteLine(output);
        }
    }
}
