using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstTask
{
    class Program
    {
        static void Main()
        {
            string number = Console.ReadLine();
            long result = 0, intermediate=0,power=1;
            for (int i = number.Length - 1; i >= 0; i--)
            {
                if (i == 0)
                    result += (number[i] - 'A') *power;
                else if ((number[i - 1] >= 97) && (number[i - 1] <= 102))
                {
                    intermediate = ((number[i - 1] - 'a' + 1) * 26 + (number[i] - 'A')) * power;
                    result += intermediate;
                    i--;
                    power *= 168;
                    continue;
                }
                else
                {
                    intermediate = (number[i] - 'A') * power;
                    result += intermediate;
                    power *= 168;
                }
            }
            Console.WriteLine(result);
        }
    }
}