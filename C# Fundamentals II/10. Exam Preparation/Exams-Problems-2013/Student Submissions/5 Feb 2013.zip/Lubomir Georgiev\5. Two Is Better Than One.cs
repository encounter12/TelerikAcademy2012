using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoIsBetterThanOne
{
    class Program
    {
        static bool IsItLucky(long num)
        {
            string stringNum = num.ToString();

            int len = stringNum.Length;
            for (int i = 0; i < len/2; i++)
			{
                if ((stringNum[i] != '3' && stringNum[i] != '5') || (stringNum[len - 1 - i] != '3' && stringNum[len - 1 - i] != '5'))
                {
                    return false;
                }
                if (stringNum[i] != stringNum[len - 1 - i])
                {
                    return false;
                }
			}
            return true;
        }

        static int GetLuckyNumbers(long firstDigit, long lastDigit)
        {
            int num = 0;
            for (long i = firstDigit; i <= lastDigit; i++)
            {
                if (i == 3 || i == 5)
                {
                    num++;
                }
                else if (i / 10 > 0)
                {
                    if (IsItLucky(i))
                    {
                        num++;
                    }
                }
            }
            return num;
        }

        static int Percent(List<int> nums, double minCount)
        {
            nums.Sort();
            for (int i = 0; i < nums.Count(); i++)
            {
                int count = 0;
                for (int j = 0; j < nums.Count(); j++)
                {
                    if (nums[i] >= nums[j])
                    {
                        count++;
                    }
                    else
                    {
                        break;
                    }
                    if (count >= minCount)
                    {
                        return nums[i];
                    }
                }
            } 
            return 0;
        }

        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            string[] nums = line.Split(' ', ',');
            long firstNum = long.Parse(nums[0]);
            long lastNum = long.Parse(nums[1]);
            //Console.WriteLine(firstNum + " " + lastNum);
            int num = GetLuckyNumbers(firstNum, lastNum);
            line = Console.ReadLine();
            string[] listOfNums = line.Split(' ', ',');
            List<int> intList = new List<int>();
            int newNum;
            foreach (var testNum in listOfNums)
            {
                if (int.TryParse(testNum, out newNum))
                {
                    intList.Add(newNum);
                }
            }
            line = Console.ReadLine();
            double percent = double.Parse(line);
            double minCount = (percent * intList.Count())/100;

            int hmm = Percent(intList, minCount);
            Console.WriteLine(num);
            Console.WriteLine(hmm);
        }
    }
}
