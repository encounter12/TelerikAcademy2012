using System;

class Program
{
    static void Main(string[] args)
    {
        string line = Console.ReadLine();
        string[] number = line.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        int[] ground = new int[number.Length];
        for (int i = 0; i < ground.Length; i++)
        {
            ground[i] = int.Parse(number[i]);
        }


        int max = FindMaxValue(ground);
        int best = 0;
        int lenght = 1;

        int expI = 0;
        for (int i = 0; i < ground.Length; i++)
        {
            for (int j = 1; j <= ground.Length; j++)
            {
                int bufferResult = 1;
                int counter = i;
                int lastMove = ground[i];
                int nextMove;
                while (ground[counter] < max)
                {
                    lastMove = ground[counter];
                    counter = counter + j;
                    if (counter > ground.Length - 1)
                    {
                        counter = counter % ground.Length;
                    }
                    nextMove = ground[counter];

                    if (nextMove <= lastMove)
                        break;
                    bufferResult++;
                }
                if (bufferResult > best)
                {
                    best = bufferResult;
                    lenght = j;
                    expI = i;
                }
            }
        }
        //Console.WriteLine(lenght);
        Console.WriteLine(best);
       // Console.WriteLine(expI);
    }

    private static int FindMaxValue(int[] ground)
    {
        int result = int.MinValue;
        for (int i = 0; i < ground.Length; i++)
        {
            if (result < ground[i])
                result = ground[i];
        }
        return result;
    }
}
