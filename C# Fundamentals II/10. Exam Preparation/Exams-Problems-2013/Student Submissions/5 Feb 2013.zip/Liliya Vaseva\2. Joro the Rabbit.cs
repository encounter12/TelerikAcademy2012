using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using _02.JoroTheRabbit;

class Program
{
    public static int totalHopCount = 0;
    public static int currentPosition;
    public static int minPos;
    public static int maxPos;
    public static TreeNod<int> sortedMap; 
   
    static void Main()
    {
        Console.WriteLine("Enter terrain - numbers:");
        int n = 2501;
        int[] bunnyPos = new int[n];
        for (int i = 0; i < n; i++)
        {
            bunnyPos[i] = int.Parse(Console.ReadLine());
        }

        Hashtable LocationHash = new Hashtable();
        Hashtable PostionHash = new Hashtable();
        int minPos = bunnyPos.Min();
        int maxPos = bunnyPos.Max();
        Array.Sort(bunnyPos);
        for (int i = 0; i < bunnyPos.Length; i++)
        {
            PostionHash.Add(bunnyPos[i], i);
        }
        for(int j = -1000; j < 1000; j++)
        {
            int nj = PostionHash.GetHashCode();
            if (nj != null)
            {
                LocationHash.Add(j, 1);
            }
            else
            {
                LocationHash.Add(j, 0);
            }
        }

        sortedMap = new TreeNod<int>(LocationHash);
        for (int i = 0; i < bunnyPos.Length; i++)
        {
            totalHopCount = 0;
            int countright = (bunnyPos[i]);
            
            int countleft = (bunnyPos[i]);
            
        }
        
    }
    public static int traverseleft(int pos)
    {
        bool canjumpmore = false;
        int jumpto;
        if (pos <= minPos)
        {
            return 0;
        }
        int current = sortedMap.GetHashCode();
        int prev = sortedMap.GetHashCode()-1;
        if (current == 1 && prev == 1)
        {
            jumpto = (2 * (pos - 1)) - pos;
            if (sortedMap.GetHashCode() == 0)
            {
                totalHopCount++;
                canjumpmore = true;
                currentPosition = jumpto;
                sortedMap.GetHashCode();
            }
        }
        if (canjumpmore)
        {
            traverseleft(currentPosition);
        }
        return totalHopCount;
    }
    public static int traverseright(int pos)
    {
        bool canjumpmore = false;
        int jumpto;
        if (pos >= maxPos)
        {
            return 0;
        }
        int current = sortedMap.GetHashCode();
        int next = sortedMap.GetHashCode() +1;
        if (current == 1 && next == 1)
        {
            jumpto = (2 * (pos + 1)) - pos;
            if (sortedMap.GetHashCode() == 0)
            {
                totalHopCount++;
                canjumpmore = true;
                currentPosition = jumpto;
                sortedMap.GetHashCode();
            }
        }
        if (canjumpmore)
        {
            traverseright(currentPosition);
        }
        return totalHopCount;
    }

}