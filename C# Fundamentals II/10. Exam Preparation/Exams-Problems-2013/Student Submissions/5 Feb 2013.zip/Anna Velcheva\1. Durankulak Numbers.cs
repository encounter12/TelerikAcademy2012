using System;
using System.Text;
using System.Collections.Generic;

class DurankulakNumbers
{
    static void Main(string[] args)
    {
        string input = Console.ReadLine();

        StringBuilder builderOfDigit = new StringBuilder();
        List<int> allDigitsInDecimal = new List<int>();
        for (int i = 0; i < input.Length; i++)
        {
            if (Char.IsUpper(input[i]))
            {
                builderOfDigit.Append(input[i]);
                allDigitsInDecimal.Add(ConvertDigitToDecimal(builderOfDigit.ToString()));
                builderOfDigit.Clear();
            }
            else
            {
                builderOfDigit.Append(input[i]);
            }
        }

        long result = 0;
        for (int i = allDigitsInDecimal.Count - 1, u = 0; i >= 0; i--, u++)
        {
            result += allDigitsInDecimal[i] * ((long)Math.Pow(168, u));
        }

        Console.WriteLine(result);
    }

    static int ConvertDigitToDecimal(string digit)
    {
        if (digit.Length == 1)
        {
            return (int)digit[0] - 65;
        }
        else // digit.Length == 2
        {
            int result = ((int)digit[0] - 96) * 26 + (int)digit[1] - 65;
            return result;
        }
    }
}
