using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
class Laser
{
    static int w;
    static int h;
    static int d;
    static bool[, ,] cube;
    static int startW;
    static int startH;
    static int startD;
    static int dirW;
    static int dirH;
    static int dirD;
    static bool stop = false;
 
 
    static void Main()
    {
        string[] dimensons = Console.ReadLine().Split(' ');
        w = int.Parse(dimensons[0]);
        h = int.Parse(dimensons[1]);
        d = int.Parse(dimensons[2]);
        cube = new bool[w, h, d];
 
        string[] startPosition = Console.ReadLine().Split(' ');
        startW = int.Parse(startPosition[0]);
        startH = int.Parse(startPosition[1]);
        startD = int.Parse(startPosition[2]);
        cube[startW, startH, startD] = true;
 
        string[] direections = Console.ReadLine().Split(' ');
        dirW = int.Parse(direections[0]);
        dirH = int.Parse(direections[1]);
        dirD = int.Parse(direections[2]);
 
        while (!stop)
        {
            MoveOnePosition();
        }
        Console.WriteLine("{0} {1} {2}", startW, startH, startD);
    }
 
    private static void MoveOnePosition()
    {
        if (startW + dirW < w && startW + dirW >= 0 &&
            startH + dirH < h && startH + dirH >= 0 &&
            startD + dirD < d && startD + dirD >= 0)
        {
            startW = startW + dirW;
            startH = startH + dirH;
            startD = startD + dirD;
            if (startW == w - 1)
            {
                //startW = startW - dirW;
                dirW *= -1;
                //return;
            }
            else if (startW == 0)
            {
                //startW = startW - dirW;
                dirW *= -1;
                //return;
            }
 
            if (startH == h-1)
            {
                //startH = startH - dirH;
                dirH *= -1;
               // return;
            }
            else if (startH == 0)
            {
                //startH = startH - dirH;
                dirH *= -1;
                //return;
            }
            if (startD == d-1)
            {
                //startD = startD - dirD;
                dirD *= -1;
                //return;
            }
            else if (startD == 0)
            {
                //startD = startD - dirD;
                dirD *= -1;
                //return;
            }
            if (cube[startW, startH, startD])
            {
                startW = startW - dirW;
                startH = startH - dirH;
                startD = startD - dirD;
                stop = true;
                return;
            }
            cube[startW, startH, startD] = true;
 
 
        }
        //else
        //{
        //    if (startW == w)
        //    {
        //        dirW *= -1;
        //    }
        //    else if (startW == -1)
        //    {
        //        dirW *= -1;
        //    }
 
        //    if (startH == h)
        //    {
        //        dirH *= -1;
        //    }
        //    else if (startH == -1)
        //    {
        //        dirH *= -1;
        //    }
        //    if (startD == d)
        //    {
        //        dirD *= -1;
        //    }
        //    else if (startD == -1)
        //    {
        //        dirD *= -1;
        //    }
        //}
    }
}