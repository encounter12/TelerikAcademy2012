using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
class Laser
{
    static bool[, ,] cube;
    static int width;
    static int height;
    static int depth;
    static Point direction;
 
    private static void BurnEdges()
    {
        for (int row = 0; row < width; row++)
        {
            cube[row, 0, 0] = true;
            cube[row, height - 1, 0] = true;
            cube[row, 0, depth - 1] = true;
            cube[row, height - 1, depth - 1] = true;
        }
        for (int col = 0; col < height; col++)
        {
            cube[0, col, 0] = true;
            cube[width -1, col, 0] = true;
            cube[0, col, depth - 1] = true;
            cube[width - 1, col, depth - 1] = true;
        }
        for (int dep = 0; dep < depth; dep++)
        {
            cube[0, 0, dep] = true;
            cube[0, height - 1, dep] = true;
            cube[width - 1, 0, dep] = true;
            cube[width - 1, height - 1, dep] = true;
        }
    }
    static void BurnCells(int width, int height, int depth)
    {
        cube[width, height, depth] = true;
    }
    static bool CheckNextPoint(Point point)
    {
        int x = point.x;
        int y = point.y;
        int z = point.z;
        if (cube[x, y, z] == false)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
 
    static void Main()
    {
        string[] input = Console.ReadLine().Split();
        width = int.Parse(input[0]) + 1;
        height = int.Parse(input[1]) + 1;
        depth = int.Parse(input[2]) + 1;
        cube = new bool[width, height, depth];
        BurnEdges();
        input = Console.ReadLine().Split();
        int startW = int.Parse(input[0]);
        int startH = int.Parse(input[1]);
        int startD = int.Parse(input[2]);
        BurnCells(startW, startH, startD);
        Point currentPoint = new Point(startW, startH, startD);
        input = Console.ReadLine().Split();
        int directionX = int.Parse(input[0]);
        int directionY = int.Parse(input[1]);
        int directionZ = int.Parse(input[2]);
        direction = new Point(directionX, directionY, directionZ);
         
        while (PointPossible(currentPoint))
        {
             
            BurnCells(currentPoint.x, currentPoint.y, currentPoint.z);
            Point nextPoint = GetNextPoint(currentPoint);
            currentPoint = nextPoint;
        }
        Console.WriteLine("{0} {1} {2}", currentPoint.x, currentPoint.y, currentPoint.z);
    }
 
    private static void GetNewDirection(Point currentPoint)
    {
        int x = currentPoint.x + direction.x;
        int y = currentPoint.y + direction.y;
        int z = currentPoint.z + direction.z;
        if (x <= 0 || x >= width)
        {
            direction.x = -direction.x;
        }
        if (y <= 0 || y >= height)
        {
            direction.y = -direction.y;
        }
        if (z <= 0 || z >= depth)
        {
            direction.z = -direction.z;
        }
    }
 
    private static Point GetNextPoint(Point currentPoint)
    {
        int x = currentPoint.x + direction.x;
        int y = currentPoint.y + direction.y;
        int z = currentPoint.z + direction.z;
        return new Point(x, y, z);
    }
 
    private static bool PointPossible(Point currentPoint)
    {
        GetNewDirection(currentPoint);
        int x = currentPoint.x + direction.x;
        int y = currentPoint.y + direction.y;
        int z = currentPoint.z + direction.z;
        if (cube[x, y, z] == false)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
 
     
 
}
 
class Point
{
    public int x { get; set; }
    public int y { get; set; }
    public int z { get; set; }
 
    public Point(int x, int y, int z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }
}