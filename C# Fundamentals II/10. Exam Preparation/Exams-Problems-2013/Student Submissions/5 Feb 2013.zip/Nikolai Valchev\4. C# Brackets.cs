using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Problem4
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            string S=Console.ReadLine();
            string[] lines=new string[number];
            string lin;
            List<string> list = new List<string>();
            List<string> list2 = new List<string>();
            StringBuilder sb=new StringBuilder();
            lines[0]=Console.ReadLine();
            string regex = " ";
            for (int i = 1; i < lines.Length; i++)
            {
                lin=Console.ReadLine();
                if(lin!=string.Empty)
                {
                    if (lin != String.Empty)
                    {
                        lines[i] = lin;
                    }
                }

            }
            
            for (int i = 0; i <lines.Length; i++)
			{
                string[] words=lines[i].Split('{');
                for (int j = 0; j < words.Length; j++)
                {
                   if (words[j] == String.Empty) list.Add("{");
                    else
                    {
                        list.Add(words[j]);
                    }
                }
               
			}

            Console.WriteLine(list[0]);
            Console.WriteLine(S + list[1]);
            Console.WriteLine(S + list[2]);
            Console.WriteLine(S + list[3]);
            Console.WriteLine(list[4]);
        }
    }
}
