using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace JoroTheRabbit
{
    class Program
    {
        static int Jump(int[] positions, int step, int start,int posCount)
        {
            int[] visited = new int[posCount];
            visited[start] = 1;
            int count=1;
            int next=start+step;
            for (int i = 0; i < posCount; i++)
            {
                if (next >= posCount) next = next - posCount;
                if (visited[next] == 0 && (positions[start] < positions[next]))
                {
                    visited[next] = 1;
                    start = next;
                    next = start + step;
                    count++;
                }
                else
                    return count;
            }
            return 0;
        }
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] strNums;
            strNums = input.Split(new char[] { ',',' ' }, StringSplitOptions.RemoveEmptyEntries);
            int[] positions = new int[strNums.Length];
            int posCount = 0;
            int sredno = 0;
            foreach (var num in strNums)
            {
                positions[posCount] = int.Parse(num);
                sredno = sredno + positions[posCount];
                posCount++;
            }
            sredno = (sredno / posCount);
            int biggestValue=0;
            int value;
            for (int start = 0; start < posCount; start++)
            {
                if (positions[start] > sredno) continue;
                for (int step = 1; step < posCount; step++)
                {
                    value=Jump(positions, step, start, posCount);
                    if (value > biggestValue) biggestValue = value;
                    if (biggestValue > 1000) break;
                }
                if (biggestValue > 1000) break;
            }
            Console.WriteLine(  biggestValue);
        }
    }
}
