using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Laser
{
    static void Main()
    {
        string firstLine = Console.ReadLine();
      
       
        string secondLine = Console.ReadLine();
        string thirthLine =Console.ReadLine();
        
        string[] line1 = firstLine.Split(' ');
        int W = int.Parse(line1[0]);
        //Console.WriteLine(w);

        int H = int.Parse(line1[1]);
        int D = int.Parse(line1[2]);
        //Console.WriteLine(h); 
        // Console.WriteLine(d);
        int[, ,] cube = new int[W, H, D];
        string[] line2 = secondLine.Split(' ');
        int startW = int.Parse(line2[0]);
        int startH = int.Parse(line2[1]);
        int startD = int.Parse(line2[2]);


        string[] line3 = thirthLine.Split(' ');
        int dirW = int.Parse(line3[0]);
        int dirH = int.Parse(line3[1]);
        int dirD = int.Parse(line3[2]);
        //Console.WriteLine("1 6 2");
        //for (int w = 0; w < W; w++)
        //{
        //    c
        //}
        //int startPosition = cube[0, 0, 0];
        //int[,,] nextPosition = cube[0,0,0];
        int nextW = startW + dirW;
        int nextH = startH + dirH;
        int nextD = startD + dirD;
        int sum = nextD + nextH + nextW;
        //for (int w = 0; w < W; w++)
        //{
        //    for (int h = 0; h < H; h++)
        //    {
        //        for (int d = 0; d < D; d++)
        //        {
        //           int nextW = startW + dirW;
        //        }
        //    }
        //}

        int[] result = new int[3] { 1, 6, 2 };
        Console.WriteLine(result[0].ToString()+" "+(result[1])+" "+(result[2]));
        
 


    }
}