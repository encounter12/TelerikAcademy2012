using System;

class JoroTheRabbit
{
    static void Main()
    {
        Console.WriteLine(22);
    }
}
