namespace TaskThree
{
    using System;
    using System.Collections.Generic;

    public class Laser
    {
        public struct Point
        {
            public int width;
            public int height;
            public int depth;

            public Point(int width, int height, int depth)
            {
                this.width = width;
                this.height = height;
                this.depth = depth;
            }
        }

        public static void Main(string[] args)
        {
            // cube dimensions
            string cubeDimensionsString = Console.ReadLine();
            string[] cubeDimensions = cubeDimensionsString.Split(' ');
            int cubeWidth = int.Parse(cubeDimensions[0]);
            int cubeHeight = int.Parse(cubeDimensions[1]);
            int cubeDepth = int.Parse(cubeDimensions[2]);

            // laser start coordinates
            string laserStartCoordinatesString = Console.ReadLine();
            string[] laserStartCoordinates = laserStartCoordinatesString.Split(' ');
            int startW = int.Parse(laserStartCoordinates[0]);
            int startH = int.Parse(laserStartCoordinates[1]);
            int startD = int.Parse(laserStartCoordinates[2]);
            Point laserStartPosition = new Point(startW, startH, startD);

            // laser direction
            string laserDirectionString = Console.ReadLine();
            string[] laserDirection = laserDirectionString.Split(' ');
            int dirW = int.Parse(laserDirection[0]);
            int dirH = int.Parse(laserDirection[1]);
            int dirD = int.Parse(laserDirection[2]);

            // build a list with edges positions to avoid them when moving the laser
            List<Point> edgesPositions = new List<Point>();
            for (int i = 0; i < cubeWidth; i++)
            {
                edgesPositions.Add(new Point(i, 0, 0));
                edgesPositions.Add(new Point(i, 0, cubeDepth));
                edgesPositions.Add(new Point(i, cubeHeight, 0));
                edgesPositions.Add(new Point(i, cubeHeight, cubeDepth));
            }
            for (int i = 0; i < cubeHeight; i++)
            {
                edgesPositions.Add(new Point(0, i, 0));
                edgesPositions.Add(new Point(cubeWidth, i, 0));
                edgesPositions.Add(new Point(cubeWidth, i, cubeDepth));
                edgesPositions.Add(new Point(0, i, cubeDepth));
            }
            for (int i = 0; i < cubeDepth; i++)
            {
                edgesPositions.Add(new Point(0, 0, i));
                edgesPositions.Add(new Point(cubeWidth, 0, i));
                edgesPositions.Add(new Point(0, cubeHeight, i));
                edgesPositions.Add(new Point(cubeWidth, cubeHeight, i));
            }

            // laser movement
            List<Point> visitedPositions = new List<Point>();
            visitedPositions.Add(laserStartPosition);

            Point laserCurrentPosition = new Point(laserStartPosition.width, laserStartPosition.height, laserStartPosition.depth);
            Point laserNextPosition = new Point();
            while (true)
            {
                // check current position for reflection and change direction
                if (IsOnWall(laserCurrentPosition, cubeWidth, cubeHeight, cubeDepth))
                {
                    if (laserCurrentPosition.width == 0 || laserCurrentPosition.width == cubeWidth)
                    {
                        dirW = dirW * -1;
                    }
                    if (laserCurrentPosition.height == 0 || laserCurrentPosition.height == cubeHeight)
                    {
                        dirH = dirH * -1;
                    }
                    if (laserCurrentPosition.depth == 0 || laserCurrentPosition.depth == cubeDepth)
                    {
                        dirD = dirD * -1;
                    }
                }

                // calculate the next position
                laserNextPosition.width = laserCurrentPosition.width + dirW;
                laserNextPosition.height = laserCurrentPosition.height + dirH;
                laserNextPosition.depth = laserCurrentPosition.depth + dirD; 

                // check if next position is visited
                if (visitedPositions.Contains(laserNextPosition))
                {
                    break;
                }

                // check if next position is on edge
                if (edgesPositions.Contains(laserNextPosition))
                {
                    break;
                }
                                
                // if we are here - move the laser
                visitedPositions.Add(laserNextPosition);
                laserCurrentPosition.width = laserNextPosition.width;
                laserCurrentPosition.height = laserNextPosition.height;
                laserCurrentPosition.depth = laserNextPosition.depth;               
            }

            Console.WriteLine(laserCurrentPosition.width + " " + laserCurrentPosition.height + " " + laserCurrentPosition.depth);
        }

        public static bool IsOnWall(Point point, int cubeWidth, int cubeHeight, int cubeDepth)
        {
            if (point.width == 0 || point.width == cubeWidth) return true;
            if (point.height == 0 || point.height == cubeHeight) return true;
            if (point.depth == 0 || point.depth == cubeDepth) return true;

            return false;
        }
    }
}
