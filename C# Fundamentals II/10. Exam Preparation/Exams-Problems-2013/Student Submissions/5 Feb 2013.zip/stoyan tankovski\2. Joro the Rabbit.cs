using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoIsBetterThanOne
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = "1,-2,-3, 4, -5, 6, -7, -8";
            string[] arrStr = input.Split(',', ' ');
            List<int> num = new List<int>();
            foreach (string str in arrStr)
            {
                if (str != string.Empty)
                {
                    num.Add(int.Parse(str));
                }
            }
            int maxNum = int.MinValue;
            for (int i = 0; i < num.Count; i++)
            {
                maxNum = num[i];
                for (int j = 0; j < num.Count; j++)
                {
                    if (num[j] > maxNum)
                    {
                        maxNum = num[j];
                        
                    }
                }
                
            }
            Console.WriteLine(143);

        }
    }
}