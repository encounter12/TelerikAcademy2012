using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class Task01
{
    static void Main()
    {
        string input = Console.ReadLine();
        BigInteger count = 0;
        int pow = 0;

        char[] array = input.ToCharArray();

        if (array.Length == 1)
        {
            count = count + ((int)array[0] - 65);
        }

        else if (array.Length == 2)
        {
            for (int i = 0; i < array.Length - 1; i++)
            {
                if ((((int)array[i]) >= 65) && ((int)array[i] <= 91))
                {
                    count = count + (((int)array[i] - 65) * 168) + ((int)array[i+1] - 65);
                    break;
                }
                else if ((((int)array[i]) >= 97) && ((int)array[i] <= 102))
                {
                    count = count + (((int)array[i] - 96) * 26) + (int)array[i + 1] - 65;
                    break;
                }
            }
        }

        else
        {

            for (int i = array.Length - 2; i >= 0; i--)
            {
                if (i == 0)
                {
                    if ( ((int)array[i] >= 65) && ((int)array[i] <= 91) )
                    {
                        pow++;
                        count = count + ((BigInteger)array[i] - 65) * (BigInteger)Math.Pow(168, pow);
                    }
                    else if ((((int)array[i]) >= 97) && ((int)array[i] <= 102))
                    {
                        count = count + ((((BigInteger)array[i] - 96) * 26) + (BigInteger)array[i + 1] - 65) * (BigInteger)Math.Pow(168, pow);
                    }
                }
                else if (((((int)array[i]) >= 65) && ((int)array[i] <= 91)) && ((((int)array[i-1]) >= 65) && ((int)array[i-1] <= 91)))
                {
                    pow++;
                    count = count + ((BigInteger)array[i] - 65) * (BigInteger)Math.Pow(168, pow); 
                }
                else if (((((int)array[i]) >= 65) && ((int)array[i] <= 91)) && ((((int)array[i - 1]) >= 97) && ((int)array[i - 1] <= 102)))
                {
                    pow++;
                }
                else if ((((int)array[i]) >= 97) && ((int)array[i] <= 102))
                {
                    count = count + ((((BigInteger)array[i] - 96) * 26) + (BigInteger)array[i + 1] - 65) * (BigInteger)Math.Pow(168, pow);
                }
            }

            if ((((int)array[array.Length - 2] >= 65) && ((int)array[array.Length - 2] <= 91)) && (((int)array[array.Length - 1] >= 65) && ((int)array[array.Length - 2] <= 91)))
            {
                count = count + ((int)array[array.Length - 1] - 65);
            }
        }
        Console.WriteLine(count);
    }
}