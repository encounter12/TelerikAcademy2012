using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    private static char[] delim = { ' ','.',',' };
    static char[] alphaBet = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
    static void Main(string[] args)
    {
        StringBuilder p = new StringBuilder();
        List<string> l = new List<string>();
        Array.Sort(alphaBet);
        String text = Console.ReadLine().Trim();
        string[] arr = text.Split(delim, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < arr.Length; i++)
        {
            p.Append(arr[i]);
        }
        text = p.ToString();
        ulong sum = 0;
        int step = 0;
        if (text.Length == 1) Console.WriteLine(Array.BinarySearch(alphaBet, char.ToLower(text[0])));
        else
        {
            for (int i = 0; i < text.Length; i++)
            {
                if (char.IsLower(text[i]))
                {
                    l.Add(text[i] + "" + text[i + 1]);
                    i++;
                }
                else if (char.IsUpper(text[i])) l.Add(text[i].ToString());
            }

            for (int i = l.Count - 1; i >= 0; i--)
            {

                if (l[i].Length == 2)
                {
                    char ch = l[i][0];
                    char cha = char.ToLower(l[i][1]);
                    int ll = (((Array.BinarySearch(alphaBet, ch) + 1) * 26)) + Array.BinarySearch(alphaBet, cha);
                    sum += (ulong)(Math.Pow(168, step) * ll);
                    step++;
                }
                else if (l[i].Length == 1)
                {
                    char ch = char.ToLower(l[i][0]);                  
                    sum += (ulong)(Math.Pow(168, step) * (Array.BinarySearch(alphaBet, ch)));
                    step++;
                }

            }
            Console.WriteLine(sum);
        }
    }
}
