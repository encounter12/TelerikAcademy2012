using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace _1.Durankulak
{
    class Program
    {
        static void Main()
        {
            string number = Console.ReadLine();
            string current = string.Empty;
            int step = 0;
            long sum = 0;
 
            for (int i = number.Length - 1; i >= 0; i--)
            {
                if (i - 1 >= 0)
                {
                    if (number[i - 1] >= 'a' && number[i - 1] <= 'z')
                    {
                        current += number[i - 1].ToString() + number[i].ToString();
                        i--;
                    }
                    else
                    {
                        current += number[i].ToString();
                    }
                }
                else
                {
                    current += number[i];
                }
 
                sum += ConvertToDec(current) * (long)Math.Pow(168, step);
                current = string.Empty;
                step++;
            }
 
            Console.WriteLine(sum);
        }
 
        private static int ConvertToDec(string current)
        {
            int result = 0;
            for (int i = 0; i < current.Length; i++)
            {
                if (current[i] >= 'a' && current[i] <= 'z')
                {
                    result += CharToNum(current[i]) * 26;
                    continue;
                }
 
                if (current[i] >= 'A' && current[i] <= 'Z')
                {
                    result += CharToNum(current[i]);
                }
            }
 
            return result;
        }
   
        private static int CharToNum(char c)
        {
            if (c >= 'a' && c <= 'z')
            {
                return c - 96;
            }
            else
            {
                return c - 65;
            }
             
        }
    }
}