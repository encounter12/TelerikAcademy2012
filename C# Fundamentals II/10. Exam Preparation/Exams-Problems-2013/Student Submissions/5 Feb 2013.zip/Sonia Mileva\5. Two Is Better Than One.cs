using System;
using System.Globalization;
using System.Threading;

namespace _5
{
    class TeoOne
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("bg-BG");
            string task1In = Console.ReadLine();
            //
            string task2List = Console.ReadLine();
            byte perc = byte.Parse(Console.ReadLine());

            //task1
            string[] task1Arr = task1In.Split(' ');
            string aStr = task1Arr[0];
            string bStr = task1Arr[1];
            uint a = uint.Parse(aStr);
            uint b = uint.Parse(bStr);
            int lucky = 0;
            bool luckyDig = true;
            for (uint i = a + 1; i < b; i++)
            {
                luckyDig = true;
                string number = i.ToString();
                //Console.WriteLine(number);
                for (int j = 0; j < number.Length; j++)
                {
                    if (number[j] != '5' && number[j] != '3')
                    {
                        luckyDig = false;
                    }
                    else if (number[j] != number[number.Length - j - 1])
                    {
                        luckyDig = false;
                    }

                }
                if (luckyDig) lucky++;
            }
            Console.WriteLine(lucky);

            //task2t
            double p = perc / 100.0;
            Math.Round(p, 2);
            string[] arrStr = task2List.Split(',');
            int[] arr = new int[arrStr.Length];
            int result = 0;
            for (int i = 0; i < arrStr.Length; i++)
            {
                arr[i] = int.Parse(arrStr[i]);
            }
            Array.Sort(arr);
            for (byte i = 1; i < arr.Length - 1; i++)
            {
                if (p * arr.Length > i)//problen
                {

                    result = arr[i]; break;
                }
            }
            Console.WriteLine(result);
        }

    }
}