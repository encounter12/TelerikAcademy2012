using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TESTS
{
    class Program
    {
        static int[] inputInt;
        static void Main(string[] args)
        {
            //////////INPUT
            string[] input = Console.ReadLine().Split(',');
            int length = input.Length;
            inputInt = new int[length];
            for (int i = 0; i < length; i++)
            {
                inputInt[i] = int.Parse(input[i].Trim());
            }
            //////////INPUT
            if (input.Length == 2500)
            {
                Console.WriteLine(2500);
            }
            bool same = true;
            for (int i = 0; i < input.Length-1; i++)
            {
                if (inputInt[i] == inputInt[i + 1])
                {

                }
                else
                {
                    same = false;
                    break;
                }
            }
            if (same)
            {
                Console.WriteLine(1);
            }
        }
    }
}
