using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

class Program
{
    static void Main()
    {
        string number = Console.ReadLine();
        BigInteger numberInt = 0;
        BigInteger[] arr = new BigInteger[17];
        arr[0] = 1;
        arr[1] = 26;
        arr[2] = 168;
        arr[3] = 168 * 26;
        arr[4] = 168 * 168;
        arr[5] = arr[4] * 26;
        arr[6] = arr[4] * 168;
        arr[7] = arr[6] * 26;
        arr[8] = arr[6] * 168;
        arr[9] = arr[8] * 26;
        arr[10] = arr[8] * 168;
        arr[11] = arr[10] * 26;
        arr[12] = arr[10] * 168;
        arr[13] = arr[12] * 26;
        arr[14] = arr[12] * 168;
        arr[15] = arr[14] * 26;
        arr[16] = arr[14] * 168;
        int c = 0;
        for (int i = (number.Length - 1); i >= 0; i--, c++)
        {
            if ((int)number[i] > 96)
            {
                numberInt += (BigInteger)(number[i] - 96) * arr[c];
            }
            else
            {
                numberInt += (BigInteger)(number[i] - 65) * arr[c];
            }
        }
        Console.WriteLine(numberInt);
    }
}

