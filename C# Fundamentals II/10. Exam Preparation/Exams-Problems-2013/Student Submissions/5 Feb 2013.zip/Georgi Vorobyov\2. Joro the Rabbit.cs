using System;

namespace JoroTheRabbit
{
    class JoroTheRabbit
    {
        static void Print(int[] array)
        {
            foreach (var number in array)
            {
                Console.WriteLine(number);
            }
        }

        static void Input(string[] input, int[] array)
        {
            for (int i = 0, l = input.Length; i < l; i++) array[i] = int.Parse(input[i]);
        }

        static int bestCount = 1;

        static void ForEachStep(int[] array, int startIndex, int stepLenght)
        {
            int count = 1;
            int arrayLenght = array.Length - 1;
            int lastStart = startIndex;
            int newStart = 0;
            int left = 0;

            while (true)
            {
                int debug = array[lastStart];
                if (lastStart + stepLenght > arrayLenght) //ako teku6tiq indeks + stypkite e po-golqm ot masiwa
                {
                    left = arrayLenght - lastStart;
                    int incrementStep = (stepLenght - left) - 1; //-1, za6toto 6te wyrne broq ot 1, a ne ot 0
                    newStart = incrementStep;
                }
                else
                {
                    newStart = lastStart + stepLenght;
                }

                if (array[newStart] <= array[lastStart])
                {
                    break;
                }
                lastStart = newStart;
                count++;
            }

            if (bestCount < count)
            {
                bestCount = count;
            }
        }

        static void StartStep(int[] array, int startIndex)// ako razmera e 8 => maxStep == 7
        {
            for (int steps = 1, length = array.Length - 1; steps < length; steps++) //broq na stypkite: prez 1, prez 2, prez 3...
            {
                ForEachStep(array, startIndex, steps);
            }
        }

        static void Steps(int[] array)
        {
            for (int startIndex = 0, length = array.Length; startIndex < length; startIndex++)
            {
                StartStep(array, startIndex); //starirame ot 0, 1, 2, 3, 4, 5, 6...
            }
        }

        static void Main()
        {
            string[] input = Console.ReadLine().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);//"1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0".Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);//"1, -2, -3, 4, -5, 6, -7, -8".Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries); //Console.ReadLine().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            int[] array = new int[input.Length];

            Input(input, array);

            Steps(array);

            Console.WriteLine(bestCount);
        }
    }
}
