using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class Program
{
    static BigInteger GetNumber(string number)
    {
        number = number.ToUpper();
        int result = number[number.Length - 1] - 65;
        for (int i = number.Length - 2; i >= 0; i--)
        {
            if (i == number.Length - 2)
            {
                result += (number[i] - 64) * 26;
            }
        }

        return result;
    }

    static BigInteger ProcessArr(string[] input)
    {
        BigInteger result = GetNumber(input[0]);
        for (int i = 1, power = 1; i < input.Length; i++, power++)
        {
            BigInteger tempNum = GetNumber(input[i]);
            result += tempNum * PowerOfNumber(power);
        }

        return result;
    }

    static BigInteger PowerOfNumber(int power)
    {
        BigInteger result = 1;
        for (int i = 0; i < power; i++)
        {
            result *= 168;
        }

        return result;
    }

    static string[] SplitInputInArr(string input)
    {
        List<string> output = new List<string>();
        for (int i = input.Length - 1; i >= 0; i--)
        {
            if (i > 0 && char.IsUpper(input[i]) && char.IsLower(input[i - 1]))
            {
                output.Add("" + input[i - 1] + input[i]);
                i -= 1;
            }
            else if (char.IsUpper(input[i]))
            {
                output.Add("" + input[i]);
            }
        }

        return output.ToArray();
    } 
    
    static void Main()
    {
        string input = Console.ReadLine();

        Console.WriteLine(ProcessArr(SplitInputInArr(input)));
    }
}   