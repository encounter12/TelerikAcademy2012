using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
  
  
class DurankulakNumbers
{
    static void Main()
    {
        string durankulak = Console.ReadLine();
  
        long decimalRep = 0;
  
        List<long> dkList = new List<long>();
  
        for (int i = 0; i < durankulak.Length; i++)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(durankulak[i]);
            if (char.IsUpper(durankulak[i]) == false)
            {
                sb.Append(durankulak[i + 1]);
                i++;
            }
            string result = sb.ToString();
            switch (result)
            {
                case "A": dkList.Add(0); break;
                case "B": dkList.Add(1); break;
                case "C": dkList.Add(2); break;
                case "D": dkList.Add(3); break;
                case "E": dkList.Add(4); break;
                case "F": dkList.Add(5); break;
                case "G": dkList.Add(6); break;
                case "H": dkList.Add(7); break;
                case "I": dkList.Add(8); break;
                case "J": dkList.Add(9); break;
                case "K": dkList.Add(10); break;
                case "L": dkList.Add(11); break;
                case "M": dkList.Add(12); break;
                case "N": dkList.Add(13); break;
                case "O": dkList.Add(14); break;
                case "P": dkList.Add(15); break;
                case "Q": dkList.Add(16); break;
                case "R": dkList.Add(17); break;
                case "S": dkList.Add(18); break;
                case "T": dkList.Add(19); break;
                case "U": dkList.Add(20); break;
                case "V": dkList.Add(21); break;
                case "W": dkList.Add(22); break;
                case "X": dkList.Add(23); break;
                case "Y": dkList.Add(24); break;
                case "Z": dkList.Add(25); break;
                case "aA": dkList.Add(26); break;
                case "aB": dkList.Add(27); break;
                case "aC": dkList.Add(28); break;
                case "aD": dkList.Add(29); break;
                case "aE": dkList.Add(30); break;
                case "aF": dkList.Add(31); break;
                case "aG": dkList.Add(32); break;
                case "aH": dkList.Add(33); break;
                case "aI": dkList.Add(34); break;
                case "aJ": dkList.Add(35); break;
                case "aK": dkList.Add(36); break;
                case "aL": dkList.Add(37); break;
                case "aM": dkList.Add(38); break;
                case "aN": dkList.Add(39); break;
                case "aO": dkList.Add(40); break;
                case "aP": dkList.Add(41); break;
                case "aQ": dkList.Add(42); break;
                case "aR": dkList.Add(43); break;
                case "aS": dkList.Add(44); break;
                case "aT": dkList.Add(45); break;
                case "aU": dkList.Add(46); break;
                case "aV": dkList.Add(47); break;
                case "aW": dkList.Add(48); break;
                case "aX": dkList.Add(49); break;
                case "aY": dkList.Add(50); break;
                case "aZ": dkList.Add(51); break;
                case "bA": dkList.Add(52); break;
                case "bB": dkList.Add(53); break;
                case "bC": dkList.Add(54); break;
                case "bD": dkList.Add(55); break;
                case "bE": dkList.Add(56); break;
                case "bF": dkList.Add(57); break;
                case "bG": dkList.Add(58); break;
                case "bH": dkList.Add(59); break;
                case "bI": dkList.Add(60); break;
                case "bJ": dkList.Add(61); break;
                case "bK": dkList.Add(62); break;
                case "bL": dkList.Add(63); break;
                case "bM": dkList.Add(64); break;
                case "bN": dkList.Add(65); break;
                case "bO": dkList.Add(66); break;
                case "bP": dkList.Add(67); break;
                case "bQ": dkList.Add(68); break;
                case "bR": dkList.Add(69); break;
                case "bS": dkList.Add(70); break;
                case "bT": dkList.Add(71); break;
                case "bU": dkList.Add(72); break;
                case "bV": dkList.Add(73); break;
                case "bW": dkList.Add(74); break;
                case "bX": dkList.Add(75); break;
                case "bY": dkList.Add(76); break;
                case "bZ": dkList.Add(77); break;
                case "cA": dkList.Add(78); break;
                case "cB": dkList.Add(79); break;
                case "cC": dkList.Add(80); break;
                case "cD": dkList.Add(81); break;
                case "cE": dkList.Add(82); break;
                case "cF": dkList.Add(83); break;
                case "cG": dkList.Add(84); break;
                case "cH": dkList.Add(85); break;
                case "cI": dkList.Add(86); break;
                case "cJ": dkList.Add(87); break;
                case "cK": dkList.Add(88); break;
                case "cL": dkList.Add(89); break;
                case "cM": dkList.Add(90); break;
                case "cN": dkList.Add(91); break;
                case "cO": dkList.Add(92); break;
                case "cP": dkList.Add(93); break;
                case "cQ": dkList.Add(94); break;
                case "cR": dkList.Add(95); break;
                case "cS": dkList.Add(96); break;
                case "cT": dkList.Add(97); break;
                case "cU": dkList.Add(98); break;
                case "cV": dkList.Add(99); break;
                case "cW": dkList.Add(100); break;
                case "cX": dkList.Add(101); break;
                case "cY": dkList.Add(102); break;
                case "cZ": dkList.Add(103); break;
                case "dA": dkList.Add(104); break;
                case "dB": dkList.Add(105); break;
                case "dC": dkList.Add(106); break;
                case "dD": dkList.Add(107); break;
                case "dE": dkList.Add(108); break;
                case "dF": dkList.Add(109); break;
                case "dG": dkList.Add(110); break;
                case "dH": dkList.Add(111); break;
                case "dI": dkList.Add(112); break;
                case "dJ": dkList.Add(113); break;
                case "dK": dkList.Add(114); break;
                case "dL": dkList.Add(115); break;
                case "dM": dkList.Add(116); break;
                case "dN": dkList.Add(117); break;
                case "dO": dkList.Add(118); break;
                case "dP": dkList.Add(119); break;
                case "dQ": dkList.Add(120); break;
                case "dR": dkList.Add(121); break;
                case "dS": dkList.Add(122); break;
                case "dT": dkList.Add(123); break;
                case "dU": dkList.Add(124); break;
                case "dV": dkList.Add(125); break;
                case "dW": dkList.Add(126); break;
                case "dX": dkList.Add(127); break;
                case "dY": dkList.Add(128); break;
                case "dZ": dkList.Add(129); break;
                case "eA": dkList.Add(130); break;
                case "eB": dkList.Add(131); break;
                case "eC": dkList.Add(132); break;
                case "eD": dkList.Add(133); break;
                case "eE": dkList.Add(134); break;
                case "eF": dkList.Add(135); break;
                case "eG": dkList.Add(136); break;
                case "eH": dkList.Add(137); break;
                case "eI": dkList.Add(138); break;
                case "eJ": dkList.Add(139); break;
                case "eK": dkList.Add(140); break;
                case "eL": dkList.Add(141); break;
                case "eM": dkList.Add(142); break;
                case "eN": dkList.Add(143); break;
                case "eO": dkList.Add(144); break;
                case "eP": dkList.Add(145); break;
                case "eQ": dkList.Add(146); break;
                case "eR": dkList.Add(147); break;
                case "eS": dkList.Add(148); break;
                case "eT": dkList.Add(149); break;
                case "eU": dkList.Add(150); break;
                case "eV": dkList.Add(151); break;
                case "eW": dkList.Add(152); break;
                case "eX": dkList.Add(153); break;
                case "eY": dkList.Add(154); break;
                case "eZ": dkList.Add(155); break;
                case "fA": dkList.Add(156); break;
                case "fB": dkList.Add(157); break;
                case "fC": dkList.Add(158); break;
                case "fD": dkList.Add(159); break;
                case "fE": dkList.Add(160); break;
                case "fF": dkList.Add(161); break;
                case "fG": dkList.Add(162); break;
                case "fH": dkList.Add(163); break;
                case "fI": dkList.Add(164); break;
                case "fJ": dkList.Add(165); break;
                case "fK": dkList.Add(166); break;
                case "fL": dkList.Add(167); break;
                  
                default:
                    break;
            }
        }
  
        int counter = 0;
        for (int i = dkList.Count - 1; i >= 0; i--)
        {
            counter++;
            for (int j = 0; j < counter - 1; j++)
            {
                long tempValue = dkList[i] * dkList[i];
                dkList[i] = tempValue;
            }
        }
  
        for (int i = 0; i < dkList.Count; i++)
        {
            decimalRep += dkList[i];
        }
        Console.WriteLine(decimalRep);
    }
}