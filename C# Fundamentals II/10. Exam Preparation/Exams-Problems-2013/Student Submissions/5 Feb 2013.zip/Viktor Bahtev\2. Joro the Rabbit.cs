using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class JoroTheRabit
{
    static void Main()
    {
        string[] terrainNumbersStr = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
        int[] terrainNumbers = new int[terrainNumbersStr.Length];
        for (int i = 0; i < terrainNumbersStr.Length; i++)
        {
            terrainNumbers[i] = int.Parse(terrainNumbersStr[i]);
        }
        int[] sortedArray = new int[terrainNumbers.Length];
        Array.Copy(terrainNumbers, sortedArray, terrainNumbers.Length);
        List<int> sorted = sortedArray.ToList();

        int bestVisitedCellsCount = 0;
        for (int startPosition = 0; startPosition < terrainNumbers.Length; startPosition++)
        {
            // check can be bigger.
            //if (Continue(terrainNumbers[startPosition], bestVisitedCellsCount, sorted)) continue;
            for (int step = terrainNumbers.Length - 1; step >=1; step--)
            {
                int currentPosition = startPosition;
                int currentVisitedCellsCount = 1;
                bool[] visited = new bool[terrainNumbers.Length];
                visited[currentPosition] = true;
                //Jump();
                while (true)
                {
                    int nextPosition = currentPosition + step;
                    if (nextPosition >= terrainNumbers.Length)
                    {
                        // avoid index out of range
                        nextPosition = currentPosition + step - terrainNumbers.Length;
                    }
                    // check if bigger and not visited
                    if (!visited[nextPosition] && terrainNumbers[currentPosition] < terrainNumbers[nextPosition])
                    {
                        visited[nextPosition] = true;
                        currentVisitedCellsCount++;
                    }
                    else
                    {
                        break;
                    }
                    currentPosition = nextPosition;
                }
                if (currentVisitedCellsCount > bestVisitedCellsCount)
                {
                    bestVisitedCellsCount = currentVisitedCellsCount;
                }
            }
        }
        Console.WriteLine(bestVisitedCellsCount);
    }

    //private static bool Continue(int number, int bestCount, List<int> sorted)
    //{
    //    int index = sorted.IndexOf(number);
    //    if (sorted.Count - index + 1 < bestCount) return true;
    //    return false;
    //}
}
