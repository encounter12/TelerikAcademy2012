using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02.Joro_The_Rabbit
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            char[] routeArr = input.ToCharArray();
            int count = 0;
            for (int i = 0; i < routeArr.Length; i++)
            {
                if (routeArr[i+1] < routeArr[i])
                {
                    count++;
                }
                else
                {
                    break;
                }
            }
            Console.WriteLine(count);

        }
    }
}
