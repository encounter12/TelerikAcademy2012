using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Numerics;

class Problem01
{
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
#endif
        string number = Console.ReadLine();
        BigInteger sum = 0;

        char[] arr = new char[26];
        for (int i = 0; i < 26; i++)
        {
            arr[i] = (char)('A' + i);
        }

        Dictionary<char, int> arr3 = new Dictionary<char, int>();
        char[] arr2 = new char[26];
        for (int i = 26; i < 52; i++)
        {
            arr3.Add((char)('a' + i - 26), 26 * (i - 25));
        }

        //
        string reversed = ReverseStrings(number);
        for (int i = 0; i < reversed.Length; i++)
        {
            if (i > 1)
            {
                if (reversed[i] < 91)
                {
                    sum += (char)Array.IndexOf(arr, reversed[i])*(BigInteger)Math.Pow(168,i-1);
                }
                if (reversed[i] > 91)
                {
                    sum += arr3[reversed[i]] * (BigInteger)Math.Pow(168, i - 1);
                }
            }
            if (i == 1 && reversed[i]<91)
            {
                if (reversed[i] < 91)
                {
                    sum += (char)Array.IndexOf(arr, reversed[i]) * (BigInteger)Math.Pow(168, i);
                }
                if (reversed[i] > 91)
                {
                    sum += arr3[reversed[i]] * (BigInteger)Math.Pow(168, i);
                }
            }
            else
            {
                if (reversed[i] < 91)
                {
                    sum += (char)Array.IndexOf(arr, reversed[i]);
                }
                if (reversed[i] > 91)
                {
                    sum += arr3[reversed[i]];
                }
            }
        }

        Console.WriteLine(sum);

    }
    public static string ReverseStrings(string s)
    {
        char[] arr = s.ToCharArray();
        Array.Reverse(arr);
        return new string(arr);
    }
}
