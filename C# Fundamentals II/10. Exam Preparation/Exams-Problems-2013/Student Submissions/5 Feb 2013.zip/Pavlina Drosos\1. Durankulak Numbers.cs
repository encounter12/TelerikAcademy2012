namespace DurankulakNumbers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    
    public class DurankulakNumbers
    {
        public static void Main(string[] args)
        {
            ulong decimalNumber = 0;

            // build Durankulak's digits positions
            List<string> durankulakDigits = new List<string>();
            StringBuilder currentDigit = new StringBuilder();
            for (char i = 'A'; i <= 'Z'; i++)
            {
                durankulakDigits.Add(i.ToString());
            }
            for (char i = 'a'; i <= 'e'; i++)
            {
                for (char j = 'A'; j <= 'Z'; j++)
                {
                    currentDigit.Append(i.ToString()).Append(j.ToString());
                    durankulakDigits.Add(currentDigit.ToString());
                    currentDigit.Clear();
                }
            }
            for (char i = 'A'; i <= 'L'; i++)
            {
                currentDigit.Append("f").Append(i.ToString());
                durankulakDigits.Add("f" + i.ToString());
                currentDigit.Clear();
            }

            // read Duranculac number
            string duranculacNumber = Console.ReadLine();

            //split Duranculac number to digits
            List<string> duranculacNumberDigits = new List<string>();
            for (int i = 0; i < duranculacNumber.Length; i++)
            {
                if (char.IsLower(duranculacNumber[i])) // a digit with format aA starts here
                {
                    currentDigit.Append(duranculacNumber[i]);
                }

                if (char.IsUpper(duranculacNumber[i])) // a new digit with format A starts here or a digit with format aA ends here  
                {
                    currentDigit.Append(duranculacNumber[i]);
                    duranculacNumberDigits.Add(currentDigit.ToString());
                    currentDigit.Clear();
                }
            }

            for (int i = duranculacNumberDigits.Count - 1; i >= 0; i--)
            {
                decimalNumber += (ulong)durankulakDigits.IndexOf(duranculacNumberDigits[i]) * (ulong)Math.Pow(168, duranculacNumberDigits.Count - i - 1);
            }

            Console.WriteLine(decimalNumber);
        }
    }
}