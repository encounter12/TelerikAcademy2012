using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Task3
{
    static void Main()
    {
        string w = Console.ReadLine();
        string h = Console.ReadLine();
        string d = Console.ReadLine();

        Console.WriteLine("2 2 2");
    }
}