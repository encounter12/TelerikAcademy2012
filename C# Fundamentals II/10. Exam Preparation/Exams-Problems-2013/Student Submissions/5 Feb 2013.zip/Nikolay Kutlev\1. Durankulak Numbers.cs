using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Program
    {
        static void Main()
        {
            string input = Console.ReadLine();
            int decNumber = 0;
            int power = 1;
            int count = 0;
            int temp = 0;
            for (int i = input.Length - 1; i >=0; i--)
            {                
                if (input[i] > 'A' && input[i] < 'Z')
                {
                    decNumber += (input[i] - 'A') * power;
                    count++;
                }
                if (input[i] >= 'a')
                {
                    if (input[i] == 'a')
                    {
                        decNumber += 26;
                        count++;
                    }
                    if (input[i] == 'b')
                    {
                        decNumber += 52;
                        count++;
                    }
                    if (input[i] == 'c')
                    {
                        decNumber += 78;
                        count++;
                    }
                    if (input[i] == 'd')
                    {
                        decNumber += 104;
                        count++;
                    }
                    if (input[i] == 'e')
                    {
                        decNumber += 130;
                        count++;
                    }
                    if (input[i] == 'f')
                    {
                        decNumber += 156;
                        count++;
                    }
                    if (count == 2)
                    {
                        decNumber = decNumber * power;
                        power = power * 168;
                        count = 0;
                        temp = decNumber;
                        decNumber = 0;
                    }
                }
            }
            decNumber = decNumber + temp;
            Console.WriteLine(decNumber);
        }
    }
}
