using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class TwoIsBetterThanOne
{

    static void FirstTask(string input)
    {
        string[] numbers = input.Split(' ');
        BigInteger a = BigInteger.Parse(numbers[0]);
        BigInteger b = BigInteger.Parse(numbers[1]);
        long counter = 0;

        for (BigInteger i = a; i <= b; i++)
        {
            if (OnlyLuckyDigits(i) && IsPolindrome(i))
            {
                counter++;
            }
        }
        Console.WriteLine(counter);

    }

    static bool IsPolindrome(BigInteger i)
    {
        string number = i.ToString();
        StringBuilder revNum = new StringBuilder();
        for (int digit = number.Length - 1; digit >= 0; digit--)
        {
            revNum.Append(number[digit]);
        }
        string reversedNumber = revNum.ToString();
        if (number == reversedNumber)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    static bool OnlyLuckyDigits(BigInteger i)
    {
        string number = i.ToString();
        if (number.Contains('1') || number.Contains('2') || number.Contains('4') || number.Contains('6') ||
            number.Contains('7') || number.Contains('8') || number.Contains('9') || number.Contains('0'))
        {
            return false;
        }
        else return true;
    }

    static void Main()
    {
        string input = Console.ReadLine();
        string inputNumbers = Console.ReadLine();
        int percentile = int.Parse(Console.ReadLine());
        FirstTask(input);
        SecondTask(inputNumbers , percentile);
    }

    static void SecondTask(string inputNumbers, int percentile)
    {

        string[] numbersStr = inputNumbers.Split(',');
        long[] number = new long[numbersStr.Length];
        for (int i = 0; i < numbersStr.Length; i++)
        {
            number[i] = long.Parse(numbersStr[i]);
        }

        Array.Sort(number);

        int startIndex = 0;
        startIndex = (int)((decimal)(percentile / 100 * number.Length));

        if (percentile % 10 == 0)
        {
            startIndex = (int)((decimal)(percentile / 100 * number.Length )) - 1;
            
        }
        else
        {
            startIndex = (int)((decimal)percentile / 100 * number.Length);
        }
        startIndex = Math.Abs(startIndex);
        

        long smallestElement = number[startIndex];
        for (int index = startIndex + 1; index < number.Length; index++)
        {
            if (number[index] < smallestElement)
            {
                smallestElement = number[index];
            }
        }
        Console.WriteLine(smallestElement);

    }
}