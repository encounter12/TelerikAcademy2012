using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class JoroTheRabbit
{
    static void Main()
    {
        string[] tokens = Console.ReadLine().Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
        int[] numbers = new int[tokens.Length];
        for (int i = 0; i < tokens.Length; i++)
        {
            numbers[i] = int.Parse(tokens[i]);
        }

        
        if (numbers.Length > 8)
        {
            int inverses = 0;
            for (int i = 1; i < numbers.Length; i++)
            {
                if (numbers[i] < numbers[i - 1])
                {
                    inverses++;
                }
            }

            if (numbers[0] < numbers[numbers.Length - 1])
            {
                inverses++;
            }

            if (inverses == 1)
            {
                Console.WriteLine(numbers.Length);
                return;
            }
            else if(inverses == 0)
            {
                Console.WriteLine(1);
                return;
            }
        }
          

        int maxSteps = GetMaxSteps(numbers);
        Console.WriteLine(maxSteps);
    }

    private static int GetMaxSteps(int[] numbers)
    {
        int best = 0;
        int current = 0;
        for (int start = 0; start < numbers.Length; start++)
        {
            int prev = start;
            bool[] visited = new bool[numbers.Length];
            visited[start] = true;
            current = 1;
            for (int step = 1; step <= numbers.Length; step++)
            {
                int next = (prev + step) % numbers.Length;
                while (!visited[next] && numbers[next] > numbers[prev])
                {
                    current++;
                    prev = next;
                    visited[next] = true;
                    next = (prev + step) % numbers.Length;
                }

                if (current > best)
                {
                    best = current;
                }

                for (int i = 0; i < visited.Length; i++)
                {
                    visited[i] = false;
                }
                prev = start;
                current = 1;
            }

            current = 0;
        }

        return best;
    }
}
