using System;
using System.Linq;
using System.Text;

class Rabbit
{
    static void Main()
    {

        string terein = Console.ReadLine();
        char[] separator = new char[] { ',' };
        string[] numbers = terein.Split(separator, StringSplitOptions.RemoveEmptyEntries);
        int n = numbers.Length * numbers.Length;
        StringBuilder sb = new StringBuilder(n);
        bool jump = false;
        int count = 0;
        int result = 1;
        int bestResult = 0;

        
        while (sb.Length < n)
        {
            foreach (var num in numbers)
            {
                sb.Append(num);

            }
        }
       
        for (int i = 0 ; i <numbers.Length-1; i++)
        {
            for (int j = i+1; j < numbers.Length; j++)
            {
                if (sb[i] < sb[j])
                {
                    jump = true;
                }
                if (jump)
                {
                    count = j;
                    int p = j + j + 1;
                    if (sb[j] < sb[p])
                    {
                        result++;
                    }
                    else
                    {
                        if (result>bestResult)
                        {
                            bestResult = result;
                        }
                        result = 1;
                    }
                    jump = false;
                }
            }
        }
        Console.WriteLine(bestResult);
    }
}
        
