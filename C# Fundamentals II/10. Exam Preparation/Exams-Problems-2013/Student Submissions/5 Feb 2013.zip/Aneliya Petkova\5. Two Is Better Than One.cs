using System;

class TwoIsBetterThanOne
{
    static void Main()
    {
        //First task

        string firstTask = Console.ReadLine();
        char separator = ' ';
        string[] range = firstTask.Split(separator);

        //Second task

        string secondTask = Console.ReadLine();
        int percentile = int.Parse(Console.ReadLine());
        string[] listOfNumbers = secondTask.Split(',');

        //First task

        ulong A = ulong.Parse(range[0]);
        ulong B = ulong.Parse(range[1]);
        bool symetric = true;
        int countPalindromes = 0;
        bool luckyNumber = true;
        for (ulong i = A; i <= B; i++)
        {
            string number = i.ToString();
            symetric = true;
            luckyNumber = true;
            for (int j = 0; j < number.Length; j++)
            {
                if (number[j] == '3' || number[j] == '5')
                {
                    luckyNumber = true;
                }
                else
                {
                    luckyNumber = false;
                    break;
                }
            }
            if (luckyNumber == true)
            {
                for (int j = 0; j < number.Length; j++)
			    {
                    if (number[j] != number[number.Length - 1 - j])
                    {
                        symetric = false;
                    }
			    } 
                if (symetric)
                {
                    countPalindromes++;
                }               
            } 
        }
        //Second task
        int[] element = new int[listOfNumbers.Length];
        byte numberOfElements = 0;
        int replace;
        for (int i = 0; i < listOfNumbers.Length; i++)
        {
            element[i] = int.Parse(listOfNumbers[i]);
        }
        
        if(percentile % 10 != 0)
        {
            numberOfElements = (byte)(((element.Length * percentile) / 100) + 1); 
        }
        else 
        {
            numberOfElements = (byte)((element.Length * percentile) / 100);            
        }
        
        for (int j = 0; j < element.Length; j++)
        {
            for (int i = j + 1; i < element.Length; i++)
            {
                if (element[j] > element[i])
                {
                    replace = element[i];
                    element[i] = element[j];
                    element[j] = replace;
                }
            }
        }
        Console.WriteLine(countPalindromes);
        Console.WriteLine(element[numberOfElements - 1]);
    }
}
