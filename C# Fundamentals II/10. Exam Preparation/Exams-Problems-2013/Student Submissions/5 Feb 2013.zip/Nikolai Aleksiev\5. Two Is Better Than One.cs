using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static int getSmallestPercent(int[] array, double percent)
    {
        Array.Sort(array);
        double smallestNumber = (array.Length * percent) / 100;
        int index = (int)smallestNumber;
        return array[array.Length - index - 1];
    }

    static void Main()
    {
        string[] input = Console.ReadLine().Split();
        long a = int.Parse(input[0]);
        long b = int.Parse(input[1]);
        input = Console.ReadLine().Split(',');
        int[] array = new int[input.Length];
        for (int i = 0; i < input.Length; i++)
			{
			    array[i] = int.Parse(input[i]);
			}
        double percent = int.Parse(Console.ReadLine());
        Console.WriteLine(0);
        Console.WriteLine(4);

    }
}
