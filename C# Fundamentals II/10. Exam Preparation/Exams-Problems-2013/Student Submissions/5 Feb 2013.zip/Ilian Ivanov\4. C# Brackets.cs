using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brackets
{
    class Brackets
    {
        static void Main()
        {
            int numbersOfLines = int.Parse(Console.ReadLine());
            string indentionString = Console.ReadLine();
            StringBuilder text = new StringBuilder();
            bool newLine = false;
            int indexTabs = 0;
            StringBuilder textInBrackets = new StringBuilder();

            for (int i = 0; i < numbersOfLines; i++)
            {
                string line = Console.ReadLine();

                for (int k = 0; k < line.Length; k++)
                {
                    if (line[k] == '{')
                    {
                        if (Convert.ToString(textInBrackets) != "")
                        {
                            text.Append("\r\n");
                            for (int tab = 0; tab < indexTabs; tab++)
                            {
                                text.Append(indentionString);
                            }
                            
                            text.Append(textInBrackets);
                            textInBrackets.Clear();
                        }
                        //isInBrackets = true;
                        if (!newLine)
                        {
                            text.Append("\r\n");
                        }
                        for (int teb = 0; teb < indexTabs; teb++)
                        {
                            text.Append(indentionString);
                        }
                        text.Append("{");
                        //text.Append("\r\n");
                        indexTabs++;
                    }
                    else if (line[k] == '}')
                    {
                        //isInBrackets = false;
                        if (Convert.ToString(textInBrackets) != "")
                        {
                            text.Append("\r\n");
                            for (int tab = 0; tab < indexTabs; tab++)
                            {
                                text.Append(indentionString);
                            }
                            text.Append(textInBrackets);
                            textInBrackets.Clear();
                        }

                        indexTabs--;
                        text.Append("\r\n");
                        for (int tab = 0; tab < indexTabs; tab++)
                        {
                            text.Append(indentionString);
                        }
                        
                        text.Append("}");
                        
                    }
                    else
                    {
                        ////text.Append(@"\r\n");
                        //for (int tab = 0; tab < indexTabs; tab++)
                        //{
                        //    text.Append(indentionString);
                        //}
                        textInBrackets.Append(line[k]);
                    }
                    newLine = false;
                }

                if (Convert.ToString( textInBrackets) != "")
                {
                    text.Append("\r\n");

                    for (int tab = 0; tab < indexTabs; tab++)
                    {
                        text.Append(indentionString);
                    }

                    text.Append(textInBrackets);
                    //text.Append("\r\n");

                    textInBrackets.Clear();
                }

                newLine = true;
            }
            
            
            string txt = text.ToString().Replace(@"\r\n\", "");
            Console.WriteLine(text.ToString());
        }

        
    }
}
