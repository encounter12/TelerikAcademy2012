using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5.LuckyNumbers
{
    class Program
    {
        static void Main()
        {
            char three = '3';
            char five= '5';
            string strInput = Console.ReadLine();
            string[] input = strInput.Split(new[]{' '}, StringSplitOptions.RemoveEmptyEntries);
            int a = int.Parse(input[0]);
            int b = int.Parse(input[1]);

            string strIputSequence = Console.ReadLine();
            string[] strSequence = strIputSequence.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

            string strPercent = Console.ReadLine();

            int length = strSequence.Length;
            int[] sequence = new int[length];
            for (int i = 0; i < length; i++)
            {
                sequence[i] = int.Parse(strSequence[i]);
            }


            bool isPalindrome = false;
            int palindromeCount = 0;
            for (int i = a; i < b; i++)
            {
                isPalindrome = false;
                if (i%3==0 || i%5==0)
                {
                    string current = i.ToString();
                    for (int j = 0; j < current.Length; j++)
                    {
                        char ch = current[j];
                        if (ch == current[current.Length-1 - j] && (ch=='3' || ch =='5'))
                        {
                            isPalindrome = true;
                            continue;
                        }
                        else
                        {
                            isPalindrome = false;
                            break;
                        }
                    }
                }
                if (isPalindrome)
                {
                    palindromeCount++;                    
                }
            }

            Array.Sort(sequence);

            int percent = int.Parse(strPercent);
            int numberOfElements = 0;
            decimal percentage = ((decimal)percent / 100) * length;
            if ((int)percentage < percentage)
            {
                 numberOfElements = (int)(percentage);
                
            }
            else
            {
                 numberOfElements = (int)(percentage )-1;
                    
            }


            Console.WriteLine(palindromeCount);
            Console.WriteLine(sequence[numberOfElements]);
        }
    }
}
