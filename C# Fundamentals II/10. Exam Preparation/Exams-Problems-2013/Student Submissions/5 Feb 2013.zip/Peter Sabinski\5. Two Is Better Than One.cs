using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Problem_4
{
    class P4

    {
        static void Main(string[] args)
        {
            //Console.WriteLine(IsLucky(353));
       
            string input = Console.ReadLine();
            //string input = "1 99";
            string[] nums = input.Split(' ');

            long low = long.Parse(nums[0]);
            long hi = long.Parse(nums[1]);

            //string seq = "10,9,8,7,6,5,4,3,2,1";
            string seq = Console.ReadLine(); 
            int p = int.Parse(Console.ReadLine()); 

          

            string[] seqMembers = seq.Split(',');

            //List<int> sequence = new List<int>();

            int[] seque = new int[seqMembers.Length];


            for (int i = 0; i < seque.Length; i++)
            {
                seque[i]=int.Parse(seqMembers[i]);
            }
            /*
            foreach (var num in seqMembers)
            {           
                sequence.Add(int.Parse(num));              
            }
             */

            //StringBuilder sb = new StringBuilder();


            int count = 0;
            for (long i = low; i <= hi; i++)
            {

                //sb.Append(i);
                if (IsLucky(i))
                {
                    if (IsPalindrome(i))
                    {

                        count++;

                    }
                }

                //sb.Clear();
            }

           Console.WriteLine(count);

            ///=========second============

           //sequence.Sort();

           Array.Sort(seque);

           int ln = seque.Length;

   





            
           int lastFound = 0;

           for (int i = 0; i < seque.Length; i++)
           {

               if (IsInRange(p, ln, i))
               {
                   
                   lastFound = seque[i];

               }
               else
               {
                   break;
               }

           }

           Console.WriteLine(lastFound);




        
        }

        static bool IsPalindrome(long n)
        {
            StringBuilder num = new StringBuilder(n.ToString());

            for (int i = 0; i < num.Length / 2; i++)
            {
                if (num[i] != num[num.Length - i - 1])
                    return false;
            }

            return true;
        }

        static bool IsLucky(long n)
        {

            if  ( (n % 5 == 0  || ((n-3)%10 ==0) ) || (n==3) )
            {

                StringBuilder num = new StringBuilder(n.ToString());
                for (int i = 0; i < num.Length; i++)
                {
                    if ((num[i] != '3') && (num[i] != '5'))
                    {
                        return false;
                    }
                    
                }
                return true;
            }
            return false;
            
        }

        static bool IsInRange(double givenRange, int arrLength, double currentCount)
        {
            double totalCount = arrLength;

            double range = currentCount / (totalCount / 100); 


            if ( givenRange > range )
            {
                return true;
            }

            return false;

        }




    }
}
