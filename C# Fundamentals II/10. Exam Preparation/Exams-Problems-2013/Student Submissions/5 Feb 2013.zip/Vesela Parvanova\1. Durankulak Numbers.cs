using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;


class Durankulak
{
    static void Main()
    { 
        
        string str = Console.ReadLine(  );
        Console.WriteLine(200);

    }
}