using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoIsBetterThenOne
{
    class Program
    {
        static void Main()
        {
            string AB = Console.ReadLine();            
            string li = Console.ReadLine();
            string persen = (Console.ReadLine());
            int persent = int.Parse(persen);

            string[] length = AB.Split();
            string[] lis = li.Split(',');
            long[] lengthAB = new long[length.Length];
            long[] list = new long[lis.Length];
            int counter = 0;

            StringToInt(lengthAB, length);
            StringToInt(list, lis);

            long[] happyEl = new long[lengthAB[1] - lengthAB[0] + 1];
            long firstElement = lengthAB[0] - 1;
            firstElement = LoadArray(happyEl, firstElement);
            
            string[] happyElstr = new string[happyEl.Length];

            for (int i = 0; i < happyEl.Length; i++)
            {
                happyElstr[i] = happyEl[i].ToString();  
            }

            for (int element = 0; element < happyElstr.Length; element++)
            {
                string str = "";
                string pal = happyElstr[element];
                for (int j = pal.Length - 1; j >= 0; j--)
                {
                    str = str + pal[j];
                }
                if (str == pal)
                { 
                    if (pal.Contains('3') || pal.Contains('5'))
                    {
                        counter++;
                    }
                }
            }

            // vtora chast LIST
            Array.Sort(list);

            double pers = (double)persent / 100;
            double index = list.Length * pers;
            int indexInt = (int)index;
            //int indexInt = 0;

            //double per = (double)100 / list.Length;

            //while (per < persent)
            //{
            //    per += per;
            //    indexInt++;
            //}
            if (persent % 10 == 0)
            {
                indexInt--;
            }
                       
            
            Console.WriteLine(counter);
            Console.WriteLine(list[indexInt]);
                        
        }

        private static long LoadArray(long[] happyEl, long firstElement)
        {
            for (int i = 0; i < happyEl.Length; i++)
            {
                firstElement = firstElement + 1;
                happyEl[i] = firstElement;
            }
            return firstElement;
        }

        private static void StringToInt(long[] array, string[] str)
        {
            for (int num = 0; num < array.Length; num++)
            {
                array[num] = long.Parse(str[num]);
                
            }
            
        }
    }
}
