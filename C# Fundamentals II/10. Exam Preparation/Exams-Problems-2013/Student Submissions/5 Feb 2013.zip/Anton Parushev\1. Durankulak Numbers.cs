using System;
using System.Collections.Generic;

class DurankulakNumbers
{
    static void Main()
    {
        string test = Console.ReadLine();
        //string test = "BCfI";
        long output = 0;
        int counter = 0;

        for (int i = test.Length - 1; i >= 0 ; i--)
        {
            if (Char.IsUpper(test[i]))
            {
                if (i - 1 >= 0 && Char.IsLower(test[i - 1]))
                {
                    if (i == test.Length - 1)
                    {
                        output += (long)(GetDecimalRepresentation(test.Substring(i - 1, 2)));
                    }
                    else
                    {
                        output += (long)(GetDecimalRepresentation(test.Substring(i - 1, 2)) * Math.Pow(168, counter));
                        i--;
                    }
                }
                else
                {
                    if (i == test.Length - 1)
                    {
                        output += (long)(GetDecimalRepresentation(test[i].ToString()));
                    }
                    else
                    {
                        output += (long)(GetDecimalRepresentation(test[i].ToString()) * Math.Pow(168, counter));
                    }
                }

                counter++;
            }
        }


        Console.WriteLine(output);
    }

    static byte GetDecimalRepresentation(string inputCode)
    {
        inputCode = inputCode.ToUpper();
        byte currentColumn = 0;
        byte buffer = 0;
        byte output = 0;

        for (int i = 0; i < inputCode.Length; i++)
        {
            currentColumn = (byte) (inputCode[i] - 65);
            
            if (i == (inputCode.Length - 1))
            {
                buffer = currentColumn;
            }
            else
            { 
                buffer = (byte) ((currentColumn + 1) * Math.Pow(26, inputCode.Length - 1 - i));
            }

            output += buffer;
        }

        return output;
    }
}