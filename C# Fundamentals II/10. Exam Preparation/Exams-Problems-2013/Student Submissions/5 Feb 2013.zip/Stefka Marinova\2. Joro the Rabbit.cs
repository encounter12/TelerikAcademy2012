using System;

class JoroTheRabbit
{
    static void Main()
    {
        //int[] arr = { 1, -2, -3, 4, -5, 6, -7, 8 };
        //int[] arr = { 1,1,1 };
        //int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0 };
        string input = Console.ReadLine();
        string[] arrInput = input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
        int len = arrInput.Length;
        int[] arr = new int[len];
        int i = 0;
        foreach (string num in arrInput)
        {
            arr[i++] = int.Parse(num);
        }

        int maxCount = 0;


        for (int step = 1; step <= len; step++)
        {
            for (int pos = 0; pos < len; pos++)
            {
                int steps = CheckStep(arr, step, pos);
                if (maxCount < steps)
                {
                    maxCount = steps;
                }
            }
        }
        Console.WriteLine(maxCount + 1);
    }

    static int CheckStep(int[] arr, int step, int pos)
    {
        int len = arr.Length;
        bool[] stepped = new bool[len];
        int count = 0;
        int current = pos;
        int prevStep = arr[pos];
        stepped[pos] = true;
        //do
        while (!stepped[current = (current + step) % len])
        {
            //Console.WriteLine(current+":"+stepped[current]);
            //current = (current + step) % len;
            if (prevStep < arr[current])
            {
                count++;
                stepped[current] = true;
                prevStep = arr[current];
            }
            else
            {
                break;
            }
        }
        //while (!stepped[current]);

        return count;
    }
}
