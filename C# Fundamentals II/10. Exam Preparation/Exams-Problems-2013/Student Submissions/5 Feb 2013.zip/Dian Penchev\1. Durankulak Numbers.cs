using System;

class Program
{
    static void Main()
    {
        string number = Console.ReadLine();

        switch (number)
        {
            case "A": { Console.WriteLine(0); break; }
            case "B": { Console.WriteLine(1); break; }
            case "C": { Console.WriteLine(2); break; }
            case "D": { Console.WriteLine(3); break; }
            case "E": { Console.WriteLine(4); break; }
            case "F": { Console.WriteLine(5); break; }
            case "G": { Console.WriteLine(6); break; }
            case "H": { Console.WriteLine(7); break; }
            case "I": { Console.WriteLine(8); break; }
            case "J": { Console.WriteLine(9); break; }
            case "K": { Console.WriteLine(10); break; }
            case "L": { Console.WriteLine(11); break; }
            case "M": { Console.WriteLine(12); break; }
            case "N": { Console.WriteLine(13); break; }
            case "O": { Console.WriteLine(14); break; }
            case "P": { Console.WriteLine(15); break; }
            case "Q": { Console.WriteLine(16); break; }
            case "R": { Console.WriteLine(17); break; }
            case "S": { Console.WriteLine(18); break; }
            case "T": { Console.WriteLine(19); break; }
            case "U": { Console.WriteLine(20); break; }
            case "V": { Console.WriteLine(21); break; }
            case "W": { Console.WriteLine(22); break; }
            case "X": { Console.WriteLine(23); break; }
            case "Y": { Console.WriteLine(240); break; }
            case "Z": { Console.WriteLine(25); break; }
            default:
                    {
                        break;
                    }
        }


    }
}
