using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{
    static int width, height, depth;
    static bool[, ,] cube;

    // static int startW, startH, startD;
    static int dirW, dirH, dirD;
    static int currentW, currentH, currentD;

    static void PrintCube(bool[, ,] cube)
    {
#if DEBUG
        for (int d = 0; d < depth; d++)
        {
            for (int h = 0; h < height; h++)
                for (int w = 0; w < width; w++)
                    Console.Write((cube[w, h, d] ? 1 : 0) + (w == width - 1 ? "\n" : " "));

            if (d < depth - 1) Console.WriteLine();
        }
#endif
    }

    static bool IsInsideCube(bool[, ,] cube, int x, int y, int z)
    {
        return 0 <= x && x < cube.GetLength(0)
            && 0 <= y && y < cube.GetLength(1)
            && 0 <= z && z < cube.GetLength(2);
    }

    static void Input()
    {
        string[] dimensions = Console.ReadLine().Split();

        width = int.Parse(dimensions[0]);
        height = int.Parse(dimensions[1]);
        depth = int.Parse(dimensions[2]);

        cube = new bool[width, height, depth];

        string[] start = Console.ReadLine().Split();

        //startW = int.Parse(start[0]);
        //startH = int.Parse(start[1]);
        //startD = int.Parse(start[2]);

        currentW = int.Parse(start[0]) - 1;
        currentH = int.Parse(start[1]) - 1;
        currentD = int.Parse(start[2]) - 1;

        cube[currentW, currentH, currentD] = true;

        string[] dir = Console.ReadLine().Split();

        dirW = int.Parse(dir[0]);
        dirH = int.Parse(dir[1]);
        dirD = int.Parse(dir[2]);
    }

    static void Start()
    {
        while (true)
        {
            // Not visited - go to next
            if (IsInsideCube(cube, currentW + dirW, currentH + dirH, currentD + dirD))
            {
                if (!cube[currentW + dirW, currentH + dirH, currentD + dirD])
                {
#if DEBUG
                    Console.WriteLine("{0} {1} {2}", currentW + 1, currentH + 1, currentD + 1);
                    Console.WriteLine(cube[currentW + dirW, currentH + dirH, currentD + dirD]);
                    Console.WriteLine();
#endif

                    currentW += dirW;
                    currentH += dirH;
                    currentD += dirD;

                    cube[currentW, currentH, currentD] = true;
                }
                else
                {
                    //currentW -= dirW;
                    //currentH -= dirH;
                    //currentD -= dirD;

                    break;
                }
            }

            // Rotate
            else
            {
                if (!(0 <= currentW + dirW && currentW + dirW < width))
                {
#if DEBUG
                    Console.WriteLine("Rotating w");
#endif
                    dirW = -dirW;
                }

                if (!(0 <= currentH + dirH && currentH + dirH < height))
                {
#if DEBUG
                    Console.WriteLine("Rotating h");
#endif
                    dirH = -dirH;
                }

                if (!(0 <= currentD + dirD && currentD + dirD < depth))
                {
#if DEBUG
                    Console.WriteLine("Rotating d");
#endif
                    dirD = -dirD;
                }

                //currentW += dirW;
                //currentH += dirH;
                //currentD += dirD;
            }
        }
    }

    static void BurnEdges()
    {
        for (int w = 0; w < width; w++)
        {
            cube[w, 0, 0] = true;
            cube[w, height - 1, 0] = true;
            cube[w, 0, depth - 1] = true;
            cube[w, height - 1, depth - 1] = true;
        }

        for (int h = 0; h < height; h++)
        {
            cube[0, h, 0] = true;
            cube[width - 1, h, 0] = true;
            cube[0, h, depth - 1] = true;
            cube[width - 1, h, depth - 1] = true;
        }

        for (int d = 0; d < depth; d++)
        {
            cube[0, 0, d] = true;
            cube[width - 1, 0, d] = true;
            cube[0, height - 1, d] = true;
            cube[width - 1, height - 1, d] = true;
        }
    }

    static void Output()
    {
        Console.WriteLine("{0} {1} {2}", currentW + 1, currentH + 1, currentD + 1);
    }

    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input2.txt"));
#endif
        Input();

        BurnEdges();

        Start();

        Output();
    }
}
