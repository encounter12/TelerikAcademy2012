using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Durankulak
{
    class Program
    {
        static void Main()
        {
            string line = Console.ReadLine();

            long sum = 0;
            int loop = 0;
            long add = 0;
            for (int i = line.Length - 1; i >= 0; i--)
            {
                add = 0;
                if (i != 0)
                {
                    if ((int)line[i - 1] > 91)
                    {
                        add = ((int)line[i - 1] - 96) * 26;
                    }
                }
                if ((int)line[i] < 91)
                {
                    add = add + ((int)line[i] - 65);
                    if (i != line.Length - 1)
                        loop++;
                }
                sum = sum + add * (long)Math.Pow(168, loop);
            }
            Console.WriteLine(sum);

        }
    }
}
