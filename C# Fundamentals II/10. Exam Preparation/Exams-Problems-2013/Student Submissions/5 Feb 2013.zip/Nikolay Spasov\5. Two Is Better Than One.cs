using System;

class TwoIsBetter
{
    static int[] arr;
    static void Main()
    {
        string line = Console.ReadLine();
        string[] splt = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

        ulong A = ulong.Parse(splt[0]);
        ulong B = ulong.Parse(splt[1]);

        line = Console.ReadLine();
        splt = line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        arr = new int[splt.Length];
        for (int i = 0; i < arr.Length; i++)
        {
            arr[i] = int.Parse(splt[i]);
        }

        int P = int.Parse(Console.ReadLine());

        int count = 0;
        for (ulong i = A; i <= B; i++)
        {
            if (IsPalindrome(i))
            {
                count++;
            }
        }

        Array.Sort(arr);

        int smaller = P * arr.Length / 100;

        int e = arr[smaller];
        Console.WriteLine(count);
        Console.WriteLine(e);
    }

    static bool IsPalindrome(ulong number)
    {
        if (number == 3 || number == 5)
        {
            return true;
        }
        string num = number.ToString();

        for (int i = 0; i < num.Length / 2; i++)
        {
            if ((num[i] == '3' || num[i] == '5') && 
                (num[i] == num[num.Length - 1 - i]))
            {
                return true;
            }
        }

        return false;
    }
}

