using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace CBrackets
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string identator = Console.ReadLine();
            StringBuilder result=new StringBuilder();
            int countBrackets = 0;
            int countSpace = 0;
            bool closedBracket = false;
            bool openBracket = false;
            for (int i = 0; i < n; i++)
            {
                string input = Console.ReadLine();
                for (int j = 0; j < input.Length; j++)
                {
                    if (input.Substring(j, 1) == "{")
                    {
                        if (j > 0)
                        {
                            result.AppendLine();
                        }
                        for (int z = 0; z < countBrackets; z++)
                        {
                            result.Append(identator);
                        }
                        countBrackets++;
                        result.Append("{");
                         
 
                        openBracket = true;
                    }
                    else if (input.Substring(j, 1) == "}")
                    {
                        result.AppendLine();
                        countBrackets--;
                        for (int z = 0; z < countBrackets; z++)
                        {
                            result.Append(identator);
                        }
                        result.Append("}");
                         
 
                        closedBracket = true;
                    }
                    else if (input.Substring(j, 1) == " ")
                    {
                        countSpace++;
                    }
                    else
                    {
                        if (countSpace >= 1)
                        {
                            result.Append(" ");
                            countSpace = 0;
                        }
                        if (openBracket || closedBracket)
                        {
                            result.AppendLine();
                            for (int z = 0; z < countBrackets; z++)
                            {
                                result.Append(identator);
                            }
                            if (openBracket)
                            {
                                openBracket = false;
                            }
                            else if (closedBracket)
                            {
                                closedBracket = false;
                            }
                        }
                        result.Append(input.Substring(j, 1));
                    }
                }
            }
            Console.WriteLine(result);
        }
    }
}