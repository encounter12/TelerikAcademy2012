using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
 
namespace EX01DurankulakNumbers
{
    class EX01DurankulakNumbers
    {
        static void Main()
        {
            //string inputText = "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
            //StringReader input = new StringReader(inputText);
            //Console.SetIn(input);
            Dictionary<string, int> numeralSystemMap = new Dictionary<string, int>();
             
            for (int i = 0; i < 168; i++)
            {
                StringBuilder numberBuilder = new StringBuilder();
                if (i > 25)
                {
                    numberBuilder.Append(((char)((i / 26) + 96)).ToString());
                }
 
                numberBuilder.Append(((char)((i % 26) + 65)).ToString());
                numeralSystemMap.Add(numberBuilder.ToString(), i);
            }
 
            string durankulakNumber = Console.ReadLine();
 
            StringBuilder decimalNumberBuilder = new StringBuilder();
            List<int> digits = new List<int>();
 
            for (int i = 0; i < durankulakNumber.Length; i++)
            {
                decimalNumberBuilder.Append(durankulakNumber[i]);
                int currentDecimalNumber = 0;
 
                if (numeralSystemMap.TryGetValue(decimalNumberBuilder.ToString(), out currentDecimalNumber))
                {
                    digits.Add(currentDecimalNumber);
                    decimalNumberBuilder.Clear();
                }
            }
 
            BigInteger result = 0;
            for (int i = digits.Count - 1; i >= 0; i--)
            {
                int pow = digits.Count - 1 - i;
                result = result + digits[i] * (BigInteger)Math.Pow(168, pow);
            }
 
            Console.WriteLine(result);
        }
    }
}