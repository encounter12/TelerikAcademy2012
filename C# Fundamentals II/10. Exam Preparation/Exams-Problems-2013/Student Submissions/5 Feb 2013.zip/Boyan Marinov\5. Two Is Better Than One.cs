using System;
using System.Collections.Generic;
using System.Numerics;

class TwoIsBetterThanOne
{
    static bool CheckIfLucky(BigInteger num)
    {
        string str = num.ToString();
        if (str.Length == 1)
        {
            if (str[0] == '3' || str[0] == '5')
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        for (int i = 0; i < str.Length / 2; i++)
        {
            if (str[i] == '3' || str[i] == '5')
            {
                if (str[i] != str[str.Length - i - 1])
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        return true;
    }
    static long CountLuckyNumbers(BigInteger start, BigInteger end)
    {
        long count = 0;
        for (BigInteger num = start; num <= end; num++)
        {
            if (CheckIfLucky(num))
            {
                //Console.WriteLine(num);
                count++;
            }
        }
        return count;
    }

    static int PercentBoundary(List<int> nums, int percentile)
    {
        nums.Sort();
        if (nums.Count == 0 || nums.Count == 1)
        {
            return 0;
        }
        if (percentile == 0)
        {
            return nums[0];
        }
        else if (percentile == 100)
        {
            return nums[nums.Count - 1];
        }
        //double target = nums.Length * (percentage / 100.0);
        double perc = (percentile / 100.0) * nums.Count + 0.5;
        int nearest = (int)(Math.Floor(perc));
        //int index = nums.IndexOf(nearest);
        //int nearest = Array.BinarySearch(nums, toSearch);
        return nums[nearest-1];
    }

    //static int FindPercentile(int[] nums, int percentile)
    //{
    //    int result = 0;
    //    Array.Sort(nums);
    //    if (nums.Length == 0 || nums.Length == 1)
    //    {
    //        return 0;
    //    }
    //    if (percentile == 0)
    //    {
    //        return nums[0];
    //    }
    //    else if (percentile == 100)
    //    {
    //        return nums[nums.Length - 1];
    //    }
    //    for (int i = 0; i < nums.Length; i++)
    //    {
    //        double currentPercentile = ((double)(i) / (nums.Length - 1)) * 100;
    //        if (currentPercentile >= (double)percentile)
    //        {
    //            result = nums[i];
    //            break;
    //        }
    //    }
    //    return result;
    //}

    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input3.txt"));
#endif


        //task1
        string[] interval = Console.ReadLine().Split();
        BigInteger start = BigInteger.Parse(interval[0]);
        BigInteger end = BigInteger.Parse(interval[1]);
        ////int start = 1;
        ////int end = 99;
        Console.WriteLine(CountLuckyNumbers(start, end));
        //Console.WriteLine(CheckIfLucky(5));


        //task2
        //int[] nums = { -2, -1, -4, -3 };
        //int[] nums = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
        //List<int> num = new List<int> { -2, -1, -4, -3 };
        //int percentile = 50;
        string[] strNums = Console.ReadLine().Split(',');
        //int[] nums = new int[strNums.Length];
        List<int> num = new List<int>();
        for (int i = 0; i < strNums.Length; i++)
        {
            //nums[i] = int.Parse(strNums[i]);
            num.Add(int.Parse(strNums[i]));
        }
        int percentile = int.Parse(Console.ReadLine());
        Console.WriteLine(PercentBoundary(num, percentile));
        //Console.WriteLine(FindPercentile(nums, percentile));
    }
}
