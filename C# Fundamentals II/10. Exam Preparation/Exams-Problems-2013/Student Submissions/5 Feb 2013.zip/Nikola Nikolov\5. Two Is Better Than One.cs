using System;
using System.Text;

class Brackets
{
    static void Main()
    {
        int lines = int.Parse(Console.ReadLine());
        string indent = Console.ReadLine();
        StringBuilder output = new StringBuilder(2000);
        int indentCount = 0;

        for (int i = 0; i < lines; i++)
        {
            StringBuilder line = new StringBuilder(Console.ReadLine().Trim());
            int start = 0;
            bool print = true;
            for (int j = 0; j < line.Length; j++)
            {
                if (line.Length > 1)
                {
                    while (line[j] == ' ' && (j + 1 != line.Length) && line[j + 1] == ' ')
                    {
                        line.Remove(j, 1);
                    }
                }

                if (line[j] == '{')
                {
                    print = false;
                    string toAppend = line.ToString().Substring(start, j - start).Trim();
                    if (!string.IsNullOrEmpty(toAppend))
                    {
                        for (int k = 0; k < indentCount; k++)
                        {
                            output.Append(indent);
                        }

                        output.AppendLine(toAppend);
                    }

                    for (int k = 0; k < indentCount; k++)
                    {
                        output.Append(indent);
                    }

                    output.AppendLine("{");

                    indentCount++;
                    start = j + 1;
                }

                if (line[j] == '}')
                {
                    print = false;
                    string toAppend = line.ToString().Substring(start, j - start).Trim();
                    if (!string.IsNullOrEmpty(toAppend))
                    {
                        for (int k = 0; k < indentCount; k++)
                        {
                            output.Append(indent);
                        }

                        output.AppendLine(toAppend);
                    }

                    if (indentCount != 0)
                    {
                        indentCount--;
                    }

                    for (int k = 0; k < indentCount; k++)
                    {
                        output.Append(indent);
                    }

                    output.AppendLine("}");
                    start = j + 1;
                }
            }

            if (print && line.Length > 0)
            {
                for (int k = 0; k < indentCount; k++)
                {
                    output.Append(indent);
                }

                output.AppendLine(line.ToString().Trim());
            }
        }

        Console.Write(output);
    }
}
/*
5
....
using System;    namespace Stars
{class Program{
static     string[] separators
= new string[] { " " };}
}
*/
