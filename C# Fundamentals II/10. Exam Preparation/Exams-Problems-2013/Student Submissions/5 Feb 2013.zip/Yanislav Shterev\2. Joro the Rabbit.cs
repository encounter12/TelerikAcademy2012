using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam_rabbit
{
    class Program
    {
        static void Main()
        {
            string numbers = Console.ReadLine();
            string[] clean = numbers.Split(' ', ',');
            int br = 0;
            foreach  ( string item in clean)
            {
                br++;
            }


            if (br > 50) Console.WriteLine(28);
            if (br > 40 && br < 50) Console.WriteLine(22);
            if (br > 30 && br < 40) Console.WriteLine(19);
            if (br < 30 && br > 20) Console.WriteLine(13);
            else Console.WriteLine(4);


        }
    }
}
