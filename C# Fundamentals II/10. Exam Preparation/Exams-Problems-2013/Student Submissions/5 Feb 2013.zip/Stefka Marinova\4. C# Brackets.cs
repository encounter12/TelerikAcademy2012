using System;
using System.Text.RegularExpressions;
using System.Text;

class CSharpBrackets
{
    static void Main()
    {
        string input =
@"{a{
}
}";

        input =
@"using System;        namespace Stars
{class Program{
static     string[] separators
= new string[] { "" "" };}
}";


        string tab = @">>";   // @"/*--*/";
        //tab = @"....";

        int Lines = int.Parse(Console.ReadLine());
        tab = Console.ReadLine();
        StringBuilder code = new StringBuilder();
        for (int i = 0; i < Lines; i++)
        {
            code.Append(Console.ReadLine());
        }
        input = code.ToString();


        input = Regex.Replace(input, @"(\s)+", @"$1");

        int indentCount = 0;
        char prev = input[0];
        int printPos = 0;

        while (printPos < input.Length)
        {
            int open, close;
            open = input.IndexOf('{', printPos);
            close = input.IndexOf('}', printPos);
            if (open < 0) open = int.MaxValue;
            if (close < 0) close = int.MaxValue;

            int indFirstBracket = Math.Min(open, close);

            if (printPos < indFirstBracket)
            {
                if (open < 0 && close < 0)
                {
                    IndentText(indentCount, tab, input.Substring(printPos));
                    printPos = input.Length;
                }
                else
                {
                    string pieceToPrint = input.Substring(printPos, indFirstBracket - printPos);
                    int indNewLinesInPiece = pieceToPrint.IndexOf('\n');
                    if (indNewLinesInPiece > -1)
                    {
                        pieceToPrint = input.Substring(printPos, indNewLinesInPiece);
                        if (pieceToPrint.Length > 0)
                        {
                            IndentText(indentCount, tab, pieceToPrint);
                        }
                        printPos += indNewLinesInPiece + 1;
                    }
                    else
                    {
                        IndentText(indentCount, tab, pieceToPrint);
                        printPos = indFirstBracket;
                    }

                }

            }
            else
            {
                if (input[indFirstBracket].Equals('{'))
                {
                    IndentText(indentCount, tab, "{");
                    indentCount++;
                }
                else
                {
                    indentCount--;
                    IndentText(indentCount, tab, "}");
                }
                printPos++;



            }

        }

    }

    static void IndentText(int tabsNum, string tab, string text)
    {
        // if (text.IndexOf('\n') > -1 && text.Length > 0) { }
        // text = text.TrimEnd(new char[] {'\r',' ' });
        //Console.WriteLine(text.Length + ":" + text.IndexOf("\r\n"));
        //Console.WriteLine("nL");
        //  Console.WriteLine(text.IndexOf('\n') + ":" + text.Length);
        text = text.Trim();
        //text = Regex.Replace(text, @"(\s)+", @"$1");

        //Console.WriteLine(text.Equals("\r"));
        if (!(text.Length == 2 && text.IndexOf("\r\n") > -1))
        {
            for (int i = 0; i < tabsNum; i++)
            {
                Console.Write(tab);
            }
            Console.WriteLine(text);
        }

    }
}
