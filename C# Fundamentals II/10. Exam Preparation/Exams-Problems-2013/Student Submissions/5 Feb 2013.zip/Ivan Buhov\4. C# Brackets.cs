using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Brackets
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string indentor = Console.ReadLine();
        StringBuilder result = new StringBuilder();
        int indent = 0;
        for (int lineNum = 0; lineNum < n; lineNum++)
        {
            string line = Console.ReadLine().Trim();
            if (line == String.Empty)
            {
                continue;
            }

            if (lineNum != 0)
            {
                result.Append('\n');
            }
            result.Append(GetIndent(indentor, indent));
            for (int i = 0; i < line.Length; i++)
            {
                if (Char.IsWhiteSpace(line[i]) && i > 0 && Char.IsWhiteSpace(line[i - 1]))
                {
                    continue;
                }

                if (line[i] == '{')
                {
                    if (i == 0 && i != line.Length - 1)
                    {
                        result.Append('{');
                        result.Append('\n');
                        indent++;
                        result.Append(GetIndent(indentor, indent));
                        continue;
                    }

                    if (i != 0 && i == line.Length - 1)
                    {
                        result.Append('\n');
                        result.Append(GetIndent(indentor, indent));
                        result.Append('{');
                        indent++;
                        continue;
                    }

                    if (i == 0 && i == line.Length - 1)
                    {
                        result.Append('{');
                        indent++;
                        continue;
                    }

                    result.Append("\n");
                    result.Append(GetIndent(indentor, indent));
                    result.Append('{');
                    result.Append('\n');
                    indent++;
                    result.Append(GetIndent(indentor, indent));
                    continue;
                }

                if (line[i] == '}')
                {
                    
                    if (i > 0 && line[i - 1] == '}' )
                    {
                        result.Remove(result.Length - indentor.Length - 1, indentor.Length + 1);
                    }
                    
                    //result.Remove(result.Length - indentor.Length, indentor.Length);
                    if (i == 0 && i != line.Length - 1)
                    {
                        result.Remove(result.Length - indentor.Length, indentor.Length);
                        result.Append('}');
                        result.Append('\n');
                        indent--;
                        result.Append(GetIndent(indentor, indent));
                        continue;
                    }

                    if (i != 0 && i == line.Length - 1)
                    {
                        result.Append('\n');
                        indent--;
                        result.Append(GetIndent(indentor, indent));
                        result.Append('}');
                        continue;
                    }

                    if (i == 0 && i == line.Length - 1)
                    {
                        result.Remove(result.Length - indentor.Length, indentor.Length);
                        result.Append('}');
                        indent--;
                        continue;
                    }

                    result.Append('\n');
                    indent--;
                    result.Append(GetIndent(indentor, indent));
                    result.Append('}');
                    result.Append('\n');
                    result.Append(GetIndent(indentor, indent));
                    continue;
                }

                result.Append(line[i]);
            }

            if (Char.IsWhiteSpace(result[result.Length - 1]))
            {
                result.Remove(result.Length - 1, 1);
            }
        }

        Console.WriteLine(result);
    }

    static string GetIndent(string indentor, int times)
    {
        StringBuilder indent = new StringBuilder(indentor.Length * times);
        for (int i = 0; i < times; i++)
        {
            indent.Append(indentor);
        }
        return indent.ToString();
    }
}
