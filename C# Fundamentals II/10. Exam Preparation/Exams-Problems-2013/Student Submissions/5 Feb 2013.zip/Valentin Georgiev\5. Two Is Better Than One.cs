using System;
using System.Collections.Generic;

class twoIsBetterThanOne
{
    static void Main()
    {
        string firstNumbers = Console.ReadLine();
        string[] firstNums = firstNumbers.Split(' ');
        long A = long.Parse(firstNums[0]);
        long B = long.Parse(firstNums[1]);
        string numList = Console.ReadLine();
        numList = numList.Trim();
        int P = int.Parse(Console.ReadLine());
        long count = 0;
        for (long i = A; i <= B; i++)
        {
            if (i < 10)
            {
                if (i != 3 && i != 5)
                {
                    continue;
                }
                else
                {
                    count++;
                }
            }
            else
            {
                bool isPalindrome = false;
                bool checkPalindrome = false;
                char[] num = i.ToString().ToCharArray();
                for (int k = 0; k < num.Length; k++)
                {
                    if (num[k] != '5' && num[k] != '3')
                    {
                        checkPalindrome = false;
                        break;
                    }
                    else
                    {
                        checkPalindrome = true;
                    }
                }
                if (checkPalindrome)
                {
                    int length = num.Length / 2;
                    for (int j = 0; j < length; j++)
                    {
                        if (num[j] == num[num.Length - 1 - j])
                        {
                            isPalindrome = true;
                        }
                        else
                        {
                            isPalindrome = false;
                        }
                    }
                    if (isPalindrome)
                    {
                        count++;
                    }
                }
            }
        }
        Console.WriteLine(count);
        string[] nums = numList.Split(',');
        int[] numbers = new int[nums.Length];
        for (int i = 0; i < nums.Length; i++)
        {
            numbers[i] = int.Parse(nums[i]);
        }
        int counter = 0;
        int validNum = 0;
        int smallestNum = numbers[0];
        for (int i = 0; i < numbers.Length; i++)
        {
            for (int j = 0; j < numbers.Length; j++)
            {
                if (numbers[i] >= numbers[j])
                {
                    counter++;
                }
            }
            float percentage = ((float)counter / (float)numbers.Length)*100;
            if (percentage >= P)
            {
                validNum = numbers[i];
            }
            if (smallestNum > validNum)
            {
                smallestNum = validNum;
            }
            percentage = 0;
            counter = 0;
        }
        Console.WriteLine(smallestNum);
    }
}
