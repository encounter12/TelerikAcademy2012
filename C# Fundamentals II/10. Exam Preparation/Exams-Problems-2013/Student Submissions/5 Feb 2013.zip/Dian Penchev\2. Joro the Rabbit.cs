using System;
class JoroTheRabbit
{
    static void Main()
    {
        int startIndex = -1;
        int currentInd = 0;
        int remainInd = 0;
        int step = 1;
        int stepsCount = 1;
        int maxSteps = 1;
        string numbers = Console.ReadLine();//"1, -2, -3, 4, -5, 6, -7, -8";
        string[] digits = numbers.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
        int[] nums = new int[digits.Length];
        for (int i = 0; i < nums.Length; i++)
        {
            nums[i] = int.Parse(digits[i]);
        }


        do
        {
            startIndex++;
            step = 1;
            stepsCount = 2;
            int startindexstep = startIndex + step;
            do
            {
                if (startindexstep > nums.Length - 1)
                {
                    startindexstep = (startindexstep - nums.Length);
                }
                if (nums[startIndex] > nums[startindexstep])
                {
                    step++;
                    startindexstep++;
                }
                else
                {
                    break;
                }
            }
            while ((true) || (step > nums.Length));
            if (step < nums.Length)
            {

                currentInd = startIndex;
                do
                {
                    if (currentInd + step > nums.Length - 1)
                    {
                        currentInd = nums.Length - currentInd + step;
                    }
                    if (nums[currentInd] < nums[currentInd + step])
                    {

                        currentInd = currentInd + step;
                        stepsCount++;
                    }
                    else
                    {
                        break;
                    }
                } while (true);
                if (stepsCount > maxSteps)
                {
                    maxSteps = stepsCount;
                }
            }

        } while (startIndex < nums.Length - 1);

        Console.WriteLine(maxSteps);
    }
}