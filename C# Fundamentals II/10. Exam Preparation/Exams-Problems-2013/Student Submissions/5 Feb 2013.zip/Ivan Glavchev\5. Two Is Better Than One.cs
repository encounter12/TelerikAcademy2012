using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2tasks
{
	class Program
	{
		static void Main(string[] args)
		{
			List<ulong> palindromes = new List<ulong>();
			for (int i = 1; i < 19; ++i)
			{
				addPalindromesToList(palindromes, i);
			}
			palindromes.Sort();

			string[] input1 = Console.ReadLine().Split(' ');
			ulong a = ulong.Parse(input1[0]);
			ulong b = ulong.Parse(input1[1]);

			string[] input2 = Console.ReadLine().Split(',');
			List<int> numbers = new List<int>();
			for (int i = 0; i != input2.Length; ++i)
			{
				numbers.Add(int.Parse(input2[i]));
			}
			numbers.Sort();

			int percentage = int.Parse(Console.ReadLine());

			// task 1
			int count = 0;
			for (int i = 0; i != palindromes.Count; ++i)
			{
				if (palindromes[i] >= a && palindromes[i] <= b)
				{
					count++;
				}
			}
			Console.WriteLine( count );

			//task 2
			for (int i = 0; i != numbers.Count; ++i)
			{
				if ((decimal)(i + 1) / numbers.Count >= (decimal)percentage / 100)
				{
					Console.WriteLine(numbers[i]);
					return;
				}
			}
		}

		private static void addPalindromesToList(List<ulong> palindromes, int length)
		{
			StringBuilder sb = new StringBuilder();
			char[] arr = new char[length / 2];
			assignCharArray(arr);
			while(true)
			{
				if (length % 2 == 1)
				{
					sb.Append(arr);
					sb.Append('3');
					sb.Append(reverse(arr));
					palindromes.Add(ulong.Parse(sb.ToString()));
					sb.Clear();

					sb.Append(arr);
					sb.Append('5');
					sb.Append(reverse(arr));
					palindromes.Add(ulong.Parse(sb.ToString()));
					sb.Clear();
				}
				else
				{
					sb.Append(arr);
					sb.Append(reverse(arr));
					palindromes.Add(ulong.Parse(sb.ToString()));
					sb.Clear();
				}
				try
				{
					arr = nextCombination(arr);
				}
				catch (Exception)
				{
					break;
				}
			}
		}

		private static char[] reverse(char[] arr)
		{
			for (int i = 0; i != arr.Length / 2; ++i)
			{
				char t = arr[i];
				arr[i] = arr[arr.Length - i - 1];
				arr[arr.Length - i - 1] = t;
			}
			return arr;
		}

		private static char[] nextCombination(char[] arr)
		{
			int i = arr.Length - 1;
			int j = 0;
			while (i != -1 && arr[i] == '5')
			{
				--i;
				++j;
			}

			if (i == -1) throw new Exception("complete");

			arr[i] = '5';
			j = i + 1;

			while (j != arr.Length)
			{
				arr[j] = '3';
				++j;
			}
			return arr;
		}

		private static void assignCharArray(char[] arr)
		{
			for (int i = 0; i != arr.Length; ++i)
			{
				arr[i] = '3';
			}
		}

		
	}
}
