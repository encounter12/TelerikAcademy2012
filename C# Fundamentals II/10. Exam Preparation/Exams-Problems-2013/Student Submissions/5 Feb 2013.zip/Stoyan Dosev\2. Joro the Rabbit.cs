using System;
using System.Collections.Generic;

class Rabbit
{
    static void Main()
    {
        string arr = Console.ReadLine();
        char[] ch = {',',' '};
        string[] bbb = arr.Split(ch, StringSplitOptions.RemoveEmptyEntries);
        int[] array = new int[bbb.Length];
        for (int i = 0; i < bbb.Length; i++)
        {
            array[i] = int.Parse(bbb[i]);
        }
         //{ 1, -2, -3, 4, -5, 6, -7, -8 };
        //{1,2,3,4,5,6,7,8,9,10};
        List<int> path = new List<int>(array);

        Queue<int> tries = new Queue<int>();
        Queue<int> jumps = new Queue<int>();

        Array.Sort(array);

        int maxCount = 0;
        for (int n = 0; n < array.Length; n++)
        {
            int count = 0;

            int num = array[n];
            int countTimes = 0;

            for (int p = 1; p < array.Length; p++)
            {
                path.Clear();
                path.AddRange(array);
                jumps.Enqueue(num);
                countTimes = 0;


                while (count <= array.Length)
                {
                    count++;
                    int current = jumps.Dequeue();

                    for (int i = 0; i < path.Count; i++)
                    {
                        if (current == path[i])
                        {
                            path.Remove(current);
                            
                            countTimes++;
                            if (countTimes > maxCount)
                            {
                                maxCount = countTimes;
                                
                            }
                            
                        }
                    }

                    jumps.Enqueue(current + p);
                    if (path.Count == 0)
                    {
                        break;
                    }
                    
                }
            }
            
            


        }
        Console.WriteLine(maxCount);

    }
}
