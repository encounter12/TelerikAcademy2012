using System;

namespace _5.Two_Is_Better_Than_One
{
    class Program
    {
        static void Main()
        {
            string AB = Console.ReadLine();
            string[] ab = AB.Split(' ');
            long A = long.Parse(ab[0]);
            long B = long.Parse(ab[1]);

            string input = Console.ReadLine();
            string[] n = input.Split(',');
            int[] numbers = new int[n.Length];
            for (byte i = 0; i < n.Length; i++)
            {
                numbers[i] = int.Parse(n[i]);
            }

            decimal P = decimal.Parse(Console.ReadLine());


            int count = 0;
            char[] luckyNumbers = { '3', '5' };
            for (long j = A; j <= B; j++)
            {
                string str = j.ToString();
                int length = str.Length;
                for (int i = 0; i < (length / 2); i++)
                {
                    if (str[i] == str[length - 1 - i] && str[i] == luckyNumbers[0] || str[i] == str[length - 1 - i] && str[i] == luckyNumbers[1])
                    {
                        count++;
                    }
                    else continue;
                }
            }
            if (A <= 3 && B >= 5)
            {
                Console.WriteLine(count + 2);
            }
            else
            {
                Console.WriteLine(count);
            }

            Array.Sort(numbers);
            P = P / 100;
            decimal middle = (numbers.Length - 1) * P;
            Console.WriteLine(numbers[(int)middle]);
        }
    }
}