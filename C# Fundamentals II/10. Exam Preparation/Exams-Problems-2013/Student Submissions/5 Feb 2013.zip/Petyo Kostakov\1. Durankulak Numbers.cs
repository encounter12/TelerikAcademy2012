using System;
using System.Text;
using System.Numerics;

class DurankulakNumbers
{
    static void Main()
    {
        string input = Console.ReadLine();
        input = input.ToUpper();
        string alphabet = " ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        string alphabetZero = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder reverced = new StringBuilder();

        for (int i = input.Length - 1; i >= 0; i--)
        {
            reverced.Append(input[i]);
        }
        decimal sum = 0;
        for (int i = 0; i < reverced.Length; i++)
        {
            if (i == 0)
                sum += alphabetZero.IndexOf(reverced[i]);
            if (i == 1)
                sum += 26 * alphabet.IndexOf(reverced[i]);
            if (i > 1)
            {
                decimal powNum = 168;
                for (int k = 0; k < i - 2; k++)
                {
                    powNum *= powNum;
                }
                sum += powNum * alphabetZero.IndexOf(reverced[i]);
            }
        }
        Console.WriteLine(sum);
    }
}
