using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;


class DurankulakNumber
{
    static void Main()
    {
        string[] arr = {"A", "B", "C", "D", "E", "F", "G","H", "I", "J", "K", "L", "M", "N", "O","P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                         "aA", "aB", "aC", "aD", "aE", "aF", "aG","aH", "aI", "aJ", "aK", "aL", "aM", "aN", "aO","aP", "aQ", "aR", "aS", "aT", "aU", "aV", "aW", "aX", "aY", "aZ",  
                         "bA", "bB", "bC", "bD", "bE", "bF", "bG","bH", "bI", "bJ", "bK", "bL", "bM", "bN", "bO","bP", "bQ", "bR", "bS", "bT", "bU", "bV", "bW", "bX", "bY", "bZ",
                         "cA", "cB", "cC", "cD", "cE", "cF", "cG","cH", "cI", "cJ", "cK", "cL", "cM", "cN", "cO","cP", "cQ", "cR", "cS", "cT", "cU", "cV", "cW", "cX", "cY", "cZ",
                         "dA", "dB", "dC", "dD", "dE", "dF", "dG","dH", "dI", "dJ", "dK", "dL", "dM", "dN", "dO","dP", "dQ", "dR", "dS", "dT", "dU", "dV", "dW", "dX", "dY", "dZ",
                         "eA", "eB", "eC", "eD", "eE", "eF", "eG","eH", "eI", "eJ", "eK", "eL", "eM", "eN", "eO","eP", "eQ", "eR", "eS", "eT", "eU", "eV", "eW", "eX", "eY", "eZ",
                          "fA", "fB", "fC", "fD", "fE", "fF", "fG","fH", "fI", "fJ", "fK", "fL"
                       };
        
        string number = Console.ReadLine();
        StringBuilder builder = new StringBuilder();
        bool isUpper = true;

        foreach (char ch in number)
        {
            if (Char.IsLower(ch))
            {
                isUpper = false;
            }
        }

        if (!isUpper)
        {
            
            for (int i = 0; i < number.Length - 1; i++)
            {
                if (Char.IsLower(number[i]))
                {
                    builder.Append(' ');
                    builder.Append(number[i]);
                    builder.Append(number[i + 1]);
                    i++;

                }
                else if (Char.IsUpper(number[i]))
                {
                    builder.Append(' ');
                    builder.Append(number[i]);
                }
                
            }

            
        }

        else
        {
            foreach (char ch in number)
            {
                builder.Append(' ');
                builder.Append(ch);
            }
        }

        Console.WriteLine(Convert(builder, arr));
    }

    static BigInteger Convert(StringBuilder builder, string[] arr)
    {
        BigInteger result = 0;
        BigInteger index = 1;
        string str = builder.ToString();
        string[] separators = { " " };
        string[] newStr = str.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        for (int i = newStr.Length - 1; i >= 0; i--)
        {
            BigInteger indexOfStr = GetIndex(newStr[i], arr);
            result += index * indexOfStr;
            index *= 168;
        }
        return result;
    }

    static BigInteger GetIndex(string str, string[] arr)
    {
        BigInteger index = -1;
        for (int i = 0; i < arr.Length; i++)
        {
            if (arr[i] == str)
                index = i;
        }
        return index;
    }
}

