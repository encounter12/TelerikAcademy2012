using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// The name of the task is: Joro the rabbit
class Problem2
{
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("input"));
#endif

        string vhod = Console.ReadLine();

        Console.WriteLine(JoroJumps(ReatInput(vhod)));

    }
    static int[] ReatInput(string input)
    {
        char[] splits = { ',', ' ' };
        var nums = input.Split(splits, StringSplitOptions.RemoveEmptyEntries);
        int[] result = new int[nums.Length];
        for (int i = 0; i < nums.Length; i++)
        {
            result[i] = int.Parse(nums[i]);
        }
        return result;
    }
    static int JoroJumps(int[] terrain)
    { 
        // steps are form 1 to source.lenght - 1
        int size = terrain.Length;
        int maxCount = int.MinValue;
        bool posibleJump = true;
        int maxResult = int.MinValue;
       // int jumpCount = 0;
        List<int> counter = new List<int>();
        for (int startPos = 1; startPos < size -1; startPos++)
        {
            int currPos = startPos;
            for (int step = 2; step < size; step++)
            {
                
                if (terrain[currPos] < terrain[Jump(currPos, step, size)])
                {
                    int turnoff = 0;
                    while (posibleJump && turnoff < 1000)
                    {
                        if (counter.Count == 0)
                        {
                            counter.Add(currPos);
                        }
                        currPos = Jump(currPos, step, size);
                        counter.Add(currPos);
                        posibleJump = canJump(currPos, step, terrain, counter);
                        turnoff++;
                    }
                    if (counter.Count > maxCount)
                    {
                        maxCount = counter.Count;
                        if (maxCount > maxResult)
                        {
                            maxResult = maxCount;
                        }
                    }
                    counter.Clear();
                    currPos = startPos;
                    posibleJump = true;
                }
            }
           
        }
        if (maxResult != int.MinValue)
        {
            return maxResult;
        }
        else
        {
            return 1;
        }
    }
    static int Jump(int index, int step, int bound)
    { 
        int nextIndex = 0;
        if (index + step < bound)
        {
            nextIndex = index + step;
        }
        else
        {
            nextIndex = (index + step) - bound;
        }
        return nextIndex;

    }
    static bool canJump(int currIndex, int step, int[] field, List<int> visited)
    { 
        //must return true if next value is bigger
        //must return false if nex value is lower or visited
        bool notVisited = true;
        if (visited.LastIndexOf((Jump(currIndex, step, field.Length)), 0) >= 0)
        {
            notVisited = false;
        }
        if (field[currIndex] < field[Jump(currIndex, step, field.Length)] && notVisited)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
