using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _05
{
    class Program
    {
        static Dictionary<string, int> capital = new Dictionary<string, int>();
        static void Main(string[] args)
        {

            int index = 0;
            for (int i = 65; i <= 90; i++)
            {
                string current = ((char)i).ToString();
                capital.Add(current, index);
                index++;
            }

            for (int i = 97; i < 123; i++)
            {
                for (int j = 65; j <= 90&&index<168; j++)
                {
                    string currenta = ((char)i).ToString();
                    string currentA = currenta+((char)j).ToString();
                    capital.Add(currentA, index);
                    index++;
                }
            }

            string durankulakNumbers = Console.ReadLine();
            int length = durankulakNumbers.Length;
            string currentDurankulak=String.Empty;
            int power = 0;
            BigInteger sum = 0;
            for (int i = length-1; i >= 0; i--)
            {
                currentDurankulak = String.Empty;
                do
                {
                    currentDurankulak = durankulakNumbers[i]+currentDurankulak;
                    i--;
                } while (i>=0 && durankulakNumbers[i]>96);
               i++;
               
               sum += GetSum(currentDurankulak,power);
               power++;
            }
            Console.WriteLine(sum);
        }

        private static BigInteger GetSum(string currentDurankulak, int power)
        {
            BigInteger sum = 0;
            BigInteger totalPower=1;
                for (int i = 0; i < power; i++)
			{
                totalPower *= 168;
			}
            sum = (capital[currentDurankulak] * totalPower);

                return sum;
        }
    }
}
