using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_5
{
    class Program
    {
        static void Main(string[] args)
        {
            //string[] input = File.ReadAllLines(@"C:\Test3.txt");
            string[] input = new string[5];
            input[0] = Console.ReadLine();
            input[1] = Console.ReadLine();
            input[2] = Console.ReadLine();
            string[] firstinput = input[0].Split(' ');

            int a = int.Parse(firstinput[0]);
            int b = int.Parse(firstinput[1]);
            int count = 0;

            for (int i = a + 1; i < b; i++)
            {
                string buff = (i).ToString();
                if (buff.ToCharArray().Where(x => x == '3').Count() + buff.Where(x => x == '5').Count() == i.ToString().Length && i.ToString().Length >= 2)
                {
                    count++;
                }
            }

            Console.Write(count);

            int[,] list = new int[50,2];
            string[] buffer = input[1].Split(',');

            for (int i = 0; i < buffer.Length; i++)
            {
                list[i, 0] = int.Parse(buffer[i]);
            }

            count = 0;
            int min = list[0, 0];

            for (int i = 0; i < buffer.Length; i++)
            {
                for (int j = i; j < buffer.Length+i; j++)
                {
                    if (list[i, 0] < list[j, 0])
                    {
                        list[i, 1] += 1;
                    }
                }
            }

            double procent;
            procent = (double.Parse(input[2]) / (double)100) * (double)buffer.Length;

            for (int i = 0; i < buffer.Length; i++)
            {
                double buf = (list[i, 1] / (double)100) * (double)buffer.Length;
                if (procent >= buf)
                {
                    //Console.WriteLine(list[i, 1]);
                }
            }

            //Console.ReadLine();
        }
    }
}
