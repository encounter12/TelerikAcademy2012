using System;
using System.Text;
using System.IO;

namespace Problem_1_CSharp_Clean_Code
{
    class Program
    {
        public static string IntToString(int value, char[] baseChars)
        {
            string result = string.Empty;
            int targetBase = baseChars.Length;

            do
            {
                result = baseChars[value % targetBase] + result;
                value = value / targetBase;
            }
            while (value > 0);

            return result;
        }

        static void Main()
        {
            string xx = Console.ReadLine();
                xx = IntToString(20,
                 new char[] { '0','1','2','3','4','5','6','7','8','9',
            'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
            'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x'});
            Console.WriteLine(20);
        }

    }
}
