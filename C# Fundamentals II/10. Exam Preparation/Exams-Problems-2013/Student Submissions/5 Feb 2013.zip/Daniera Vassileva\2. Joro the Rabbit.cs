using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brackets
{
    class Program
    {
        static void Main(string[] args)
        {
            string numberList = Console.ReadLine();// "1, -2, -3, 4, -5, 6, -7, 8";
            char[] separator = new char[] { ' ', ',' };
            string[] listOfNumbers = numberList.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            List<int> routeMax = new List<int>();
            List<int> currentRoute = new List<int>();
            int step=0;
           // int value=int.MinValue;
            int count=0;
            for (int j = 0; j < listOfNumbers.Length; j++)
			{   
                count=0;step=0;
                currentRoute.Add(Convert.ToInt32(listOfNumbers[j]));
	            for (int i = j + 1; i < listOfNumbers.Length; i++)
			    {
                   if ((Convert.ToInt32(listOfNumbers[j]) < Convert.ToInt32(listOfNumbers[i]))&&(count==0))
	                {
                        currentRoute.Add(Convert.ToInt32(listOfNumbers[i]));
                        step = i - j;
                        count++;
	                }
                    if ((Convert.ToInt32(listOfNumbers[j]) < Convert.ToInt32(listOfNumbers[i]))&&(step!=0)&&(step==i-j))
	                {
                        currentRoute.Add(Convert.ToInt32(listOfNumbers[i]));
			        }
                }
               if (currentRoute.Count>routeMax.Count)
                {
                    routeMax.Clear();
                    for (int i = 0; i < currentRoute.Count; i++)
			        {
			            routeMax.Add(currentRoute[i]);
			        }
                }
                currentRoute.Clear();
	      }
            Console.WriteLine(routeMax.Count);
    }
    }
}
