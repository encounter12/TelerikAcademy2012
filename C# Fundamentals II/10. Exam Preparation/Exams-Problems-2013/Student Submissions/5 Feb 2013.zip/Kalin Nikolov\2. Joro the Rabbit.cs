using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoroTheRabbit
{
    class JoroTheRabbit
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number of the jumps: ");
            int jumps = int.Parse(Console.ReadLine());
            int[] numbers = new int[jumps];
            
            Console.WriteLine("Enter the numbers of the terrain separated with comma and space");
            
            for (int i = 0; i < jumps; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
            }
        }
    }
}
