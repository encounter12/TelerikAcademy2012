using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContestLatest
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] minMax = input.Split(' ');
            ulong min = ulong.Parse(minMax[0]);
            ulong max = ulong.Parse(minMax[1]);
            string numberStr = Console.ReadLine();
            input = Console.ReadLine();
            int percentage = int.Parse(input);

            HashSet<ulong> result = AllPalindromic(min, max);

            Console.WriteLine(result.Count);

            //foreach (var item in result)
            //{
            //    Console.WriteLine(item);
            //}

            string[] arrStr = numberStr.Split(',');
            int[] numbers = new int[arrStr.Length];
            for (int i = 0; i < arrStr.Length; i++)
            {
                numbers[i] = int.Parse(arrStr[i].Trim());
            }

            Array.Sort(numbers);
            double k = (numbers.Length * (100 - percentage) / 100);
            int index = -1;

            if (k % 1 == 0)
            {
                index = numbers.Length - ((numbers.Length * (100 - percentage) / 100) + 1);
            }
            else
            {
                index = numbers.Length - ((numbers.Length * (100 - percentage) / 100));
            }

            Console.WriteLine(numbers[index]);
        }

        public static HashSet<ulong> AllPalindromic(ulong min, ulong max) 
        {
            HashSet<ulong> result = new HashSet<ulong>();

            if (3 > min && 3 < max)
            {
                result.Add(3);
            }

            if (5 > min && 5 < max)
            {
                result.Add(5);
            }

            string next = "3";

            bool cont = true;
            for (int i = 1; cont; i++) 
            {
                string rev = ReverseString(next);
                cont = false;
                string[] digits = { "", "3", "5" };
                for (int j = 0; j < 3; j++)
                {
                    ulong n = ulong.MaxValue;
                    if (ulong.TryParse(next + digits[j] + rev, out n))
                    {
                        if ((n < max && n > min) || n == max || n == min)
                        {
                            result.Add(n);
                        }

                        cont = true;
                    }
                    else
                    {
                        cont = false;
                    }
                }
                next = GenerateNextNumber(next);
            }

            return result;
        }

        public static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }

        public static string GenerateNextNumber(string str)
        {
            char[] arr = str.ToCharArray();

            if (arr[arr.Length - 1] == '3')
            {
                arr[arr.Length - 1] = '5';
                return new string(arr);

            }
            else
            {
                char[] nNumber = new char[arr.Length + 1];

                for (int i = 0; i < arr.Length; i++)
                {
                    nNumber[i] = arr[i];
                }

                nNumber[nNumber.Length - 1] = '3';
                return new string(nNumber);
            }
        }
    }
}
