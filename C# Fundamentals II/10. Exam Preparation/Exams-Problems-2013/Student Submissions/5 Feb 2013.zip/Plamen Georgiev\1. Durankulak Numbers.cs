using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class Program
{
    static void Main()
    {
        string input = Console.ReadLine();
        int sum = 0;
        int value = 0;
        byte isSmall = 0;
        char[] arr = new char[input.Length];
        for (int i = 0; i < input.Length; i++)
        {
            arr[i] = input[i];
        }
        Array.Reverse(arr);

        for (int i = 0; i < arr.Length; i++)
        {
            switch (arr[i])
            {
                case 'A':
                    {
                        value = 0;
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'a'))
                        {
                            value += 26;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'b'))
                        {
                            value += 52;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'c'))
                        {
                            value += 78;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'd'))
                        {
                            value += 104;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'e'))
                        {
                            value += 130;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'f'))
                        {
                            value += 156;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        sum += (int)(Math.Pow(168, i) * value);
                        break;
                    }
                case 'B':
                    {
                        value = 1;
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'a'))
                        {
                            value += 26;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'b'))
                        {
                            value += 52;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'c'))
                        {
                            value += 78;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'd'))
                        {
                            value += 104;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'e'))
                        {
                            value += 130;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'f'))
                        {
                            value += 156;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        sum += (int)(Math.Pow(168, i) * value);
                        break;
                    }
                case 'C':
                    {
                        value = 2;
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'a'))
                        {
                            value += 26;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'b'))
                        {
                            value += 52;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'c'))
                        {
                            value += 78;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'd'))
                        {
                            value += 104;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'e'))
                        {
                            value += 130;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'f'))
                        {
                            value += 156;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        sum += (int)(Math.Pow(168, i) * value);
                        break;
                    }
                case 'D':
                    {
                        value = 3;
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'a'))
                        {
                            value += 26;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'b'))
                        {
                            value += 52;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'c'))
                        {
                            value += 78;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'd'))
                        {
                            value += 104;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'e'))
                        {
                            value += 130;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'f'))
                        {
                            value += 156;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        sum += (int)(Math.Pow(168, i) * value);
                        break;
                    }
                case 'E':
                    {
                        value = 4;
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'a'))
                        {
                            value += 26;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'b'))
                        {
                            value += 52;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'c'))
                        {
                            value += 78;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'd'))
                        {
                            value += 104;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'e'))
                        {
                            value += 130;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'f'))
                        {
                            value += 156;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        sum += (int)(Math.Pow(168, i) * value);
                        break;
                    }
                case 'F':
                    {
                        value = 5;
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'a'))
                        {
                            value += 26;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'b'))
                        {
                            value += 52;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'c'))
                        {
                            value += 78;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'd'))
                        {
                            value += 104;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'e'))
                        {
                            value += 130;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'f'))
                        {
                            value += 156;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        sum += (int)(Math.Pow(168, i) * value);
                        break;
                    }
                case 'G':
                    {
                        value = 6;
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'a'))
                        {
                            value += 26;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'b'))
                        {
                            value += 52;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'c'))
                        {
                            value += 78;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'd'))
                        {
                            value += 104;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'e'))
                        {
                            value += 130;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'f'))
                        {
                            value += 156;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        sum += (int)(Math.Pow(168, i) * value);
                        break;
                    }

                case 'H':
                    {
                        value = 7;
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'a'))
                        {
                            value += 26;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'b'))
                        {
                            value += 52;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'c'))
                        {
                            value += 78;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'd'))
                        {
                            value += 104;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'e'))
                        {
                            value += 130;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'f'))
                        {
                            value += 156;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        sum += (int)(Math.Pow(168, i) * value);
                        break;
                    }
                case 'I':
                    {
                        value = 8;
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'a'))
                        {
                            value += 26;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'b'))
                        {
                            value += 52;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'c'))
                        {
                            value += 78;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'd'))
                        {
                            value += 104;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'e'))
                        {
                            value += 130;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'f'))
                        {
                            value += 156;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        sum += (int)(Math.Pow(168, i) * value);
                        break;
                    }
                case 'J':
                    {
                        value = 9;
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'a'))
                        {
                            value += 26;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'b'))
                        {
                            value += 52;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'c'))
                        {
                            value += 78;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'd'))
                        {
                            value += 104;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'e'))
                        {
                            value += 130;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'f'))
                        {
                            value += 156;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        sum += (int)(Math.Pow(168, i) * value);
                        break;
                    }
                case 'K':
                    {
                        value = 10;
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'a'))
                        {
                            value += 26;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'b'))
                        {
                            value += 52;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'c'))
                        {
                            value += 78;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'd'))
                        {
                            value += 104;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'e'))
                        {
                            value += 130;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'f'))
                        {
                            value += 156;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        sum += (int)(Math.Pow(168, i) * value);
                        break;
                    }
                case 'L':
                    {
                        value = 11;
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'a'))
                        {
                            value += 26;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'b'))
                        {
                            value += 52;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'c'))
                        {
                            value += 78;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'd'))
                        {
                            value += 104;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'e'))
                        {
                            value += 130;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        if ((i + 1 <= arr.Length - 1) && (arr[i + 1] == 'f'))
                        {
                            value += 156;
                            isSmall++;
                            sum += (int)(Math.Pow(168, i) * value);
                            break;
                        }
                        sum += (int)(Math.Pow(168, i) * value);
                        break;
                    }
                case 'M': { sum += (i * 12); break; }
                case 'N': { sum += (i * 13); break; }
                case 'O': { sum += (i * 14); break; }
                case 'P': { sum += (i * 15); break; }
                case 'Q': { sum += (i * 16); break; }
                case 'R': { sum += (i * 17); break; }
                case 'S': { sum += (i * 18); break; }
                case 'T': { sum += (i * 19); break; }
                case 'U': { sum += (i * 20); break; }
                case 'V': { sum += (i * 21); break; }
                case 'W': { sum += (i * 22); break; }
                case 'X': { sum += (i * 23); break; }
                case 'Y': { sum += (i * 24); break; }
                case 'Z': { sum += (i * 25); break; }
                default:
                    break;
            }


        }
        Console.WriteLine(sum);
    }
}