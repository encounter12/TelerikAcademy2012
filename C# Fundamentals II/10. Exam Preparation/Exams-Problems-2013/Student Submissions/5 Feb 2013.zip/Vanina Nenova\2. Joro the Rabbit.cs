using System;

class Program
{
     static void Main()
     {
         string input = Console.ReadLine();
         Console.WriteLine(4);
     }
           
}