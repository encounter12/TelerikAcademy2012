using System;
using System.Numerics;

class DurankulakNumbers
{
    static void Main()
    {
        string number = Console.ReadLine();
        Console.WriteLine(ConvertToDec(number, 168));
    }

    static int[] numbers = { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90 };

    private static BigInteger ConvertToDec(string number, int fromBase)
    {
        BigInteger dec = 0;
        int length = number.Length;
        int digitsCount = length;

        for (int i = length - 1; i >= 0; i--)
        {
            BigInteger digit = Array.BinarySearch(numbers, number[i]);
            if (i > 0)
            {
                if (number[i - 1] > 96 && number[i - 1] < 123)
                {
                    i--;
                    digit += 26 * (number[i] - 96);
                    digitsCount--;
                }
            }

            dec += digit * (BigInteger)Math.Pow(fromBase, digitsCount - 1 - i);
        }

        return dec;
    }
}
// fLfLfLfLfLfLfLfLfLfLfLfLfLfLfLfL