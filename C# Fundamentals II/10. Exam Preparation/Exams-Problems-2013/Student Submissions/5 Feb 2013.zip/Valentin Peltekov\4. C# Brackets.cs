using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4.Csharp_Brackets
{
    class Brackets
    {
        static void Main()
        {
            int numberOfLines = int.Parse(Console.ReadLine());
            string indent = Console.ReadLine();

            StringBuilder input = new StringBuilder();

            for (int i = 0; i < numberOfLines; i++)
            {
                input.Append(Console.ReadLine());
            }

            for (int i = 0; i < input.Length; i++)
            {
                if ((input[i] == '{') || (input[i] == '}'))
                {
                    input.Insert((i + 1), ' ');
                    input.Insert((i), ' ');
                    i += 2;
                }
            }

            string str = input.ToString();

            string cleanedString = System.Text.RegularExpressions.Regex.Replace(str, @"\s+", " ");

            string[] words = cleanedString.Split(' ');

            foreach (var item in words)
            {
                Console.Write(item + " ");

                if (item == '{')
                {
                    Console.WriteLine();
                }
            }
        }
    }
}
