using System;
using System.Collections.Generic;
using System.Text;

class TwoIsBetterThanOne
{
    static void Main(string[] args)
    {
        string inputA = Console.ReadLine();
        string inputB = Console.ReadLine();
        int percentile = int.Parse(Console.ReadLine());

        int count = NumberOfLuckyNumbers(inputA);
        Console.WriteLine(count);

        int number = SmallestElement(inputB, percentile);
        Console.WriteLine(number);
    }

    static int SmallestElement(string inputB, int percentile)
    {
        string[] splitedInputB = inputB.Split(',');
        int[] numbers = new int[splitedInputB.Length];

        for (int i = 0; i < numbers.Length; i++)
        {
            numbers[i] = int.Parse(splitedInputB[i]);
        }

        Array.Sort(numbers);

        int index = (int)(Math.Round(numbers.Length * (percentile / 100.0)));

        int number = numbers[index - 1];

        return number;
    }

    static bool CheckPalindrome(ulong number)
    {
        ulong n = number;
        ulong rev = 0;
        ulong dig = 0;
        while (number > 0)
        {
            dig = number % 10;
            if (dig != 5 && dig != 3)
            {
                return false;                
            }
            rev = rev * 10 + dig;
            number = number / 10;
        }
        if (n == rev) return true;
        else return false;
    }

    static int NumberOfLuckyNumbers(string inputA)
    {
        string[] splitedInputA = inputA.Split(' ');

        ulong A = ulong.Parse(splitedInputA[0]);
        ulong B = ulong.Parse(splitedInputA[1]);
        bool palindrome;
        int count = 0;
        
        for (ulong i = A; i <= B; i++)
        {
            palindrome = false;
            palindrome = CheckPalindrome(i);
            if (palindrome == true)
                count++;           
        }
        return count;
    }
}