using System;
using System.Collections.Generic;
using System.Text;

class CSharpBrackets
{
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input2.txt"));
#endif


        int rowsNum = int.Parse(Console.ReadLine());
        string indent = Console.ReadLine();
        List<string> rows = new List<string>();
        for (int i = 0; i < rowsNum; i++)
        {
            rows.Add(Console.ReadLine());
        }

        StringBuilder output = new StringBuilder();
        StringBuilder lineBuilder = new StringBuilder();
        List<string> lines = new List<string>();

        bool firstOfLine = false;
        int count = 0;
        for (int j = 0; j < rowsNum; j++)
        {
            string line = rows[j].Trim();
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];

                if (c == '{')
                {
                    lines.Add(lineBuilder.ToString());
                    lineBuilder.Clear();
                    for (int indentNum = 0; indentNum < count; indentNum++)
                    {
                        lineBuilder.Append(indent);
                    }
                    lineBuilder.Append("{");
                    lines.Add(lineBuilder.ToString());
                    lineBuilder.Clear();
                    count++;
                    firstOfLine = true;

                }
                else if (c == '}')
                {
                    if (lineBuilder.ToString() == string.Empty)
                    {
                        count--;
                    }
                    else
                    {
                        lines.Add(lineBuilder.ToString());
                        lineBuilder.Clear();
                        count--;
                    }
                    for (int indentNum = 0; indentNum < count; indentNum++)
                    {
                        lineBuilder.Append(indent);
                    }
                    lineBuilder.Append("}");
                    lines.Add(lineBuilder.ToString());
                    lineBuilder.Clear();
                    //count--;
                }
                else
                {
                    //if(c == '\"' || c == '\'')
                    //{
                    //    lineBuilder
                    //}
                    if (firstOfLine)
                    {
                        for (int indentNum = 0; indentNum < count; indentNum++)
                        {
                            lineBuilder.Append(indent);
                        }
                        firstOfLine = false;
                    }
                    lineBuilder.Append(c.ToString());
                    if (i == line.Length - 1)
                    {
                        firstOfLine = true;
                        lines.Add(lineBuilder.ToString());
                        lineBuilder.Clear();
                        if (c == '}')
                        {
                            count--;
                        }
                    }
                }
            }
            
        }
        for (int i = 0; i < lines.Count; i++)
        {
            if (lines[i] != string.Empty)
            {
                Console.WriteLine(lines[i]);
            }
        }
    }
}
