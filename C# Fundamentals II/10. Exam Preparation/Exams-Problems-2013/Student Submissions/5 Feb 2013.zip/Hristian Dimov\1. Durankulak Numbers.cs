using System;
using System.Numerics;
   
class DurankulakNumbers
{
    static void Main(string[] args)
    {
        string[] alphabet = {
            "A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z",
            "aA","aB","aC","aD","aE","aF","aG","aH","aI","aJ","aK","aL","aM","aN","aO","aP","aQ","aR","aS","aT","aU","aV","aW","aX","aY","aZ",
            "bA","bB","bC","bD","bE","bF","bG","bH","bI","bJ","bK","bL","bM","bN","bO","bP","bQ","bR","bS","bT","bU","bV","bW","bX","bY","bZ",
            "cA","cB","cC","cD","cE","cF","cG","cH","cI","cJ","cK","cL","cM","cN","cO","cP","cQ","cR","cS","cT","cU","cV","cW","cX","cY","cZ",
            "dA","dB","dC","dD","dE","dF","dG","dH","dI","dJ","dK","dL","dM","dN","dO","dP","dQ","dR","dS","dT","dU","dV","dW","dX","dY","dZ",
            "eA","eB","eC","eD","eE","eF","eG","eH","eI","eJ","eK","eL","eM","eN","eO","eP","eQ","eR","eS","eT","eU","eV","eW","eX","eY","eZ",
            "fA","fB","fC","fD","fE","fF","fG","fH","fI","fJ","fK","fL","fM","fN","fO","fP","fQ","fR","fS","fT","fU","fV","fW","fX","fY","fZ",
        };
   
        string readInput = Console.ReadLine();
        int index = -1;
   
        BigInteger sum = 0;
        if (readInput.Length == 1 || readInput.Length == 2)
        {
            index = Array.IndexOf(alphabet, readInput);
            sum += index;
        }
        else
        {
            for (int i = 0; i < readInput.Length; i++)
            {
                if (readInput[i] >= 'a' && readInput[i] <= 'z')
                {
                    BigInteger howManyTimes = 1;
                    string concat = "" + readInput[i] + readInput[i + 1];
   
                    index = Array.IndexOf(alphabet, concat);
                    for (int j = 0; j < (readInput.Length - 2) / 2 - ( i / 2); j++)
                        howManyTimes *= 168;
   
                    sum += index * howManyTimes;
                    i++;
                }
                else
                {
                    BigInteger howManyTimes = 1;
                    index = Array.IndexOf(alphabet, readInput[i].ToString());
                    for (int j = 0; j < readInput.Length / 2 - i; j++)
                        howManyTimes *= 168;
                    sum += index * howManyTimes;
                }
            }
        }
        Console.WriteLine(sum);
    }
}