using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5.TwoIsBetterThan_One
{
    class Program
    {
        static void Main(string[] args)
        {
            string aAndB;
            string[] secondNumbers;
            int persent;
            InputData(out aAndB, out secondNumbers, out persent);

            string[] nums = aAndB.Split();

            //Might be no need to parse
            long a = long.Parse(nums[0]);
            long b = long.Parse(nums[1]);

            int palindromsCount = 0;

            palindromsCount = GetPalindroms(a, b, palindromsCount);  
            List<int> numsToInt = GetNums(secondNumbers);
            
            Console.WriteLine(palindromsCount);
            int val = (int)((persent * numsToInt.Count / 100));
            Console.WriteLine(numsToInt[ val]);
        }

     

        private static int GetPalindroms(long a, long b, int palindromsCount)
        {
            for (long i = a; i <= b; i++)
            {
                if (IsLuckPalindrome(i))
                {
                    palindromsCount++;
                }
            }
            return palindromsCount;
        }

        private static void InputData(out string aAndB, out string[] secondNumbers, out int persent)
        {
            aAndB = Console.ReadLine();

            secondNumbers = Console.ReadLine().
                Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

            persent = int.Parse(Console.ReadLine());
        }

        private static List<int> GetNums(string[] secondNumbers)
        {
            List<int> nums = new List<int>();
            foreach (var item in secondNumbers)
            {
                nums.Add(int.Parse(item));                
            }
            nums.Sort();
            return nums;
        }        

        private static bool IsLuckPalindrome(long num)
        {
            string numToString =num.ToString();
            int length = numToString.Length;
            for (int i = 0; i <=numToString.Length/2 ; i++)
            {
                if (!IsThreeOrFive(numToString[i]) || numToString[i]!=numToString[length-i -1])
                {
                    return false;
                }
            }

            return true;
        }
  
        private static bool IsThreeOrFive(char numToString)
        {
            return numToString == '5' || numToString == '3';
        }
    }
}
