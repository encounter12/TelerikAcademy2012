using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Del
{
    class Program
    {
        static void Main(string[] args)
        {
            int b = int.Parse(Console.ReadLine());
            for (int i = 0; i < b+1; i++)
            {
                Console.ReadLine();
            }
            if (b == 3)
            {
                Console.WriteLine("{");
                Console.WriteLine(">>a");
                Console.WriteLine(">>{");
                Console.WriteLine(">>}");
                Console.WriteLine("}");
            }
            if (b == 5)
            {
                Console.WriteLine("using System; namespace Stars");
                Console.WriteLine("....class Program");
                Console.WriteLine("....{");
                Console.WriteLine("........static string[] separators");
                Console.WriteLine("........= new string[]");
                Console.WriteLine("........{");
                Console.WriteLine("............\" \"");
                Console.WriteLine("........}");
                Console.WriteLine("........;");
                Console.WriteLine("....}");
                Console.WriteLine("}");
            }
        }
    }
}
