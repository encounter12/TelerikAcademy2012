using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

class Problem3
{
    static void Main()
    {
        string line = Console.ReadLine();
        string[] rawNumbers = line.Split(' ');
        int width = int.Parse(rawNumbers[0]);
        int height = int.Parse(rawNumbers[1]);
        int deepth = int.Parse(rawNumbers[2]);
        line = Console.ReadLine();
        rawNumbers = line.Split(' ');
        int startW = int.Parse(rawNumbers[0]);
        int startH = int.Parse(rawNumbers[1]);
        int startD = int.Parse(rawNumbers[2]);
        line = Console.ReadLine();
        rawNumbers = line.Split(' ');
        int dirW = int.Parse(rawNumbers[0]);
        int dirH = int.Parse(rawNumbers[1]);
        int dirD = int.Parse(rawNumbers[2]);
        int[, ,] cube = new int[width, height, deepth];
        BurnEdges(cube);
        int prevW=startW, prevH=startH, prevD=startD;
        int currW=startW, currH=startH, currD=startD;
        int nextW=startW+dirW, 
            nextH=startH+dirH, 
            nextD=startD+dirD;
        cube[currW, currH, currD] = 1;
        while (true)
        {
            currW = nextW;
            currH = nextH;
            currD = nextD;            
            if (currW==cube.GetLength(0)-1 && dirW==1)
            {
                if (dirH==0 && dirD==0)
                {
                    Console.WriteLine(currW + " " + currH + " " + currD);
                    return;
                }
                dirW = -1;               
            }
            if (currH==cube.GetLength(1)-1 && dirH==1)
            {
                if (dirW == 0 && dirD == 0)
                {
                    Console.WriteLine(prevW + " " + prevH + " " + prevD);
                    return;
                }
                dirH = -1;
            }
            if (currD==cube.GetLength(2)-1 && dirD==0)
            {
                if (dirW == 0 && dirH == 0)
                {
                    Console.WriteLine(prevW + " " + prevH + " " + prevD);
                    return;
                }
                dirD = -1;
            }
            if (currW == 0 && dirW!=0)
            {
                dirW = 1;              
            }
            if (currH == 0 && dirH!=0)
            {
                dirH = 1;                
            }
            if (currD == 0 && dirD!=0)
            {
                dirD = 1;               
            }
            if (cube[currW, currH, currD] == 1)
            {
                Console.WriteLine(currW + " " + currH + " " + currD);
                return;
            }      
            cube[currW, currH, currD] = 1;
            
            nextW +=dirW;
            nextH +=dirH; 
            nextD +=dirD;
            prevW = currW;
            prevH = currH;
            prevD = currD;
        }
    }
    static void BurnEdges(int[, ,] cube)
    {
        for (int w = 0; w < cube.GetLength(0); w++)
        {
            cube[w, 0, 0] = 1;
        }
        for (int w = 0; w < cube.GetLength(0); w++)
        {
            cube[w, 0, cube.GetLength(2) - 1] = 1;
        }
        for (int w = 0; w < cube.GetLength(0); w++)
        {
            cube[w, cube.GetLength(1) - 1, 0] = 1;
        }
        for (int w = 0; w < cube.GetLength(0); w++)
        {
            cube[w, cube.GetLength(1) - 1, cube.GetLength(2) - 1] = 1;
        }

        for (int h = 0; h < cube.GetLength(1); h++)
        {
            cube[0, h, 0] = 1;
        }
        for (int h = 0; h < cube.GetLength(1); h++)
        {
            cube[cube.GetLength(0) - 1, h, 0] = 1;
        }
        for (int h = 0; h < cube.GetLength(1); h++)
        {
            cube[0, h, cube.GetLength(2) - 1] = 1;
        }
        for (int h = 0; h < cube.GetLength(1); h++)
        {
            cube[cube.GetLength(0)-1, h, cube.GetLength(2) - 1] = 1;
        }

        for (int d = 0; d < cube.GetLength(2); d++)
        {
            cube[0, 0, d] = 1;
        }
        for (int d = 0; d < cube.GetLength(2); d++)
        {
            cube[cube.GetLength(0)-1, 0, d] = 1;
        }
        for (int d = 0; d < cube.GetLength(2); d++)
        {
            cube[0, cube.GetLength(1)-1, d] = 1;
        }
        for (int d = 0; d < cube.GetLength(2); d++)
        {
            cube[cube.GetLength(0)-1, cube.GetLength(1)-1, d] = 1;
        }
    }
}