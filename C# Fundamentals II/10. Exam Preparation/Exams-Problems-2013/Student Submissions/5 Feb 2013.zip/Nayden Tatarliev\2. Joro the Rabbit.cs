using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;


class Task2
{
    static void Main()
    {
        string input = Console.ReadLine();
        string[] splitStr = input.Split(',');
        string[] trimArray = new string[splitStr.Length];
        int[] array = new int[splitStr.Length];
        int count, rest, bestLength = int.MinValue;

        for (int i = 0; i < splitStr.Length; i++)
        {
            array[i] = int.Parse(splitStr[i].Trim());
        }

        for (int start = 0; start < array.Length; start++)
        {
            for (int step = array.Length - 1; step > 1; step--)
            {
                rest = array.Length - step;
                count = 1;
                for (int j = step; ; j = j - rest)
			    {
                   
                    if (array[start] < array[j])
                    {
                        count++;
                    }
                    else break;
	            }
                if (bestLength < count)
                {
                    bestLength = count;
                }
            }
        }
        Console.WriteLine(bestLength);
    }
}
