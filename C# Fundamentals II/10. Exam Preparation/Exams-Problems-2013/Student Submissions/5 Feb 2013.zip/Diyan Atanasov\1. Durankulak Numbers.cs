using System;
using System.Numerics;
using System.Text.RegularExpressions;

class DuNumbers
{

    static int ConvertToSingle(string num)
    {
        int number = 0;
        int meta = 0;
        if (num.Length == 1)
        {
            number = num[0] - 65;
        }
        else
        {
            meta = (1 + num[0]) - 97;
            number = ((num[1] - 65)) + (meta*25) + meta ;
        }

        return number;
    }

    static BigInteger PowerOf(int power)
    {
        BigInteger product = 1;
        for (int i = 0; i < power; i++)
        {
            product = product * 168;
        }
        return product;
    }


    static void Main()
    {

        string input = Console.ReadLine();
        int counter = 0;
        BigInteger total = 0;
        int meta = 0;
        Regex digitsPat = new Regex(@"[a-z]{0,1}[A-Z]{1}");

        var durDigits = digitsPat.Matches(input);

        for (int i = durDigits.Count - 1; i >= 0; i-- )
        {
            meta = ConvertToSingle(durDigits[i].ToString());
            total += meta * PowerOf(counter);
            counter++;

        }

        Console.WriteLine(total);

    }
}
