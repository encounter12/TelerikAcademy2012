using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.Jumps
{
    class Program
    {
        static void Main()
        {
            string[] input = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            int[] array = new int[input.Length];
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = int.Parse(input[i]);
            }
            int maxLen = int.MinValue;

            for (int i = 0; i < array.Length; i++)
            {               
                for (int step = 1; step < array.Length; step++)
                {
                    bool[] visited = new bool[array.Length];
                    visited[i] = true;
                    int len = 1;
                    int curStep = i + step;
                    if (curStep >= array.Length)
                    {
                        curStep = Math.Abs(array.Length - curStep);
                    }

                    int current = array[i];
                    while (true)
                    {
                        if (current < array[curStep] && !visited[curStep])
                        {
                            current = array[curStep];
                            visited[curStep] = true;
                        }
                        else
                        {
                            break;
                        }
                        len++;
                        if (curStep + step >= array.Length)
                        {
                            curStep = Math.Abs(array.Length - (curStep + step));
                        }
                        else
                        {
                            curStep += step;
                        }
                    }

                    if (len > maxLen)
                    {
                        maxLen = len;
                    }
                }
            }

            Console.WriteLine(maxLen);
        }
    }
}
