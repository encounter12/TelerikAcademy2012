using System;

    class Program
    {
        static void Main()
        {
            string numbers = Console.ReadLine();
            string replaced = numbers.Replace(", ", ",");
            string[] nums = replaced.Split(',');
            int[] cells = new int[nums.Length];
            int len = cells.Length;
            for (int i = 0; i < len; i++)
            {
                cells[i] = int.Parse(nums[i]);
                
            }
            int counter = 1;
            int maxCounter=1;
            for (int step = 1; step < len; step++)
            {
                for (int v = 0; v < len - step; v++)
                {
                    for (int i = v; i < len - step; i = i + step)
                    {
                        if (cells[i] < cells[i + step])
                        {
                            counter++;
                            if (maxCounter < counter)
                            {
                                maxCounter = counter;
                                
                            }
                        }
                        if (i + step > len)
                        {
                            i = i - len;
                        }

                    }
                    counter = 0;
                }
            }
            Console.WriteLine(maxCounter+1);
            


        }
    }
