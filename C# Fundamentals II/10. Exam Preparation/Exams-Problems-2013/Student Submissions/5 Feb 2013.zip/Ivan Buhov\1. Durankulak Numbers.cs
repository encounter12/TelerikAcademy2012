using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class DurankulakNumbers
{
    static void Main()
    {
        Console.WriteLine(ToDec(Console.ReadLine()));
    }
    static private long ToDec(string number)
    {
        List<string> digits = new List<string>();

        for (int i = 0; i < number.Length; i++)
        {
            if (Char.IsLower(number[i]))
            {
                digits.Add(number[i].ToString() + number[i + 1].ToString());
                i++;
            }
            else
            {
                digits.Add(number[i].ToString());
            }
        }

        long result = 0;
        long mult = 1;
        for (int i = digits.Count - 1; i >= 0; i--)
        {
            int value = 0;
            if (digits[i].Length == 1)
            {
                value = digits[i][0] - 'A';
            }
            else
            {
                value = (digits[i][0] - 'a' + 1) * 26 + digits[i][1] - 'A';
            }

            result += value * mult;
            mult *= 168;
        }

        return result;
    }
}
