using System;
using System.Collections.Generic;

    class TwoBetter
    {
        static void Main()
        {
            string twoNumbers = Console.ReadLine();
            string[] arr = twoNumbers.Split(' ');
            ulong first = ulong.Parse(arr[0]);
            ulong second = ulong.Parse(arr[1]);
            
            string list = Console.ReadLine();
            float percent = int.Parse(Console.ReadLine())/100f;
            string[] parsedList = list.Split(',');
            //int[] numbers = new int[parsedList.Length];
            //for (int i = 0; i < numbers.Length; i++)
            //{
            // numbers[i] = int.Parse(parsedList[i]);
            //}
            List<int> listInt = new List<int>();
            int k = 0;
            foreach (var item in parsedList)
	            {
		                listInt.Add(int.Parse(parsedList[k]));
                k++;
	            }
            int[] numbers = listInt.ToArray();
            int numberOfEls = (int)(parsedList.Length * percent);

            bool isLucky = true;
            int counter = 0;
            for (ulong i = first; i <= second; i++)
            {
               ulong holder = i;
              
                while(holder > 0)
                {
                    if ((holder/10 == 3 || holder/10 == 5) && holder > 9)
                    {                      
                        holder /= 10;
                    }
                    else if (holder < 9 && (holder == 3 || holder == 5))
                    {
                        isLucky = true;
                        holder /= 10;
                    }
                    else
                    {
                        isLucky = false;
                        break;
                    }
                }               
                
                if (isLucky)
                {
                    counter++;
                }
                else
                {
                    isLucky = true;
                }
            }

            Console.WriteLine(counter);

            int min = int.MaxValue;
            int secondCounter = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                for (int j = 0; j < numbers.Length; j++)
                {
                    if (j == i)
                    {
                        continue;
                    }
                    else
                    {
                        if (numbers[i] > numbers[j])
                        {
                            secondCounter++;
                        }
                    }
                }
                if (secondCounter == numberOfEls && i < min)
                {
                    min = i;
                }
                secondCounter = 0;
            }
            Console.WriteLine(numbers[min]);

        }
       
     
     
    }
