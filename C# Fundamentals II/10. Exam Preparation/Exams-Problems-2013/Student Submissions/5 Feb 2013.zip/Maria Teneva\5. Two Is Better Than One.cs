using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace zad5
{
    class Program
    {
        static void Main(string[] args)
        {
            
            
            //Input
            string inputAB = Console.ReadLine();
            string[] inputABarr = inputAB.Split(' ');          

            int A = int.Parse(inputABarr[0]);
            int B = int.Parse(inputABarr[1]);


            string listNum = Console.ReadLine();
            string[] listNumarr = listNum.Split(',');
            int[] listNumarrN = new int[listNumarr.Length];

            for (int i = 0; i < listNumarr.Length; i++)
            {
                listNumarrN[i] = int.Parse(listNumarr[i]);
            }

            int P = int.Parse(Console.ReadLine());
             

            //Output
            int count = 0;
            List<string> numbersABasStr= new List<string>{};
            for (int i = A; i <= B; i++)
            {
                numbersABasStr.Add((i).ToString());
            }

            char keyWord = '3';

            for (int i = 0; i < numbersABasStr.Count; i++)
            {
                for (int j = 0, s=(numbersABasStr[i].Length-1); j < numbersABasStr[i].Length/2; j++, s--)
                {
                    if (numbersABasStr[i].IndexOf(keyWord, j) == numbersABasStr[i].IndexOf(keyWord, s))
                    {
                        count++;
                    }
                    if (numbersABasStr[i].IndexOf('5', j) == numbersABasStr[i].IndexOf('5', s))
                    {
                        count++;
                    }
                }
            
            }
            Console.WriteLine(count);
            
        }
    }
}
