using System;
using System.IO;
using System.Text;

namespace taks4_FormatCode
{
    class Program
    {
        static void Main(string[] args)
        {
#if DEBUG
            Console.SetIn(new StreamReader(@"../../test.txt"));
#endif   
            int n = int.Parse(Console.ReadLine());
            string formatingString = Console.ReadLine();
            StringBuilder format = new StringBuilder();
            StringBuilder newLine = new StringBuilder();
            StringBuilder finalOutput = new StringBuilder();
            bool begOfNewLine = false;

            //bool part
            for (int i = 0; i < n; i++)
            {
                string line = Console.ReadLine().Trim();
                for (int j = 0; j < line.Length; j++)
                {
                    char c = line[j];

                    if (c == ' ')
                    {
                        if (ValidIndex(j + 1, line) && line[j + 1] == ' ')
                        {
                            continue;
                        }
                        else
                        {
                            if (begOfNewLine)
                            {
                                continue;
                            }
                        }
    
                       
                    }
                    if (j == line.Length - 1)
                    {
                        if (NotBracket(c))
                        {
                            finalOutput.Append(c);
                            finalOutput.Append("\n");
                            begOfNewLine = true;
                            continue;
                        }
                    }
                    else
                    {
                        if (begOfNewLine)
                        {
                            if (NotBracket(c))
                            {
                                begOfNewLine = false;
                                finalOutput.Append(format+c.ToString());
                                continue;
                            }
                        }
                        else
                        {
                            if (NotBracket(c))
                            {
                                finalOutput.Append(c);
                                continue;
                            }
                        }
                        
                    }
                   
                    if(c == '{') 
                    {
                        if (ValidIndex(j - 1,line))
                        {
                            finalOutput.Append("\n");
                            finalOutput.Append(format + "{");
                            finalOutput.Append("\n");
                            format.Append(formatingString);
                            begOfNewLine = true;
                            continue;
                        }
                        else
                        {
                            finalOutput.Append(format+"{");
                            finalOutput.Append('\n');
                            format.Append(formatingString);
                            begOfNewLine = true;
                            continue;
                        }
                    }
                   
                    if (c == '}')
                    {

                        if (ValidIndex(j - 1,line))
                        {
                            if (format.Length - formatingString.Length == 0)
                            {
                                format.Clear();
                            }
                            else
                            {
                                format =format.Remove(format.Length - formatingString.Length, formatingString.Length);
                            }
                            finalOutput.Append("\n");
                            finalOutput.Append(format + "}");
                            finalOutput.Append("\n");
                            begOfNewLine = true;
                            continue;
                        }
                        else
                        {
                            if (format.Length - formatingString.Length == 0)
                            {
                                format.Clear();
                            }
                            else
                            {
                                format = format.Remove(format.Length - formatingString.Length, formatingString.Length);
                            }
                            finalOutput.Append(format + "}");
                            finalOutput.Append('\n');
                            begOfNewLine = true;
                            continue;
                        }
                    }
                }
            }
            finalOutput.Remove(finalOutput.Length - 1, 1);
            //StreamWriter writer = new StreamWriter(@"../../out.txt");
            //writer.WriteLine(finalOutput);
            
            Console.WriteLine(finalOutput);
        }

        static bool ValidIndex(int p,string line)
        {
            if (p < 0 || p >= line.Length )
            {
                return false;
            }
            return true;
        }

        static bool NotBracket(char c)
        {
            if (c != '{' && c != '}')
            {
                return true;
            }
            return false;
        }
    }
}
