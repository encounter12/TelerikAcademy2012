using System;
using System.Text;

class Brackets
{
    static void Main()
    {
        int numLinesN = int.Parse(Console.ReadLine());
        string indentionStr = Console.ReadLine();
        StringBuilder codeFormat = new StringBuilder();
        int openBracketCount = 0;
        int whiteSpaceCount = 0;
        bool inQuotes = false;

        for (int i = 0; i < numLinesN; i++)
        {
           string input =   Console.ReadLine();
           input = input.Trim();

           if (i != 0)
           {
               codeFormat.AppendLine();
           }
           


           for (int token = 0; token < input.Length; token++)
           {
               if (input[token] == '{')
               {
                   if (openBracketCount > 0)
                   {
                       codeFormat.AppendLine(); //new row
                       for (int br = 0; br < openBracketCount; br++)
                       {
                           codeFormat.Append(indentionStr);
                       }
                       

                       if (token != input.Length-1)
                       {
                           codeFormat.AppendLine(input[token].ToString());
                           for (int k = 0; k <= openBracketCount; k++)
                           {
                               codeFormat.Append(indentionStr);
                           }  
                       }
                       else
                       {
                           codeFormat.Append(input[token].ToString());
                       }
                       
                   }
                   else
                   {
                       codeFormat.AppendLine(input[token].ToString());
                       codeFormat.Append(indentionStr);
                   }

                   whiteSpaceCount = 0;
                   openBracketCount++;
               }
               else if (input[token] == '}')
               {
                   if (input.Length > 1 && i!=numLinesN-1 && token != numLinesN-1)
                   {
                       codeFormat.AppendLine(); //new row
                   }

                   openBracketCount--;

                   for (int j = 0; j < openBracketCount; j++)
                   {
                       codeFormat.Append(indentionStr);
                   }
                   codeFormat.AppendLine(input[token].ToString());
                   for (int k = 0; k < openBracketCount; k++)
                   {
                       codeFormat.Append(indentionStr);
                   }

                   whiteSpaceCount = 0;

               }
               else if (char.IsWhiteSpace(input[token]) || input[token] == ' ')
               {
                   if (whiteSpaceCount == 0 || inQuotes == true)
                   {
                       codeFormat.Append(input[token].ToString());
                       whiteSpaceCount++;
                   }
                   else
                   {
                       whiteSpaceCount++;
                   }
               }
               else if (input[token] == '"')
               {
                   if (inQuotes == true)
                   {
                       inQuotes = false;
                   }
                   else
                   {
                       inQuotes = true;
                   }
                  
                  codeFormat.Append(input[token].ToString());
               }
               else //code strings
               {
                   if (token == 0)
                   {
                       for (int br = 0; br < openBracketCount; br++)
                       {
                           codeFormat.Append(indentionStr);
                       }
                       codeFormat.Append(input[token].ToString());
                   }
                   else
                   {
                       codeFormat.Append(input[token].ToString());
                       whiteSpaceCount = 0;
                   }
               }

           }
        }

        string replaceExpr = indentionStr + Environment.NewLine;
        codeFormat.Replace(replaceExpr, "");
        codeFormat.Replace((indentionStr + " "), indentionStr);
        codeFormat.Replace(("}" + Environment.NewLine), "}");
       
        Console.WriteLine(codeFormat.ToString()); 
    }
}
 