using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main()
    {
        int N = int.Parse(Console.ReadLine());
        string S = Console.ReadLine();
        StringBuilder elements = new StringBuilder();
        List<string> listElements = new List<string>();
        int bracketCounter = 0;
        bool addSymbol = true;
        for (int i = 0; i < N; i++)
        {
            string line = Console.ReadLine();
            for (int j = 0; j < line.Length; j++)
            {
                if (line[j] != '{' && line[j] != '}')
                {
                        if (addSymbol)
                        {
                            for (int s = 0; s < bracketCounter; s++)
                            {
                                elements.Append(S);
                            }
                            addSymbol = false;
                        }
                        elements.Append(line[j]);
                    
                }
                else if (line[j] == '{')
                {
                    if (elements.Length > 0)
                    {
                        listElements.Add(elements.ToString());
                        elements.Clear();
                    }
                    for (int s = 0; s < bracketCounter; s++)
                    {
                        elements.Append(S);
                    }
                    elements.Append('{');
                    listElements.Add(elements.ToString());
                    elements.Clear();
                    bracketCounter++;
                    addSymbol = true;
                        
                    
                }
                else if (line[j] == '}')
                {
                    if (elements.Length > 0)
                    {
                        listElements.Add(elements.ToString());
                        elements.Clear();
                    }
                    bracketCounter--;
                    for (int s = 0; s < bracketCounter; s++)
                    {
                        elements.Append(S);
                    }
                    elements.Append('}');
                    listElements.Add(elements.ToString());
                    elements.Clear();
                    addSymbol = true;
                }

            }
            if (elements.Length > 0)
            {
                string el = (elements.ToString()).Trim();
                listElements.Add(el);
                elements.Clear();
                addSymbol = true;
            }
        }
        for (int i = 0; i < listElements.Count; i++)
        {
            if((listElements[i].ToString()).Contains('{'))
            {
                Console.WriteLine(listElements[i]);
                continue;
            }
            else if ((listElements[i].ToString()).Contains('}'))
            {
                Console.WriteLine(listElements[i]);
                continue;
            }
            else
            {
                string[] words = listElements[i].Split (new char[' '], StringSplitOptions.RemoveEmptyEntries);
                for (int j = 0; j < words.Length; j++)
                {
                    
                    if (words[j] != " " && j != words.Length - 1)
                    {
                        Console.Write("{0} ", words[j]);
                    }
                    else if (j == words.Length - 1 && words[j] != " ")
                    {
                        Console.Write("{0}", words[j]);
                    }
                }
                Console.WriteLine();
            }
            
        }

    }
}
