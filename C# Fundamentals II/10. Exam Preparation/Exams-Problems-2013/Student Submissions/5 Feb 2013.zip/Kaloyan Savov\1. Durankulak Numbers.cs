using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
  
class DurankulakNumbers
{
    static void Main()
    {
        string number = Console.ReadLine();
        //char[] array = number.ToCharArray();
        char[] array = new char[number.Length + 1];
        for (int i = 0; i < number.Length; i++)
        {
            array[i + 1] = number[i];
        }
        List<string> digits = new List<string>();
        //string[] digits = new string[number.Length];
        double result = 0;
        double currentNumber = 0;
for (int i = array.Length - 1; i > 0; i--)
                {
                    if (char.IsUpper(array[i]))
                    {
                        if (char.IsLower(array[i - 1]))
                        {
                            digits.Add(Convert.ToString(array[i - 1]) + Convert.ToString(array[i]));
                        }
                        else
                        {
                            digits.Add(Convert.ToString(array[i]));
                        }
                    }
                }
                for (int i = 0; i < digits.Count; i++)
                {
                    switch (digits[i])
                    {
                        case "A": currentNumber = 0; break;
                        case "B": currentNumber = 1; break;
                        case "C": currentNumber = 2; break;
                        case "D": currentNumber = 3; break;
                        case "E": currentNumber = 4; break;
                        case "F": currentNumber = 5; break;
                        case "G": currentNumber = 6; break;
                        case "H": currentNumber = 7; break;
                        case "I": currentNumber = 8; break;
                        case "J": currentNumber = 9; break;
                        case "K": currentNumber = 10; break;
                        case "L": currentNumber = 11; break;
                        case "M": currentNumber = 12; break;
                        case "N": currentNumber = 13; break;
                        case "O": currentNumber = 14; break;
                        case "P": currentNumber = 15; break;
                        case "Q": currentNumber = 16; break;
                        case "R": currentNumber = 17; break;
                        case "S": currentNumber = 18; break;
                        case "T": currentNumber = 19; break;
                        case "U": currentNumber = 20; break;
                        case "V": currentNumber = 21; break;
                        case "W": currentNumber = 22; break;
                        case "X": currentNumber = 23; break;
                        case "Y": currentNumber = 24; break;
                        case "Z": currentNumber = 25; break;
                        case "aA": currentNumber = 26; break;
                        case "aB": currentNumber = 27; break;
                        case "aC": currentNumber = 28; break;
                        case "aD": currentNumber = 29; break;
                        case "aE": currentNumber = 30; break;
                        case "aF": currentNumber = 31; break;
                        case "aG": currentNumber = 32; break;
                        case "aH": currentNumber = 33; break;
                        case "aI": currentNumber = 34; break;
                        case "aJ": currentNumber = 35; break;
                        case "aK": currentNumber = 36; break;
                        case "aL": currentNumber = 37; break;
                        case "aM": currentNumber = 38; break;
                        case "aN": currentNumber = 39; break;
                        case "aO": currentNumber = 40; break;
                        case "aP": currentNumber = 41; break;
                        case "aQ": currentNumber = 42; break;
                        case "aR": currentNumber = 43; break;
                        case "aS": currentNumber = 44; break;
                        case "aT": currentNumber = 45; break;
                        case "aU": currentNumber = 46; break;
                        case "aV": currentNumber = 47; break;
                        case "aW": currentNumber = 48; break;
                        case "aX": currentNumber = 49; break;
                        case "aY": currentNumber = 50; break;
                        case "aZ": currentNumber = 51; break;
                        case "bA": currentNumber = 52; break;
                        case "bB": currentNumber = 53; break;
                        case "bC": currentNumber = 54; break;
                        case "bD": currentNumber = 55; break;
                        case "bE": currentNumber = 56; break;
                        case "bF": currentNumber = 57; break;
                        case "bG": currentNumber = 58; break;
                        case "bH": currentNumber = 59; break;
                        case "bI": currentNumber = 60; break;
                        case "bJ": currentNumber = 61; break;
                        case "bK": currentNumber = 62; break;
                        case "bL": currentNumber = 63; break;
                        case "bM": currentNumber = 64; break;
                        case "bN": currentNumber = 65; break;
                        case "bO": currentNumber = 66; break;
                        case "bP": currentNumber = 67; break;
                        case "bQ": currentNumber = 68; break;
                        case "bR": currentNumber = 69; break;
                        case "bS": currentNumber = 70; break;
                        case "bT": currentNumber = 71; break;
                        case "bU": currentNumber = 72; break;
                        case "bV": currentNumber = 73; break;
                        case "bW": currentNumber = 74; break;
                        case "bX": currentNumber = 75; break;
                        case "bY": currentNumber = 76; break;
                        case "bZ": currentNumber = 77; break;
                        case "cA": currentNumber = 78; break;
                        case "cB": currentNumber = 79; break;
                        case "cC": currentNumber = 80; break;
                        case "cD": currentNumber = 81; break;
                        case "cE": currentNumber = 82; break;
                        case "cF": currentNumber = 83; break;
                        case "cG": currentNumber = 84; break;
                        case "cH": currentNumber = 85; break;
                        case "cI": currentNumber = 86; break;
                        case "cJ": currentNumber = 87; break;
                        case "cK": currentNumber = 88; break;
                        case "cL": currentNumber = 89; break;
                        case "cM": currentNumber = 90; break;
                        case "cN": currentNumber = 91; break;
                        case "cO": currentNumber = 92; break;
                        case "cP": currentNumber = 93; break;
                        case "cQ": currentNumber = 94; break;
                        case "cR": currentNumber = 95; break;
                        case "cS": currentNumber = 96; break;
                        case "cT": currentNumber = 97; break;
                        case "cU": currentNumber = 98; break;
                        case "cV": currentNumber = 99; break;
                        case "cW": currentNumber = 100; break;
                        case "cX": currentNumber = 101; break;
                        case "cY": currentNumber = 102; break;
                        case "cZ": currentNumber = 103; break;
                        case "dA": currentNumber = 104; break;
                        case "dB": currentNumber = 105; break;
                        case "dC": currentNumber = 106; break;
                        case "dD": currentNumber = 107; break;
                        case "dE": currentNumber = 108; break;
                        case "dF": currentNumber = 109; break;
                        case "dG": currentNumber = 110; break;
                        case "dH": currentNumber = 111; break;
                        case "dI": currentNumber = 112; break;
                        case "dJ": currentNumber = 113; break;
                        case "dK": currentNumber = 114; break;
                        case "dL": currentNumber = 115; break;
                        case "dM": currentNumber = 116; break;
                        case "dN": currentNumber = 117; break;
                        case "dO": currentNumber = 118; break;
                        case "dP": currentNumber = 119; break;
                        case "dQ": currentNumber = 120; break;
                        case "dR": currentNumber = 121; break;
                        case "dS": currentNumber = 122; break;
                        case "dT": currentNumber = 123; break;
                        case "dU": currentNumber = 124; break;
                        case "dV": currentNumber = 125; break;
                        case "dW": currentNumber = 126; break;
                        case "dX": currentNumber = 127; break;
                        case "dY": currentNumber = 128; break;
                        case "dZ": currentNumber = 129; break;
                        case "eA": currentNumber = 130; break;
                        case "eB": currentNumber = 131; break;
                        case "eC": currentNumber = 132; break;
                        case "eD": currentNumber = 133; break;
                        case "eE": currentNumber = 134; break;
                        case "eF": currentNumber = 135; break;
                        case "eG": currentNumber = 136; break;
                        case "eH": currentNumber = 137; break;
                        case "eI": currentNumber = 138; break;
                        case "eJ": currentNumber = 139; break;
                        case "eK": currentNumber = 140; break;
                        case "eL": currentNumber = 141; break;
                        case "eM": currentNumber = 142; break;
                        case "eN": currentNumber = 143; break;
                        case "eO": currentNumber = 144; break;
                        case "eP": currentNumber = 145; break;
                        case "eQ": currentNumber = 146; break;
                        case "eR": currentNumber = 147; break;
                        case "eS": currentNumber = 148; break;
                        case "eT": currentNumber = 149; break;
                        case "eU": currentNumber = 150; break;
                        case "eV": currentNumber = 151; break;
                        case "eW": currentNumber = 152; break;
                        case "eX": currentNumber = 153; break;
                        case "eY": currentNumber = 154; break;
                        case "eZ": currentNumber = 155; break;
                        case "fA": currentNumber = 156; break;
                        case "fB": currentNumber = 157; break;
                        case "fC": currentNumber = 158; break;
                        case "fD": currentNumber = 159; break;
                        case "fE": currentNumber = 160; break;
                        case "fF": currentNumber = 161; break;
                        case "fG": currentNumber = 162; break;
                        case "fH": currentNumber = 163; break;
                        case "fI": currentNumber = 164; break;
                        case "fJ": currentNumber = 165; break;
                        case "fK": currentNumber = 166; break;
                        case "fL": currentNumber = 167; break;
                        default:
                            break;
                    }
                    result = result + currentNumber * (Math.Pow(168, i));
                }
                Console.WriteLine(result);
            }
        }