using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DurnakulakNb
{
    class DurankulakNb
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();//"CfI";

            //int[] nbCode=new int[16];
            List<int> nbCode = new List<int>();

            StringBuilder sb = new StringBuilder(9);
            for (char i = 'A'; i <= 'Z'; i++)
            {
                sb.Append(i);
                sb.Append(",");
            }
            string check = sb.ToString();
            //for (int i = 0; i < check.Length; i++)
            //{
            //    Console.Write(check[i]);
            //}
            char[] separator = new char[] { ',' };
            string[] duranOneDigit = check.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            //for (int i = 0; i < duranOneDigit.Length; i++) //OK
            //{
            //    Console.WriteLine(duranOneDigit[i]);
            //}
            //Console.WriteLine(duranOneDigit.Length);
            StringBuilder sb1 = new StringBuilder();

            for (char i = 'a'; i <= 'f'; i++)
            {
                for (int j = 0; j < duranOneDigit.Length; j++)
                {
                    string temp = i.ToString() + duranOneDigit[j];
                    sb1.Append(temp);
                    sb1.Append(',');
                }
            }
            string durankulakCodes = sb1.ToString();
            //for (int i = 0; i < durankulakCodes.Length; i++)
            //{
            //    Console.Write(durankulakCodes[i] + " ");
            //}
            // Console.WriteLine(durankulakCodes.Length);
            
            string[] duranTwoDigits = durankulakCodes.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            
            //for (int i = 0; i < duranTwoDigits.Length; i++)//OK
            //{
            //    Console.Write(duranTwoDigits[i] + " ");
                
            //}
            //Console.WriteLine(duranTwoDigits.Length);

            if (input.Length == 1)
            {
                for (int i = 0; i < duranOneDigit.Length; i++)
                {
                    if (input == duranOneDigit[i])
                    {
                        Console.WriteLine(i);
                    }
                }
            }
            else if (input.Length == 2)
            {
                for (int i = 0; i < duranTwoDigits.Length; i++)
                {
                    if (input == duranTwoDigits[i])
                    {
                        Console.WriteLine(i+26);
                    }
                }
            }
            
            else //if (more than 3  char)
            {
                 for (int i = 0; i < input.Length; i++)
			     {
                     if (((input[i]) >= 'a')&&(input[i] <= 'f')) //2 letters
                     {
                         string temp = input.Substring(i, 2); //Console.WriteLine("temp"+temp);
                         i++;
                         for (int j = 0; j < duranTwoDigits.Length; j++)
                         {
                             if (temp == duranTwoDigits[j])
                             {
                                 //remember j+26
                                 nbCode.Add(j + 26);
                             }
                             
                         } 
                         
                     }
                     else if ((input[i] >= 'A') ||(input[i] <= 'Z')) //upper letter substitute from 
                     {
                         for (int k = 0; k < duranOneDigit.Length; k++)
                         {
                            if (input[i].ToString() == duranOneDigit[k])
                            {
                                //remembre k
                                nbCode.Add(k);
                            }
                        }
                     }
                                    
			     }
                 long nb = 0;
                 for (int i = 0; i < nbCode.Count; i++)
                 {
                     nb += nbCode[nbCode.Count - i - 1] * (long)Math.Pow(168, i);
                 }
                 Console.WriteLine(nb);
                 //foreach (var item in nbCode)
                 //{
                 //    Console.WriteLine(item + " ");
                 //}
            }
        }
    }
}
