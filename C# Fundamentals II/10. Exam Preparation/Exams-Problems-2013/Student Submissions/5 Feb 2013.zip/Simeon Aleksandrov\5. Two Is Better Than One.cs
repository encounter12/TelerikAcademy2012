using System;
using System.Numerics;

class Program
{
    static void Main(string[] args)
    {
        string line = Console.ReadLine();
        string[] splitLine = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        BigInteger min = BigInteger.Parse(splitLine[0]);
        BigInteger max = BigInteger.Parse(splitLine[1]);

        string line2 = Console.ReadLine();
        string[] splitline2 = line2.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        int[] numbers = new int[splitline2.Length];
        for (int i = 0; i < numbers.Length; i++)
        {
            numbers[i] = int.Parse(splitline2[i]);
        }

        string line3 = Console.ReadLine();
        int percentile = int.Parse(line3);

        int countLucky = 0;
        for (BigInteger i = min; i <= max; i++)
        {
            if (IsLuckyalindrom(i))
            {
                countLucky++;
            }
        }
        Console.WriteLine(countLucky);

        FindElement(numbers, percentile);


    }

    private static void FindElement(int[] numbers, int percentile)
    {
        int postition = (int)Math.Round((double)numbers.Length * percentile / 100);
        Array.Sort(numbers);
        if (postition > 0)
            Console.WriteLine(numbers[postition-1]);
        else
            Console.WriteLine(numbers[postition]);
    }

    private static bool IsLuckyalindrom(BigInteger i)
    {
        BigInteger reversed = 0;
        BigInteger n = i;

        while (n > 0)
        {
            if (n % 10 == 5 || n % 10 == 3)
            {
                reversed = reversed * 10 + n % 10;
                n /= 10;
            }
            else
                return false;
        }
        return (i == reversed);
    }
}
