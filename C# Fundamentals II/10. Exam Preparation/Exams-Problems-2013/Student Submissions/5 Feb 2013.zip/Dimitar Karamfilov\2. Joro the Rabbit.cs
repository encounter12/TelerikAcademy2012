using System;

class Program
{
    static void Main()
    {
        string[] str = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
        int[] array = new int[str.Length];

        for (int i = 0; i < array.Length; i++)
        {
            array[i] = int.Parse(str[i]);
        }
        int count =0;
        int max =0;
        for (int step = 1; step <array.Length-1; step++)
        {
            for (int i = 0; i < array.Length; i++)
            {
                
                
                count = calc(array, i, step);
                
                if (max < count) max = count;
            }
        }
        
        Console.WriteLine(max);
    }
    static int calc(int[] array, int i,int step)
    {
        int[] visted = new int[array.Length]; 
         int count = 0;
        int next = i + step;
        if (next > array.Length - 1)
        {
            next = next - array.Length;
        }
        while ((array[i] < array[next]) && (visted[next] != int.MinValue))
        {
            count++;
            visted[i] = int.MaxValue;
            i = next;
            next = i + step;
            
            if (next > array.Length-1)
            {
                next = next - array.Length;
            }
        }

        return ++count;
    }
}
