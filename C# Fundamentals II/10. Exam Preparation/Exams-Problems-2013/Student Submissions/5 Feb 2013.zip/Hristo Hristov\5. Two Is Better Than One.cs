using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoIsBetterThanOne
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] firstTask = Console.ReadLine().Split(' ');
            string[] secondTask = Console.ReadLine().Split(',');
            double procent = Convert.ToDouble(Console.ReadLine());
            long[] arr = new long[secondTask.Length];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = Convert.ToInt64(secondTask[i]);
            }
            
            Array.Sort(arr);
            ulong start = Convert.ToUInt64(firstTask[0]);
            ulong end = Convert.ToUInt64(firstTask[1]);
            List<string> lucky = new List<string>();
            for (int i = 1; i <= 19; i++)
            {
                if (i == 1)
                {
                    lucky.Add("3");
                    lucky.Add("5");
                }
                else if (i == 2)
                {
                    lucky.Add("33");
                    lucky.Add("55");
                }
                else
                {
                    int str = 1;
                    int middle = i - str * 2;

                    while (middle > 0)
                    {
                        lucky.Add(new String('3', str) + new String('5', middle) + new String('3', str));
                        lucky.Add(new String('5', str) + new String('3', middle) + new String('5', str));
                        str++;
                        middle = i - str * 2;
                    }
                }
            }
            int count = 0;
            foreach (var item in lucky)
            {
                if (Convert.ToUInt64(item) <= end && Convert.ToUInt64(item) >= start)
                {
                    count++;
                }
            }
            Console.WriteLine(count);
            int test = (int)((arr.Length - 1) * (procent / 100));
            Console.WriteLine(arr[test]);
        }
    }
}
