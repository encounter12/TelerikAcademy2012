using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class JoroTheRabbit
{
    static void Main()
    {

        string input = Console.ReadLine();
        string[] numbers = input.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        int length = numbers.Length;
        short[] values = new short[length];
        short[] sortedValues = new short[length];
        short[] tempArr =new short[length];
      

        for (int i = 0; i < numbers.Length; i++)
        {
            values[i]=short.Parse(numbers[i]);
        }
            
        //for (int i = 0; i < length; i++)
        //{
                
        //    sortedValues[i] = values[i];
                
        //}
        //Array.Sort(sortedValues);
        int sum=1;
        int bestSum = 1;
        int startIndex=0;
        int start = 0;
        int findBest = 0;
        int theIndex = 0;
        for (int i = 0; i < values.Length; i++)
        {
            start = values[i];
            for (int index = 0; index < length; index++)
            {
                if (values[index] == start)
                {
                    theIndex = index;
                }
            }
            startIndex = theIndex;
                for (int jump = 0; jump < length - startIndex-1; jump++)
                {
                    tempArr[jump] = values[startIndex + jump];
                    if (tempArr[jump] == values[length - 1])
                    {
                        for (int jumpToEnd = 1; jumpToEnd < length; jumpToEnd++)
                        {
                            tempArr[jumpToEnd + jump] = values[jumpToEnd - 1];
                        }
                    }
                }
                for (int indexSum = 1; indexSum < (length - 1)/2; indexSum++)
                {
                    for (int indexSearch = 0; indexSearch < length; indexSearch++)
                    {
                        if (indexSearch + indexSum >= length)
                        {
                            break;
                        }

                        else if (tempArr[indexSearch] < tempArr[indexSearch + indexSum])
                        {
                            sum++;
                        }
                        if (sum > bestSum)
                        {
                            bestSum = sum;
                        }

                    }
                    if (findBest < bestSum)
                    {
                        findBest = bestSum;
                    }
                    sum = 0;
                    bestSum = 0;
                }
                
            }

        Console.WriteLine(findBest);
        
    }
}
