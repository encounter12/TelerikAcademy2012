using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Text;
using System.Threading.Tasks;

namespace TwoIsBetterThanOne
{
    class TwoIsBetterThanOne
    {



        static void Main()
        {
            string[] startEnd = Console.ReadLine().Split(' ');
            long start = long.Parse(startEnd[0]);
            long end = long.Parse(startEnd[1]);
            StringBuilder num = new StringBuilder();
            bool isPalindrom = false;
            long countPalindroms = 0;

            for (long i = start; i < end; i++)
			{
			    num.Append(i);
                num.Append(" ");
			}





            for (long i = start; i <= end; i++)
            {
                num.Clear();
                num.Append(i);
                string number = Convert.ToString(num);
                //Console.WriteLine(number);
                if (number[0] == '3' || number[0] == '5')
                {

                    for (int k = 0; k < number.Length / 2; k++)
                    {
                        if (number[k] == number[number.Length - k - 1] && (number[k] == '3' || number[k] == '5'))
                        {
                            isPalindrom = true;
                            //Console.WriteLine(number[k]);
                        }
                        else
                        {
                            isPalindrom = false;
                            break;
                        }
                    }
                    if (number.Length == 1)
                    {
                        if (number == "3" || number == "5")
                        {
                            countPalindroms++;
                        }
                    }

                    if (isPalindrom)
                    {
                        countPalindroms++;
                    }
                }
            }

//---------------------------------------------------------------------------------------------second part

            //string[] arrayStr = Console.ReadLine().Split(new char[] {' ', ','},StringSplitOptions.RemoveEmptyEntries);
            //int[] array = new int[arrayStr.Length];

            //int percent = int.Parse(Console.ReadLine());

            //for (int i = 0; i < arrayStr.Length; i++)
            //{
            //    array[i] = int.Parse(arrayStr[i]);
            //}

            //Array.Sort(array);

            //double decSum = 100d / percent;
            //int index = 100 / percent;
            //if (decSum > index)
            //{
            //    index++;
            //}
            //if (decSum == index)
            //{
            //    index--;
            //}

            Console.WriteLine(countPalindroms);
            //Console.WriteLine(array[index]);
        }
    }
}
