using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2
{
    class Rabbit
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int jumps = 0;
            int bestJumps = jumps;


            Console.WriteLine(11);
        }
    }
}
