using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class CSarpBrackets
{
    public static StringBuilder oneLine = new StringBuilder();

    static void Main()
    {
        int n = 0;
        int indent = 0;
        bool isNotBracket = false;
        bool isFirstCharacter = true;
        string s = string.Empty;
        string[] lines;
        string pattern = @"\s+";
        Regex regx = new Regex(pattern);
        StringBuilder oneLine = new StringBuilder();

        n = Int32.Parse(Console.ReadLine());
        s = Console.ReadLine();

        lines = new string[n];
        for (int i = 0; i < n; i++)
        {
            lines[i] = Console.ReadLine();
            lines[i] = lines[i].Trim();
            lines[i] = regx.Replace(lines[i], " ");
        }
        for (int i = 0; i < n; i++)
        {
            if (lines[i] != string.Empty)
            {
                //isNotBracket = false;
                isFirstCharacter = true;
                foreach (var ch in lines[i])
                {
                    switch (ch)
                    {
                        case '{':
                            if (isNotBracket && !isFirstCharacter) 
                            {
                                if (oneLine.ToString() != string.Empty)
                                {
                                    Console.WriteLine(oneLine.ToString().Trim());
                                }
                                oneLine.Clear();
                            }
                            PrintIndent(indent, s);
                            indent++;
                            oneLine.Append(ch);
                            if (oneLine.ToString() != string.Empty)
                            {
                                Console.WriteLine(oneLine.ToString().Trim());
                            }
                            oneLine.Clear();
                            //PrintIndent(indent, s);
                            isNotBracket = false;
                            isFirstCharacter = false;
                            break;
                        case '}':
                            if (isNotBracket && !isFirstCharacter)
                            {
                                if (oneLine.ToString() != string.Empty)
                                {
                                    Console.WriteLine(oneLine.ToString().Trim());
                                }
                                oneLine.Clear();
                            }
                            indent--;
                            PrintIndent(indent, s);
                            oneLine.Append(ch);
                            if (oneLine.ToString() != string.Empty)
                            {
                                Console.WriteLine(oneLine.ToString().Trim());
                            }
                            oneLine.Clear();
                            //PrintIndent(indent, s);
                            isNotBracket = false;
                            isFirstCharacter = false;
                            break;
                        default:
                            if (!isNotBracket) PrintIndent(indent, s);
                            oneLine.Append(ch); //Console.Write(ch);
                            isNotBracket = true;
                            isFirstCharacter = false;
                            break;
                    }
                }
                if (isNotBracket && i != (n-1))
                {
                    if (oneLine.ToString() != string.Empty)
                    {
                        Console.WriteLine(oneLine.ToString().Trim());
                    }
                    oneLine.Clear();
                    PrintIndent(indent, s);
                }
                if (isNotBracket && i == (n - 1))
                {
                    if (oneLine.ToString() != string.Empty)
                    {
                        Console.Write(oneLine.ToString().Trim());
                    }
                }
                
            }
            
            
        }
    }

    private static void PrintIndent(int indent, string s)
    {
        for (int j = 0; j < indent; j++)
        {
            Console.Write(s);
        }
    }
}