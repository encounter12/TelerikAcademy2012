using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondTask
{
    class Program
    {
        static void Main(string[] args)
        {
            string numbers = Console.ReadLine();
            string[] arr = numbers.Split(new string[] { ", " }, StringSplitOptions.None);
            int[] array = new int[arr.Length];
            for (int i = 0; i < arr.Length; i++)
                array[i] = int.Parse(arr[i]);
            int count=0,position=0,current=0,maxCount=1;
            for (int i = 0; i < array.Length; i++)
            {
                List<int> steps = GetPossibleSteps(i, array);
                foreach (int c in steps)
                {
                    count = 1;
                    position = i;
                    current = array[(i + c) % (array.Length)];
                    while (array[position] < current)
                    {
                        count++;
                        position = (position + c) % (array.Length);
                        current = array[(position + c) % (array.Length)];
                    }
                    if (count > maxCount)
                        maxCount = count;
                }
            }
            /*Array.Reverse(array);
            for (int i = 0; i < array.Length; i++)
            {
                List<int> steps = GetPossibleSteps(i, array);
                foreach (int c in steps)
                {
                    count = 0;
                    position = i;
                    current = array[(i + c) % (array.Length)];
                    while (array[position] < current)
                    {
                        count++;
                        position = (position + c) % (array.Length);
                        current = array[(position + c) % (array.Length)];
                    }
                    if (count > maxCount)
                        maxCount = count;
                }
            }*/
            Console.WriteLine(maxCount);
        }

        static List<int> GetPossibleSteps(int i, int[] array)
        {
            List<int> l = new List<int>();
            int position=0,step=1;;
            if (i < array.Length - 1)
                position = i + 1;
            else
                position = 0;
            while (position != i)
            {
                if (array[position] > array[i])
                    l.Add(step);
                step++;
                position = (position + 1) % (array.Length);
            }
            return l;
        }
    }
}
