using System;
using System.Linq;

class FindRoute
{
    static void Main()
    {
        string[] inputToknes = Console.ReadLine().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

        short[] numbers = new short[inputToknes.Length];

        for (int i = 0; i < inputToknes.Length; i++)
        {
            numbers[i] = short.Parse(inputToknes[i]);
        }

        short bestRoute = 0;

        for (short j = 0; j < numbers.Length; j++)
        {
            for (short i = 1; i < numbers.Length; i++)
            {
                bool[] marked = new bool[numbers.Length];
                short currentRoute = 0;

                int lastNumber = short.MinValue;

                for (int k = j, step = k; k < numbers.Length + j; k++, step += i)
                {
                    if (step >= numbers.Length)
                        step %= numbers.Length;

                    if (!marked[step] && lastNumber < numbers[step])
                    {
                        marked[step] = true;
                        currentRoute++;
                    }
                    else
                    {
                        break;
                    }

                    lastNumber = numbers[step];
                }

                if (currentRoute > bestRoute)
                    bestRoute = currentRoute;
            }
        }

        Console.WriteLine(bestRoute);
    }
}