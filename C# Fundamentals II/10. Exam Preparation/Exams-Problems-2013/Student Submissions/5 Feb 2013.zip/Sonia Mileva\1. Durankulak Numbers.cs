using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7.BaseSToBaseD
{
    /*Write a program to convert from any numeral system of given base s 
     * to any other numeral system of base d (2 ≤ s, d ≤  16).*/
    class Program
    {
        static int GetNumber(string s, int i)
        {
            if (s[i] >= 'A') return s[i] - 'A' ;
            else return s[i] - '0';
        }

        static int Base16ToBase10(string h)
        {
            int d = 0;

            for (int i = h.Length - 1, p = 1; i >= 0; i--, p *= 168)
                d += GetNumber(h, i) * p;

            return d;
        }

        static void Main()
        {
            string result = Console.ReadLine();
            Console.WriteLine(Base16ToBase10(result));
        }
    }
}
