using System;
using System.Collections.Generic;

class AcademyTasks
{
    static int minNumber(int[] terrain, int[]originalTerrain)
    {
        int startIndex=0;
        int endIndex = 0;
        int step = 0;
        int count = 0;
        List<int> counts = new List<int>();

        for (int k = 0; k < terrain.Length-1; k++)
        {
            for (int j = 0; j < originalTerrain.Length; j++)
            {
                if (terrain[k] == originalTerrain[j])
                {
                    startIndex = j;
                }
            }
            for (int m = 0; m < originalTerrain.Length; m++)
            {
                if (terrain[k+1] == originalTerrain[m])
                {
                    endIndex = m;
                }
            }

            if (startIndex>endIndex)
            {
                step = originalTerrain.Length - startIndex + endIndex;
            }
            else
            {
                step = endIndex - startIndex;
            }

            count = 0;
            for (int n = 0; n < originalTerrain.Length; n++)
            {
                if (startIndex>=originalTerrain.Length)
                {
                    startIndex = startIndex - originalTerrain.Length;
                }
                int end = startIndex + step;
                if (end>=originalTerrain.Length)
                {
                    end = end - originalTerrain.Length;
                }
                if (originalTerrain[startIndex] < originalTerrain[end])
                {
                    count++;
                }
                else
                {
                    break;
                }
                startIndex = end;

            }
            counts.Add(count);
        }

        counts.Sort();

        return counts[counts.Count-1]+1;

        
    }

    static void Main()
    {
        string line = Console.ReadLine();
        string[] lineArr = line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        int[] terrain = new int[lineArr.Length];
        int[] originalTerrain = new int[lineArr.Length];

        for (int i = 0; i < lineArr.Length; i++)
        {
            originalTerrain[i] = int.Parse(lineArr[i]);
        }
        for (int i = 0; i < lineArr.Length; i++)
        {
            terrain[i] = int.Parse(lineArr[i]);
        }

         Array.Sort(terrain);

        int terrainLenght = terrain.Length;


       // foreach (var t in terrain)
       //{
       //    Console.WriteLine(t);
       // }
       // foreach (var t in originalTerrain)
       // {
       //     Console.WriteLine(t);
       // }
       Console.WriteLine(minNumber(terrain,originalTerrain));


    }


}
