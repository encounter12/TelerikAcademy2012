
using System;

class Program
{
    static int sizeX = 0;

    static int sizeY = 0;

    static int sizeZ = 0;

    static int[] dir = null;

    static bool[, ,] cuboid = null;

    static Cell thisCell = null;

    static Cell prevCell = null;

    class Cell
    {
        public int posX;

        public int posY;

        public int posZ;

        public Cell(int a, int b, int c)
        {
            posX = a;
            posY = b;
            posZ = c;
        }

        public string PrintCell()
        {
            return posX + " " + posY + " " + posZ;
        }
    }

    static void Main(string[] args)
    {
        string[] dimensions = Console.ReadLine().Split(new char[] {' '});

        sizeX = int.Parse(dimensions[0]);

        sizeY = int.Parse(dimensions[1]);

        sizeZ = int.Parse(dimensions[2]);

        cuboid = new bool[sizeX, sizeY, sizeZ];

        string[] startPos = Console.ReadLine().Split(new char[] { ' ' });

        thisCell = new Cell(int.Parse(startPos[0]) - 1, int.Parse(startPos[1]) - 1, int.Parse(startPos[2]) - 1);

        prevCell = new Cell(thisCell.posX, thisCell.posY, thisCell.posZ);

        string[] inputDirection = Console.ReadLine().Split(new char[] { ' ' });

        dir = new int[] {int.Parse(inputDirection[0]), int.Parse(inputDirection[1]), int.Parse(inputDirection[2])};

        InitCuboid();

        StartLazer();

        ++prevCell.posX;

        ++prevCell.posY;

        ++prevCell.posZ;

        Console.WriteLine(prevCell.PrintCell());
    }

    private static void InitCuboid()
    {
        for (int i = 0; i < sizeX; i++)
        {
            cuboid[i, 0, 0] = true;
            cuboid[i, sizeY - 1, 0] = true;
            cuboid[i, sizeY - 1, sizeZ - 1] = true;
            cuboid[i, 0, sizeZ - 1] = true;
        }

        for (int i = 0; i < sizeY; i++)
        {
            cuboid[0, i, 0] = true;
            cuboid[0, i, sizeZ - 1] = true;
            cuboid[sizeX - 1, i, 0] = true;
            cuboid[sizeX - 1, i, sizeZ - 1] = true;
        }

        for (int i = 0; i < sizeZ; i++)
        {
            cuboid[0, 0, i] = true;
            cuboid[0, sizeY - 1, i] = true;
            cuboid[sizeX - 1, sizeY - 1, i] = true;
            cuboid[sizeX - 1, 0, i] = true;
        }
    }

    private static void StartLazer()
    {
        if (cuboid[thisCell.posX, thisCell.posY, thisCell.posZ])
        {
            return;
        }

        cuboid[thisCell.posX, thisCell.posY, thisCell.posZ] = true;

        prevCell.posX = thisCell.posX;
        prevCell.posY = thisCell.posY;
        prevCell.posZ = thisCell.posZ;

        GetNextCell();

        StartLazer();
    }

    private static void GetNextCell()
    {
        if ((dir[0] == 1 && thisCell.posX==sizeX-1) || (dir[0] == -1 && thisCell.posX == 0))
        {
            ReflectDirection(0);
        }

        if ((dir[1] == 1 && thisCell.posY==sizeY-1) || (dir[1] == -1 && thisCell.posY == 0))
        {
            ReflectDirection(1);
        }

        if((dir[2] == 1 && thisCell.posZ==sizeZ-1) || (dir[2] == -1 && thisCell.posZ == 0))
        {
            ReflectDirection(2);
        }

        thisCell.posX += dir[0];
        thisCell.posY += dir[1]; 
        thisCell.posZ += dir[2];
    }

    private static void ReflectDirection(int i)
    {
        dir[i] = -dir[i];
    }
}
