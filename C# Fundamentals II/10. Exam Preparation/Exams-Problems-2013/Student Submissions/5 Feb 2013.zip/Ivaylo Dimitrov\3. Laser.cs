using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Laser
{
    class Laser
    {
        static void Main()
        {
            string cube = Console.ReadLine();

            char[] separator = { ' ' };
            string[] cubDim = cube.Split(separator);
            CubeW = int.Parse(cubDim[0]);
            CubeH = int.Parse(cubDim[1]);
            CubeD = int.Parse(cubDim[2]);

            string lazerPosition = Console.ReadLine();
            string[] lazerSplit = lazerPosition.Split(separator);

            Laser laser = new Laser(int.Parse(lazerSplit[0]), int.Parse(lazerSplit[1]), int.Parse(lazerSplit[2]));

            string lazerDirection = Console.ReadLine();
            string[] direction = lazerDirection.Split(separator);
            int[] dirct = { int.Parse(direction[0]), int.Parse(direction[1]), int.Parse(direction[2]) };

            bool[, ,] isSpet = new bool[CubeW + 1, CubeH + 1, CubeD + 1];
            isSpet[laser.W, laser.H, laser.D] = true;

            while (true)
            {
                laser.W += dirct[0];
                laser.H += dirct[1];
                laser.D += dirct[2];

                if (isSpet[laser.W, laser.H, laser.D])
                {
                    laser.W -= dirct[0];
                    laser.H -= dirct[1];
                    laser.D -= dirct[2];
                    break;
                }

                if (laser.IsBurn())
                {
                    laser.W -= dirct[0];
                    laser.H -= dirct[1];
                    laser.D -= dirct[2];
                    break;
                }

                if (laser.W == CubeW | laser.W == 1)
                {
                    if (dirct[0] == 1)
                    {
                        dirct[0] = -1;
                    }
                    else
                    {
                        dirct[0] = 1;
                    }
                }

                if (laser.H == CubeH | laser.H == 1)
                {
                    if (dirct[1] == 1)
                    {
                        dirct[1] = -1;
                    }
                    else
                    {
                        dirct[1] = 1;
                    }
                }

                if (laser.D == CubeD | laser.D == 1)
                {
                    if (dirct[2] == 1)
                    {
                        dirct[2] = -1;
                    }
                    else
                    {
                        dirct[2] = 1;
                    }
                }

                isSpet[laser.W, laser.H, laser.D] = true;
            }

            Console.WriteLine(laser.W + " " + laser.H + " " + laser.D );

        }

        public int W;
        public int H;
        public int D;
        public static int CubeW;
        public static int CubeH;
        public static int CubeD;

        public Laser(int w, int h, int d)
        {
            this.W = w;
            this.H = h;
            this.D = d;
        }

        public bool IsBurn()
        {
            if ((this.W >= 1 && this.W <= CubeW) && this.H == 1 && this.D ==1)
            {
                return true;
            }
            if ((this.W >= 1 && this.W <= CubeW) && this.H == 1 && this.D == CubeD)
            {
                return true;
            }
            if ((this.W >= 1 && this.W <= CubeW) && this.H == CubeH && this.D ==1)
            {
                return true;
            }
            if ((this.W >= 1 && this.W <= CubeW) && this.H == CubeH && this.D == CubeD)
            {
                return true;
            }

            if (this.W == 1 && this.H == 1 && (this.D >=1 && this.D <= CubeD))
            {
                return true;
            }
            if (this.W == CubeW && this.H == 1 && (this.D >=1 && this.D <= CubeD))
            {
                return true;
            }
            if (this.W == CubeW && this.H == CubeH && (this.D >=1 && this.D <= CubeD))
            {
                return true;
            }
            if (this.W == 1 && this.H == CubeH && (this.D >=1 && this.D <= CubeD))
            {
                return true;
            }

            if (this.W == 1 && (this.H >= 1 && this.H <= CubeH) && this.D == 1)
            {
                return true;
            }
            if (this.W == CubeW && (this.H >= 1 && this.H <= CubeH) && this.D == 1)
            {
                return true;
            }
            if (this.W == CubeW && (this.H >= 1 && this.H <= CubeH) && this.D == CubeD)
            {
                return true;
            }
            if (this.W == 1 && (this.H >= 1 && this.H <= CubeH) && this.D == CubeD)
            {
                return true;
            }

            return false;
        }
    }
}
