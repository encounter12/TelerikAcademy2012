using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Problem1DurankulakNumbers
{
    class Program
    {
        static char[] alfa ={'0','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T',
'U','V','W','X','Y','Z'};
        static public int GetPoss(char asd)
        {
            for (int i = 1; i < alfa.Length; i++)
                if (asd == alfa[i])
                    return i;
            return -1;
        }
 
        static void Main(string[] args)
        {
            string inpute = Console.ReadLine().ToUpper();
 
            List<string> Split2By2 = new List<string>();
            for (int i = inpute.Length - 1; i >= -1; i -= 2)
            {
                if (i - 1 >= 0)
                    Split2By2.Add(inpute.Substring(i - 1, 2));
                else if (i == 0)
                    Split2By2.Add(inpute[i].ToString());
            }
            List<int> number = new List<int>();
 
            for (int listPoss = Split2By2.Count - 1; listPoss >= 0; listPoss--)
            {
                if (Split2By2[listPoss].Length > 1)
                {
                    int f = GetPoss(Split2By2[listPoss][0]) * 26;
                    f += GetPoss(Split2By2[listPoss][1]) - 1;
                    number.Add(f);
                }
                else
                {
                    int f = 0;
                    f += GetPoss(Split2By2[listPoss][0]) - 1;
                    number.Add(f);
                }
            }
            long result = 0;
 
            for (int i = 0; i < number.Count; i++)
            {
                long temp = number[i];
 
                if (i < number.Count - 1)
                    for (int times = number.Count - 1; times > 0; times--)
                        temp *= 168;
                result += temp;
            }
            Console.WriteLine(result);
        }
    }
}