using System;
using System.Collections.Generic;

namespace ExamTwo
{
    class NumberSystem
    {
        static Dictionary<string, byte> symbols = new Dictionary<string, byte>();
        const byte AlphabetLength = 26;
        const byte DuranLenght = 168;

        private static void PrintSymbols()
        {
            foreach (var symbol in symbols)
                Console.WriteLine("{0} {1}", symbol.Key, symbol.Value);
        }

        static void GenerateSymbols()
        {
            string key;
            byte value = 0;

            for (int i = 0, l = DuranLenght / AlphabetLength; i <= l; i++)
            {
                for (int j = 0; j < AlphabetLength; j++)
                {
                    if (i == 0)
                    {
                        key = ((char)(j + 'A')).ToString();
                        symbols[key] = value++;
                    }
                    else
                    {
                        key = ((char)((i - 1) + 'a')).ToString() + (char)(j + 'A');
                        symbols[key] = value++;
                    }

                    if (value == 168)
                    {
                        break;
                    }
                }
            }
        }

        static void Main()
        {
            GenerateSymbols();

            string input = Console.ReadLine().Trim();

            string key;
            string lastChar = input[input.Length - 1].ToString();

            if (input.Length > 1)
            {
                string nextChar = input[input.Length - 2].ToString();
                if (lastChar == lastChar.ToUpper() && nextChar != nextChar.ToUpper())
                {
                    key = input[input.Length - 2] + lastChar.ToString();
                }
                else
                {
                    key = lastChar.ToString();
                }
            }
            else
            {
                key = lastChar.ToString();
            }

            long sum = symbols[key];
            long power = 168;

            for (int i = (input.Length - 1) - key.Length; i >= 0; i--, power *= 168)
            {
                string currentChar = input[i].ToString();

                if (currentChar == currentChar.ToUpper())
                {
                    if (i == 0)
                    {
                        key = currentChar.ToString();
                    }
                    else
                    {
                        string nextKey = (input[i - 1]).ToString();
                        if (nextKey != nextKey.ToUpper())
                        {
                            key = nextKey + currentChar.ToString();
                            i--;
                        }
                        else
                        {
                            key = currentChar.ToString();
                        }
                    }
                }
                else
                {
                    key = currentChar.ToString();
                }

                sum += symbols[key] * power;
            }

            Console.WriteLine(sum);

        }
    }
}
