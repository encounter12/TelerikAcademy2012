using System;
using System.Text;
using System.Text.RegularExpressions;

class Brackets
{
    static void Main()
    {
        int totalLinesNumber = int.Parse(Console.ReadLine());
        string pattern = Console.ReadLine();

        string inputLine = String.Empty;
        StringBuilder tempString = new StringBuilder();
        int patternCount = 0;

        for (int lineNumber = 0; lineNumber < totalLinesNumber; lineNumber++)
        {
            inputLine = Console.ReadLine().Trim();

            char currentChar = ' ';
            for (int i = 0; i < inputLine.Length; i++)
            {
                inputLine = Regex.Replace(inputLine, @"\s{2,}", " ");
                currentChar = inputLine[i];


                if (currentChar != '{' && currentChar != '}' && i == 0)
                {
                    for (int k = 0; k < patternCount; k++)
                    {
                        tempString.Append(pattern);
                    }
                }

                //Opening bracket
                if (i == 0 && currentChar == '{' && i + 1 >= inputLine.Length)
                {
                    for (int j = 0; j < patternCount; j++)
                    {
                        tempString.Append(pattern);
                    }
                    tempString.AppendLine("{");
                    patternCount++;
                    continue;
                }

                if (i == 0 && currentChar == '{' && i + 1 <= inputLine.Length)
                {

                    for (int j = 0; j < patternCount; j++)
                    {
                        tempString.Append(pattern);
                    }
                    tempString.AppendLine("{");
                    patternCount++;
                    for (int k = 0; k < patternCount; k++)
                    {
                        tempString.Append(pattern);
                    }
                    continue;
                }

                if (i != 0 && currentChar == '{' && i + 1 >= inputLine.Length)
                {
                    tempString.AppendLine();

                    for (int k = 0; k < patternCount; k++)
                    {
                        tempString.Append(pattern);
                    }
                    tempString.Append("{");
                    tempString.AppendLine();
                    patternCount++;
                    continue;
                }

                if (i != 0 && currentChar == '{' && i + 1 < inputLine.Length)
                {
                    tempString.AppendLine();
                    for (int k = 0; k < patternCount; k++)
                    {
                        tempString.Append(pattern);
                    }
                    tempString.AppendLine("{");
                    patternCount++;
                    for (int k = 0; k < patternCount; k++)
                    {
                        tempString.Append(pattern);
                    }
                    continue;
                }

                //Closing bracket
                if (i == 0 && currentChar == '}' && i + 1 >= inputLine.Length)
                {
                    patternCount--;
                    for (int j = 0; j < patternCount; j++)
                    {
                        tempString.Append(pattern);
                    }
                    tempString.AppendLine("}");
                    continue;
                }


                if (i != 0 && currentChar == '}' && i + 1 < inputLine.Length && inputLine[i + 1] != '{' && inputLine[i + 1] != '}')
                {
                    tempString.AppendLine();
                    patternCount--;
                    for (int j = 0; j < patternCount; j++)
                    {
                        tempString.Append(pattern);
                    }
                    tempString.AppendLine("}");

                    for (int k = 0; k < patternCount; k++)
                    {
                        tempString.Append(pattern);
                    }
                    continue;
                }

                if (i != 0 && currentChar == '}' && i + 1 >= inputLine.Length)
                {
                    tempString.AppendLine();
                    patternCount--;
                    for (int k = 0; k < patternCount; k++)
                    {
                        tempString.Append(pattern);
                    }
                    tempString.AppendLine("}");
                    continue;
                }

                if (i != 0 && currentChar == '}' && i + 1 < inputLine.Length)
                {
                    tempString.AppendLine();
                    patternCount--;
                    for (int k = 0; k < patternCount; k++)
                    {
                        tempString.Append(pattern);
                    }
                    tempString.AppendLine("}");

                    for (int k = 0; k < patternCount; k++)
                    {
                        tempString.Append(pattern);
                    }
                    continue;
                }
                if (currentChar==' ')
                {
                    if (tempString.ToString().Length - pattern.Length>=0)
                    {
                        if (tempString.ToString().Substring(tempString.ToString().Length - pattern.Length) == pattern)
                        {
                            continue;
                        }
                    }
                   
                }

                tempString.Append(currentChar);

                if (i == inputLine.Length - 1)
                {
                    tempString.AppendLine();
                }
            }
        }
        string final = tempString.ToString();

        string[] allLines = final.Split(new char[] {'\n','\r'}, StringSplitOptions.RemoveEmptyEntries);
        StringBuilder resultString = new StringBuilder();
        foreach (string line in allLines)
        {
            if (!String.IsNullOrWhiteSpace(line))
            {
                resultString.AppendLine(line.TrimEnd());
            }
        }
        Console.Write(resultString.ToString());
    }
}
