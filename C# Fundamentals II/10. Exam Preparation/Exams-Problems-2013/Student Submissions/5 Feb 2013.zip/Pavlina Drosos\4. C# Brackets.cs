namespace TaskFour
{
    using System;
    using System.Text;
    using System.Linq;
    using System.Text.RegularExpressions;

    public class CSharpBrackets
    {
        public static void Main(string[] args)
        {
            int numberOfLines = int.Parse(Console.ReadLine());
            string identationSymbols = Console.ReadLine();

            StringBuilder code = new StringBuilder();

            string line;
            int openingBracketsCount = 0;
            char currentSymbol;
            for (int i = 0; i < numberOfLines; i++)
            {
                line = ClearWhiteSpaces(Console.ReadLine().Trim());
                if (line.Length > 0)
                {
                    for (int j = 0; j < line.Length; j++)
                    {
                        currentSymbol = line[j];

                        if (currentSymbol == '{')
                        {
                            openingBracketsCount++;

                            if (j > 0 || (code.Length > 0 && code[code.Length - 1] != '\n')) // we must add a new line berofe the bracket
                            {
                                code.Append('\n');
                            }

                            if (openingBracketsCount > 1)
                            {
                                code.Append(string.Concat(Enumerable.Repeat(identationSymbols, openingBracketsCount - 1)));
                            }

                            code.Append(currentSymbol);

                            if (j < line.Length - 1 && line[j + 1] != '\n') // we must add a new line after the bracket
                            {
                                code.Append('\n');
                            }
                            
                            continue;
                        }

                        if (currentSymbol == '}')
                        {
                            if (j > 0 || (code.Length > 0 && code[code.Length - 1] != '\n')) // we must add a new line berofe the bracket
                            {
                                code.Append('\n');
                            }

                            if (openingBracketsCount > 1)
                            {
                                code.Append(string.Concat(Enumerable.Repeat(identationSymbols, openingBracketsCount - 1)));
                            }

                            code.Append(currentSymbol);

                            if (j < line.Length - 1 && line[j + 1] != '\n') // we must add a new line after the bracket
                            {
                                code.Append('\n');
                            }

                            openingBracketsCount--;
                            continue;
                        }

                        if (code.Length > 0 && code[code.Length - 1] == '\n')
                        {
                            code.Append(string.Concat(Enumerable.Repeat(identationSymbols, openingBracketsCount)));
                        }
                        code.Append(currentSymbol);
                    }
                }
            }
            
            Console.WriteLine(code.ToString().Trim());
        }

        public static string ClearWhiteSpaces(string text)
        {
            return Regex.Replace(text.Trim(), @"\s+", " ");
        }
    }
}
