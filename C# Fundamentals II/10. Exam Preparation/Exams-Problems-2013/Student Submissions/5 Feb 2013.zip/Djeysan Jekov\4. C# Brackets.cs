using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{
    static int totalLines;
    static string indentationString;
    static List<string> unformatedCode;
    static List<string> formatedCode;

    static void Input()
    {
        totalLines = int.Parse(Console.ReadLine());
        indentationString = Console.ReadLine();

        unformatedCode = new List<string>(totalLines);
        formatedCode = new List<string>(totalLines * 2);

        for (int i = 0; i < totalLines; i++)
            unformatedCode.Add(Console.ReadLine());
    }

    static void PrintCode(List<string> code)
    {
#if DEBUG
        foreach (var line in code)
            Console.WriteLine(line);
#endif
    }

    static string TrimInnerSpaces(string line)
    {
        line = line.Trim(); // BGCoder trims end

        return Regex.Replace(line, " +", " ");

        // return Regex.Replace(line, @"([^\""])\s{2,}([^\""])", "$1 $2");
    }

    static StringBuilder GetIdentation(int stack)
    {
        StringBuilder indentation = new StringBuilder();

        for (int i = 0; i < stack; i++)
            indentation.Append(indentationString);

        return indentation;
    }

    static void FormatCode()
    {
        int stack = 0;

        for (int i = 0; i < unformatedCode.Count; i++)
        {
            string line = unformatedCode[i];

            for (int j = 0; j < line.Length; j++)
            {
                char c = line[j];

                if (c == '{')
                {
                    formatedCode.Add(GetIdentation(stack).Append("{").ToString());
                    stack++;
                }

                else if (c == '}')
                {
                    stack--;
                    formatedCode.Add(GetIdentation(stack).Append("}").ToString());
                }

                else
                {
                    StringBuilder left = new StringBuilder();

                    while (j < line.Length && line[j] != '{' && line[j] != '}')
                    {
                        left.Append(line[j++]);
                    }
                    j--;

                    string str = left.ToString();

                    if (!String.IsNullOrWhiteSpace(str))
                        formatedCode.Add(GetIdentation(stack).Append(TrimInnerSpaces(left.ToString())).ToString());
                }

            }
        }
    }

    static void Output()
    {
        foreach (var line in formatedCode)
            Console.WriteLine(line);
    }

    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input3.txt"));
#endif
        Input();

        // PrintCode(unformatedCode);

        FormatCode();

        Output();
    }
}
