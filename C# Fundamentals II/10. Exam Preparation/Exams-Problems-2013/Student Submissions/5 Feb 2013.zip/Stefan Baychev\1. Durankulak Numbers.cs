using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Task_One
{
    class Program
    {
 
 
        static void Main(string[] args)
        {
            string cons = Console.ReadLine();
            for (int i = cons.Length; i > 0; i--)
            {
                if (cons.Length == 1)
                {
                    var temp = Encoding.ASCII.GetBytes(cons);
                    foreach (byte element in temp)
                        Console.WriteLine(element - 65);
                }
                else
                {
 
                }
            }
 
        }
    }
}