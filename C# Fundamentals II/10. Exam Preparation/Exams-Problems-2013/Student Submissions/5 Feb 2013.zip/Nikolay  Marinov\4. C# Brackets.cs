using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Problem04
{
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
#endif

        //variables
        int n = int.Parse(Console.ReadLine());
        string s = Console.ReadLine();

        int bracketsCounter = 0;
        int counter = 0;
        string indent = null;
        string[] code = new string[n];
        //char[] codes = new char[]();

        for (int i = 0; i < n; i++)
        {
            string line = Console.ReadLine();
            string[] codes = new string[300];

            codes = line.Split();
            foreach (var letters in line)
            //for (int m = 0; m < codes.Length; m++)
            {
                if (letters == '{' || letters == '}')
                {
                    bracketsCounter++;
                }
            }
            code[i] = line;
        }

        counter = bracketsCounter;
        bool isMethod = false;
        bool isBracket = false;
        bool isSpace = false;
        foreach (var line in code)
        {
            if (line.IndexOfAny(new char[] { '[', '(', }) != -1
                && line.IndexOfAny(new char[] { ']', ')', }) != -1)
            {
                isMethod = true;
            }
            foreach (var letter in line)
            {
                #region Opneing
                if (letter == '{' && counter == bracketsCounter)
                {
                    counter--;
                    indent += s;
                    Console.Write(letter + "\n" + indent);
                    //isBracket = true;
                    continue;
                }
                if (letter == '{' && counter < bracketsCounter && counter > bracketsCounter / 2 && isMethod)
                //&& line.LastIndexOf(letter)!= line.Length)
                {
                    counter--;
                    indent += s;
                    Console.Write("\n" + indent + letter + "\n" + indent);
                    isBracket = true;
                    continue;
                }
                if (letter == '{' && counter < bracketsCounter && counter > bracketsCounter / 2 && !isMethod)
                //&& line.LastIndexOf(letter)!= line.Length)
                {
                    counter--;
                    //indent += s;
                    Console.Write("\n" + indent + letter + "\n" + indent);
                    isBracket = true;
                    continue;
                }
                #endregion


                #region Closing
                if (letter == '}' && counter <= bracketsCounter / 2 && !isBracket)
                {
                    if (indent.Length > 0)
                    {
                        indent = indent.Remove(indent.Length - s.Length);
                    }
                    //Console.Write(indent + letter + "\n" + indent);
                    Console.Write("\n" + indent + letter + "\n" + indent);
                    continue;
                }
                if (letter == '}' && counter <= bracketsCounter / 2 && isBracket)
                {
                    if (indent.Length > 0)
                    {
                        indent = indent.Remove(indent.Length - s.Length);
                    }
                    Console.Write(indent + letter + "\n" + indent);
                    //Console.Write("\n" + indent + letter + "\n" + indent);
                    continue;
                }
                #endregion


                #region letter
                if (letter == ' ' && !isSpace)
                {
                    isSpace = true;
                    Console.Write(letter);
                }
                if (letter == ' ' && isSpace)
                {
                    continue;
                }
                if (line.IndexOf(letter) == 0 && letter != '{' || letter != '}' && letter != ' ' && isBracket)
                {
                    Console.Write(indent + letter);
                    isBracket = false;
                    isSpace = false;
                    continue;
                }
                if (letter != '{' || letter != '}' && letter != ' ')
                {
                    Console.Write(letter);
                    isBracket = false;
                    isSpace = false;
                    continue;
                }
                #endregion
            }
            //Console.WriteLine();
        }
    }
}