using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;



class Program
{
    private static bool[] _visited;
    private static void FindMin(int[] arr)
    {
        int min = int.MaxValue;
        int minIndex = -1;
        for (int i = 0; i < arr.Length; i++)
        {
            if (_visited[i] == false && arr[i] < min)
            {
                min = arr[i];
                minIndex = i;
            }
            if (_visited[arr.Length - 1 - i] == false && arr[arr.Length - 1 - i] < min)
            {
                min = arr[arr.Length - 1 - i];
                minIndex = arr.Length - 1 - i;
            }
        }
        _visited[minIndex] = true;
    }

    static void Main()
    {
        string input = Console.ReadLine();
        string[] temp = input.Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
        int[] numbers = new int[temp.Length];
        _visited= new bool[temp.Length];
        List<int> lol = new List<int>(numbers);
        Console.WriteLine(numbers.Length);
        
        
    }
}

