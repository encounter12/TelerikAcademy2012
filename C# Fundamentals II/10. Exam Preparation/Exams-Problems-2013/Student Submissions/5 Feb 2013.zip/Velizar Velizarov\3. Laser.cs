using System;
 
class Laser
{
    static int w, h, d;
    static int lStartW, lStartH, lStartD;
    static int lDirectionW, lDirectionH,lDirectionD;
    static bool[, ,] cuboid;
    static int resultW, resultH, resultD;
 
    static void Main()
    {
        ReadCuboid();
        BurnEdges();
        LaserMove(lStartW, lStartH, lStartD, lDirectionW, lDirectionH, lDirectionD);
        Console.WriteLine("{0} {1} {2}", resultW, resultH, resultD);
    }
 
    private static void BurnEdges()
    {
        for (int i = 0; i < w; i++)
        {
            cuboid[i, 0, 0] = true;
            cuboid[i, h - 1, d - 1] = true;
            cuboid[i, 0, d - 1] = true;
            cuboid[i, h - 1, 0] = true;
        }
        for (int i = 0; i < h; i++)
        {
            cuboid[0, i, 0] = true;
            cuboid[w - 1, i, 0] = true;
            cuboid[0, i, d - 1] = true;
            cuboid[w - 1, i, d - 1] = true;
        }
        for (int i = 0; i < d; i++)
        {
            cuboid[0, 0, i] = true;
            cuboid[w - 1, h - 1, i] = true;
            cuboid[0, h - 1, i] = true;
            cuboid[w - 1, 0, i] = true;
        }
    }
 
    private static void LaserMove(int currentX, int currentY, int currentZ, int directionX, int directionY, int directionZ)
    {
        if (cuboid[currentX, currentY, currentZ])
        {
            return;
        }
        cuboid[currentX, currentY, currentZ] = true;
        resultW = currentX;
        resultH = currentY;
        resultD = currentZ;
 
        currentX += directionX;
        currentY += directionY;
        currentZ += directionZ;
        if (cuboid[currentX, currentY, currentZ])
        {
            return;
        }
        else if ((currentX >= w - 1 && currentZ >= d - 1) || (currentX <= 1 && currentZ <= 1))
        {
            LaserMove(currentX, currentY, currentZ, -directionX, directionY, -directionZ);
        }
        else if ((currentX >= w - 1 && currentY >= h - 1) || (currentX <= 1 && currentY <= 1))
        {
            LaserMove(currentX, currentY, currentZ, -directionX, -directionY, directionZ);
        }
        else if ((currentY >= h - 1 && currentZ >= d - 1) || (currentY <= 1 && currentZ <= 1))
        {
            LaserMove(currentX, currentY, currentZ, directionX, -directionY, -directionZ);
        }
        else if (currentX >= w - 1 || currentX <= 1)
        {
            LaserMove(currentX, currentY, currentZ, -directionX, directionY, directionZ);
        }
        else if (currentY >= h - 1 || currentY <= 1)
        {
            LaserMove(currentX, currentY, currentZ, directionX, -directionY, directionZ);
        }
        else if (currentZ >= d - 1 || currentZ <= 1)
        {
            LaserMove(currentX, currentY, currentZ, directionX, directionY, -directionZ);
        }
        else
        {
            LaserMove(currentX, currentY, currentZ, directionX, directionY, directionZ);
        }
    }
 
 
    private static void ReadCuboid()
    {
        string cuboidSize = Console.ReadLine();
        string[] sizes = cuboidSize.Split(' ');
        w = int.Parse(sizes[0]);
        h = int.Parse(sizes[1]);
        d = int.Parse(sizes[2]);
        cuboid = new bool[w, h, d];
 
        string lazerStart = Console.ReadLine();
        string[] startPoints = lazerStart.Split(' ');
        lStartW = int.Parse(startPoints[0]);
        lStartH = int.Parse(startPoints[1]);
        lStartD = int.Parse(startPoints[2]);
 
        string lazerDirection = Console.ReadLine();
        string[] direction = lazerDirection.Split(' ');
        lDirectionW = int.Parse(direction[0]);
        lDirectionH = int.Parse(direction[1]);
        lDirectionD = int.Parse(direction[2]);
    }
}