using System;

class JoroTheRabbit
{
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
#endif
        string input = Console.ReadLine();
        string[] values = input.Split(',');
        int len = values.Length;
        int[] circle = new int[len];
        for (int i = 0; i < len; i++)
        {
            circle[i] = int.Parse(values[i]);
        }

        int result = 1;
        for (int step = 1; step < len; step++)
        {
            for (int i = 0; i < len; i++)
            {
                if (result < checkJumps(circle, i, step, len))
                {
                    result = checkJumps(circle, i, step, len);
                }

            }
        }
       
        Console.WriteLine(result);
    }

    static int checkJumps(int[] circle, int index, int step, int len) 
    {
        int i = index;
        int count = 1;
        bool[] visited = new bool[len];//false by def
        visited[i] = true;

        while (count <= len)
        {
            int next = i + step;

            if (i+step > len - 1)
            {
                next = (i + step) % (len); 
            }
            if (!visited[next])
            {
                if (circle[i] < circle[next])
                {
                    count++;
                    visited[next] = true;
                    i = next;
                }
                else//fail attempt
                {
                    return count;
                }
            }
            else
            {
                return count;
            }   
        }
        return -1;
    }
}
