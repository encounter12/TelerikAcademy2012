using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Numerics;

namespace _05.Luckynumbers
{
    class Program
    {
        static double palindromeCount = 0;
        static void Main(string[] args)
        {
            string firstTask = Console.ReadLine();
            string[] splittedFirstTask = firstTask.Split(' ');

            string left = splittedFirstTask[0];
            string right = splittedFirstTask[1];
            string input = Console.ReadLine();
            string percentile = Console.ReadLine();

            List<int> sortedList = new List<int>();
            string[] numberList = input.Split(',');
            foreach (string item in numberList)
            {
                sortedList.Add(int.Parse(item));
            }
            sortedList.Sort();
            double preIndex = (int.Parse(percentile) * sortedList.Count()) / 100.0;
            if (preIndex - (int)preIndex == 0)
            {
                preIndex--;
            }
            int indexElement = (int)preIndex;


            FindPalindromes(left, right);
            Console.WriteLine(palindromeCount);
            Console.WriteLine(sortedList[indexElement]);
        }

        private static void FindPalindromes(string left, string right)
        {
            double marginLeft = double.Parse(left);
            double marginRight = double.Parse(right);
            string currentNumber;
            double reversedNumber;
            int j = 1;
            for (double i = marginLeft; i <= marginRight; i++)
            {
                //if (CheckLuckyDigits(i))
                currentNumber = i.ToString();
                if (currentNumber.IndexOf("1")==-1 &&currentNumber.IndexOf("2")==-1 &&currentNumber.IndexOf("4")==-1 &&
                    currentNumber.IndexOf("6")==-1 &&currentNumber.IndexOf("7")==-1 &&currentNumber.IndexOf("8")==-1 &&
                    currentNumber.IndexOf("9")==-1 &&currentNumber.IndexOf("0")==-1)
                
                {
                    if (isPalindrome(i)&&currentNumber[currentNumber.Length-1] == '3')
                    {
                        palindromeCount++;
                        i = i + 1;
                    }
                    else if (isPalindrome(i) && currentNumber[currentNumber.Length - 1] == '5')
                    {
                        palindromeCount++;
                        i = i + 7;
                    }
                    
                }
                
            }

        }

        private static bool isPalindrome(double i)
        {
            string palindrome = i.ToString();
            int length = palindrome.Length;
            for (int j = 0; j < length; j++)
            {
                if (palindrome[j]!= palindrome[length-1-j])
                {
                    return false;
                }
            }

            return true;
        }

        private static bool CheckLuckyDigits(double currentNumber)
        {
            string pattern = @"[12467890]";
            if (Regex.Match(currentNumber.ToString(), pattern).ToString() == "")
            {
                return true;
            }
            return false;
        }

        
    }
}