using System;
using System.Collections.Generic;
 
class TwoIsBetterThanOne
{
    static void Main()
    {
 
        string[] nums = new string[2];
        string input = Console.ReadLine();
         
        nums = input.Split(' ');
        long num1 = long.Parse(nums[0]);
        long num2 = long.Parse(nums[1]);
 
        string[] list = Console.ReadLine().Split(',');
 
        long[] numbers = new long[list.Length];
 
        for (int i = 0; i < list.Length; i++)
        {
            numbers[i] = long.Parse(list[i]);
        }
 
        SortArray(numbers);
 
        string temp = num1.ToString();
        long currNumb = num1;
        long remainder = 1;
 
        bool checkIsPalindrome = true;
        bool isLucky = true;
        int counter = 0;
 
        for (long i = num1; i <= num2; i++)
        {
            temp = i.ToString();
            for (int j = 0; j < (temp.Length / 2); j++)
            {
                if (temp[j] != temp[temp.Length - j - 1])
                {
                    checkIsPalindrome = false;
                    break;
                }
            }
            if (checkIsPalindrome)
            {
                remainder = i;
                while (remainder > 0)
                {
                    if (remainder % 10 == 3 | remainder % 10 == 5)
                    {
                        remainder = remainder / 10;
                        continue;
                    }
                    else
                    {
                        isLucky = false;
                        break;
                    }
                }
            }
            if (checkIsPalindrome == true && isLucky == true)
            {
                counter++;
            }
            checkIsPalindrome = isLucky = true;
        }
 
        int percebtile = int.Parse(Console.ReadLine());
        int pp = 0;
         
         
        Console.WriteLine(counter);
 
        double p = ((list.Length) * percebtile) / 100.0;
        pp = ((list.Length) * percebtile) / 100;
        double ppD = (double)pp;
 
        if (p > ppD)
        {
            Console.WriteLine(numbers[pp]);
        }
        else
        {
            Console.WriteLine(numbers[pp - 1]);
        }     
    }
 
    static void SortArray(long[] myArray)
    {
        long min, temp;
 
        for (int i = 0; i < myArray.Length - 1; i++)
        {
            min = i;
            for (int j = i + 1; j < myArray.Length; j++)
            {
                if (myArray[j] < myArray[min])
                {
                    min = j;
                }
            }
            temp = myArray[i];
            myArray[i] = myArray[min];
            myArray[min] = temp;
        }
    }
}