using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class TwoIsBetterThanOne
{
    static bool Print(string str)
    {
        foreach (char ch in str)
        {
            if (ch == '1' | ch == '2' | ch == '4' | ch == '6' | ch == '7' | ch == '8' | ch == '9' | ch == '0')
            {
                return false;
            }
        }
        return true;
    }
    static bool IsPalindrome(string str)
    {
        for (int i = 0; i < str.Length / 2; i++)
        {
            if (str[i] != str[str.Length - 1 - i])
            {
                return false;
            }
        }
        return true;
    }
    static void Main()
    {
        string input1 = Console.ReadLine();
        string[] arr = input1.Split();
        int a, b;
        a = int.Parse(arr[0]);
        b = int.Parse(arr[1]);
        int number=a;
        string str="";
        int count = 0;

        for (int j = a; j <= b; j += 2)
        {
            number=j;
            if (number % 10 == 3 | number % 10 == 5)
            {
                str = Convert.ToString(number);

                foreach (Match item in Regex.Matches(str, @"\w+"))
                {
                    if (Print(str))
                    {
                        if (IsPalindrome(item.Value))
                        {
                            count++;
                        }
                    }
                }
            }
        }
        //2

        string input2 = Console.ReadLine();
        decimal p = decimal.Parse(Console.ReadLine());
        string[] arr2 = input2.Split(',');
        decimal[] numbers = new decimal[arr2.Length];
        List<decimal> list = new List<decimal>();
        int count2 = 0;
        for (int i = 0; i < arr2.Length; i++)
        {
            numbers[i] = Convert.ToDecimal(arr2[i]);
        }

        for (int i = 0; i < numbers.Length; i++)
        {
            for (int j = 0; j < numbers.Length; j++)
            {
                if (numbers[i] >= numbers[j])
                {
                    count2++;
                }
            }
            if (Convert.ToDecimal(count2) >= numbers.Length * p / 100)
            {
                list.Add(numbers[i]);
            }
            count2 = 0;
        }
        list.Sort();
        Console.WriteLine(count + "\n" + (int)(list[0]));
        
    }
}
