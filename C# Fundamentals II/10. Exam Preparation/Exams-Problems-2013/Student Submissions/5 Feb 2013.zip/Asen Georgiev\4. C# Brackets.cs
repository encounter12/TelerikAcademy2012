using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace _04.Forth
{
    class forth
    {
        static void Main()
        {
            //string separator = ">>";
           // string[] str = new string[] { "{class prer{ ", "stat dfs[] serfe", "= new ster[] { \" \" };}","}" };

            int n = int.Parse(Console.ReadLine());
            string separator = Console.ReadLine();
            string[] str = new string[n];
            for (int i = 0; i < n; i++)
            {
                str[i] = Console.ReadLine();
            }


            List<string> newstr = new List<string>();
            StringBuilder sb = new StringBuilder();          

            int countBracket = 0;
            for (int k = 0; k < str.Length; k++)
            {
                bool newline = true;
                sb.Append(str[k]);

                for (int j = 0; j < sb.Length; j++)
                {
                    if (Regex.IsMatch(sb[j].ToString(), @"[^\{\}\s].?"))
                    {
                        if (newline == true)
                        {
                            for (int i = 0; i < countBracket; i++)
                            {
                                sb.Insert(j, separator);
                                j += separator.Length;
                            }
                            newline = false;
                        }
                        if (j == sb.Length - 1)
                        {
                            sb.Insert(j + 1, Environment.NewLine);
                            j += 2;
                        }
                    }
                    else if (sb[j] == ' ')
                    {
                        if (newline == true)
                        {
                            sb.Remove(j, 1);
                            j--;
                        }
                        else if (j == sb.Length - 1)
                        {
                            sb.Remove(j, 1);
                            j--;
                            sb.Insert(j + 1, Environment.NewLine);
                            j += 2;
                        }
                        else if (sb[j - 1] == ' ')
                        {
                            sb.Remove(j, 1);
                            j--;
                        }
                    }
                    else if (sb[j] == '{')
                    {
                        if (newline == false)
                        {
                            sb.Insert(j, Environment.NewLine);
                            j += 2;
                        }
                        for (int i = 0; i < countBracket; i++)
                        {
                            sb.Insert(j, separator);
                            j += separator.Length;
                        }
                        countBracket++;

                        sb.Insert(j + 1, Environment.NewLine);
                        j += 2;

                        newline = true;
                    }
                    else if (sb[j] == '}')
                    {
                        if (newline == false)
                        {
                            sb.Insert(j, Environment.NewLine);
                            j += 2;
                        }
                        countBracket--;
                        for (int i = 0; i < countBracket; i++)
                        {
                            sb.Insert(j, separator);
                            j += separator.Length;
                        }
                        sb.Insert(j + 1, Environment.NewLine);
                        j += 2;

                        newline = true;
                    }
                }

                Console.Write(sb.ToString());
                sb.Clear();
            }
        }
    }
}
