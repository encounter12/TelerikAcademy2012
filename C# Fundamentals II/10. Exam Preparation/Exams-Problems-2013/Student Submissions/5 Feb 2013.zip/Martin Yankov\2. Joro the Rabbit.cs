using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Second
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] arrStr = input.Split(',');
            int[] numbers = new int[arrStr.Length];

            for (int i = 0; i < arrStr.Length; i++)
            {
                numbers[i] = int.Parse(arrStr[i].Trim());
            }

            //foreach (var item in numbers)
            //{
            //    Console.WriteLine(item);
            //}

            int largestSequence = 0;

            for (int j = 1; j <= numbers.Length; j++)
            {
                int range = j;

                for (int i = 0; i < numbers.Length; i++)
                {
                    int sequence = TryJumping(i, range, numbers);

                    if (sequence > largestSequence)
                    {
                        largestSequence = sequence;
                    }
                }
            }

            Console.WriteLine(largestSequence);
        }

        public static int TryJumping(int start, int range, int[] numbers)
        {
            int index = start;
            int currentValue = -1001;
            bool[] visited = new bool[numbers.Length];
            int counter = 0;

            while (numbers[index] > currentValue && visited[index] == false)
            {
                visited[index] = true;
                currentValue = numbers[index];
                counter++;
                index += range;

                if (index > numbers.Length - 1)
                {
                    index = index - numbers.Length;
                }
            }

            return counter;
        }
    }
}
