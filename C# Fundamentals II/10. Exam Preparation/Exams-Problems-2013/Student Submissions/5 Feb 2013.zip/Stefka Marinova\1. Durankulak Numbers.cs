using System;
using System.Numerics;

class DurankulakNumbers
{
    static void Main()
    {
        string dnum = Console.ReadLine();
        char char96 = (char)96;

        int len = 0;
        BigInteger dec = 0;
        BigInteger pow = 1;
        string last = "";


        
        while ((len = dnum.Length) > 0)
        {
            if (len > 1)
            {
                last = dnum.Substring(len - 2);
                if (last[0] > 'Z')
                {
                    // small letter
                    dec += (((int)last[0] - char96) * 26 + (last[1] - 'A')) * pow;
                   // Console.WriteLine((((int)last[0] - char96) * 26 + (last[1] - 'A')) * pow);
                    dnum = dnum.Remove(len - 2);
                }
                else
                {
                    // capital letter
                    dec += (last[1] - 'A') * pow;
                    //Console.WriteLine((last[1] - 'A') * pow);
                    dnum = dnum.Remove(len - 1);
                }
            }
            else
            {
                dec += (dnum[0] - 'A') * pow;
                //Console.WriteLine(pow);
                //Console.WriteLine((dnum[0] - 'A') * pow);
                dnum = "";
            }
            pow *= 168;
        }

        Console.WriteLine(dec);
    }
}
