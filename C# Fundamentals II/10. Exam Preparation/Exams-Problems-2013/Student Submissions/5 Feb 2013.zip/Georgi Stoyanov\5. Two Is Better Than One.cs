using System;
using System.Linq;

class Problem5
{
    static void Main()
    {
        ulong[] input1 = Console.ReadLine().Split(' ').Select(h => ulong.Parse(h)).ToArray();
        //int[] input2 = {10,9,8,7,6,5,4,3,2,1};
        //int input3 = 39;
        int[] input2 = Console.ReadLine().Split(',').Select(h => int.Parse(h)).ToArray();
        int input3 = int.Parse(Console.ReadLine());
        int answer = 0;
        string number = "";
        string check = "";
        for (ulong i = input1[0]; i <= input1[1]; i++)
        {
            number = i.ToString();
            if (!(number.IndexOf('5') < 0 && number.IndexOf('3') < 0) )
            {
                check = string.Empty;
                for (int x = number.Length - 1; x >= 0; x--)
                {
                    check = check + number[x];
                }
                if (number == check)
                {
                    answer++;
                }
            }
        }

        Array.Sort(input2);

        Console.WriteLine(answer);
               
            Console.WriteLine(input2[(int)((((decimal)input3 / (decimal)100) * (decimal)input2.Length))]);
        
        
    }
}