using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Numerics;

class Program
{
    static void Main()
    {
        string s = Console.ReadLine();
        List<string> ns = new List<string>();
        StringBuilder curr = new StringBuilder();
        BigInteger n = 0;
        for (int i = 0; i < s.Length; i++)
        {
            if (s[i] >= 'a' && s[i] <= 'z')
            {
                curr.Append(s[i]);
            }
            else
            {
                curr.Append(s[i]);
                //Console.WriteLine(curr.ToString());
                ns.Add(curr.ToString());
                curr.Clear();
            }
        }

        for (int i = ns.Count - 1, j = 0; i >= 0; i--, j++)
        {
            if (ns[i].Length == 1)
            {
                n += (ns[i][0] - 'A') * (long)Math.Pow(168, j);
            }
            else
            {
                long num = (ns[i][0] - 'a' + 1) * 26 + (ns[i][1] - 'A');
                n += num * (long)Math.Pow(168, j);
            }
        }

        Console.WriteLine(n);

    }
}