using System;
using System.Collections.Generic;
using System.Text;

class TwoIsBetterTahnOne
{
    static void Main()
    {
        string strNumbers = Console.ReadLine();

        string taskTwoDigit = Console.ReadLine();
        string strPercentile = Console.ReadLine();

        
        string[] array = strNumbers.Split(' ');
        ulong[] newTemp = new ulong[array.Length];

        int counter = 0;

        for (int i = 0; i < array.Length; i++)
        {
            newTemp[i] = ulong.Parse(array[i]);
        }

        ulong numberCount = newTemp[0];

        ulong[] newNumArr = new ulong[newTemp[1]];

        for (ulong i = newTemp[0]; i < (ulong)newNumArr.Length; i++)
        {
            newNumArr[numberCount] = (ulong)(i + 1);
            numberCount++;
        }

        for (int i = 0; i < newNumArr.Length; i++)
        {
            if (newNumArr[i] == 3)
            {
                counter++;
            }
            else if (newNumArr[i] == 5)
            {
                counter++;
            }
            else if (newNumArr[i] == 33)
            {
                counter++;
            }
            else if (newNumArr[i] == 55)
            {
                counter++;
            }
            else
            {
                string temp = newNumArr[i].ToString();
                bool isEqual = false;

                for (int j = 0; j < temp.Length; j++)
                {
                    if (temp[j] == '3' ^ temp[j] == '5')
                    {
                        isEqual = true;
                    }
                    else
                    {
                        isEqual = false;
                    }
                }

                if (isEqual == true)
                {
                    bool isSymmetric = true;

                    if (temp.Length > 3)
                    {
                        for (int k = 0; k < temp.Length / 2; i++)
                        {
                            if (temp[i] != temp[temp.Length - i - 1])
                            {
                                isSymmetric = false;
                            }
                        }

                        if (isSymmetric == true)
                        {
                            counter++;
                        }                        
                    }

                }
            }
        }
        Console.WriteLine(counter);


        string[] tArray = taskTwoDigit.Split(',');
        int[] numbers = new int[tArray.Length];

        for (int i = 0; i < tArray.Length; i++)
        {
            numbers[i] = int.Parse(tArray[i]);
        }

        double percentile = double.Parse(strPercentile);
        percentile = percentile / 100;

        double minLimit = tArray.Length * percentile;
        int limit = (int)Math.Round(minLimit);

        Array.Sort(numbers);

        Console.WriteLine(numbers[limit - 1]);
    }

}
