using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class DurankulakNumbers
{
    static List<int> result = new List<int>();

    static void Main()
    {
        string numbers = Console.ReadLine();
        //ABC aA dC
        //A = 65
        //a = 97
        
        int lastIndex = 0;
        for (int i = lastIndex; i < numbers.Length; i++)
        {
            if ((int)numbers[i] > 64)
            {
                ExtractNumber(numbers, lastIndex, i);
                lastIndex = i + 1;
                i = lastIndex;
            }
            else
            {
                continue;
            }
        }

        GetResult(result);
    }

    private static void ExtractNumber(string numbers, int firstIndex, int lastIndex)
    {
        int num;
        char firstLetter;
        char secondLetter;
        if ((int)numbers[firstIndex] > 96)
        {
            if (lastIndex - firstIndex == 1)
            {
                firstLetter = numbers[firstIndex];
                secondLetter = numbers[lastIndex];
                num = ((int)firstLetter - 96) * 26 + (int)secondLetter - 65;  
            }
            else
            {
                firstLetter = numbers[firstIndex];
                secondLetter = numbers[lastIndex + 1];
                num = ((int)firstLetter - 96) * 26 + (int)secondLetter - 65;
            }
            
        }
        else
        {
            firstLetter = numbers[firstIndex];
            num = (int)firstLetter - 65;
        }
        result.Add(num);
    }

    //private static void GetResult(List<int> list)
    //{
    //    double num = 0;
    //    if (list.Count == 1)
    //    {
    //        for (int i = 0; i < list.Count; i++)
    //        {
    //            num = list[i] + 168 * i;
    //        }
    //    }
    //    else
    //    {
    //        //list.Reverse();
    //        double multiplier = list[list.Count - 2];
    //        for (int i = 1; i < list.Count; i++)
    //        {
    //            num = list[i] + 168 * multiplier;
    //            multiplier = list[list.Count - i - 1];
    //        }
             
    //    }
    //    Console.Write(num);
    //}

    private static void GetResult(List<int> list)
    {
        double num = 0;
        if (list.Count == 1)
        {
            for (int i = 0; i < list.Count; i++)
            {
                num = list[i] + 168 * i;
            }
        }
        else
        {
            double multiplier = list[0];
            for (int i = 1; i < list.Count; i++)
            {
                num = list[i] + 168 * multiplier;
                multiplier=list[i];
            }

        }
        Console.WriteLine(num);
    }
}
