using System;
using System.Collections.Generic;
using System.Linq;

class LuckyNumbers
{
    public static bool IsPalindromic(ulong n)
    {
        bool check = false;
        string num = n.ToString();
        int l = num.Length;
        if (l==1)
        {
            if((num[0]=='3')||(num[0]=='5'))
            {
                check = true;
            }
        }
        if (l > 1)
        {
            for (int digit = 0; digit < l - 1; digit++)
            {
                if ((num[0] == '3') && (num[digit] == num[digit + 1]))
                {
                    check = true;
                }
                else if ((num[0] == '5') && (num[digit] == num[digit + 1]))
                {
                    check = true;
                }
                else
                {
                    check = false;
                }
            }
        }
        return check;
    }

    public static void Main()
    {
        string inputStr = Console.ReadLine();
        char[] empty = new char[] { ' ' };
        string[] inputStrArr = inputStr.Split(empty, StringSplitOptions.RemoveEmptyEntries);

        string inputList = Console.ReadLine();
        char[] sep = new char[] { ' ', ',' };
        string[] inputStrList = inputList.Split(sep, StringSplitOptions.RemoveEmptyEntries);
        int p = int.Parse(Console.ReadLine());

        ulong a = ulong.Parse(inputStrArr[0]);
        ulong b = ulong.Parse(inputStrArr[1]);
        ulong counter = 0;
        ulong n = a;
        while (n <= b)
        {
            if (IsPalindromic(n))
            {
                counter++;
            }
            n++;
        }
        Console.WriteLine(counter);
    }
}