using System;
using System.Numerics;

class Program
{
    static void Main()
    {
        string line1 = Console.ReadLine();
        string[] numbers = line1.Split(' ');
        string word = "";
        int index = 0;
        BigInteger A, B;
        int numberDigitA = 0, numberDigitB = 0, counter = 0;
        A = BigInteger.Parse(numbers[0]);
        B = BigInteger.Parse(numbers[1]);
        numberDigitA = numbers[0].Length;
        numberDigitB = numbers[1].Length;

        string three = "", five = "";
        for (int i = 0; i < numberDigitA; i++)
        {
            three += "3";
        }
        if (BigInteger.Parse(three) > A)
        {
            A = BigInteger.Parse(three);
        }
        for (int i = 0; i < numberDigitB; i++)
        {
            five += "5";
        }
        if (BigInteger.Parse(five) < B)
        {
            B = BigInteger.Parse(five);
        }

        for (BigInteger i = A; i <= B; i++)
        {
            word = Convert.ToString(i);
            for (int j = 0; j < word.Length; j++)
            {
                if (word[j] == '3' || word[j] == '5')
                {
                    if (j == word.Length - 1)
                    {
                        while (index < word.Length / 2 + 1)
                        {
                            if (word[index] != word[word.Length - 1 - index])
                            {
                                break;
                            }
                            index++;
                        }
                        if (index == word.Length / 2 + 1)
                        {
                            counter++;
                        }
                        index = 0;
                    }
                    continue;
                }
                else
                {
                    break;
                }
            }
        }  

        string digits = Console.ReadLine();
        string[] separatedDigits = digits.Split(',');
        int[] intdigits = new int[separatedDigits.Length];
        byte percentage = byte.Parse(Console.ReadLine());
        double index1 = 0;
        for (int i = 0; i < separatedDigits.Length; i++)
        {
            intdigits[i] = int.Parse(separatedDigits[i]);
        }
        Array.Sort(intdigits);
        index1 = intdigits.Length * percentage / (double)100;
        if (index1 - Math.Truncate(index1) == 0)
        {
            index1 -= 1;
        }
        else
        {
            index1 = Math.Truncate(index1);
        }

        Console.WriteLine(counter);
        Console.WriteLine(intdigits[Convert.ToInt32(index1)]);
        
    }
}
