using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02.Task2
{
    class Task2
    {
        static void Main(string[] args)
        {
            //"1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0";
            string sequence = Console.ReadLine();//"1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0";//"1, -2, -3, 4, -5, 6, -7, -8";
            
            string[] splitedSequence = sequence.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            int[] numbers=new int[splitedSequence.Length];
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = int.Parse(splitedSequence[i]);
            }

            bool isEqual = false;
            for (int j = 0; j < numbers.Length-1; j++)
            {
                if (numbers[j]!=numbers[j+1])
                {
                    isEqual = false;
                }
                else
                {
                    isEqual = true;
                }
            }
            if (isEqual==true)
            {
                Console.WriteLine(1);
                return;
            }
           
            //for (int i = 0; i < numbers.Length; i++)
            //{
            //    Console.WriteLine(numbers[i]); 
            //}
            int[] copy = new int[numbers.Length];


            for (int i = 0; i < numbers.Length; i++)
            {
                copy[i] = numbers[i];
            }
            Array.Sort(copy);
          
            int maxLength = 0;
            int counter = 0;
            int currentNumber = 0;
            int startPosition = 0;
            int currentStep = 0;
            int lastPosition = numbers.Length - 1;
            int firstBigger = 0;
           
            //for (int i = 0; i < numbers.Length; i++)
            //{
            //    int j = 0;
            //    visited[i] = true;
            //    counter = 1;
            //    startPosition = i;
            //    currentNumber = numbers[i];
            //    currentStep = 0;
            //    int k = 0;
            //    if (i != 0)
            //    {
            //        lastPosition = startPosition - 1;
            //    }
            //    while (k < lastPosition)
            //    {
            //        if (currentNumber < numbers[k])
            //        {
            //            currentStep = k;
            //            firstBigger = numbers[k];
            //            break;
            //        }
            //        k++;
            //    }
            //    for (int s = 0; s < numbers.Length; s++)
            //    {

            //        //while (j<lastPosition)
            //        // {

            //        if (currentNumber < numbers[currentStep])
            //        {
            //            if (visited[currentStep] == false)
            //            {
            //                currentNumber = numbers[currentStep];
            //                counter++;
            //                //currentStep=j
            //                visited[j] = true;

            //            }

            //        }

            //        currentStep += currentStep;


            //        if (i != 0)
            //        {
            //            if (currentStep >= numbers.Length - 1)
            //            {
            //                currentStep = currentStep;
            //            }
            //        }
            //        //  }
            //    }
            //    if (counter >= maxLength)
            //    {
            //        maxLength = counter;
            //    }
            //    //  lastPosition = startPosition;//na starata startova poziciq

            //}

          //  counter = 0;
           // Console.WriteLine("The counter is {0} ",maxLength);
            //for (int i = 0; i < visited.Length; i++)
            //{
            //    if (visited[i]==true)
            //    {
            //        counter++;
            //    }
            //}
            //Console.WriteLine(counter);



            for (int i = 0; i < numbers.Length; i++)
            {
                bool[] visited = new bool[numbers.Length];
                currentNumber = numbers[i];
                counter = 1;
                visited[i] = true;
                startPosition = i;
                if (i != 0)
                {
                    lastPosition = startPosition - 1;
                }
                int k = i;
                currentStep = 0;
                int newPos = 0;
                while (true)
                {
                    int newPos2 = Array.BinarySearch(copy, currentNumber);
                    if (newPos2 == copy.Length - 1)
                    {
                        Console.WriteLine(maxLength+1);
                        return;
                       // newPos2 = copy.Length - newPos2;
                    }
                    else
                    {
                        firstBigger = copy[newPos2 + 1];
                    }

                    newPos = 0;
                    for (int l = 0; l < numbers.Length; l++)
                    {
                        if (numbers[l] == firstBigger)
                        {
                            newPos = l;
                            break;
                        }
                    }
                    //if (newPos+i>numbers.Length-1)
                    //{
                         currentStep = numbers.Length - i + newPos;
                    //}
                    //else
                    //{
                       // currentStep = i + newPos;
                    //}
                    break;
                    //if (currentNumber < numbers[k])
                    //{
                    //    // currentStep ++;
                    //    firstBigger = numbers[k];
                    //    currentNumber = firstBigger;
                    //    counter++;
                    //    visited[k] = true;
                    //    break;
                    //}
                    //k++;
                    //currentStep++;
                    //if (k == numbers.Length - 1)
                    //{
                    //    k = 0;
                    //}
                    //if (k == startPosition)
                    //{
                    //    break;
                    //}
                }

                int j = newPos;
                while (true)
                {
                    
                    if (j >= numbers.Length)
                    {
                        j = j - numbers.Length;
                    }
                    if ((currentNumber < numbers[j]) && (visited[j] == false))
                    {
                        counter++;
                        currentNumber = numbers[j];
                        visited[j] = true;
                    }
                    else
                    {
                        break;
                    }
                    j = j + currentStep;

                }

                if (counter>maxLength)
                {
                    maxLength = counter;
                }
            }
            Console.WriteLine(maxLength+1);
        }
    }
}
