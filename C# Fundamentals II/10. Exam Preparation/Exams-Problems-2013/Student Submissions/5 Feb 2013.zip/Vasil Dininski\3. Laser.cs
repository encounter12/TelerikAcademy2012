using System;

class Program
{
    public static bool[, ,] cube;
    public static int endW, endH, endD;

    private static void StartBouncing(int startW, int startH, int startD, int dirW, int dirH, int dirD)
    {
        int posW = startW;
        int posH = startH;
        int posD = startD;

        bool chW = false, chH = false, chD = false;
        while (!cube[posW, posH, posD])
        {
            chD = false;
            chW = false;
            chH = false;
            cube[posW, posH, posD] = true;
            if (posW + dirW == cube.GetLength(0) - 1 || posW + dirW == 0)
            {
                dirW = -dirW;
                chW = true;
            }
            if (posH + dirH == cube.GetLength(1) - 1 || posH + dirH == 0)
            {
                dirH = -dirH;
                chH = true;
            }
            if (posD + dirD == cube.GetLength(2) - 1 || posD + dirD == 0)
            {
                dirD = -dirD;
                chD = true;
            }

            posW += dirW;
            posD += dirD;
            posH += dirH;
        }
       

        endH = posH - dirH;
        endW = posW - dirW;
        endD = posD - dirD;
    }

    static void Main(string[] args)
    {
        string[] dimensions = Console.ReadLine().Split();
        int width = int.Parse(dimensions[0]);
        int height = int.Parse(dimensions[1]);
        int depth = int.Parse(dimensions[2]);
        string[] startPositions = Console.ReadLine().Split();
        int startW = int.Parse(startPositions[0]);
        int startH = int.Parse(startPositions[1]);
        int startD = int.Parse(startPositions[2]);
        string[] directions = Console.ReadLine().Split();
        int dirW = int.Parse(directions[0]);
        int dirH = int.Parse(directions[1]);
        int dirD = int.Parse(directions[2]);

        cube = new bool[width, height, depth];

        StartBouncing(startW, startH, startD, dirW, dirH, dirD);

        Console.WriteLine("{0} {1} {2}", endW, endH, endD);
    }


}