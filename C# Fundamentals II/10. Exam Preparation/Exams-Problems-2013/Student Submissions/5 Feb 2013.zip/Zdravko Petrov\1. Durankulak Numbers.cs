using System;
using System.Collections.Generic;

class Durankulak
{
    static ulong ConvertToDecimal(string digit) 
    {
        ulong converted = 0;
        for (int i = 0; i < digit.Length; i++)
        {
            if (digit[i]<=90)
            {
                converted += (ulong)(digit[i] - 65);
            }
            else
            {
                converted += (ulong)(26 * (digit[i] - 96));
            }
        }
        return converted;
    }
    static ulong AddValue(string digit, int power) 
    {
        return ConvertToDecimal(digit) * GetPowerOfBase(power);
    }
    static ulong GetPowerOfBase(int power)
    {
        ulong returnThis = 1;
        if (power==0)
        {
            return 1;
        }
        else
        {
            for (int i = 0; i < power; i++)
            {
                returnThis *= 168;
            }
            return returnThis;
        }
    }

    static void Main()
    {
        string durankulakNumber = Console.ReadLine();
        List<string> digits = new List<string>();
        for (int i = 0;; i++)
        {
            if (i >= durankulakNumber.Length)
            {
                break;
            }
            if (durankulakNumber[i]<=90)
            {
                digits.Add(new string(durankulakNumber[i],1));
            }
            else
            {
                digits.Add(new string(durankulakNumber[i], 1)+new string(durankulakNumber[i+1],1));
                i++;
            }
        }
        ulong toDecimal=0;
        int power = 0;
        for (int i = digits.Count-1; i >=0; i--)
        {
            toDecimal += AddValue(digits[i], power);
            power++;
        }
        Console.WriteLine(toDecimal);
    }
}
