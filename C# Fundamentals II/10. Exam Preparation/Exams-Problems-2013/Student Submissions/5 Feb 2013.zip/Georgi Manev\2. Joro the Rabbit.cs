using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
class JoroTheRabbit
{
    static void Main()
    {
        string input = Console.ReadLine();
        List<int> inputCollection = new List<int>();
        string[] cells = input.Split(',');
        int tempInt, temp, index, step = 0, maxLenght = 0, maxTempLenght = 0, minElement = 0, counter = 0;
 
        for (int i = 0; i < cells.Length; i++)
        {
            tempInt = int.Parse(cells[i]);
            inputCollection.Add(tempInt);
        }
 
        for (int i = 0; i < inputCollection.Count; i++)
        {
            RotateList(inputCollection);
            for (int k = 0; k < inputCollection.Count; k++)
            {
                step++;
                for (int j = 0; j < inputCollection.Count - step; j = j + step)
                {
                    if (inputCollection[j] < inputCollection[j + step])
                    {
                        counter++;
                        if (counter > maxTempLenght)
                        {
                            maxTempLenght = counter;
                        }
                        if ((counter > 0) && (inputCollection[j] >= inputCollection[j + step]))
                        {
                            break;
                        }
                    }
                }
 
                if (maxTempLenght > maxLenght)
                {
                    maxLenght = maxTempLenght;
                }
                maxTempLenght = 0;
                counter = 0;
            }
        }
        Console.WriteLine(maxLenght + 1);
    }
 
    static List<int> RotateList(List<int> inputCollection)
    {
        int arrayLast = inputCollection[0];
 
        for (int j = 0; j < inputCollection.Count - 1; j++)
        {
            inputCollection[j] = inputCollection[j + 1];
        }
 
        inputCollection[inputCollection.Count - 1] = arrayLast;
 
        return inputCollection;
    }
}