using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam4
{
    class Exam4
    {
        static int jumpsMax = 0;
        static void Main(string[] args)
        {
            string a = Console.ReadLine();
            string[] aa = a.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int[] array = new int[aa.Length];

            for (int i = 0; i < aa.Length; i++)
            {
                array[i] = int.Parse(aa[i]);
            }
            Function(array);
            Console.WriteLine(jumpsMax+1);

        }

        private static void Function(int[] array)
        {
            
            
            for (int i = 0; i < array.Length; i++)
            {
                for (int k = 1; k < array.Length; k++)
                {
                    int lastJump = array[i];               
                    int jumpCounter = 0;
                    int jump=i ;
                    bool[] checkArray = new bool[array.Length];
                    while (true)
                    {
                        jump += k;                         
                        if (jump < array.Length)
                        {
                            if ((checkArray[jump] == false)&&(array[jump]>lastJump))
                            {
                                checkArray[jump] = true;
                                jumpCounter++;
                                lastJump = array[jump];
                            }
                            else
                            {
                                if (jumpsMax<jumpCounter)
                                {
                                    jumpsMax = jumpCounter;
                                }
                                break;
                            }

                        }
                        else
                        {
                            jump = jump - array.Length;
                            if ((checkArray[jump] == false) && (array[jump] > lastJump))
                            {
                                checkArray[jump] = true;
                                jumpCounter++;
                                lastJump = array[jump];
                            }
                            else
                            {
                                if (jumpsMax < jumpCounter)
                                {
                                    jumpsMax = jumpCounter;
                                }
                                break;
                            }
                        }
                        
                    }
                }
            }
            
        }
    }
}
