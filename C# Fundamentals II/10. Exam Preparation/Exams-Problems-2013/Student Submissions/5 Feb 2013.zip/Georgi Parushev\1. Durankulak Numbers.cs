using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class Program01
{
    static void Main()
    {
        string input = Console.ReadLine();
        List<int> durankulakDigits = new List<int>();
        for (int i = 0; i < input.Length; i++)
        {
            int nextDigit = 0;
            if (input[i] >= 'a')
            {
                nextDigit = 26 * (input[i++] - 'a' + 1);
            }
            nextDigit += input[i] - 'A';
            durankulakDigits.Add(nextDigit);
        }
        BigInteger Output = 0;
        for (int i = 0; i < durankulakDigits.Count; i++)
        {
            Output *= 168;
            Output += durankulakDigits[i];
        }
        Console.WriteLine(Output);
    }
}
