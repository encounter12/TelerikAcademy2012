using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        string terrain = Console.ReadLine();
        string[] separators = { ", " };
        string[] cells = terrain.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        int[] numbers = new int[cells.Length];
        for (int i = 0; i < cells.Length; i++)
        {
            numbers[i] = int.Parse(cells[i]);
        }
       

        int count = 1;
        int maxCount = 1;
        List<int> used = new List<int>();
        List<int> positions = new List<int>();


        //Console.WriteLine(GetIndex(numbers.Min(), numbers));
        for (int step = 1; step <= numbers.Length; step++) //steps
        {
            for (int startPosition = 0; startPosition < numbers.Length; startPosition++)
            {
                for (int position = startPosition; position < numbers.Length; position += step, position %= numbers.Length)
                {
                    int stepIn = position + step;
                    if (stepIn >= numbers.Length)
                    {
                        stepIn =  stepIn % numbers.Length;
                    }

                    if (numbers[position] < numbers[stepIn])
                    {
                        if (!used.Contains(numbers[position]))
                        {
                            used.Add(numbers[position]);
                            count++;
                            if (count > maxCount)
                            {
                                maxCount = count;
                            }
                        }

                        else
                        {
                            count = 1;
                            maxCount = 1;
                            used.Clear();
                            break;
                        }
                    }

                    else
                    {
                        count = 1;
                       // maxCount = 1;
                        used.Clear();
                        break;
                    }
                }
            }
        }
        Console.WriteLine(maxCount);
        }

}
