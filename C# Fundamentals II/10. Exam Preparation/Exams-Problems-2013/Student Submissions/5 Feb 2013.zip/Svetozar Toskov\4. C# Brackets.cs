using System;
using System.IO;
using System.Linq;
using System.Text;
 
namespace EX04CSharpBrackets
{
	class EX04CSharpBrackets
	{
		private static void AppendIndent(StringBuilder formatedCode, string indentChars, int indentCount)
		{
			for (int indent = 0; indent < indentCount; indent++)
			{
				formatedCode.Append(indentChars);
			}
		}
 
		static void Main()
		{
//			string inputText = @"12
//...
//us
//{
//class Program 
//{
//static string separators 
//= new string[] 
//{
//""    ""   
//}
//;   
//}
//}";
//			StringReader input = new StringReader(inputText);
//			Console.SetIn(input);
			int linesCount = int.Parse(Console.ReadLine());
			string indentChars = Console.ReadLine();
             
			StringBuilder codeText = new StringBuilder();
 
			for (int i = 0; i < linesCount; i++)
			{
				codeText.AppendLine(Console.ReadLine());
			}
 
			StringBuilder formatedCode = new StringBuilder();
			bool hasWhiteSpace = false;
			bool hasNewLine = false;
			bool isBegginingOfLIne = false;
			bool isEndOfBlock = false;
			int indentIndex = 0;
			bool isInString = false;
 
			for (int i = 0; i < codeText.Length; i++)
			{
				if (codeText[i] == '\t')
				{
					continue;
				}
 
				if (codeText[i] == '{')
				{
					if (i != 0)
					{
						formatedCode.AppendLine();
					}
					hasNewLine = false;
					isEndOfBlock = true;
					isBegginingOfLIne = true;
					AppendIndent(formatedCode, indentChars, indentIndex);
					formatedCode.AppendLine("{");
					indentIndex++;
					continue;
				}
                 
				if (codeText[i] == '}')
				{
					indentIndex--;
					hasNewLine = false;
					isBegginingOfLIne = true;
					if (!hasNewLine && !isEndOfBlock)
					{
						formatedCode.AppendLine();                     
					}
					AppendIndent(formatedCode, indentChars, indentIndex);
					formatedCode.AppendLine("}");  
					isEndOfBlock = true;
					continue;
				}
                 
				if (codeText[i] == ' ' && isInString)
				{
					formatedCode.Append(" ");  
					continue;
				}
 
				if (codeText[i] == ' ' && !hasWhiteSpace)
				{
					hasWhiteSpace = true;
					continue;
				}
 
				if (codeText[i] == '\n' || codeText[i] == '\r')
				{
					hasNewLine = true;
					continue;
				}
 
				if (codeText[i] == '\"')
				{
					isInString = !isInString;
				}
                 
				if (codeText[i] != ' ')
				{
					isEndOfBlock = false;
 
					if (hasWhiteSpace)
					{
						formatedCode.Append(" ");  
					}
 
					if (hasNewLine && !isBegginingOfLIne)
					{
						formatedCode.AppendLine();
						hasNewLine = false;
						isBegginingOfLIne = true;
					}
 
					if (isBegginingOfLIne)
					{
						AppendIndent(formatedCode, indentChars, indentIndex);
						isBegginingOfLIne = false;
						hasNewLine = false;
					}
                     
					hasWhiteSpace = false;
					formatedCode.Append(codeText[i].ToString());                   
				}
			}
			
			string[] lines = formatedCode.ToString().Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
			foreach (string line in lines)
			{
				Console.WriteLine(line.Trim());
				//Console.Write(Environment.NewLine);
			}

			//Console.Write(formatedCode.ToString());
		}
	}
}