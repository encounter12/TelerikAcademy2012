using System;
using System.Collections.Generic;
 
 
    class Program
    {
        static void Main()
        {
            string input = Console.ReadLine();
            string[] chars = input.Split(',');
            int[] list = new int[chars.Length];
            int[] sorted = new int[chars.Length];
            for (int i = 0; i < chars.Length; i++)
            {
                list[i] = (int.Parse(chars[i]));
                //sorted[i] = (int.Parse(chars[i]));
            }
 
            Array.Copy(list, sorted, list.Length);
            //1, -2, -3, 4, -5, 6, -7, -8
            Array.Sort(sorted);
            int start = sorted[0];
            int bestPath = 0;
            for (int i = 0; i < sorted.Length/4; i++)
            {
                for (int step = list.Length - 1; step > 3; step--)
                {
                    int path = CountLength(start, step, list);
                    if (path > bestPath)
                    {
                        bestPath = path;
                    }
                     
                }
                start = sorted[i];
            }
  
            Console.WriteLine(bestPath+1);
        }
 
        private static int CountLength(int start, int step, int[] list)
        {
            int ctr = 0;
            bool[] isVisited = new bool[list.Length];
            int first =  Array.IndexOf(list, start);
            int next = step + first - list.Length;
            while (true)
            {
                if (next < 0)
                {
                    next = step + first;
                }
                if (next > list.Length)
                {
                    next = next - list.Length;
                }
                if ((list[first] < list[next]) && isVisited[next] == false)
                {
                    ctr++;
                    isVisited[next] = true;
                    first = next;
                    next = step + first - list.Length;
                }
                else
                {
                    break;
                }
            }
            return ctr;
        }   
    }