using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DurankulakNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine();
            double result = 0;
            int count = 0;
            for (int i = str.Length - 1; i >= 0; i--)
            {

                if ((str[i]) == 'a')
                {
                    if (count == 2)
                        result += 26 * 168;
                    else
                    {
                        if (count > 2)
                            result += 26 * (168 * 168);
                        else
                            result += 26;
                    }
                }
                if ((str[i]) == 'b')
                {
                    if (count == 2)
                        result += 52 * 168;
                    else
                    {
                        if (count > 2)
                            result += 52 * (168 * 168);
                        else
                            result += 52;
                    }
                   
                }
                if ((str[i]) == 'c')
                {
                    if (count == 2)
                        result += 78 * 168;
                    else
                    {
                        if (count > 2)
                            result += 78 * (168 * 168);
                        else
                            result += 78;
                    }
                    
                }
                if ((str[i]) == 'd')
                {
                    if (count == 2)
                        result += 104 * 168;
                    else
                    {
                        if (count > 2)
                            result += 104 * (168 * 168);
                        else
                            result += 104;
                    }
                }
                if ((str[i]) == 'e')
                {
                    if (count == 2)
                        result += 130 * 168;
                    else
                    {
                        if (count > 2)
                            result += 130 * (168 * 168);
                        else
                            result += 130;
                    }
                }
                if ((str[i]) == 'f')
                {
                    if (count == 2)
                        result += 156 * 168;
                    else
                    {
                        if (count > 2)
                            result += 156 * (168 * 168);
                        else
                            result += 156;
                    }
                }
                switch (str[i])
                {
                    case 'A':
                        if (count == 2)
                        {
                            result += 0 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 0 * (168 * 168);
                            else
                                result += 0;
                        }
                        break;

                    case 'B':
                        if (count == 2)
                        {
                            result += 1 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 1 * (168 * 168);
                            else
                                result += 1;
                        }
                        break;

                    case 'C': if (count == 2)
                        {
                            result += 2 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 2 * (168 * 168);
                            else
                                result += 2;
                        }
                        break;

                    case 'D': if (count == 2)
                            {
                                result += 3 * 168;
                            }
                            else
                             {
                            if (count > 2)
                                result += 3 * (168 * 168);
                            else
                                result += 3;
                             }
                        break;

                    case 'E': if (count >= 2)
                        {
                            result += 4 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 4 * (168 * 168);
                            else
                                result += 4;
                        }
                        break;
                    case 'F': if (count == 2)
                        {
                            result += 5 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 5 * (168 * 168);
                            else
                                result += 5;
                        }
                        break;

                    case 'G': if (count == 2)
                        {
                            result += 6 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 6 * (168 * 168);
                            else
                                result += 6;
                        }
                        break;

                    case 'H': if (count == 2)
                        {
                            result += 7 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 7 * Math.Pow(168, count);
                            else
                                result += 7;
                        }
                        break;

                    case 'I': if (count == 2)
                        {
                            result += 8 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 8 * Math.Pow(168, count);
                            else
                                result += 8;
                        }
                        break;

                    case 'J': if (count == 2)
                        {
                            result += 9 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 9 * (168 * 168);
                            else
                                result += 9;
                        }
                        break;

                    case 'K': if (count == 2)
                        {
                            result += 10* 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 10 * (168 * 168);
                            else
                                result += 10;
                        }
                        break;

                    case 'L': if (count == 2)
                        {
                            result += 11 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 11 * Math.Pow(168, count);
                            else
                                result += 11;
                        }
                        break;

                    case 'M': if (count == 2)
                        {
                            result += 12 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 12 *Math.Pow(168, count);
                            else
                                result += 12;
                        }
                        break;

                    case 'N': if (count == 2)
                        {
                            result += 13 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 13 * Math.Pow(168, count);
                            else
                                result += 13;
                        }
                        break;

                    case 'O': if (count == 2)
                        {
                            result += 14 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 14 * Math.Pow(168, count);
                            else
                                result += 14;
                        }
                        break;

                    case 'P': if (count == 2)
                        {
                            result += 15 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 15 * Math.Pow(168, count);
                            else
                                result += 15;
                        }
                        break;

                    case 'Q': if (count == 2)
                        {
                            result += 16 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 16 * Math.Pow(168, count);
                            else
                                result += 16;
                        }
                        break;

                    case 'R': if (count == 2)
                        {
                            result += 17 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 17 * (168 * 168);
                            else
                                result += 17;
                        }
                        break;

                    case 'S': if (count == 2)
                        {
                            result += 18 * 168;
                        }
                        else  {
                            if (count > 2)
                                result += 18 * (168 * 168);
                            else
                                result += 18;
                        }
                        break;

                    case 'T': if (count == 2)
                        {
                            result += 19 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 19 * (168 * 168);
                            else
                                result += 19;
                        }
                        break;

                    case 'U': if (count == 2)
                        {
                            result += 20* 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 20 * (168 * 168);
                            else
                                result += 20;
                        }
                        break;

                    case 'V': if (count == 2)
                        {
                            result += 21 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 21 * (168 * 168);
                            else
                                result += 21;
                        }
                        break;

                    case 'W': if (count == 2)
                        {
                            result += 22 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 22 * (168 * 168);
                            else
                                result += 22;
                        }
                        break;

                    case 'X': if (count == 2)
                        {
                            result += 23 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 23 * (168 * 168);
                            else
                                result += 23;
                        }
                        break;

                    case 'Y': if (count == 2)
                        {
                            result += 24 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 24 * (168 * 168);
                            else
                                result += 24;
                        }
                        break;

                    case 'Z': if (count == 2)
                        {
                            result += 25 * 168;
                        }
                        else
                        {
                            if (count > 2)
                                result += 25 * (168 * 168);
                            else
                                result += 25;
                        }
                        break;
                }
                count++;
               
            }

            Console.WriteLine(result);
        }
    

    }
}
