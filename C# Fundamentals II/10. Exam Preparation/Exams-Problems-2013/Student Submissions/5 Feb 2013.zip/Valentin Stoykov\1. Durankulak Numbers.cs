using System;
using System.Collections.Generic;
class DurankulakNumbers
{
    static int LetterConvertDecimal(char lower, char upper)
    {
        int multiple = 6;
        switch (lower)
        {
            case 'a': multiple = 1; break;
            case 'b': multiple = 2; break;
            case 'c': multiple = 3; break;
            case 'd': multiple = 4; break;
            case 'e': multiple = 5; break;
            case 'f': multiple = 6; break;
        }
        return (upper - 'A' + multiple * 25 + multiple);
    }
 
    static void Main()
    {
        string darankulakNumber = Console.ReadLine();
        List<int> digits = new List<int>();
        for (int counter = 0, max = darankulakNumber.Length; counter < max; counter++)
        {
            if (char.IsUpper(darankulakNumber[counter]))
            {
                digits.Add(darankulakNumber[counter] - 'A');
            }
            else
            {
                digits.Add(LetterConvertDecimal(darankulakNumber[counter], darankulakNumber[counter + 1]));
                counter++;
            }
        }
        long totalSum = 0;
        long power = 1;
        for (int counter = digits.Count - 1; counter >= 0; counter--, power *= 168)
        {
            totalSum += digits[counter] * power;
        }
        Console.WriteLine(totalSum);
    }
}