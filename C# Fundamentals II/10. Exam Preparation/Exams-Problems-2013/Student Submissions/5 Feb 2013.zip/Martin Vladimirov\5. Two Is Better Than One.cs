using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer5TwoIsBetterThenOne
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] input1 = Console.ReadLine().Split(' ');
            int numb1 = int.Parse(input1[0]);
            int numb2 = int.Parse(input1[1]);
            int cnt = 0;

            for (int i = numb1; i <= numb2; i++)
            {
                string numb = i.ToString();
                bool isTrue = true;
                for (int j = 0; j < (numb.Length / 2)+1; j++)
                {
                    if (numb[j] == numb[numb.Length - 1])
                    {
                        if (numb[j] == '3' || numb[j] == '5')
                            continue;
                        else
                        {
                            isTrue = false;
                            break;
                        }
                    }
                    else
                    {
                        isTrue = false;
                        break;
                    }
                }
                if (isTrue)
                    cnt++;
            }

            string[] input2 = Console.ReadLine().Split(',');
            int[] a=new int [input2.Length];
            double pers = int.Parse(Console.ReadLine());
            pers /= 100;
            long sum = 0;
            for (int i = 0; i < input2.Length; i++)
            {
                a[i] = int.Parse(input2[i]);
                sum += a[i];
            }
            Console.WriteLine("sum =" +sum);
            Array.Sort(a);
            int maxNumb = (double)a.Length* (double)pers;
            Console.WriteLine("asdds"+maxNumb);
            int theNumberPoss=0;
            


            Console.WriteLine(cnt);
            Console.WriteLine(maxNumb);
        }
    }
}
