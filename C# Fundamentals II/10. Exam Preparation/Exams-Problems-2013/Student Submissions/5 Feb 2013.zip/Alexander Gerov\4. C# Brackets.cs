using System;
using System.Collections.Generic;
using System.Text;

namespace Brackets
{
    class Program
    {
        static string[] lines;
        static string S;

        static bool inQuotes = false;
        static bool inComment = false;

        static int openingCounter = 0;

        static StringBuilder output = new StringBuilder();

        static void AddSpaces()
        {
            for (int i = 0; i < openingCounter; i++)
            {
                output.Append(S);
            }
        }

        static void WorkOverLine(int index)
        {
            if (String.IsNullOrWhiteSpace(lines[index]))
            {
                return;
            }

            string current = lines[index].Trim();

            AddSpaces();

            for (int i = 0; i < current.Length; i++)
            {
                if (current[i] == '"')
                {
                    inQuotes = !inQuotes;
                }

                if (current[i] == '\\')
                {
                    if (i < current.Length - 1)
                    {
                        if (current[i] == '\\')
                        {
                            inComment = !inComment;
                        }
                    }
                }

                if (inQuotes)
                {
                    if (current[i] != ' ')
                    {
                        output.Append(current[i]);
                    }
                    else
                    {
                        if (current[i] != current[i + 1])
                        {
                            output.Append(current[i]);
                        }
                    }
                    continue;
                }

                if (inComment)
                {
                    if (current[i] != ' ')
                    {
                        output.Append(current[i]);
                    }
                    else
                    {
                        if (current[i] != current[i + 1])
                        {
                            output.Append(current[i]);
                        }
                    }
                    continue;
                }

                if (current[i] == '{')
                {
                    if (i == 0)
                    {
                        output.Append(current[i]);
                        openingCounter++;

                        if (i < current.Length - 1)
                        {
                            //output.Append("$");
                            output.Append("\r\n");
                            AddSpaces();
                        }
                    }
                    else if (current[i - 1] == '{')
                    {
                        output.Append(current[i]);
                        openingCounter++;

                        if (i < current.Length - 1)
                        {
                            //output.Append("$");
                            output.Append("\r\n");
                            AddSpaces();
                        }
                    }
                    else
                    {
                        //output.Append("$");
                        output.Append("\r\n");
                        AddSpaces();
                        output.Append(current[i]);
                        openingCounter++;

                        if (i < current.Length - 1)
                        {
                            //output.Append("$");
                            output.Append("\r\n");
                            AddSpaces();
                        }
                    }

                    continue;
                }

                if (current[i] == '}')
                {
                    if (i == 0)
                    {
                        output.Remove(output.Length - S.Length, S.Length); // possible error!!!
                        output.Append(current[i]);
                        openingCounter--;

                        if (i < current.Length - 1)
                        {
                            //output.Append("$");
                            output.Append("\r\n");
                            AddSpaces();
                        }
                    }
                    else if (current[i - 1] == '}')
                    {
                        output.Remove(output.Length - S.Length, S.Length); // possible error!!!
                        output.Append(current[i]);
                        openingCounter--;

                        if (i < current.Length - 1)
                        {
                            //output.Append("$");
                            output.Append("\r\n");
                            AddSpaces();
                        }
                    }
                    else
                    {
                        //output.Append("$");
                        output.Append("\r\n");
                        openingCounter--;
                        AddSpaces();
                        output.Append(current[i]);

                        if (i < current.Length - 1)
                        {
                            //output.Append("$");
                            output.Append("\r\n");
                            AddSpaces();
                        }
                    }

                    continue;
                }

                if (current[i] == ' ')
                {
                    if ((current[i - 1] == '{') || (current[i - 1] == '}') || (current[i + 1] == '{') || (current[i + 1] == '}'))
                    {
                        while (current[i + 1] == ' ')
                        {
                            i++;
                        }

                        continue;
                    }

                    if (current[i] == current[i + 1])
                    {
                        continue;
                    }
                    else
                    {
                        output.Append(current[i]);
                        continue;
                    }
                }

                if (!char.IsSeparator(current[i]))
                {
                    output.Append(current[i]);
                }
            }

            if (index < lines.Length - 1)
            {
                //output.Append("$");
                output.Append("\r\n");
            }
        }

        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            S = Console.ReadLine();

            lines = new string[N];
            for (int i = 0; i < N; i++)
            {
                lines[i] = Console.ReadLine();
            }

            //int N = 5;
            //S = "....";
            //lines = new string[] { 
            //    "using System;     namespace Stars",
            //    "{class Program{",
            //    "static string[] separators",
            //    "= new string[] {{ \" asdflnfsdle     \" \\ \" { \" hello}}     ;}     ",
            //    "}"
            //};

            for (int i = 0; i < N; i++)
            {
                WorkOverLine(i);
            }

            Console.WriteLine(output.ToString());
        }
    }
}
