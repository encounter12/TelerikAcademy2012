using System;
using System.Linq;
using System.Numerics;
using System.Text;

namespace LuckyNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputLine = Console.ReadLine();
            string[] numbers = inputLine.Split(' ');

            BigInteger valueA = BigInteger.Parse(numbers[0]);
            BigInteger valueB = BigInteger.Parse(numbers[1]);
            long happyNumbers = 0;
            for (BigInteger i = valueA; i <= valueB; i++)
            {
                string number = i.ToString();

                if (CheckDigits(number))
                {
                    if (number == Reverse(number))
                    {
                        happyNumbers++;
                    }
                }
            }

            inputLine = Console.ReadLine();
            numbers = inputLine.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int[] listNumbers = new int[numbers.Length];

            for (int i = 0; i < numbers.Length; i++)
            {
                listNumbers[i] = int.Parse(numbers[i]);
            }

            int p = int.Parse(Console.ReadLine());
            double leastElements = (((double)p / 100) * numbers.Length);
            int smallestElement = int.MaxValue;
            int counter = 0;

            for (int i = 0, index = 0; i < listNumbers.Length; index++)
            {
                int currentEl = listNumbers[i];

                if (currentEl >= listNumbers[index])
                {
                    counter++;
                }

                if (counter >= leastElements)
                {
                    if (currentEl < smallestElement)
                    {
                        smallestElement = currentEl;
                    }
                }

                if (index==listNumbers.Length-1)
                {
                    index = 0;
                    counter = 0;
                    i++;
                }

            }
            Console.WriteLine(happyNumbers);
            Console.WriteLine(smallestElement);
        }

        private static bool CheckDigits(string number)
        {
            for (int i = 0; i < number.Length; i++)
            {
                if (number[i] != '3' && number[i] != '5')
                {
                    return false;
                }
            }
            return true;
        }

        private static string Reverse(string number)
        {
            StringBuilder reversedNumber = new StringBuilder(number.Length);

            for (int i = number.Length - 1; i >= 0; i--)
            {
                reversedNumber.Append(number[i]);
            }
            return reversedNumber.ToString();
        }
    }
}
