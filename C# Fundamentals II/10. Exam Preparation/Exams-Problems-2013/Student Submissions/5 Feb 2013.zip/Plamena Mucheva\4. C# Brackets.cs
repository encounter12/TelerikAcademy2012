using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 6;
            string s = "....";
            int countLeftBracket = 0;
            int countRightBracket = 0;
            char leftBracket = '{';
            char rightBracket = '}';
            string symbols = "{,a,{,},}";
            int count = 0;
            for (int i = 0; i < n; i++)
            {
                
                for (int j = 0; j < symbols.Length; j++)
                {
                    int b = symbols[i].CompareTo(leftBracket);
                    if (b == 0)
                    {
                        countLeftBracket++;
                    }
                    int c = symbols[i].CompareTo(rightBracket);
                    if (c == 0) 
                    { 
                        countRightBracket++; 
                    }
                    count++;
                    s += s;
                }
            }
            if (countLeftBracket == countRightBracket)
            {
                Console.WriteLine(symbols);
            }
            else Console.WriteLine("Incorrect expression: " + symbols);
        }
    }
}
