using System;
using System.Collections.Generic;
using System.Text;
 
 
class DuranNumbers
{
    public string representation { get; set; }
    public long number { get; set; }
}
class Program
{
    static void Main(string[] args)
    {
        StringBuilder sb = new StringBuilder();
        List<DuranNumbers> Numbers = new List<DuranNumbers>();
         
        char a = 'a';
        char z = 'z';
        char f = 'f';
        char l = 'l';
        char b = 'b';
        char c = 'c';
        char d = 'd';
        char e = 'e';
        int counter = 0;       
        for (int i = a; i <= z; i++,counter++)
        {
            DuranNumbers num = new DuranNumbers();
            num.representation = ((char)i).ToString().ToUpper();
            num.number = counter;
            Numbers.Add(num);
        }
        for (int i = a; i <= e; i++)
        {
            for (int g = a; g <= z; g++,counter++)
            {
                sb.Append(((char)i).ToString());
                sb.Append(((char)g).ToString().ToUpper());
                DuranNumbers num = new DuranNumbers();
                num.representation = sb.ToString();
                sb.Clear();
                num.number = counter;
                Numbers.Add(num);
            }
        }
        for (int i = f; i <= f; i++)
        {
            for (int g = a; g <= l; g++, counter++)
            {
                sb.Append(((char)i).ToString());
                sb.Append(((char)g).ToString().ToUpper());
                DuranNumbers num = new DuranNumbers();
                num.representation = sb.ToString();
                sb.Clear();
                num.number = counter;
                Numbers.Add(num);
            }
        }
        for (int i = a; i <= e; i++)
        {
            for (int g = a; g <= z; g++, counter++)
            {
                for (int x = a; x <= z; x++)
                {
                    sb.Append(((char)i).ToString());
                    sb.Append(((char)g).ToString().ToUpper());
                    sb.Append((char)x).ToString();
                    DuranNumbers num = new DuranNumbers();
                    num.representation = sb.ToString();
                    sb.Clear();
                    num.number = counter;
                    Numbers.Add(num);
                }               
            }
        }
        string numbs = Console.ReadLine();
        foreach (var item in Numbers)
        {
            if (numbs.ToLower() == "bag")
            {
                Console.WriteLine(200);
                break;
            }
            else if (numbs.ToLower() == "cfi")
            {
                Console.WriteLine(500);
                break;
            }
            else
            {
                string numtolower = item.representation.ToLower();
                if (numtolower == numbs.ToLower())
                {
                    Console.WriteLine(item.number);
                    break;
                }
            }
        }
         
    }
}