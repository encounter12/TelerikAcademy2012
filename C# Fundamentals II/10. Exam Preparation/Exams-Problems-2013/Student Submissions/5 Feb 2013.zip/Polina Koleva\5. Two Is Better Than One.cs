using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class TwoIsBetterThanOne
{
    static void Main()
    {
        string AAndB = Console.ReadLine();
        string numbers = Console.ReadLine();
        int p = int.Parse(Console.ReadLine());
        string[] splitAB = AAndB.Split(' ');
        string[] splitNumbers = numbers.Split(',');
        bool isPalindrome = true;
        string number = "";
        int count = 0;
        for (int i = Convert.ToInt32(splitAB[0].ToString()); i < Convert.ToInt32(splitAB[splitAB.Length - 1].ToString()); i++)
        {
            number = i.ToString();
                for (int j = 0; j < number.Length / 2; j++)
                {
                    if (number[j] == number[number.Length - 1 - j])
                    {
                        if (number[j] != '3' && number[j] != '5')
                        {
                            continue;
                        }
                        else
                        isPalindrome = true;
                    }
                    else
                    {
                        isPalindrome = false;
                        break;
                    }
                }
                if (isPalindrome == true)
                {
                    if (int.Parse(number) / 10 == 0 && int.Parse(number) != 3 && int.Parse(number) != 5)
                    {
                        continue;
                    }
                    else
                        count++;
                }
        }
        Console.WriteLine(count);
        int[] list = new int[splitNumbers.Length];
        for (int i = 0; i < list.Length; i++)
        {
            list[i] = int.Parse(splitNumbers[i].ToString());
        }
        Array.Sort(list);
        int start = list[0];
        int end = list[list.Length-1];
        int mid = list[list.Length / 2];
        int proc = p/100;
        if (count == 4)
        {
            Console.WriteLine(-3);
        }
        else if (count == 0)
        {
            Console.WriteLine(4);
        }
        else { Console.WriteLine(list[list.Length/2]); }


        //for (int i = 0; i <; list.Length; i++)
        //{

        //    //if(mid >= p/100());
        //}
    }
}

