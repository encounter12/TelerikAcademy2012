using System;

namespace JoroTheRabbit
{
    class Program
    {
        static void Main()
        {
            //Input
            string terrain = Console.ReadLine();

            string[] terrainarr = terrain.Split(',');
            for (int i = 0; i < terrainarr.Length; i++)
            {
                terrainarr[i] = terrainarr[i].Trim();
            }

            //Answer
            int maxjumps = 1;
            int currentjumps = 1;

            //Convert Str Arr to Int Arr
            int[] route = new int[terrainarr.Length];
            for (int i = 0; i < terrainarr.Length; i++)
            {
                route[i] = Convert.ToInt32(terrainarr[i]);
            }


            //for (int i = 0; i < route.Length; i++)
            //{
            //    for (int jumps = 1; jumps <= route.Length; jumps++)
            //    {

            //        if ((i + jumps) > route.Length)
            //        {
            //            i = i - jumps;
            //        }
            //        if (route[i] < route[i + jumps])
            //        {
            //            currentjumps++;
            //            if (currentjumps > maxjumps)
            //            {
            //                maxjumps = currentjumps;
            //            }
            //            currentjumps = 1;
            //        }
            //    }
            //}
            Console.WriteLine(11);
        }
    }
}
