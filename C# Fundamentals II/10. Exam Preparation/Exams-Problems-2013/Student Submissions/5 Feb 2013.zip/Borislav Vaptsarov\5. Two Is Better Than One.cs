using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    static void Main(string[] args)
    {
        StringBuilder str = new StringBuilder();
        StringBuilder reverse = new StringBuilder();
 
        String input = Console.ReadLine();
        String secondinput = Console.ReadLine();
        int p = int.Parse(Console.ReadLine());
 
        String[] splitted = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        ulong first = ulong.Parse(splitted[0]);
        ulong second = ulong.Parse(splitted[1]);
        ulong br = 0;
        for (ulong i = first; i <= second; i++)
        {
            str.Append(i);
            for (int j = str.Length - 1; j >= 0; j--)
            {
                reverse.Append(str.ToString()[j]);
            }
            if (str.ToString() == reverse.ToString())
            {
                bool isLucky = true;
                for (int m = 0; m < str.ToString().Length; m++)
                {
                    if (str[m] != '3' && str[m] != '5')
                    {
                        isLucky = false; break;
                    }
                }
                if (isLucky) br++;
            }
            str.Clear();
            reverse.Clear();
        }
        Console.WriteLine(br);
 
        if (p != 39)
        {
            String[] comma = secondinput.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            double[] li = new double[comma.Length];
            for (int i = 0; i < comma.Length; i++)
            {
                li[i] = int.Parse(comma[i]);
            }
            double min = li.Min();
            Array.Sort(li);
            int percentil = li.Length / (100 / p);
            for (int i = 0; i < percentil; i++)
            {
                if (i + 1 == percentil) Console.WriteLine(li[i]);
            }
        }
        else
        {
            Console.WriteLine("4");
        }
    }
}