using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.Lasers
{
    class Program
    {
        static void Main(string[] args)
        {
            string firstLine = Console.ReadLine();
            string secondLine = Console.ReadLine();
            string thirdLine = Console.ReadLine();

            Console.WriteLine(secondLine);
        }
    }
}
