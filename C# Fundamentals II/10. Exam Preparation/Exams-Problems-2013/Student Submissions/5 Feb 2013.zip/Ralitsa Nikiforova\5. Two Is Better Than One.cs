using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using System.Diagnostics;

namespace TwoIsBetterThanOne
{
    class Program
    {
        public static Stopwatch stopWatch = new Stopwatch();

        public static List<BigInteger> FindPalidromes(BigInteger start, BigInteger end)
        {
            
            List<BigInteger> palindromes = new List<BigInteger>();
            //List<string> palindromesStr = new List<string>();

            for (BigInteger k = start; k <= end; k++)
            {
                //string data = k.ToString();               //converts the int value of k into sting

                if (k % 5 == 0 || k % 10 == 3)
                {



                    BigInteger num = k;
                    BigInteger rev = 0;
                    while (num > 0)
                    {
                        BigInteger dig = num % 10;
                        rev = rev * 10 + dig;
                        num = num / 10;
                    }

                    if (k == rev)
                    {
                        palindromes.Add(k);
                    }
                }
            }


            return palindromes;
            
        }

        public static void LuckyPalindrome(BigInteger a, BigInteger b)
        {

            List<BigInteger> palidromes = FindPalidromes(a, b);

            // Is palindrome lucky?

            BigInteger count = 0;
            bool isLucky = false;

            for (int i = 0; i < palidromes.Count; i++)
            {
                string currPalindrome = palidromes[i].ToString();

                for (int j = 0; j < currPalindrome.Length; j++)
                {
                    if (currPalindrome[j] != '5' && currPalindrome[j] != '3')
                    {
                        isLucky = false;
                        break;
                    }
                    else
                    {
                        isLucky = true;
                    }
                }

                if (isLucky)
                {
                    count++;
                }
            }

            Console.WriteLine(count);
            
           
        }

        static void SmallestNumber(int[] arr, int percent)
        {
            //int percent = 50;
            //int[] arr = { -2,-1,-4,-3 };

            //int percent = 39;
            //int[] arr = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
            Array.Sort(arr);

            int percentLen = (percent * arr.Length) / 100;
            if ((percent * arr.Length) % 100 > 0)
            {
                percentLen++;
            }
            int currEl = 0;
            int min = int.MaxValue;
            bool foundEl = false;
           

            for (int i = 0; i < arr.Length; i++)
            {
                currEl = arr[i];

                if (currEl > min)
                {
                    break;
                }

                for (int j = 0; j < percentLen; j++)
                {
                    if (arr[j] > currEl)
                    {
                        foundEl = false;
                        break;
                    }
                    else
                    {
                        foundEl = true;
                    }
                }

                if (foundEl)
                {
                    if (currEl <= min)
                    {
                        min = currEl;
                    }
                }


            }
            Console.WriteLine(min);
        }

        public static void Main(string[] args)
        {
            
            

            string[] range = Console.ReadLine().Split(' ');
       

            string[] arrayStr = Console.ReadLine().Split(',');
            int percent = int.Parse(Console.ReadLine());

            stopWatch.Start();

            BigInteger a = BigInteger.Parse(range[0]);
            BigInteger b = BigInteger.Parse(range[1]);
            
            int[] arr = new int[arrayStr.Length];

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = int.Parse(arrayStr[i]);
            }

            
            LuckyPalindrome(a, b);      //00:00:00.0039771
            
            stopWatch.Stop();
            //Console.WriteLine(stopWatch.Elapsed);

            SmallestNumber(arr, percent); //00:00:00.0007458

       

        }
    }
}
