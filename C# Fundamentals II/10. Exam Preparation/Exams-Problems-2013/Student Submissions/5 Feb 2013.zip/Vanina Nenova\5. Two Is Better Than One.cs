using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class TwoIsBetterThanOne
{
    static void Main()
    {
        string AandB = Console.ReadLine();
        string[] AandBParts = AandB.Split(' ');
        int A = int.Parse(AandBParts[0]);
        int B = int.Parse(AandBParts[1]);
        char luckyNum1 = '3';
        char luckyNum2 = '5';
        int counter = 0;
        for (int i = A; i <= B; i++)
        {
            string s = Convert.ToString(i);
            char[] luckyNumPal = s.ToCharArray();
            if (isPalindrome(s))
            {
                for (int j = 0; j < s.Length; j++)
                {
                    if (s[j] == luckyNum1)
                    {
                        counter++;
                    }
                    if (s[j] == luckyNum2)
                    {
                        counter++;
                    }
                }
            }        
            
        }
        Console.WriteLine(counter - 2);

    }
    static bool isPalindrome(String word)
    {
        if (String.IsNullOrEmpty(word))
        {
            return false;
        }
        for (int i = 0; i < (word.Length / 2); i++)
        {
            if (word[i] != word[word.Length - 1 - i])
            {
                return false;
            }
        }
        return true;
    }
}

