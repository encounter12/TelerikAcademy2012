using System;


namespace Ex_22
{
    class Program
    {
        static void Main()
        {
            string code;
            //string code = @"using System;   namespace Stars{class Program{static     string[] separator= new string[] {""};}";
            //string resultStr = "";
            code = Console.ReadLine();
           
            int N = Convert.ToInt32(Console.ReadLine());  
                code = code.Replace("}", "\n}\n").TrimStart();
                code = code.Replace("{", "\n{\n").TrimStart();
                code = code.Replace(";", ";\n").TrimStart();            
            Console.WriteLine(code.Trim());           
        }
    }
}
