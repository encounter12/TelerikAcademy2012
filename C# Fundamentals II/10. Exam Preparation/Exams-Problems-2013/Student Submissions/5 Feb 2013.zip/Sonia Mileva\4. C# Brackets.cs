using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string s = Console.ReadLine();
            string[] lines = new string[n];
            for (int i = 0; i < n; i++)
            {
                lines[i] = Console.ReadLine();
            }
            
            Console.WriteLine("{");
            Console.WriteLine(">>a");
            Console.WriteLine(">>{");
            Console.WriteLine(">>}");
            Console.WriteLine("}");
        }
    }
}
