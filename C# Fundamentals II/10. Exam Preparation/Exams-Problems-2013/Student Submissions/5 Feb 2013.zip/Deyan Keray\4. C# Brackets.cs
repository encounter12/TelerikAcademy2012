using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string pad = Console.ReadLine();
        StringBuilder lines = new StringBuilder();
        for (int i = 0; i < n; i++)
        {
            lines.Append(Console.ReadLine());
            lines.Append("\n");
        }
        StringBuilder result = new StringBuilder();
        int padcount = -1;
        bool newline = false;
        for (int i = 0; i < lines.Length; i++)
        {

            if (lines[i] == '{')
            {
                result.Append('\n');
                result.Append('{');
                result.Append('\n');
                newline = false;
            }
            else if (lines[i] == '}')
            {
                result.Append('\n');
                result.Append('}');
                result.Append('\n');
                newline = false;
            }
            else if (lines[i] == '\n')
            {
                result.Append('\n');
                newline = true;
            }
            else if (lines[i] == ' ' && lines[i+1] == ' ')
            {

            }
            else result.Append(lines[i]); 
          
        }
        string s = result.ToString();
        s = s.Replace("\n\n", "\n");
        s = s.Replace("\n\n", "\n");
       // Console.WriteLine(s);

        lines.Clear();

        for (int i = 0; i < s.Length; i++)
        {
            if (s[i] == '{')
            {
                padcount++;
            }
            if (s[i] == '}')
            {
                padcount -=2;
            }
            
            while (s[i] != '\n')
            {
                lines.Append(s[i]);
                i++;
            }
            lines.Append(s[i]);
            for (int y = 0; y <= padcount; y++)
            {
                lines.Append(pad);
            }

        }
        Console.WriteLine(lines.ToString());



    }
}
