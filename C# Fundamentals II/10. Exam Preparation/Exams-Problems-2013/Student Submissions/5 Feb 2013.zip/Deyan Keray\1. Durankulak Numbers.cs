using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class Durankulak
{
    static void Main()
    {
        string input = Console.ReadLine();
        int count = 0;
        BigInteger sum = 0;
        if (input.Length == 1)
        {
            Console.WriteLine(DecodeCode(input[0]));
            return;
        }
        else
        for (int i = input.Length-1; i >= 0; i--)
        {
            if (i > 0 )
                if (isCharLower(input[i - 1]))
                {
                    sum += (int)Math.Pow(168, count) * DecodeCode(input[i], input[i - 1]);
                    i--;
                }
                else sum += (int)Math.Pow(168, count) * DecodeCode(input[i]);
            else sum += (int)Math.Pow(168, count) * DecodeCode(input[i]);
            count++;
        }

        Console.WriteLine(sum);
        

    
    
    }

    static bool isCharLower(char a)
    {
        if (a >= 'a' && a <= 'z')
        {
            return true;
        }
        else return false;
    }

    static int DecodeCode(char big, char small = '9')
    {
        int row = 0;
        int col = 0;

        switch (small)
        {
            case 'a': row = 1; break;
            case 'b': row = 2; break;
            case 'c': row = 3; break;
            case 'd': row = 4; break;
            case 'e': row = 5; break;
            case 'f': row = 6; break;
            default:
                break;
        }
        switch (big)
        {
            case 'A': col = 0; break;
            case 'B': col = 1; break;
            case 'C': col = 2; break;
            case 'D': col = 3; break;
            case 'E': col = 4; break;
            case 'F': col = 5; break;
            case 'G': col = 6; break;
            case 'H': col = 7; break;
            case 'I': col = 8; break;
            case 'J': col = 9; break;
            case 'K': col = 10; break;
            case 'L': col = 11; break;
            case 'M': col = 12; break;
            case 'N': col = 13; break;
            case 'O': col = 14; break;
            case 'P': col = 15; break;
            case 'Q': col = 16; break;
            case 'R': col = 17; break;
            case 'S': col = 18; break;
            case 'T': col = 19; break;
            case 'U': col = 20; break;
            case 'V': col = 21; break;
            case 'W': col = 22; break;
            case 'X': col = 23; break;
            case 'Y': col = 24; break;
            case 'Z': col = 25; break;
            default:
                break;
        }
        return row * 26 + col;

    }
}