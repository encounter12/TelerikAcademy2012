using System;
using System.Numerics;


class DrukulakNumbers
{
    static void Main()
    {
        
           

        string numberForConvert = Console.ReadLine();

        string[] BigLetters = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        string[] SmallLetters = { "", "a", "b", "c", "d", "e", "f" };
        int indexBigLetters = 0;
        int indexSmallLetters = 0;
        BigInteger numberBig = (BigInteger)0;
        BigInteger numberSmall = (BigInteger)0;
        BigInteger result = (BigInteger)0;

        string extractedBig = ExtraxtCapitals(numberForConvert);


        for (int i = 0; i < extractedBig.Length; i++)
        {
            string currentNum = extractedBig[(extractedBig.Length - 1) - i].ToString();
            for (int k = 0; k < BigLetters.Length; k++)
            {
                if (currentNum == BigLetters[k])
                {
                    indexBigLetters = k;
                    break;
                }
            }
            numberBig += (BigInteger)((Math.Pow(168, i)) * indexBigLetters);//index *1
        }


        string extractedSmall = ExtraxtSmall(numberForConvert);
        for (int i = 0; i < extractedSmall.Length; i++)
        {
            string currentNum = extractedSmall[(extractedSmall.Length - 1) - i].ToString();
            for (int b = 0; b < SmallLetters.Length; b++)
            {
                if (currentNum == SmallLetters[b])
                {
                    indexSmallLetters = b;
                    break;
                }

            }
            numberSmall += (BigInteger)(Math.Pow(168, i) * indexSmallLetters * 26);
        }

        result = numberSmall + numberBig;

        Console.WriteLine(result);
    }

    private static string ExtraxtSmall(string numberForConvert)
    {
        string extracted = "";
        for (int i = 0; i < numberForConvert.Length; i++)
        {
            char ch = numberForConvert[i];
            if (char.IsLower(ch))
            {
                extracted += ch;
            }
        }
        return extracted;
    }
  
    private static string ExtraxtCapitals(string numberForConvert)
    {
        string extracted = "";
        for (int i = 0; i < numberForConvert.Length; i++)
        {
            char ch = numberForConvert[i];
            if (char.IsUpper(ch))
            {
                extracted += ch;
            }
        }
        return extracted;
    }
}
