using System;
using System.Linq;
using System.Text;
using System.IO;

namespace CSharpBrackets
{
    class Program
    {
        static void Main()
        {
            StringBuilder brackets = new StringBuilder();
            int linesCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < linesCount; i++)
            {
                string line = Console.ReadLine();
                for (int j = 0; j < line.Length; j++)
                {
                    if (line[j] == '{')
                    {
                        //brackets.Append("{").AppendLine();
                        brackets.AppendLine();
                        j++;
                        continue;
                    }
                    if (line[j] == '}')
                    {
                        brackets.AppendLine();
                        j++;
                        continue;
                    }
                }
            }
            StringReader sr = new StringReader(brackets.ToString());
            string lineToPrint = null;
            while ((lineToPrint = sr.ReadLine()) != null)
            {
                if (!string.IsNullOrWhiteSpace(lineToPrint))
                {
                    Console.WriteLine(lineToPrint);
                }
            }
        }
    }
}