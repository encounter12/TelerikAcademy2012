using System;

class Program
{
    static void Main()
    {
        string number = Console.ReadLine();
        ulong[] arr = new ulong[16];
        int len = number.Length;
        char[] dNums = new char[26];
        int c = 65;
        for (int i = 0; i < 26; i++)
        {
            dNums[i] = (char)c;
            c++;

        }
        for (int i = 0; i < len; i++)
        {
            for (int v = 0; v < 26; v++)
            {
                if (number[i] == dNums[v])
                {
                    arr[i] =(ulong) v;
                }
                if (number[i] == 'a')
                {
                    arr[i] = 26;
                }
                if (number[i] == 'b')
                {
                    arr[i] = 52;
                }
                if (number[i] == 'c')
                {
                    arr[i] = 78;
                }
                if (number[i] == 'd')
                {
                    arr[i] = 104;
                }
                if (number[i] == 'e')
                {
                    arr[i] = 130;
                }
                if (number[i] == 'f')
                {
                    arr[i] = 156;
                }

            }
            //  Console.WriteLine(arr[i]);
        }
        ulong[] arr2 = new ulong[len];
        for (int i = 0; i < len; i++)
        {
            arr2[len - 1 - i] = arr[i];
        }
        //for (int i = 0; i < len; i++)
        //{
        //    Console.WriteLine(arr2[i]);
        //}
        ulong sum = (ulong)arr2[0];
        ulong mult = 1;
        for (int i = 1; i < (len); i++)
        {

            if (arr2[i] > 25)
            {
                sum = sum + (arr2[i] * mult);
            }
            if (arr2[i] < 26)
            {
                mult = mult * 168;
                sum = sum + (arr2[i] * mult);
            }
        }
        Console.WriteLine(sum);
    }
}
