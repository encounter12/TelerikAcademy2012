using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace problem
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            BigInteger number=0;
            long digitCount = 1;
            BigInteger finalNumber = 0;
            while (input.Length>0)
            {
                number = input[input.Length - 1] - 65;
                if (input.Length>1&&input[input.Length - 2] >= 97 && input[input.Length - 2] <= 122)
                {
                    number=number+(input[input.Length - 2]-96)*26;
                    input = input.Remove(input.Length - 2, 2);
                }
                else
                    input = input.Remove(input.Length - 1, 1);
                number = number * digitCount;
                finalNumber = finalNumber + number;
                digitCount = digitCount * 168;
            }
            Console.WriteLine(finalNumber);
        }
    }
}
