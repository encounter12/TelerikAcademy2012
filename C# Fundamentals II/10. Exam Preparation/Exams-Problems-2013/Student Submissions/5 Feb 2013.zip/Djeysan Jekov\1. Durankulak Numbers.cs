using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{
    static string durankulakNumber;
    static long decimalNumber;

    static void Input()
    {
        durankulakNumber = Console.ReadLine();
    }

    static void PrintArray(int[] array)
    {
#if DEBUG
        for (int i = 0; i < array.Length; i++)
            Console.Write(array[i] + (i == array.Length - 1 ? "\n" : " "));
#endif
    }

    static long GetDecimalDigit(string durankulakDigit)
    {
        if (durankulakDigit.Length == 1) return (durankulakDigit[0] - 'A');
        else return (durankulakDigit[0] - 'a' + 1) * 26 + (durankulakDigit[1] - 'A');
    }

    static void Convert(string durankulakNumber)
    {
        decimalNumber = 0;


        List<string> durankulakGigits = new List<string>();

        foreach (Match digit in Regex.Matches(durankulakNumber, "[a-z]?[A-Z]"))
        {
            durankulakGigits.Add(digit.Value);
        }

        long p = 1;
        for (int i = durankulakGigits.Count - 1; i >= 0; i--, p*=168)
        {
            decimalNumber += GetDecimalDigit(durankulakGigits[i]) * p;
        }
    }

    static void Output()
    {
        Console.WriteLine(decimalNumber);
    }

    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
#endif
        Input();

        Convert(durankulakNumber);

        //Console.WriteLine(GetDecimalDigit("fA"));

        Output();
    }
}
