using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace First
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            List<string> digits = GenerateDigits(input);

            //foreach (var item in digits)
            //{
            //    Console.WriteLine(item);
            //}

            int[] numbers = GenerateNumbersFromDigits(digits);

            //foreach (var item in numbers)
            //{
            //    Console.WriteLine(item);
            //}

            BigInteger result = 0;

            for (int i = 0; i < numbers.Length; i++)
            {
                result += (BigInteger)(numbers[i] * BigInteger.Pow(168, numbers.Length - 1 - i));
            }

            Console.WriteLine(result);

        }

        public static List<string> GenerateDigits(string str)
        {
            List<string> result = new List<string>();
            bool smallLetter = false;

            for (int i = 0; i < str.Length; i++)
            {
                if (smallLetter)
                {
                    result.Add("" + str[i - 1] + str[i]);
                    smallLetter = false;
                }
                else
                {
                    if (IsSmallLetter(str[i]))
                    {
                        smallLetter = true;
                        continue;
                    }
                    else
                    {
                        result.Add("" + str[i]);
                    }
                }
            }

            return result;
        }

        public static bool IsSmallLetter(char c)
        {
            if ((int)c >= 97 && (int)c <= 122)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static int[] GenerateNumbersFromDigits(List<string> digits)
        {
            int[] result = new int[digits.Count];

            for (int i = 0; i < digits.Count; i++)
            {
                if (digits[i].Length == 2)
                {
                    int value = ((int)digits[i][0] - 96) * 26 + ((int)digits[i][1] - 65);
                    result[i] = value;
                }
                else
                {
                    int value = (int)digits[i][0] - 65;
                    result[i] = value;
                }
            }

            return result;
        }
    }
}
