using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DurankulakNumbers
{
    class Program
    {
        static List<char> letters = new List<char>();

        static ulong Convert(string input)
        {
            if (input.Length == 1)
            {
                return (ulong)(input[0] - 65);
            }
            else
            {
               return (ulong)((input[1] - 65) + ((input[0] - 96) * 26));
            }
            return 0;
        }
        static void Main(string[] args)
        {
            letters.Add('a');
            letters.Add('b');
            letters.Add('c');
            letters.Add('d');
            letters.Add('e');
            letters.Add('f');
            letters.Add('g');
            letters.Add('h');
            letters.Add('i');
            letters.Add('j');
            letters.Add('k');
            letters.Add('l');
            letters.Add('m');
            letters.Add('n');
            letters.Add('o');
            letters.Add('p');
            letters.Add('q');
            letters.Add('r');
            letters.Add('s');
            letters.Add('t');
            letters.Add('u');
            letters.Add('v');
            letters.Add('w');
            letters.Add('x');
            letters.Add('y');
            letters.Add('z');

            string input = Console.ReadLine();
            List<string> digits = new List<string>();
            string help = "";
            foreach (var symbol in input)
            {
                if (letters.Contains(symbol))
                {
                    help += symbol;
                }
                else
                {
                    help += symbol;
                    digits.Add(help);
                    help = "";
                }
            }
            ulong sum = 0;
            for (int i = 0; i < digits.Count; i++)
            {
                sum += Convert(digits[i]) * (ulong)Math.Pow(168, digits.Count - 1 - i);
            }
            Console.WriteLine(sum);
        }
    }
}
