using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace _05.Fifth
{
    class Fifth
    {
        static void Main()
        {
            long A;
            long B;
            string[] Buffer = Console.ReadLine().Split(new char[]{' '},StringSplitOptions.RemoveEmptyEntries);
            A = Convert.ToInt64(Buffer[0]);
            B = Convert.ToInt64(Buffer[1]);
            string[] Buffer1 = Console.ReadLine().Split(new char[] { ' ',',' }, StringSplitOptions.RemoveEmptyEntries);
            List<int> arr = new List<int>();
            for (int i = 0; i < Buffer1.Length; i++)
            {
                arr.Add(int.Parse(Buffer1[i]));
            }
            double p = double.Parse(Console.ReadLine());
            //long A = 1;
            //long B = 10000000000;
            //List<int> arr = new List<int>() { 10,9,8,7,6,5,4,3,2,1};
            //double p = 39;

            Console.WriteLine(findLuckyNum(A, B));
            Console.WriteLine(findSmallestItem(arr, p));

        }

        private static int findSmallestItem(List<int> arr, double p)
        {
            int element = 0;
            arr.Sort();
            int index = Convert.ToInt32(p / 100 * arr.Count);
            if (index - 2 > 0)
            {
                index -= 2;
            }
            else if (index - 1 > 0)
            {
                index--;
            }
            while (index < arr.Count * (p / 100))
            {
                index++;
            }
            element = arr[index-1];
            return element;
        }
        

        private static int findLuckyNum(long A, long B)
        {
            int alength = A.ToString().Length;
            int blength = B.ToString().Length;
            string number="";
            int count = 0;
            List<string> proba = new List<string>(){"3","5"};
            for (int i = 2; i < blength / 2 + 1; i++)
            {
                int len = proba.Count;
                for (int j = 0; j < len; j++)  //// povtarqt mi se
                {
                    proba.Add(proba[j] + "3");
                    proba.Add(proba[j] + "5");

                }
                
            }
            proba.Sort((x,y) => x.Length.CompareTo(y.Length));
            for (int i = 1; i < proba.Count; i++)
            {
                if (proba[i] == proba[i - 1])
                {
                    proba.RemoveAt(i);
                    i--;
                }
            }
            for (int i = 0; i < proba.Count; i++)
            {
                char[] c = proba[i].ToCharArray();
                Array.Reverse(c);
                proba[i] = proba[i] + new string(c);
            }

            int len1 = proba.Count;
            for (int i = 0; i < len1; i++)
            {
                //if (proba[i].Length < blength / 2 + 1)

                proba.Add(proba[i].Substring(0, proba[i].Length / 2) + "3" + proba[i].Substring(proba[i].Length / 2));
                proba.Add(proba[i].Substring(0, proba[i].Length / 2) + "5" + proba[i].Substring(proba[i].Length / 2));


            }
            for (int i = 0; i < proba.Count; i++)
            {
                if (Convert.ToInt64(proba[i]) >= A && Convert.ToInt64(proba[i]) <= B)
                {
                    count++;
                }
            }
            if (3 >= A && 3 <= B)
                count++;
            if (5 >= A && 5 <= B)
                count++;
                
             /*
            for (long i = A; i <= B; i++)
            {
                string str = i.ToString();
                if (Regex.IsMatch(str, @"^(3|5)+$"))
                {
                    if (str.Length == 1)
                        count++;
                    if (str.Substring(0, str.Length/2) == str.Substring(str.Length/2))
                    {
                        count++;
                    }

                }
            }*/
            return count;

        }
    }
}
