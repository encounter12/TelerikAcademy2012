using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelerikExam2Day2
{
    class JoroTheRabbit
    {

        static int JumpJoro(int startPos, int curPos, int step, List<int> terrainPlaces)
        {
            int len = 2;
            int posCount = terrainPlaces.Count();
            bool[] visited = new bool[posCount];
            visited[startPos] = true;
            visited[curPos] = true;

            int stepsDone = 0;
            int movingPos = curPos;
            while (true)
            {
                stepsDone++;
                movingPos++;
                if (posCount - 1 < movingPos)
                {
                    movingPos = 0;
                }
                if (stepsDone == step)
                {
                    if (terrainPlaces[movingPos] > terrainPlaces[curPos])
                    {
                        curPos = movingPos;
                        stepsDone = 0;
                        len++;
                    }
                    else
                    {
                        return len;
                    }
                }
            }
        }
        static void Main()
        {
            string line = Console.ReadLine();

            string[] places = line.Split(' ', ',');

            int num;
            List<int> terrainPlaces = new List<int>();
            foreach (var position in places)
            {
                if (int.TryParse(position, out num))
                {
                    terrainPlaces.Add(num);
                }
            }
            // end parsing
            int posCount = terrainPlaces.Count;
            bool[] visited = new bool[posCount];
            int lenght = 1;
            int oldLen = 1;

            for (int i = 0; i < posCount; i++)
            {
                int k = 0;
                do
                {
                    k++;
                    int step = 1;
                    if (posCount - 1 < k + i)
                    {
                        k = -i;
                    }
                    if (terrainPlaces[i + k] > terrainPlaces[i])
                    {
                        if (k < 0)
                        {
                            step = i + k  + posCount - i;
                        }
                        else
                        {
                            step = k;
                        }
                        
                        lenght = JumpJoro(i, i + k, step, terrainPlaces);
                        if (oldLen < lenght)
                        {
                            oldLen = lenght;
                        }
                    }
                } while (i != i + k);
            }
            Console.WriteLine(oldLen);
        }
    }
}
