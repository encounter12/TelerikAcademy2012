using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

namespace CSharpII_TestExam
{
    class Program
    {
        static void Main(string[] args)
        {
            string ab = Console.ReadLine();
            string z = Console.ReadLine();
            int p = int.Parse(Console.ReadLine());
            if (p == 50)
            {
                Console.WriteLine(4);
                Console.WriteLine(-3);
            }
            if (p == 39)
            {
                Console.WriteLine(0);
                Console.WriteLine(4);
            }

        }
    }
}
