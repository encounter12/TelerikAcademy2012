using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DurankulakNumbers
{
    class DurankulakNumbers
    {
        static void Main()
        {
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "A":
                    Console.WriteLine("0");
                    break;
                case "B":
                    Console.WriteLine("1");
                    break;
                case "C":
                    Console.WriteLine("2");
                    break;
                case "D":
                    Console.WriteLine("3");
                    break;
                case "E":
                    Console.WriteLine("4");
                    break;
                case "F":
                    Console.WriteLine("5");
                    break;
                case "G":
                    Console.WriteLine("6");
                    break;
                case "H":
                    Console.WriteLine("7");
                    break;
                case "I":
                    Console.WriteLine("8");                    
                    break;
                case "J":
                    Console.WriteLine("9");
                    break;
                case "K":
                    Console.WriteLine("10");
                    break;
                case "L":
                    Console.WriteLine("11");
                    break;
                case "M":
                    Console.WriteLine("12");
                    break;
                case "N":
                    Console.WriteLine("13");
                    break;
                case "O":
                    Console.WriteLine("14");
                    break;
                case "P":
                    Console.WriteLine("15");
                    break;
                case "Q":
                    Console.WriteLine("16");
                    break;
                case "R":
                    Console.WriteLine("17");
                    break;
                case "S":
                    Console.WriteLine("18");
                    break;
                case "T":
                    Console.WriteLine("19");
                    break;
                case "U":
                    Console.WriteLine("20");
                    break;
                case "V":
                    Console.WriteLine("21");
                    break;
                case "W":
                    Console.WriteLine("22");
                    break;
                case "X":
                    Console.WriteLine("23");
                    break;
                case "Y":
                    Console.WriteLine("24");
                    break;
                case "Z":
                    Console.WriteLine("25");
                    break;
                case "aA":
                    Console.WriteLine("26");
                    break;
                case "aB":
                    Console.WriteLine("27");
                    break;
                case "aC":
                    Console.WriteLine("28");
                    break;
                case "aD":
                    Console.WriteLine("29");
                    break;
                case "aE":
                    Console.WriteLine("30");
                    break;
                case "aF":
                    Console.WriteLine("31");
                    break;
                case "aG":
                    Console.WriteLine("32");
                    break;
                case "aH":
                    Console.WriteLine("33");
                    break;
                case "aI":
                    Console.WriteLine("34");
                    break;
                case "aJ":
                    Console.WriteLine("35");
                    break;
                case "aK":
                    Console.WriteLine("36");
                    break;
                case "aL":
                    Console.WriteLine("37");
                    break;
                case "aM":
                    Console.WriteLine("38");
                    break;
                case "aN":
                    Console.WriteLine("39");
                    break;
                case "aO":
                    Console.WriteLine("40");
                    break;
                case "aP":
                    Console.WriteLine("41");
                    break;
                case "aQ":
                    Console.WriteLine("42");
                    break;
                case "aR":
                    Console.WriteLine("43");
                    break;
                case "aS":
                    Console.WriteLine("44");
                    break;
                case "aT":
                    Console.WriteLine("45");
                    break;
                case "aU":
                    Console.WriteLine("46");
                    break;
                case "aV":
                    Console.WriteLine("47");
                    break;
                case "aW":
                    Console.WriteLine("48");
                    break;
                case "aX":
                    Console.WriteLine("49");
                    break;
                case "aY":
                    Console.WriteLine("50");
                    break;
                case "aZ":
                    Console.WriteLine("51");
                    break;
                case "bA":
                    Console.WriteLine("52");
                    break;
                case "bB":
                    Console.WriteLine("53");
                    break;
                case "bC":
                    Console.WriteLine("54");
                    break;
                case "bD":
                    Console.WriteLine("55");
                    break;
                case "bE":
                    Console.WriteLine("56");
                    break;
                case "bF":
                    Console.WriteLine("57");
                    break;
                case "bG":
                    Console.WriteLine("58");
                    break;
                case "bH":
                    Console.WriteLine("59");
                    break;
                case "bI":
                    Console.WriteLine("60");
                    break;
                case "bJ":
                    Console.WriteLine("61");
                    break;
                case "bK":
                    Console.WriteLine("62");
                    break;
                case "bL":
                    Console.WriteLine("63");
                    break;
                case "bM":
                    Console.WriteLine("64");
                    break;
                case "bN":
                    Console.WriteLine("65");
                    break;
                case "bO":
                    Console.WriteLine("66");
                    break;
                case "bP":
                    Console.WriteLine("67");
                    break;
                case "bQ":
                    Console.WriteLine("68");
                    break;
                case "bR":
                    Console.WriteLine("69");
                    break;
                case "bS":
                    Console.WriteLine("70");
                    break;
                case "bT":
                    Console.WriteLine("71");
                    break;
                case "bU":
                    Console.WriteLine("72");
                    break;
                case "bV":
                    Console.WriteLine("73");
                    break;
                case "bW":
                    Console.WriteLine("74");
                    break;
                case "bX":
                    Console.WriteLine("75");
                    break;
                case "bY":
                    Console.WriteLine("76");
                    break;
                case "bZ":
                    Console.WriteLine("77");
                    break;
                case "cA":
                    Console.WriteLine("78");
                    break;
                case "cB":
                    Console.WriteLine("79");
                    break;
                case "cC":
                    Console.WriteLine("80");
                    break;
                case "cD":
                    Console.WriteLine("81");
                    break;
                case "cE":
                    Console.WriteLine("82");
                    break;
                case "cF":
                    Console.WriteLine("83");
                    break;
                case "cG":
                    Console.WriteLine("84");
                    break;
                case "cH":
                    Console.WriteLine("85");
                    break;
                case "cI":
                    Console.WriteLine("86");
                    break;
                case "cJ":
                    Console.WriteLine("87");
                    break;
                case "cK":
                    Console.WriteLine("88");
                    break;
                case "cL":
                    Console.WriteLine("89");
                    break;
                case "cM":
                    Console.WriteLine("90");
                    break;
                case "cN":
                    Console.WriteLine("91");
                    break;
                case "cO":
                    Console.WriteLine("92");
                    break;
                case "cP":
                    Console.WriteLine("93");
                    break;
                case "cQ":
                    Console.WriteLine("94");
                    break;
                case "cR":
                    Console.WriteLine("95");
                    break;
                case "cS":
                    Console.WriteLine("96");
                    break;
                case "cT":
                    Console.WriteLine("97");
                    break;
                case "cU":
                    Console.WriteLine("98");
                    break;
                case "cV":
                    Console.WriteLine("99");
                    break;
                case "cW":
                    Console.WriteLine("100");
                    break;
                case "cX":
                    Console.WriteLine("101");
                    break;
                case "cY":
                    Console.WriteLine("102");
                    break;
                case "cZ":
                    Console.WriteLine("103");
                    break;
                case "dA":
                    Console.WriteLine("104");
                    break;
                case "dB":
                    Console.WriteLine("105");
                    break;
                case "dC":
                    Console.WriteLine("106");
                    break;
                case "dD":
                    Console.WriteLine("107");
                    break;
                case "dE":
                    Console.WriteLine("108");
                    break;
                case "dF":
                    Console.WriteLine("109");
                    break;
                case "dG":
                    Console.WriteLine("110");
                    break;
                case "dH":
                    Console.WriteLine("111");
                    break;
                case "dI":
                    Console.WriteLine("112");
                    break;
                case "dJ":
                    Console.WriteLine("113");
                    break;
                case "dK":
                    Console.WriteLine("114");
                    break;
                case "dL":
                    Console.WriteLine("115");
                    break;
                case "dM":
                    Console.WriteLine("116");
                    break;
                case "dN":
                    Console.WriteLine("117");
                    break;
                case "dO":
                    Console.WriteLine("118");
                    break;
                case "dP":
                    Console.WriteLine("119");
                    break;
                case "dQ":
                    Console.WriteLine("120");
                    break;
                case "dR":
                    Console.WriteLine("121");
                    break;
                case "dS":
                    Console.WriteLine("122");
                    break;
                case "dT":
                    Console.WriteLine("123");
                    break;
                case "dU":
                    Console.WriteLine("124");
                    break;
                case "dV":
                    Console.WriteLine("125");
                    break;
                case "dW":
                    Console.WriteLine("126");
                    break;
                case "dX":
                    Console.WriteLine("127");
                    break;
                case "dY":
                    Console.WriteLine("128");
                    break;
                case "dZ":
                    Console.WriteLine("129");
                    break;
                case "eA":
                    Console.WriteLine("130");
                    break;
                case "eB":
                    Console.WriteLine("131");
                    break;
                case "eC":
                    Console.WriteLine("132");
                    break;
                case "eD":
                    Console.WriteLine("133");
                    break;
                case "eE":
                    Console.WriteLine("134");
                    break;
                case "eF":
                    Console.WriteLine("135");
                    break;
                case "eG":
                    Console.WriteLine("136");
                    break;
                case "eH":
                    Console.WriteLine("137");
                    break;
                case "eI":
                    Console.WriteLine("138");
                    break;
                case "eJ":
                    Console.WriteLine("139");
                    break;
                case "eK":
                    Console.WriteLine("140");
                    break;
                case "eL":
                    Console.WriteLine("141");
                    break;
                case "eM":
                    Console.WriteLine("142");
                    break;
                case "eN":
                    Console.WriteLine("143");
                    break;
                case "eO":
                    Console.WriteLine("144");
                    break;
                case "eP":
                    Console.WriteLine("145");
                    break;
                case "eQ":
                    Console.WriteLine("146");
                    break;
                case "eR":
                    Console.WriteLine("147");
                    break;
                case "eS":
                    Console.WriteLine("148");
                    break;
                case "eT":
                    Console.WriteLine("149");
                    break;
                case "eU":
                    Console.WriteLine("150");
                    break;
                case "eV":
                    Console.WriteLine("151");
                    break;
                case "eW":
                    Console.WriteLine("152");
                    break;
                case "eX":
                    Console.WriteLine("153");
                    break;
                case "eY":
                    Console.WriteLine("154");
                    break;
                case "eZ":
                    Console.WriteLine("155");
                    break;
                case "fA":
                    Console.WriteLine("156");
                    break;
                case "fB":
                    Console.WriteLine("157");
                    break;
                case "fC":
                    Console.WriteLine("158");
                    break;
                case "fD":
                    Console.WriteLine("159");
                    break;
                case "fE":
                    Console.WriteLine("160");
                    break;
                case "fF":
                    Console.WriteLine("161");
                    break;
                case "fG":
                    Console.WriteLine("162");
                    break;
                case "fH":
                    Console.WriteLine("163");
                    break;
                case "fI":
                    Console.WriteLine("164");
                    break;
                case "fJ":
                    Console.WriteLine("165");
                    break;
                case "fK":
                    Console.WriteLine("166");
                    break;
                case "fL":
                    Console.WriteLine("167");
                    break;
                case "AaA":
                    Console.WriteLine("168");
                    break;
                case "AaB":
                    Console.WriteLine("169");
                    break;
                case "AaC":
                    Console.WriteLine("170");
                    break;
                case "AaD":
                    Console.WriteLine("171");
                    break;
                case "AaE":
                    Console.WriteLine("172");
                    break;
                case "AaF":
                    Console.WriteLine("173");
                    break;
                case "AaG":
                    Console.WriteLine("174");
                    break;
                case "AaH":
                    Console.WriteLine("175");
                    break;
                case "AaI":
                    Console.WriteLine("176");
                    break;
                case "AaJ":
                    Console.WriteLine("177");
                    break;
                case "AaK":
                    Console.WriteLine("178");
                    break;
                case "AaL":
                    Console.WriteLine("179");
                    break;
                case "AaM":
                    Console.WriteLine("180");
                    break;
                case "AaN":
                    Console.WriteLine("181");
                    break;
                case "AaO":
                    Console.WriteLine("182");
                    break;
                case "AaP":
                    Console.WriteLine("183");
                    break;
                case "AaQ":
                    Console.WriteLine("184");
                    break;
                case "AaR":
                    Console.WriteLine("185");
                    break;
                case "AaS":
                    Console.WriteLine("186");
                    break;
                case "AaT":
                    Console.WriteLine("187");
                    break;
                case "AaU":
                    Console.WriteLine("188");
                    break;
                case "AaV":
                    Console.WriteLine("189");
                    break;
                case "AaW":
                    Console.WriteLine("190");
                    break;
                case "AaX":
                    Console.WriteLine("191");
                    break;
                case "AaY":
                    Console.WriteLine("192");
                    break;
                case "AaZ":
                    Console.WriteLine("193");
                    break;
                case "BaA":
                    Console.WriteLine("194");
                    break;
                case "BaB":
                    Console.WriteLine("195");
                    break;
                case "BaC":
                    Console.WriteLine("196");
                    break;
                case "BaD":
                    Console.WriteLine("197");
                    break;
                case "BaE":
                    Console.WriteLine("198");
                    break;
                case "BaF":
                    Console.WriteLine("199");
                    break;
                case "BaG":
                    Console.WriteLine("200");
                    break;
                case "BaH":
                    Console.WriteLine("201");
                    break;
                case "BaI":
                    Console.WriteLine("202");
                    break;
                case "BaJ":
                    Console.WriteLine("203");
                    break;
                case "BaK":
                    Console.WriteLine("204");
                    break;
                case "BaL":
                    Console.WriteLine("205");
                    break;
                case "BaM":
                    Console.WriteLine("206");
                    break;
                case "BaN":
                    Console.WriteLine("207");
                    break;
                case "BaO":
                    Console.WriteLine("208");
                    break;
                case "BaP":
                    Console.WriteLine("209");
                    break;
                case "BaQ":
                    Console.WriteLine("210");
                    break;
                case "BaR":
                    Console.WriteLine("211");
                    break;
                case "BaS":
                    Console.WriteLine("212");
                    break;
                case "BaT":
                    Console.WriteLine("213");
                    break;
                case "BaU":
                    Console.WriteLine("214");
                    break;
                case "BaV":
                    Console.WriteLine("215");
                    break;
                case "BaW":
                    Console.WriteLine("216");
                    break;
                case "BaX":
                    Console.WriteLine("217");
                    break;
                case "BaY":
                    Console.WriteLine("218");
                    break;
                case "BaZ":
                    Console.WriteLine("219");
                    break;
                case "BbA":
                    Console.WriteLine("220");
                    break;
                case "BbB":
                    Console.WriteLine("221");
                    break;
                case "BbC":
                    Console.WriteLine("222");
                    break;
                case "BbD":
                    Console.WriteLine("223");
                    break;
                case "BbE":
                    Console.WriteLine("224");
                    break;
                case "BbF":
                    Console.WriteLine("225");
                    break;
                case "BbG":
                    Console.WriteLine("226");
                    break;
                case "BbH":
                    Console.WriteLine("227");
                    break;
                case "BbI":
                    Console.WriteLine("228");
                    break;
                case "BbJ":
                    Console.WriteLine("229");
                    break;
                case "BbK":
                    Console.WriteLine("230");
                    break;
                case "BbL":
                    Console.WriteLine("231");
                    break;
                case "BbM":
                    Console.WriteLine("232");
                    break;
                case "BbN":
                    Console.WriteLine("233");
                    break;
                case "BbO":
                    Console.WriteLine("234");
                    break;
                case "BbP":
                    Console.WriteLine("235");
                    break;
                case "BbQ":
                    Console.WriteLine("236");
                    break;
                case "BbR":
                    Console.WriteLine("237");
                    break;
                case "BbS":
                    Console.WriteLine("238");
                    break;
                case "BbT":
                    Console.WriteLine("239");
                    break;
                case "BbU":
                    Console.WriteLine("240");
                    break;
                case "BbV":
                    Console.WriteLine("241");
                    break;
                case "BbW":
                    Console.WriteLine("242");
                    break;
                case "BbX":
                    Console.WriteLine("243");
                    break;
                case "BbY":
                    Console.WriteLine("244");
                    break;
                case "BbZ":
                    Console.WriteLine("245");
                    break;
                case "BcA":
                    Console.WriteLine("246");
                    break;
                case "BcB":
                    Console.WriteLine("247");
                    break;
                case "BcC":
                    Console.WriteLine("248");
                    break;
                case "BcD":
                    Console.WriteLine("249");
                    break;
                case "BcE":
                    Console.WriteLine("250");
                    break;
                case "BcF":
                    Console.WriteLine("251");
                    break;
                case "BcG":
                    Console.WriteLine("252");
                    break;
                case "BcH":
                    Console.WriteLine("253");
                    break;
                case "BcI":
                    Console.WriteLine("254");
                    break;
                case "BcJ":
                    Console.WriteLine("255");
                    break;
                case "BcK":
                    Console.WriteLine("256");
                    break;
                case "BcL":
                    Console.WriteLine("257");
                    break;
                case "BcM":
                    Console.WriteLine("258");
                    break;
                case "BcN":
                    Console.WriteLine("259");
                    break;
                case "BcO":
                    Console.WriteLine("260");
                    break;
                case "BcP":
                    Console.WriteLine("261");
                    break;
                case "BcQ":
                    Console.WriteLine("262");
                    break;
                case "BcR":
                    Console.WriteLine("263");
                    break;
                case "BcS":
                    Console.WriteLine("264");
                    break;
                case "BcT":
                    Console.WriteLine("265");
                    break;
                case "BcU":
                    Console.WriteLine("266");
                    break;
                case "BcV":
                    Console.WriteLine("267");
                    break;
                case "BcW":
                    Console.WriteLine("268");
                    break;
                case "BcX":
                    Console.WriteLine("269");
                    break;
                case "BcY":
                    Console.WriteLine("270");
                    break;
                case "BcZ":
                    Console.WriteLine("271");
                    break;
                case "BdA":
                    Console.WriteLine("272");
                    break;
                case "BdB":
                    Console.WriteLine("273");
                    break;
                case "BdC":
                    Console.WriteLine("274");
                    break;
                case "BdD":
                    Console.WriteLine("275");
                    break;
                case "BdE":
                    Console.WriteLine("276");
                    break;
                case "BdF":
                    Console.WriteLine("277");
                    break;
                case "BdG":
                    Console.WriteLine("278");
                    break;
                case "BdH":
                    Console.WriteLine("279");
                    break;
                case "BdI":
                    Console.WriteLine("280");
                    break;
                case "BdJ":
                    Console.WriteLine("281");
                    break;
                case "BdK":
                    Console.WriteLine("282");
                    break;
                case "BdL":
                    Console.WriteLine("283");
                    break;
                case "BdM":
                    Console.WriteLine("284");
                    break;
                case "BdN":
                    Console.WriteLine("285");
                    break;
                case "BdO":
                    Console.WriteLine("286");
                    break;
                case "BdP":
                    Console.WriteLine("287");
                    break;
                case "BdQ":
                    Console.WriteLine("288");
                    break;
                case "BdR":
                    Console.WriteLine("289");
                    break;
                case "BdS":
                    Console.WriteLine("290");
                    break;
                case "BdT":
                    Console.WriteLine("291");
                    break;
                case "BdU":
                    Console.WriteLine("292");
                    break;
                case "BdV":
                    Console.WriteLine("293");
                    break;
                case "BdW":
                    Console.WriteLine("294");
                    break;
                case "BdX":
                    Console.WriteLine("295");
                    break;
                case "BdY":
                    Console.WriteLine("296");
                    break;
                case "BdZ":
                    Console.WriteLine("297");
                    break;
                case "BeA":
                    Console.WriteLine("298");
                    break;
                case "BeB":
                    Console.WriteLine("299");
                    break;
                case "BeC":
                    Console.WriteLine("300");
                    break;
                case "BeD":
                    Console.WriteLine("301");
                    break;
                case "BeE":
                    Console.WriteLine("302");
                    break;
                case "BeF":
                    Console.WriteLine("303");
                    break;
                case "BeG":
                    Console.WriteLine("304");
                    break;
                case "BeH":
                    Console.WriteLine("305");
                    break;
                case "BeI":
                    Console.WriteLine("306");
                    break;
                case "BeJ":
                    Console.WriteLine("307");
                    break;
                case "BeK":
                    Console.WriteLine("308");
                    break;
                case "BeL":
                    Console.WriteLine("309");
                    break;
                case "BeM":
                    Console.WriteLine("310");
                    break;
                case "BeN":
                    Console.WriteLine("311");
                    break;
                case "BeO":
                    Console.WriteLine("312");
                    break;
                case "BeP":
                    Console.WriteLine("313");
                    break;
                case "BeQ":
                    Console.WriteLine("314");
                    break;
                case "BeR":
                    Console.WriteLine("315");
                    break;
                case "BeS":
                    Console.WriteLine("316");
                    break;
                case "BeT":
                    Console.WriteLine("317");
                    break;
                case "BeU":
                    Console.WriteLine("318");
                    break;
                case "BeV":
                    Console.WriteLine("319");
                    break;
                case "BeW":
                    Console.WriteLine("320");
                    break;
                case "BeX":
                    Console.WriteLine("321");
                    break;
                case "BeY":
                    Console.WriteLine("322");
                    break;
                case "BeZ":
                    Console.WriteLine("323");
                    break;
                case "BfA":
                    Console.WriteLine("324");
                    break;
                case "BfB":
                    Console.WriteLine("325");
                    break;
                case "BfC":
                    Console.WriteLine("326");
                    break;
                case "BfD":
                    Console.WriteLine("327");
                    break;
                case "BfE":
                    Console.WriteLine("328");
                    break;
                case "BfF":
                    Console.WriteLine("329");
                    break;
                case "BfG":
                    Console.WriteLine("330");
                    break;
                case "BfH":
                    Console.WriteLine("331");
                    break;
                case "BfI":
                    Console.WriteLine("332");
                    break;
                case "BfJ":
                    Console.WriteLine("333");
                    break;
                case "BfK":
                    Console.WriteLine("334");
                    break;
                case "BfL":
                    Console.WriteLine("335");
                    break;
                case "CaA":
                    Console.WriteLine("362");
                    break;
                case "CaB":
                    Console.WriteLine("363");
                    break;
                case "CaC":
                    Console.WriteLine("364");
                    break;
                case "CaD":
                    Console.WriteLine("365");
                    break;
                case "CaE":
                    Console.WriteLine("366");
                    break;
                case "CaF":
                    Console.WriteLine("367");
                    break;
                case "CaG":
                    Console.WriteLine("368");
                    break;
                case "CaH":
                    Console.WriteLine("369");
                    break;
                case "CaI":
                    Console.WriteLine("370");
                    break;
                case "CaJ":
                    Console.WriteLine("371");
                    break;
                case "CaK":
                    Console.WriteLine("372");
                    break;
                case "CaL":
                    Console.WriteLine("373");
                    break;
                case "CaM":
                    Console.WriteLine("374");
                    break;
                case "CaN":
                    Console.WriteLine("375");
                    break;
                case "CaO":
                    Console.WriteLine("376");
                    break;
                case "CaP":
                    Console.WriteLine("377");
                    break;
                case "CaQ":
                    Console.WriteLine("378");
                    break;
                case "CaR":
                    Console.WriteLine("379");
                    break;
                case "CaS":
                    Console.WriteLine("380");
                    break;
                case "CaT":
                    Console.WriteLine("381");
                    break;
                case "CaU":
                    Console.WriteLine("382");
                    break;
                case "CaV":
                    Console.WriteLine("383");
                    break;
                case "CaW":
                    Console.WriteLine("384");
                    break;
                case "CaX":
                    Console.WriteLine("385");
                    break;
                case "CaY":
                    Console.WriteLine("386");
                    break;
                case "CaZ":
                    Console.WriteLine("387");
                    break;
                case "CbA":
                    Console.WriteLine("388");
                    break;
                case "CbB":
                    Console.WriteLine("389");
                    break;
                case "CbC":
                    Console.WriteLine("390");
                    break;
                case "CbD":
                    Console.WriteLine("391");
                    break;
                case "CbE":
                    Console.WriteLine("392");
                    break;
                case "CbF":
                    Console.WriteLine("393");
                    break;
                case "CbG":
                    Console.WriteLine("394");
                    break;
                case "CbH":
                    Console.WriteLine("395");
                    break;
                case "CbI":
                    Console.WriteLine("396");
                    break;
                case "CbJ":
                    Console.WriteLine("397");
                    break;
                case "CbK":
                    Console.WriteLine("398");
                    break;
                case "CbL":
                    Console.WriteLine("399");
                    break;
                case "CbM":
                    Console.WriteLine("400");
                    break;
                case "CbN":
                    Console.WriteLine("401");
                    break;
                case "CbO":
                    Console.WriteLine("402");
                    break;
                case "CbP":
                    Console.WriteLine("403");
                    break;
                case "CbQ":
                    Console.WriteLine("404");
                    break;
                case "CbR":
                    Console.WriteLine("405");
                    break;
                case "CbS":
                    Console.WriteLine("406");
                    break;
                case "CbT":
                    Console.WriteLine("407");
                    break;
                case "CbU":
                    Console.WriteLine("408");
                    break;
                case "CbV":
                    Console.WriteLine("409");
                    break;
                case "CbW":
                    Console.WriteLine("410");
                    break;
                case "CbX":
                    Console.WriteLine("411");
                    break;
                case "CbY":
                    Console.WriteLine("412");
                    break;
                case "CbZ":
                    Console.WriteLine("413");
                    break;
                case "CcA":
                    Console.WriteLine("414");
                    break;
                case "CcB":
                    Console.WriteLine("415");
                    break;
                case "CcC":
                    Console.WriteLine("416");
                    break;
                case "CcD":
                    Console.WriteLine("417");
                    break;
                case "CcE":
                    Console.WriteLine("418");
                    break;
                case "CcF":
                    Console.WriteLine("419");
                    break;
                case "CcG":
                    Console.WriteLine("420");
                    break;
                case "CcH":
                    Console.WriteLine("421");
                    break;
                case "CcI":
                    Console.WriteLine("422");
                    break;
                case "CcJ":
                    Console.WriteLine("423");
                    break;
                case "CcK":
                    Console.WriteLine("424");
                    break;
                case "CcL":
                    Console.WriteLine("425");
                    break;
                case "CcM":
                    Console.WriteLine("426");
                    break;
                case "CcN":
                    Console.WriteLine("427");
                    break;
                case "CcO":
                    Console.WriteLine("428");
                    break;
                case "CcP":
                    Console.WriteLine("429");
                    break;
                case "CcQ":
                    Console.WriteLine("430");
                    break;
                case "CcR":
                    Console.WriteLine("431");
                    break;
                case "CcS":
                    Console.WriteLine("432");
                    break;
                case "CcT":
                    Console.WriteLine("433");
                    break;
                case "CcU":
                    Console.WriteLine("434");
                    break;
                case "CcV":
                    Console.WriteLine("435");
                    break;
                case "CcW":
                    Console.WriteLine("436");
                    break;
                case "CcX":
                    Console.WriteLine("437");
                    break;
                case "CcY":
                    Console.WriteLine("438");
                    break;
                case "CcZ":
                    Console.WriteLine("439");
                    break;
                case "CdA":
                    Console.WriteLine("440");
                    break;
                case "CdB":
                    Console.WriteLine("441");
                    break;
                case "CdC":
                    Console.WriteLine("442");
                    break;
                case "CdD":
                    Console.WriteLine("443");
                    break;
                case "CdE":
                    Console.WriteLine("444");
                    break;
                case "CdF":
                    Console.WriteLine("445");
                    break;
                case "CdG":
                    Console.WriteLine("446");
                    break;
                case "CdH":
                    Console.WriteLine("447");
                    break;
                case "CdI":
                    Console.WriteLine("448");
                    break;
                case "CdJ":
                    Console.WriteLine("449");
                    break;
                case "CdK":
                    Console.WriteLine("450");
                    break;
                case "CdL":
                    Console.WriteLine("451");
                    break;
                case "CdM":
                    Console.WriteLine("452");
                    break;
                case "CdN":
                    Console.WriteLine("453");
                    break;
                case "CdO":
                    Console.WriteLine("454");
                    break;
                case "CdP":
                    Console.WriteLine("455");
                    break;
                case "CdQ":
                    Console.WriteLine("456");
                    break;
                case "CdR":
                    Console.WriteLine("457");
                    break;
                case "CdS":
                    Console.WriteLine("458");
                    break;
                case "CdT":
                    Console.WriteLine("459");
                    break;
                case "CdU":
                    Console.WriteLine("460");
                    break;
                case "CdV":
                    Console.WriteLine("461");
                    break;
                case "CdW":
                    Console.WriteLine("462");
                    break;
                case "CdX":
                    Console.WriteLine("463");
                    break;
                case "CdY":
                    Console.WriteLine("464");
                    break;
                case "CdZ":
                    Console.WriteLine("465");
                    break;
                case "CeA":
                    Console.WriteLine("466");
                    break;
                case "CeB":
                    Console.WriteLine("467");
                    break;
                case "CeC":
                    Console.WriteLine("468");
                    break;
                case "CeD":
                    Console.WriteLine("469");
                    break;
                case "CeE":
                    Console.WriteLine("470");
                    break;
                case "CeF":
                    Console.WriteLine("471");
                    break;
                case "CeG":
                    Console.WriteLine("472");
                    break;
                case "CeH":
                    Console.WriteLine("473");
                    break;
                case "CeI":
                    Console.WriteLine("474");
                    break;
                case "CeJ":
                    Console.WriteLine("475");
                    break;
                case "CeK":
                    Console.WriteLine("476");
                    break;
                case "CeL":
                    Console.WriteLine("477");
                    break;
                case "CeM":
                    Console.WriteLine("478");
                    break;
                case "CeN":
                    Console.WriteLine("479");
                    break;
                case "CeO":
                    Console.WriteLine("480");
                    break;
                case "CeP":
                    Console.WriteLine("481");
                    break;
                case "CeQ":
                    Console.WriteLine("482");
                    break;
                case "CeR":
                    Console.WriteLine("483");
                    break;
                case "CeS":
                    Console.WriteLine("484");
                    break;
                case "CeT":
                    Console.WriteLine("485");
                    break;
                case "CeU":
                    Console.WriteLine("486");
                    break;
                case "CeV":
                    Console.WriteLine("487");
                    break;
                case "CeW":
                    Console.WriteLine("488");
                    break;
                case "CeX":
                    Console.WriteLine("489");
                    break;
                case "CeY":
                    Console.WriteLine("490");
                    break;
                case "CeZ":
                    Console.WriteLine("491");
                    break;
                case "CfA":
                    Console.WriteLine("492");
                    break;
                case "CfB":
                    Console.WriteLine("493");
                    break;
                case "CfC":
                    Console.WriteLine("494");
                    break;
                case "CfD":
                    Console.WriteLine("495");
                    break;
                case "CfE":
                    Console.WriteLine("496");
                    break;
                case "CfF":
                    Console.WriteLine("497");
                    break;
                case "CfG":
                    Console.WriteLine("498");
                    break;
                case "CfH":
                    Console.WriteLine("499");
                    break;
                case "CfI":
                    Console.WriteLine("500");
                    break;
                case "CfJ":
                    Console.WriteLine("501");
                    break;
                case "CfK":
                    Console.WriteLine("502");
                    break;
                case "CfL":
                    Console.WriteLine("503");
                    break;
                default:
                    Console.WriteLine("Error");
                    break;

            }
        }
    }
}
