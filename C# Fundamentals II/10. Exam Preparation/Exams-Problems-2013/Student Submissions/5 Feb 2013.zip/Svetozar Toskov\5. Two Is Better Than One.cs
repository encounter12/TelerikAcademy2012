using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
   
namespace EX05TwoIsBetterThanOne
{
    class EX05TwoIsBetterThanOne
    {
        private static bool IsPalindrome(string word)
        {
            if (word.Length == 1)
            {
                return true;
            }
   
            bool containsOnlyLuckyDigits = (word.IndexOf("0") == -1) &&
                                           (word.IndexOf("1") == -1) &&
                                           (word.IndexOf("2") == -1) &&
                                           (word.IndexOf("4") == -1) &&
                                           (word.IndexOf("6") == -1) &&
                                           (word.IndexOf("7") == -1) &&
                                           (word.IndexOf("8") == -1) &&
                                           (word.IndexOf("9") == -1);
   
            if (!containsOnlyLuckyDigits)
            {
                return false;
            }
   
            for (int i = 0; i < word.Length / 2; i++)
                if (word[i] != word[word.Length - 1 - i])
                {
                    return false;
                }
               
            return true;
        }
   
        private static bool ContainsOnlyLuckyDigits(string number)
        {
            bool containsOnlyLuckyDigits = (number.IndexOf("0") == -1) &&
                                           (number.IndexOf("1") == -1) &&
                                           (number.IndexOf("2") == -1) &&
                                           (number.IndexOf("4") == -1) &&
                                           (number.IndexOf("6") == -1) &&
                                           (number.IndexOf("7") == -1) &&
                                           (number.IndexOf("8") == -1) &&
                                           (number.IndexOf("9") == -1);
            return containsOnlyLuckyDigits;
        }
   
        static void Main()
        {
//          string inputText = @"1 99
//-2,-1,-4,-3
//50";
//          StringReader input = new StringReader(inputText);
//          Console.SetIn(input);
            string[] task1BordersString = Console.ReadLine().Split(' ');
               
            double[] task1Borders = new double[2];
   
            for (int i = 0; i < task1BordersString.Length; i++)
            {
                task1Borders[i] = double.Parse(task1BordersString[i]);
            }
   
            List<string> luckyNumbers = new List<string>();
   
            for (double i = task1Borders[0]; i <= task1Borders[1]; i++)
            {
                string currentNumber = i.ToString();
                //currentNumber = currentNumber.Substring(0, currentNumber.IndexOf('.'));
                if (currentNumber[0] != '3' && currentNumber[0] != '5')
                {
                    continue;
                }
                if (IsPalindrome(currentNumber))
                {
                    luckyNumbers.Add(currentNumber);
                }
            }
   
            Console.WriteLine(luckyNumbers.Count);
   
            string[] task2NumbersString = Console.ReadLine().Split(',');
            int percentage = int.Parse(Console.ReadLine());
               
            int[] task2Numbers = new int[task2NumbersString.Length];
   
            for (int i = 0; i < task2NumbersString.Length; i++)
            {
                task2Numbers[i] = int.Parse(task2NumbersString[i]);
            }
   
            Array.Sort(task2Numbers);
            int elementsToSearchCount = (int)Math.Ceiling(task2Numbers.Length * percentage / 100.0);
            Console.WriteLine(task2Numbers[elementsToSearchCount - 1]);
        }
    }
}