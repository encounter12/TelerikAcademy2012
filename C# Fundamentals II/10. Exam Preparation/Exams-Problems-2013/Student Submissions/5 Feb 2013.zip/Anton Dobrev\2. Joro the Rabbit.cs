using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class ArrayJoroRabbit
{
    static void Main()
    {
        string input = Console.ReadLine();

        string[] splitted = input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

        int[] arr = new int[splitted.Length];

        for (int i = 0; i < arr.Length; i++)
        {
            arr[i] = int.Parse(splitted[i]);
        }

        //Array.Sort(arr);

        //foreach (var item in arr)
        //{
        //    Console.WriteLine(item);
        //}


        //Declare and initialize the array
        //int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0 };

        //Array.Sort(arr); - Dava TIME LIMIT

        // Write a program that finds the maximal increasing sequence in an array.
//Ex. {3, 2,3,4, 2, 2, 4} -> {2, 3, 4}

        
        //Declare 2 variables for the start of each sequence and its length, by default 0 and 1;
        int start = 0;
        int length = 1;
        //Declare 2 variables for the start of maximal sequence and its length, by default 0 and 1;
        int bestStart = 0;
        int bestLength = 1;
        //Iterating the array with a for cycle, while preserving the cycle to get out of the bounds of the array
        int bestStep = 0;
        int counter = 0;
        for (int step = 1; step < arr.Length; step++)
        {
            for (int i = arr.Length % step; i < arr.Length - 1; i++)
            {
                //checking if the next element is greater than the previous
                if ((arr[i] > arr[step]))
                {
                    length++;

                    if (length >= bestLength) // >= shows the greater sequence if there are two with the same length
                    {
                        bestLength = length;
                        bestStart = start;
                        bestStep = step;
                    }
                }

                else
                {
                    length = 1;
                    start = i + 1;
                }
                
            }
            
            
        }
        Console.WriteLine(arr.Length);
        
        
        //Console.WriteLine(counter);
        //for (int i = bestStart; i < bestStart+bestLength; i++)
        //{
        //    Console.Write(arr[i] + " ");
        //}
        //Console.WriteLine();
    }
}
    


