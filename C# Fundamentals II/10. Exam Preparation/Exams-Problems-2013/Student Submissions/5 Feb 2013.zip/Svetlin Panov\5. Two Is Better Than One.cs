using System;
using System.Linq;

namespace LuckyNumbers
{
    class Program
    {
        private static bool IsPalindromeLukcy(string text)
        {
            bool palindrom = false;

            for (int j = 0; j < text.Length / 2; j++)
            {
                bool a = text.Substring(j, 1) == text.Substring(text.Length - 1 - j, 1);
                bool b = text.Substring(j, 1) == "3" || (text.Substring(j, 1) == "5");
                if (a && b)
                {
                    palindrom = true;
                }
                else
                {
                    palindrom = false;
                    break;
                }
            }
            return palindrom;
        }

        private static int CountLukcyNumbers(long start, long end)
        {
            long number = 0;
            int count = 0;
            for (long i = start; i < end; i++)
            {
                number = i;
                if (number == 3 || number == 5)
                {
                    count++;
                }
                if (IsPalindromeLukcy(number.ToString()))
                {
                    count++;
                }
            }
            return count;
        }
        private static int ReturnMinValue(int[] numbers, int p)
        {

            int index = numbers.Length * (p / 100);
            int minNumber = numbers[index];
            return minNumber;
        }
        static void Main()
        {
            //Read input
            long rangeStart = 0;
            long rangeEnd = 0;
            string range = Console.ReadLine();
            string[] rangeNumber = range.Split(' ');
            rangeStart = long.Parse(rangeNumber[0]);
            rangeEnd = long.Parse(rangeNumber[1]);

            string elements = Console.ReadLine();
            string[] elementsList = elements.Split(',');
            int[] numbers = new int[elementsList.Length];
            Array.Sort(numbers);
            for (int i = 0; i < elementsList.Length; i++)
            {
                numbers[i] = int.Parse(elementsList[i]);
            }
            int p = int.Parse(Console.ReadLine());
            int count = CountLukcyNumbers(rangeStart, rangeEnd);
            Console.WriteLine(count);
            int minvalue = ReturnMinValue(numbers, p);
            Console.WriteLine(minvalue);
        }
    }
}