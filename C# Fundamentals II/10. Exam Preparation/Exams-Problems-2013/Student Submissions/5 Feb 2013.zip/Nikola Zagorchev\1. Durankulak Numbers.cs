using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

    class Program
    {
        static void Main()
        {
            string[] numbers=Numbers();
            List<string> input = new List<string>();
            StringBuilder lt = new StringBuilder();
            string read = Console.ReadLine();
            int index=0;
            for (int i = read.Length-1; i >= 0; i--)
            {
                char check=read[i];
                bool low=char.IsLower(read[i]);
                bool big = char.IsUpper(read[i]);
                if (big)
                {
                    if (i - 1>=0)
                    {
                        if (char.IsLower(read[i - 1]))
                        {
                            lt.Append(read[i - 1]);
                            lt.Append(read[i]);
                            //input[index] = lt.ToString();
                            input.Add(lt.ToString());
                            index++;
                            lt.Clear();
                        }
                        else
                        {
                            lt.Append(read[i]);
                            //input[index] = lt.ToString();
                            input.Add(lt.ToString());
                            index++;
                            lt.Clear();
                        }
                    }
                    else
                    {
                        lt.Append(read[i]);
                        //input[index] = lt.ToString();
                        input.Add(lt.ToString());
                        index++;
                        lt.Clear();
                    }
                }
            }
            BigInteger result = 0;
            BigInteger count = 1;
            for (int i = 0; i < 1; i++)
            {
                for(int j=0;j<numbers.Length;j++)
                {
                    if (input[i]==numbers[j])
                    {
                        result += j*count;
                        count *= 168;
                        j = 0;
                        i++;
                        if (i>=input.Count)
                        {
                            break;
                        }
                    }
                }
            }
            Console.WriteLine(result);
        }
        static string[] Numbers()
        {
            char[] symbols = new char[26];
            char[] letters = new char[26];
            string[] numbers = new string[168];
            for (int i = 0; i < symbols.Length; i++)
            {
                for (int j = (int)'A'; j <= (int)'Z'; j++,i++)
                {
                    letters[i] = (char)j;
                }
                i = 0;
                for (int j = (int)'a'; j <= (int)'z'; j++, i++)
                {
                    symbols[i] = (char)j;
                }
            }
            int index;
            for (index = 0; index < letters.Length; index++)
            {
                numbers[index] = letters[index].ToString();
            }
            for (int j = 0; j < 5; j++)
            {
                for (int i = 0; i < letters.Length; i++, index++)
                {
                    StringBuilder curr = new StringBuilder();
                    curr.Append(symbols[j].ToString());
                    curr.Append(letters[i].ToString());
                    numbers[index] = curr.ToString();
                }
            }
            for (int i = 0; i < 12; i++, index++)
            {
                StringBuilder curr = new StringBuilder();
                curr.Append(symbols[5].ToString());
                curr.Append(letters[i].ToString());
                numbers[index] = curr.ToString();
            }
            //for (int i = 0; i < numbers.Length; i++)
            //{
            //    Console.WriteLine("{0} {1}", i, numbers[i]);
            //}
            return numbers;
        }
    }

