using System;
using System.Collections.Generic;

class JoroTheRabbit
{
    static void Main()
    {
        char[] splitter = { ',', ' ' };
        string[] numbers = Console.ReadLine().Split(splitter, StringSplitOptions.RemoveEmptyEntries);

        List<int> fieldNums = new List<int>();
        foreach (string num in numbers)
        {
            fieldNums.Add(int.Parse(num));
        }

        int maxFun = 1;
        List<int> visited = new List<int>();
        for (int i = 0; i < fieldNums.Count; i++)
        {
            for (int j = 0; j <= fieldNums.Count; j++)
            {
                visited.Clear();
                int currFun = 1, currField = i;
                int k = (i + j) >= fieldNums.Count ? i + j - fieldNums.Count : i + j;

                while (true)
                {
                    if (fieldNums[currField] >= fieldNums[k] && !visited.Contains(fieldNums[k]))
                    {
                        break;
                    }
                    else
                    {
                        currFun++;
                        visited.Add(fieldNums[k]);
                        currField = k;
                        k = (k + j) >= fieldNums.Count ? k + j - fieldNums.Count : k + j;
                    }
                }
                if (currFun > maxFun)
                {
                    maxFun = currFun;
                }
            }
        }

        Console.WriteLine(maxFun);
    }
}