using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
        {
            int N = Convert.ToInt32(Console.ReadLine());
            string S = Console.ReadLine();
            string[] raw = new string[N];

            for (int i=1, int i < N, i++)
            {
              raw[i] =  Console.ReadLine();
                raw[i].TrimStart;
            }
            for (j=1, j<raw.Length, j ++)
            {
            Console.WriteLine(raw[j]);
        }
        }
}