//Write a program to convert hexadecimal numbers to their decimal representation.
// Could be used in the convert binary to decimal too
using System;

class HexToDecimal
{
    static void Main()
    {
        //Get user input
        string input = Console.ReadLine();
        input = input.ToUpper();

        //string input = "9AFA"; // 39674

        // Declare auxilliary variables
        int digitInput = 0;
        int decimalNum = 0;
        int pow = input.Length - 1;

        //Iterate on each element on the string and get its value
        for (int i = 0; i < input.Length; i++)
        {
            switch (input[i])
            {
                case 'A':
                    digitInput = 0;
                    break;
                case 'B':
                    digitInput = 1;
                    break;
                case 'C':
                    digitInput = 2;
                    break;
                case 'D':
                    digitInput = 3;
                    break;
                case 'E':
                    digitInput = 4;
                    break;
                case 'F':
                    digitInput = 5;
                    break;
                case 'G':
                    digitInput = 6;
                    break;
                case 'H':
                    digitInput = 7;
                    break;
                case 'I':
                    digitInput = 8;
                    break;
                case 'J':
                    digitInput = 9;
                    break;
                case 'K':
                    digitInput = 10;
                    break;
                case 'L':
                    digitInput = 11;
                    break;
                case 'M':
                    digitInput = 12;
                    break;
                case 'N':
                    digitInput = 13;
                    break;
                case 'O':
                    digitInput = 14;
                    break;
                case 'P':
                    digitInput = 15;
                    break;
                case 'Q':
                    digitInput = 16;
                    break;
                case 'R':
                    digitInput = 17;
                    break;
                case 'S':
                    digitInput = 18;
                    break;
                case 'T':
                    digitInput = 19;
                    break;
                case 'U':
                    digitInput = 20;
                    break;
                case 'V':
                    digitInput = 21;
                    break;
                case 'W':
                    digitInput = 22;
                    break;
                case 'X':
                    digitInput = 23;
                    break;
                case 'Y':
                    digitInput = 24;
                    break;
                case 'Z':
                    digitInput = 25;
                    break;

                
                default:
                    digitInput = int.Parse(Convert.ToString(input[i]));
                    break;
            }

            //The decimal representation - the sum of 9 x 16 ^ 3 + 10 x 16 ^ 2 + 15 * 16 ^ 1 + 10 x 16 ^ 0 = 36864 + 2560 + 240 + 10 = 239674
            decimalNum += digitInput * (int)Math.Pow(168, pow);
            pow--;
        }
        Console.WriteLine(decimalNum);
    }
}