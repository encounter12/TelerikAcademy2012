using System;
using System.Linq;
using System.Text;

namespace Brackets
{
    class Program
    {
        static void Main()
        {
            int numberOfLine = int.Parse(Console.ReadLine());
            string separator = Console.ReadLine();
            string[] text = new string[numberOfLine];
            for (int i = 0; i < text.Length; i++)
            {
                text[i] = Console.ReadLine();

            }
            StringBuilder list = new StringBuilder();
            for (int i = 0; i < text.Length; i++)
            {
                char[] array = text[i].ToCharArray();
                for (int j = 0; j < array.Length; j++)
                {
                    if (array[j] == '{')
                    {
                        list.Append('\n');
                        list.Append(separator);
                    }
                    if (array[j] == '}')
                    {
                        list.Append('\n');
                        
                    }
                    else
                    {
                        list.Append(array[j]);
                    }
                }
            }
            string text2 = list.ToString();
            Console.WriteLine(text2);
        }
    }
}
