using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class JoroTheRabbit
{
    static void Main()
    {
        string input = Console.ReadLine();

        string[] inputSplited = input.Split(',');

        List<int> inputArr = new List<int>();
        for (int i = 0; i < inputSplited.Length; i++)
        {
            inputArr.Add(int.Parse(inputSplited[i].Trim()));
        }

        int finalResult = 0;
        for (int i = 0; i < inputArr.Count - 1; i++)//стартира от всяко число
        {
            int result = 0;
            int counter = 0;
            for (int j = i; counter < inputArr.Count - 1; j++)
            {
                if (j + 1 > inputArr.Count - 1)
                {
                    if (inputArr[(j + 1) - (inputArr.Count - 1)] > inputArr[j - (inputArr.Count - 1)])
                    {
                        result++;
                    }
                }
                else
                {
                    if (inputArr[j + 1] > inputArr[j])
                    {
                        result++;
                    }
                }
                counter++;
            }
            if (result > finalResult)
            {
                finalResult = result;
            }
        }
        Console.WriteLine(finalResult);
    }
}
