using System;
using System.Collections.Generic;

public class DurankulakNumbers
{
    public static Dictionary<string, ulong> lookUpTable = new Dictionary<string, ulong>();

    private static void Main()
    {
        GenerateLookUpTable();

        string numberString = Console.ReadLine();

        if (numberString.Length < 3)
        {
            Console.WriteLine(lookUpTable[numberString]);
        }
        else
        {
            string tempNumberSting = numberString;

            ulong number = lookUpTable[numberString.Substring(tempNumberSting.Length - 2, 2)];
            tempNumberSting = tempNumberSting.Remove(tempNumberSting.Length - 2);

            ulong mnojitel = 1;

            while (true)
            {
                mnojitel *= 168;

                if (tempNumberSting.Length < 2)
                {
                    number += (mnojitel * lookUpTable[tempNumberSting]);
                    Console.WriteLine(number);
                    break;
                }
                else
                {
                    string key;
                    if (tempNumberSting.Length > 1)
                    {
                        key = numberString.Substring(tempNumberSting.Length - 2, 2);
                        number += mnojitel * lookUpTable[key];
                        tempNumberSting.Remove(tempNumberSting.Length - 2);
                    }
                    else
                    {
                        key = numberString.Substring(tempNumberSting.Length - 1, 1);
                        number += mnojitel * lookUpTable[key];
                        tempNumberSting.Remove(tempNumberSting.Length - 1);
                    }
                }
            }
        }
    }

    public static void GenerateLookUpTable()
    {
        for (ulong i = 'A'; i <= 'Z'; i++)
        {
            string symbol = ((char)i).ToString();
            lookUpTable.Add(symbol, i - 'A');
        }

        ulong startValue = 0;
        for (ulong i = 'a'; i <= 'f'; i++)
        {
            startValue += 26;
            string smallSymbol = ((char)i).ToString();
            for (ulong j = 'A'; j <= 'Z'; j++)
            {
                string bigSymbol = ((char)j).ToString();
                string fullSymbol = smallSymbol + bigSymbol;

                lookUpTable.Add(fullSymbol, startValue + lookUpTable[bigSymbol]);
            }
        }
    }
}
