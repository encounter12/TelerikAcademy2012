using System;
using System.Text;
using System.Numerics;

class DurankulakNumbers
{
    static BigInteger Conversion(string number)
    {
        BigInteger result = 0;
        switch (number)
        {
            case "A": result = 0;break ;
            case "B": result = 1; break;
            case "C": result = 2; break;
            case "D": result = 3; break;
            case "E": result = 4; break;
            case "F": result = 5; break;
            case "G": result = 6; break;
            case "H": result = 7; break;
            case "I": result = 8; break;
            case "J": result = 9; break;
            case "K": result = 10; break;
            case "L": result = 11; break;
            case "M": result = 12; break;
            case "N": result = 13; break;
            case "O": result = 14; break;
            case "P": result = 15; break;
            case "Q": result = 16; break;
            case "R": result = 17; break;
            case "S": result = 18; break;
            case "T": result = 19; break;
            case "U": result = 20; break;
            case "V": result = 21; break;
            case "W": result = 22; break;
            case "X": result = 23; break;
            case "Y": result = 24; break;
            case "Z": result = 25; break;
            case "aA": result = 26; break;
            case "aB": result = 27; break;
            case "aC": result = 28; break;
            case "aD": result = 29; break;
            case "aE": result = 30; break;
            case "aF": result = 31; break;
            case "aG": result = 32; break;
            case "aH": result = 33; break;
            case "aI": result = 34; break;
            case "aJ": result = 35; break;
            case "aK": result = 36; break;
            case "aL": result = 37; break;
            case "aM": result = 38; break;
            case "aN": result = 39; break;
            case "aO": result = 40; break;
            case "aP": result = 41; break;
            case "aQ": result = 42; break;
            case "aR": result = 43; break;
            case "aS": result = 44; break;
            case "aT": result = 45; break;
            case "aU": result = 46; break;
            case "aV": result = 47; break;
            case "aW": result = 48; break;
            case "aX": result = 49; break;
            case "aY": result = 50; break;
            case "aZ": result = 51; break;
            case "bA": result = 52; break;
            case "bB": result = 53; break;
            case "bC": result = 54; break;
            case "bD": result = 55; break;
            case "bE": result = 56; break;
            case "bF": result = 57; break;
            case "bG": result = 58; break;
            case "bH": result = 59; break;
            case "bI": result = 60; break;
            case "bJ": result = 61; break;
            case "bK": result = 62; break;
            case "bL": result = 63; break;
            case "bM": result = 64; break;
            case "bN": result = 65; break;
            case "bO": result = 66; break;
            case "bP": result = 67; break;
            case "bQ": result = 68; break;
            case "bR": result = 69; break;
            case "bS": result = 70; break;
            case "bT": result = 71; break;
            case "bU": result = 72; break;
            case "bV": result = 73; break;
            case "bW": result = 74; break;
            case "bX": result = 75; break;
            case "bY": result = 76; break;
            case "bZ": result = 77; break;
            case "cA": result = 78; break;
            case "cB": result = 79; break;
            case "cC": result = 80; break;
            case "cD": result = 81; break;
            case "cE": result =82; break;
            case "cF": result = 83; break;
            case "cG": result = 84; break;
            case "cH": result = 85; break;
            case "cI": result = 86; break;
            case "cJ": result = 87; break;
            case "cK": result = 88; break;
            case "cL": result = 89; break;
            case "cM": result = 90; break;
            case "cN": result = 91; break;
            case "cO": result = 92; break;
            case "cP": result = 93; break;
            case "cQ": result = 94; break;
            case "cR": result = 95; break;
            case "cS": result = 96; break;
            case "cT": result = 97; break;
            case "cU": result = 98; break;
            case "cV": result = 99; break;
            case "cW": result = 100; break;
            case "cX": result = 101; break;
            case "cY": result = 102; break;
            case "cZ": result = 103; break;
            case "dA": result = 104; break;
            case "dB": result = 105; break;
            case "dC": result = 106; break;
            case "dD": result = 107; break;
            case "dE": result =108; break;
            case "dF": result = 109; break;
            case "dG": result =110; break;
            case "dH": result = 111; break;
            case "dI": result = 112; break;
            case "dJ": result = 113; break;
            case "dK": result = 114; break;
            case "dL": result = 115; break;
            case "dM": result = 116; break;
            case "dN": result = 117; break;
            case "dO": result =118; break;
            case "dP": result = 119; break;
            case "dQ": result = 120; break;
            case "dR": result = 121; break;
            case "dS": result = 122; break;
            case "dT": result = 123; break;
            case "dU": result = 124; break;
            case "dV": result = 125; break;
            case "dW": result = 126; break;
            case "dX": result = 127; break;
            case "dY": result = 128; break;
            case "dZ": result = 129; break;
            case "eA": result = 130; break;
            case "eB": result = 131; break;
            case "eC": result = 132; break;
            case "eD": result = 133; break;
            case "eE": result = 134; break;
            case "eF": result = 135; break;
            case "eG": result = 136; break;
            case "eH": result = 137; break;
            case "eI": result = 138; break;
            case "eJ": result = 139; break;
            case "eK": result = 140; break;
            case "eL": result = 141; break;
            case "eM": result = 142; break;
            case "eN": result = 143; break;
            case "eO": result = 144; break;
            case "eP": result = 145; break;
            case "eQ": result = 146; break;
            case "eR": result = 147; break;
            case "eS": result = 148; break;
            case "eT": result = 149; break;
            case "eU": result = 150; break;
            case "eV": result = 151; break;
            case "eW": result = 152; break;
            case "eX": result = 153; break;
            case "eY": result = 154; break;
            case "eZ": result = 155; break;
            case "fA": result = 156; break;
            case "fB": result = 157; break;
            case "fC": result = 158; break;
            case "fD": result = 159; break;
            case "fE": result = 160; break;
            case "fF": result = 161; break;
            case "fG": result = 162; break;
            case "fH": result = 163; break;
            case "fI": result = 164; break;
            case "fJ": result = 165; break;
            case "fK": result = 166; break;
            case "fL": result = 167; break;
        }
        return result;
    }

    static void Main()
    {
        string durankulak = Console.ReadLine();
        //Console.WriteLine( Conversion(durankulak));
        BigInteger currentResult = 0;
        BigInteger totalResult = 0;
        StringBuilder buffer=new StringBuilder();

        if (durankulak.Length < 3)
        {
            Console.WriteLine(Conversion(durankulak));
        }
        else
        {
            for (int i = 0; i < durankulak.Length; i++)
            {
                char checker = durankulak[i];

                if (char.IsUpper(checker))
                {
                    currentResult = Conversion(Convert.ToString(checker));
                    currentResult = 168 * currentResult;
                    totalResult += currentResult;
                    if (i < durankulak.Length - 2)
                    {
                        totalResult = (BigInteger)Math.Pow((double)totalResult,(durankulak.Length - (2 + i)));

                    }

                    
                    //currentResult += totalResult;
                }
                else
                {
                    buffer.Append(durankulak[i]);
                    buffer.Append(durankulak[i + 1]);
                    i++;
                    currentResult = Conversion(Convert.ToString(buffer));
                    buffer.Clear() ;
                    totalResult += currentResult;

                    if (i<durankulak.Length-2)
                    {
                        totalResult = (BigInteger)Math.Pow((double)totalResult, durankulak.Length-(2+i));

                    }

                }
               
            }
            Console.WriteLine(totalResult);
        }
    }
}
