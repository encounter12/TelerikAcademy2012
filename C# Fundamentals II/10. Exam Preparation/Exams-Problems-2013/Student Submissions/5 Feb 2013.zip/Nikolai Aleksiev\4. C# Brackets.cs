using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

class Brackets
{
    static StringBuilder result = new StringBuilder();
    static string indent = null;
    static int indentCount = 0;
    static void SetIndent()
    {
        for (int i = 0; i < indentCount; i++)
        {
            result.Append(indent);
        }
    }
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        indent = Console.ReadLine();
        string[] input = new string[n];
        for (int i = 0; i < n; i++)
        {
            input[i] = Console.ReadLine();
        }
        int startIndex = 0;
        for (int i = 0; i < n; i++)
        {
            input[i] = input[i].Trim();
            if (input[i] != "")
            {
                string s = System.Text.RegularExpressions.Regex.Replace(input[i], @"\s{2,}", " ");
                startIndex = 0;
                //SetIndent();
                int openBrackets = 0;
                int closeBrackets = 0;
                while (openBrackets != -1 || closeBrackets != -1)
                {
                    openBrackets = s.IndexOf('{', startIndex);
                    closeBrackets = s.IndexOf('}', startIndex);
                    if ((openBrackets != -1 && openBrackets < closeBrackets) || (openBrackets != -1 && closeBrackets == -1))
                    {
                        if (openBrackets - startIndex > 0)
                        {
                            SetIndent();
                            result.Append(s.Substring(startIndex, openBrackets - startIndex).Trim());
                            result.AppendLine();
                            SetIndent();
                            result.Append('{');
                        }
                        else
                        {
                            SetIndent();
                            result.Append('{');
                        }
                        if (openBrackets < s.Length - 1)
                        {
                            result.AppendLine();
                            startIndex = openBrackets + 1;
                            indentCount++;
                        }
                        else
                        {
                            if (i < n -1)
                            {
                                result.AppendLine();
                                indentCount++;
                            }
                            break;
                        }
                        

                        
                    }
                    else if ((closeBrackets != -1 && closeBrackets < openBrackets) || (closeBrackets != -1 && openBrackets == -1))
                    {
                        if (closeBrackets - startIndex > 0)
                        {
                            SetIndent();
                            result.Append(s.Substring(startIndex, closeBrackets - startIndex).Trim());
                            result.AppendLine();
                            indentCount--;
                            SetIndent();
                            result.Append('}');
                        }
                        else
                        {
                            indentCount--;
                            SetIndent();
                            result.Append('}');
                        }
                        if (closeBrackets < s.Length - 1)
                        {
                            result.AppendLine();
                            startIndex = closeBrackets + 1;
                        }
                        else
                        {
                            if (i < n - 1)
                            {
                                result.AppendLine();
                            }
                            break;
                        }
                        
                    }
                    else
                    {
                        SetIndent();
                        result.Append(s).AppendLine();
                    }
                }
                
            }
        }
        Console.WriteLine(result);
    }
}
