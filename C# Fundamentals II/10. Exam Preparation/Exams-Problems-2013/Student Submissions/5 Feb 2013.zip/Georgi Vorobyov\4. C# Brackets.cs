using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brackets
{
    class StripComments
    {
        string file;
        StringBuilder result = new StringBuilder();
        string indent;
        char specialSymbol;
        int openBracketsCount = 0;

        public StripComments(string file, string indent)
        {
            this.indent = indent;
            this.specialSymbol = indent[indent.Length - 1];
            this.file = file;
        }

        public void StripComment()
        {
            bool isFoundedSpace = false;
            bool bracket = false;
            bool startWithSpace = false;
            bool lastSymbolIsNewLine = false;
            bool start = true;

            for (int i = 0, l = file.Length; i < l; i++)
            {
                char c = file[i];
                if ((file[i] == '\n' || file[i] == ' ') && start)
                {
                    continue;
                }
                start = false;

                if (file[i] == '\n')
                {
                    lastSymbolIsNewLine = true;
                    result.AppendLine();
                    continue;
                }

                //if (lastSymbolIsNewLine && file[i] == ' ')
                //{
                //    continue;
                //}

                //imalo e skoba,a sled neq spaces. Trqbwa da bydat propusnati
                if (bracket && file[i] == ' ')
                {
                    continue;
                }
                bracket = false;

                if (isFoundedSpace)
                {
                    if (file[i] == ' ')
                    {
                        continue;
                    }
                }

                if (!isFoundedSpace)
                {
                    if (file[i] == ' ')
                    {
                        result.Append(' ');
                        isFoundedSpace = true;
                        continue;
                    }
                }
                isFoundedSpace = false;

                //Ako e namerena skoba i koq e tq pod nomer;
                if (file[i] == '{')
                {
                    if (i - 1 >= 0)
                    {
                        //predi6niq simwol e razli4en ot now red i predi6niq simwol e razli4en
                        if (file[i - 1] != specialSymbol && file[i - 1] != '\n')
                        {
                            result.AppendLine();
                        }
                    }

                    result.AppendLine(Indent() + "{");
                    openBracketsCount++;
                    bracket = true;
                    continue;
                }

                //zatwarq6ta skoba
                if (file[i] == '}')
                {
                    if (i - 1 >= 0)
                    {
                        //predi6niq simwol e razli4en ot now red i predi6niq simwol e razli4en
                        if (file[i - 1] != specialSymbol && file[i - 1] != '\n')
                        {
                            result.AppendLine();
                        }
                    }
                    openBracketsCount--;
                    result.AppendLine(Indent() + "}");
                    //now red
                    continue;
                }

                if (file[i] == '\n')
                {
                    if (i == 0)
                    {
                        continue; //ima prazen red na pyrwa poziciq
                    }
                    else if (i - 1 >= 0)
                    {
                        if (file[i - 1] == '{' || file[i -1] == '}')
                        {
                            continue;
                        }
                    }
                }

                if (i - 1 >= 0)
                {
                    if (file[i - 1] == '\n' || result[result.Length - 1] == '\n')
                    {
                        result.Append(Indent());
                    }
                }
                result.Append(file[i]);
            }

            this.StripEmptyLines();
        }

        string Indent()
        {
            StringBuilder currIndent = new StringBuilder();

            for (int i = 0; i < openBracketsCount; i++)
            {
                currIndent.Append(this.indent);
            }

            return currIndent.ToString();
        }

        private void StripEmptyLines()
        {
            string[] result = this.result.ToString().Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
                    char[] array = new char[this.indent.Length + 2];
            array[this.indent.Length + 1] =  '\n';
            array[this.indent.Length + 1] =  ' ';

            for (int i = 0; i < result.Length - 1; i++)
            {
                if (!string.IsNullOrWhiteSpace(result[i]))
                {
                    if (result[i].TrimStart(array) != "")
                    {
                        Console.WriteLine(result[i].TrimEnd(' '));
                    }
                }
            }
            Console.WriteLine(result[result.Length - 1].TrimEnd(new char [] {' ', '\n'}));
            
        }
    }

    class Brackets
    {

        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            string indent = Console.ReadLine();
            string[] lines = new string[n];
            StringBuilder input = new StringBuilder();

            for (int i = 0; i < n; i++)
            {
                lines[i] = Console.ReadLine().Trim();//Trimwam

                if (string.IsNullOrWhiteSpace(lines[i]))
                {
                    lines[i] = null;
                }
            }

            StripComments cmt = new StripComments(String.Join("\n", lines), indent);

            cmt.StripComment();


        }
    }
}
