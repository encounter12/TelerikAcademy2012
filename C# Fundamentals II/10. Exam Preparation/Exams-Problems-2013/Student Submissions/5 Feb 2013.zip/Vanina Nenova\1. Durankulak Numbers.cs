using System;

class Program
{
    static void Main()
    {
        string input = Console.ReadLine();
        Return(input);
    }
    static void Return(string input)
    {
        string[] capitalLetters = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                                    "aA", "aB", "aC", "aD", "aE", "aF", "aG", "aH", "aI", "aJ", "aK", "aL", "aM", "aN", "aO", "aP", "aQ", "aR", "aS", "aT", "aU", "aV", "aW", "aX", "aY", "aZ",
                                    "bA", "bB", "bC", "bD", "bE", "bF", "bG", "bH", "bI", "bJ", "bK", "bL", "bM", "bN", "bO", "bP", "bQ", "bR", "bS", "bT", "bU", "bV", "bW", "bX", "bY", "bZ",
                                    "cA", "cB", "cC", "cD", "cE", "cF", "cG", "cH", "cI", "cJ", "cK", "cL", "cM", "cN", "cO", "cP", "cQ", "cR", "cS", "cT", "cU", "cV", "cW", "cX", "cY", "cZ",
                                    "dA", "dB", "dC", "dD", "dE", "dF", "dG", "dH", "dI", "dJ", "dK", "dL", "dM", "dN", "dO", "dP", "dQ", "dR", "dS", "dT", "dU", "dV", "dW", "dX", "dY", "dZ",
                                    "eA", "eB", "eC", "eD", "eE", "eF", "eG", "eH", "eI", "eJ", "eK", "eL", "eM", "eN", "eO", "eP", "eQ", "eR", "eS", "eT", "eU", "eV", "eW", "eX", "eY", "eZ",
                                    "fA", "fB", "fC", "fD", "fE", "fF", "fG", "fH", "fI", "fJ", "fK", "fL", "fM", "fN", "fO", "fP", "fQ", "fR", "fS", "fT", "fU", "fV", "fW", "fX", "fY", "fZ"
                                  };
        string[] letters = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        for (int i = 0; i < input.Length; i++)
        {
            for (int j = 0; j < capitalLetters.Length; j++)
            {
                if (char.IsUpper(input[i]) && i == 0 && input == capitalLetters[j])
                {
                    Console.WriteLine(j);
                }
                if (char.IsLower(input[i]) && char.IsUpper(input[i + 1]) && input == capitalLetters[j])
                {
                    Console.WriteLine(j);
                }
                for (int k = 0; k < letters.Length; k++)
                {
                    if (char.IsUpper(input[0]) && char.IsLower(input[i]) && char.IsUpper(input[i + 1]) && input.Trim(input[i], input[i + 1]) == letters[k] && input.Trim(input[0]) == capitalLetters[j])
                    {
                        Console.WriteLine((k * 168) + j);
                    }
                }
            }
        }          
    }
}

