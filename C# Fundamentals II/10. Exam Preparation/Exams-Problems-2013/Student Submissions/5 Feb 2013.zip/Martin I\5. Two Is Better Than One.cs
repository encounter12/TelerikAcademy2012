using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
         //   first task input
            string[] range = Console.ReadLine().Split();

            //second task input
            char[] separators = new char[] { ',', ' ' };
            string[] input = Console.ReadLine().Split(separators, StringSplitOptions.RemoveEmptyEntries);
            int[] numbers = new int[input.Length];
            for (int i = 0; i < input.Length; i++)
            {
                numbers[i] = int.Parse(input[i]);
            }

            double percentile = double.Parse(Console.ReadLine());
            //end of inputs


            //first task
            BigInteger luckyNumbersCounter = 0;
            for (BigInteger i = BigInteger.Parse(range[0]) + 1; i <= BigInteger.Parse(range[1]) - 1; i++)
            {
                bool isLuckyNumber = true;
                BigInteger currentLuckyNumber = i;

                BigInteger reverse = 0;
                int power = currentLuckyNumber.ToString().Length;
                while (currentLuckyNumber != 0)
                {
                    BigInteger remainder = currentLuckyNumber % 10;
                    if (remainder != 3 && remainder != 5)
                    {
                        isLuckyNumber = false;
                        break;
                    }
                    currentLuckyNumber /= 10;
                    reverse += remainder * (int)Math.Pow(10, power);
                    power--;
                }
                if (isLuckyNumber)
                {   
                    luckyNumbersCounter++;
                }
            }
            
            if (BigInteger.Parse(range[0]) <= 10)
            {
                luckyNumbersCounter -= 2;
            }
            Console.WriteLine(luckyNumbersCounter);
            //end of first task

            //second task
            
            double percents = (double)numbers.Length * (percentile / 100.0d);
            Array.Sort(numbers);

            int smaller = int.MaxValue;
            for (int i = 0; i < numbers.Length; i++)
            {
                int counterCurrentSmallers = 0;
                for (int j = 0; j < numbers.Length; j++)
                {
                    if (numbers[i] >= numbers[j] && i != j)
                    {
                        counterCurrentSmallers++;
                        if (counterCurrentSmallers >= percents && numbers[i] <= smaller)
                        {
                            smaller = numbers[i] - 1;
                            break;
                        }
                    }
                }
            }


            Console.WriteLine(smaller);
        }
    }
}
