using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class Program
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        string ident = Console.ReadLine();
        List<string> input = new List<string>(n);
        for (int i = 1; i <= n; i++)
        {
            string line = Console.ReadLine();
            if (line != string.Empty && line.Trim(' ')!="")
            {
                input.Add(line.Trim(' '));
            }
        }

        StringBuilder output = new StringBuilder();
        int mult = 0;
        foreach (string codeLine in input)
        {
            foreach (char c in codeLine)
            {
                if (c == '{')
                {
                    //add identation
                    output.Append("\r\n");
                    for (int z = 1; z <= mult; z++)
                    {
                        output.Append(ident);
                    }
                    
                    output.Append(c);
                    output.Append("\r\n");
                    mult++;
                }
                else if(c != '{' && c!='}')
                {
                    //add identation
                    for (int z = 1; z <= mult; z++)
                    {
                        output.Append(ident);
                    }
                    output.Append(c);
                }
                else if (c == '}')
                {
                    //add identation
                    mult--;
                    for (int z = 1; z <= mult; z++)
                    {
                        output.Append(ident);
                    }
                    output.Append(c);
                    output.Append("\r\n");
                    
                }
            }
            output.Append("\r\n");
        }
        Console.WriteLine(output.ToString().Trim(new char[] {'\r', '\n'}));
    }
}

