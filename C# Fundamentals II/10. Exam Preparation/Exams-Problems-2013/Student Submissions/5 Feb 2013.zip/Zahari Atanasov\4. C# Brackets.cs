using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brackets_and_such
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder code = new StringBuilder();
            int linesCount = int.Parse(Console.ReadLine());
            string indent = Console.ReadLine();

            for (int i = 1; i <= linesCount; i++)
            {
                string line = Console.ReadLine();
               
                for (int j = 0; j < line.Length; j++)
                {

                    if ((i != 1) && (line[j] == '{' || line[j] == '}'))
                    {
                        code.Insert(j - 1, indent);
                    }
                    if ((line[j] == ' ') && (line[j - 1] == ' '))
                    {
                        code.Remove(line[j-1], 1);
                    }
                    if (i == linesCount - 1)
                    {
                        if (line[j]!='}')
                        {
                            code.Append("\n");
                            code.Append('}');
                        }
                    }
                }
                if (i == 1)
                {
                    code.Insert(0, '{');
                    code.Append("\n");
                }
            }

            Console.WriteLine(code);
        }
    }
}
