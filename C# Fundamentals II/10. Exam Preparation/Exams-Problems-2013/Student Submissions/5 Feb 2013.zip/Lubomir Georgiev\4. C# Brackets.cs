using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brackets
{
    class Program
    {

        static void PrintSpecial(string special, int deep)
        {
            for (int i = 0; i < deep; i++)
            {
                Console.Write(special);
            }
        }
        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            int linesNumber = int.Parse(line);
            string specSym = Console.ReadLine();
            List<string> linesOfCode = new List<string>();

            for (int i = 0; i < linesNumber; i++)
            {
                linesOfCode.Add(Console.ReadLine());
            }
            int deepness = 0;
            char lastChar = '>';
            bool first = true;
            foreach (string lineOfCode in linesOfCode)
            {
                for (int i = 0; i < lineOfCode.Length; i++)
                {
                    if (lineOfCode[i] == '{')
                    {
                        if (lastChar != '{' && lastChar != '}')
                        {
                            if (!first)
                            {
                                Console.WriteLine();
                            }
                            else
                            {
                                first = false;
                            }
                            PrintSpecial(specSym, deepness);
                        }
                        if (lastChar == '{' || lastChar == '}')
                        {
                            Console.WriteLine();
                            PrintSpecial(specSym, deepness);
                        }
                        Console.Write("{");
                        deepness++;
                    }
                    else if (lineOfCode[i] == '}')
                    {
                        if (lastChar != '{' && lastChar != '}')
                        {
                            deepness--;
                            Console.WriteLine();
                            PrintSpecial(specSym, deepness);
                        }
                        else
                        {
                            deepness--;
                            Console.WriteLine();
                            PrintSpecial(specSym, deepness);
                        }
                        Console.Write("}");
                    }
                    else
                    {
                        if (lastChar == '{' || lastChar == '}')
                        {
                            Console.WriteLine();
                            PrintSpecial(specSym, deepness);
                        }

                        if ((lastChar == ' ' && lineOfCode[i] == ' ') || (lineOfCode[i]==' ' && i==0))
                        {

                        }
                        else
                        {
                            if ((lastChar == '{' || lastChar == '}') && lineOfCode[i] == ' ')
                            {
                            }
                            else
                            {
                                Console.Write(lineOfCode[i]);
                            }
                        }
                    }
                    lastChar = lineOfCode[i];
                }
                if (lastChar != '{' && lastChar != '}')
                {
                    Console.WriteLine();
                    PrintSpecial(specSym, deepness);
                }
            }
        }
    }
}
