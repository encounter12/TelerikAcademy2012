using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace problem1
{
    class Program
    {
        static void Main(string[] args)
        {
            long res = 0;
            string str = Console.ReadLine();
            char[] digits = new char[16];
            long result=0;
            List<long> did=new List<long>();
         
            for (int i = 0; i <str.Length; i++)
            {
                digits[i] = str[str.Length - 1 - i]; 
            }
            /*
            for (int i = 0; i < digits.Length; i++)
            {
                if (digits[i] > 90) result += (26)*(digits[i] - 96);
                if (digits[i] < 90) result += (digits[i]-65);
                if (i == 2&&digits[i]!=65)
                {
                   result += 167 * (digits[i] - 65);
                }
 
                if (i == 3 && digits[i] != 65)
                {
                   result += 26*167 * (digits[i] - 96);
                  
                }
                if (i == 4 && digits[i] != 65)
                {
                    result += 26 * 167 * 26 * 167 * (digits[i] - 65);
 
                }
                if (i == 5 && digits[i] != 65)
                {
                    result += 26*26*26 * 167 * (digits[i] - 96);
 
                }
            }
 
            Console.WriteLine(result);*/
            
                for (int j = 0; j < 2; j++)
                {
 
                    if (digits[j] > 90) result += (26) * (digits[j] - 96);
                    if (digits[j] < 90 && digits[j] > 60) result += (digits[j] - 65);
                   
                }
                did.Add(result);
                result = 0;
                for (int j = 2; j < 4; j++)
                {
 
                    if (digits[j] > 90) result += (26) * (digits[j] - 96);
                    if (digits[j] < 90 && digits[j] > 60) result += (digits[j] - 65);
                 //   result += 168;
                }
                did.Add(result*168);
                result = 0;
               for (int j = 4; j < 6; j++)
                {
                    
                    if (digits[j] > 90) result += (26) * (digits[j] - 96);
                    if (digits[j] < 90 && digits[j] > 64)
                    {
                        result += (digits[j] - 65);
               //         result += 168;
                    }
                }
               did.Add(result);
               result = 0;
               for (int j = 6; j < 8; j++)
               {
 
                   if (digits[j] > 90) result += (26) * (digits[j] - 96);
                   if (digits[j] < 90 && digits[j] > 64)
                   {
                       result += (digits[j] - 65);
                       //         result += 168;
                   }
               }
               did.Add(result);
               result = 0;
               for (int j = 8; j < 10; j++)
               {
 
                   if (digits[j] > 90) result += (26) * (digits[j] - 96);
                   if (digits[j] < 90 && digits[j] > 64)
                   {
                       result += (digits[j] - 65);
                       //         result += 168;
                   }
               }
               did.Add(result);
            foreach (var item in did)
            {
                res += item;
            }
            Console.WriteLine(res);
        }
    }
}