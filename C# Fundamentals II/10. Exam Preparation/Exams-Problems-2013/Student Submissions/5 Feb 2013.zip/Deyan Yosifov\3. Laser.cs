using System;
using System.Collections.Generic;

class Laser
{
    public class Point3D
    {
        public int x;
        public int y;
        public int z;

        public Point3D(int x, int y, int z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public static Point3D operator +(Point3D a, Point3D b)
        {
            return new Point3D(a.x + b.x, a.y + b.y, a.z + b.z);
        }

        public override bool Equals(object obj)
        {
            if (this == obj)
                return true;
            Point3D other = obj as Point3D;
            if (other == null)
                return false;
            if (!this.x.Equals(other.x))
                return false;
            if (!this.y.Equals(other.y))
                return false;
            if (!this.z.Equals(other.z))
                return false;
            return true;
        }

        public override int GetHashCode()
        {
            int prime = 83;
            int result = 1;
            unchecked
            {
                result = result * prime + this.x.GetHashCode();
                result = result * prime + this.y.GetHashCode();
                result = result * prime + this.z.GetHashCode();
            }
            return result;
        }

        public override string ToString()
        {
            return String.Format("({0}, {1}, {2})", this.x, this.y, this.z);
        }
    }

    static void Main()
    {
        int[] sizes = new int[3];
        Point3D current = new Point3D(0, 0, 0);
        Point3D vector = new Point3D(0, 0, 0);
        GetInput(sizes, current, vector);
        //GetSampleInput(sizes, current, vector);
        bool[, ,] visited = new bool[sizes[0], sizes[1], sizes[2]];
        MarkEdgesAsVisited(visited);
        bool playGame = true;

        while (playGame)
        {
            PlayMove(ref playGame, ref visited, ref current, ref vector);
        }

        Console.WriteLine("{0} {1} {2}", current.x + 1, current.y + 1, current.z + 1);      
    }

    private static void PlayMove(ref bool playGame, ref bool[, ,] visited, ref Point3D current, ref Point3D vector)
    {
        visited[current.x, current.y, current.z] = true;
        
        Point3D nextPoint = current + vector;
        ChangeVectorIfNecessary(ref nextPoint, ref vector, ref current, ref visited);

        if (CheckIfVisited(ref visited, ref nextPoint))
        {
            playGame = false;
        }
        else
        {
            current = nextPoint;
        }
    }

    private static void ChangeVectorIfNecessary(ref Point3D nextPoint, ref Point3D vector, ref Point3D current, ref bool[,,] visited)
    {
        if (nextPoint.x < 0 || nextPoint.x >= visited.GetLength(0))
        {
            vector.x *= -1;
        }
        if (nextPoint.y < 0 || nextPoint.y >= visited.GetLength(1))
        {
            vector.y *= -1;
        }
        if (nextPoint.z < 0 || nextPoint.z >= visited.GetLength(2))
        {
            vector.z *= -1;
        }

        nextPoint = current + vector;
    }

    private static bool CheckIfVisited(ref bool[, ,] visited, ref Point3D nextPoint)
    {
        return visited[nextPoint.x, nextPoint.y, nextPoint.z];
    }

    private static void MarkEdgesAsVisited(bool[, ,] visited)
    {
        int x = 0;
        while (x < visited.GetLength(0))
        {
            visited[x, 0, 0] = true;
            visited[x, visited.GetLength(1) - 1, 0] = true;

            visited[x, 0, visited.GetLength(2) - 1] = true;
            visited[x, visited.GetLength(1) - 1, visited.GetLength(2) - 1] = true;
            x++;
        }

        int y = 0;
        while (y < visited.GetLength(1))
        {
            visited[0, y, 0] = true;
            visited[visited.GetLength(0) - 1, y, 0] = true;

            visited[0, y, visited.GetLength(2) - 1] = true;
            visited[visited.GetLength(0) - 1, y, visited.GetLength(2) - 1] = true;
            y++;
        }

        for (int z = 1; z < visited.GetLength(2) - 1; z++)
        {
            visited[0, 0, z] = true;
            visited[visited.GetLength(0) - 1, 0, z] = true;
            visited[0, visited.GetLength(1) - 1, z] = true;
            visited[visited.GetLength(0) - 1, visited.GetLength(1) - 1, z] = true;
        }
    }

    private static void GetSampleInput(int[] sizes, Point3D current, Point3D vector)
    {
        string[] input = "5 10 5".Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < 3; i++)
        {
            sizes[i] = int.Parse(input[i]);
        }

        input = "2 6 3".Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        current.x = int.Parse(input[0]) - 1;
        current.y = int.Parse(input[1]) - 1;
        current.z = int.Parse(input[2]) - 1;

        input = "1 0 1".Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        vector.x = int.Parse(input[0]);
        vector.y = int.Parse(input[1]);
        vector.z = int.Parse(input[2]);
    }

    private static void PrintVisited(bool[, ,] visited)
    {
        for (int z = 0; z < visited.GetLength(2); z++)
        {
            Console.WriteLine("Level: {0}", z);
            for (int y = 0; y < visited.GetLength(1); y++)
            {
                for (int x = 0; x < visited.GetLength(0); x++)
                {
                    Console.Write("{0} ", visited[x, y, z] ? 1 : 0);
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }
    }

    private static void GetInput(int[] sizes, Point3D current, Point3D vector)
    {
        string[] input = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < 3; i++)
        {
            sizes[i] = int.Parse(input[i]);
        }

        input = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        current.x = int.Parse(input[0]) - 1;
        current.y = int.Parse(input[1]) - 1;
        current.z = int.Parse(input[2]) - 1;

        input = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        vector.x = int.Parse(input[0]);
        vector.y = int.Parse(input[1]);
        vector.z = int.Parse(input[2]);
    }


}
