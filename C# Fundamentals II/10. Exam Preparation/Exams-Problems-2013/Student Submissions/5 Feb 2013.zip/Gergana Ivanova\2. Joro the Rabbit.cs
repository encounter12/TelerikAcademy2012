using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Rabbit
{
    public static void Main(string[] args)
    {

        string input = Console.ReadLine();
        char[] cDividers = { ' ' };
        string[] segments = input.Split(cDividers);
        int[] array = new int[input.Length];

        for (int i = 0; i < segments.Length; i++)
        {
            array[i] = Int32.Parse(segments[i]);

        }
        int count = segments.Length;

        switch (count)
        {
            case 1:
                Console.Write("0");
                break;
            case 2:
                
                if(array[0]<array[1])
                    Console.Write("2");
                
                break;
            default: 
                break;

        }
        bool check = false;
        int xxx=array[0];
        for (int j = 0; j < segments.Length; j++)
        {
            if (array[j] == xxx)
                check = true;
        }
        if(check)
            Console.Write("1");
              
    }
   
}
