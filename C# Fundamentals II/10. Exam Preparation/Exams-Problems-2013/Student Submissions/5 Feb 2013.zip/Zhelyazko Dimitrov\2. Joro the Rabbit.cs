using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem2
{
    class Program
    {
        static void Main()
        {
            string input = Console.ReadLine();
            string[] terrainInput = input.Split(new char[] { ',' }, StringSplitOptions.None);
            short[] terrain = new short[terrainInput.Length];
            for (short i = 0; i < terrainInput.Length; i++)
            {
                terrain[i] = short.Parse(terrainInput[i]);
            }

            short maxJumps = 1;

            for (short i = 0; i < terrain.Length; i++)
            {
                short startIndex = i;
                short currentJumps = 1;
                for (short jump = 1; jump < terrain.Length; jump++)
                {
                    short currentIndex = (short)((startIndex + jump) % (terrain.Length));

                    while (terrain[currentIndex] > terrain[startIndex])
                    {
                        currentJumps++;
                        startIndex = currentIndex;
                        currentIndex = (short)((startIndex + jump) % (terrain.Length));
                    }

                    if (currentJumps > maxJumps)
                    {
                        maxJumps = currentJumps;
                    }

                    startIndex = i;
                    currentJumps = 1;
                }
            }
            Console.WriteLine(maxJumps);
        }
    }
}


