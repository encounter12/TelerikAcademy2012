using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laser
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] cub = Console.ReadLine().Split(' ');
            string[] point = Console.ReadLine().Split(' ');
            string[] direction = Console.ReadLine().Split(' ');

            int cubW = Convert.ToInt32(cub[0]);
            int cubH = Convert.ToInt32(cub[1]);
            int cubD = Convert.ToInt32(cub[2]);
            int startL = Convert.ToInt32(point[0]);
            int startT = Convert.ToInt32(point[1]);
            int startR = Convert.ToInt32(point[2]);
            int dirL = Convert.ToInt32(direction[0]);
            int dirT = Convert.ToInt32(direction[1]);
            int dirR = Convert.ToInt32(direction[2]);
            int nowL = startL;
            int nowT = startT;
            int nowR = startR;
            List<string> points = new List<string>();
            while (true)
            {
                if (nowL + dirL > cubW)
                {
                    dirL *= -1;
                }
                if (nowT + dirL > cubH)
                {
                    dirT *= -1;
                }
                if (nowR + dirL > cubD)
                {
                    dirR *= -1;
                }
                nowL += dirL;
                nowT += dirT;
                nowR += dirR;
                if (point.Contains(" " + nowL + nowR + nowT))
                {
                    nowL -= dirL;
                    nowT -= dirT;
                    nowR -= dirR;
                    Console.WriteLine(dirL + " " + dirT + " " + dirR);
                    break;
                }
                else
                {
                    points.Add(" " + nowL + nowR + nowT);
                }
            }
        }
    }
}
