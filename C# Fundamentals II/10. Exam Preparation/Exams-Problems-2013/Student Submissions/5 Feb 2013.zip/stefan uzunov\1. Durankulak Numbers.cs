using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace _1.Durankulak
{
    class Program
    {
        static void Main(string[] args)
        {
            string number = Console.ReadLine();
            
            List<string> numbersTable = GeneratenumbersTable();
            

            BigInteger result = 0;
            BigInteger counter = 1;
            for (int i = number.Length - 1; i >= 0; )
            {
                if (i - 1 >= 0 && char.IsLower(number[i - 1]))
                {
                    int val = numbersTable.IndexOf(number.Substring(i - 1, 2));

                    result += val * (BigInteger)(counter);
                    i -= 2;

                }
                else
                {
                    int val = numbersTable.IndexOf(number[i].ToString());

                    result += val * (BigInteger)(counter);


                    i--;
                }
                counter *= 168;

            }
            
            Console.WriteLine(result);            
            //Print(numbersTable);
        }

        private static void Print(List<string> numbersTable)
        {
            foreach (var item in numbersTable)
            {
                Console.WriteLine(item);
                
            }
        }

        private static List<string> GeneratenumbersTable()
        {
            string[] table = new string[168];
            for (int i = 65; i <= 90; i++)
            {

                table[i - 65] = ((char)i).ToString();

            }

            for (int i = 97; i < 102; i++)
            {
                for (int j = 65; j <= 90; j++)
                {

                    table[26 * (i - 97 + 1) + j - 65] = ((char)(i)).ToString() + ((char)(j)).ToString();
                }
            }

            for (int j = 65; j <= 76; j++)
            {
                table[26 * (102 - 97 + 1) + j - 65] = ((char)(102)).ToString() + ((char)(j)).ToString();
            }
            return table.ToList();
        }
    }
}
