using System;

class TwoTasks
{
    static void Main()
    {
        string input = Console.ReadLine();
        string[] list = Console.ReadLine().Split(',');
        int percent = int.Parse(Console.ReadLine());
        int cut = input.IndexOf(' ');
        string a = input.Substring(0, cut);
        string b = input.Substring(cut + 1);
        int maxLength = b.Length - a.Length;
        SolveTaskOne(a, maxLength);
        SolveTaskTwo(list, percent);
    }

    private static void SolveTaskTwo(string[] list, int percent)
    {
        int[] listOfNumbers = new int[list.Length];
        for (int i = 0; i < list.Length; i++)
        {
            listOfNumbers[i] = int.Parse(list[i]);
        }
        double limit = (percent * listOfNumbers.Length / 100);
        Console.WriteLine(findSmalestElement(listOfNumbers, limit)); 
    }

    static int findSmalestElement(int[] listOfNumbers, double limit)
    {
        Array.Sort(listOfNumbers, (a, b) => a.CompareTo(b));
        int index = (int)Math.Round(limit);
        return listOfNumbers[index-1];
    }

    private static void SolveTaskOne(string a, int maxLength)
    {
        if (maxLength == 0 && a.Length > 1)
        {
            Console.WriteLine("0");
        }
        else if (maxLength == 0 && a.Length == 1)
        {
            int bNumber = int.Parse(a);
            if (bNumber >= 5)
            {
                Console.WriteLine("2");
            }
            else
            {
                Console.WriteLine("1");
            }
        }
        else
        {
            Console.WriteLine(AllPalindrome(maxLength));
        }
    }


    static ulong AllPalindrome(int maxLength)
    {
        ulong result = 2;
        for (int i = 1; i <= maxLength; i++)
        {
            result += 1U << i;
        }
            return result;
    }
}