using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
 
class Program
{
 
    static string smallLetters = "*abcdef";
 
    static void Main()
    {
        string durankulakNumber = Console.ReadLine();
 
        int durankulakNumberLength = durankulakNumber.Length;
        int value = 0;
        int counter = 1;
 
        for (int i = durankulakNumberLength - 1; i >= 0; i--)
        {
            value += counter * (durankulakNumber[i] - 'A');
 
            if (i > 0)
            {
                int index = smallLetters.IndexOf(durankulakNumber[i - 1]);
 
                if (index >= 0)
                {
                    value += counter * 26 * index;
                    i--;
                }
 
            }
 
            counter *= 168;
        }
 
        Console.WriteLine(value);
    }
}