using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

class DurankulakNumbers
{
    private static BigInteger MakeInputBaseToBase10System(string number, int fromBase)
    {
        int digit = 0;
        BigInteger result = 0;      
        string temp = "";


        List<string> temporary = new List<string>();

        for (int i = 0; i < number.Length; i++)
        {
            temp += (char)number[i];

            if ((int)number[i] < 92)
            {
                temporary.Add(temp);

                //Console.WriteLine(temp);
                temp = "";
            }
        }

        


        int count = temporary.Count - 1;
        for (int i = 0; i < temporary.Count; i++)
			{

                //Console.WriteLine(count);
                    switch (temporary[i])
                    {
                        case "A": digit = 0; break;
                        case "B": digit = 1; break;
                        case "C": digit = 2; break;
                        case "D": digit = 3; break;
                        case "E": digit = 4; break;
                        case "F": digit = 5; break;
                        case "G": digit = 6; break;
                        case "H": digit = 7; break;
                        case "I": digit = 8; break;
                        case "J": digit = 9; break;
                        case "K": digit = 10; break;
                        case "L": digit = 11; break;
                        case "M": digit = 12; break;
                        case "N": digit = 13; break;
                        case "O": digit = 14; break;
                        case "P": digit = 15; break;
                        case "Q": digit = 16; break;
                        case "R": digit = 17; break;
                        case "S": digit = 18; break;
                        case "T": digit = 19; break;
                        case "U": digit = 20; break;
                        case "V": digit = 21; break;
                        case "W": digit = 22; break;
                        case "X": digit = 23; break;
                        case "Y": digit = 24; break;
                        case "Z": digit = 25; break;
                             
                        case "aA": digit = 26; break;
                        case "aB": digit = 27; break;
                        case "aC": digit = 28; break;
                        case "aD": digit = 29; break;
                        case "aE": digit = 30; break;
                        case "aF": digit = 31; break;
                        case "aG": digit = 32; break;
                        case "aH": digit = 33; break;
                        case "aI": digit = 34; break;
                        case "aJ": digit = 35; break;
                        case "aK": digit = 36; break;
                        case "aL": digit = 37; break;
                        case "aM": digit = 38; break;
                        case "aN": digit = 39; break;
                        case "aO": digit = 40; break;
                        case "aP": digit = 41; break;
                        case "aQ": digit = 42; break;
                        case "aR": digit = 43; break;
                        case "aS": digit = 44; break;
                        case "aT": digit = 45; break;
                        case "aU": digit = 46; break;
                        case "aV": digit = 47; break;
                        case "aW": digit = 48; break;
                        case "aX": digit = 49; break;
                        case "aY": digit = 50; break;
                        case "aZ": digit = 51; break;

                        case "bA": digit = 52; break;
                        case "bB": digit = 53; break;
                        case "bC": digit = 54; break;
                        case "bD": digit = 55; break;
                        case "bE": digit = 56; break;
                        case "bF": digit = 57; break;
                        case "bG": digit = 58; break;
                        case "bH": digit = 59; break;
                        case "bI": digit = 60; break;
                        case "bJ": digit = 61; break;
                        case "bK": digit = 62; break;
                        case "bL": digit = 63; break;
                        case "bM": digit = 64; break;
                        case "bN": digit = 65; break;
                        case "bO": digit = 66; break;
                        case "bP": digit = 67; break;
                        case "bQ": digit = 68; break;
                        case "bR": digit = 69; break;
                        case "bS": digit = 70; break;
                        case "bT": digit = 71; break;
                        case "bU": digit = 72; break;
                        case "bV": digit = 73; break;
                        case "bW": digit = 74; break;
                        case "bX": digit = 75; break;
                        case "bY": digit = 76; break;
                        case "bZ": digit = 77; break;

                        case "cA": digit = 78; break;
                        case "cB": digit = 79; break;
                        case "cC": digit = 80; break;
                        case "cD": digit = 81; break;
                        case "cE": digit = 82; break;
                        case "cF": digit = 83; break;
                        case "cG": digit = 84; break;
                        case "cH": digit = 85; break;
                        case "cI": digit = 86; break;
                        case "cJ": digit = 87; break;
                        case "cK": digit = 88; break;
                        case "cL": digit = 89; break;
                        case "cM": digit = 90; break;
                        case "cN": digit = 91; break;
                        case "cO": digit = 92; break;
                        case "cP": digit = 93; break;
                        case "cQ": digit = 94; break;
                        case "cR": digit = 95; break;
                        case "cS": digit = 96; break;
                        case "cT": digit = 97; break;
                        case "cU": digit = 98; break;
                        case "cV": digit = 99; break;
                        case "cW": digit = 100; break;
                        case "cX": digit = 101; break;
                        case "cY": digit = 102; break;
                        case "cZ": digit = 103; break;

                        case "dA": digit = 104; break;
                        case "dB": digit = 105; break;
                        case "dC": digit = 106; break;
                        case "dD": digit = 107; break;
                        case "dE": digit = 108; break;
                        case "dF": digit = 109; break;
                        case "dG": digit = 110; break;
                        case "dH": digit = 111; break;
                        case "dI": digit = 112; break;
                        case "dJ": digit = 113; break;
                        case "dK": digit = 114; break;
                        case "dL": digit = 115; break;
                        case "dM": digit = 116; break;
                        case "dN": digit = 117; break;
                        case "dO": digit = 118; break;
                        case "dP": digit = 119; break;
                        case "dQ": digit = 120; break;
                        case "dR": digit = 121; break;
                        case "dS": digit = 122; break;
                        case "dT": digit = 123; break;
                        case "dU": digit = 124; break;
                        case "dV": digit = 125; break;
                        case "dW": digit = 126; break;
                        case "dX": digit = 127; break;
                        case "dY": digit = 128; break;
                        case "dZ": digit = 129; break;

                        case "eA": digit = 130; break;
                        case "eB": digit = 131; break;
                        case "eC": digit = 132; break;
                        case "eD": digit = 133; break;
                        case "eE": digit = 134; break;
                        case "eF": digit = 135; break;
                        case "eG": digit = 136; break;
                        case "eH": digit = 137; break;
                        case "eI": digit = 138; break;
                        case "eJ": digit = 139; break;
                        case "eK": digit = 140; break;
                        case "eL": digit = 141; break;
                        case "eM": digit = 142; break;
                        case "eN": digit = 143; break;
                        case "eO": digit = 144; break;
                        case "eP": digit = 145; break;
                        case "eQ": digit = 146; break;
                        case "eR": digit = 147; break;
                        case "eS": digit = 148; break;
                        case "eT": digit = 149; break;
                        case "eU": digit = 150; break;
                        case "eV": digit = 151; break;
                        case "eW": digit = 152; break;
                        case "eX": digit = 153; break;
                        case "eY": digit = 154; break;
                        case "eZ": digit = 155; break;

                        case "fA": digit = 156; break;
                        case "fB": digit = 157; break;
                        case "fC": digit = 158; break;
                        case "fD": digit = 159; break;
                        case "fE": digit = 160; break;
                        case "fF": digit = 161; break;
                        case "fG": digit = 162; break;
                        case "fH": digit = 163; break;
                        case "fI": digit = 164; break;
                        case "fJ": digit = 165; break;
                        case "fK": digit = 166; break;
                        case "fL": digit = 167; break;

                    }

                    result += digit * Pow(count, fromBase);
                    count--;

            }      

        return result;
    }

    private static BigInteger Pow(int sqr, int numeralBase)
    {
        BigInteger result = 1;

        for (int i = 0; i < sqr; i++)
        {
            result = result * numeralBase;
        }

        return result;
    }

    static void Main()
    {
        string number = Console.ReadLine();
        string[] darankulakDigits = new string[168];

        int counter = 0;

//------------------------------------------------------------fills digits
        for (char i = 'A'; i <= 'Z'; i++)
        {
            darankulakDigits[counter] += i;
            counter++;
        }

        for (char i = 'a'; i <= 'e'; i++)
        {
            for (char k = 'A'; k <= 'Z'; k++)
            {
                darankulakDigits[counter] += (char)i + "" + (char)k;
                counter++;
            }
        }

        for (char i = 'f'; i <= 'f'; i++)
        {
            for (char k = 'A'; k <= 'L'; k++)
            {
                darankulakDigits[counter] += (char)i + "" + (char)k;
                counter++;
            }
        }


            //for (int i = 0; i < darankulakDigits.Length; i++)
            //{
            //    Console.WriteLine(darankulakDigits[i]);
            //}
        
        Console.WriteLine(MakeInputBaseToBase10System(number, 168));

    }
}
