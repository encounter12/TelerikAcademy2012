using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1.DurankulakNumbers
{
    class DurankulakNumbers
    {
        static void Main()
        {
            char[] capital = new char[26];
            char letter = 'A';
            capital[0] = 'A';
            char[] small = new char[26];
            char smallLetter = 'a';
            small[0]='a';

            string[] myInput = new string[16];
            StringBuilder sbInput = new StringBuilder();


            for (int indexA = 1; indexA < capital.Length; indexA++)
                {
                    letter += (char)1;
                    capital[indexA] = letter;
                }

            for (int indexA = 1; indexA < capital.Length; indexA++)
            {
                smallLetter += (char)1;
                small[indexA] = smallLetter;
            }
                Console.WriteLine();
            


            string input = Console.ReadLine();
            //string reversedInput = ReverseText(input);


            for (int index = 1; index < input.Length; index++)
            {
                char ch= input[index];
                char beffor = input[index-1];
                if (char.IsUpper(ch) && char.IsLower(beffor) )
                {


                    sbInput.Append(beffor);
                    sbInput.Append(ch);
                    sbInput.Append(",");
                }
                else
                {
                    sbInput.Append(input[index]);
                }
            }
            string[] codeText = sbInput.ToString().Split(new char[] {','}, StringSplitOptions.RemoveEmptyEntries);

            int length = codeText.Length;
            for (int i = 0; i < codeText.Length; i++)
            {
                if (codeText[i].Length>1)
                {
                    string tmp = codeText[i];
                    for (int j = 0; j < length; j++)
                    {
                        for (int s = 0; s < length; s++)
                        {
                            if (tmp[j]==small[s])
                            {
                                if (small[s]=='a')
                                {
                                    
                                }
                            }
                        }
                    }
                }
            }
            Console.WriteLine("20");






        }
       
    }
}
