using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Two_Is_Better_Than_One
{
    class Program
    {
        static void Main()
        {
            string taskOne = Console.ReadLine();
            string[] taskOneSplitted = taskOne.Split(' ');

            ulong a = ulong.Parse(taskOneSplitted[0]);
            ulong b = ulong.Parse(taskOneSplitted[1]);

            string taskTwo = Console.ReadLine();
            char[] punctuationMarks = new char[] { ' ', ','};
            string[] taskTwoSplitted = taskTwo.Split(punctuationMarks, StringSplitOptions.RemoveEmptyEntries);

            List<int> taskTwoNumbers = new List<int>();

            foreach (var item in taskTwoSplitted)
            {
                taskTwoNumbers.Add(int.Parse(item));
            }

            taskTwoNumbers.Sort();

            string percentile = Console.ReadLine();
            int p = int.Parse(percentile);

            int palindromeCount = 0;

            for (ulong i = a; i <= b; i++)
            {
                ulong temp = i;
                List<ulong> digits = new List<ulong>();
               
                for (int j = 0; j <= i.ToString().Length; j++)
                {
                    digits.Add(i % 10);
                    i = i / 10;
                }
               
                i = temp;

                digits.Reverse();

                for (int o = 0; o <= (digits.Count / 2); o++)
                {
                    bool isPalindrome = true;

                    if ((digits[o] == 3) || (digits[o] == 5))
                    {
                        if (digits[o] != digits[digits.Count - 1 - o])
                        {
                            isPalindrome = false;
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }

                    if (isPalindrome)
                    {
                        palindromeCount++;
                    }
                }
            }

            float percent = (taskTwoNumbers.Count / 100F) * p;

            Console.WriteLine(palindromeCount);
            if (taskTwoNumbers.Count % 2 == 0)
            {
                Console.WriteLine(taskTwoNumbers[(int)Math.Ceiling(percent)-1]);
            }
            else
	        {
                Console.WriteLine(taskTwoNumbers[(int)Math.Ceiling(percent)]);
	        }
            
        }
    }
}
