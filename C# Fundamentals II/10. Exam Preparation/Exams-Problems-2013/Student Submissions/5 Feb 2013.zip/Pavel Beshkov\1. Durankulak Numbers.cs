using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Numerics;
class Problem1
{
    static void Main()
    {
        int[,] chars = new int[7, 26];
        int value = 0;
        for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 26; j++)
            {
                if (i == 6 && j == 12)
                {
                    break;
                }
                chars[i, j] = value++;
            }
        }
        long pow = 1;
        BigInteger result = 0;
        string rawNumber = Console.ReadLine();
        char prevSymbol=' ';//= rawNumber[rawNumber.Length - 1];
        char lastSymbol = rawNumber[0];
        int secondIndex=3;// = prevSymbol - 'A';
        int firstIndex;// = rawNumber[rawNumber.Length - 2] - 'a';
        bool hadUpper = false;
        long add = 0;
        for (int i = rawNumber.Length - 1; i >= 0; i--)
        {
            lastSymbol = rawNumber[i];
            if (char.IsUpper(lastSymbol))
            {
                if (hadUpper)
                {
                    add = pow * chars[0, prevSymbol - 'A'];
                    result += add;
                    pow *= 168;
                }
                else
                {
                    secondIndex = lastSymbol - 'A';
                    hadUpper = true;
                }
            }              
            else
            {
                firstIndex = lastSymbol - 'a'+1;
                add = pow * chars[firstIndex, secondIndex];
                result += add;
                pow *= 168;
                hadUpper = false;
            }
            prevSymbol=lastSymbol;

        }
        if (char.IsUpper(lastSymbol))
        {
            result += chars[0, lastSymbol - 'A']*pow;
        }
        //else
        //{
        //    result+=chars[rawNumber[0]-'a',lastSymbol-'A']*pow;
        //}
        Console.WriteLine(result);
    }
}