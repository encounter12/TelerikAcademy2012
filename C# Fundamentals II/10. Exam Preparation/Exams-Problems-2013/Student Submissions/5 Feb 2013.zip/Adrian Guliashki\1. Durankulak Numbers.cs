using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace _01.DurankulakNumbers
{
    class Program
    {
        static BigInteger FinalConvert(List<int> decimalDigits)
        {
            int pow = 0;
            BigInteger result = 0;
            for (int i = decimalDigits.Count - 1; i >= 0; i--)
            {
                result += decimalDigits[i] * ((BigInteger)Math.Pow(168, pow));
                pow++;
            }
            return result;
        }
        static List<int> ConvertDigitsToDecimal(List<string> digits, char[] capitalValues, char[] smallValues)
        {
            List<int> decimalDigits = new List<int>();
            int decimalRep;

            for (int i = 0; i < digits.Count; i++)
            {
                decimalRep = 0;
                if (digits[i].Length == 1)
                {
                    decimalRep = Array.IndexOf(capitalValues,digits[i][0]);
                    decimalDigits.Add(decimalRep);
                }
                else
                {
                    decimalRep = (Array.IndexOf(capitalValues, digits[i][1]) + (Array.IndexOf(smallValues, digits[i][0]) * 26));
                    decimalDigits.Add(decimalRep);
                }
            }

            return decimalDigits;
        }
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            List<string> digits = new List<string>();
            List<int> decimalDigits = new List<int>();
            string digitsAsString;
            BigInteger result = 0;

            for (int i = 0; i < input.Length; i++)
            {
                digitsAsString = null;
                if (input[i] > 'Z')
                {
                    digitsAsString = input[i].ToString() + input[i + 1];
                    digits.Add(digitsAsString);
                    i++;
                }
                else
                {
                    digitsAsString = input[i].ToString();
                    digits.Add(digitsAsString);
                }
            }

            char[] capitalValues = new char[26];
            char[] smallValues = new char[7];
            int index = 0;
            for (int i = 65; i <= 90; i++)
            {
                capitalValues[index] = (char)i;
                index++;
            }
            index = 1;
            for (int i = 97; i <= 102; i++)
            {
                smallValues[index] = (char)i;
                index++;
            }
            decimalDigits = ConvertDigitsToDecimal(digits, capitalValues, smallValues);
            result = FinalConvert(decimalDigits);
            Console.WriteLine(result);
        }
    }
}
