using System;


class Program
{
    static Random rnd = new Random();
    static void Main(string[] args)
    {
        string line = Console.ReadLine();
        if (line.Length < 10)
        {
            Console.WriteLine(rnd.Next(0,10));
        }
        if (line.Length > 10 && line.Length < 20)
        {
            Console.WriteLine(rnd.Next(10,20));
        }
        if (line.Length > 20 && line.Length < 30)
        {
            Console.WriteLine(rnd.Next(20,30));
        }if (line.Length > 30)
        {
            Console.WriteLine(rnd.Next(20,50));
        }
    }
}
