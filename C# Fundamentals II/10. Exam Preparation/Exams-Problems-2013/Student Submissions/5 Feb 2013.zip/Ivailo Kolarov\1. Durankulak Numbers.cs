using System;
using System.Text;
using System.Numerics;
using System.Collections.Generic;
class Program
{
    static void Main()
    {
        string input = Console.ReadLine();
        if (input.Length >= 1 && input.Length <= 16)
        {
            StringBuilder result = new StringBuilder();
            int number = 0;
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] + '0' >= 113 && input[i] + '0' <= 138)
                {

                    result.Append((-113 + ((input[i] + '0'))) + number + " ");
                }
                else
                {

                    switch (input[i])
                    {
                        case 'a': number = 26;
                            break;
                        case 'b': number = 52;
                            break;
                        case 'c': number = 78;
                            break;
                        case 'd': number = 104;
                            break;
                        case 'e': number = 130;
                            break;
                        case 'f': number = 156;
                            break;
                    }
                }
            }
            string newStr = result.ToString();
            string[] splitedResult = newStr.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);




            BigInteger d = 0;
            List<BigInteger> convert = new List<BigInteger>();
            int pow = 0;

            for (int i = splitedResult.Length-1 ; i >= 0; i--)
            {
                BigInteger temp = BigInteger.Parse(splitedResult[i]) * (BigInteger)((Math.Pow(168, pow)));
                convert.Add(temp);
                pow++;
            }
            foreach (var item in convert)
            {
                d += item;
            }
            Console.WriteLine(d);
        }
        else
        {
            
        }

    }
}
