using System;
namespace DurankulakNumbers
{
    class Program
    {
        static void Main()
        {
            //Input
            string durankulak = Console.ReadLine();
            char[] newarray = durankulak.ToCharArray();
            Array.Reverse(newarray);
            int answer = 0;
            int total = 0;
 
            for (int i = 0; i < newarray.Length; i++)
            {
                for (char letter = 'A'; letter <= 'Z'; letter++)
                {
                    if (newarray[i] == letter)
                    {
                        answer += newarray[i] - 65;
                    }
                }
 
                if (newarray[i] == 'a' || newarray[i] == 'b' || newarray[i] == 'c' || newarray[i] == 'd' || newarray[i] == 'e' || newarray[i] == 'f')
                {
                    if (newarray[i] == 'a')
                    {
                        answer += 26;
                    }
                    else if (newarray[i] == 'b')
                    {
                        answer += 2 * 26;
                    }
                    else if (newarray[i] == 'c')
                    {
                        answer += 3 * 26;
                    }
                    else if (newarray[i] == 'd')
                    {
                        answer += 4 * 26;
                    }
                    else if (newarray[i] == 'e')
                    {
                        answer += 5 * 26;
                    }
                    else if (newarray[i] == 'f')
                    {
                        answer += 6 * 26;
                    }
                }
                total = answer;
            }
            Console.WriteLine(total);
        }
    }
}