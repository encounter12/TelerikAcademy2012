using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;

class DurankulakNumbers
{
      static void Main(string[] args)
   {
string text = "U";
         string replaced = text.Replace("U", "20");          
          Console.WriteLine(replaced);
}
}
