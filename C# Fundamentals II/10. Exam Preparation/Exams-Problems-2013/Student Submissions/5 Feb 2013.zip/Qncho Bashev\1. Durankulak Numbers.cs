using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DuranKolak
{
    class Program
    {
        static void Main(string[] args)
        {
            string number = Console.ReadLine();
            number = number.ToUpper();
            int sum = 0;
            int counter = 0;
            int multiplicator = 1;
            int bigmultiplicator = 1;

            for (int i = number.Length - 1; i >= 0; i--)
            {
                if (counter == 0)
                {
                    switch (number[i])
                    {
                        case 'A':
                            sum = sum + 0;
                            break;
                        case 'B':
                            sum = sum + 1;
                            break;
                        case 'C':
                            sum = sum + 2;
                            break;
                        case 'D':
                            sum = sum + 3;
                            break;
                        case 'E':
                            sum = sum + 4;
                            break;
                        case 'F':
                            sum = sum + 5;
                            break;
                        case 'G':
                            sum = sum + 6;
                            break;
                        case 'H':
                            sum = sum + 7;
                            break;
                        case 'I':
                            sum = sum + 8;
                            break;
                        case 'J':
                            sum = sum + 9;
                            break;
                        case 'K':
                            sum = sum + 10;
                            break;
                        case 'L':
                            sum = sum + 11;
                            break;
                        case 'M':
                            sum = sum + 12;
                            break;
                        case 'N':
                            sum = sum + 13;
                            break;
                        case 'O':
                            sum = sum + 14;
                            break;
                        case 'P':
                            sum = sum + 15;
                            break;
                        case 'Q':
                            sum = sum + 16;
                            break;
                        case 'R':
                            sum = sum + 17;
                            break;
                        case 'S':
                            sum = sum + 18;
                            break;
                        case 'T':
                            sum = sum + 19;
                            break;
                        case 'U':
                            sum = sum + 20;
                            break;
                        case 'V':
                            sum = sum + 21;
                            break;
                        case 'W':
                            sum = sum + 22;
                            break;
                        case 'X':
                            sum = sum + 23;
                            break;
                        case 'Y':
                            sum = sum + 24;
                            break;
                        case 'Z':
                            sum = sum + 25;
                            break;

                        default:
                            break;
                    }
                    counter++;
                }
                else
                {
                    switch (number[i])
                    {
                        case 'A':
                            multiplicator = 1;
                            break;
                        case 'B':
                            multiplicator = 2;
                            break;
                        case 'C':
                            multiplicator = 3;
                            break;
                        case 'D':
                            multiplicator = 4;
                            break;
                        case 'E':
                            multiplicator = 5;
                            break;
                        case 'F':
                            multiplicator = 6;
                            break;

                        default:
                            break;
                    }

                    switch (number[i])
                    {
                        case 'A':
                            sum = sum + multiplicator*26;
                            break;
                        case 'B':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'C':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'D':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'E':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'F':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'G':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'H':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'I':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'J':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'K':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'L':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'M':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'N':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'O':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'P':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'Q':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'R':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'S':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'T':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'U':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'V':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'W':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'X':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'Y':
                            sum = sum + multiplicator * 26;
                            break;
                        case 'Z':
                            sum = sum + multiplicator * 26;
                            break;

                        default:
                            break;
                    }
                    counter++;

                    if (counter == 2 && number.Length - 1 > 1)
                    {
                        switch (number[i - 1])
                        {
                            case 'A':
                                bigmultiplicator = 0;
                                break;
                            case 'B':
                                bigmultiplicator = 1;
                                break;
                            case 'C':
                                bigmultiplicator = 2;
                                break;
                            case 'D':
                                bigmultiplicator = 3;
                                break;
                            case 'E':
                                bigmultiplicator = 4;
                                break;
                            case 'F':
                                bigmultiplicator = 5;
                                break;

                            default:
                                break;
                        }

                        sum = sum + bigmultiplicator * 167;
                        counter = 0;
                    }
                }
            }

            Console.WriteLine(sum);
        }
    }
}
