using System;
using System.Numerics;
class Program
{
    static void Main()
    {
        string number = Console.ReadLine();
        int pow = 0;
        for (int i = 0; i < number.Length; i++)
        {
            if (char.IsUpper(number[i]))
            {
                pow++;
            }
        }
        pow -= 1;
       
        BigInteger digit = 0;
        BigInteger result = 0;

        int count = 0;
        int small = 0;

        for (int i = 0; i < number.Length; i++)
        {
            switch (number[i])
            {
                case 'A': digit = 0; break;
                case 'B': digit = 1; break;
                case 'C': digit = 2; break;
                case 'D': digit = 3; break;
                case 'E': digit = 4; break;
                case 'F': digit = 5; break;
                case 'G': digit = 6; break;
                case 'H': digit = 7; break;
                case 'I': digit = 8; break;
                case 'J': digit = 9; break;
                case 'K': digit = 10; break;
                case 'L': digit = 11; break;
                case 'M': digit = 12; break;
                case 'N': digit = 13; break;
                case 'O': digit = 14; break;
                case 'P': digit = 15; break;
                case 'Q': digit = 16; break;
                case 'R': digit = 17; break;
                case 'S': digit = 18; break;
                case 'T': digit = 19; break;
                case 'U': digit = 20; break;
                case 'V': digit = 21; break;
                case 'W': digit = 22; break;
                case 'X': digit = 23; break;
                case 'Y': digit = 24; break;
                case 'Z': digit = 25; break;

                case 'a': small = 26; break;
                case 'b': small = 52; break;
                case 'c': small = 78; break;
                case 'd': small = 104; break;
                case 'e': small = 130; break;
                case 'f': small = 156; break;
            }
            if (char.IsLower(number[i]))
            {
                count = small;
            }
            else if (number.Length == 1)
            {
                result = digit;
            }
            else  
            {
                result += ((digit + count) * (BigInteger)Math.Pow(168, pow));
                count = 0;
                if (pow > 0)
                {
                    pow--;
                }
                else { pow = 0; }
            }
        }
        Console.WriteLine(result);

    }
}
