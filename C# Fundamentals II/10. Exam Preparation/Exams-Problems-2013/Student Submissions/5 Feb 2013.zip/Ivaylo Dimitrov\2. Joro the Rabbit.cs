using System;
using System.Linq;
using System.Diagnostics;
using System.Threading;


namespace JoroTheRabbit
{
    class JoroTheRabbit
    {
        public static int terrainSize;
        
        static void Main()
        {
            string terrainString = Console.ReadLine();
            string[] separator = {", "};
            string[] terrainSplit = terrainString.Split(separator, StringSplitOptions.None);

            int[] terrain = new int[terrainSplit.Length];

            for (int i = 0; i < terrainSplit.Length; i++)
            {
                terrain[i] = int.Parse(terrainSplit[i]);
            }

            terrainSize = terrain.Length;
            bool[] isSpeted = new bool[terrainSize];
            int maxVisited = 0;

            for (int step = 1; step < terrain.Length; step++)
            {
                for (int positionStart = 0; positionStart < terrain.Length; positionStart++)
                {
                    int currentSpet = positionStart;
                    isSpeted[currentSpet] = true;
                    int visited = 1;
                    currentSpet += step;

                    while (true)
                    {
                        if (!isSpeted[NextStep(currentSpet)] && terrain[NextStep(currentSpet)] > terrain[NextStep(currentSpet - step)])
                        {
                            isSpeted[NextStep(currentSpet)] = true;
                            visited++;
                            currentSpet += step;
                        }
                        else
                        {
                            break;
                        }
                    }

                    if (maxVisited < visited)
                    {
                        maxVisited = visited;
                    }

                    for (int k = 0; k < isSpeted.Length; k++)
                    {
                        isSpeted[k] = false;
                    }
                }
            }

            Console.WriteLine(maxVisited);
        }

        public static int NextStep(int number)
        {
            if (number <= terrainSize - 1)
            {
                return number;
            }
            else
            {
                return number % terrainSize;
            }
        }
    }
}
