using System;



class Brackets
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string s = Console.ReadLine();
        string[] initial = new string[n];
        string[] formatted = new string[n];
        for (int i = 0; i < n; i++)
        {
            initial[i] = Console.ReadLine();
        }
        for (int i = 0; i < n; i++)
        {
            string line = initial[i];
            formatted[i] = initial[i];
            if (string.IsNullOrEmpty(initial[i]))
            {
                formatted[i] = line.Trim('\n');
            }
            else 
            {
                formatted[i] = initial[i];
                formatted[i] = initial[i].Replace(s, "\t");

                for (int j = 0; j < line.Length; j++)
                {
                    if (line[j] == '{')
                    {
                        formatted[i] = "\n" + line[j] + "\n";
                        formatted[i + 1] = "\t" + initial[i + 1];

                    }
                    else if (line[j] == '}')
                    {
                        formatted[i] = "\n" + line[j] + "\n";
                    }
                    else if ((line[j] == ' ') && (line[j+1] == ' '))
                    {
                        formatted[i] = line.Trim(line[j]);
                    }

                }
                if ((line[0] == ' ') || (line[line.Length - 1]) == ' ')
                {
                    formatted[i] = line.TrimStart(' ');
                    formatted[i] = line.TrimEnd(' ');
                }
                
            }
        }
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine(formatted[i]);
        }
    }
}
