using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5.TwoIsBetter
{
    class Program
    {
        static long Reverse(long number)
        {
            long result = 0;

            while (number > 0)
            {
                long digit = number % 10;
                result = result * 10 + digit;
                number /= 10;
            }

            return result;
        }

        static void Main(string[] args)
        {
            string[] first = Console.ReadLine().Split(new string[]{" "}, StringSplitOptions.RemoveEmptyEntries);
            long a = long.Parse(first[0]);
            long b = long.Parse(first[1]);

            List<int> elements = new List<int>();//Console.ReadLine().Split(new string[] {","}, StringSplitOptions.RemoveEmptyEntries)
            //    .Select(s => int.Parse(s)).ToList();
            foreach(var s in Console.ReadLine().Split(new string[] {","}, StringSplitOptions.RemoveEmptyEntries))
            {
                elements.Add(int.Parse(s));
            }

            byte percent = byte.Parse(Console.ReadLine());

            //first task
            char[] not = { '1', '2', '4', '6', '7', '8', '9', '0' };
            int count = 0;
            for(long i = a; i <= b; i ++)
            {
                long res = 0;
                long num = i;
                while (num > 0)
                {
                    long digit = num % 10;
                    res = res * 10 + digit;
                    num /= 10;
                }

                if(i == res)
                {
                    if (!i.ToString().Any(c => not.Contains(c)))
                    {
                        count++;
                    }
                }
            }

            //second task

            elements.Sort(); 
            int result = elements.LastOrDefault();
            for (int i = 0; i < elements.Count; i ++)
            {
                if(((i + 1) * 100) / elements.Count >= percent)
                {
                    result = elements[i];
                    break;
                }
            }

            Console.WriteLine(count);
            Console.WriteLine(result);
        }
    }
}
