using System;
  
  
class ExcelColums
{
    static void Main()
    {
        string[] letters = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        string str = Console.ReadLine();
       // char[] array = new char[str.Length];
        string upper = str.ToUpper();
        //for (int i = 0; i < str.Length; i++)
        //{
  
        //    array[i] = str[i];
        //    Console.WriteLine(array[i]);
        //}
        double result = 0.0;
        int p = str.Length - 1;
        int num = 0;
  
       
  
        for (int k = 0; k < str.Length; k++)
        {
            for (int j = 0; j < 26; j++)
            {
                if (upper[k].ToString() == letters[j])
                {
                    num = j + 1;
                }
                if (num != 0)
                {
                    result = result + num * Math.Pow(26, p);
                    p--;
                    num = 0;
                }
            }
        }
  
  
        Console.WriteLine(result-1);
    }
}
