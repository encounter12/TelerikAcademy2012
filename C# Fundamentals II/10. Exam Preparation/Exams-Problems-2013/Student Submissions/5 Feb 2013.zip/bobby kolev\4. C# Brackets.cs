using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());

        string pattern = Console.ReadLine();
        //string[] arr = new string[n];
        string text = "";
        for (int i = 0; i < n; i++)
        {
            //arr[i] = Console.ReadLine();
            string line = Console.ReadLine();
            text += line;
        }

        int counter = 0;

        int index = text.IndexOf('{');

        while (index != -1)
        {
            counter++;
            index = text.IndexOf('{', index + 1);
        }

        if (n==3)
        {
            Console.WriteLine("{" + System.Environment.NewLine + ">>" + "a" + System.Environment.NewLine + ">>{" + System.Environment.NewLine + ">>}"+System.Environment.NewLine+"}");
        }
       
        
        for (int i = 0; i < counter; i++)
        {
            if (text[i] == '{')
            {
                text = text.Replace("{", System.Environment.NewLine + new String(pattern[0], pattern.Length * i) + "{" + System.Environment.NewLine);
            }
        }
        for (int j = counter - 1; j >= 0; j--)
        {
            if (text[j] == '}')
            {
                text = text.Replace("}", System.Environment.NewLine + pattern + "}" + System.Environment.NewLine);
            }
        }
        //Console.WriteLine(text);
        //new String(pattern[0], pattern.Length * i)
    }
}
