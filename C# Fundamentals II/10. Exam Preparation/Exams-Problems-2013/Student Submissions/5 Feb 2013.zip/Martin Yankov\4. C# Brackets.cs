using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fourth
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int lines = int.Parse(input);
            string indent = Console.ReadLine();
            StringBuilder sb = new StringBuilder();
            StringBuilder lineBuilder = new StringBuilder();
            bool whiteSpaceFlag = false;
            int bracketCounter = 0;
            bool bracketFlag = false;
            bool indentFlag = false;
            bool onlyWhiteSpace = true;

            for (int i = 0; i < lines; i++)
            {
                input = Console.ReadLine().Trim();

                for (int k = 0; k < bracketCounter; k++)
                {
                    lineBuilder.Append(indent);
                }

                indentFlag = true;
                onlyWhiteSpace = true;

                for (int j = 0; j < input.Length; j++)
                {
                    if (input[j] == '{')
                    {
                        if (!indentFlag)
                        {
                            lineBuilder.Append("\n");
                            for (int z = 0; z < bracketCounter; z++)
                            {
                                lineBuilder.Append(indent);
                            }
                        }
                        lineBuilder.Append("{");
                        bracketCounter++;
                        bracketFlag = true;
                        indentFlag = false;
                        onlyWhiteSpace = false;
                    }
                    else if (input[j] == '}')
                    {
                        bracketCounter--;
                        if (!indentFlag)
                        {
                            lineBuilder.Append("\n");
                            for (int z = 0; z < bracketCounter; z++)
                            {
                                lineBuilder.Append(indent);
                            }
                        }
                        else if (lineBuilder.Length >= indent.Length)
                        {
                            lineBuilder.Remove(lineBuilder.Length - indent.Length, indent.Length);
                        }
                        lineBuilder.Append("}");
                        bracketFlag = true;
                        indentFlag = false;
                        onlyWhiteSpace = false;
                    }
                    else if (input[j] == ' ')
                    {
                        if (whiteSpaceFlag != true)
                        {
                            lineBuilder.Append(' ');
                            whiteSpaceFlag = true;
                        }
                    }
                    else
                    {
                        if (bracketFlag && j != 0)
                        {
                            lineBuilder.Append("\n");
                            for (int z = 0; z < bracketCounter; z++)
                            {
                                lineBuilder.Append(indent);
                            }
                            lineBuilder.Append(input[j]);
                        }
                        else
                        {
                            lineBuilder.Append(input[j]);
                        }

                        if (whiteSpaceFlag == true)
                        {
                            whiteSpaceFlag = false;
                        }

                        onlyWhiteSpace = false;
                        indentFlag = false;
                        bracketFlag = false;
                    }
                }

                if (!onlyWhiteSpace)
                {
                    sb.Append(lineBuilder.ToString());
                    if (i != lines - 1)
                    {
                        sb.Append("\n");
                    }
                }

                lineBuilder.Clear();
            }

            Console.WriteLine(sb.ToString());

        }
    }
}
