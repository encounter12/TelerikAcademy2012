using System;

class Laser
{
    static void Main()
    {
        string[] dimStr = Console.ReadLine().Split(' ');
        int width = int.Parse(dimStr[0]);
        int height = int.Parse(dimStr[1]);
        int depth = int.Parse(dimStr[2]);

        string[] startStr = Console.ReadLine().Split(' ');
        int startW = int.Parse(startStr[0]);
        int startH = int.Parse(startStr[1]);
        int startD = int.Parse(startStr[2]);

        string[] dirStr = Console.ReadLine().Split(' ');

        char[, ,] cube = SetCube(width, height, depth);

        int[] current = new int[3];
        int[] next = { startW, startH, startD };
        int[] direction = { int.Parse(dirStr[0]), int.Parse(dirStr[1]), int.Parse(dirStr[2]) };

        bool end = false;
        while (!end)
        {
            //set current to visited
            current[0] = next[0];
            current[1] = next[1];
            current[2] = next[2];
            cube[current[0], current[1], current[2]] = '*';

            //reflect
            if (current[0] + direction[0] > width - 1 || current[0] + direction[0] < 0)
            {
                direction[0] *= -1;
            }
            else if (current[1] + direction[1] > height - 1 || current[1] + direction[1] < 0)
            {
                direction[1] *= -1;
            }
            else if (current[2] + direction[2] > depth - 1 || current[2] + direction[2] < 0)
            {
                direction[2] *= -1;
            }

            next[0] = current[0] + direction[0];
            next[1] = current[1] + direction[1];
            next[2] = current[2] + direction[2];

            //check if next is visited
            if (cube[next[0], next[1], next[2]] == '*')
            {
                end = true;
            }
        }
        current[0] = current[0] - direction[0]; //no idea why this give a better result?!
        current[1] = current[1] - direction[1];
        current[2] = current[2] - direction[2];

        Console.WriteLine(string.Join(" ", current));
    }

    private static char[, ,] SetCube(int width, int height, int depth)
    {
        char[, ,] cube = new char[width, height, depth];
        char symbol = '*';
        for (int w = 0; w < cube.GetLength(0); w++)
        {
            cube[w, 0, 0] = symbol;
            cube[w, height - 1, 0] = symbol;
            cube[w, 0, depth - 1] = symbol;
            cube[w, height - 1, depth - 1] = symbol;
        }
        for (int h = 0; h < cube.GetLength(1); h++)
        {
            cube[0, h, 0] = symbol;
            cube[width - 1, h, 0] = symbol;
            cube[0, h, depth - 1] = symbol;
            cube[width - 1, h, depth - 1] = symbol;
        }
        for (int d = 0; d < cube.GetLength(2); d++)
        {
            cube[0, 0, d] = symbol;
            cube[0, height - 1, d] = symbol;
            cube[width - 1, 0, d] = symbol;
            cube[width - 1, height - 1, d] = symbol;
        }
        return cube;
    }
}