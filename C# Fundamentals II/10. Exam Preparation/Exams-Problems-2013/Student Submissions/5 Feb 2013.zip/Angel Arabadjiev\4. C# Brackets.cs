using System;
using System.Text;

public class CSharpBrackets
{
    private static StringBuilder sbOutput;
    private static string indentation;

    private static void Main()
    {
        int totalLines = int.Parse(Console.ReadLine());
        indentation = Console.ReadLine();

        StringBuilder sbInput = new StringBuilder(totalLines);
        sbOutput = new StringBuilder(totalLines);

        for (int i = 0; i < totalLines; i++)
        {
            string lineS = Console.ReadLine().Trim();
            if (lineS != "\n")
            {
                sbInput.AppendLine(lineS);
            }
        }

        int indentationCounter = 0;
        bool openBracketFlag = false;
        int line = -1;
        while (sbInput[++line] != null)
        {
            while (sbInput[line]!=null)
            {
                int index2 = sbInput[line].ToString().IndexOf("{");
                if (index2 >= 0)
                {
                    openBracketFlag = true;
                    sbOutput.AppendLine("{");
                    indentationCounter++;

                    sbInput[line].ToString().Remove(0, 1);
                    string kk = sbInput.ToString();

                    int index = sbInput[line].ToString().IndexOf("}");
                    if (index < 0)
                    { // nqma "}"
                        AppendIndetation(indentationCounter);
                        sbOutput.Append(sbInput.ToString());
                        sbOutput.AppendLine();
                        break;
                    }

                    // ima "}"
                    AppendIndetation(indentationCounter);
                    sbOutput.Append(sbInput.ToString().Substring(0, index));
                    indentationCounter--;
                    AppendIndetation(indentationCounter);
                    sbOutput.AppendLine("}");
                    sbInput[line].ToString().Remove(index, 1);
                    openBracketFlag = false;
                }

                // nqma "{"
                AppendIndetation(indentationCounter);
                sbOutput.Append(sbInput.ToString());
                sbInput.Remove(0,sbInput.ToString().Length);
            }

        }

        Console.WriteLine(sbOutput.ToString());
    }

    private static void AppendIndetation(int indentationCounter)
    {
        for (int i = 0; i < indentationCounter; i++)
        {
            sbOutput.Append(indentation);
        }
    }
}
