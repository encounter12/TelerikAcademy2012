using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
 
namespace Brackets
{
    class Program
    {
        public static string Add_Formattin(int index, string format, string item)
        {
            string formatted_string = string.Empty;
            StringBuilder temp = new StringBuilder();
            if (index == 0)
            {
                formatted_string = item;
            }
            for (int i = 0; i < index; i++)
            {
                temp.Append(format);
                //Console.WriteLine(temp);
            }
            temp.Append(item);
            formatted_string = temp.ToString();
            temp.Clear();
            return formatted_string;
        }
 
        static void Main(string[] args)
        {
            int input = int.Parse(Console.ReadLine());
            StringBuilder temp = new StringBuilder();
            StringBuilder element_no_bracket = new StringBuilder();
            List<string> code = new List<string>();
            string formatting = Console.ReadLine();
            List<string> no_formatting = new List<string>();
 
 
            for (int i = 0; i < input; i++)
            {
                code.Add(Console.ReadLine());
            }
 
 
            int count_brackets = 0;
            foreach (var element in code)
            {
                temp.Append(element);
                //Console.WriteLine(temp);
                for (int i = 0; i < temp.Length; i++)
                {
                    if (temp[i].ToString() != "{" && temp[i].ToString() != "}")
                    {
                        element_no_bracket.Append(temp[i]);
                    }
                    else if (temp[i].ToString() == "{")
                    {
                        no_formatting.Add(element_no_bracket.ToString());
                        no_formatting.Add("{");
                        element_no_bracket.Clear();
                        count_brackets++;
                    }
                    else if (temp[i].ToString() == "}")
                    {
                        no_formatting.Add(element_no_bracket.ToString());
                        no_formatting.Add("}");
                        element_no_bracket.Clear();
                        //count_brackets++;
                    }
 
                }
                 
                string temp_string = element_no_bracket.ToString();
                string cleanedString = Regex.Replace(temp_string, @"^\s+$[\r\n]*", "", RegexOptions.Multiline);
                //element_no_bracket = element_no_bracket.Replace("  ", " ");
                //element_no_bracket = element_no_bracket.Replace("\r", "");
                //element_no_bracket = element_no_bracket.Replace("\t", "");
                //element_no_bracket = element_no_bracket.Replace("\n", "");
                //temp_string.Trim();
                no_formatting.Add(cleanedString);
                temp.Clear();
                element_no_bracket.Clear();
                //Console.WriteLine(item);
            }
 
            int index = 0;
            List<string> result = new List<string>();
            temp.Clear();
            //string add_formattin = string.Empty;
            //result.Add(no_formatting[1]);
 
            /*foreach (var item in no_formatting)
            {
                Console.WriteLine(item);
            }*/
 
            foreach (var item in no_formatting)
            {
                 
                //Console.WriteLine(index);
                if (item == "{")
                {
                    //Console.WriteLine("++");
                    //result.Add(Add_Formattin(index, formatting) + "}");
                    //result.Add(Add_Formattin(index, formatting));
                    result.Add(Add_Formattin(index, formatting, item));
                    index++;
                     
 
                }
                else if (item == "}")
                {
                    //Console.WriteLine("--");
                    //result.Add(Add_Formattin(index, formatting) + "}");
                    index--;
                    result.Add(Add_Formattin(index, formatting, item));
                }
                else if(item != string.Empty)
                {
                    result.Add(Add_Formattin(index, formatting, item));
                }
 
            }
 
 
            foreach (var item in result)
            {
                Console.WriteLine(item);
            }
        }
    }
}
