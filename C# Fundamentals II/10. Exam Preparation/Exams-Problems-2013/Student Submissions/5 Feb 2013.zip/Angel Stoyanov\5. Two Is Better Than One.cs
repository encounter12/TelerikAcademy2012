using System;
using System.Collections.Generic;
using System.Text;

class TwoAtATime
{
    static void Main(string[] args)
    {
        string[] intervals = Console.ReadLine().Split(new char[] {' '});

        long luckyNumbers = GetLuckyNumbers(intervals[0], intervals[1]);



        string[] numbers = Console.ReadLine().Split(new char[] { ' ', ',' });

        int percents = int.Parse(Console.ReadLine());

        int secondResult = GetSecondTask(numbers, percents);


        Console.WriteLine(luckyNumbers);
        Console.WriteLine(secondResult);
        
    }

    private static int GetSecondTask(string[] numbers, int percents)
    {
        List<int> sorted = new List<int>(numbers.Length);

        for (int i = 0; i < numbers.Length; i++)
        {
            sorted.Add(int.Parse(numbers[i]));
        }

        sorted.Sort();

        int correctIndex = GetCorrectIndex(sorted.Count, percents);

        return sorted[correctIndex];
    }

    private static int GetCorrectIndex(int p, int percents)
    {
        double temp = (percents / (double)100) * p; 

        int whole = (int)temp;

        if (temp - (int)temp > 0)
        {
            whole++;
        }

        if (whole == 0)
        {
            return 0;
        }
        return whole - 1;
    }

    private static long GetLuckyNumbers(string p1, string p2)
    {
        if (p1.Length == p2.Length)
        {
            return GetLuckyHelp(p1, p2, p1.Length);
        }

        long result = 0;

        for (int i = 1; i < p2.Length - p1.Length; i++)
        {
            result = result + GetLuckyCleanInterval(p1.Length + i);
        }

        result = result + GetLuckyHelp(p1, " ", p1.Length);

        result = result + GetLuckyHelp(" ", p2, p2.Length);

        return result;
    }

    private static long GetLuckyHelp(string p1, string p2, int length)
    {
        long result = GetLuckyCleanInterval(length);

        long lostNumbers = 0;

        long num1 = 0;

        long num2 = 0;

        if (!p1.Equals(" "))
        {
            lostNumbers = lostNumbers + GetLostLower(p1, result);
        }

        if (!p2.Equals(" "))
        {
            lostNumbers = lostNumbers + GetLostUpper(p2, result);
        }

        return result - lostNumbers;
    }

    private static long GetLostUpper(string p, long max)
    {
        long lost = 0;

        if (p[0] < '3')
        {
            return max;
        }

        if (p[0] < '5')
        {
            lost = max / 2;
        }

        if (p[0] > '5')
        {
            return 0;
        }

        return lost;
    }

    private static long GetLostLower(string p, long max)
    {
        long lost = 0;

        /*
        StringBuilder boundary3 = new StringBuilder(p1.Length);

        StringBuilder boundary5 = new StringBuilder(p1.Length);

        for (int i = 0; i < p1.Length; i++)
        {
            boundary3.Append('3');

            boundary5.Append('5');
        }
        */

        if (p[0] < '3')
        {
            return 0;
        }
        
        if (p[0] > '3')
        {
            lost = max / 2;
        }

        if (p[0] == '3')
        {
            for (int i = 0; i < p.Length; i++)
            {
                if (p[i] < '3')
                {
                    break;
                }

                if (p[i] > '3')
                {
                    lost = max;
                }
            }
        }

        if (p[0] > '5')
        {
            return max;
        }

        return lost;
    }

    private static long GetLuckyCleanInterval(int p)
    {
        int remainder = p % 2;

        long result = 0;

        result = (1 << (p / 2));

        if (remainder != 0)
        {
            result = result * 2;
        }

        return result;
    }
}
