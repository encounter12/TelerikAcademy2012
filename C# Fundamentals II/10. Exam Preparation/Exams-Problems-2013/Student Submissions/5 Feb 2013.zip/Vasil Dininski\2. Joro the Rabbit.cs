using System;
using System.Collections.Generic;

class Joro
{
    class Cell
    {
        public int Position { set; get; }
        public int Value { set; get; }
    }

    static void Main(string[] args)
    {
        string terrain = Console.ReadLine();
        int[] terrainSteps;
        int maxJumps = 1;
        int jumps = 1;

        string[] terrainStepsStr = terrain.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
        terrainSteps = new int[terrainStepsStr.Length];
        for (int i = 0; i < terrainSteps.Length; i++)
        {
            terrainSteps[i] = int.Parse(terrainStepsStr[i]);
        }


        for (int i = 0; i < terrainSteps.Length; i++)
        {
            for (int step = 1; step < terrainSteps.Length; step++)
            {
                jumps = 1;
                Cell currentCell = new Cell();
                currentCell.Position = i;
                currentCell.Value = terrainSteps[currentCell.Position];
                Cell nextCell = new Cell();
                nextCell.Position = (currentCell.Position + step) % terrainSteps.Length;
                nextCell.Value = terrainSteps[nextCell.Position];
                //dokato tekushtata kletka ne e ravna na kletkata, koqto proverqvame ili kletkata, koqto proverqvame e po-golqma ot tekushtata
                while (currentCell.Position != nextCell.Position && nextCell.Value > currentCell.Value)
                {
                    jumps++;
                    currentCell.Position = nextCell.Position;
                    currentCell.Value = nextCell.Value;
                    nextCell.Position = (currentCell.Position + step) % terrainSteps.Length;
                    nextCell.Value = terrainSteps[nextCell.Position];
                }
                if (maxJumps < jumps)
                {
                    maxJumps = jumps;
                }
            }
        }
        Console.WriteLine(maxJumps);
    }
}