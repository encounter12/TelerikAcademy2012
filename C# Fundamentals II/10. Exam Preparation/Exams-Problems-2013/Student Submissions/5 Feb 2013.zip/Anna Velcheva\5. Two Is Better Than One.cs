using System;
using System.Collections.Generic;
using System.Text;

class TwoIsBetterThanOne
{
    static void Main(string[] args)
    {
        //first task
        string line = Console.ReadLine();
        string[] splitInput = line.Split();
        long a = Int64.Parse(splitInput[0]);
        long b = Int64.Parse(splitInput[1]);

        int result = 0;

        if (3 >= a && 3 <= b)
        {
            result += 1;
        }
        
        if (5 >= a && 5 <= b)
        {
            result += 1;
        }

        if (a < 10)
        {
            a = 10;
        }

        if (b < 10)
        {
            b = 10;
        }

        if (a.ToString().Length != b.ToString().Length)
        {
            result += GetNumberOfPalindromesAfter(a);
            result += GetNumberOfPalindromesBefore(b);
        }
        else
        {
            result += GetNumberOfPalindromesBetween(a, b);
        }

        for (int i = a.ToString().Length + 1; i < b.ToString().Length; i++)
        {
            if (i % 2 == 0)
            {
                result += (int)Math.Pow(2, i / 2);
            }
            else
            {
                result += (int)Math.Pow(2, i / 2) * 2;
            }
        }

        Console.WriteLine(result);

        //second task
        line = Console.ReadLine();
        splitInput = line.Split(',');
        int[] numbers = new int[splitInput.Length];
        for (int i = 0; i < splitInput.Length; i++)
        {
            numbers[i] = Int32.Parse(splitInput[i]);
        }
        int p = Int32.Parse(Console.ReadLine());

        Array.Sort(numbers);
        int indexResult = (int)Math.Ceiling(((double)numbers.Length / 100) * p) - 1;
        Console.WriteLine(numbers[indexResult]);
    }

    static int GetNumberOfPalindromesBetween(long a, long b)
    {
        currentPermutation = new int[b.ToString().Length / 2];
        allPermutations35 = new List<string>();
        GetAllPermutationsWithRepetition35(b.ToString().Length / 2, 0);

        int result = 0;

        if (b.ToString().Length % 2 == 0)
        {
            foreach (string permutation in allPermutations35)
            {
                StringBuilder builder = new StringBuilder();
                builder.Append(permutation);
                for (int i = permutation.Length - 1; i >= 0; i--)
                {
                    builder.Append(permutation[i]);
                }

                if (Int64.Parse(builder.ToString()) <= b && Int64.Parse(builder.ToString()) >= a)
                {
                    result++;
                }
            }
        }
        else
        {
            foreach (string permutation in allPermutations35)
            {
                StringBuilder builder = new StringBuilder();
                builder.Append(permutation);
                builder.Append("3");
                for (int i = permutation.Length - 1; i >= 0; i--)
                {
                    builder.Append(permutation[i]);
                }

                if (Int64.Parse(builder.ToString()) <= b && Int64.Parse(builder.ToString()) >= a) 
                {
                    result++;
                }

                builder = new StringBuilder();
                builder.Append(permutation);
                builder.Append("5");
                for (int i = permutation.Length - 1; i >= 0; i--)
                {
                    builder.Append(permutation[i]);
                }

                if (Int64.Parse(builder.ToString()) <= b && Int64.Parse(builder.ToString()) >= a)
                {
                    result++;
                }
            }
        }

        return result;
    }

    static int GetNumberOfPalindromesBefore(long b)
    {
        currentPermutation = new int[b.ToString().Length / 2];
        allPermutations35 = new List<string>();
        GetAllPermutationsWithRepetition35(b.ToString().Length / 2, 0);

        int result = 0;

        if (b.ToString().Length % 2 == 0)
        {
            foreach (string permutation in allPermutations35)
            {
                StringBuilder builder = new StringBuilder();
                builder.Append(permutation);
                for (int i = permutation.Length - 1; i >= 0; i--)
                {
                    builder.Append(permutation[i]);
                }

                if (Int64.Parse(builder.ToString()) <= b)
                {
                    result++;
                }
            }
        }
        else
        {
            foreach (string permutation in allPermutations35)
            {
                StringBuilder builder = new StringBuilder();
                builder.Append(permutation);
                builder.Append("3");
                for (int i = permutation.Length - 1; i >= 0; i--)
                {
                    builder.Append(permutation[i]);
                }

                if (Int64.Parse(builder.ToString()) <= b)
                {
                    result++;
                }

                builder = new StringBuilder();
                builder.Append(permutation);
                builder.Append("5");
                for (int i = permutation.Length - 1; i >= 0; i--)
                {
                    builder.Append(permutation[i]);
                }

                if (Int64.Parse(builder.ToString()) <= b)
                {
                    result++;
                }
            }
        }

        return result;
    }

    static int GetNumberOfPalindromesAfter(long a)
    {
        currentPermutation = new int[a.ToString().Length / 2];
        allPermutations35 = new List<string>();
        GetAllPermutationsWithRepetition35(a.ToString().Length / 2, 0);

        int result = 0;

        if (a.ToString().Length % 2 == 0)
        {
            foreach (string permutation in allPermutations35)
            {
                StringBuilder builder = new StringBuilder();
                builder.Append(permutation);
                for (int i = permutation.Length - 1; i >= 0; i--)
                {
                    builder.Append(permutation[i]);
                }

                if (Int64.Parse(builder.ToString()) >= a)
                {
                    result++;
                }
            }
        }
        else
        {
            foreach (string permutation in allPermutations35)
            {
                StringBuilder builder = new StringBuilder();
                builder.Append(permutation);
                builder.Append("3");
                for (int i = permutation.Length - 1; i >= 0; i--)
                {
                    builder.Append(permutation[i]);
                }

                if (Int64.Parse(builder.ToString()) >= a)
                {
                    result++;
                }

                builder = new StringBuilder();
                builder.Append(permutation);
                builder.Append("5");
                for (int i = permutation.Length - 1; i >= 0; i--)
                {
                    builder.Append(permutation[i]);
                }

                if (Int64.Parse(builder.ToString()) >= a)
                {
                    result++;
                }
            }
        }

        return result;
    }

    static List<string> allPermutations35 = new List<string>();
    static int[] currentPermutation;
    static void GetAllPermutationsWithRepetition35(int k, int currentIndex)
    {
        
        currentPermutation[currentIndex] = 3;
        if (currentIndex == k - 1)
        {
            AddCurrentToList();
        }
        else
        {
            GetAllPermutationsWithRepetition35(k, currentIndex + 1);
        }

        currentPermutation[currentIndex] = 5;
        if (currentIndex == k - 1)
        {
            AddCurrentToList();
        }
        else
        {
            GetAllPermutationsWithRepetition35(k, currentIndex + 1);
        }
    }

    static void AddCurrentToList()
    {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < currentPermutation.Length; i++)
        {
            builder.Append(currentPermutation[i].ToString());
        }
        allPermutations35.Add(builder.ToString());
    }
}
