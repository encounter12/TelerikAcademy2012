using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
#endif
        //int luckyOne = 3;
        //int luckyTwo = 5;
        //FIRST PART
        string[] inputOne = (Console.ReadLine()).Split(' ');
        ulong borderA = ulong.Parse(inputOne[0]);
        ulong borderB = ulong.Parse(inputOne[1]);
        
        int counter = 0;
        
        //for (ulong i = borderA; i <= borderB; i++)
        //{
        //    bool isfound = true;
        //    string number = Convert.ToString(i);
        //    for (int j = 0; j < number.Length / 2; j++)
        //    {
               
        //            if ((number[j] != number[number.Length - 1 - j]))
        //            {
        //                isfound = false;
        //                break;
        //            }
        //            if (isfound)
        //            {
        //                counter++;
        //            }
                
        //    }
           
        //}
        Console.WriteLine(counter);

        // SECOND PART
        string input = Console.ReadLine();

        string[] splitted = input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

        int[] arr = new int[splitted.Length];

        for (int i = 0; i < arr.Length; i++)
        {
            arr[i] = int.Parse(splitted[i]);
        }

        QuickSortByRecursion(arr, 0, arr.Length - 1);

        int pivot = int.Parse(Console.ReadLine());
        //int per = arr.Length * pivot;
        pivot = (arr.Length * pivot) / 100;
       
       
        Console.WriteLine(arr[pivot]);
    }

    static public int Split(int[] myArray, int left, int right)
    {
        // you can choose random number in the array
        int pivot = myArray[left];

        while (true)
        {
            while (myArray[left] < pivot)
            {
                left++;
            }

            while (myArray[right] > pivot)
            {
                right--;
            }

            if (left < right)
            {
                int temp = myArray[right];
                myArray[right] = myArray[left];
                myArray[left] = temp;
            }
            else
            {
                return right;
            }
        }
    }

    static public void QuickSortByRecursion(int[] arr, int left, int right)
    {
        if (left < right)
        {
            int pivot = Split(arr, left, right);

            if (pivot > 1)
            {
                QuickSortByRecursion(arr, left, pivot - 1);
            }

            if (pivot + 1 < right)
            {
                QuickSortByRecursion(arr, pivot + 1, right);
            }
        }
    }
}
