using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

class DurankulakNumbers
{
    static void Main()
    {
        string input = Console.ReadLine();
        char[] durankulakChar = input.ToCharArray();
        BigInteger[] durankulak = new BigInteger[durankulakChar.Length];
        char ch1 = '0';
        int tempResult = 0;

        //for (int i = 0; i < durankulakChar.Length; i++)
        //{
        //    durankulak[i] = durankulakChar[i] - 65;
        //}

        foreach (char ch in durankulakChar)
        {
            if (ch >= 'A' && ch <='Z')
            {
                tempResult = tempResult + (ch - 65);
                if ((ch1 == 'a') && (ch >= 'A' && ch <= 'Z'))
            {
                tempResult = tempResult + (25 + (ch - 64));
            }
            if ((ch1 == 'b') && (ch >= 'A' && ch <= 'Z'))
            {
                tempResult = tempResult + (51 + (ch - 64));
            }
            if ((ch1 == 'c') && (ch >= 'A' && ch <= 'Z'))
            {
                tempResult = tempResult + (77 + (ch - 64));
            }
            if ((ch1 == 'd') && (ch >= 'A' && ch <= 'Z'))
            {
                tempResult = tempResult + (102 + (ch - 64));
            }
            if ((ch1 == 'e') && (ch >= 'A' && ch <= 'Z'))
            {
                tempResult = tempResult + (129 + (ch - 64));
            }
            if ((ch1 == 'f') && (ch >= 'A' && ch <= 'L'))
            {
                tempResult = tempResult + (155 + (ch - 64));
            }
            if ((ch1 >= 'A' && ch1 <='Z') && (ch >= 'a' && ch <='z'))
            {
                tempResult = tempResult + (ch1 - 65);
            }
            }
            ch1 = ch;
        }

        //for (int i = 0; i < durankulak.Length; i++)
        //{
        //    Console.Write(durankulak[i] + " ");
        //}

        Console.WriteLine(tempResult);
    }
}
