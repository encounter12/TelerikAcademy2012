using System;

class TwoIsBetterThanOne
{
    static void Main()
    {
        string firstRow = Console.ReadLine();
        string secondRow = Console.ReadLine();
        string thirdRow = Console.ReadLine();


        Console.WriteLine(0);
        Console.WriteLine(0);
    }
}
