using System;

namespace Durankulak2
{
    class Program
    {
        static void Main()
        {
            string input = Console.ReadLine();
            double[] symbols = new double[input.Length];
            double result = 0;
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] == 97) symbols[i] = 26;
                else if (input[i] == 98) symbols[i] = 52;
                else if (input[i] == 99) symbols[i] = 78;
                else if (input[i] == 100) symbols[i] = 104;
                else if (input[i] == 101) symbols[i] = 130;
                else if (input[i] == 102) symbols[i] = 156;
                else symbols[i] = (double)input[i] - 65;
            }
            switch (input.Length)
            {
                case 1:
                    result = symbols[0];
                    Console.WriteLine(result);
                    break;
                case 2:
                    result = symbols[0];
                    result = result + symbols[1];
                    Console.WriteLine(result);
                    break;
                case 3:
                    result = Math.Pow(168, 1)*(symbols[0]);
                    result = result + symbols[1];
                    result = result + symbols[2];
                    Console.WriteLine(result);
                    break;
                case 4:
                    result = Math.Pow(168, 2) * (symbols[0]);
                    result = result+Math.Pow(168, 1) * (symbols[1]);
                    result = result +symbols[2];
                    result = result + symbols[3];
                    Console.WriteLine(result);
                    break;
                case 5:
                    result = Math.Pow(168, 3) * (symbols[0]);
                    result = result+Math.Pow(168, 2) * (symbols[1]);
                    result = result+Math.Pow(168, 1) * (symbols[2]);
                    result = result +  symbols[3];
                    result = result + symbols[4];
                    Console.WriteLine(result);
                    break;
                case 6:
                    result = Math.Pow(168, 4) * (symbols[0]);
                    result = result+Math.Pow(168, 3) * (symbols[1]);
                    result = result+Math.Pow(168, 2) * (symbols[2]);
                    result = result+Math.Pow(168, 1) * (symbols[3] );
                    result = result +  symbols[4];
                    result = result + symbols[5];
                    Console.WriteLine(result );
                    break;
                case 7:
                    result = Math.Pow(168, 5) * (symbols[0] );
                    result = result+Math.Pow(168, 4) * (symbols[1] );
                    result = result+Math.Pow(168, 3) * (symbols[2] );
                    result = result+Math.Pow(168, 2) * (symbols[3] );
                    result = result+Math.Pow(168, 1) * (symbols[4] );
                    result = result +  symbols[5];
                    result = result + symbols[6];
                    Console.WriteLine(result);
                    break;
                case 8:
                    result = Math.Pow(168, 6) * (symbols[0]);
                    result = result + Math.Pow(168, 5) * (symbols[1]);
                    result = result + Math.Pow(168, 4) * (symbols[2] );
                    result = result + Math.Pow(168, 3) * (symbols[3] );
                    result = result + Math.Pow(168, 2) * (symbols[4]);
                    result = result + Math.Pow(168, 1) * (symbols[5] );
                    result = result + symbols[6];
                    result = result + symbols[7];
                    Console.WriteLine(result );
                    break;
                case 9:
                    result = Math.Pow(168, 7) * (symbols[0] );
                    result = result + Math.Pow(168, 6) * (symbols[1] );
                    result = result + Math.Pow(168, 5) * (symbols[2] );
                    result = result + Math.Pow(168, 4) * (symbols[3] );
                    result = result + Math.Pow(168, 3) * (symbols[4] );
                    result = result + Math.Pow(168, 2) * (symbols[5] );
                    result = result + Math.Pow(168, 1) * (symbols[6] );
                    result = result +  symbols[7];
                    result = result + symbols[8];
                    Console.WriteLine(result );
                    break;
                case 10:
                    result = Math.Pow(168, 8) * (symbols[0] );
                    result = result + Math.Pow(168, 7) * (symbols[1]);
                    result = result + Math.Pow(168, 6) * (symbols[2] );
                    result = result + Math.Pow(168, 5) * (symbols[3] );
                    result = result + Math.Pow(168, 4) * (symbols[4] );
                    result = result + Math.Pow(168, 3) * (symbols[5] );
                    result = result + Math.Pow(168, 2) * (symbols[6] );
                    result = result + Math.Pow(168, 1) * (symbols[7] );
                    result = result + symbols[8];
                    result = result + symbols[9];
                    Console.WriteLine(result );
                    break;
                case 11:
                    result = Math.Pow(168, 9) * (symbols[0] );
                    result = result + Math.Pow(168, 8) * (symbols[1] );
                    result = result + Math.Pow(168, 7) * (symbols[2] );
                    result = result + Math.Pow(168, 6) * (symbols[3] );
                    result = result + Math.Pow(168, 5) * (symbols[4] );
                    result = result + Math.Pow(168, 4) * (symbols[5] );
                    result = result + Math.Pow(168, 3) * (symbols[6] );
                    result = result + Math.Pow(168, 2) * (symbols[7]);
                    result = result + Math.Pow(168, 1) * (symbols[8] );
                    result = result +  symbols[9];
                    result = result + symbols[10];
                    Console.WriteLine(result );
                    break;
                case 12:
                    result = Math.Pow(168, 10) * (symbols[0] );
                    result = result + Math.Pow(168, 9) * (symbols[1] );
                    result = result + Math.Pow(168, 8) * (symbols[2]);
                    result = result + Math.Pow(168, 7) * (symbols[3] );
                    result = result + Math.Pow(168, 6) * (symbols[4] );
                    result = result + Math.Pow(168, 5) * (symbols[5] );
                    result = result + Math.Pow(168, 4) * (symbols[6] );
                    result = result + Math.Pow(168, 3) * (symbols[7] );
                    result = result + Math.Pow(168, 2) * (symbols[8] );
                    result = result + Math.Pow(168, 1) * (symbols[9]);
                    result = result +  symbols[10];
                    result = result + symbols[11];
                    Console.WriteLine(result);
                    break;
                case 13:
                    result = Math.Pow(168, 11) * (symbols[0] );
                    result = result + Math.Pow(168, 10) * (symbols[1] );
                    result = result + Math.Pow(168, 9) * (symbols[2] );
                    result = result + Math.Pow(168, 8) * (symbols[3] );
                    result = result + Math.Pow(168, 7) * (symbols[4] );
                    result = result + Math.Pow(168, 6) * (symbols[5] );
                    result = result + Math.Pow(168, 5) * (symbols[6] );
                    result = result + Math.Pow(168, 4) * (symbols[7] );
                    result = result + Math.Pow(168, 3) * (symbols[8] );
                    result = result + Math.Pow(168, 2) * (symbols[9]);
                    result = result + Math.Pow(168, 1) * (symbols[10]);
                    result = result +  symbols[11];
                    result = result + symbols[12];
                    Console.WriteLine(result );
                    break;
                case 14:
                    result =  Math.Pow(168, 12) * (symbols[0] );
                    result = result + Math.Pow(168, 11) * (symbols[1] );
                    result = result + Math.Pow(168, 10) * (symbols[2] );
                    result = result + Math.Pow(168, 9) * (symbols[3] );
                    result = result + Math.Pow(168, 8) * (symbols[4] );
                    result = result + Math.Pow(168, 7) * (symbols[5] );
                    result = result + Math.Pow(168, 6) * (symbols[6] );
                    result = result + Math.Pow(168, 5) * (symbols[7] );
                    result = result + Math.Pow(168, 4) * (symbols[8] );
                    result = result + Math.Pow(168, 3) * (symbols[9]);
                    result = result + Math.Pow(168, 2) * (symbols[10]);
                    result = result + Math.Pow(168, 1) * (symbols[11] );
                    result = result +  symbols[12];
                    result = result + symbols[13];
                    Console.WriteLine(result );
                    break;
                case 15:
                    result = Math.Pow(168, 13) * (symbols[0] );
                    result = result + Math.Pow(168, 12) * (symbols[1] );
                    result = result + Math.Pow(168, 11) * (symbols[2] );
                    result = result + Math.Pow(168, 10) * (symbols[3]);
                    result = result + Math.Pow(168, 9) * (symbols[4] );
                    result = result + Math.Pow(168, 8) * (symbols[5] );
                    result = result + Math.Pow(168, 7) * (symbols[6] );
                    result = result + Math.Pow(168, 6) * (symbols[7]);
                    result = result + Math.Pow(168, 5) * (symbols[8] );
                    result = result + Math.Pow(168, 4) * (symbols[9] );
                    result = result + Math.Pow(168, 3) * (symbols[10]);
                    result = result + Math.Pow(168, 2) * (symbols[11] );
                    result = result + Math.Pow(168, 1) * (symbols[12] );
                    result = result +  symbols[13];
                    result = result + symbols[14];
                    Console.WriteLine(result );
                    break;
                case 16:
                    result = Math.Pow(168, 14) * (symbols[0] );
                    result = result + Math.Pow(168, 13) * (symbols[1]);
                    result = result + Math.Pow(168, 12) * (symbols[2] );
                    result = result + Math.Pow(168, 11) * (symbols[3]);
                    result = result + Math.Pow(168, 10) * (symbols[4]);
                    result = result + Math.Pow(168, 9) * (symbols[5] );
                    result = result + Math.Pow(168, 8) * (symbols[6] );
                    result = result + Math.Pow(168, 7) * (symbols[7] );
                    result = result + Math.Pow(168, 6) * (symbols[8]);
                    result = result + Math.Pow(168, 5) * (symbols[9] );
                    result = result + Math.Pow(168, 4) * (symbols[10] );
                    result = result + Math.Pow(168, 3) * (symbols[11] );
                    result = result + Math.Pow(168, 2) * (symbols[12] );
                    result = result + Math.Pow(168, 1) * (symbols[13] );
                    result = result +  symbols[14];
                    result = result + symbols[15];
                    Console.WriteLine(result);
                    break;
            }
        }
    }
}
