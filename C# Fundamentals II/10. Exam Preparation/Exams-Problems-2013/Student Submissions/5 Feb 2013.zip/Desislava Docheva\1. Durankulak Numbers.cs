using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace trerte
{
    class Program
    {
        static void Main()
        {
            string sss=Console.ReadLine();
            int num;
            if(sss="fA"){
                
                num==64;

                Console.WriteLine("trte", sss);
            }
        }
    }
}
