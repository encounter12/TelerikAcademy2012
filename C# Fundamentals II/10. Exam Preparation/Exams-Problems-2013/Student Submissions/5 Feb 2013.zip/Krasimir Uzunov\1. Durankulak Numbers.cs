using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        string line = Console.ReadLine();
        int number = 0;
        int counter = 0;
        for (int i = line.Length - 1; i >= 0; i--)
        {
            if (Regex.IsMatch(line[i].ToString(), "[a-z]"))
            {
                number += (((int)line[i] - 96) * 26);
            }
            else
            {
                if (i == line.Length - 1)
                {
                    number += ((int)line[i] - 65);
                    counter++;
                }
                else
                {
                    double pow = Math.Pow(168, counter);
                    number += ((int)line[i] - 65) * (int)pow;
                    counter++;
                }
            } 
        }
        Console.WriteLine(number);
    }
}
