using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Third
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();//"100 100 100";
            string[] arrStr = input.Split(' ');
            int[] dimensions = new int[3];

            for (int i = 0; i < 3; i++)
            {
                dimensions[i] = int.Parse(arrStr[i].Trim());
            }

            input = Console.ReadLine(); //"1 2 2";
            arrStr = input.Split(' ');
            int[] startCoord = new int[3];

            for (int i = 0; i < 3; i++)
            {
                startCoord[i] = int.Parse(arrStr[i].Trim());
            }

            input = Console.ReadLine();//"0 1 0";
            arrStr = input.Split(' ');
            int[] directions = new int[3];

            for (int i = 0; i < 3; i++)
            {
                directions[i] = int.Parse(arrStr[i].Trim());
            }

            int[] currentPosition = new int[3];

            for (int i = 0; i < 3; i++)
			{
			    currentPosition[i] = startCoord[i];
			}

            bool[,,] visited = new bool[dimensions[0], dimensions[1],dimensions[2]];

            visited = InitVisited(visited,dimensions);
            int[] lastPosition = new int[3];

            //Print3D(visited);

            while (visited[currentPosition[0]-1,currentPosition[1]-1,currentPosition[2]-1] != true)
            {
                visited[currentPosition[0] - 1, currentPosition[1] - 1, currentPosition[2] - 1] = true;

                for (int i = 0; i < 3; i++)
                {
                    if (currentPosition[i] == dimensions[i])
                    {
                        if (directions[i] == 1)
                        {
                            directions[i] = -1;
                        }
                    }
                    else if (currentPosition[i] - 1 == 0)
                    {
                        if (directions[i] == -1)
                        {
                            directions[i] = 1;
                        }
                    }
                }

                for (int i = 0; i < 3; i++)
                {
                    lastPosition[i] = currentPosition[i];
                }

                currentPosition = MoveOnce(dimensions, directions, currentPosition);

                //foreach (var item in currentPosition)
                //{
                //    Console.Write("{0} ", item);
                //}

                //Console.WriteLine();
            }

            foreach (var item in lastPosition)
            {
                Console.Write("{0} ", item);
            }

        }

        static public int[] MoveOnce(int[] dimensions, int[] directions, int[] currentPos)
        {
            for (int i = 0; i < 3; i++)
            {
                if (directions[i] > 0)
                {
                    currentPos[i]++;
                }
                else if (directions[i] < 0)
                {
                    currentPos[i]--;
                }
            }

            return currentPos;
        }

        public static bool[, ,] InitVisited(bool[,,] visited, int[] dimensions)
        {
            for (int i = 0; i < visited.GetLength(0); i++)
            {
                for (int j = 0; j < visited.GetLength(1); j++)
                {
                    for (int k = 0; k < visited.GetLength(2); k++)
                    {
                        visited[i, 0, 0] = true;
                        visited[i, 0, dimensions[2]-1] = true;
                        visited[i, dimensions[1]-1, 0] = true;
                        visited[i, dimensions[1]-1, dimensions[2]-1] = true;

                        visited[0, j, 0] = true;
                        visited[dimensions[0]-1, j, 0] = true;
                        visited[dimensions[0]-1, j, dimensions[2]-1] = true;
                        visited[0, j, dimensions[2]-1] = true;

                        visited[0, 0, k] = true;
                        visited[dimensions[0]-1, 0, k] = true;
                        visited[dimensions[0]-1, dimensions[1]-1, k]=true;
                        visited[0, dimensions[1]-1, k] = true;

                    }
                }
            }

            return visited;
        }

        static public void Print3D(bool[, ,] visited)
        {
            for (int i = 0; i < visited.GetLength(0); i++)
            {
                for (int j = 0; j < visited.GetLength(1); j++)
                {
                    for (int k = 0; k < visited.GetLength(2); k++)
                    {
                        Console.Write("{0}({1},{2},{3}) ", visited[i,j,k], i, j, k);
                    }

                    Console.WriteLine();
                }

                Console.WriteLine();
            }

            Console.WriteLine();
        }
    }
}
