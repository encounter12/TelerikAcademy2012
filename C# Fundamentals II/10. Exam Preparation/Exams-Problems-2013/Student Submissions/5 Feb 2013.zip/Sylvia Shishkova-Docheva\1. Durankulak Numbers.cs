using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;
using System.Threading.Tasks;
using System.Globalization;

class DurankulakNumbers
{
    public static Encoding enc = new UTF8Encoding(true, true);

    static string[] GenerateLetters()
    {
        string[] durankulakNums = new string[168];
        Encoding enc = new UTF8Encoding(true, true);

        for (int i = 0; i < 26; i++)
        {
            durankulakNums[i] = ((char)(i + 65)).ToString();
        }

        int k = 26;
        int end = k + 26;
        for (int j = 0; j < 6; j++)
        {
            for (int i = k; i < end; i++)
            {
                durankulakNums[i] = durankulakNums[j].ToLowerInvariant() + durankulakNums[i - k];
            }

            k += 26;
            end = k + 26;
            if (k == 156)
            {
                end = 168;
            }
        }
        return durankulakNums;
    }

    static BigInteger ConvertToDecimal(List<string> numsToMatch, string[] durankulakTable)
    {
        List<int> numsToConvert = new List<int>();
        for (int i = 0; i < numsToMatch.Count; i++)
        {
           int digit = Array.IndexOf(durankulakTable, (numsToMatch[i]));
           numsToConvert.Add(digit);
        }

        BigInteger result = 0;
        for (int i = 0; i < numsToConvert.Count; i++)
        {
            double power = Math.Pow(168, Convert.ToDouble(i));
            result = result + numsToConvert[i] * Convert.ToInt64(power);
           
        }
        return result;
    }
    static void Main()
    {
        string[] durankulakTable = GenerateLetters();
        string input = Console.ReadLine();

        List<string> numsToMatch = new List<string>();
        string compositeNum = "";

        for (int i = input.Length - 1; i >=0 ; i--)
        {
            if (char.IsUpper(input[i]))
            {
                if (compositeNum != "")
                {
                    numsToMatch.Add(compositeNum);
                }
                compositeNum = input[i].ToString();
            }
            if (char.IsLower(input[i]))
            {
                compositeNum = input[i] + compositeNum;
            }
        }

        if (compositeNum != "")
        {
            numsToMatch.Add(compositeNum);
        }

        BigInteger decimalNum = 0;
        decimalNum = ConvertToDecimal(numsToMatch,durankulakTable);
        Console.WriteLine(decimalNum);
    }
}
