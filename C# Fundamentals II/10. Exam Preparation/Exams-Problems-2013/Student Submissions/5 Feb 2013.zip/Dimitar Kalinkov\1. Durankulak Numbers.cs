using System;
using System.Collections.Generic;

class DurankulakNumbers
{
    static void Main()
    {
        string duranNumber = Console.ReadLine();
        List<long> numbers = new List<long>();

        for (int i = 0; i < duranNumber.Length; i++)
        {
            if (i != duranNumber.Length - 1)
            {
                if (duranNumber[i] < 95)
                {
                    numbers.Add(duranNumber[i] - 'A');
                }
                else
                {
                    int number = (((duranNumber[i] - 'a') + 1) * 26) + (duranNumber[i + 1] - 'A');
                    numbers.Add(number);
                    i++;
                }
            }
            else
            {
                numbers.Add(duranNumber[i] - 'A');
            }
        }

        long decNum = 0, pow = numbers.Count - 1;
        foreach (int num in numbers)
        {
            decNum += num * (long)Math.Pow(168, pow);
            pow--;
        }

        Console.WriteLine(decNum);
    }
}