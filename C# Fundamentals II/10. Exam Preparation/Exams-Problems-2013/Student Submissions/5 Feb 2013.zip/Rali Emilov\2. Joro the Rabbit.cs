using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rabbit
{
	class Program
	{
		static void Main(string[] args)
		{
			string input = Console.ReadLine();
			string[] numbersString = input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
			int[] terrain = new int[numbersString.Length];
			int[,] reach = new int[3000, 3000];

			for (int i = 0; i < numbersString.Length; i++)
			{
				terrain[i] = int.Parse(numbersString[i]);
			}

			Console.WriteLine(terrain.Length);

			//foreach (var item in terrain)
			//{
			//	Console.WriteLine(item);
			//}

			//for (int i = 0; i < terrain.Length; i++)
			//{
			//	for (int j = 0; j < terrain.Length; j++)
			//	{
			//		if (terrain[i] < terrain[(i + j) % (terrain.Length)])
			//		{
			//			reach[i, j] = (i + j) % (terrain.Length);
			//		}
			//	}
			//}

			//int cnt = 0,
			//	ans = 0;
			//for (int i = 0; i < 10; i++)
			//{
			//	for (int j = 1; j < 10; j++)
			//	{
			//		//if (reach[
			//		Console.Write("{0} ", reach[i, j]);
			//	}
			//	Console.WriteLine();
			//}
		}
	}
}
