using System;

class Program
{
    static void Main()
    {
        string input = Console.ReadLine();
        string alphabet = "ABCDEFGHIGKLMNOPQRSTUVWXYZ";
        char[] arr = new char[input.Length];
        arr = input.ToUpper().ToCharArray();
        Array.Reverse(arr);
        input = string.Empty;
        for (int i = 0; i < arr.Length; i++)
        {
            input = input + arr[i];
        }
        double result = 0;
        int pow = 0;
        int numericBase = 26;
        int max = 168;
        for (int i = 0; i < arr.Length; i++)
        {
            if (i == 0)
            {
                int index = alphabet.IndexOf(input[i]);
                
                result += index * Math.Pow(numericBase, pow);
                pow++;
            }
            else if(i == 1)
            {
                int index = alphabet.IndexOf(input[i]);
                index += 1;
                result += index * Math.Pow(numericBase, pow);
                pow++;
            }
            else
            {
                
                int index = alphabet.IndexOf(input[i]);
                if (index == 0)
                {
                    index = 1;
                    result += index * max - 26;
                }
                else
                {
                    result += index * max;
                    max *= 26;
                }
            }

        }
        Console.WriteLine(result);
    }
}