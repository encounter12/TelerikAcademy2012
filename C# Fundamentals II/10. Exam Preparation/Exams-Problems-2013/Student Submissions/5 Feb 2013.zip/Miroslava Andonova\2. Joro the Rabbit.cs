using System;

class task2
{
    static void Main()
    {
        string digits = Console.ReadLine();
        string[] separatedDigits = digits.Split(',');
        int[] intdigits = new int[separatedDigits.Length];
        int minValue=-1000,index=0, step=1,numberOfJumps=1, maxnumberOfJumps=1,tempIndex=0;
        bool stop = false,breakstep=false;
        for (int i = 0; i < separatedDigits.Length; i++)
        {
            intdigits[i] = int.Parse(separatedDigits[i]);
        }
        bool [] visited= new bool[separatedDigits.Length];
        int left = separatedDigits.Length, right = separatedDigits.Length;
        for (int i = 1; i < separatedDigits.Length; i++)
        {
            tempIndex = 0;
            while (stop == false)
            {
                if (tempIndex + i < separatedDigits.Length)
                {
                    if (visited[tempIndex + i] == false)
                    {
                        if (intdigits[tempIndex + i] > intdigits[tempIndex])
                        {
                            visited[tempIndex] = true;
                            numberOfJumps++;
                        }
                        else
                        {
                            stop = true;
                            break;
                        }
                    }
                    else
                    {
                        stop = true;
                        break;
                    }
                    tempIndex += i;
                }
                else
                {
                    tempIndex=i-(separatedDigits.Length-1-tempIndex);
                }

            }
            if (maxnumberOfJumps < numberOfJumps)
            {
                maxnumberOfJumps = numberOfJumps;
            }
            numberOfJumps = 1;
            breakstep = false;
            for (int b = 0; b <  separatedDigits.Length; b++)
            {
                visited[b] = false;
            }
        }
        Console.WriteLine(maxnumberOfJumps);
    }
}
