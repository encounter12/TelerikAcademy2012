using System;
using System.Numerics;

namespace task1
{
    class task1
    {
        static void Main()
        {
            string digits = Console.ReadLine();
            int smallint=0, bigint = 0;
            BigInteger counter = 0, increase=1;
            for (int i = digits.Length-1; i>=0; i--)
            {
                if (i > 0)
                {
                    if (char.IsLower(digits[i - 1]))
                    {
                        smallint = (int)digits[i - 1];
                        bigint = (int)digits[i];
                        i--;
                        counter += (26 * Math.Abs(96 - smallint) + Math.Abs(65 - bigint)) * increase;
                        increase *= 168;
                    }
                    else
                    {
                        bigint = (int)digits[i];
                        counter += (Math.Abs(65 - bigint)) * increase;
                        increase *= 168;
                    }
                }
                else
                {
                    bigint = (int)digits[i];
                    counter += (Math.Abs(65 - bigint)) * increase;
                    increase *= 168;
                }
            }
             Console.WriteLine(counter);
        }
    }
}
