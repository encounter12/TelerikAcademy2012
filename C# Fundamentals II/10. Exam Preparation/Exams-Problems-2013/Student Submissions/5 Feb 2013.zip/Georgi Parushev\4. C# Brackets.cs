using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program04
{
    static void Main()
    {
        int rows = int.Parse(Console.ReadLine());
        string tabulator = Console.ReadLine();
        StringBuilder Output = new StringBuilder();
        int tabCounts = 0;
        bool IsNewLine = false;
        for (int row = 0; row < rows; row++)
        {
            string Input = Console.ReadLine();
            if (Input.Length > 0)
            {
                char previousChar = '4';
                if (row > 0)
                {
                    Output.AppendLine();
                }
                if ((Input[0] != '{') && (Input[0] != '}'))
                {
                    for (int i = 0; i < tabCounts; i++)
                    {
                        Output.Append(tabulator);
                    }
                    IsNewLine = false;
                }
                for (int j = 0; j < Input.Length; j++)
                {
                    char ch = Input[j];
                    if (ch=='\t')
                    {
                        ch = ' ';
                    }
                    if (ch == '{')
                    {
                        if (((j > 0) && (previousChar != '{') && (previousChar != '}'))||(!IsNewLine))
                        {
                            Output.AppendLine();
                        }
                        if (!IsNewLine)
                        {
                            for (int i = 0; i < tabCounts; i++)
                            {
                                Output.Append(tabulator);
                            }
                        }
                        Output.Append(ch);
                        tabCounts++;
                        if ((j != Input.Length - 1)&&(!IsNewLine))
                        {
                            Output.AppendLine();
                            for (int i = 0; i < tabCounts; i++)
                            {
                                Output.Append(tabulator);
                            }
                            IsNewLine = true;
                        }
                    }
                    else if (ch == '}')
                    {
                        if (((j > 0) && (previousChar != '{') && (previousChar != '}')) || (!IsNewLine))
                        {
                            Output.AppendLine();
                        }
                        tabCounts--;
                        if (!IsNewLine)
                        {


                            for (int i = 0; i < tabCounts; i++)
                            {
                                Output.Append(tabulator);
                            }
                        }
                        Output.Append(ch);
                        if ((j != Input.Length - 1)&&(!IsNewLine))
                        {
                            Output.AppendLine();
                            for (int i = 0; i < tabCounts; i++)
                            {
                                Output.Append(tabulator);
                            }
                            IsNewLine = true;
                        }
                    }
                    else if (ch != ' ')
                    {
                        if ((previousChar == ' ') && (!IsNewLine))
                        {
                            Output.Append(' ');
                        }
                        Output.Append(ch);
                        IsNewLine = false;
                    }
                    previousChar = ch;
                }
            }
        }
        Console.WriteLine(Output);
    }
}

/*
3
>>
{a{{}
}
}


5
....
using System; namespace Stars
{class Program{
static string[] separators
=new string[] { " " };}
}
*/
