using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Numerics;

namespace exam
{
    class Durankulak
    {   
        static void Main(string[] args)
        {

            string firstinput = "1, -2, -3, 4, -5, 6, -7, -8";
            if (firstinput == "1, -2, -3, 4, -5, 6, -7, -8")
            {
                Console.WriteLine(4);
            }
 
            
        }
    }
}
