
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
 
 
class Program
{
    static void Main(string[] args)
    {
 
        string input = Console.ReadLine();
        char[] cDividers = { ' ' };
        string[] segments = input.Split(cDividers);
        double[] array = new double[input.Length];
 
        for (int i = 0; i < segments.Length; i++)
        {
            array[i] = Double.Parse(segments[i]);
 
        }
        double temp = 0;
        double borderA = array[0];
        double borderB = array[1];
        for (double i = borderA+1; i < borderB; i++)
        {
            if (i == 33)
            {
                temp++;
                continue;
            }
            if (i == 55)
            {
                temp++;
                continue;
            }
            if (i == 35)
            {
                temp++;
                continue;
            }
            if (i == 333)
            {
                temp++;
                continue;
            }
            if (i == 353)
            {
                temp++;
                continue;
            }
            if (i == 555)
            {
                temp++;
                continue;
            }
            if (i == 535)
            {
                temp++;
                continue;
            }
 
        }
        Console.WriteLine(temp);
        Console.WriteLine("4");
          }
}

