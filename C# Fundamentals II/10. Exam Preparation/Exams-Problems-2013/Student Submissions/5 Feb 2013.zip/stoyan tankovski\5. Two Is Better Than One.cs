using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5TwoIsBetterThanOne
{
    class Program
    {
        static void Main(string[] args)
        {
            string task1 = Console.ReadLine();
            string task2 = Console.ReadLine();
            int percentage =int.Parse(Console.ReadLine());
            string[] task1Arr = task1.Split(' ');
            int[] TaskInts = new int[task1Arr.Length];
            
            int count = 0;
            for (decimal i = decimal.Parse(task1Arr[0]); i <= decimal.Parse(task1Arr[1]); i++)
            {
                int[] arrayInt = { 3, 5, 33, 55, 333, 555, 3333, 5555, 33333, 55555, 333333, 555555, 3333333, 5555555, 3333333, 5555555 };
                for (int j = 0; j < arrayInt.Length-1; j++)
                {
                    
                    if (i==arrayInt[j])
                    {
                        count++;
                        i = arrayInt[j + 1] - 1;
                    }
                    if (i >= arrayInt[j] && i < arrayInt[j + 1])
                    {
                        i = arrayInt[j + 1]-1;
                        break;
                    }
                }
                //if (i==3||i==5|i==33||i==55||i==333||i==555||i==3333||i==5555||i==33333||i==55555||i==333333||i==555555||i==3333333||i==5555555||i==33333333||i==55555555||i==3333333333||i==5555555555||i==33333333333||i==55555555555)
                //{
                //    count++;
                //}
            }
            Console.WriteLine(count);
            
            string[] task2Str = task2.Split(',');
            int[] array = new int[task2Str.Length];
            for (int i = 0; i < task2Str.Length; i++)
            {
               array[i]=int.Parse(task2Str[i]);
              
            }

            Array.Sort(array);
            double perc = (array.Length) * ((double)percentage / 100);
            int intPerc = (int)perc;
            if (perc % intPerc != 0)
            {
                intPerc += 1;
            }
            
            Console.WriteLine(array[intPerc-1]);
            
        }
    }
}