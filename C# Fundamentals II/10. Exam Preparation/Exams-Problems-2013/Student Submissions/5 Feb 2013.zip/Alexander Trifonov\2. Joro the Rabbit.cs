using System;
using System.Collections.Generic;

class Program
{
    static int result = 1;
    static int[] cells;
    static void CheckSteps(int step)
    {
        if (step >= cells.Length)
        {
            return;
        }

        for (int i = 0; i < cells.Length; i++)
        {
            int startsFrom = i;
            int previous = int.MinValue;
            int stepCounter = 0;
            while (true)
            {
                int value = cells[startsFrom];
                if (value > previous)
                {
                    stepCounter++;
                }
                else
                {
                    if (stepCounter > result)
                    {
                        result = stepCounter;
                    }
                    //stepCounter = 1;
                    break;
                }
                
                previous = value;
                startsFrom += step;
                if (startsFrom >= cells.Length)
                {
                    startsFrom = startsFrom % cells.Length;
                }
                if (startsFrom == i)
                {
                    if (stepCounter > result)
                    {
                        result = stepCounter;
                    }
                    break;
                }
            }
        }
        CheckSteps(step + 1);
    }
    static void Main()
    {
        string[] strInput = Console.ReadLine().Split(new string[]{", "}, StringSplitOptions.RemoveEmptyEntries);
        cells = new int[strInput.Length];
        for (int i = 0; i < strInput.Length; i++)
		{
            cells[i] = int.Parse(strInput[i]);
        }
        CheckSteps(1);
        Console.WriteLine(result);
    }
}

