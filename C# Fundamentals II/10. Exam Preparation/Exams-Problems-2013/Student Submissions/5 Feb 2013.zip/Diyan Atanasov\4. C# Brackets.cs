using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

class Brackets
{
    static string CalcTab(string tab, int rep)
    {
        string line = "";
        for (int i = 1; i <= rep; i++)
        {
            line += tab;
        }

        return line;
    }




    static void Copy(StringBuilder fix, int tabs, string tab)
    {
        Regex pat = new Regex(@"[ ]{2,n}");
        string format = "";

        for (int i = 1; i <= tabs; i++)
        {
            format += tab;
        }

        Console.WriteLine(format + pat.Replace(fix.ToString(), "").Trim());
        fix.Clear();


    }

    static void Prints(StringBuilder fix)
    {
        Regex pat = new Regex(@"[ ]{2,n}");

        Console.WriteLine(pat.Replace(fix.ToString(), "").Trim());
        fix.Clear();


    }

    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string tab = Console.ReadLine();
        string lineTab = "";
        int inBracket = 0;
        bool afterBra = false;
        string asd = "";
        StringBuilder fix = new StringBuilder();
        string line = "";
        string total = "";
      // using (StreamReader s = new StreamReader("new.txt"))
      // {
            for (int i = 0; i < n; i++)
            {

                line = Console.ReadLine();//s.ReadLine(); //

                for (int j = 0; j < line.Length; j++)
                {

                    if (line[j] == '{')
                    {
                        //Print(fix, inBracket, tab);
                        fix.Append('\n');
                        fix.Append(lineTab);
                        fix.Append('{');
                        fix.Append('\n');
                        inBracket++;
                        lineTab = CalcTab(tab, inBracket);
                        continue;
                    }

                    if (line[j] == '}')
                    {
                        //Print(fix, inBracket, tab);
                        inBracket--;
                        lineTab = CalcTab(tab, inBracket);
                        fix.Append('\n');
                        fix.Append(lineTab);
                        fix.Append('}');
                        fix.Append('\n');
                        continue;
                    }

                    fix.Append(lineTab);

                    while (line[j] == ' ')
                    {
                        j++;
                        
                    }
                    if (line[j] == '{' || line[j] == '}')
                    {
                        continue;
                    }

                    while (j < line.Length)
                    {
                       
                        fix.Append(line[j]);

                        if (j + 1 < line.Length)
                        {
                            if (line[j + 1] == '{' || line[j + 1] == '}')
                            {
                                break;
                            }
                        }
                        
                        j++;

                    }

                }

                fix.Append('\n');

            }
      // }

       
       Regex format = new Regex(@"[ ]{2,}");
       string final = format.Replace(fix.ToString(), " ");
       StringReader read = new StringReader(final);
       string print = read.ReadLine();

        while (print != null)
        {
            if (!string.IsNullOrEmpty(print))
            {
                Console.WriteLine(print.Trim());
            }
            print = read.ReadLine();

        }

    }
}
    