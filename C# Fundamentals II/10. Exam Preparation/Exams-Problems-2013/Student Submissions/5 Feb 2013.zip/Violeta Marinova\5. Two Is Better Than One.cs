using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static string[] separators = new string[] { " " };
    static string[] separators1 = new string[] { "," };
    static int[] digits = new int[] { 3, 5 };

    static void Main()
    {

        string ABStr = Console.ReadLine();
        string[] AB = ABStr.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        // List<int> palindromes = new List<int>();
        int A = int.Parse(AB[0]);
        int B = int.Parse(AB[1]);
        int counterPalindromes = 0;
        for (int i = A; i <= B; i++)
        {
            int check = i % 10;
            if(((check==3)||(check==5))&&(IsPalindrome(i)))
            {

                counterPalindromes++;
            }
        }



        //task2




        string line = Console.ReadLine();
        int p = int.Parse(Console.ReadLine());
        string[] lineArr = line.Split(separators1, StringSplitOptions.RemoveEmptyEntries);
        int[] array = new int[lineArr.Length];

        for (int j = 0; j < lineArr.Length; j++)
        {
            array[j] = int.Parse(lineArr[j]);
        }

        int  numberOfElementInt;
        if (p == 0)
        {
            numberOfElementInt = 0;
        }
        else
        {
            decimal numberOfElement = (p / 100.0m) * lineArr.Length;
            numberOfElement = Math.Round(numberOfElement, MidpointRounding.AwayFromZero);
            numberOfElementInt = (int)numberOfElement;
        }

        Array.Sort(array);
        int index = 0;
        while (true)
        {
            index++;
            if (index == numberOfElementInt)
            {
                break;
            }            
        }

        //out
        Console.WriteLine(counterPalindromes);

        Console.WriteLine(array[index-1]);


    }

    private static bool IsPalindrome(int num)
    {
        bool result = false;
        int n = num;
        int rev = 0;
        int dig;
        bool flag = true;


        while ((num > 0) && flag)
        {
            dig = num % 10;
            if ((dig == 3) || (dig == 5))
            {
                flag = true;
            }
            else
            {
                flag = false;
                break;
            }
            rev = rev * 10 + dig;
            num = num / 10;

        }

        if (n == rev)
        {
            result = true;
        }
        if ((n <= 9) && (!digits.Contains(n)))
        {
            result = false;
        }
        return result;
    }
}
