using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Durankulak_Numbers
{
    class Program
    {

        static void Main(string[] args)
        {
            string[] Durankulak_Numbers = new string[168];
            char first = 'A';
            for (int i = 0; i < 26; i++)
            {
                Durankulak_Numbers[i] = first.ToString();
                first++;
            }

            first = 'A';
            for (int i = 26; i < 52; i++)
            {
                Durankulak_Numbers[i] = 'a'+first.ToString();
                first++;
            }

            first = 'A';
            for (int i = 52; i < 78; i++)
            {
                Durankulak_Numbers[i] = 'b' + first.ToString();
                first++;
            }

            first = 'A';
            for (int i = 78; i < 104; i++)
            {
                Durankulak_Numbers[i] = 'c' + first.ToString();
                first++;
            }

            first = 'A';
            for (int i = 104; i < 130; i++)
            {
                Durankulak_Numbers[i] = 'd' + first.ToString();
                first++;
            }

            first = 'A';
            for (int i = 130; i < 156; i++)
            {
                Durankulak_Numbers[i] = 'e' + first.ToString();
                first++;
            }

            first = 'A';
            for (int i = 156; i < 168; i++)
            {
                Durankulak_Numbers[i] = 'f' + first.ToString();
                first++;
            }

            string input = Console.ReadLine();

            //input.Reverse();
            StringBuilder temp = new StringBuilder();
            temp.Append(input);
            StringBuilder temp_holder = new StringBuilder();
            int index = 0;
            StringBuilder result = new StringBuilder();
            BigInteger number = 0;
            //temp.reve

            List<string> keeper = new List<string>();
            for (int i = 0; i < temp.Length; i++)
            {
                temp_holder.Append(temp[i]);
                //Console.WriteLine(temp_holder);
                for (int j = 0; j < Durankulak_Numbers.Length; j++)
                {
                    if (temp_holder.ToString() == Durankulak_Numbers[j])
                    {
                        keeper.Add(j.ToString());
                        temp_holder.Clear();
                        index++;
                    }
                }
            }

            //Console.WriteLine(result);
            //keeper.Reverse();
            index = index - 1;
            foreach (var item in keeper)
            {
                //Console.WriteLine(index);
                //Console.WriteLine(item);
                number += (Convert.ToInt32(item) * (BigInteger)Math.Pow(168, index));
                //int temo = (int)Math.Pow(168, index);
               // Console.WriteLine(temo);
                index--;

                //result.Append(number)
            }

            Console.WriteLine(number);

        }
    }
}
