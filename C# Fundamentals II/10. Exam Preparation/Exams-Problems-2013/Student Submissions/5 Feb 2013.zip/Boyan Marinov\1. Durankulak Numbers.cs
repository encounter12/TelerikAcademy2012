using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;

class DurankulakNumbers
{
    static List<string> ParseToNums(string input)
    {
        List<string> result = new List<string>();
        StringBuilder number = new StringBuilder();
        //if(input[index] >= 'A' && input[index] <= 'Z')
        //{
        //    result.Add(input[index].ToString());
        //    index++;
        //}
        //while (index < input.Length-1)
        //{

        //}
        bool inNumber = false;
        for (int i = 0; i < input.Length; i++)
        {
            char c = input[i];
            if (c >= 'a' && c <= 'z')
            {
                if (number.ToString() != String.Empty)
                {
                    result.Add(number.ToString());
                    number.Clear();
                    inNumber = true;
                }
                else
                {
                    number.Append(c);
                    inNumber = true;
                }
            }
            else if (c >= 'A' && c <= 'Z')
            {
                if (inNumber)
                {
                    number.Append(c);
                    result.Add(number.ToString());
                    number.Clear();
                    inNumber = false;
                }
                else
                {
                    result.Add(c.ToString());
                    
                }
            }
        }
        if (number.ToString() != string.Empty)
        {
            result.Add(number.ToString());
        }
        return result;
    }

    static int ParseADuranNumber(string number)
    {
        if (number.Length == 1)
        {
            return (int)(number[0] - 'A');
        }
        else
        {
            int first = (int)(number[1] - 'A');
            int second = (int)(number[0] - 'a' + 1) * 26;
            return first + second;
        }
    }
    static BigInteger Pow(int num, int deg)
    {
        BigInteger result = 1;
        for (int i = 0; i < deg; i++)
        {
            result *= num;
        }
        return result;
    }

    static BigInteger ConvertTo168Base(List<string> nums)
    {
        BigInteger result = 0;
        int degree = 0;
        for (int i = nums.Count - 1; i >= 0; i--)
        {
            int currentNumValue = ParseADuranNumber(nums[i]);
            result += Pow(168, degree) * currentNumValue;
            degree++;
        }
        return result;
    }
    static BigInteger ConvertToDuranNumber(string input)
    {
        List<string> durans = ParseToNums(input);
        BigInteger result = ConvertTo168Base(durans);
        return result;
    }

    static void Main()
    {
        List<string> duranNum = new List<string>();
        string input = Console.ReadLine();
        //string input = "fLABaC";
        //List<string> durannum = ParseToNums(input);
        //foreach (var item in durannum)
        //{
        //    Console.WriteLine(item);
        //}
        Console.WriteLine(ConvertToDuranNumber(input));
        
    }
}
