using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

  class Brackets
    {
        static void Main()
        {
            string strN = Console.ReadLine();
            int n = int.Parse(strN);
            string indStr = Console.ReadLine();
            string[] lines=new string[n];
            for (int count = 0; count < n; count++)
            {
                lines[count] = Console.ReadLine();
            }
            StringBuilder sbLine = new StringBuilder();
            bool isInBrackets = false;
            int indNum = 0;
            int countWhite = 0;
            for (int count = 0; count < n; count++)
            {
                string line = lines[count];
                sbLine.Clear();
                for (int index = 0; index < line.Length; index++)
                {
                    if ((line[index]!='{') && (line[index]!='}'))
                    {
                        if (line[index]==' ')
                        {
                            while ((index<line.Length)&&(line[index+1]==' '))
                            {
                                index++;
                            }
                        }
                        if (sbLine.ToString() == "")
                        {
                            for (int times = 0; times < indNum; times++)
                            {
                                sbLine.Append(indStr);
                            }
                        }
                        if (countWhite>1)
                        {
                             sbLine.Append(' ');
                             countWhite = 0;
                        }
                        sbLine.Append(line[index]);
                    }
                    else if (line[index]=='{')
                    {
                        if (sbLine.ToString() != "")
                        {
                            Console.WriteLine(sbLine.ToString().Trim());
                        }
                        sbLine.Clear();
                        for (int times = 0; times < indNum; times++)
                        {
                            sbLine.Append(indStr);
              
                        }
                        sbLine.Append('{');
                        if (sbLine.ToString() != "")
                        {
                            Console.WriteLine(sbLine.ToString().Trim());
                        }
                        
                        sbLine.Clear();
                        indNum++;
                    }
                    else if (line[index] == '}')
                    {
                        indNum--;
                        if (sbLine.ToString()!="")
                        {
                            Console.WriteLine(sbLine.ToString().Trim());
                        }
                        sbLine.Clear();
                        for (int times = 0; times < indNum; times++)
                        {
                            sbLine.Append(indStr);
                        }
                        sbLine.Append('}');
                        Console.WriteLine(sbLine.ToString().Trim());
                        sbLine.Clear();
                    }
                }
                if (sbLine.ToString() != "")
                {
                    Console.WriteLine(sbLine.ToString().Trim());
                }
            }
        }
    }
