using System;
  
class Program
{
    static void Main(string[] args)
    {
        char[] separators = { ' ', ',' };
        string[] terrainNUmbers = Console.ReadLine().Split(separators, StringSplitOptions.RemoveEmptyEntries);
        int[] tNUmbers = new int[terrainNUmbers.Length];
        for (int i = 0; i < tNUmbers.Length; i++)
        {
            tNUmbers[i] = int.Parse(terrainNUmbers[i]);
        }
        int countJumps = 0;
        int bestCount = 0;
        for (int j = 1; j < tNUmbers.Length; j++)
        {
            for (int i = 0; i < tNUmbers.Length; i++)
            {
                int currentPosition = j - 1;
                if (currentPosition + j > tNUmbers.Length - 1)
                {
                    currentPosition = (tNUmbers.Length - 1) - currentPosition;
                    int diff = (j - currentPosition) - 1;
                    currentPosition = 0 + diff;
                }
                else
                {
                    if (tNUmbers[currentPosition] < tNUmbers[currentPosition + j])
                    {
                        if (currentPosition + j > tNUmbers.Length - 1)
                        {
                            currentPosition = (tNUmbers.Length - 1) - currentPosition;
                            int diff = (j - currentPosition) - 1;
                            currentPosition = 0 + diff;
                        }
                        currentPosition += j;
                        countJumps++;
                    }
                }
            }
            if (countJumps > bestCount)
            {
                bestCount = countJumps;
            }
            countJumps = 0;
        }
        Console.WriteLine(bestCount);
    }
}