using System;

public class JoroTheRabbit
{
    public static bool[] used;
    private static void Main()
    {
        string numberString = Console.ReadLine();

        string[] numberStr = numberString.Split(',');

        int[] numbers = new int[numberStr.Length];
        used = new bool[numberStr.Length];

        for (int i = 0; i < numberStr.Length; i++)
        {
            numbers[i] = int.Parse(numberStr[i].Trim());
        }

        int startNumberIndex = 0;
        int maxCounter = 0;
        used = new bool[numberStr.Length];

        while (startNumberIndex < numberStr.Length)
        {
            for (int i = 0; i < numberStr.Length; i++)
            {
                used[i] = false;
            }

            for (int step = 1; step < numberStr.Length; step++)
            {
                int currentNumber = numbers[startNumberIndex];

                int counter = 1;
                int i = startNumberIndex;
                int visited = -1;
                while (++visited < numbers.Length)
                {
                    i += step;
                    if (i >= numbers.Length)
                    {
                        i -= numbers.Length;
                    }

                    if (numbers[i] <= currentNumber)
                    {
                        break;
                    }

                    if (used[i] == true)
                    {
                        continue;
                    }

                    counter++;
                    currentNumber = numbers[i];
                }

                if (maxCounter < counter)
                {
                    maxCounter = counter;
                }
            }

            startNumberIndex++;
        }

        Console.WriteLine(maxCounter);
    }
}