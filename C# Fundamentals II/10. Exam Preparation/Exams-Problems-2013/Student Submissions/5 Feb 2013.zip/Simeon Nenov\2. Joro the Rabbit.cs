using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApplication1
{
    class Program
    {
        public static bool retuned = false;
        public static int Jumps(string[] parseInput, int start, int step, int count)
        {
            if (start >= parseInput.Length) 
            {
                start = (start + step) - parseInput.Length;
            }
            if (parseInput[start] == "stop")
            {
                if (!retuned)
                {
                    Console.Write(count);
                }
                retuned = true;
                return count;
            }

            parseInput[start] = "stop";
            count++;
            Jumps(parseInput, start + step, step, count);

            //return count;
            return count;
        }

        public static int FreeStart(string[] parseInput)
        {
            int i = 0;
            foreach (var item in parseInput)
            {
                if (item != "stop")
                {
                    return i;
                }
                i++;
            }
            return 0;
        }

        static void Main(string[] args)
        {
            //string input = File.ReadAllText(@"C:\Test12.txt");
            string input = Console.ReadLine();
            input = input.Replace(" ", string.Empty);
            string[] parseInput = input.Split(',');
            int min = int.Parse(parseInput[0]);

            foreach (var item in parseInput)
            {
                int buff = int.Parse(item);
                if (buff < min) min = buff;
            }

            for (int i = 2; i < parseInput.Count(); i++) // <=    <        i=1, i=2
            {
                Jumps(parseInput, FreeStart(parseInput), i, 0);
            }

            //Console.Read();
        }
    }
}
