using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace FirstTask
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputNumber = Console.ReadLine();

            string[] allDigits = FillDigitsArray();
            BigInteger resultNumber = ConvertToDecimal(inputNumber, allDigits);
            Console.WriteLine(resultNumber);
        }

        private static BigInteger ConvertToDecimal(string inputNumber, string[] allDigits)
        {
            BigInteger power = 168;
            StringBuilder currentNumber = new StringBuilder();
            char currentChar = ' ';
            int index = inputNumber.Length-1;
            BigInteger result = 0;
            int value = 0;
            bool firstDigitPassed = false;

            while (true)
            {
                currentChar = inputNumber[index];


                if (index == 0 || inputNumber[index - 1] >= 65 && inputNumber[index - 1] <= 91)
                {
                    currentNumber.Append(currentChar.ToString());
                    index -= 1;
                }
                else
                {
                    currentNumber.Append(inputNumber[index - 1].ToString() + currentChar.ToString());
                    index -= 2;
                }

                for (int i = 0; i < 168; i++)
                {
                    if (allDigits[i] == currentNumber.ToString())
                    {
                        value = i;
                        break;
                    }
                }

                if (firstDigitPassed == true)
                {
                    result += power * value;
                    power *= 168;
                }
                else
                {
                    result += value;
                }
                firstDigitPassed = true;
                currentNumber.Clear();

                if (index < 0)
                {
                    break;
                }
            }
            return result;
        }

        private static string[] FillDigitsArray()
        {
            string[] allDigits = new string[168];
            int firstCharCode = 0;
            int secondCharCode = 95;

            for (int i = 0; i < 168; i++)
            {
                if (i % 26 == 0)
                {
                    firstCharCode = 65;
                    secondCharCode++;
                }


                if (i >= 0 && i <= 25)
                {
                    allDigits[i] = ((char)firstCharCode).ToString();
                    firstCharCode++;
                }

                if (i > 25)
                {
                    allDigits[i] = ((char)secondCharCode).ToString() + ((char)firstCharCode).ToString();
                    firstCharCode++;
                }
            }
            return allDigits;
        }


    }
}
