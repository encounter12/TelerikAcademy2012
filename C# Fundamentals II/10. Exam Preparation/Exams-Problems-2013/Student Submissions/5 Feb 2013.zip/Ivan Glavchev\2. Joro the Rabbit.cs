using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZaekaJoro
{
	class Program
	{
		private static int[] processInput(string input)
		{
			string[] separator = { ", " };
			string[] numbers = input.Split(separator, StringSplitOptions.None);
			int[] result = new int[numbers.Length];
			for (int i = 0; i != result.Length; ++i)
			{
				result[i] = int.Parse(numbers[i]);
			}
			return result;
		}
		static void Main(string[] args)
		{
			int[] terrain = processInput(Console.ReadLine());
			bool[] visited = new bool[terrain.Length];

			int current = 0, result = 0;
			for (int i = 0; i != terrain.Length; ++i)
			{
				current = longestIncrLength(terrain, visited, i);
				if (current > result)
				{
					result = current;
				}
			}
			Console.WriteLine(result);
		}
		private static int longestIncrLength(int[] terrain, bool[] visited, int startPos)
		{
			int result = 0;
			int current = 0;
			for (int i = 1; i != terrain.Length; ++i)
			{
				current = incrLength(terrain, visited, startPos, i);
				if (current > result)
				{
					result = current;
				}
			}
			return result;
		}
		private static int incrLength(int[] terrain, bool[] visited, int startPos, int step)
		{
			int result = 0;
			int curent = 0;
			int first = terrain[startPos] - 1;
			for (int i = startPos; !visited[i] && terrain[i] > first; i = (i + step)%terrain.Length)
			{
				first = terrain[i];
				result++;
				visited[i] = true;
			}
			initialize(visited);
			return result;
		}

		private static void initialize(bool[] visited)
		{
			for(int i=0 ; i!=visited.Length ; ++i)
			{
				visited[i] = false;
			}
		}
	}
}
