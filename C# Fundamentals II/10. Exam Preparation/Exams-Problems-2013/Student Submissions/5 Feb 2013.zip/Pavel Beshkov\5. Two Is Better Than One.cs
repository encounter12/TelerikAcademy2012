using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
 
class Problem5
{
    static bool CheckDigits(string rawNumber)
    {      
        foreach (char item in rawNumber)
        {
            if (item!='3' && item!='5')
            {
                return false;
            }
        }
        return true;
    }
    static bool CheckPalindrom(string word)
    {
        int start = 0;
        int end = word.Length - 1;
        bool isPalindrom = true;
        for (int index = 0; index < word.Length / 2; index++)
        {
            if (word[start] != word[end])
            {
                return false;
                //break;
            }
        }
        return isPalindrom;
    }
    static long CountPalindroms(long start,long end)
    {
        if (start<=2)
        {
            start = 3;
        }
        long remains=start%10;
        if (remains<=2 && remains>=0)
        {
            start += 3 - remains;
        }
        else if(remains==4)
        {
            start++;
        }
        else if (remains>=6)
        {
            start -= remains - 5;
        }
        long palindromCount = 0;
        for (long number = start; number <= end;number+=2)
        {
            string rawValue = number.ToString();
            if (CheckDigits(rawValue))
            {
                if (CheckPalindrom(rawValue))
                {
                    palindromCount++;
                }
            }           
        }             
        return palindromCount;
    }
    static void Main()
    {
        string line = Console.ReadLine();//"1 99";
        string[] AB = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        long a = long.Parse(AB[0]);
        long b = long.Parse(AB[1]);
        long count = CountPalindroms(a, b);
        line = Console.ReadLine(); //-2,-1,-4,-3";
        string[] numbers = line.Split(new char[] {' ',',' }, StringSplitOptions.RemoveEmptyEntries);
        int[] arr = new int[numbers.Length];//{10,9,8,7,6,5,4,3,2,1 };//{-2,-1,-4,-3};
        for (int i = 0; i < numbers.Length; i++)
        {
            arr[i] = int.Parse(numbers[i]);
        }
        line = Console.ReadLine(); //"50";//Console.ReadLine();
        int percent = int.Parse(line);
        int result = FindElement(arr, percent);
        Console.WriteLine(count);
        Console.WriteLine(result);
    }
    static int FindElement(int[] elements, int percent)
    {
        Array.Sort(elements);
        decimal percentFloat = elements.Length* percent * 0.01M;
        int wholePart = (int)(elements.Length * (percent * 0.01));
        if (wholePart < percentFloat)
        {
            wholePart++;
        }
        int elementIndex = wholePart - 1;
        return elements[elementIndex];
    }
}