using System;

class Program
{
    static void Main(string[] args)
    {
        string line = Console.ReadLine();

        long result = 0;
        int counter = 0;
        for (int i = line.Length - 1; i >= 0; i--)
        {
            long buffer = 0;
            if (i - 1 >= 0 && (int)line[i - 1] > 96 && (int)line[i - 1] < 103)
            {
                if (counter > 0)
                {
                    buffer = (((int)line[i] - 65) + ((int)line[i - 1] - 96) * 26) * (long)Math.Pow(168, counter);
                    counter++;
                    i--;
                }
                else
                {
                    buffer = ((int)line[i] - 65) + ((int)line[i - 1] - 96) * 26;
                    counter++;
                    i--;
                }
            }
            else
            {
                if (counter > 0)
                {
                    buffer = ((int)line[i] - 65) * (long)Math.Pow(168, counter);
                    counter++;
                }
                else
                {
                    buffer = (int)line[i] - 65;
                    counter++;
                }
            }
            result += buffer;

        }
        Console.WriteLine(result);

    }
}
