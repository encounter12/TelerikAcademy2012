
using System;

 

public class Problem1

{

    private static void Main()

    {

        string[] tab = 

            {

                 "A"

                ,"B"

                ,"C"

                ,"D"

                ,"E"

                ,"F"

                ,"G"

                ,"H"

                ,"I"

                ,"J"

                ,"K"

                ,"L"

                ,"M"

                ,"N"

                ,"O"

                ,"P"

                ,"Q"

                ,"R"

                ,"S"

                ,"T"

                ,"U"

                ,"V"

                ,"W"

                ,"X"

                ,"Y"

                ,"Z"

                ,"aA"

                ,"aB"

                ,"aC"

                ,"aD"

                ,"aE"

                ,"aF"

                ,"aG"

                ,"aH"

                ,"aI"

                ,"aJ"

                ,"aK"

                ,"aL"

                ,"aM"

                ,"aN"

                ,"aO"

                ,"aP"

                ,"aQ"

                ,"aR"

                ,"aS"

                ,"aT"

                ,"aU"

                ,"aV"

                ,"aW"

                ,"aX"

                ,"aY"

                ,"aZ"

                ,"bA"

                ,"bB"

                ,"bC"

                ,"bD"

                ,"bE"

                ,"bF"

                ,"bG"

                ,"bH"

                ,"bI"

                ,"bJ"

                ,"bK"

                ,"bL"

                ,"bM"

                ,"bN"

                ,"bO"

                ,"bP"

                ,"bQ"

                ,"bR"

                ,"bS"

                ,"bT"

                ,"bU"

                ,"bV"

                ,"bW"

                ,"bX"

                ,"bY"

                ,"bZ"

                ,"cA"

                ,"cB"

                ,"cC"

                ,"cD"

                ,"cE"

                ,"cF"

                ,"cG"

                ,"cH"

                ,"cI"

                ,"cJ"

                ,"cK"

                ,"cL"

                ,"cM"

                ,"cN"

                ,"cO"

                ,"cP"

                ,"cQ"

                ,"cR"

                ,"cS"

                ,"cT"

                ,"cU"

                ,"cV"

                ,"cW"

                ,"cX"

                ,"cY"

                ,"cZ"

                ,"dA"

                ,"dB"

                ,"dC"

                ,"dD"

                ,"dE"

                ,"dF"

                ,"dG"

                ,"dH"

                ,"dI"

                ,"dJ"

                ,"dK"

                ,"dL"

                ,"dM"

                ,"dN"

                ,"dO"

                ,"dP"

                ,"dQ"

                ,"dR"

                ,"dS"

                ,"dT"

                ,"dU"

                ,"dV"

                ,"dW"

                ,"dX"

                ,"dY"

                ,"dZ"

                ,"eA"

                ,"eB"

                ,"eC"

                ,"eD"

                ,"eE"

                ,"eF"

                ,"eG"

                ,"eH"

                ,"eI"

                ,"eJ"

                ,"eK"

                ,"eL"

                ,"eM"

                ,"eN"

                ,"eO"

                ,"eP"

                ,"eQ"

                ,"eR"

                ,"eS"

                ,"eT"

                ,"eU"

                ,"eV"

                ,"eW"

                ,"eX"

                ,"eY"

                ,"eZ"

                ,"fA"

                ,"fB"

                ,"fC"

                ,"fD"

                ,"fE"

                ,"fF"

                ,"fG"

                ,"fH"

                ,"fI"

                ,"fJ"

                ,"fK"

                ,"fL"

                };

        string input = Console.ReadLine();

        int position = 0;

        int count = input.Length - 1;

        ulong result = 0;

        while (count >= 0)

        {

            if (count > 0 && input[count - 1] <= 'f' && input[count - 1] >= 'a')

            {

                string num = string.Format("{0}{1}", input[count - 1].ToString(), input[count].ToString());

                result += (ulong)Array.IndexOf(tab, num) * (ulong)Math.Pow(168, position);

                position++;

                count-=2;

            }

            else

            {

                result += (ulong)Array.IndexOf(tab, input[count].ToString()) * (ulong)Math.Pow(168, position);

                position++;

                count--;

            }

        }

        Console.WriteLine(result);

    }

}