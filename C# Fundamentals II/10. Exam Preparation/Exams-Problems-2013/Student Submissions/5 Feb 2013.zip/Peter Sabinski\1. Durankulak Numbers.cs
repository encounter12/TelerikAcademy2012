using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Problem_1

{ 
    class P1
    {
     
        //  static TextReader input11 = Console.In;
        //input11 = File.OpenText(@"../../t.txt");

        static void Main(string[] args)
        {
            //string input = "CfIA";
           string input = Console.ReadLine();

            //Console.WriteLine((int)'a');

            //Console.WriteLine(IsCapital('a'));

           Stack<char> currentNum = new Stack<char>();
           List<string> abc = new List<string>();
           StringBuilder sb = new StringBuilder();
           char capital ='0';
           char lower = '0';


            

            for (int i = input.Length-1; i >=0; i--)
            {
              //  Console.WriteLine(input[i]);
                if ((IsCapital(input[i])) && currentNum.Count == 0)
                {
                    currentNum.Push(input[i]);

                    if (i==0)
                    {
                        capital = currentNum.Pop();
                        abc.Add(capital.ToString());
                    }

                    
                }

                else if ((IsCapital(input[i])) && i== 0)
                {
                       
                    // make sure that it is not the last one
                    // convert


                    if (currentNum.Count!=0)
                    {
                        capital = currentNum.Pop();
                        abc.Add(capital.ToString());
                        
                    }

                    abc.Add(input[i].ToString());

                }
               

                else if ((IsCapital(input[i])) && currentNum.Count == 1)
                {
                    lower = currentNum.Pop();

                    currentNum.Push(input[i]);
                    // convert
                    abc.Add(lower.ToString());

                }
                else if (currentNum.Count == 1)
                {
                    lower = input[i];
                    capital = currentNum.Pop();

                    sb.Append(lower);
                    sb.Append(capital);

                    // convert
                    abc.Add(sb.ToString());
                    sb.Clear();
                }
              
                
            }
            /*
            foreach (var item in abc)
            {
                Console.Write(item + " ");
            }
             */

            BigInteger sum = ConvertNum(abc[0]);

            for (int pos = 1; pos < abc.Count; pos++)
            {
               
                    sum += ConvertNum(abc[pos]) * (long)(Math.Pow(168,pos));
                             

            }

            Console.WriteLine(sum);
       
     

           // Console.WriteLine(ConvertNum("aB"));

        }

        static int ConvertNum(string num)
        {
            if (num.Length == 2)
            {
                return GetValueLC(num[0]) + GetValueUC(num[1]);
            }
            else
            {
                return GetValueUC(num[0]);
            }

        }


        static int GetValueUC(char current)
        {
            string abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            int value = abc.IndexOf(current);

            return value;
        }
        static int GetValueLC(char current)
        {
            switch (current)
            {
                case 'a': return 26;
                case 'b': return 52;
                case 'c': return 78;
                case 'd': return 104;
                case 'e': return 130;
                case 'f': return 156;
            }

            return -1;

        }

        static bool IsCapital(char symbol)
        {
            if ((int)symbol < 91)
            {
                return true;
            }
            return false;

        }
        
    }
}
