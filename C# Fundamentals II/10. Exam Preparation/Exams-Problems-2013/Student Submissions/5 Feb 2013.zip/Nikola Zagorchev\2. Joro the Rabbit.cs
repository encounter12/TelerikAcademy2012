using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Joro_the_Rabbit
{
    class Joro
    {
        static void Main(string[] args)
        {
            //StreamReader ttt = new StreamReader(@"D:\tt.txt");
            string input = Console.ReadLine();
            int paceCount=1;
            int bestCount = 0;
            string[] num=input.Split(',');
            int[] numbers = new int[num.Length];
            for (int i = 0; i < num.Length; i++)
            {
                numbers[i] = int.Parse(num[i].Trim());
            }
            for (int i = numbers.Length - 1; i > 0; i--)
            {
                int curr = i;
                for (int pace = 1; pace < numbers.Length-1; pace++)
                {
                    curr = i;
                    int currPace;
                    for (currPace = i + pace; ; currPace += pace)//currPace<numbers.Length//pace-1
                    {
                        if (currPace>=numbers.Length)
                        {
                            currPace -= numbers.Length;
                        }
                        if (currPace==i)
                        {
                            break;
                        }
                        if (numbers[curr] < numbers[currPace])
                        {
                            paceCount++;
                            curr = i - i + currPace;
                        }
                        else
                        {
                            break;
                        }
                        //currPace = pace - 1;
                    }
                    //Console.WriteLine(paceCount);
                    if (bestCount<paceCount)
                    {
                        bestCount = paceCount;
                    }
                    //Console.WriteLine(bestCount);
                    paceCount = 1;
                    if (bestCount==numbers.Length)
                    {
                        break;
                    }
                    
                }
                
            }
            Console.WriteLine(bestCount);
        }
    }
}
