using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Task2
{
    static string[] separators = new string[] { ",", " " };
   // static bool[] visited;
    static int bestRes = 0;

    static void Main()
    {
        string[] line = Console.ReadLine().Split(separators, StringSplitOptions.RemoveEmptyEntries);
        int[] inputVal = new int[line.Length];
       // visited = new bool[line.Length];

        for (int i = 0; i < line.Length; i++)
        {
            inputVal[i] = int.Parse(line[i]);
            //visited[i] = false;
        }

        int counter = 1;
        // int start = 0;
        bool flag = true;
        int res = 0;
        int bestCounter = 0;
        int bestRes = 0;
       

        for (int j = 0; j < line.Length; j++)
        {
            for (int cntr = line.Length; cntr >= 1; cntr--)
            {
                bool[] visited = new bool[line.Length];
                int startPos = j;
                counter = cntr;
                int currentRes = 0;
                int newPos;

                while (true)
                {
                    if (startPos + counter < inputVal.Length)
                    {
                        newPos = startPos + counter;
                    }
                    else
                    {
                        newPos = startPos + counter - inputVal.Length;
                    }
                    visited[startPos] = true;

                    if ((inputVal[startPos] >= inputVal[newPos]) || (visited[newPos]))
                    {
                        //flag = false;
                        break;
                    }
                    else
                    {
                        // visited[newPos] = true;
                        startPos = newPos;
                        currentRes++;
                    }
                }
                if (currentRes>bestRes)
                {
                    bestRes = currentRes;
                    bestCounter = counter;
                }

               // int currentRes = GetBestRes(j, cntr, inputVal);
                /*
                if (currentRes > res)
                {
                    // res = bestRes;
                    res = bestRes;
                    bestCounter = cntr;
                }
                 * */
            }
            
        }

       //Console.WriteLine(res);
      // Console.WriteLine(bestCounter);
       Console.WriteLine(bestRes+1);
       // Console.WriteLine(Math.Abs(2 * bestCounter-line.Length));

    }

    /*
    private static int GetBestRes(int startPos, int counter, int[] inputVal)
    {
        int currentRes = 0;
        int newPos;
        bool flag = true;
        for (int i = 0; i < inputVal.Length; i++)
        {
            inputVal[i] = int.Parse(line[i]);
            //visited[i] = false;
        }
        while (flag)
        {
            if (startPos + counter < inputVal.Length)
            {
                newPos = startPos + counter;
            }
            else
            {
                newPos = startPos + counter - inputVal.Length;
            }
            visited[startPos] = true;

            if ((inputVal[startPos] > inputVal[newPos]) || (visited[newPos]))
            {
                flag = false;
                break;
            }
            else
            {
                // visited[newPos] = true;
                startPos = newPos;
                currentRes++;
            }
        }
        return currentRes;
    }
     * */
}