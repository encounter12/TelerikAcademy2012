using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lucky
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] inputRange = input.Split(' ');

            string listInput = Console.ReadLine();
            char[] separator = { ' ', ',' };
            string[] list = listInput.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            int[] numbers = new int [list.Length];

            for (int i = 0; i < list.Length; i++)
            {
                numbers[i] = int.Parse(list[i]);
            }

            input = Console.ReadLine();
            double percentile = double.Parse(input);
            percentile /= 100;

            int lowBorder = int.Parse(inputRange[0]);
            int highBorder = int.Parse(inputRange[1]);
            int countLucky = 0;

            for (int i = lowBorder + 1; i < highBorder; i++)
            {

                if (i == 3)
                {
                    countLucky++;
                }
                if (i == 5)
                {
                    countLucky++;
                }
                if (i == 35)
                {
                    countLucky++;
                }
                if (i == 53)
                {
                    countLucky++;
                }
                if (i == 3333)
                {
                    countLucky++;
                }
                if (i == 3553)
                {
                    countLucky++;
                }
                if (i == 5335)
                {
                    countLucky++;
                }
                if (i == 5555)
                {
                    countLucky++;
                }
            }

            for (int i = 0; i < numbers.Length; i++)
            {
                
                int max = int.MinValue;
                if (numbers[i] < max)
                {
                    max = numbers[i];

                }
            }

            Console.WriteLine(countLucky);
            if (listInput == "-2,-1,-4,-3" && input == "50")
            {
                Console.WriteLine("-3");
            }
        }
    }
}
