using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace test2
{
    class Program
    {
        static int BestRoute(int[] input)
        {
            int bestRoute = int.MinValue;
             
            for (int start = 0; start < input.Length; start++)
            {
                for (int step = 1; step < input.Length; step++)
                {
                    int tempRoute = 0;
                    List<int> visited = new List<int>();
                    List<int> steps = new List<int>();
                    for (int i = start, stepNum = 0, prevStep = start - step, index = -1; true; i+=step, prevStep += step, stepNum++, index++)
                    {
                        if (i >= input.Length)
                        {
                            i -= input.Length;
                        }
 
                        if (steps.Count == 0)
                        {
                            steps.Add(i);
                            continue;
                        }
 
                        if (CheckIfExists(visited, i))
                        {
                            break;
                        }
                        else
                        {
                            visited.Add(i);
                        }
 
                        if (input[steps[index]] < input[i])
                        {
                            tempRoute++;
                        }
                        else
                        {
                            break;
                        }
 
                        steps.Add(i);
                    }
 
                    if (tempRoute > bestRoute)
                    {
                        bestRoute = tempRoute;
                    }
 
                    if (bestRoute == input.Length)
                    {
                        return bestRoute;
                    }
                }
            }
 
            return bestRoute;
        }
 
        static bool CheckIfExists(List<int> list, int number)
        {
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i] == number)
                {
                    return true;
                }
            }
 
            return false;
        }
 
        static void Main()
        {
            string input = Console.ReadLine();
            string[] strArr = input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            int[] intArr = new int[strArr.Length];
            for (int i = 0; i < intArr.Length; i++)
            {
                intArr[i] = int.Parse(strArr[i]);
            }
 
            //int[] intArr = { 1, -2, -3, 4, -5, 6, -7, -8 };
 
            Console.WriteLine(BestRoute(intArr) + 1);
        }
    }
}
