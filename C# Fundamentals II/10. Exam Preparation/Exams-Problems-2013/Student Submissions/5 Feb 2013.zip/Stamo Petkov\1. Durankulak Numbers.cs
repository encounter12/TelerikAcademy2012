using System;
using System.Collections.Generic;
using System.Text;


class DurankulakNumbers
{
    static Dictionary<string, int> CreateTable()
    {
        Dictionary<string, int> conversionTable = new Dictionary<string, int>();
        int number = 0;
        StringBuilder str = new StringBuilder();


        for (int i = 65; i < 91; i++)
        {
            conversionTable.Add(((char)i).ToString(), number);
            number++;
        }
        for (int i = 97; i < 103; i++)
        {
            for (int j = 65; j < 91; j++)
            {
                str.Append((char)i);
                str.Append((char)j);
                conversionTable.Add(str.ToString(), number);
                str.Clear();
                number++;
            }
        }

        return conversionTable;
    }

    static void Main()
    {
        string input = string.Empty;
        StringBuilder tempStr = new StringBuilder();
        List<string> number = new List<string>();
        Dictionary<string, int> conversionTable = new Dictionary<string, int>();
        ulong convertedNumber = 0;

        input = Console.ReadLine();
        tempStr.Append(input[input.Length - 1]);
        for (int i = input.Length - 2; i >= 0; i--)
        {
            if ((int)input[i] < 97 && (int)input[i] > 64)
            {
                number.Add(tempStr.ToString());
                tempStr.Clear();
                tempStr.Append(input[i]);
            }
            else if ((int)input[i] > 96 && (int)input[i] < 103)
            {
                tempStr.Insert(0, input[i]);
            }

        }
        number.Add(tempStr.ToString());
        conversionTable = CreateTable();

        for (int i = 0; i < number.Count; i++)
        {
            convertedNumber += (ulong)(conversionTable[number[i]] * Math.Pow(168, i));
        }
        Console.WriteLine(convertedNumber);

    }
}