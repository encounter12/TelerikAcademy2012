using System;
using System.Text;
using System.Text.RegularExpressions;

class CSharpBrackets
{
    static void Main(string[] args)
    {
        int numberOfLines = Int32.Parse(Console.ReadLine());
        string indent = Console.ReadLine();
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < numberOfLines; i++)
        {
            builder.AppendLine(Console.ReadLine());
        }

        //insert new lines around teh brackets
        builder.Replace("{", Environment.NewLine + "{" + Environment.NewLine);
        builder.Replace("}", Environment.NewLine + "}" + Environment.NewLine);

        //remove all the unnecessary new lines and all the empty spaces in each line
        string[] splitState = builder.ToString().Split(new string[] {Environment.NewLine}, StringSplitOptions.RemoveEmptyEntries);
        builder.Clear();
        Regex emptySpaces = new Regex("\\s+");
        for (int i = 0; i < splitState.Length; i++)
        {
            splitState[i] = emptySpaces.Replace(splitState[i], " ");
            splitState[i] = splitState[i].Trim();
            builder.AppendLine(splitState[i]);
        }
    
        //insert indentation
        int bracketCounter = 0;
        indent = indent.Trim();
        for (int i = 0; i < builder.Length; i++)
        {
            if (builder[i] == '{')
            {
                bracketCounter++;
            }
            else if (builder[i] == '}')
            {
                bracketCounter--;
            }
            else if (builder[i] == '\n')
            {
                for (int u = 0; u < bracketCounter; u++)
                {
                    builder.Insert(i + 1, indent);
                    i += indent.Length;
                }

            }
        }
        builder.Replace(indent + "}", "}");

        Console.WriteLine(builder.ToString());
    }
}
