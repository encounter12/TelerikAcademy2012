using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace DurankulakNumbers
{
    class DurankulakNumbers
    {
        static void Main()
        {
            string duranNumber = Console.ReadLine();

            List<string> numbers = new List<string>();

            for (int i = 0; i < duranNumber.Length; i++)
            {
                if (Char.IsUpper(duranNumber[i]))
                {
                    numbers.Add(duranNumber[i].ToString());
                }
                if (Char.IsLower(duranNumber[i]) && Char.IsUpper(duranNumber[i + 1]))
                {
                    numbers.Add(duranNumber[i].ToString() + duranNumber[i + 1].ToString());
                    i++;
                }
            }

            string[] numbersArray = numbers.ToArray();
            BigInteger decimalNumber = 0;

            for (int i = 0; i < numbersArray.Length; i++)
            {
                if (numbersArray[i].Length == 1)
                {
                    decimalNumber += ToDigit(numbersArray[i].ToLower()) * (BigInteger)Math.Pow(168, numbersArray.Length - 1 - i);
                }

                if (numbersArray[i].Length == 2)
                {
                    decimalNumber += (26 + 26 * ToDigit(numbersArray[i][0].ToString()) + ToDigit(numbersArray[i][1].ToString().ToLower())) * (BigInteger)Math.Pow(168, numbersArray.Length - 1 - i);
                }
            }

            Console.WriteLine(decimalNumber);
        }

        public static int ToDigit(string letter)
        {
            switch (letter)
            {
                case "a": return 0;
                case "b": return 1;
                case "c": return 2;
                case "d": return 3;
                case "e": return 4;
                case "f": return 5;
                case "g": return 6;
                case "h": return 7;
                case "i": return 8;
                case "j": return 9;
                case "k": return 10;
                case "l": return 11;
                case "m": return 12;
                case "n": return 13;
                case "o": return 14;
                case "p": return 15;
                case "q": return 16;
                case "r": return 17;
                case "s": return 18;
                case "t": return 19;
                case "u": return 20;
                case "v": return 21;
                case "w": return 22;
                case "x": return 23;
                case "y": return 24;
                case "z": return 25;
                default: return -100;
            }
        }
    }
}
