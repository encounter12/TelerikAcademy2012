using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Numerics;

class DurankolakNumbers
{
    static void Main()
    {
        string durankolak = Console.ReadLine();

        MatchCollection matches = Regex.Matches(durankolak, @"(?<big>[A-Z])|(?<small>[a-z][A-Z])");
        List<int> numbers = new List<int>();
        int smallBig = 0;
        foreach (Match match in matches)
        {
            
            if (match.ToString() == match.Groups["big"].ToString())
            {
                numbers.Add((int)(char.Parse(match.ToString())) - 65);
            }
            else
            {
                MatchCollection mathces1 = Regex.Matches(match.ToString(), @"(?<small1>[a-z])|(?<smallBig>[A-Z])");
                foreach (Match match1 in mathces1)
                {
                    if (match1.ToString() == match1.Groups["smallBig"].ToString())
                    {

                        smallBig += (int)(char.Parse(match1.ToString())) - 65;


                    }
                    else if (match1.ToString() == match1.Groups["small1"].ToString())
                    {

                        if (char.Parse(match1.ToString()) == 'a')
                        {
                            smallBig += (int)(char.Parse(match1.ToString())) - 71;
                        }
                        else if (char.Parse(match1.ToString()) == 'b')
                        {
                            smallBig += (int)(char.Parse(match1.ToString())) - 46;
                        }
                        else if (char.Parse(match1.ToString()) == 'c')
                        {
                            smallBig += (int)(char.Parse(match1.ToString())) - 21;
                        }
                        else if (char.Parse(match1.ToString()) == 'd')
                        {
                            smallBig += (int)(char.Parse(match1.ToString())) + 4;
                        }
                        else if (char.Parse(match1.ToString()) == 'e')
                        {
                            smallBig += (int)(char.Parse(match1.ToString())) + 29;
                        }
                        else if (char.Parse(match1.ToString()) == 'f')
                        {
                            smallBig += (int)(char.Parse(match1.ToString())) + 54;
                        }


                    }
                }
                numbers.Add(smallBig);
                smallBig = 0;
            }
        }
        BigInteger sum = 0;
        int count = 0;
        for (int i = numbers.Count - 1; i >= 0; i--)
        {
            sum += numbers[i] * (BigInteger)Math.Pow(168,count);
            count++;
        }
        Console.WriteLine(sum);


    }
}