using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Exam
{
    static void Main()
    {
        string duranKulak = Console.ReadLine(); ;
        string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        string smallAlpha = "abcdef";
        int number;
        //Console.WriteLine(aplhabet.Length);
        if (duranKulak.Length == 1)
        {
            Console.WriteLine(alphabet.IndexOf(duranKulak));
        }
        if (duranKulak.Length == 2)
        {
            Console.WriteLine(alphabet.IndexOf(duranKulak[1]) + ((smallAlpha.IndexOf(duranKulak[0]) + 1) * 26));
        }

        if (duranKulak.Length > 2)
        {
            number = ((alphabet.IndexOf(duranKulak[0]) * 168)) + (alphabet.IndexOf(duranKulak[duranKulak.Length - 1]) + ((smallAlpha.IndexOf(duranKulak[duranKulak.Length - 2]) + 1) * 26));
            Console.WriteLine(number);
        }

    }
}