using System;
    class Durankulak
    {
        static void Main()
        {
            string numberInDurankulak = Console.ReadLine(); 
            long sum = 0;
            long power = 0;
            long upper = 0;
            long lower = 0;
            for (int i = numberInDurankulak.Length-1; i >=0; i--)
            {
                if (i > 0)
                {
                    if (char.IsUpper(numberInDurankulak[i - 1]))
                    {
                        upper = (int)(((int)numberInDurankulak[i]) - 65);
                        sum += upper * RaiseToPower(168, power);
                    }
                    else if(char.IsLower(numberInDurankulak[i - 1]))
                    {
                        upper = (int)(((int)numberInDurankulak[i]) - 65);
                        lower = (int)((numberInDurankulak[i - 1]) - 96) * 26;
                        sum += (upper + lower) * RaiseToPower(168, power);
                        i--;
                    }
                }
                else
                {
                    if (char.IsUpper(numberInDurankulak[i]))
                    {
                         upper = (int)(((int)numberInDurankulak[i]) - 65);
                        sum += upper * RaiseToPower(168, power);
                    }
                }
               
                power++;
            }
            Console.WriteLine(sum);
        }

        private static long RaiseToPower(long p, long power)
        {
            long result = p;
            if (power == 0)
            {
                return 1;
            }
            if (power == 1)
            {
                return p;
            }
            else if (power > 1)
            {
                for (int i = 1; i < power; i++)
                {
                    result *= p;
                }
            }
            return result;
        }
    }
