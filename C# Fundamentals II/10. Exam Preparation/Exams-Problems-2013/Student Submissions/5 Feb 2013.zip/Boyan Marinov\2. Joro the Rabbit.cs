using System;

class JoroTheRabbit
{
    static int MaxLen(int[] nums)
    {
        int[] sorted = new int[nums.Length];
        for (int i = 0; i < nums.Length; i++)
        {
            sorted[i] = nums[i];
        }
        Array.Sort(sorted);

        int currentStepCount = 0;
        int maxStepCount = 0;
        int maxCount = 0;
        for (int step = 1; step < sorted.Length; step++)
        {
            for (int start = sorted.Length-1; start >= 0; start--)
            {
                currentStepCount = CountHops(nums, start, step);
                if (currentStepCount > maxStepCount)
                {
                    maxStepCount = currentStepCount;
                }
            }
            if (maxStepCount > maxCount)
            {
                maxCount = maxStepCount;
            }
        }
        return maxCount;
    }
    static int CountHops(int[] nums, int start, int step)
    {
        int count = 0;
        int maxCount = 0;
        bool[] visited = new bool[nums.Length];

        int previous = start;
        while (visited[start] == false && nums[previous] <= nums[start])
        {
            count++;
            visited[start] = true;
            previous = start;
            start = (start + step) % nums.Length;
        }
        if (count > maxCount)
        {
            maxCount = count;
        }

        return maxCount;
    }
    static void Main()
    {
        string[] input = Console.ReadLine().Split(',');
        int[] nums = new int[input.Length];
        for (int i = 0; i < nums.Length; i++)
        {
            nums[i] = int.Parse(input[i]);
        }
        //int[] nums = { 1, -2, -3, 4, -5, 6, -7, -8 };
        //Console.WriteLine(CountHops(nums, 6, 6));
        Console.WriteLine(MaxLen(nums));
    }
}
