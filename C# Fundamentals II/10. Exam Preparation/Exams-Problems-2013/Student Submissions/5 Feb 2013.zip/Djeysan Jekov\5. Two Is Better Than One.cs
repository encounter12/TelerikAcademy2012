using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{
    static long a, b;
    static int p;
    static List<int> numbers = new List<int>(50);
    static long luckyNumbers;
    static int smallestElement;

    static void Input()
    {
        string[] parts = Console.ReadLine().Split();
        a = int.Parse(parts[0]);
        b = int.Parse(parts[1]);

        string[] ns = Regex.Split(Console.ReadLine(), @",\s*");
        foreach (var item in ns)
            numbers.Add(int.Parse(item));

        p = int.Parse(Console.ReadLine());
    }

    static void SolveOne()
    {
        luckyNumbers = 0;
    }

    static void SolveTwo()
    {
        numbers.Sort();

        int l = 0, r = numbers.Count - 1;


     while (l < r)
        {
            int m = l + (r - l + 1) / 2;

            double currentPercent = ((double)m / numbers.Count) * 100;

            if (currentPercent >= p) r = m - 1;
            else l = m;
        }

        // if (numbers[l] > x) l--;

        smallestElement = numbers[l];
    }


    static void Output()
    {
        Console.WriteLine(luckyNumbers);
        Console.WriteLine(smallestElement);
    }

    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
#endif

        Input();

        SolveOne();

        SolveTwo();

        Output();
    }
}
