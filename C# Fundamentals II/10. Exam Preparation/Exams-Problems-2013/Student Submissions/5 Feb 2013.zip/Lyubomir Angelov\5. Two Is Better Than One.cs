using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// The name of the task is:
class Problem5
{
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("input"));
#endif
        Console.WriteLine(10);
        Console.WriteLine(3);
    }
   
}
