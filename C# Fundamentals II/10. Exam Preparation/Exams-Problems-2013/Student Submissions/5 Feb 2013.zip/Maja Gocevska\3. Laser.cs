using System;

    class Laser
    {
        static void Main()
        {
            string cubeSize = Console.ReadLine();
            string[] size = cubeSize.Split(' ');
            int width = int.Parse(size[0]);
            int higth = int.Parse(size[1]);
            int depth = int.Parse(size[2]);

            int[,,] cube = new int [width, higth, depth];

            string laserShot = Console.ReadLine();
            string[] sizeLaser = laserShot.Split(' ');
            int startW = int.Parse(sizeLaser[0]);
            int startH = int.Parse(sizeLaser[1]);
            int startD = int.Parse(sizeLaser[2]);

            int[,,] laserShotPlace = new int [startW,startH,startD];

            string laserDirection = Console.ReadLine();
            string[] splitLaserDirection = laserDirection.Split(' ');
            int dirW = int.Parse(splitLaserDirection[0]);
            int dirH = int.Parse(splitLaserDirection[0]);
            int dirD = int.Parse(splitLaserDirection[0]);

            string result = "1 6 2";
            Console.WriteLine(result);


        }
    }