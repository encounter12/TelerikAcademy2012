using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Problem4CsharpBrackets
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string tab = Console.ReadLine();

            string[] input = new string[n];
            for (int i = 0; i < n; i++)
            {
                input[i] = Console.ReadLine();
            }
            List<string> result = new List<string>();



            StringBuilder temp = new StringBuilder();
            int brackers = 0;

            bool isPrevOpen = false;
            bool isEmpty = true;
            bool isFirst = true;

            for (int iposs = 0; iposs < input.Length; iposs++)
            {

                if(!isFirst)
                    result.Add(temp.ToString());
                isFirst = true;

                for (int i = 0; i < input[iposs].Length; i++)
                {
                    char ch = input[iposs][i];

                    if (ch == ' ' && input[iposs][i + 1] == ' ')
                    {
                        isPrevOpen = false;
                        continue;
                    }
                    else if (ch == '{')
                    {
                        isPrevOpen = true;
                        if (!isEmpty)
                            result.Add(temp.ToString());

                        temp = new StringBuilder();

                        if (brackers != 0)
                            temp.Append(AddBrackers(brackers, tab));
                        temp.Append("{");
                        result.Add(temp.ToString());
                        brackers++;

                        temp = new StringBuilder();
                        temp.Append(AddBrackers(brackers, tab));
                        isEmpty = true;
                        isFirst = true;

                    }
                    else if (ch == '}')
                    {
                        brackers--;
                        if (isFirst)
                        {
                            temp = new StringBuilder();
                            if (brackers != 0)
                                temp.Append(AddBrackers(brackers , tab));
                            temp.Append("}");
                            result.Add(temp.ToString());
                        }
                        else
                        {
                            result.Add(temp.ToString());

                            temp = new StringBuilder();
                            if (brackers != 0)
                                temp.Append(AddBrackers(brackers, tab));
                            temp.Append("}");
                            result.Add(temp.ToString());
                        }
                        isFirst = true;
                    }
                    else
                    {
                        bool noFirstSpace=true;
                        if (isFirst)
                        {
                            
                            if (ch == ' ')
                            {
                                noFirstSpace=false;
                                continue;
                            }
                            else
                            {
                            temp = new StringBuilder();
                            if (brackers != 0)
                                temp.Append(AddBrackers(brackers, tab));
                            }
                            
                        }
                        if (noFirstSpace)
                        {
                            isFirst = false;
                            temp.Append(ch);
                            for (int h = i + 1; h < input[iposs].Length; h++)
                            {
                                if (input[iposs][h] == ' ' && input[iposs][h + 1] == ' ')
                                    continue;
                                else if (input[iposs][h] == '{' || input[iposs][h] == '}')
                                {
                                    i = h - 1;
                                    break;
                                }
                                else
                                {
                                    temp.Append(input[iposs][h]);
                                    i = h;
                                }
                            }
                        }
                    }

                }

            }

            for (int i = 0; i < result.Count; i++)
            {
                if (!string.IsNullOrWhiteSpace(result[i]))
                    Console.WriteLine(result[i].TrimEnd());
            }
        }

        private static string AddBrackers(int brackers, string tab)
        {
            StringBuilder a = new StringBuilder();
            for (int i = 0; i < brackers; i++)
                a.Append(tab);
            return a.ToString();
        }

    }
}
