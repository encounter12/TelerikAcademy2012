using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class Durankulak_Numbers
{
    static void Main()
    {
        string input = Console.ReadLine();
        char[] durankulak = input.ToCharArray();
        string[] alphabet = new string[168];
        int final = 0;
        for (int i = 0; i < 26; i++)
        {
            alphabet[i] = ((char)('A' + i)).ToString();
        }
        for (int i = 26; i < 52; i++)
        {
            alphabet[i] = "a" + ((char)('A' + i - 26)).ToString();
        }
        for (int i = 52; i < 78; i++)
        {
            alphabet[i] = "b" + ((char)('A' + i - 52)).ToString();
        }
        for (int i = 78; i < 104; i++)
        {
            alphabet[i] = "c" + ((char)('A' + i - 78)).ToString();
        }
        for (int i = 104; i < 130; i++)
        {
            alphabet[i] = "d" + ((char)('A' + i - 104)).ToString(); 
        }
        for (int i = 130; i < 156; i++)
        {
            alphabet[i] = "e" + ((char)('A' + i - 130)).ToString();
        }
        for (int i = 156; i < 168; i++)
        {
            alphabet[i] = "f" + ((char)('A' + i - 156)).ToString();
        }
        StringBuilder number = new StringBuilder();
        string newLower;
        string newUpper;
        string doubleLetter;

        if (durankulak.Length == 1)
        {
            number.Append(durankulak[0]);
        }
        else if (durankulak.Length == 2)
        {
            if (char.IsLower((durankulak[0])))
            {
                newLower = durankulak[0].ToString();
                newUpper = durankulak[1].ToString();
                doubleLetter = newLower + newUpper;
                number.Append(doubleLetter);
                for (int j = 0; j < alphabet.Length; j++)
                {
                    if (alphabet[j] == doubleLetter)
                    {
                        final = j;
                    }
                }
            }
            else
            {
                number.Append(durankulak[0]);
                number.Append(durankulak[1]);
            }
        }
        else
        {
            for (int i = 0; i <= durankulak.Length - 2; i++)
            {
                if (char.IsUpper(durankulak[i]))

                {
                    number.Append(durankulak[i]);
                }

                if (!char.IsUpper(durankulak[i]))
                {
                    newLower = durankulak[i].ToString();
                    newUpper = durankulak[i + 1].ToString();
                    doubleLetter = newLower + newUpper;
                    number.Append(doubleLetter);
                    i++;
                   
                }
            }
        }
        List<int> result = new List<int>();
        for (int i = 0; i < alphabet.Length; i++)
        {
            for (int j = 0; j < number.Length; j++)
            {
                string temp = number[j].ToString();
                if (alphabet[i] == temp)
                {
                    result.Add(i);
                }
            }
        }
        
        for (int i = 0; i < result.Count; i++)
        {
            final = final + (result[i])*(int)(Math.Pow(168,i));
        }
        Console.WriteLine(final);
    }
}