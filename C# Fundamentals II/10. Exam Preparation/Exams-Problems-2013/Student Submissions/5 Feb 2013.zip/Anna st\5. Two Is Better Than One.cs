using System;
using System.Collections.Generic;
using System.Numerics;

class Program
{


    static void Swap(int[] arr, int i, int j)
    {
        int t = arr[i];
        arr[i] = arr[j];
        arr[j] = t;
    }

    static int Partition(int[] arr, int l, int r)
    {
        Swap(arr, new Random().Next(l, r + 1), r);
        int pivot = arr[r], i = l;

        for (int j = l; j < r; j++) if (arr[j] <= pivot) Swap(arr, i++, j);
        Swap(arr, i, r);

        return i;
    }

    static void QuickSort(int[] arr, int l, int r)
    {
        if (l >= r) return;

        int q = Partition(arr, l, r);

        QuickSort(arr, l, q - 1);
        QuickSort(arr, q + 1, r);
    }
    //---------------------------------------------
    private static int LuckyDigits(BigInteger a, BigInteger b)
    {
        int counterForLuckyDigits=0;
        for (; a < b; a++)
        {
            int flag = 0;
            for (int j = 0; j < a.ToString().Length/2+1; j++)
            {
                if ((a.ToString()[j].CompareTo(a.ToString()[a.ToString().Length - 1 - j])) == 0
                    && a.ToString()[j].CompareTo('3') == 0 || a.ToString()[j].CompareTo('5') == 0)
                {
                    continue;
                }
                else
                {
                    flag = 1;
                }
            }
            if (flag == 0)
            {
                counterForLuckyDigits++;
            }

        }
        return counterForLuckyDigits;
    }
    static void Main()
    {
        string aAndB = Console.ReadLine();
        string[] aAndBArr = aAndB.Split(new char[]{' '},StringSplitOptions.RemoveEmptyEntries);
        int count = LuckyDigits(BigInteger.Parse(aAndBArr[0]), BigInteger.Parse(aAndBArr[1]));
        string listOfIntegers = Console.ReadLine();
        string[] text = listOfIntegers.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        int[] textInInt = new int[text.Length];
        for (int i = 0; i < textInInt.Length; i++)
        {
            textInInt[i] = int.Parse(text[i]);
        }
        //Array.Sort(textInInt);
        //--------------------------------------------
        QuickSort(textInInt, 0, textInInt.Length - 1);
        //--------------------------------------------

        double percentage = double.Parse(Console.ReadLine());
        double numberInPerc = textInInt.Length * (percentage / 100);
        int nInP = (int)numberInPerc;
        if (numberInPerc > (int)numberInPerc)
        {
            nInP = (int)numberInPerc + 1;
        }
        int ans = textInInt[nInP - 1];
        Console.WriteLine(count);
        Console.WriteLine(ans);
    }
}

