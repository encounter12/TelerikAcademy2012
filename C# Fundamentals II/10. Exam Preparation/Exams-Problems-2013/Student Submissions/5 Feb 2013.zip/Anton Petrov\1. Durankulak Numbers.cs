using System;
using System.Text.RegularExpressions;
using System.Numerics;
class DurankulakNumbers
{
    static void Main()
    {
        string input = Console.ReadLine();
        string pattern = @"[A-Z]|[a-z][A-Z]*";
        BigInteger result = 0;
        string[] matches = new string[Regex.Matches(input, pattern).Count];
        for (int i = 0; i < matches.Length; i++)
        {
            matches[i] = Regex.Matches(input, pattern)[i].ToString();
        }
        for (int symbols = 0; symbols < matches.Length; symbols++)
        {
            result *= 168;
            if (matches[symbols].Length == 1)
            {
                result += matches[symbols][0] - 'A';
            }
            else
            {
                result += ((matches[symbols][0] - 'a' + 1) * 26 + matches[symbols][1] - 'A');
            }
        }
        Console.WriteLine(result);
    }
}
