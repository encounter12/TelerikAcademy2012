using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4.Brackets
{
    class Program
    {
        static void Main()
        {

            const char openBracket = '{';
            const char closeBracket = '}';
            string outputFileName = @"..\..\test.txt";

            int lineNumber = int.Parse(Console.ReadLine());
            string identationString = Console.ReadLine();

            //StringBuilder sbInput = new StringBuilder();
            StringBuilder sb = new StringBuilder();
            //using (StreamWriter sw = new StreamWriter(outputFileName))
            //{
                int countOpenBrackets = 0;
                int countCloseBrackets = 0;
                bool isNewLine = false;
                for (int i = 0; i < lineNumber; i++)
                {
                    string line = Console.ReadLine();
                    line = line.Trim();
                    int lineLength = line.Length;
                    int countSpaces = 0;
                    if (lineLength > 0)
                    {
                        countSpaces = 0;
                        for (int j = 0; j < lineLength; j++)
                        {
                            char currentSymbol = line[j];
                            if (currentSymbol == '{')
                            {
                                if (countOpenBrackets != 0)
                                {
                                    sb.Append("\r\n");
                                }
                                for (int k = 0; k < countOpenBrackets; k++)
                                {
                                    sb.Append(identationString);
                                }
                                sb.Append('{');
                                //sb.Append("\r\n");

                                countOpenBrackets++;
                                countSpaces = 0;
                                isNewLine = true;

                                //if ((j + 1) != lineLength)
                                //{
                                //    sb.Append("\r\n");
                                //    if (line[j + 1] != closeBracket)
                                //    {
                                //        for (int k = 0; k < countOpenBrackets; k++)
                                //        {
                                //            sb.Append(identationString);
                                //        }
                                //    }
                                //    countSpaces = 0;
                                //    isNewLine = true;
                                //}
                                //else
                                //{
                                //    sb.Append("\r\n");
                                //    for (int k = 0; k < countOpenBrackets; k++)
                                //    {
                                //        sb.Append(identationString);
                                //    }
                                //    countSpaces = 0;
                                //    isNewLine = true;
                                //}
                            }
                            else if (currentSymbol == '}')
                            {
                                countOpenBrackets--;
                                sb.Append("\r\n");
                                for (int k = 0; k < countOpenBrackets; k++)
                                {
                                    sb.Append(identationString);
                                }
                                sb.Append('}');
                                //sb.Append("\r\n");

                                isNewLine = true;
                                countSpaces = 0;
                                //if ((j + 1) != lineLength)
                                //{
                                //    sb.Append("\r\n");
                                //    if (line[j + 1] != closeBracket)
                                //    {
                                //        for (int k = 0; k < countOpenBrackets; k++)
                                //        {
                                //            sb.Append(identationString);
                                //        }
                                //    }
                                //    countSpaces = 0;
                                //    isNewLine = true;
                                //}
                            }
                            else
                            {
                                if (isNewLine && countSpaces == 0)
                                {
                                    //if (countSpaces == 0)
                                    //{
                                    sb.Append("\r\n");
                                        //if (line[j + 1] != closeBracket)
                                        //{
                                            for (int k = 0; k < countOpenBrackets; k++)
                                            {
                                                sb.Append(identationString);
                                            }
                                        //}
                                    //}
                                }
                                else if (currentSymbol == ' ' && isNewLine)
                                {

                                    isNewLine = false;
                                    continue;
                                }
                                if (currentSymbol == ' ')
                                {

                                    countSpaces++;
                                    continue;
                                }
                                isNewLine = false;
                                if (countSpaces > 0)
                                {
                                    sb.Append(' ');
                                }
                                countSpaces = 0;
                                sb.Append(currentSymbol);
                                if (j + 1 == lineLength)
                                {
                                    sb.Append("\r\n");
                                    for (int k = 0; k < countOpenBrackets; k++)
                                    {
                                        sb.Append(identationString);
                                    }
                                }
                            }
                        }
                    }
                    //if (countSpaces > 0)
                    //{
                    //    sb.Append("\r\n");
                    //    for (int k = 0; k < countOpenBrackets; k++)
                    //    {
                    //        sb.Append(identationString);
                    //    }
                    //}
                }

                Console.WriteLine(sb);
            //    sw.WriteLine(sb);
            //}
        }
    }
}
