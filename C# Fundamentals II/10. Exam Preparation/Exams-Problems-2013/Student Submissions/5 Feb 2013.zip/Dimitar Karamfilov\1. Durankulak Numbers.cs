using System;

class Program
{
    static void Main()
    {
        long result = 0;
        int index =0;
        
        string input = Console.ReadLine();
        input = "#"+input;
        if (input.Length == 1)
        {
            result = input[0] - 'A';
        }
        else
        {
            for (int i = input.Length -1; i > 0; i--)
            {
                
                string digit;
                if ((input[i] >= 'A' && input[i] <= 'Z') && (input[i - 1] >= 'a' && input[i - 1] <= 'f'))
                {
                    digit = input[i-1].ToString() + input[i].ToString();
                   // Console.WriteLine(digit);

                    result += (((digit[0] - 'a'+1) * 26) + (digit[1] - 'A')) * (long)Math.Pow(168, index);
                    index++;
                    i--;
                }
                else
                {
                   
                    char singledigit = input[i];
                    //Console.WriteLine(singledigit);
                    result+= (singledigit -'A')* (long)Math.Pow(168,index);
                    index++;
                }
            }


        }
        Console.WriteLine(result);

    }
}
