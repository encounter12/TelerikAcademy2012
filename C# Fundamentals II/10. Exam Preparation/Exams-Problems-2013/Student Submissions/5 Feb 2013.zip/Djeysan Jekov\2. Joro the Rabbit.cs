using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{
    static int[] array = new int[2500];
    static int length;
    static int maxJumps = 0;

    static void PrintArray(int[] array)
    {
#if DEBUG
        for (int i = 0; i < length; i++)
            Console.Write(array[i] + (i == length - 1 ? "\n" : " "));
#endif
    }

    static void Input()
    {
        int i = 0;
        foreach (var item in Regex.Split(Console.ReadLine(), ", "))
            array[i++] = int.Parse(item);

        length = i;
    }

    static void Output()
    {
        Console.WriteLine(maxJumps);
    }

    static void CountJumps()
    {
        bool[,] usedStep = new bool[length, length];

        for (int step = 1; step < length; step++)
        {
            for (int position = 0; position < length; position++)
            {
                if (usedStep[position, step]) continue;

                int currentMaxJumps = 1;
                
                for (int i = (position + step) % length; i != position; currentMaxJumps++)
                {
                    int next = (i + step) % length;

                    if (!(array[next] > array[i])) break;

                    usedStep[i, step] = true;

                    i = next;
                }

                if (maxJumps < currentMaxJumps)
                    maxJumps = currentMaxJumps;
            }
        }
    }

    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input2.txt"));
#endif
        Input();

        PrintArray(array);

        CountJumps();

        Output();
    }
}