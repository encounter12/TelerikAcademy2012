using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<string> digits = new List<string>();
        string input = Console.ReadLine();

        for (int i = input.Length - 1; i >= 0; i--)
        {
            if (i - 1 >= 0 && Char.IsLower(input[i - 1]))
            {
                digits.Add(string.Concat(input[i - 1], input[i]));
                i--;
            }
            else
            {
                digits.Add(input[i].ToString());
            }
        }

        ulong result = 0;
        ulong powerOf168 = 1;
        for (int i = 0; i < digits.Count; i++)
        {
            result += (powerOf168 * (ulong)GetValueFor(digits[i]));
            powerOf168 *= 168;
        }

        Console.WriteLine(result);
    }

    static int GetValueFor(string digit)
    {
        int value = 0;
        if (digit.Length == 1)
        {
            for (char ch = 'A'; ch <= 'Z'; ch++)
            {
                if (digit[0] == ch)
                {
                    return value;
                }
                value++;
            }
        }
        else
        {
            value = 26;
            for (char ch1 = 'a'; ch1 <= 'z'; ch1++)
            {
                for (char ch2 = 'A'; ch2 <= 'Z'; ch2++)
                {
                    if (ch1 == digit[0] && ch2 == digit[1])
                    {
                        return value;
                    }

                    value++;
                }
            }
        }

        throw new ArgumentOutOfRangeException();
    }
}

