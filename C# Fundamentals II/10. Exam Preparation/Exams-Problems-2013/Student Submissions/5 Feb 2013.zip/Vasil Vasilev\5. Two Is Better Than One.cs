using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class TwoBetterThanOne
{
    static void SolveOne(long startThree, long startFive, long endNumber)
    {
        long luckyTree = 0;
        long luckyFive = 0;
        for (long number = startThree; number <= endNumber; number += 10)
        {
            string sequenceOne = number.ToString();
            int length = sequenceOne.Length;
            bool isSymmetric = true;
            for (int sign = 0; sign < (length / 2); sign++)
            {
                if (sequenceOne[sign] != sequenceOne[length - 1 - sign])
                {
                    isSymmetric = false;
                    break;
                }
            }

            if (isSymmetric)
            {
                luckyTree++;
            }
        }

        for (long number = startFive; number <= endNumber; number += 10)
        {
            string sequenceTwo = number.ToString();
            int length = sequenceTwo.Length;
            bool isSymmetric = true;
            for (int sign = 0; sign < (length / 2); sign++)
            {
                if (sequenceTwo[sign] != sequenceTwo[length - 1 - sign])
                {
                    isSymmetric = false;
                    break;
                }
            }

            if (isSymmetric)
            {
                luckyFive++;
            }
        }

        Console.WriteLine(luckyTree + luckyFive);
    }

    static void Main()
    {
        string inputOne = Console.ReadLine();
        string[] dataOne = inputOne.Split(' ');
        long startNumber = long.Parse(dataOne[0]);
        long endNumber = long.Parse(dataOne[1]);
        long lastStartDigit = startNumber % 10;
        long startThree = startNumber + Math.Abs(lastStartDigit - 3);
        long startFive = startNumber + Math.Abs(lastStartDigit - 5);

        SolveOne(startThree, startFive, endNumber);

        string inputTwo = Console.ReadLine();
        string[] dataTwo = inputTwo.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
        int length = dataTwo.Length;
        int[] numberList = new int[length];
        for (int number = 0; number < length; number++)
        {
            numberList[number] = int.Parse(dataTwo[number]);
        }
        Array.Sort(numberList);
        int percent = int.Parse(Console.ReadLine());
        double index = (length * (double)percent) / 100;
        if (index <= (length * percent) / 100)
        {
            Console.WriteLine(numberList[((length * percent) / 100) - 1]);
        }
        else if (index > (length * percent) / 100)
        {
            Console.WriteLine(numberList[(length * percent) / 100]);
        }

    }
}