using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;

class DurankulakNumbers
{
    static void Main()
    {
        string durankulak = Console.ReadLine();
        BigInteger multiplier = 1;
        BigInteger number = 0;
        BigInteger countUpper=0;
        for (int index = durankulak.Length - 1; index >= 0; index--)
        {
            if (char.IsUpper(durankulak[index]))
            {
                countUpper++;
                if (countUpper==2)
                {
                    multiplier = multiplier * 168;
                }
                countUpper = 1;
                number = number + multiplier * ((BigInteger)durankulak[index] - 65);
            }
            else
            {
                switch (durankulak[index])
                {
                    case 'a': number += multiplier*26;
                        break;
                    case 'b': number += multiplier * 52;
                        break;
                    case 'c': number += multiplier * 78;
                        break;
                    case 'd': number +=multiplier* 104;
                        break;
                    case 'e': number += multiplier * 130;
                        break;
                    case 'f': number += multiplier * 156;
                        break;
                }
                if (countUpper == 1)
                {
                    multiplier = multiplier * 168;
                    countUpper = 0;
                }
            }
        }
        Console.WriteLine(number);
    }
}
