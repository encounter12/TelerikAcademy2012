using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TwoIsBetterThanOne
{
    class TwoIsBetterThanOne
    {
        static void Main(string[] args)
        {
            string range = Console.ReadLine();
            string sequence = Console.ReadLine();
            PalindromeNumber(range);
            Percentage(sequence);
        }
  
        private static void PalindromeNumber(string range)
        {
            string[] arrayRange = range.Split(' ');
            ulong a = ulong.Parse(arrayRange[0]);
            ulong b = ulong.Parse(arrayRange[1]);
            ulong count = 0;
            for (ulong i = a; i <= b; i++)
            {
                if (((i / 3 == 1 || i / 3 == 11) && i % 3 == 0) || ((i / 5 == 1 || i / 5 == 11)) && i % 5 == 0)
                {
                    count++;
                }
            }
            Console.WriteLine(count);
        }

        private static void Percentage(string sequence)
        {
            string[] arraySequence = sequence.Split(',');
            decimal p = decimal.Parse(Console.ReadLine());
            List<int> listSequence = new List<int>();
            for (int i = 0; i < arraySequence.Length; i++)
            {
                listSequence.Add(Convert.ToInt32(arraySequence[i]));
            }
            listSequence.Sort();
            decimal length = listSequence.Count * (p / 100);
            Console.WriteLine(listSequence[(int)(listSequence.Count - length - 1)]);
        }
    }
}
