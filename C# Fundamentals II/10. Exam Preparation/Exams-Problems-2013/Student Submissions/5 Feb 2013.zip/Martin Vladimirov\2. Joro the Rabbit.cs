using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem2JoroTheRabbit
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split(',');
            int[] a = new int[input.Length];
            

            for (int i = 0; i < a.Length; i++)
            {
                a[i] = int.Parse(input[i]);
                //Console.WriteLine(a[i]);
            }
            int maxCnt = -1;
            int cnt = 1;

            for (int start = 0; start < a.Length; start++)
            {
                for (int steps = 1; steps < a.Length; steps++)
                {
                        int firstPoss=start;

                    while (true)
                    {
                        int nextPoss = (firstPoss + steps);
                        if (nextPoss > a.Length - 1)
                            nextPoss -= a.Length;
                        if (a[firstPoss] < a[nextPoss])
                        {
                            cnt++;
                            firstPoss = nextPoss;
                        }
                        else
                        {
                            if (maxCnt < cnt)
                                maxCnt = cnt;
                            cnt = 1;
                            break;
                        }
                    }
                }

            }
            Console.WriteLine(maxCnt);




        }
    }
}
