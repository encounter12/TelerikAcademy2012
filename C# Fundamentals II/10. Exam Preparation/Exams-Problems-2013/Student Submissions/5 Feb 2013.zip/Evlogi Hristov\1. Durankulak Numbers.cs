using System;
using System.Numerics;
using System.Collections.Generic;

class DurankulakNumbers
{
    static void Main()
    {
        string inputStr = Console.ReadLine();
        List<char> input = new List<char>();
        foreach (var ch in inputStr)
        {
            if (!char.IsWhiteSpace(ch))
            {
                input.Add(ch);
            }
        }

        BigInteger[] arr = new BigInteger[input.Count];

        BigInteger coef = 1;
        for (int i = input.Count - 1; i >= 0; i--)
        {
            if (char.IsUpper(input[i]))
            {
                switch (input[i])
                {
                    case 'A': arr[i] = 0 * coef; break;
                    case 'B': arr[i] = 1 * coef; break;
                    case 'C': arr[i] = 2 * coef; break;
                    case 'D': arr[i] = 3 * coef; break;
                    case 'E': arr[i] = 4 * coef; break;
                    case 'F': arr[i] = 5 * coef; break;
                    case 'G': arr[i] = 6 * coef; break;
                    case 'H': arr[i] = 7 * coef; break;
                    case 'I': arr[i] = 8 * coef; break;
                    case 'J': arr[i] = 9 * coef; break;
                    case 'K': arr[i] = 10 * coef; break;
                    case 'L': arr[i] = 11 * coef; break;
                    case 'M': arr[i] = 12 * coef; break;
                    case 'N': arr[i] = 13 * coef; break;
                    case 'O': arr[i] = 14 * coef; break;
                    case 'P': arr[i] = 15 * coef; break;
                    case 'Q': arr[i] = 16 * coef; break;
                    case 'R': arr[i] = 17 * coef; break;
                    case 'S': arr[i] = 18 * coef; break;
                    case 'T': arr[i] = 19 * coef; break;
                    case 'U': arr[i] = 20 * coef; break;
                    case 'V': arr[i] = 21 * coef; break;
                    case 'W': arr[i] = 22 * coef; break;
                    case 'X': arr[i] = 23 * coef; break;
                    case 'Y': arr[i] = 24 * coef; break;
                    case 'Z': arr[i] = 25 * coef; break;
                    default: break;
                }
            }
            if (i - 1 >= 0 && char.IsLower(input[i - 1]))
            {
                i--;
                switch (input[i])
                {
                    case 'a': arr[i] = 26 * 1 * coef; break;
                    case 'b': arr[i] = 26 * 2 * coef; break;
                    case 'c': arr[i] = 26 * 3 * coef; break;
                    case 'd': arr[i] = 26 * 4 * coef; break;
                    case 'e': arr[i] = 26 * 5 * coef; break;
                    case 'f': arr[i] = 26 * 6 * coef; break;
                    default: break;
                }
            }
            coef *= 168;
        }

        BigInteger result = 0;
        for (int i = 0; i < arr.Length; i++)
        {
            result += arr[i];
        }
        Console.WriteLine(result);
    }
}
