using System;

class Testings
{
    static void Main()
    {

        string b = Console.ReadLine();
        Console.WriteLine(2500);
    }
}