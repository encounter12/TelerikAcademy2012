using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class JoroRabbit
{
    static void Main()
    {
        string inputLine = Console.ReadLine();
        string[] stringNums = inputLine.Split(new char[] {',', ' '}, StringSplitOptions.RemoveEmptyEntries);
        int[] nums = new int[stringNums.Length];
        for (int i = 0; i < nums.Length; i++)
        {
            nums[i] = Convert.ToInt32(stringNums[i]);
        }
        List<int> result = new List<int>();
        for (int y = 0; y < nums.Length-1; y++)
        {
            int i = y+1;
            int startPos = y;
            int jump = 1;
            while (true)
            {
                if (nums[y] > nums[i])
                {
                    if (jump > nums.Length - 1)
                        break;
                    jump++;


                }
                else break;
                
                if (i >= nums.Length-1) i = 0; else i++;
            }
            int j = y;
            int sum = 1;
            int last = nums[y];
            while (true)
            {                
                if (nums[j] >= last)
                {
                    sum++;
                    last = nums[j];
                }
                else break;
                j += jump;
                if (j >= nums.Length - 1)
                {
                    j = 0;
                }
                

            }
            result.Add(sum);
          //  Console.WriteLine(jump);
        }

        result.Sort();
        Console.WriteLine(result[result.Count-1]);
    }

}