using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Rabbit
{
    static void Main()
    {
        string[] input = Console.ReadLine().Split(',');
        int[] numbers = new int[input.Length];
        int minElement = int.MaxValue;
        //int index = 0;
        for (int i = 0; i < input.Length; i++)
        {
            numbers[i] = int.Parse(input[i]);
            //if (minElement > numbers[i])
            //{
            //    index = i;
            //}
        }
        int maxCount = 0;
        
        for (int index = 0; index < numbers.Length; index++)
        {
            int step = 1;
            while (step < numbers.Length)
            {
                bool[] visited = new bool[numbers.Length];
                int currentCount = 1;
                int startIndex = index;
                int nextIndex = 0;

                while (true)
                {
                    visited[startIndex] = true;
                    nextIndex = startIndex + step;
                    if (nextIndex >= numbers.Length)
                    {
                        nextIndex = nextIndex - numbers.Length;
                    }
                    if (numbers[nextIndex] > numbers[startIndex] && visited[nextIndex] == false)
                    {
                        currentCount++;
                        startIndex = nextIndex;
                        visited[startIndex] = true;
                    }
                    else
                    {
                        break;
                    }
                }
                if (maxCount < currentCount)
                {
                    maxCount = currentCount;
                }
                step++;
            }
        }

        
        Console.WriteLine(maxCount);

	}
   
}
