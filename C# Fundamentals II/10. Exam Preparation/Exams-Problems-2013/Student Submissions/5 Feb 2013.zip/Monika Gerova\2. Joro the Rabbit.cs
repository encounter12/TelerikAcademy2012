using System;

class TheRabbit
{
    static void Main()
    {
        
       string[] strArray = Console.ReadLine().Split(',', '.', ' ');
        for (int i = 0; i < strArray.Length; i++)
        {
           
                strArray[i] = strArray[i].Trim();
           
        }
        int len = 0;
        int bestlen = 0;
        int visited = int.MinValue;
        int counter = 0;
        int temp = 0;
        int[] terrain = new int[strArray.Length];
        int[] terraincopy = new int[terrain.Length];
        for (int i = 0; i < strArray.Length; i++)
        {
           
                terrain[i] = Convert.ToInt32(strArray[i]);
           
        }
        for(int index=0; index<terraincopy.Length; index++)
        {
            terraincopy[index] = terrain[index];
        }

        for (int i = 0; i < terrain.Length; i++)
        {
            if (i == 0)
            {
                for (int j = i; j < terrain.Length; j++)
                {

                    if (j >= 0 && terrain[j] > visited)
                    {
                        visited = terrain[j];
                        counter++;
                        len = counter;
                    }
                }
            }
            if (len > bestlen)
            {
                bestlen = counter;
            }
           
            if (i > 0)
            {
                int var = i;
                for (int k = terrain.Length - var; k < terrain.Length; k++)
                {
                    terrain[k] = terraincopy[temp];
                    temp++;
                }
                temp = 0;
                for (int j = 0; j < terrain.Length -i; j++)
                {
                    terrain[j] = terraincopy[var];
                    var++;
                }
               
                for (int cells = 0; cells < terrain.Length; cells++)
                {

                    if (cells >= 0 && terrain[cells] > visited)
                    {

                        visited = terrain[cells];

                        counter++;
                        len = counter;
                    }
                   
                }
                if (len > bestlen)
                {
                    bestlen = counter;
                  
                    
                }
                visited = int.MinValue ;
                counter = 0;

            }
        }
        Console.WriteLine(bestlen);
    }
           
        
    
       
}