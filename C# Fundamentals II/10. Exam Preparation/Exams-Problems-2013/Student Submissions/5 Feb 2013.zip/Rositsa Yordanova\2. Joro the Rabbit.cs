using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
  
namespace Rabit
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] input_array = input.Split(',');
            int[] array = new int[input_array.Length];
            bool[] bool_array = new bool[input_array.Length];
  
            int count = 2;
  
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = Convert.ToInt32(input_array[i]);
                bool_array[i] = false;
            }
  
            for (int i = 0; i < array.Length-1; i++)
            {
                bool_array[i] = true;
                if (array[i] < array[i+1] && bool_array[i+1] == false)
                {
                    count++;
                }
                //array[i] = Convert.ToInt32(input_array[i]);
                //bool_array[i] = false;
            }
  
            Console.WriteLine(count);
        }
    }
}