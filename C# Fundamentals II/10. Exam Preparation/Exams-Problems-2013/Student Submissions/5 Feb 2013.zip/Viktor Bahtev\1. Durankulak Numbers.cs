using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
class DurankulakNumbers
{
    static void Main()
    {
        string durankulakNumber = Console.ReadLine();
        List<string> durankulakDigits = new List<String>();
        for (int i = durankulakNumber.Length - 1; i >= 0; i--)
        {
            if (i > 0 && Char.IsLower(durankulakNumber[i - 1]))
            {
                durankulakDigits.Add(durankulakNumber[i - 1].ToString() + durankulakNumber[i].ToString());
                i--;
            }
            else
            {
                durankulakDigits.Add(durankulakNumber[i].ToString());
            }
        }
  
        Console.WriteLine(DurankulakToDecimal(durankulakDigits));
    }
  
    private static Decimal DurankulakToDecimal(List<string> durankulakDigits)
    {
        Decimal result = 0;
        for (int i = 0; i < durankulakDigits.Count; i++)
        {
            switch (durankulakDigits[i])
            {
                case "A": result += 0 * Pow(168, i); break;
                case "B": result += 1 * Pow(168, i); break;
                case "C": result += 2 * Pow(168, i); break;
                case "D": result += 3 * Pow(168, i); break;
                case "E": result += 4 * Pow(168, i); break;
                case "F": result += 5 * Pow(168, i); break;
                case "G": result += 6 * Pow(168, i); break;
                case "H": result += 7 * Pow(168, i); break;
                case "I": result += 8 * Pow(168, i); break;
                case "J": result += 9 * Pow(168, i); break;
                case "K": result += 10 * Pow(168, i); break;
                case "L": result += 11 * Pow(168, i); break;
                case "M": result += 12 * Pow(168, i); break;
                case "N": result += 13 * Pow(168, i); break;
                case "O": result += 14 * Pow(168, i); break;
                case "P": result += 15 * Pow(168, i); break;
                case "Q": result += 16 * Pow(168, i); break;
                case "R": result += 17 * Pow(168, i); break;
                case "S": result += 18 * Pow(168, i); break;
                case "T": result += 19 * Pow(168, i); break;
                case "U": result += 20 * Pow(168, i); break;
                case "V": result += 21 * Pow(168, i); break;
                case "W": result += 22 * Pow(168, i); break;
                case "X": result += 23 * Pow(168, i); break;
                case "Y": result += 24 * Pow(168, i); break;
                case "Z": result += 25 * Pow(168, i); break;
  
                case "aA": result += (1 + 25) * Pow(168, i); break;
                case "aB": result += (1 + 26) * Pow(168, i); break;
                case "aC": result += (1 + 27) * Pow(168, i); break;
                case "aD": result += (1 + 28) * Pow(168, i); break;
                case "aE": result += (1 + 29) * Pow(168, i); break;
                case "aF": result += (1 + 30) * Pow(168, i); break;
                case "aG": result += (1 + 31) * Pow(168, i); break;
                case "aH": result += (1 + 32) * Pow(168, i); break;
                case "aI": result += (1 + 33) * Pow(168, i); break;
                case "aJ": result += (1 + 34) * Pow(168, i); break;
                case "aK": result += (1 + 35) * Pow(168, i); break;
                case "aL": result += (1 + 36) * Pow(168, i); break;
                case "aM": result += (1 + 37) * Pow(168, i); break;
                case "aN": result += (1 + 38) * Pow(168, i); break;
                case "aO": result += (1 + 39) * Pow(168, i); break;
                case "aP": result += (1 + 40) * Pow(168, i); break;
                case "aQ": result += (1 + 41) * Pow(168, i); break;
                case "aR": result += (1 + 42) * Pow(168, i); break;
                case "aS": result += (1 + 43) * Pow(168, i); break;
                case "aT": result += (1 + 44) * Pow(168, i); break;
                case "aU": result += (1 + 45) * Pow(168, i); break;
                case "aV": result += (1 + 46) * Pow(168, i); break;
                case "aW": result += (1 + 47) * Pow(168, i); break;
                case "aX": result += (1 + 48) * Pow(168, i); break;
                case "aY": result += (1 + 49) * Pow(168, i); break;
                case "aZ": result += (1 + 50) * Pow(168, i); break;
  
                case "bA": result += (1 + 51) * Pow(168, i); break;
                case "bB": result += (1 + 52) * Pow(168, i); break;
                case "bC": result += (1 + 53) * Pow(168, i); break;
                case "bD": result += (1 + 54) * Pow(168, i); break;
                case "bE": result += (1 + 55) * Pow(168, i); break;
                case "bF": result += (1 + 56) * Pow(168, i); break;
                case "bG": result += (1 + 57) * Pow(168, i); break;
                case "bH": result += (1 + 58) * Pow(168, i); break;
                case "bI": result += (1 + 59) * Pow(168, i); break;
                case "bJ": result += (1 + 60) * Pow(168, i); break;
                case "bK": result += (1 + 61) * Pow(168, i); break;
                case "bL": result += (1 + 62) * Pow(168, i); break;
                case "bM": result += (1 + 63) * Pow(168, i); break;
                case "bN": result += (1 + 64) * Pow(168, i); break;
                case "bO": result += (1 + 65) * Pow(168, i); break;
                case "bP": result += (1 + 66) * Pow(168, i); break;
                case "bQ": result += (1 + 67) * Pow(168, i); break;
                case "bR": result += (1 + 68) * Pow(168, i); break;
                case "bS": result += (1 + 69) * Pow(168, i); break;
                case "bT": result += (1 + 70) * Pow(168, i); break;
                case "bU": result += (1 + 71) * Pow(168, i); break;
                case "bV": result += (1 + 72) * Pow(168, i); break;
                case "bW": result += (1 + 73) * Pow(168, i); break;
                case "bX": result += (1 + 74) * Pow(168, i); break;
                case "bY": result += (1 + 75) * Pow(168, i); break;
                case "bZ": result += (1 + 76) * Pow(168, i); break;
  
                case "cA": result += (1 + 77) * Pow(168, i); break;
                case "cB": result += (1 + 78) * Pow(168, i); break;
                case "cC": result += (1 + 79) * Pow(168, i); break;
                case "cD": result += (1 + 80) * Pow(168, i); break;
                case "cE": result += (1 + 81) * Pow(168, i); break;
                case "cF": result += (1 + 82) * Pow(168, i); break;
                case "cG": result += (1 + 83) * Pow(168, i); break;
                case "cH": result += (1 + 84) * Pow(168, i); break;
                case "cI": result += (1 + 85) * Pow(168, i); break;
                case "cJ": result += (1 + 86) * Pow(168, i); break;
                case "cK": result += (1 + 87) * Pow(168, i); break;
                case "cL": result += (1 + 88) * Pow(168, i); break;
                case "cM": result += (1 + 89) * Pow(168, i); break;
                case "cN": result += (1 + 90) * Pow(168, i); break;
                case "cO": result += (1 + 91) * Pow(168, i); break;
                case "cP": result += (1 + 92) * Pow(168, i); break;
                case "cQ": result += (1 + 93) * Pow(168, i); break;
                case "cR": result += (1 + 94) * Pow(168, i); break;
                case "cS": result += (1 + 95) * Pow(168, i); break;
                case "cT": result += (1 + 96) * Pow(168, i); break;
                case "cU": result += (1 + 97) * Pow(168, i); break;
                case "cV": result += (1 + 98) * Pow(168, i); break;
                case "cW": result += (1 + 99) * Pow(168, i); break;
                case "cX": result += (1 + 100) * Pow(168, i); break;
                case "cY": result += (1 + 101) * Pow(168, i); break;
                case "cZ": result += (1 + 102) * Pow(168, i); break;
  
                case "dA": result += (1 + 103) * Pow(168, i); break;
                case "dB": result += (1 + 104) * Pow(168, i); break;
                case "dC": result += (1 + 105) * Pow(168, i); break;
                case "dD": result += (1 + 106) * Pow(168, i); break;
                case "dE": result += (1 + 107) * Pow(168, i); break;
                case "dF": result += (1 + 108) * Pow(168, i); break;
                case "dG": result += (1 + 109) * Pow(168, i); break;
                case "dH": result += (1 + 110) * Pow(168, i); break;
                case "dI": result += (1 + 111) * Pow(168, i); break;
                case "dJ": result += (1 + 112) * Pow(168, i); break;
                case "dK": result += (1 + 113) * Pow(168, i); break;
                case "dL": result += (1 + 114) * Pow(168, i); break;
                case "dM": result += (1 + 115) * Pow(168, i); break;
                case "dN": result += (1 + 116) * Pow(168, i); break;
                case "dO": result += (1 + 117) * Pow(168, i); break;
                case "dP": result += (1 + 118) * Pow(168, i); break;
                case "dQ": result += (1 + 119) * Pow(168, i); break;
                case "dR": result += (1 + 120) * Pow(168, i); break;
                case "dS": result += (1 + 121) * Pow(168, i); break;
                case "dT": result += (1 + 122) * Pow(168, i); break;
                case "dU": result += (1 + 123) * Pow(168, i); break;
                case "dV": result += (1 + 124) * Pow(168, i); break;
                case "dW": result += (1 + 125) * Pow(168, i); break;
                case "dX": result += (1 + 126) * Pow(168, i); break;
                case "dY": result += (1 + 127) * Pow(168, i); break;
                case "dZ": result += (1 + 128) * Pow(168, i); break;
  
                case "eA": result += (1 + 129) * Pow(168, i); break;
                case "eB": result += (1 + 130) * Pow(168, i); break;
                case "eC": result += (1 + 131) * Pow(168, i); break;
                case "eD": result += (1 + 132) * Pow(168, i); break;
                case "eE": result += (1 + 133) * Pow(168, i); break;
                case "eF": result += (1 + 134) * Pow(168, i); break;
                case "eG": result += (1 + 135) * Pow(168, i); break;
                case "eH": result += (1 + 136) * Pow(168, i); break;
                case "eI": result += (1 + 137) * Pow(168, i); break;
                case "eJ": result += (1 + 138) * Pow(168, i); break;
                case "eK": result += (1 + 139) * Pow(168, i); break;
                case "eL": result += (1 + 140) * Pow(168, i); break;
                case "eM": result += (1 + 141) * Pow(168, i); break;
                case "eN": result += (1 + 142) * Pow(168, i); break;
                case "eO": result += (1 + 143) * Pow(168, i); break;
                case "eP": result += (1 + 144) * Pow(168, i); break;
                case "eQ": result += (1 + 145) * Pow(168, i); break;
                case "eR": result += (1 + 146) * Pow(168, i); break;
                case "eS": result += (1 + 147) * Pow(168, i); break;
                case "eT": result += (1 + 148) * Pow(168, i); break;
                case "eU": result += (1 + 149) * Pow(168, i); break;
                case "eV": result += (1 + 150) * Pow(168, i); break;
                case "eW": result += (1 + 151) * Pow(168, i); break;
                case "eX": result += (1 + 152) * Pow(168, i); break;
                case "eY": result += (1 + 153) * Pow(168, i); break;
                case "eZ": result += (1 + 154) * Pow(168, i); break;
  
                case "fA": result += (1 + 155) * Pow(168, i); break;
                case "fB": result += (1 + 156) * Pow(168, i); break;
                case "fC": result += (1 + 157) * Pow(168, i); break;
                case "fD": result += (1 + 158) * Pow(168, i); break;
                case "fE": result += (1 + 159) * Pow(168, i); break;
                case "fF": result += (1 + 160) * Pow(168, i); break;
                case "fG": result += (1 + 161) * Pow(168, i); break;
                case "fH": result += (1 + 162) * Pow(168, i); break;
                case "fI": result += (1 + 163) * Pow(168, i); break;
                case "fJ": result += (1 + 164) * Pow(168, i); break;
                case "fK": result += (1 + 165) * Pow(168, i); break;
                case "fL": result += (1 + 166) * Pow(168, i); break;
                case "fM": result += (1 + 167) * Pow(168, i); break;
                case "fN": result += (1 + 168) * Pow(168, i); break;
                default: throw new ArgumentException();
            }
        }
        return result;
  
    }
  
    static Decimal Pow(int x, int y)
    {
        Decimal result = 1;
        for (int i = 0; i < y; i++)
        {
            result *= x;
        }
        return result;
    }
}