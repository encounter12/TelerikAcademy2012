using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace JoroTheRabbit
{
    class JoroTheRabbit
    {
        static void Main()
        {
            string terrain = Console.ReadLine();
            string[] terrainN = terrain.Split(',');
            StringBuilder terrainNum = new StringBuilder();
            int MinEl = 0;
            int steppps = 0;
            int bestRoute = 1;
            int Route = 1;
            int nextIndex = 0;
            int[] terrNumber = new int[terrainN.Length];
            int[] SortNumbers = new int[terrainN.Length];
            int[] MinFirst = new int[terrainN.Length];
            for (int num = 0; num < terrainN.Length; num++)
            {
                terrNumber[num] = int.Parse(terrainN[num]);
                SortNumbers[num] = int.Parse(terrainN[num]);
            }           
            Array.Sort(SortNumbers); //sort!!!
            for (int sn = 0; sn < SortNumbers.Length; sn++)
            {
                MinEl = SortNumbers[sn];
 
                for (int step = 1; step < terrNumber.Length-1; step++)
                {
                    int nextMinEl = MinEl;
                    while (true)
                    {
                        int index = Array.IndexOf(terrNumber, nextMinEl);
                        nextIndex = index;
                         
                            nextIndex = index + step;
                         
                        if (nextIndex >= terrNumber.Length)
                        {
                            steppps = (nextIndex) - (terrNumber.Length);
                        }
                        else
                        {
                            steppps = nextIndex;
                        }
                        if (terrNumber[steppps] > nextMinEl) //!!!!
                        {
                            nextMinEl = terrNumber[steppps]; //!!!!
                            Route++;
                        }
                        else
                        {           
                            break;
                        }
                         
                    }
                    if (bestRoute < Route)
                    {
                        bestRoute = Route;
                        Route = 1;
                    }
                    else
                    {
                        Route = 1;
                    }
                     
                }
            }
            Console.WriteLine(bestRoute);
        }
    }
}