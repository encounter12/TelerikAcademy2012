using System;
using System.Numerics;

class Durankulak
{

    static BigInteger GetNumber(int power)
    {
        BigInteger result = 1;
        for (int i = 1; i <= power; i++)
        {
            result *= 168;
        }
        return result;
    }

    static void Main()
    {
        string input = Console.ReadLine();
        char[] arr = input.ToCharArray();
        Array.Reverse(arr);
        BigInteger result = 0;
        int power = 0;
        for (int i = 0; i < arr.Length; i++)
        {
            if (i + 1 < arr.Length && arr[i + 1] >= 'a' && arr[i + 1] <= 'z')
            {
                int baseNumber = (arr[i] - 'A') + (arr[i + 1] - 96) * 26;
                result += baseNumber * GetNumber(power);
                i++;
                power++;
            }
            else
            {
                int baseNumber = (arr[i] - 'A');
                result += baseNumber * GetNumber(power);
                power++;
            }
        }
        Console.WriteLine(result);
    }
}
