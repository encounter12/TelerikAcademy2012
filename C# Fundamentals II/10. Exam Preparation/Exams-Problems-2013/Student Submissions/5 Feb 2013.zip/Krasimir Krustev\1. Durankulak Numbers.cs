using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;
 
class DurankulakNumbers
{
    static void Main()
    {
        IDictionary<string, int> fromAToZ = new Dictionary<string, int>();
        int uppersStartValue = 0;
        for (char ch = 'A'; ch <= 'Z'; ch++)
        {
            fromAToZ.Add(ch.ToString(), uppersStartValue++);
        }
 
        int lowersStartValue = 26;
        IDictionary<string, int> fromAToF = new Dictionary<string, int>();
        for (char ch = 'a'; ch <= 'f'; ch++)
        {
            fromAToF.Add(ch.ToString(), lowersStartValue);
            lowersStartValue += 26;
        }
 
        string inputString = Console.ReadLine();
 
        BigInteger multiplier = 1;
        int stringLastChar = inputString.Length - 1;
        BigInteger convertedNum = 0;
 
 
        if (inputString.Length == 1)
        {
            convertedNum = fromAToZ[inputString];
        }
        else if (inputString.Length > 1 && inputString.Length <= 16)
        {
            for (int i = stringLastChar; i >= 0; i--)
            {
                if (char.IsUpper(inputString[i]) && i - 1 >= 0 && char.IsLower(inputString[i - 1]))
                {
                    convertedNum += (fromAToZ[inputString[i].ToString()] + fromAToF[inputString[i - 1].ToString()]) * multiplier;
                    i--;
                }
                else if (char.IsUpper(inputString[i]))
                {
                    convertedNum += (fromAToZ[inputString[i].ToString()]) * multiplier;
                }
                multiplier *= 168;
            }
        }
 
        Console.WriteLine(convertedNum);
    }
}