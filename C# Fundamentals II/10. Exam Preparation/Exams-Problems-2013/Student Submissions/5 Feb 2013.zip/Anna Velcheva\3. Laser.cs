using System;

class Laser
{
    static void Main(string[] args)
    {
        string line = Console.ReadLine();
        string[] splitInput = line.Split();

        int w = Int32.Parse(splitInput[0]);
        int h = Int32.Parse(splitInput[1]);
        int d = Int32.Parse(splitInput[2]);

        line = Console.ReadLine();
        splitInput = line.Split();

        int startW = Int32.Parse(splitInput[0]);
        int startH = Int32.Parse(splitInput[1]);
        int startD = Int32.Parse(splitInput[2]);

        line = Console.ReadLine();
        splitInput = line.Split();

        int dirW = Int32.Parse(splitInput[0]);
        int dirH = Int32.Parse(splitInput[1]);
        int dirD = Int32.Parse(splitInput[2]);

        bool[, ,] burned = new bool[w + 1, h + 1, d + 1];

        for (int i = 1; i <= w; i++)
        {
            burned[i, 1, 1] = true;
            burned[i, h, 1] = true;
            burned[i, h, d] = true;
            burned[i, 1, d] = true;
        }

        for (int i = 1; i <= h; i++)
        {
            burned[1, i, 1] = true;
            burned[w, i, 1] = true;
            burned[w, i, d] = true;
            burned[1, i, d] = true;
        }

        for (int i = 1; i < d; i++)
        {
            burned[1, 1, i] = true;
            burned[w, 1, i] = true;
            burned[1, h, i] = true;
            burned[w, h, i] = true;
        }

        int currentW = startW;
        int currentH = startH;
        int currentD = startD;

        while (burned[currentW, currentH, currentD] == false)
        {
            burned[currentW, currentH, currentD] = true;
            currentW += dirW;
            currentH += dirH;
            currentD += dirD;

            if (currentW > w || currentW < 1)
            {
                currentW -= dirW * 2;
                dirW = 0 - dirW;
            }
            if (currentH > h || currentH < 1)
            {
                currentH -= dirH * 2;
                dirH = 0 - dirH;
            }
            if (currentD > d || currentD < 1)
            {
                currentD -= dirD * 2;
                dirD = 0 - dirD;
            }
        }

        currentW -= dirW;
        currentH -= dirH;
        currentD -= dirD;

        Console.WriteLine(currentW + " " + currentH + " " + currentD);
    }
}
