using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

class DurankulakNumbers
{
    static string[] digits = new string[168];
    static List<string> number = new List<string>();
    static BigInteger result = new BigInteger();

    static void InitializeDigits()
    {
        char firstDigit = 'a';
        char secondDigit = 'A';

        for (int i = 0; i < 26; i++)
        {
            digits[i] = secondDigit.ToString();
            secondDigit++;
        }

        secondDigit = 'A';

        int digitCount = 0;

        for (int i = 26; i < +168; i++)
        {
            digits[i] = firstDigit.ToString() + secondDigit.ToString();

            secondDigit++;

            digitCount++;

            if (digitCount == 26)
            {
                firstDigit++;
                secondDigit = 'A';

                digitCount = 0;
            }
        }
    }

    static void InitializeNumber(string input)
    {
        for (int i = 0; i < input.Length; i++)
        {
            if (char.IsUpper(input[i]))
            {
                number.Add(input[i].ToString());
            }
            else
            {
                number.Add(input[i].ToString() + input[i + 1].ToString());
                i++;
            }
        }
    }

    static void CalculateResult()
    {
        for (int i = 0; i < number.Count; i++)
        {
            for (int j = 0; j < digits.Length; j++)
            {
                if (number[number.Count - i - 1] == digits[j])
                {
                    if (i == 0)
                    {
                        result = j;
                    }
                    else
                    {
                        BigInteger tempNum = new BigInteger(168);

                        for (int k = 1; k < i; k++)
                        {
                            tempNum = tempNum * 168;
                        }

                        result = result + (j * tempNum);
                    }
                }
            }
        }
    }

    static void Main()
    {
        string input = Console.ReadLine();

        InitializeDigits();

        InitializeNumber(input);

        CalculateResult();

        Console.WriteLine(result);
    }
}