using System;
using System.Text;

class Brackets
{
    static bool isMultilineComment = false;

    static bool inQuotes = false;

    static bool isSingleLineComment = false;

    static string indent = "";

    static void Main(string[] args)
    {
        int lines = int.Parse(Console.ReadLine());

        indent = Console.ReadLine();

        string inputLine;

        StringBuilder resultText = new StringBuilder();

        for (int i = 0; i < lines; i++)
        {
            inputLine = Console.ReadLine();

            resultText.Append(inputLine.Trim()).Append("\n");
        }

        Console.WriteLine(resultText);
    }
}
