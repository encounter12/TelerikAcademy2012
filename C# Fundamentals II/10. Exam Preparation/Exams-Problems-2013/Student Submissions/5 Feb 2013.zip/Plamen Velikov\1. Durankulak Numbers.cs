using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace durankulak
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder();
            char[] upperLetters = new char[26];
            for (int i = 0; i < upperLetters.Length; i++)
            {
                upperLetters[i] = (char)('A' + i);
            }
            char[] lowerLetters = new char[6];
            for (int i = 0; i < lowerLetters.Length; i++)
            {
                lowerLetters[i] = (char)('a' + i);
            }
            string durankulak = Console.ReadLine();
            char[] durankSymbols = durankulak.ToCharArray();
            Array.Reverse(durankSymbols);
            int number = 0;
            int k =1;
            int count = 0;
            int bigletterCoef = 0;
            for (int i = 0; i < durankSymbols.Length; i++)
            {
                
                if (char.IsUpper(durankSymbols[i]))
                {
                    bigletterCoef = durankSymbols[i]-'A';
                    if (i + 1 <= durankSymbols.Length - 1)
                    {
                        if (char.IsUpper(durankSymbols[i + 1]))
                        {
                            number = bigletterCoef;
                            bigletterCoef = 0;
                            count++;
                        }
                    }
                    else
                    {
                        number = bigletterCoef;
                    }
                }
                else
                {
                    if (durankSymbols[i] == 'a')
                    {
                        number += (k * 25 + bigletterCoef + k) *(int)Math.Pow(168 , count);
                    }
                    if (durankSymbols[i] == 'b')
                    {
                        k += 1;
                        number += (k * 25 + bigletterCoef + k) *(int)Math.Pow(168 , count);
                    }
                    if (durankSymbols[i] == 'c')
                    {
                        k += 2;
                        number += (k * 25 + bigletterCoef + k) *(int)Math.Pow(168 , count);
                    }
                    if (durankSymbols[i] == 'd')
                    {
                        k += 3;
                        number += (k * 25 + bigletterCoef + k) *(int)Math.Pow(168 , count);
                    }
                    if (durankSymbols[i] == 'e')
                    {
                        k += 4;
                        number += (k * 25 + bigletterCoef + k) *(int)Math.Pow(168 , count);
                    }
                    if (durankSymbols[i] == 'f')
                    {
                        k += 5;
                        number += k * 25 + bigletterCoef + k;
                    }
                }
            }
            Console.WriteLine(number);
        }
    }
}
