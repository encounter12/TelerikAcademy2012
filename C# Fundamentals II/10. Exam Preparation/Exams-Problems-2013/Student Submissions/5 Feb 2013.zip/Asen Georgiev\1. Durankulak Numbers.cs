using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01First
{
    class first
    {
        static void Main()
        {
            //string number = "CfI";

            string number = Console.ReadLine();
            string numberResult = String.Empty;
            numberResult = ConvertToDecimal(number, 168).ToString();
            Console.WriteLine(numberResult);
        }


        static ulong ConvertToDecimal(string str, int baseinput)
        {
            ulong result = 0;
            string simbol;
            int number = 0;
            List<int> Digits = new List<int>();
            for (int i = 0; i < str.Length; i++)
            {
                //string Digit ="";
                if (Char.IsLower(str, i))
                {
                    Digits.Add(ConvertDigit(str.Substring(i, 2)));
                    i++;
                }
                else
                {
                    Digits.Add(ConvertDigit(str.Substring(i, 1)));
                }
            }
            for (int i = 0; i < Digits.Count; i++)
            {
                result += (ulong)Digits[i] * (ulong)Math.Pow(baseinput, Digits.Count - 1 - i);
            }
           
            return result;
        }
        static int ConvertDigit(string number)
        {
            int result = 0;
            List<string> Letters = new List<string>() {
                "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                "aA","aB","aC","aD","aE","aF","aG","aH","aI","aJ","aK","aL","aM","aN","aO","aP",
                "aQ","aR","aS","aT","aU","aV","aW","aX","aY","aZ","bA","bB","bC","bD","bE","bF",
                "bG","bH","bI","bJ","bK","bL","bM","bN","bO","bP","bQ","bR","bS","bT","bU","bV",
                "bW","bX","bY","bZ","cA","cB","cC","cD","cE","cF","cG","cH","cI","cJ","cK","cL",
                "cM","cN","cO","cP","cQ","cR","cS","cT","cU","cV","cW","cX","cY","cZ","dA","dB",
                "dC","dD","dE","dF","dG","dH","dI","dJ","dK","dL","dM","dN","dO","dP","dQ","dR",
                "dS","dT","dU","dV","dW","dX","dY","dZ","eA","eB","eC","eD","eE","eF","eG","eH",
                "eI","eJ","eK","eL","eM","eN","eO","eP","eQ","eR","eS","eT","eU","eV","eW","eX",
                "eY","eZ","fA","fB","fC","fD","fE","fF","fG","fH","fI","fJ","fK","fL"};
            result = Letters.IndexOf(number);
            return result;
        }
    }
}
