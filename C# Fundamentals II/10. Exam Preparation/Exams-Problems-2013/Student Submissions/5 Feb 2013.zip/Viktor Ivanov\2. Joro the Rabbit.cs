using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1
{
    class Program
    {
        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            string[] inputStr = line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            int[] input = new int[inputStr.Length];
            for (int i = 0; i < inputStr.Length; i++)
            {
                input[i] = int.Parse(inputStr[i]);
            }
            //int[] input = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0 };
            int[] newInput = new int[input.Length * input.Length];

            int startFill = 0;
            for (int i = 0; i < input.Length; i++)
            {
                for (int j = 0; j < input.Length; j++)
                {
                    newInput[startFill] = input[j];
                    startFill++;
                }

            }

            int bestMatch = 0;
            for (int i = 0; i < input.Length; i++)
            {
                for (int j = 1; j < input.Length; j++)
                {
                    int match = checkJumps(newInput, i, j, input.Length);
                    if (match > bestMatch)
                    {
                        bestMatch = match;
                    }
                }
                
            }
            Console.WriteLine(bestMatch + 1);
        }

        static int checkJumps(int[] inputArr, int numToStart, int step, int lenghtInput)
        {
            int maxJump = inputArr.Length * 2;
            int countJumps = 0;
            //int step = 0;
            int bestMatch = 0;
            int currentStep = 0;
            int matches = 0;
            int currPos = numToStart + step;
                for (int j = 0; j < lenghtInput; j++)
                {

                    int currentArr = inputArr[j];
                    
                    if (inputArr[numToStart] < inputArr[numToStart + step])
                    {
                        matches++;
                        if (matches > bestMatch)
                        {
                            bestMatch = matches;
                        }
                        numToStart = numToStart + step;
                        currPos = numToStart + step;
                    }
                    else
                    {
                        break;
                    }



            }
            return bestMatch;
        }
    }
}
