using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace ConsoleApplication1
{
    class Zad1
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();


            List<string> lettersDigits = new List<string> { };
            string[] capitalLetters = {"A", "B", "C", "D","E", "F", "G","H", "I", "J","K","L","M", "N", "O","P","Q","R","S","T","U","V","W", "X", "Y","Z"};
            string[] smallLetters = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
            List<string> smallUpLetters = new List<string> { };

            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < capitalLetters.Length; j++)
                {
                    smallUpLetters.Add(smallLetters[i] + capitalLetters[j]);
                }
            }


            for (int i = 0; i < capitalLetters.Length; i++)
            {
                lettersDigits.Add(capitalLetters[i]);
            }

            for (int i = 26, k=0 ; i < 168; i++,k++)
            {
                lettersDigits.Add(smallUpLetters[k]);
            }

           
             


            List<string> groupedString = new List<string> { };
            BigInteger sum = 0;
            int x = 1;

            for (int i = 0; i < input.Length; i+=2)
            {
                if (input.Length <= 1)
                {
                    groupedString.Add(input.Substring(i));
                }
                else
                {
                    groupedString.Add(input.Substring(i, 2));
                }
            }


           


            for(int i = groupedString.Count - 1; i >= 0; i--)
            {
                for (int j = 0; j < lettersDigits.Count; j++)
                {
                    if ((groupedString[i]) == (lettersDigits[j]))
                    {
                        sum += j * x;
                        x *= 168;
                    }
                }
            }

            Console.WriteLine(sum);
           


        }
    }
}
