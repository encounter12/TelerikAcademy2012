using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace _01.Task1
{
    class Task1
    {
        static void Main(string[] args)
        {
            string number = Console.ReadLine();

            BigInteger numberInDecimal = 0;
            List<string> realNumStr = new List<string>();
            StringBuilder brb = new StringBuilder();

            if (number.Length == 1)
            {
                numberInDecimal = (Convert.ToChar(number[0]) - 'A') * ((int)Math.Pow(168, 0));
                Console.WriteLine(numberInDecimal);
                return;
            }
            else
            {
                for (int i = 0; i < number.Length - 1; )
                {
                    if (char.IsUpper(number[i]))
                    {
                        realNumStr.Add(Convert.ToString(number[i]));

                        i++;
                    }
                    else
                    {

                        realNumStr.Add(Convert.ToString(number[i]) + Convert.ToString(number[i + 1]));
                        i = i + 2;
                    }
                }
                //last
                if (char.IsUpper(number[number.Length - 2]))
                {
                    realNumStr.Add(Convert.ToString(number[number.Length - 1]));
                }

            }

            //for (int i = 0; i < realNumStr.Count; i++)
            //{
            //    Console.WriteLine(realNumStr[i]);
            //}

            //Console.WriteLine(realNumStr[1][0]);
            //Console.WriteLine(26 + (realNumStr[1][0]-'a') * 26);
            BigInteger current = 0;
            for (int i = realNumStr.Count - 1; i >= 0; i--)
            {
                if (char.IsLower(realNumStr[i][0]))
                {
                    current = (26 + (realNumStr[i][0] - 'a') * 26) + realNumStr[i][1] - 'A';
                    numberInDecimal += current * ((long)Math.Pow(168, (realNumStr.Count - 1 - i)));
                }
                else
                {
                    current = realNumStr[i][0] - 'A';
                    numberInDecimal += current * ((long)Math.Pow(168, (realNumStr.Count - 1 - i)));
                }
            }
            Console.WriteLine(numberInDecimal);
        }
    }
}