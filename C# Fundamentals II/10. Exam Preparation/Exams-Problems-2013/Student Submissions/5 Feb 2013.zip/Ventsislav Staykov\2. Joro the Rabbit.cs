using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JorroTheRabbit
{
    class Program
    {
        static readonly char[] separators = { ' ', ',' };
        static void Main(string[] args)
        {
            string inputString = Console.ReadLine();
            string[] terrainIntString = inputString.Split(separators, StringSplitOptions.RemoveEmptyEntries);

            int[] terrain = new int[terrainIntString.Length];
            for (int i = 0; i < terrainIntString.Length; i++)
            {
                terrain[i] = int.Parse(terrainIntString[i]);
            }

            int maxCells = 0;
            int tempCells =1;
            
            for (int i = 0; i < terrain.Length; i++)
            {
                
                for (int step = 1; step <= terrain.Length; step++)
                {
                    int enterIndex = i;
                    bool[] isVisited = new bool[terrain.Length];
                    
                    isVisited[i] = true;

                    while (true)
                    {

                        int nextIndex = enterIndex + step;

                        if (nextIndex > terrain.Length - 1)
                        {
                            nextIndex -= terrain.Length;
                        }

                        if ( isVisited[nextIndex]==true || terrain[nextIndex] <= terrain[enterIndex])
                        {
                            break;
                        }
                        else
                        {
                            tempCells++;
                            isVisited[nextIndex] = true;
                            enterIndex = nextIndex;
                        }
                    }

                    if (tempCells>maxCells)
                    {
                        maxCells = tempCells;
                    }
                    tempCells = 1;
                }
            }
            Console.WriteLine(maxCells);
        }
    }
}
