using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace _02.JoroTheRabbit
{
    class Program
    {
        static void Main(string[] args)
        {
            string terrain = Console.ReadLine();
            string[] plates = terrain.Split(new string[] {", "},StringSplitOptions.RemoveEmptyEntries);
            int[] platesInt = new int[plates.Length];
            int countJumps = 1;
            int distance =  -1;
            int plateToJump = 0;
            int maximalElement;
            int maxJups = 0;
            int newDistance = 0;
 
            for (int i = 0; i < platesInt.Length; i++)
            {
                platesInt[i] = int.Parse(plates[i]);
            }
 
            for (int i = 0; i < platesInt.Length; i++)//move the starting position;
            {
                maximalElement = platesInt[i];
                for (int j = 0; j < platesInt.Length; j++)
                {
                    newDistance = 0;
                    countJumps = 1;
                    if (platesInt[j] > platesInt[i])
                    {
                        maximalElement = platesInt[j];
                        if (j < i)
                        {
                            distance = (platesInt.Length - i) + j;
                        }
                        else
                        {
                            distance = j - i;
                        }
                        plateToJump = j;
                        countJumps++;
                        while (true)
                        {
                            newDistance = 0;
                            while (newDistance < distance)
                            {
                                if (plateToJump == platesInt.Length - 1)
                                {
                                    plateToJump = (distance - newDistance) - 1;
                                    break;
                                }
                                newDistance++;
                                plateToJump++;
                            }
                            if (platesInt[plateToJump] > maximalElement)
                            {
                                maximalElement = platesInt[plateToJump];
                                countJumps++;
                            }
                            else
                            {
                                 
                                break;
                            }
                        }
                        if (countJumps > maxJups)
                        {
                            maxJups = countJumps;
                        }
                    }
                }
            }
            Console.WriteLine(maxJups);
        }
    }
}