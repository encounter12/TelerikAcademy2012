using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {

            List<short> circle = new List<short>();
            string input = Console.ReadLine();

            string target = @"-?\d";
            Match match = Regex.Match(input, target);
            while (match.Success)
            {
                circle.Add(short.Parse(match.Value));
                match = match.NextMatch();
            }
            List<short> stepsLen = new List<short>();


            int countHigh = 0;
            int countLess = 0;

            int generalCounter = 1;
            for (int i = 0; i < circle.Count; i++)
            {
                for (int j = i, step = 1; j < circle.Count - 1; j += step)
                {
                    int nextIndex = j + step;
                    if (circle[i] > circle[j + step])
                    {
                        countLess = 0;
                        countHigh++;
                        if (countHigh > generalCounter)
                        {
                            generalCounter = countHigh;
                        }
                    }
                    else if (circle[i] < circle[j + step])
                    {
                        countHigh = 0;
                        countLess++;
                        if (countLess > generalCounter)
                        {
                            generalCounter = countLess;
                        }
                    }

                    if (j == circle.Count - 1)
                    {
                        step++;
                        if (step == circle.Count - 1)
                        {
                            break;
                        }
                    }
                }
                countHigh = 0;
                countLess = 0;
            }
            Console.WriteLine(generalCounter);
        }
    }
}
