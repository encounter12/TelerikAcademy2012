using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Numerics;

class Program
{
    static void Main()
    {

        string number = Console.ReadLine();

        int len = 0;

        if (number.Length % 2 != 0)
        {
            len = number.Length + 1;
        }
        else
        {
            len = number.Length;
        }

        char[] column = new char[len];


        for (int i = number.Length - 1; i >= 0; i--)
        {
            column[(number.Length - 1) - i] = (char)(number[i]);
        }      

        BigInteger result = 0;
        int count = 0;

        for (int i = 1; i < len; i+=2)
        {
            if (column[i]=='\0')
            {
                column[i] = '`';
            }
            BigInteger currentSum = (((int)column[i - 1]) - 65) + (26 * ((int)column[i] - 96));
            result += currentSum * (BigInteger)Math.Pow(168, count);
            count++;
        }

        Console.WriteLine(result);

 
    }
}
