using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class DurankilakNumbers
    {
        static void Main()
        {
            string input = "BaG";
            //int length = input.Length;
            //int[] osnova = new int[26];
            //for (int A = 0; A < 26; A++)
            //{
            //    osnova[A] = A;
            //}

            //int[,] numbArray = new int[26,26];
            //for (int a = 1; a <= 26; a++)
            //{
                
            //}
            List<int> somethingNew=new List<int>();
            foreach (char item in input)
            {
                if (item.Equals('a'))
                {
                    somethingNew.Add(26);
                }
                else if (item.Equals('b'))
                {
                    somethingNew.Add(52);
                }
                else if (item.Equals('c'))
                {
                    somethingNew.Add(78);
                }
                else if (item.Equals('d'))
                {
                    somethingNew.Add(104);
                }
                else if (item.Equals('e'))
                {
                    somethingNew.Add(130);
                }
                else if (item.Equals('f'))
                {
                    somethingNew.Add(156);
                }
                else if (item.Equals('g'))
                {
                    somethingNew.Add(26*7);
                }
                else if (item.Equals('h'))
                {
                    somethingNew.Add(182);
                }
                else if (item.Equals('i'))
                {
                    somethingNew.Add(208);
                }
                else if (item.Equals('g'))
                {
                    somethingNew.Add(234);
                }
                else if (item.Equals('k'))
                {
                    somethingNew.Add(260);
                }
                else if (item.Equals('l'))
                {
                    somethingNew.Add(286);
                }
                else if (item.Equals('m'))
                {
                    somethingNew.Add(312);
                }
                else if (item.Equals('n'))
                {
                    somethingNew.Add(338);
                }
                else if (item.Equals('o'))
                {
                    somethingNew.Add(364);
                }
                else if (item.Equals('p'))
                {
                    somethingNew.Add(390);
                }
                else if (item.Equals('q'))
                {
                    somethingNew.Add(416);
                }
                else if (item.Equals('r'))
                {
                    somethingNew.Add(442);
                }
                else if (item.Equals('s'))
                {
                    somethingNew.Add(468);
                }
                else if (item.Equals('t'))
                {
                    somethingNew.Add(494);
                }
                else if (item.Equals('u'))
                {
                    somethingNew.Add(520);
                }
                else if (item.Equals('v'))
                {
                    somethingNew.Add(546);
                }
                else if (item.Equals('w'))
                {
                    somethingNew.Add(572);
                }
                else if (item.Equals('x'))
                {
                    somethingNew.Add(598);
                }
                else if (item.Equals('y'))
                {
                    somethingNew.Add(624);
                }
                else if (item.Equals('z'))
                {
                    somethingNew.Add(650);
                }
                else if (item.Equals('A'))
                {
                    somethingNew.Add(0);
                }
                else if (item.Equals('B'))
                {
                    somethingNew.Add(1);
                }
                else if (item.Equals('C'))
                {
                    somethingNew.Add(2);
                }
                else if (item.Equals('D'))
                {
                    somethingNew.Add(3);
                }
                else if (item.Equals('E'))
                {
                    somethingNew.Add(4);
                }
                else if (item.Equals('F'))
                {
                    somethingNew.Add(5);
                }
                else if (item.Equals('G'))
                {
                    somethingNew.Add(6);
                }
                else if (item.Equals('H'))
                {
                    somethingNew.Add(7);
                }
                else if (item.Equals('I'))
                {
                    somethingNew.Add(8);
                }
                else if (item.Equals('J'))
                {
                    somethingNew.Add(9);
                }
                else if (item.Equals('K'))
                {
                    somethingNew.Add(10);
                }
                else if (item.Equals('L'))
                {
                    somethingNew.Add(11);
                }
                else if (item.Equals('M'))
                {
                    somethingNew.Add(12);
                }
                else if (item.Equals('N'))
                {
                    somethingNew.Add(13);
                }
                else if (item.Equals('O'))
                {
                    somethingNew.Add(14);
                }
                else if (item.Equals('P'))
                {
                    somethingNew.Add(15);
                }
                else if (item.Equals('Q'))
                {
                    somethingNew.Add(16);
                }
                else if (item.Equals('R'))
                {
                    somethingNew.Add(17);
                }
                else if (item.Equals('S'))
                {
                    somethingNew.Add(18);
                }
                else if (item.Equals('T'))
                {
                    somethingNew.Add(19);
                }
                else if (item.Equals('U'))
                {
                    somethingNew.Add(20);
                }
                else if (item.Equals('V'))
                {
                    somethingNew.Add(21);
                }
                else if (item.Equals('W'))
                {
                    somethingNew.Add(22);
                }
                else if (item.Equals('X'))
                {
                    somethingNew.Add(23);
                }
                else if (item.Equals('Y'))
                {
                    somethingNew.Add(24);
                }
                else if (item.Equals('Z'))
                {
                    somethingNew.Add(25);
                }
            }
            int counter = 0;
            for (int i = 0; i < somethingNew.Count; i++)
            {
                counter += somethingNew[i];
            }

            Console.WriteLine(counter);

            //////int count = 0;
            //////for (int a = 0; a < 26; a++)
            //////{
            //////    for (int A = 0; A < 26; A++)
            //////    {
            //////        osnova[a, A] =count;
            //////        count++;
            //////    }
            //////}
            //////Console.WriteLine(osnova[1, 25]);
            //////char[] separator = new char[] { 'a', 'b', 'b','c','d','e','f','g','h','i','g','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z' };
            ////////char[] separator = new char[] { 'a', 'b', 'f' };



            //////string splited = input.Substring(input.IndexOf('f'), (input.IndexOf('f') + 1));
            //////string[] separeted=new string[16];
            ////////StringBuilder strBuild;

            //////Console.WriteLine(splited);

        }
    }
}
