using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoroTheRabbit
{
    class JoroTheRabbit
    {
        static void Main()
        {
            string input = Console.ReadLine();
            string[] terrainStr = input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            int[] terrain = new int[terrainStr.Length];



            for (int i = 0; i < terrain.Length; i++)
            {
                terrain[i] = int.Parse(terrainStr[i]);
            }

            int step = 0;
            int startPosition;
            //int temp;
            int countSteps = 1;
            int maxSteps = 0;
            int startPositionPlusStep;

            for (int i = 0; i < terrain.Length; i++)
            {
                startPosition = i;
                step = 0;
                while (step < terrain.Length)
                {
                    startPosition = i;
                    step++;
                    startPositionPlusStep = startPosition + step;
                    bool[] isPassed = new bool[terrainStr.Length];
                    countSteps = 1;
                    while (true)
                    {
                        if (startPositionPlusStep > terrain.Length - 1)
                        {
                            startPositionPlusStep = startPositionPlusStep - terrain.Length;
                        }
                        if (terrain[startPosition] < terrain[startPositionPlusStep] && !isPassed[startPositionPlusStep])
                        {
                            countSteps++;
                            isPassed[startPosition] = true;
                            isPassed[startPositionPlusStep] = true;
                            startPosition = startPositionPlusStep;
                            startPositionPlusStep = startPositionPlusStep + step;
                        }
                        else
                        {                          
                            break;
                        }
                    }

                    if (maxSteps < countSteps)
                    {
                        maxSteps = countSteps;
                    }
                }
            }

            Console.WriteLine(maxSteps);

        }
    }
}
