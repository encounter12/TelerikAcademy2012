using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;



class Program
{


    private static BigInteger CalculateValue(char numbers)
    {
        BigInteger value = 0;
        List<char> capitalLetters = new List<char>();
        List<char> smallLetters = new List<char>();

        for (char i = 'A'; i <= 'Z'; i++)
        {
            capitalLetters.Add(i);
        }
        for (char i = 'a'; i <= 'z'; i++)
        {
            smallLetters.Add(i);
        }

        Dictionary<char, int> capLetterValues = new Dictionary<char, int>();
        Dictionary<char, int> smallLetterValues = new Dictionary<char, int>();
        for (int i = 0; i < 26; i++)
        {
            capLetterValues.Add(capitalLetters[i], i);
        }
        for (int i = 0; i < 26; i++)
        {
            smallLetterValues.Add(smallLetters[i], 26 * i + 26);
        }


        if (capLetterValues.ContainsKey(numbers))
        {
            value = capLetterValues[numbers];
        }

        if (smallLetterValues.ContainsKey(numbers))
        {
            value = smallLetterValues[numbers];
        }

        return value;
    }
    static void Main()
    {
        string input = Console.ReadLine();
        List<char> capitalLetters = new List<char>();
        List<char> smallLetters = new List<char>();
        List<char> numbCap = new List<char>();
        List<char> numbSmal = new List<char>();

        BigInteger value = 0;
        for (char i = 'A'; i <= 'Z'; i++)
        {
            capitalLetters.Add(i);
        }
        for (char i = 'a'; i <= 'z'; i++)
        {
            smallLetters.Add(i);
        }

        for (int i = input.Length - 1; i >= 0; i--)
        {
            for (int j = 0; j < capitalLetters.Count; j++)
            {
                if (input[i] == capitalLetters[j])
                {
                    numbCap.Add(input[i]);
                }
                else if (input[i] == smallLetters[j])
                {
                    numbSmal.Add(input[i]);
                }

            }
        }
        for (int i = numbSmal.Count; i < numbCap.Count; i++)
        {
            numbSmal.Add('A');
        }
        value = (BigInteger)(CalculateValue(numbCap[0]) + CalculateValue(numbSmal[0]));
        BigInteger pow = 1;
        for (int i = 1; i < numbCap.Count; i++)
        {
            pow *= 168;
            value += (BigInteger)(CalculateValue(numbCap[i]) + CalculateValue(numbSmal[i])) * pow;
        }

        Console.WriteLine(value);
    }
}
