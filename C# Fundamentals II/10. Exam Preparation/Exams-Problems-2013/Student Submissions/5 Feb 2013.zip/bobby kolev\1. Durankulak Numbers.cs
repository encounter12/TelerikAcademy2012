using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.Numerics;


class Program
{
    static void Main()
    {
        string input = Console.ReadLine();
        char[] big = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
        char[] small = { ' ', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };

        long number = 0;
        long first = 0;
        long second = 0;
        int count1 = 0;
        int count2 = 1;
        int count3 = 0;
        long temp = 0;



        for (int i = input.Length - 1; i >= 0; i--)
        {
            if ((input.Length & 1) != 0)
            {
                if ((i & 1) == 1)
                {
                    second = (long)Array.IndexOf(small, input[i]) * ((long)Math.Pow(26, count2));
                    count3++;
                }
                else
                {
                    first = (long)Array.IndexOf(big, input[i]);
                    count3++;

                }
                if ((count3 & 1) == 0 || i == 0)
                {
                    temp = (first + second) * (long)Math.Pow(168, count1);
                    count1++;
                    first = 0;
                    second = 0;
                }
                number += temp;
                temp = 0;
            }
            else
            {
                if ((i & 1) == 1)
                {
                    first = (long)Array.IndexOf(big, input[i]);
                    count3++;
                }
                else
                {
                    second = (long)Array.IndexOf(small, input[i]) * ((long)Math.Pow(26, count2));
                    count3++;

                }
                if ((count3 & 1) == 0 || i == 0)
                {
                    temp = (first + second) * (long)Math.Pow(168, count1);
                    count1++;
                    first = 0;
                    second = 0;
                }
                number += temp;
                temp = 0;
            }
        }
        Console.WriteLine(number);
    }
}
