using System;
using System.Linq;

class Problem2
{
    static void Main()
    {
        int[] input = Console.ReadLine().Split(new string[] { ", " }, StringSplitOptions.None).Select(h => int.Parse(h)).ToArray();

        int position = 0;
        int maxResult = 0;
        for (int step = 1; step < input.Length; step++)
        {
            for (int a = 0; a < input.Length; a++)
            {
                bool[] mirror = new bool[input.Length];
                int count = 0;
                int index = a;
                position = a;
                bool check = true;
                while (check)
                {

                    for (int i = 0; i < step; i++)
                    {
                        index++;
                        if (index == input.Length)
                        {
                            index = 0;
                        }
                    }

                    if (!mirror[index] && input[position] < input[index])
                    {
                        position = index;
                        mirror[index] = true;
                        count++;
                    }
                    else
                    {
                        if (count > maxResult)
                        {
                            maxResult = count;
                        }
                        check = false;
                        if (maxResult + 1 == input.Length)
                        {
                            break;
                        }
                    }

                }
            }
        }

        Console.WriteLine(maxResult + 1);
    }
}