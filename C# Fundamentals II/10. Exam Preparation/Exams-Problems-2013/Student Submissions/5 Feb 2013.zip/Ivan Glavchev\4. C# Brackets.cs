using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4__brackets
{
	class Program
	{
		private static void app(StringBuilder sb, string indent, int count)
		{
			for (int i = 0; i != count; ++i)
			{
				sb.Append(indent);
			}
		}
		static void Main(string[] args)
		{
			StringBuilder sb = new StringBuilder();
			Stack<char> brackets = new Stack<char>();

			int n = int.Parse(Console.ReadLine());
			string indent = Console.ReadLine();
			List<string> asa = new List<string>();
			for (int i = 0; i != n; ++i)
			{
				asa.Add(Console.ReadLine());
			}
			int whitespaceCount = 0;
			for (int i = 0; i != n; ++i)
			{
				string line = asa[i].Trim() ;
				if (i != 0 && line[0] != '}')
				{
					sb.Append('\n');
					app(sb, indent, brackets.Count);
				}
				for (int j = 0; j != line.Length; ++j)
				{
					if(char.IsWhiteSpace(line[j]))
					{
						if (j == 0 || line[j - 1] == '{' || line[j - 1] == '}') continue; 
						if(whitespaceCount == 0)
						{
							sb.Append(line[j]);
						}
						whitespaceCount++;
						continue;
					}
					whitespaceCount = 0;
					if (line[j] == '{')
					{

						brackets.Push('{');
						if (j == 0)
						{
							sb.Append(line[j]);
							if ((line.Length > 1 && line[j + 1] == '{') || (line.Length == 1 && asa[i+1][0] == '{'))
							{
								continue;
							}
							sb.Append('\n');
							app(sb, indent, brackets.Count);
						}
						else 
						{
							sb.Append('\n');
							app(sb, indent, brackets.Count - 1);
							sb.Append('{');
							if (j!=line.Length - 1 && line[j + 1] != '}')
							{
								sb.Append('\n');
								app(sb, indent, brackets.Count);
							}// za posle

						}
						continue;
					}
					if (line[j] == '}')
					{
						brackets.Pop();
						sb.Append('\n');
						app(sb, indent, brackets.Count);
						sb.Append(line[j]);
						if(j==line.Length - 1 || line[j+1] != '}')

						continue;
						sb.Append('\n');
					}
					
					sb.Append(line[j]);

				}
				
			}
			Console.WriteLine(sb.ToString());
		}
	}
}
