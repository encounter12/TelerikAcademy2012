using System;
using System.IO;
using System.Collections.Generic;

namespace _4.HappyNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] lines = File.ReadAllLines(args[0]);
            foreach (string line in lines)
            {
                int i = int.Parse(line);
                if (IsHappy(i))
                    Console.WriteLine(1);
                else
                    Console.WriteLine(0);
            }
            Console.ReadKey();
        }

        static bool IsHappy(int i)
        {
            if (i == 1) return true;

            List<int> sequence = new List<int>();
            sequence.Add(i);
            int prev = i;
            int next;

            while (true)
            {
                next = GetSumOfSquaredDigits(prev);
                if (next == 1) return true;
                if (sequence.Contains(next)) break; // sequence is repeating    
                sequence.Add(next);
                prev = next;
            }

            return false;
        }

        static int GetSumOfSquaredDigits(int i)
        {
            int sum = 0;
            foreach (char digit in i.ToString()) sum += (digit - 48) * (digit - 48); // '0' is ASCII 48
            return sum;
        }
    }
}