using System;
using System.Collections.Generic;

class Rabit
{
    static void Main()
    {
        string terrain = Console.ReadLine();
        Console.WriteLine(FindResult(SplitAndParse(terrain)));
    }

    static List<int> AllJumpsPerStep = new List<int>();

    static int[] SplitAndParse(string text) 
    {
        string[] splitted = text.Split(',');
        int[] splittedNumbers = new int[splitted.Length];
        splittedNumbers[0] = int.Parse(splitted[0]);
        int theSmalest = splittedNumbers[0];
        int theSmalestIndex = 0;
       for (int i = 1; i < splitted.Length; i++)
       {
           splittedNumbers[i] = int.Parse(splitted[i].TrimStart());
           if (theSmalest > splittedNumbers[i])
           {
               theSmalest = splittedNumbers[i];
               theSmalestIndex = i;
           }
       }
        return splittedNumbers;
    }

    static int MakeJump(int[] numbers, int jumpStep, int startFrom)
    {
        int nextjump = startFrom + jumpStep;
        int limit = numbers.Length;
        int countJumps = 0;

        while (true)
        {
            nextjump = startFrom + jumpStep;
            if (nextjump >= limit)
            {
                nextjump = nextjump - limit;
            }
            if (numbers[startFrom] > numbers[nextjump])
            {
                break;
            }
            else
            {
                countJumps++;
            }
        }
        return (countJumps);
    }

    static int FindResult(int[] splittedNumbers)
    {
        int result = 0;
        int next = 0;
        int previous = 0;
        for (int i = 0; i < splittedNumbers.Length; i++)
        {
            for (int j = 0; j < splittedNumbers.Length; j++)
			{
                next = MakeJump(splittedNumbers, j, i);
                if (next > previous)
                {
                    previous = next;
                }
			}
            AllJumpsPerStep.Add(previous);
        }
        previous = 0;
        for (int i = 0; i < AllJumpsPerStep.Count; i++)
        {
            if (previous < AllJumpsPerStep[i] )
            {
                previous = AllJumpsPerStep[i];
            }
        }
        return previous;
    }
}