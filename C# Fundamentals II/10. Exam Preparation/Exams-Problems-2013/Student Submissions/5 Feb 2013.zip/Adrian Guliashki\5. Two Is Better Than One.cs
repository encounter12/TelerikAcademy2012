using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace _05.TwoIsBetterThanOne
{
    class Program
    {
        static bool Palindromes(BigInteger number)
        {
            
            string reversed = null;
            bool isPalindrom = false;
            for (int i = number.ToString().Length - 1; i >= 0; i--)
            {
                reversed += number.ToString()[i];
                if (number.ToString()[i] != '3' || number.ToString()[i] != '5' )
                {
                    break;
                }
            }
            if (BigInteger.Parse(reversed) == number)
            {
                isPalindrom = true;
            }
            return isPalindrom;
        }
        static void Main(string[] args)
        {
            //first task
            string input = Console.ReadLine();
            string[] split = input.Split(' ');
            int start = int.Parse(split[0]);
            int end = int.Parse(split[1]);
            int count = 0;

            for (BigInteger i = start; i <= end; i++)
            {
                if (Palindromes(i))
                {
                    count++;   
                }
            }

            //second task
            string list = Console.ReadLine();
            int p = int.Parse(Console.ReadLine());
            string[] numbers = list.Split(',');
            BigInteger[] arr = new BigInteger[numbers.Length];
            int count1 = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                arr[i] = BigInteger.Parse(numbers[i]);
            }
            BigInteger min = arr[0];
            for (int i = 0; i < arr.Length - 1; i++)
            {
                if (arr[i] < min)
                {
                    min = arr[i];
                }
                
            }
            
            Console.WriteLine(count);
            Console.WriteLine(min);
           
        }
    }
}
