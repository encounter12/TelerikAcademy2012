
using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Threading.Tasks;

using System.Numerics;

namespace DurankulakNUmbers

{

    class Program

    {

        static string[] upperLetters = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };

        //A B   C   D   E   F   G   H   I   J   K   L   M   N   O   P   Q   R   S   T   U   V   W   X   Y   Z

        static string[] downLetters = new string[] { "a", "b", "c", "d", "e", "f" };

        static void Main(string[] args)

        {

             

            string input = Console.ReadLine();

            string temp = "";

            BigInteger result = new BigInteger() ;

            long grade = 0;

            for (int i = input.Length - 1; i >= 0; i--)

            {

                temp += input.Substring(i, 1);

                if (temp.Length == 2 || (temp.Length == 1 && i == 0))

                {

                    result+=GetValueOfString(temp,grade);

                    temp="";

                    grade++;   

                }

            }

            Console.WriteLine(result);

        }

  

        static BigInteger GetValueOfString(string temp, long grade)

        {

            BigInteger res = new BigInteger();

            if (temp.Length == 2)

            {

                if (char.IsUpper(Convert.ToChar(temp.Substring(0, 1))) && char.IsUpper(Convert.ToChar(temp.Substring(1, 1))))

                {

                    res += Array.BinarySearch(upperLetters, temp.Substring(0, 1)) *(BigInteger)Math.Pow(168, grade) + (Array.BinarySearch(upperLetters, temp.Substring(1, 1))) * (BigInteger)Math.Pow(168, grade + 1);

                    grade++;

                }

                else

                {

                    res += (Array.BinarySearch(upperLetters, temp.Substring(0, 1)) + (Array.BinarySearch(downLetters, temp.Substring(1, 1)) + 1) * 26) * (BigInteger)Math.Pow(168, grade);

                }

            }

            else if (temp.Length == 1)

            {

                res += Array.BinarySearch(upperLetters, temp.Substring(0, 1))*(BigInteger)Math.Pow(168,grade);

            }

            return res;

        }

    }

}