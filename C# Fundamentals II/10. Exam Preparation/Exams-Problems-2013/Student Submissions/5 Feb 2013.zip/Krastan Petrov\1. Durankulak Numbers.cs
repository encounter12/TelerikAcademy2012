using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;

class Program
{
    static void Main()
    {
        string input = Console.ReadLine();
        StringBuilder result = new StringBuilder();
        int number = 0;
        for (int i = 0; i < input.Length; i++)
        {
            if (input[i] + '0' >= 113 && input[i] + '0' <= 138)
            {
                result.Append((-138+25+((input[i]+'0'))) + number +" ");
            }
            else
            {
                
                switch (input[i])
                {
                    case 'a': number = 26;
                        break;
                    case 'b': number = 52;
                        break;
                    case 'c': number = 78;
                        break;
                    case 'd': number = 104;
                        break;
                    case 'e': number = 130;
                        break;
                    case 'f': number = 156;
                        break;
                }
            }
        }
        string asd=result.ToString();
        string[] splitedStringResult = asd.Split(new char[] {' '},StringSplitOptions.RemoveEmptyEntries);
        BigInteger dec = 0;
        List<BigInteger> ba = new List<BigInteger>();
        int pow = 0;
        for (int i = splitedStringResult.Length-1; i >= 0; i--)
        {
            
            BigInteger temp = BigInteger.Parse(splitedStringResult[i]) * (BigInteger)((Math.Pow(168, pow)));
            ba.Add(temp);
            pow++;
        }
        foreach (var item in ba)
        {
            dec += item;
        }


        ////////// Printing Result
        Console.WriteLine(dec);
    }
}

