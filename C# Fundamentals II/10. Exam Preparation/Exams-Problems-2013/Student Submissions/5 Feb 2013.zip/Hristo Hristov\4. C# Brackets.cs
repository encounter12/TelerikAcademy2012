using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpBrackets
{
    class Program
    {
        static void Space(string separator, int times)
        {
            for (int i = 0; i < times; i++)
            {
                Console.Write(separator);
            }
        }
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            string separator = Console.ReadLine();
            string[] lines = new string[n];
            int openBrackets = 0;
            bool space = false;
            for (int i = 0; i < n; i++)
            {
                lines[i] = Console.ReadLine();
            }
            for (int i = 0; i < n; i++)
            {
                bool furstItem = true;
                space = false;
                foreach (var symbol in lines[i])
                {
                    if (symbol == '{')
                    {
                        if (!furstItem)
                        {
                            Console.WriteLine();
                        }
                        Space(separator, openBrackets);
                        Console.Write(symbol);
                        Console.WriteLine();
                        furstItem = true;
                        openBrackets++;
                        space = false;
                    }
                    else if (symbol == '}')
                    {
                        if (!furstItem)
                        {
                            Console.WriteLine();
                        }
                        openBrackets--;
                        Space(separator, openBrackets);
                        Console.Write(symbol);
                        Console.WriteLine();
                        furstItem = true;
                        space = false;
                    }
                    else if (symbol == ' ')
                    {
                        if (!space && !furstItem)
                        {
                            Console.Write(symbol);
                            space = true;
                        }
                    }
                    else
                    {
                        if (furstItem)
                        {
                            Space(separator, openBrackets);
                        }
                        furstItem = false;
                        space = false;
                        Console.Write(symbol);
                    }
                }

                if(!furstItem)
                {
                    Console.WriteLine();
                }
            }
        }
    }
}
