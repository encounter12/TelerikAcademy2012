using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
class JoroTheRabbit
{
    static void Main()
    {
        string circle = Console.ReadLine();
        string[] array = circle.Split(',');
        int lenght = 0;
        int count = 0;
        int start = 0;
        int[] numbers = new int[array.Length + 2];
        for (int i = 0; i < array.Length; i++)
        {
            numbers[i] = Convert.ToInt32(array[i]);
        }
        for (int i = 1; i < numbers.Length; i++)
        {
            lenght = i;
            for (int j = 0; j < numbers.Length; j = j + i)
            {
                 
                if (start < numbers[j])
                {
                    start = numbers[j];
                    count++;
                    //numbers[j] = int.MinValue;
                }
            }
        }
        Console.WriteLine(++count);
    }
}