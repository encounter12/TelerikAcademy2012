using System;
using System.Numerics;
 
class Program
{
    static void Main(string[] args)
    {
        string input = Console.ReadLine();
        BigInteger result = 0;
        char firstChar;
        int firstCharInt;
        char secondChar;
        int secondCharInt;
        //int power1 = 26;
        int power2 = 1;
        //chetene po dvoiki
        for (int i = input.Length - 1; i >= 0; i--)
        {
            if (i > 0)
            {
                if (input[i - 1] >= 'a' && input[i - 1] <= 'z')
                {
                    firstCharInt = (int)(input[i-1] - 'a'+ 1);
                    secondCharInt = (int)(input[i] - 'A');
                    int temp = (secondCharInt + firstCharInt * 26) * power2;
                    result += temp;
                    //Console.WriteLine(temp);
                    //Console.WriteLine("{0}{1}", input[i-1], input[i]);
                    i--;
                }
                else
                {
                    secondCharInt = (int)(input[i] - 'A');
                    result += secondCharInt * power2;
                    //Console.WriteLine(secondCharInt);
                    //only 1 number
                }
            }
            else
            {
                secondCharInt = (int)(input[i] - 'A');
                result += secondCharInt * power2;
                //Console.WriteLine(secondCharInt);
                //starts with capital
            }
            power2 *= 168;
            //if (i == input.Length-1)
            //{
            //    if (i > 0 && input[i-1] >='a' && input[i-1] <= 'z')
            //    {
            //        firstChar = input[i - 1];
            //        firstCharInt = (int)(firstChar - 'a' + 1);
            //        i--;
                     
            //    }
            //    else
            //    {
            //        firstCharInt = 0;
            //    }
            //    secondChar = input[i];
            //    secondCharInt = (int)(secondChar - 'A');
            //    result += secondCharInt + firstCharInt * 26;
            //}
            //else
            //{
            //    if (i - 1 >= 0 && input[i - 1] >= 'a' && input[i - 1] <= 'z')
            //    {
            //        firstChar = input[i - 1];
            //        firstCharInt = (int)(firstChar - 'a' + 1);
            //        i--;
            //    }
            //    else
            //    {
            //        firstCharInt = 0;
            //    }
            //    secondChar = input[i];
            //    secondCharInt = (int)(secondChar - 'A');
            //    result += (secondCharInt + firstCharInt * 26) * power2;
            //    power2 *= 168;
            //}
 
        }
 
        Console.WriteLine(result);
    }
}
 
//char nextChar = (char)0;
//if ( i+1 < input.Length)
//{
//    nextChar = input[i + 1];
//}
//currentChar = input[i];
//if (currentChar>='A' && currentChar <= 'Z')
//{
//    result += (currentChar - 'A') + 168 * nextChar;
//}