using System;
class Program
{
    static void Main(string[] args)
    {
        string[] cuboidMessures = Console.ReadLine().Split();
        string[] laserStart = Console.ReadLine().Split();
        string[] laserDirections = Console.ReadLine().Split();
        int[] cubMessers = new int[cuboidMessures.Length];
        int[] laserS = new int[laserStart.Length];
        int[] laserDir = new int[laserDirections.Length];
        for (int i = 0; i < cuboidMessures.Length; i++)
        {
            cubMessers[i] = int.Parse(cuboidMessures[i]);
            laserS[i] = int.Parse(laserStart[i]);
            laserDir[i] = int.Parse(laserDirections[i]);
        }
        bool[, ,] cuboid = new bool[cubMessers[0], cubMessers[1], cubMessers[2]];
        bool isBurned = false;
        cuboid[1, 1, 1] = true;
        cuboid[1, cubMessers[1]-1, 1] = true;
        cuboid[cubMessers[0]-1, cubMessers[1]-1, 1] = true;
        cuboid[cubMessers[0]-1, cubMessers[1]-1, cubMessers[2]-1] = true;
        cuboid[1, 1, cubMessers[2]-1] = true;
        cuboid[cubMessers[0]-1, 1, cubMessers[2]-1] = true;
        cuboid[cubMessers[0]-1, 1, 1] = true;
        cuboid[1, cubMessers[1]-1, cubMessers[2]-1] = true;
        int moveX = laserS[0];
        int moveY = laserS[1];
        int moveD = laserS[2];
        while (true)
        {
            if ((laserS[0] == 0 && laserDir[0] == -1 ))
            {
                laserDir[0] = -(laserDir[0]);
            }
            if ((laserS[1] == 0 && laserDir[1] == -1))
            {
                laserDir[1] = -(laserDir[1]);
            }
            if ((laserS[2] == 0 && laserDir[2] == -1))
            {
                laserDir[2] = -(laserDir[2]);
            }
            if (moveY != cubMessers[1]-1 && moveX != cubMessers[0]-1 && moveD != cubMessers[2]-1
                && moveY != 0 && moveX != 0 && moveD != 0)
            {
                if (isBurned == cuboid[moveX, moveY, moveD])
                {
                    cuboid[moveX, moveY, moveD] = true;
                    moveX += laserDir[0];
                    moveY += laserDir[1];
                    moveD += laserDir[2];
                }
                else
                {
                    moveX -= laserDir[0];
                    moveY -= laserDir[1];
                    moveD -= laserDir[2];
                    break;
                }
            }
            else
            {
                if (isBurned == cuboid[moveX, moveY, moveD])
                {
                    if ((moveX == cubMessers[0] - 1 || moveX == 0)&& laserS[0]!=0)
                    {
                        laserDir[0] = laserDir[1];
                    }
                    if ((moveY == cubMessers[1] - 1 || moveY == 0)&& laserS[1]!=0)
                    {
                        laserDir[1] = laserDir[2];
                    }
                    if ((moveD == cubMessers[2] - 1 || moveD == 0)&& laserS[2]!=0)
                    {
                        laserDir[2] = laserDir[0];
                    }
                    cuboid[moveX, moveY, moveD] = true;
                    moveX += laserDir[0];
                    moveY += laserDir[1];
                    moveD += laserDir[2];
                }
            }
        }
        Console.Write(moveX+" ");
        Console.Write(moveY + " ");
        Console.Write(moveD);
    }
}
