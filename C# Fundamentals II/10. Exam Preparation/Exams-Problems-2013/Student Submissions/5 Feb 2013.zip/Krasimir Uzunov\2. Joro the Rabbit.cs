using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rabbit
{
    class Program
    {
        static void Main(string[] args)
        {
            string N = Console.ReadLine();
            string[] terr = N.Split(',');
            int[] terrain = new int[terr.Length];
            for (int i = 0; i < terr.Length; i++)
            {
                terrain[i] = int.Parse(terr[i]);
            }
            int step = 1;
            int jumpCounter = 0; ;
            int maxjumps = 0;
            int nextJump = 0;
            for (int i = 0; i < terrain.Length; i++)
            {
                int index = i;
                step = 1;
                while (true)
                {

                    nextJump = index + step;
                    if (nextJump > terrain.Length - 1)
                    {
                        nextJump %= terrain.Length;
                    }

                    if (terrain[index] < terrain[nextJump])
                    {
                        jumpCounter++;
                        if (jumpCounter > maxjumps)
                        {
                            maxjumps = jumpCounter;
                        }
                        index = nextJump;
                    }
                    else
                    {
                        jumpCounter = 0;
                        step++;
                        index = i;
                        
                    }
                    if (step == terrain.Length)
                    {
                        break;
                    }

                }
            }
            Console.WriteLine(maxjumps);
        }
    }
}
