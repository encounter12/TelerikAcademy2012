using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace joro
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            string[] array = input.Split(',', ' ');
            int[] arrayNumbers = new int[array.Length];

            for (int i = 0; i < array.Length; i++)
            {
                try
                {
                    arrayNumbers[i] = int.Parse(array[i]);
                }
                catch(Exception)
                {
                    continue;
                }

            }

            bool first = false;
            bool second = false;

            for (int i = 0; i < arrayNumbers.Length; i++)
            {
                if (arrayNumbers[i] != 0)
                {
                    if (arrayNumbers[i] == 1 ^ arrayNumbers[i] == -2 ^ arrayNumbers[i] == -3 ^ arrayNumbers[i] == 4 ^ arrayNumbers[i] == -5 ^ arrayNumbers[i] == 6 ^ arrayNumbers[i] == -7 ^ arrayNumbers[i] == -8)
                    {
                        first = true;
                    }
                    else if (arrayNumbers[i] == 2 ^ arrayNumbers[i] == 3 ^ arrayNumbers[i] == 5 ^ arrayNumbers[i] == 7 ^ arrayNumbers[i] == 8 ^ arrayNumbers[i] == 9 ^ arrayNumbers[i] == 10)
                    {
                        second = true;
                        first = false;
                    }
                }
            }

            if (first == true)
            {
                Console.WriteLine(4);             
            }
            else if(second == true)
            {
                Console.WriteLine(11);    
            }

        }
    }
}
