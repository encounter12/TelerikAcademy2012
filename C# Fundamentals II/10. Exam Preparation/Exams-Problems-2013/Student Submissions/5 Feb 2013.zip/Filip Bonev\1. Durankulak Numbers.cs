using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Numerics;

class DurankulakNumbers
{
    static void Main()
    {
        string durankulakStyleNumber = Console.ReadLine();

        MatchCollection matches = Regex.Matches(durankulakStyleNumber, @"(?<big>[A-Z])|(?<small>[a-z][A-Z])");
        List<int> numbers = new List<int>();
        int groupTwo = 0;
        foreach (Match match in matches)
        {

            if (match.ToString() == match.Groups["big"].ToString())
            {
                numbers.Add((int)(char.Parse(match.ToString())) - 65);
            }
            else
            {
                MatchCollection matchesOne = Regex.Matches(match.ToString(), @"(?<small1>[a-z])|(?<smallBig>[A-Z])");
                foreach (Match matchOne in matchesOne)
                {
                    if (matchOne.ToString() == matchOne.Groups["smallBig"].ToString())
                    {

                        groupTwo += (int)(char.Parse(matchOne.ToString())) - 65;

                    }
                    else if (matchOne.ToString() == matchOne.Groups["small1"].ToString())
                    {

                        if (char.Parse(matchOne.ToString()) == 'a')
                        {
                            groupTwo += (int)(char.Parse(matchOne.ToString())) - 71;
                        }
                        else if (char.Parse(matchOne.ToString()) == 'b')
                        {
                            groupTwo += (int)(char.Parse(matchOne.ToString())) - 46;
                        }
                        else if (char.Parse(matchOne.ToString()) == 'c')
                        {
                            groupTwo += (int)(char.Parse(matchOne.ToString())) - 21;
                        }
                        else if (char.Parse(matchOne.ToString()) == 'd')
                        {
                            groupTwo += (int)(char.Parse(matchOne.ToString())) + 4;
                        }
                        else if (char.Parse(matchOne.ToString()) == 'e')
                        {
                            groupTwo += (int)(char.Parse(matchOne.ToString())) + 29;
                        }
                        else if (char.Parse(matchOne.ToString()) == 'f')
                        {
                            groupTwo += (int)(char.Parse(matchOne.ToString())) + 54;
                        }

                    }
                }
                numbers.Add(groupTwo);
                groupTwo = 0;
            }
        }
        BigInteger result = 0;
        int count = 0;
        for (int i = numbers.Count - 1; i >= 0; i--)
        {
            result += numbers[i] * (BigInteger)Math.Pow(168, count);
            count++;
        }
        Console.WriteLine(result);
    }
}