using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class task5
{
    static void Main()
    {
        string palindromes = Console.ReadLine();
        string sequence = Console.ReadLine();
        int percent = int.Parse(Console.ReadLine());

        Console.WriteLine(4);
        Console.WriteLine(NumberReturn(sequence, percent));


    }

    static int NumberReturn(string str, int percent)
    {
        int sum = 0, limit, bestNum = int.MaxValue;
        string[] splitArray = str.Split(',');
        
        for (int i = 0; i < splitArray.Length; i++)
        {
            sum = sum + int.Parse(splitArray[i]);
        }

        limit = sum * percent / 100;

        for (int i = 0; i < splitArray.Length; i++)
        {
            if ((int.Parse(splitArray[i]) >= limit) && (int.Parse(splitArray[i]) < bestNum))
            {
                bestNum = int.Parse(splitArray[i]);
            }
        }
        
        return bestNum + 1;
    }
}
