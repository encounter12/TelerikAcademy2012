using System;
using System.Linq;

    class JoroTheRabbit
    {
        static void Main()
        {
            string terrain = Console.ReadLine();
             char[] charSeparators = new char[] { ' ', ',' };
             string[] splitedArray = terrain.Split(charSeparators, StringSplitOptions.RemoveEmptyEntries);
            int counter = 0;
            int[] flow = splitedArray.Select(n => Convert.ToInt32(n)).ToArray();

            for (int i = 0; i < flow.Length - 1; i++)
            {
                if (flow[i] < flow[i + 1])
                {
                    counter++;
                }
            }
            Console.WriteLine(counter);
        }
    }
