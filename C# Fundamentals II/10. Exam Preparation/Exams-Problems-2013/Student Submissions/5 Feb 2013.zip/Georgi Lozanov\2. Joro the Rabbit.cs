using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace ConsoleApplication4
{
    class Program
    {
        static void Main()
        {
            string sizesStr = Console.ReadLine();
            string[] array = sizesStr.Split(',');
     
        
            int count = 2;
             
            int currentIndex = 0, currentLenght = 1;
            int maxIndex = 0; int maxLenght = 1;
            for (int i = 0; i < array.Length-1; i++)
            {
                if (i > 0 && array[i] != array[i+1])
                {
                    count++;
                }
                if (array[i] == array[i + 1])
                {
                    currentLenght++;
                }
                else
                {
                    if (maxLenght < currentLenght)
                    {
                        maxLenght = currentLenght;
                        maxIndex = currentIndex;
                        currentLenght = 1;
                    }  
                }
            }
            Console.WriteLine("{0}", count);
 
        }
    }
}