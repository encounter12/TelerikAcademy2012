using System;



    class DurankulakNumbers
    {
        static void Main()
        {
            string inputNumber = "aA";
            int result = 0;
            int digit = 0;
            int digitPlus = 0;
            int digitTotal = 0;
            int digitPos = -1;
            for (int i = inputNumber.Length - 1; i >= 0; i--)
            {
                if ((int)inputNumber[i] >= 'A' && (int)inputNumber[i] <= 'Z')
                {
                    digitPlus = 0;
                    switch (inputNumber[i])
                    {
                        case 'A': digit = 0; break;
                        case 'B': digit = 1; break;
                        case 'C': digit = 2; break;
                        case 'D': digit = 3; break;
                        case 'E': digit = 4; break;
                        case 'F': digit = 5; break;
                        case 'G': digit = 6; break;
                        case 'H': digit = 7; break;
                        case 'I': digit = 8; break;
                        case 'J': digit = 9; break;
                        case 'K': digit = 10; break;
                        case 'L': digit = 11; break;
                        case 'M': digit = 12; break;
                        case 'N': digit = 13; break;
                        case 'O': digit = 14; break;
                        case 'P': digit = 15; break;
                        case 'Q': digit = 16; break;
                        case 'R': digit = 17; break;
                        case 'S': digit = 18; break;
                        case 'T': digit = 19; break;
                        case 'U': digit = 20; break;
                        case 'V': digit = 21; break;
                        case 'W': digit = 22; break;
                        case 'X': digit = 23; break;
                        case 'Y': digit = 24; break;
                        case 'Z': digit = 25; break;
                    }
                    digitPos++;
                    
                }
                if ((int)inputNumber[i] >= 'a' && (int)inputNumber[i] <= 'z')
                {
                    digit = 0;
                    switch (inputNumber[i])
                    {
                        case 'a': digitPlus = 26; break;
                        case 'b': digitPlus = 52; break;
                        case 'c': digitPlus = 78; break;
                        case 'd': digitPlus = 104; break;
                        case 'e': digitPlus = 130; break;
                        case 'f': digitPlus = 156; break;
                    }
                }
                digitTotal = (int)(digit + digitPlus) * (int)Math.Pow(168, digitPos);
                result += digitTotal;
            }
            Console.WriteLine(result);
        }
    }

