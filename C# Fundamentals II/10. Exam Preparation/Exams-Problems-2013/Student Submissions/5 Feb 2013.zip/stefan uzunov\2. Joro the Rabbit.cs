using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.Rabbit
{
    class Program
    {
        static void Main(string[] args)
        {
            //string inpu = "1,-2,-3,4,-5,6,-7,-8";
            string[] input =
                Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

            int[] nums = ToInt(input);
            int length = nums.Length;
            

            int maxSeqLength = 1;
            int currentSeqLength = 1;
            int currentNumindex = 0;
            int nextindex;
            bool[] visited = new bool[length];

            for (int i = 0; i < length; i++)
            {
                
                

                 
                
                
                for (int jump = 1; jump <= length; jump++)
                {
                    currentSeqLength = 1;
                    visited = new bool[length];
                    visited[i] = true;
                    
                   
                    while (true)
                    {
                        nextindex =(currentNumindex +jump)%length;

                        if (!visited[nextindex] &
                            nums[nextindex]>nums[currentNumindex])
                        {
                            currentSeqLength++;
                            currentNumindex = nextindex;
                            visited[currentNumindex] = true;
                        }
                        else
                        {
                            currentNumindex = i; 
                            break;
                        }

                    }

                    if (currentSeqLength>maxSeqLength)
                    {
                        maxSeqLength = currentSeqLength;                        
                    }
                }
            }

            Console.Write(maxSeqLength);
            
        }

        private static int[] ToInt(string[] input)
        {
            int[] res = new int[input.Length];
            for (int i = 0; i < input.Length; i++)
            {
                res[i] = int.Parse(input[i]);
            }
            return res;
        }
    }
}
