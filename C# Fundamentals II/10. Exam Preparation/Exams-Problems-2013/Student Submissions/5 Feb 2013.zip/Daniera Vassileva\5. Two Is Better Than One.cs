using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Task_1
{
    class TwoBetterThanOne
    {
        static bool IsPalindrome(string value)
        {
            int min = 0;
            int max = value.Length - 1;

            while (true)
            {
                if (min > max)
                {
                    return true;
                }
                char a = value[min];
                char b = value[max];
                if (a != b)
                {
                    return false;
                }
                else if ((a != '3') && (a != '5'))
                {
                    return false;
                }

                min++;
                max--;
            }
        }

        static void Main(string[] args)
        {
            string numberRange =  Console.ReadLine();// "35 53"; 
            string numberList = Console.ReadLine();// "10,9,8,7,6,5,4,3,2,1"; // Console.WriteLine(Console.ReadLine());
            string str =  Console.ReadLine(); //39;            //Console.WriteLine(Console.ReadLine());
            int P = int.Parse(str);

            char[] separator = new char[] { ' ', ',' };
            string[] listOfNumbers = numberList.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            //foreach (var item in listOfNumbers)
            //{
            //    Console.WriteLine(item);
            //}
            int countNb = listOfNumbers.Length;
            string[] number = numberRange.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            BigInteger a = BigInteger.Parse(number[0]);
            BigInteger b = BigInteger.Parse(number[1]);
            BigInteger temp = 0;
            if (b < a)
            {
                temp = a;
                a = b;
                b = temp;
            }
            //Console.WriteLine(a);
            //Console.WriteLine(b);
            //Console.WriteLine(countNb);
            bool isPali = false;
            int countPali = 0;
            for (BigInteger i = a; i < b; i++)
            {
                isPali = IsPalindrome(i.ToString());
                if (isPali == true)
                {
                    countPali++;
                    isPali = false;
                    // Console.WriteLine(i);
                }
            }
            Console.WriteLine(countPali);


            //Second part
            double nbOfLowerEl = Math.Ceiling((double)(listOfNumbers.Length * P) / 100);
            //Console.WriteLine(nbOfLowerEl);
            Array.Sort(listOfNumbers);
            //foreach (var item in listOfNumbers)
            //{
            //    Console.Write(item + " ");
            //}
            Console.WriteLine(listOfNumbers[(int)nbOfLowerEl]);
        }
    }
}
