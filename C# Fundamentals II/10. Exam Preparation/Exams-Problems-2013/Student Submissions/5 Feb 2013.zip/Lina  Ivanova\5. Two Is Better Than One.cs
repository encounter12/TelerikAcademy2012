using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
       
        static ulong Palindrome(ulong i)
        {
            ulong pal = 0;
            if (i > 0)
            {
                pal = (pal * 10) + (i % 10);
                i = i / 10;
            }
            return pal;
        }
        static void Main(string[] args) 
        {
            string[] input = Console.ReadLine().Split(' ');
            ulong a = Convert.ToUInt64(input[0], 10);
            ulong b = Convert.ToUInt64(input[1], 10);
            string[] input1 = Console.ReadLine().Split(',');
            int[] numbers2 = new int[input1.Length];
            int counters = 0;
            int index = 0;
            for (int i = 0; i < numbers2.Length; i++)
            {
                numbers2[i] = int.Parse(input1[i]);
            }
            int p = int.Parse(Console.ReadLine());
            int counter = 0;
            string palindrome = String.Empty;
            StringBuilder Lucky = new StringBuilder();
             for (ulong i = a; i < b; i++)
             {
                 palindrome = i.ToString();
                 if (i == Palindrome(i))
                 {
                    
                     if ((i == 3)||(i == 5))
                     {
                         counter++;
                     }
                     else
                     foreach (var item in palindrome)
                     {
                         if ((item == '3')||(item == '5'))
                         {
                             counter++;
                         }
                     }
                 }
             }
             Console.WriteLine(counter);
             
             Array.Sort(numbers2);
             int smallest = numbers2[0];
             int maxCounter = 0;
             List<int> results = new List<int>();
             for (int i = 0; i < numbers2.Length; i++)
             {
                 smallest = numbers2[i];
                 for (int j = 0; j < numbers2.Length; j++)
                 {
                     if (smallest <= numbers2[j])
                     {
                         counters++;
                     }
                     if ((p * numbers2.Length) / 100 <= counters)
                     {
                         index = i;
                     }
                 }

             }
             Console.WriteLine(numbers2[index]);
        }
             
        }

    }
