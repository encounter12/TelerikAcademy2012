
    using System;
    using System.Linq;
 
    class HexToDec
    {
 
        public static void Main()
        {
          
            string myNumber = Console.ReadLine();
         
            Console.WriteLine(ConvertToType(myNumber, 16));
        }
       
        public static int ConvertToType(string myNumber, int type)
        {
            int size = myNumber.Length;
            int power = size - 1;
            int result = 0;
            int caseLetter = 0;
            for (int i = 0; i < size; i++)
            {
                switch (myNumber[i])
                {
                    case 'A': caseLetter = 0;
                        break;
                    case 'B': caseLetter = 1;
                        break;
                    case 'C': caseLetter = 2;
                        break;
                    case 'D': caseLetter = 3;
                        break;
                    case 'E': caseLetter = 4;
                        break;
                    case 'F': caseLetter = 5;
                        break;
                    case 'G': caseLetter = 6;
                        break;
                    case 'H': caseLetter = 7;
                        break;
                    case 'I': caseLetter = 8;
                        break;
                    case 'J': caseLetter = 9;
                        break;
                    case 'K': caseLetter = 10;
                        break;
                    case 'L': caseLetter = 11;
                        break;
                    case 'M': caseLetter = 12;
                        break;
                    case 'N': caseLetter = 13;
                        break;
                    case 'O': caseLetter = 14;
                        break;
                    case 'P': caseLetter = 15;
                        break;
                    case 'Q': caseLetter = 16;
                        break;
                    case 'R': caseLetter = 17;
                        break;
                    case 'S': caseLetter = 18;
                        break;
                    case 'T': caseLetter = 19;
                        break;
                    case 'U': caseLetter = 20;
                        break;
                    case 'V': caseLetter = 21;
                        break;
                    case 'W': caseLetter = 22;
                        break;
                    case 'X': caseLetter = 23;
                        break;
                    case 'Y': caseLetter = 24;
                        break;
                    case 'Z': caseLetter = 25;
                        break;
          
               
              

                    default: caseLetter = int.Parse(Convert.ToString(myNumber[i]));
                        break;
                }
                result = result + caseLetter * (int)(Math.Pow(type, power));
                power--;
            }
            return result;
        }
    }
