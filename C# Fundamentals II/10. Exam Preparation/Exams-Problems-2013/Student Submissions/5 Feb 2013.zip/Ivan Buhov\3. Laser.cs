using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Laser
{
    static void Main()
    {
        string[] dims = Console.ReadLine().Split(' ');
        int w = int.Parse(dims[0]);
        int h = int.Parse(dims[1]);
        int d = int.Parse(dims[2]);

        string[] pos = Console.ReadLine().Split(' ');
        Position laserPos = new Position(int.Parse(pos[0]) - 1, int.Parse(pos[1]) - 1, int.Parse(pos[2]) - 1);

        string[] dir = Console.ReadLine().Split(' ');
        Direction direction = new Direction(int.Parse(dir[0]), int.Parse(dir[1]), int.Parse(dir[2]));

        Cube cube = new Cube(w, h, d, laserPos, direction);
        Position last = cube.Laser();
        PrintPos(last);
    }

    public static void PrintPos(Position pos)
    {
        Console.WriteLine((pos.W + 1) + " " + (pos.H + 1) + " " + (pos.D + 1));
    }
}


public class Cube
{
    public bool[, ,] cube;
    public Position CurrentPosition;
    public Direction CurrentDirection;

    public Cube(int w, int h, int d, Position laserPos, Direction dir)
    {
        this.cube = new bool[w, h, d];
        this.CurrentPosition = laserPos;
        this.CurrentDirection = dir;
        this.cube[CurrentPosition.W, CurrentPosition.H, CurrentPosition.D] = true;
    }

    public Position Laser()
    {
        while (this.MakeStep())
        {
            
        }
        return CurrentPosition;
    }

    public bool MakeStep()
    {
        Position next = new Position(CurrentPosition.W + CurrentDirection.W, CurrentPosition.H + CurrentDirection.H, CurrentPosition.D + CurrentDirection.D);
        if (isEdge(next))
        {
            return false;
        }

        if (!isInTheCube(next))
        {
            this.ChangeDir();
            next = new Position(CurrentPosition.W + CurrentDirection.W, CurrentPosition.H + CurrentDirection.H, CurrentPosition.D + CurrentDirection.D);
        }

        if (isUsed(next))
        {
            return false;
        }

        this.cube[next.W, next.H, next.D] = true;
        this.CurrentPosition = next;
        return true;
        
    }

    private void ChangeDir()
    {
        if (CurrentPosition.W == 0 || CurrentPosition.W == cube.GetLength(0) - 1)
        {
            CurrentDirection.W = -CurrentDirection.W;
        }
        else if (CurrentPosition.H == 0 || CurrentPosition.H == cube.GetLength(1) - 1)
        {
            CurrentDirection.H = -CurrentDirection.H;
        }
        else if (CurrentPosition.D == 0 || CurrentPosition.D == cube.GetLength(2) - 1)
        {
            CurrentDirection.D = -CurrentDirection.D;
        }
        return;
    }

    public bool isUsed(Position pos)
    {
        if (this.cube[pos.W, pos.H, pos.D])
        {
            return true;
        }

        return false;
    }

    public bool isInTheCube(Position pos)
    {
        if (pos.W >= 0 && pos.W < cube.GetLength(0) && pos.H >= 0 && pos.H < cube.GetLength(1) && pos.D >= 0 && pos.D < cube.GetLength(2))
        {
            return true;
        }

        return false;
    }

    public bool isEdge(Position pos)
    {
        int ends = 0;
        if (pos.W == 0 || pos.W == this.cube.GetLength(0) - 1)
        {
            ends++;
        }

        if (pos.H == 0 || pos.H == this.cube.GetLength(1) - 1)
        {
            ends++;
        }

        if (pos.D == 0 || pos.D == this.cube.GetLength(2) - 1)
        {
            ends++;
        }

        if (ends > 1)
        {
            return true;
        }

        return false;
    }
}

public struct Direction
{
    public int W;
    public int H;
    public int D;

    public Direction(int w, int h, int d)
    {
        this.W = w;
        this.H = h;
        this.D = d;
    }
}

public struct Position
{
    public int W;
    public int H;
    public int D;

    public Position(int w, int h, int d)
    {
        this.W = w;
        this.H = h;
        this.D = d;
    }
}

