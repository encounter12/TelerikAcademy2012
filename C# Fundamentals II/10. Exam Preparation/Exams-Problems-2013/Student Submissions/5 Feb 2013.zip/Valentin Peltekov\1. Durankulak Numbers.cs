using System;
using System.Collections.Generic;
using System.Linq;

namespace Durankulak_Numbers
{
    class Program
    {
        static void Main()
        {
            string input = Console.ReadLine();

            System.Text.StringBuilder appendSpace = new System.Text.StringBuilder();

                foreach (Char C in input)
                {
                    if (Char.IsUpper(C))
                    {
                        appendSpace.Append(C);
                        appendSpace.Append(' ');
                    }
                    else
                    {
                        appendSpace.Append(C);
                    }
                }

                string inputWithSpaces = appendSpace.ToString();

                string[] inputSplitted = inputWithSpaces.Split(' ');

                Array.Reverse(inputSplitted);

                List<int> conversion = new List<int>();

                foreach (string element in inputSplitted)
                {
                    switch (element)
                    {
                        case "A": conversion.Add(0); break;
                        case "B": conversion.Add(1); break;
                        case "C": conversion.Add(2); break;
                        case "D": conversion.Add(3); break;
                        case "E": conversion.Add(4); break;
                        case "F": conversion.Add(5); break;
                        case "G": conversion.Add(6); break;
                        case "H": conversion.Add(7); break;
                        case "I": conversion.Add(8); break;
                        case "J": conversion.Add(9); break;
                        case "K": conversion.Add(10); break;
                        case "L": conversion.Add(11); break;
                        case "M": conversion.Add(12); break;
                        case "N": conversion.Add(13); break;
                        case "O": conversion.Add(14); break;
                        case "P": conversion.Add(15); break;
                        case "Q": conversion.Add(16); break;
                        case "R": conversion.Add(17); break;
                        case "S": conversion.Add(18); break;
                        case "T": conversion.Add(19); break;
                        case "U": conversion.Add(20); break;
                        case "V": conversion.Add(21); break;
                        case "W": conversion.Add(22); break;
                        case "X": conversion.Add(23); break;
                        case "Y": conversion.Add(24); break;
                        case "Z": conversion.Add(25); break;
                        case "aA": conversion.Add(26); break;
                        case "aB": conversion.Add(27); break;
                        case "aC": conversion.Add(28); break;
                        case "aD": conversion.Add(29); break;
                        case "aE": conversion.Add(30); break;
                        case "aF": conversion.Add(31); break;
                        case "aG": conversion.Add(32); break;
                        case "aH": conversion.Add(33); break;
                        case "aI": conversion.Add(34); break;
                        case "aJ": conversion.Add(35); break;
                        case "aK": conversion.Add(36); break;
                        case "aL": conversion.Add(37); break;
                        case "aM": conversion.Add(38); break;
                        case "aN": conversion.Add(39); break;
                        case "aO": conversion.Add(40); break;
                        case "aP": conversion.Add(41); break;
                        case "aQ": conversion.Add(42); break;
                        case "aR": conversion.Add(43); break;
                        case "aS": conversion.Add(44); break;
                        case "aT": conversion.Add(45); break;
                        case "aU": conversion.Add(46); break;
                        case "aV": conversion.Add(47); break;
                        case "aW": conversion.Add(48); break;
                        case "aX": conversion.Add(49); break;
                        case "aY": conversion.Add(50); break;
                        case "aZ": conversion.Add(51); break;
                        case "bA": conversion.Add(52); break;
                        case "bB": conversion.Add(53); break;
                        case "bC": conversion.Add(54); break;
                        case "bD": conversion.Add(55); break;
                        case "bE": conversion.Add(56); break;
                        case "bF": conversion.Add(57); break;
                        case "bG": conversion.Add(58); break;
                        case "bH": conversion.Add(59); break;
                        case "bI": conversion.Add(60); break;
                        case "bJ": conversion.Add(61); break;
                        case "bK": conversion.Add(62); break;
                        case "bL": conversion.Add(63); break;
                        case "bM": conversion.Add(64); break;
                        case "bN": conversion.Add(65); break;
                        case "bO": conversion.Add(66); break;
                        case "bP": conversion.Add(67); break;
                        case "bQ": conversion.Add(68); break;
                        case "bR": conversion.Add(69); break;
                        case "bS": conversion.Add(70); break;
                        case "bT": conversion.Add(71); break;
                        case "bU": conversion.Add(72); break;
                        case "bV": conversion.Add(73); break;
                        case "bW": conversion.Add(74); break;
                        case "bX": conversion.Add(75); break;
                        case "bY": conversion.Add(76); break;
                        case "bZ": conversion.Add(77); break;
                        case "cA": conversion.Add(78); break;
                        case "cB": conversion.Add(79); break;
                        case "cC": conversion.Add(80); break;
                        case "cD": conversion.Add(81); break;
                        case "cE": conversion.Add(82); break;
                        case "cF": conversion.Add(83); break;
                        case "cG": conversion.Add(84); break;
                        case "cH": conversion.Add(85); break;
                        case "cI": conversion.Add(86); break;
                        case "cJ": conversion.Add(87); break;
                        case "cK": conversion.Add(88); break;
                        case "cL": conversion.Add(89); break;
                        case "cM": conversion.Add(90); break;
                        case "cN": conversion.Add(91); break;
                        case "cO": conversion.Add(92); break;
                        case "cP": conversion.Add(93); break;
                        case "cQ": conversion.Add(94); break;
                        case "cR": conversion.Add(95); break;
                        case "cS": conversion.Add(96); break;
                        case "cT": conversion.Add(97); break;
                        case "cU": conversion.Add(98); break;
                        case "cV": conversion.Add(99); break;
                        case "cW": conversion.Add(100); break;
                        case "cX": conversion.Add(101); break;
                        case "cY": conversion.Add(102); break;
                        case "cZ": conversion.Add(103); break;
                        case "dA": conversion.Add(104); break;
                        case "dB": conversion.Add(105); break;
                        case "dC": conversion.Add(106); break;
                        case "dD": conversion.Add(107); break;
                        case "dE": conversion.Add(108); break;
                        case "dF": conversion.Add(109); break;
                        case "dG": conversion.Add(110); break;
                        case "dH": conversion.Add(111); break;
                        case "dI": conversion.Add(112); break;
                        case "dJ": conversion.Add(113); break;
                        case "dK": conversion.Add(114); break;
                        case "dL": conversion.Add(115); break;
                        case "dM": conversion.Add(116); break;
                        case "dN": conversion.Add(117); break;
                        case "dO": conversion.Add(118); break;
                        case "dP": conversion.Add(119); break;
                        case "dQ": conversion.Add(120); break;
                        case "dR": conversion.Add(121); break;
                        case "dS": conversion.Add(122); break;
                        case "dT": conversion.Add(123); break;
                        case "dU": conversion.Add(124); break;
                        case "dV": conversion.Add(125); break;
                        case "dW": conversion.Add(126); break;
                        case "dX": conversion.Add(127); break;
                        case "dY": conversion.Add(128); break;
                        case "dZ": conversion.Add(129); break;
                        case "eA": conversion.Add(130); break;
                        case "eB": conversion.Add(131); break;
                        case "eC": conversion.Add(132); break;
                        case "eD": conversion.Add(133); break;
                        case "eE": conversion.Add(134); break;
                        case "eF": conversion.Add(135); break;
                        case "eG": conversion.Add(136); break;
                        case "eH": conversion.Add(137); break;
                        case "eI": conversion.Add(138); break;
                        case "eJ": conversion.Add(139); break;
                        case "eK": conversion.Add(140); break;
                        case "eL": conversion.Add(141); break;
                        case "eM": conversion.Add(142); break;
                        case "eN": conversion.Add(143); break;
                        case "eO": conversion.Add(144); break;
                        case "eP": conversion.Add(145); break;
                        case "eQ": conversion.Add(146); break;
                        case "eR": conversion.Add(147); break;
                        case "eS": conversion.Add(148); break;
                        case "eT": conversion.Add(149); break;
                        case "eU": conversion.Add(150); break;
                        case "eV": conversion.Add(151); break;
                        case "eW": conversion.Add(152); break;
                        case "eX": conversion.Add(153); break;
                        case "eY": conversion.Add(154); break;
                        case "eZ": conversion.Add(155); break;
                        case "fA": conversion.Add(156); break;
                        case "fB": conversion.Add(157); break;
                        case "fC": conversion.Add(158); break;
                        case "fD": conversion.Add(159); break;
                        case "fE": conversion.Add(160); break;
                        case "fF": conversion.Add(161); break;
                        case "fG": conversion.Add(162); break;
                        case "fH": conversion.Add(163); break;
                        case "fI": conversion.Add(164); break;
                        case "fJ": conversion.Add(165); break;
                        case "fK": conversion.Add(166); break;
                        case "fL": conversion.Add(167); break;
                    }
                }

                long decimalNumber = 0;

                for (int i = 0; i < conversion.Count; i++)
                {
                    decimalNumber += conversion[i] * (long)Math.Pow(168, i);
                }

                Console.WriteLine(decimalNumber);

        }
    }
}
