using System;
using System.Numerics;

class Tasks
{

    static ulong[] ReturnNums(string nums, char separator)
    {
        string[] input = nums.Split(separator);
        ulong[] numbers = new ulong[input.Length];

        for (int i = 0; i < input.Length; i++)
        {
            numbers[i] = ulong.Parse(input[i]);
        }

        return numbers;
    }



    static int[] ReturnNumsSec(string nums, char separator)
    {
        string[] input = nums.Split(separator);
        int[] numbers = new int[input.Length];

        for (int i = 0; i < input.Length; i++)
        {
            numbers[i] = int.Parse(input[i]);
        }

        return numbers;
    }


    static bool IsLucky(ulong num)
    {
        if (num == 3 || num == 5)
        {
            return true;
        }
        bool isLucky = true;
        string numb = num.ToString();
        if (numb.Length % 2 == 0)
        {
            for (int i = 0; i < numb.Length / 2; i++)
            {
                if (numb[i] == '3' || numb[i] == '5')
                {
                    if (numb[i] != numb[(numb.Length - 1) - i])
                    {
                        isLucky = false;
                        break;
                    }
                }
                else
                {
                    isLucky = false;
                    break;
                }

            }
        }
        else
        {
            if ( numb[numb.Length / 2] == '3' || numb[numb.Length / 2] == '5')
            {

                for (int i = 0; i < numb.Length / 2; i++)
                {
                    if (numb[i] == '3' || numb[i] == '5')
                    {
                        if (numb[i] != numb[(numb.Length - 1) - i])
                        {
                            isLucky = false;
                            break;
                        }
                    }
                    else
                    {
                        isLucky = false;
                        break;
                    }

                }

            }
            else
            {
                isLucky = false;
            }
        }

        return isLucky;
    }





    static void Main()
    {
        ulong[] numbers = ReturnNums(Console.ReadLine(), ' ');
        ulong start = numbers[0];
        ulong end = numbers[1];
        int counter = 0;
        int[] secondNums = ReturnNumsSec(Console.ReadLine(), ',');
        
        int percent = int.Parse(Console.ReadLine());

        for (ulong i = start; i <= end; i++)
        {
            if (IsLucky(i))
            {
                counter++;

            }
        }
        //int[] nums = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };

        percent = (percent * secondNums.Length) / 100;

        int metaNum = 0;
        for (int i = 0; i < secondNums.Length - 1; i++)
        {

            for (int j = i + 1; j < secondNums.Length; j++)
            {
                if (secondNums[i] > secondNums[j])
                {
                    metaNum = secondNums[j];
                    secondNums[j] = secondNums[i];
                    secondNums[i] = metaNum;
                }


            }
        }
        
        Console.WriteLine(counter);
        Console.WriteLine(secondNums[percent]);

    }
}
