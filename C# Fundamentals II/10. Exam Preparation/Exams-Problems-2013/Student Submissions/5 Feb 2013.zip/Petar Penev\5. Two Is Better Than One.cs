using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FifthTask
{
    class Program
    {
        static void Main()
        {
            string number = Console.ReadLine();
            string numbers = Console.ReadLine();
            decimal percentage = decimal.Parse(Console.ReadLine())/100;
            string[] arr = number.Split(' ');
            long a = long.Parse(arr[0]), b = long.Parse(arr[1]);
            long count=0;
            for (long i=a;i<=b;i++)
            {
                bool check=true;
                StringBuilder str =new StringBuilder(i.ToString());
                for (int l=0;l<str.Length/2;l++)
                {
                    if ((str[l]!=str[str.Length-l-1])||((str[l]!='3')&&(str[l]!='5')))
                        check=false;
                    if (str.Length / 2 + 1 < str.Length)
                    {
                        if ((str[str.Length / 2 + 1] != '3') && (str[str.Length / 2 + 1] != '5'))
                            check = false;
                    }
                }
                if (str.Length==1)
                    if ((str[0]!='3') &&(str[0]!='5'))
                        check=false;
                if (check==true)
                    count++;
                if (str[str.Length-1]=='3')
                    i++;
                else if (str[str.Length-1]=='5')
                    i+=7;
            }
            string[] arr1 = numbers.Split(',');
            int[] array = new int[arr1.Length];
            for (int i = 0; i < arr1.Length; i++)
                array[i] = int.Parse(arr1[i]);
            Array.Sort(array);
            int position = (int)Math.Ceiling(array.Length * percentage)-1;
            Console.WriteLine(count);
            Console.WriteLine(array[position]);

        }
    }
}