using System;

class DurankulakNumbers
{
    static void Main()
    {
        string fullNumber = Console.ReadLine();
        char[] DurankulakNumbers = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
        ulong sum = 0;
        int index = 0;
        if (fullNumber.Length > 1)
        {
            for (int i = fullNumber.Length - 1; i >= 0 ; i--)
            {
                for (int j = 0; j < DurankulakNumbers.Length; j++)
                {
                    if (i != 0)
                    {
                        if (fullNumber[i - 1] == 'a')
                        {
                            if (fullNumber[i] == DurankulakNumbers[j])
                            {
                                sum = sum + (ulong)(Math.Pow(168, index)*(j + 26));
                                index++;
                            } 
                        }
                        else if (fullNumber[i - 1] == 'b')
                        {
                            if (fullNumber[i] == DurankulakNumbers[j])
                            {
                                sum = sum + (ulong)(Math.Pow(168, index)*(j + 52));
                                index++;
                            }
                        }
                        else if (fullNumber[i - 1] == 'c')
                        {
                            if (fullNumber[i] == DurankulakNumbers[j])
                            {
                                sum = sum + (ulong)(Math.Pow(168, index)*(j + 78));
                                index++;
                            }
                        }
                        else if (fullNumber[i - 1] == 'd')
                        {
                            if (fullNumber[i] == DurankulakNumbers[j])
                            {
                                sum = sum + (ulong)(Math.Pow(168, index)*(j + 104));
                                index++;
                            }
                        }
                        else if (fullNumber[i - 1] == 'e')
                        {
                            if (fullNumber[i] == DurankulakNumbers[j])
                            {
                                sum = sum + (ulong)(Math.Pow(168, index)*(j + 130));
                                index++;
                            }
                        }
                        else if (fullNumber[i - 1] == 'f')
                        {
                            if (fullNumber[i] == DurankulakNumbers[j])
                            {
                                sum = sum + (ulong)(Math.Pow(168, index)*(j + 156));
                                index++;
                            }
                        }
                        else
                        {
                            if (fullNumber[i] == DurankulakNumbers[j])
                            {
                                sum = sum + (ulong)(Math.Pow(168, index)*j);
                                index++;
                            }
                        }                          
                    }
                    else if (i == 0)
                    {
                        if (fullNumber[0] == DurankulakNumbers[j])
                        {
                            sum = sum + (ulong)( j * Math.Pow(168,index));
                        }
                    }
                }
            }
        }
        else if (fullNumber.Length == 1)
        {
            for (int j = 0; j < DurankulakNumbers.Length; j++)
            {
                if (fullNumber[0] == DurankulakNumbers[j])
                {
                    sum = sum + (ulong)j;
                }
            }
        }
        Console.WriteLine(sum);
    }
}