using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class TwoTasks
{
    static List<long> pols = new List<long>();
    static List<int> numbers = new List<int>();

    static void Main()
    {
        string[] tokens = Console.ReadLine().Split(' ');
        Generate(tokens[1].Length);

        string[] strNums = Console.ReadLine().Split(',');
        int percent = int.Parse(Console.ReadLine());
        for (int i = 0; i < strNums.Length; i++)
        {
            numbers.Add(int.Parse(strNums[i]));
        }

        numbers.Sort();
        int element = (int)Math.Ceiling((numbers.Count * percent) / 100.0) - 1;
        Console.WriteLine(PolsInInterval(long.Parse(tokens[0]), long.Parse(tokens[1])));
        Console.WriteLine(numbers[element]);
    }

    static int PolsInInterval(long A, long B)
    {
        int count = 0;
        for (int i = 0; i < pols.Count; i++)
        {
            if (pols[i] >= A && pols[i] <= B)
            {
                count++;
            }
        }
        return count;
    }

    private static void Generate(int digits)
    {
        Queue<StringBuilder> queue = new Queue<StringBuilder>(digits);
        queue.Enqueue(new StringBuilder("3"));
        queue.Enqueue(new StringBuilder("5"));
        for (int i = 1; i <= digits; i++)
        {
            int end = queue.Count;
            for (int j = 0; j < end; j++)
            {
                StringBuilder inter = queue.Dequeue();
                if (isPolindrome(inter))
                {
                    pols.Add(long.Parse(inter.ToString()));
                }
                StringBuilder first = new StringBuilder(inter.ToString());
                StringBuilder second = new StringBuilder(inter.ToString());
                first.Append('3');
                second.Append('5');
                queue.Enqueue(first);
                queue.Enqueue(second);
            }
        }
    }

    static bool isPolindrome(StringBuilder num)
    {
        for (int i = 0; i < num.Length / 2; i++)
        {
            if (num[i] != num[num.Length - 1 - i])
            {
                return false;
            }
        }
        return true;
    }
}
