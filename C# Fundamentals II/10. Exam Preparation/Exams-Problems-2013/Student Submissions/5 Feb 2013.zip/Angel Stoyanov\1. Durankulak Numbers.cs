using System;

class DurankulakNumbers
{
    static void Main(string[] args)
    {
        System.Numerics.BigInteger totalResult = new System.Numerics.BigInteger();
        totalResult = 0;

        System.Numerics.BigInteger tempValue = new System.Numerics.BigInteger();

        tempValue = 1;

        string inputLine = Console.ReadLine();

        char tempChar;

        char previousChar = ' ';

        int tempNumber = 0;

        int previousNumber = 1;

        //long totalResult = 0;

        int numbers = 0;

        for (int i = inputLine.Length - 1; i >= 0; i--)
        {
            tempChar= inputLine[i];

            if (tempChar >= 'A' && tempChar <= 'Z')
            {
                if (previousChar != ' ')
                {
                    if (numbers == 0)
                    {
                        totalResult += previousNumber;
                        
                    }
                    else
                    {
                        totalResult += tempValue * previousNumber;
                    }

                    ++numbers;

                    tempValue *= 168;
                }

                previousChar = tempChar;

                previousNumber = tempChar - 'A';

                continue;
            }

            if (tempChar >= 'a' && tempChar <= 'f')
            {
                tempNumber = (tempChar - 'a' + 1) * 26;

                tempNumber += previousNumber;

                totalResult += tempNumber * tempValue;

                previousChar = ' ';

                previousNumber = 0;

                ++numbers;

                tempValue *= 168;
            }
        }

        if (previousChar != ' ')
        {
            if (numbers == 0)
            {
                totalResult += previousNumber;
            }
            else
            {
                totalResult += tempValue * previousNumber;
            }
        }

        Console.WriteLine(totalResult);
    }
}
