using System;

namespace _1.DurankulakNumbers
{
    class Program
    {
        static void Main()
        {
            string[] NumeralSystem = new string[168];

            int index = 0;
            while (index < 26)
            {
                NumeralSystem[index] = ((char)('A' + index)).ToString();
                index++;
            }

            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 26 && index < 168; j++)
                {
                    NumeralSystem[index] = string.Concat(((char)('a' + i)).ToString(), ((char)('A' + j)).ToString());
                    index++;
                }
            }

            string durankulakRepresentation = Console.ReadLine();

            ulong powerBase = 1;
            ulong decimalRepresentation = 0;
            string current = string.Empty;
            for (int i = durankulakRepresentation.Length - 1; i >= 0; i--)
            {
                current = durankulakRepresentation[i].ToString();
                if (i > 0)
                {
                    if (char.IsLower(durankulakRepresentation[i - 1]))
                    {
                        current = string.Concat(durankulakRepresentation[i - 1], current);
                        i--;
                    }
                }
                
                decimalRepresentation = decimalRepresentation + (ulong)Array.IndexOf(NumeralSystem, current) * powerBase;

                powerBase *= 168;                
            }

            Console.WriteLine(decimalRepresentation);
        }
    }
}
