using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
 
namespace Darankulak
{
    class Program
    {
        static Dictionary<string, int> dictionary = new Dictionary<string, int>();
 
        static void Initialization()
        {
            for (int i = 'A'; i <= 'Z'; i++)
            {
                dictionary[((char)i).ToString()] = i - 'A';
            }
 
            int cnt = 26;
 
            for (int i = 'a'; i <= 'e'; i++)
            {
                for (int j = 'A'; j <= 'Z'; j++)
                {
                    dictionary[((char)i).ToString() + ((char)j).ToString()] = cnt;
                    cnt++;
                }
            }
 
            for (int i = 'A'; i <= 'L'; i++)
            {
                dictionary["f" + ((char)i).ToString()] = cnt++;
            }
        }
 
        static void Main(string[] args)
        {
            Initialization();
            string s = Console.ReadLine();
 
            //foreach (var item in dictionary)
            //{
            //  Console.WriteLine("{0} {1}", item.Key.ToString(), item.Value);
            //}
 
            List<string> digits = new List<string>();
 
            StringBuilder sb = new StringBuilder();
 
            foreach (char item in s)
            {
                sb.Append(item);
                if (char.IsUpper(item))
                {
                    digits.Add(sb.ToString());
                    sb.Clear();
                }
            }
 
            BigInteger number = new BigInteger();
            //long number = 0;
            //foreach (var item in digits)
            //{
            //  Console.WriteLine(item);
            //}
 
            //Console.WriteLine(dictionary[digits[0]]);
 
            for (int i = digits.Count - 1; i >= 0; i--)
            {
                number += dictionary[digits[i]] * BigInteger.Pow(168, digits.Count - i - 1);
                    //(int)Math.Pow(168, digits.Count - i - 1);
                //Console.WriteLine(dictionary[digits[i]]);
                //Console.WriteLine(dictionary[digits[i]] * (int)Math.Pow(168, digits.Count - i - 1));
            }
 
            Console.WriteLine(number);
        }
    }
}