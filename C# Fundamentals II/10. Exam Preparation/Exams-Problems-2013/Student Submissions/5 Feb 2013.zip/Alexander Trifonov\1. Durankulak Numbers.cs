using System;
using System.Collections.Generic;
using System.Numerics;

class Program
{
    static string capitalValues = "ABCDEFGHIGKLMNOPQRSTUVWXYZ";
    static int smallValues(char letter)
    {
        switch (letter)
        {
            case 'a': return 26;
            case 'b': return 52;
            case 'c': return 78;
            case 'd': return 104;
            case 'e': return 130;
            case 'f': return 156;
        }
        return 0;
    }
    static void Main()
    {
        string input = Console.ReadLine().Trim();
        BigInteger result = 0;
        List<string> inputToDigit = new List<string>();
        for (int i = 0; i < input.Length; i++)
		{
            if (Char.IsLower(input[i]))
            {
                string temp = input[i].ToString() + input[i + 1].ToString();
                inputToDigit.Add(temp);
                i++;
            }
            else
            {
                inputToDigit.Add(input[i].ToString());
            }
		}
        inputToDigit.Reverse();
        for (int i = 0; i < inputToDigit.Count; i++)
        {
            if (inputToDigit[i].Length > 1)
            {
                int num = smallValues(inputToDigit[i][0]) + capitalValues.IndexOf(inputToDigit[i][1]);
                if (i > 0)
                {
                    result += num * Powing(i);
                }
                else
                {
                    result += num;
                }
            }
            else
            {
                int num = capitalValues.IndexOf(inputToDigit[i]);
                if (i > 0)
                {
                    result += num * Powing(i);
                }
                else
                {
                    result += num;
                }
            }
        }
        Console.WriteLine(result);
    }

    static BigInteger Powing(int times)
    {
        BigInteger result = 168;
        for (int i = 1; i < times; i++)
        {
            result *= 168;
        }

        return result;
    }
}
