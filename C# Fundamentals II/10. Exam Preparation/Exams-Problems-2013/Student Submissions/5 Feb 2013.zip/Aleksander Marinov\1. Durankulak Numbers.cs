using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;

class Program
{
    static void Main()
    {

        Dictionary<string, int> dict = new Dictionary<string, int>(){
	    {"A", 0},
	    {"B", 1},
	    {"C", 2},
	    {"D", 3},
        {"E", 4},
	    {"F", 5},
	    {"G", 6},
	    {"H", 7},
        {"I", 8},
        {"j", 9},
	    {"K", 10},
	    {"L", 11},
	    {"M", 12},
        {"N", 13},
	    {"O", 14},
	    {"P", 15},
	    {"Q", 16},
        {"R", 17},
	    {"S", 18},
	    {"T", 19},
	    {"U", 20},
        {"V", 21},
	    {"W", 22},
	    {"X", 23},
	    {"Y", 24},
        {"Z", 25},
	};
        Dictionary<string, int> smallDict = new Dictionary<string, int>(){
	    {"a", 26},
	    {"b", 52},
	    {"c", 78},
	    {"d", 104},
        {"e", 130},
	    {"f", 156},};

        string input = Console.ReadLine();
        string nextChar;
        List<BigInteger> numbers = new List<BigInteger>();
        bool inNumber = false;
        StringBuilder builder = new StringBuilder();
        BigInteger temp = 0;
        foreach (var item in input)
        {
            nextChar = item.ToString();
            if (dict.ContainsKey(nextChar) && inNumber == false)
            {
                numbers.Add(dict[nextChar]);
            }
            else if (dict.ContainsKey(nextChar) && inNumber == true)
            {
                
                numbers.Add(temp+dict[nextChar]);
                
                inNumber = false;
            }
            else
            {
                if (smallDict.ContainsKey(nextChar))
                {
                    temp = smallDict[nextChar];
                    inNumber = true;
                }
                else
                {
                    Console.WriteLine(0);
                    return;
                }
                
                
            }
        }
        BigInteger result = 0;
        for (int i = numbers.Count-1, reverse = 0; i >=0 ; i--,reverse++)
        {
            if (i == numbers.Count-1)
            {
                result += numbers[i];
            }
            else
            {
                result += numbers[i] * (BigInteger)Math.Pow(168, reverse);
            }
        }
        Console.WriteLine(result);
    } 	 		 	 
}

