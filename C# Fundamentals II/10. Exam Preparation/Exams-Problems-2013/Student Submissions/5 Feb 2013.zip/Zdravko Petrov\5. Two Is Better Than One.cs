using System;
 
 
class TwoIsBetterThanOne
{
    static bool ContainsOnlyFiveAndThree(ulong number)
    {
        byte digit;
        ulong checkCurrentNumber = number;
        while (checkCurrentNumber>0)
        {
            digit = (byte)(checkCurrentNumber % 10);
            if (digit!=3&&digit!=5)
            {
                return false;
            }
            checkCurrentNumber /= 10;
        }
        return true;
    }
    static bool IsPalindrome(ulong number)
    {
 
        ulong n = number;
        byte digit;
        ulong reversed = 0;
        while (number > 0)
        {
            digit = (byte)(number % 10);
            reversed = reversed * 10 + (ulong)digit;
            number = number / 10;
        }
        if (n==reversed)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
     
 
    static void Main()
    {
        //first problem
        string[] tokens = Console.ReadLine().Split();
        ulong a = ulong.Parse(tokens[0]);
        ulong b = ulong.Parse(tokens[1]);
 
        int firstProblemSolutionPrint = 0;
        for (ulong i = a; i <= b; i++)
        {
            if (ContainsOnlyFiveAndThree(i) && IsPalindrome(i))
            {
                firstProblemSolutionPrint++;
            }
        }
 
        //second problem
        tokens = Console.ReadLine().Split(new char[] {','});
        int[] arrayWithInputNumbers = new int[tokens.Length];
        for (int i = 0; i < arrayWithInputNumbers.Length; i++)
        {
            arrayWithInputNumbers[i] = int.Parse(tokens[i]);
        }
        byte percentage = byte.Parse(Console.ReadLine());
        int percentageOfElementsAsNumber = (int)(((double)percentage / 100) * arrayWithInputNumbers.Length);
        Array.Sort(arrayWithInputNumbers);
 
        //print results
        Console.WriteLine(firstProblemSolutionPrint);
        Console.WriteLine(arrayWithInputNumbers[percentageOfElementsAsNumber]);
    }
}