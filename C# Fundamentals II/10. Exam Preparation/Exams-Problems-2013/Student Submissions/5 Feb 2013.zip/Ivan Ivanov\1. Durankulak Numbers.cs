using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Numerics;
using System.Text.RegularExpressions;

namespace task1_DuranNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            //Dictionary generator

            //Dictionary<int, string> dict = new Dictionary<int, string>();
            //int couter = 0;
            //for (int i = 1; i <= 7; i++)
            //{
            //    switch(i)
            //    {
            //        case (1):
            //            for (int j = 0; j <= 25; j++)
            //            {
            //                dict.Add(couter++, ((char)('A' + j)).ToString());
            //            }
            //            break;
            //        case (2):
            //            for (int j = 0; j <= 25; j++)
            //            {
            //                dict.Add(couter++, ("a" + (char)('A' + j)).ToString()); 
            //            }
            //            break;
            //        case (3):
            //            for (int j = 0; j <= 25; j++)
            //            {
            //                dict.Add(couter++, ("b" + (char)('A' + j)).ToString()); 
            //            }
            //            break;
            //        case (4):
            //            for (int j = 0; j <= 25; j++)
            //            {
            //                dict.Add(couter++, ("c" + (char)('A' + j)).ToString());
            //            }
            //            break;
            //        case (5):
            //            for (int j = 0; j <= 25; j++)
            //            {
            //                dict.Add(couter++, ("d" + (char)('A' + j)).ToString());
            //            }
            //            break;
            //        case (6):
            //            for (int j = 0; j <= 25; j++)
            //            {
            //                dict.Add(couter++, ("e" + (char)('A' + j)).ToString());
            //            }
            //            break;
            //        case (7):
            //            for (int j = 0; j <= 11; j++)
            //            {
            //                dict.Add(couter++, ("f" + (char)('A' + j)).ToString()); 
            //            }
            //            break;
            //    }
            //}
            Dictionary<string, int> dict = new Dictionary<string, int>();
            int couter = 0;
            for (int i = 1; i <= 7; i++)
            {
                switch (i)
                {
                    case (1):
                        for (int j = 0; j <= 25; j++)
                        {
                            dict.Add(((char)('A' + j)).ToString(), couter++);
                        }
                        break;
                    case (2):
                        for (int j = 0; j <= 25; j++)
                        {
                            dict.Add(("a" + (char)('A' + j)).ToString(), couter++);
                        }
                        break;
                    case (3):
                        for (int j = 0; j <= 25; j++)
                        {
                            dict.Add(("b" + (char)('A' + j)).ToString(), couter++);
                        }
                        break;
                    case (4):
                        for (int j = 0; j <= 25; j++)
                        {
                            dict.Add(("c" + (char)('A' + j)).ToString(), couter++);
                        }
                        break;
                    case (5):
                        for (int j = 0; j <= 25; j++)
                        {
                            dict.Add(("d" + (char)('A' + j)).ToString(), couter++);
                        }
                        break;
                    case (6):
                        for (int j = 0; j <= 25; j++)
                        {
                            dict.Add(("e" + (char)('A' + j)).ToString(), couter++);
                        }
                        break;
                    case (7):
                        for (int j = 0; j <= 11; j++)
                        {
                            dict.Add(("f" + (char)('A' + j)).ToString(), couter++);
                        }
                        break;
                }
            }
            //Input
            string durankulakNumber = Console.ReadLine();
            long result = 0;
            Regex regex = new Regex(@"[a-z][A-Z]|[A-Z]");
            MatchCollection matches = regex.Matches(durankulakNumber);
            string[] splitedNumber = new string[matches.Count];
            int index = 0;
            foreach (var item in matches)
            {
                splitedNumber[index++] = item.ToString();
            }
            BigInteger decimalRes = 0;
            int pow=0;
            BigInteger powerOf168 = 1;
            for (int i = splitedNumber.Length -1; i >=0; i--)
            {
                decimalRes += dict[splitedNumber[i]] * powerOf168;
                powerOf168 *= 168;
            }
            Console.WriteLine(decimalRes);
        }
    }
}
