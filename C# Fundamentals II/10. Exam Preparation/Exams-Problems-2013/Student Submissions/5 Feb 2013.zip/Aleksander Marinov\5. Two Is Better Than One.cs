using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Linq;
using System.Numerics;

class Program
{
    static void Main()
    {
        BigInteger start, end;
        string[] data = Console.ReadLine().Split();
        start = BigInteger.Parse(data[0]);
        end = BigInteger.Parse(data[1]);
        if (start > end)
        {
            start ^= end;
            end ^= start;
            start ^= end;
        }

        string num;


        BigInteger count = 0;

        bool isMatch = false;
        for (BigInteger i = start; i <= end; i++)
        {

            num = i.ToString();
            if (num.StartsWith("3") == false && !num.StartsWith("5"))
            {

            }
            if (num.StartsWith("3"))
            {
                isMatch = true;
                foreach (var item in num)
                {
                    if (item != '3')
                    {
                        isMatch = false;
                    }

                }
            }
            if (num.StartsWith("5"))
            {
                isMatch = true;
                foreach (var item in num)
                {
                    if (item != '5')
                    {
                        isMatch = false;
                    }

                }
            }
            if (isMatch == true)
            {
                count++;
                isMatch = false;
            }

        }

        //second part
        string[] numStr = Console.ReadLine().Split(new char[] { ',' }, StringSplitOptions.None);
        //string[] numStr = { "10", "9", "8", "7", "6", "5", "4", "3", "2", "1" };
        BigInteger[] nums = new BigInteger[numStr.Length];
        int inputPercent = int.Parse(Console.ReadLine());
        for (BigInteger i = 0; i < numStr.Length; i++)
        {
            nums[(int)i] = int.Parse(numStr[(int)i]);
        }
        Array.Sort(nums);

        BigInteger percent = 100 / nums.Length;

        BigInteger delPerc = inputPercent / percent;
        BigInteger element = (BigInteger)delPerc;
        //Console.WriteLine(element);
        //Console.WriteLine(delPerc);
        //print answer
        Console.WriteLine(count);
        if (element == delPerc)
        {
            element -= 1;
        }
        Console.WriteLine(nums[(int)element]);

    }

}

