using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;

namespace _1.DurankulakNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            Dictionary<string, byte> map = new Dictionary<string, byte>();
            byte index = 0;
            for (char i = 'A'; i <= 'Z'; i++)
            {
                map.Add(i.ToString(), index);
                index++;
            }

            for (char i = 'a'; i <= 'f'; i++)
            {
                for (char j = 'A'; j <= 'Z'; j++)
                {
                    map.Add(i.ToString() + j.ToString(), index);
                    index++;

                    if (i == 'f' && j == 'L')
                    {
                        break;
                    }
                }
            }

            BigInteger sum = 0;
            int count = 0;
            input = new string(input.Reverse().ToArray());
            for (int i = 0; i < input.Length; i++)
            {
                string num = "";
                if (i == input.Length - 1)
                {
                    num = input[i].ToString();
                }
                else
                {
                    num = input[i].ToString() + input[i + 1].ToString();
                }

                num = new string(num.Reverse().ToArray());
                if (!map.ContainsKey(num))
                {
                    num = input[i].ToString();
                }
                else
                {
                    i++;
                }

                sum += map[num] * (BigInteger)Math.Pow(168, count);
                count++;
            }

            if (input.Length == 1)
            {
                sum = map[input];
            }

            Console.WriteLine(sum);
        }
    }
}