using System;
using System.Text;

class TwoIsBetterThanOne
{
    public static bool isLuckyNumber(ulong number)
    {
        bool luckyNumber = true;

        luckyNumber = ContainsOnlyLuckyDigits(number);
        if (luckyNumber)
        {
            luckyNumber = isPalindrome(number);
        }
        return luckyNumber;
    }

    public static bool ContainsOnlyLuckyDigits(ulong number)
    {
        bool containsOnlyLD = true;
        string numberStr = number.ToString();
        foreach (var digit in numberStr)
        {
            if (digit != '3' && digit != '5')
            {
                containsOnlyLD = false;
                break;
            }
        }
        return containsOnlyLD;
    }

    public static bool isPalindrome(ulong number)
    {
        string toCheck = number.ToString(), reverse;
        char[] charArray = toCheck.ToCharArray();
        Array.Reverse(charArray);
        reverse = new string(charArray);

        return toCheck == reverse;
    }

    public static int SmallestValidElement(int[] list, int p)
    {
        int index = 0;
        Array.Sort(list);
        index = (int)Math.Ceiling(list.Length * p / 100.0) - 1;
        return list[index];
    }

    static void Main()
    {
        ulong a = 0, b = 0, count = 0;
        string input = string.Empty;
        string[] splitedInput;
        int[] list;
        int element = 0, p = 0;
        char[] splitters = { ' ' };
        char[] splitList = { ',' };

        input = Console.ReadLine();
        splitedInput = input.Split(splitters, StringSplitOptions.RemoveEmptyEntries);
        a = UInt64.Parse(splitedInput[0]);
        b = UInt64.Parse(splitedInput[1]);

        if (a % 2 == 0)
        {
            a += 1;
        }
        for (ulong i = a; i <= b; i+=2)
        {
            if (isLuckyNumber(i))
            {
                count++;
            }
        }

        input = Console.ReadLine();
        splitedInput = input.Split(splitList, StringSplitOptions.RemoveEmptyEntries);
        list = new int[splitedInput.Length];
        for (int i = 0; i < splitedInput.Length; i++)
        {
            list[i] = Int32.Parse(splitedInput[i]);
        }
        p = Int32.Parse(Console.ReadLine());

        element = SmallestValidElement(list, p);

        Console.WriteLine(count);
        Console.WriteLine(element);
    }
}