using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();            
            int result = 0;

            for (int i = 0, j = 0; i < input.Length; i++, j++)
            {
                if (j > 16)
                {
                    break;
                }
                int valueHigh = 0;
                int valueLow = 0;
                if (input[i] > 96)
                {
                    valueLow = 156 - ('f' - input[i]) * 26;                 
                }
                else
                {                    
                    if (i != input.Length - 1)
                    {
                        valueHigh = (168 * (input[i] - 'A'));
                    }
                    else
                    {
                        valueHigh = input[i] - 'A';
                    }

                }                
                result += valueHigh + valueLow;
            }
            Console.WriteLine(result);
        }
    }
}
