using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        string input = Console.ReadLine();//"1, 1, 1";//"1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0";//"1, -2, -3, 4, -5, 6 , -7, -8";//
        string[] arrS = input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
        int[] arr = new int[arrS.Length];

        for (int i = 0; i < arr.Length; i++)
        {
            arr[i] = int.Parse(arrS[i]);
        }
        List<int> listF = arr.ToList();
        int temp = 1;
        int sum = 1;

        List<int> listV = new List<int>();

        listV.Add(int.MinValue);

        bool helper = true;
        int counterH = 0;
        for (int p = 0; p < listF.Count; p++)
        {
            for (int s = 0; s < listF.Count; s++)
            {
                
                for (int t = p; t < 2 * listF.Count; t = t + s)
                {
                    if (t >= listF.Count)
                    {
                        t = t % listF.Count;
                    }
                    if ((listV[listV.Count - 1] < listF[t]))
                    {
                        temp++;
                        if (temp > sum)
                        {
                            sum = temp;
                        }
                    }
                    else
                    {
                        break;
                    }
                    listV.Add(listF[t]);
                }
            }
           
        }
            Console.WriteLine(sum);
    }
}
