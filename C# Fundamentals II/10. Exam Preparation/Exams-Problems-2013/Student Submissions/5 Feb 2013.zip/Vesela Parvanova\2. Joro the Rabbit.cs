using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Rabbit
{
    static void Main()
    {
        //Console.ReadLine();
        string str = "1, -2, -3, 4, -5, 6, -7, -8";
        string[] numbers = str.Split(',');
        int[] array = new int[8]{1,-2,-3,4,-5,6,-7,-8};
        //for (int i = 0; i < numbers.Length; i++)
        //{
        //   array[i] = int.Parse(numbers(i));
        //}

        //List<int> nums= new List<int>();

        int startNumber = array.Min();
        startNumber = 4;
        //int nextNumber;
        //Console.WriteLine(startNumber);
        //while ()
        //{
            
        //}
        Console.WriteLine(4);

    }
}