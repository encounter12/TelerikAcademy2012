using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoroTheRabbit
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Enter some numbers between -1000 and 1000:");
            //int input = {1, 5, -7, 9, -19, 22, -33};
            string numbers = Console.ReadLine();
            string[] arr2 = numbers.Split(' ', ',');
            //int[] arr = int.Parse(arr2);
            for (int i = 0; i < arr2.Length; i++)
            {
                Console.Write(arr2[i] + "-");
            }
        }
    }
}
