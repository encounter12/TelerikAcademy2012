using System;

class Program
{
    static int[,,] cube;
    static int width;
    static int height;
    static int depth;
    static int resultW = 0;
    static int resultH = 0;
    static int resultD = 0;
    static void Blaster(int lw, int lh, int ld, int dw, int dh, int dd)
    {
        if ((lw >= width - 1) || (lw <= 0))
        {
            dw *= -1;
        }
        if ((lh >= height - 1) || (lh <= 0))
        {
            dh *= -1;
        }
        if ((ld >= depth - 1) || (ld <= 0))
        {
            dd *= -1;
        }
        if (cube[lw, lh, ld] == 1)
        {
            resultW = lw;
            resultH = lh;
            resultD = ld;
            return;
        }
        

        cube[lw, lh, ld] = 1;
        Blaster(lw + dw, lh + dh, ld + dd, dw, dh, dd);
    }
    static void Main()
    {
        string[] temp = Console.ReadLine().Split(' ');
        width = int.Parse(temp[0]);
        height = int.Parse(temp[1]);
        depth = int.Parse(temp[2]);
        string[] lastemp = Console.ReadLine().Split(' ');
        int lasWidth = int.Parse(lastemp[0]);
        int lasHeight = int.Parse(lastemp[1]);
        int lasDepth = int.Parse(lastemp[2]);
        string[] dirtemp = Console.ReadLine().Split(' ');
        int dirWidth = int.Parse(dirtemp[0]);
        int dirHeight = int.Parse(dirtemp[1]);
        int dirDepth = int.Parse(dirtemp[2]);
        cube = new int[width, height, depth];
        for (int w = 0; w < width; w++)
        {
            cube[w, 0, 0] = 1;
            cube[w, height - 1, 0] = 1;

            cube[w, 0, depth - 1] = 1;
            cube[w, height - 1, depth - 1] = 1;
        }

        for (int h = 0; h < height; h++)
        {
            cube[0, h, 0] = 1;
            cube[width - 1, h, 0] = 1;

            cube[0, h, depth - 1] = 1;
            cube[width - 1, h, depth - 1] = 1;
        }

        for (int d = 0; d < depth; d++)
        {
            cube[0, 0, d] = 1;
            cube[0, height - 1, d] = 1;

            cube[width - 1, 0, d] = 1;
            cube[width - 1, height - 1, d] = 1;
        }
       
        Blaster(lasWidth, lasHeight, lasDepth, dirWidth, dirHeight, dirDepth);
        Console.WriteLine("{0} {1} {2}", resultW, resultH, resultD);
    }
}
