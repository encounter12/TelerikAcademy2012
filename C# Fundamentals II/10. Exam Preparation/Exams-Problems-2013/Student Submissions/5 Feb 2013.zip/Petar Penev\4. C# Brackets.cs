using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FourthTask
{
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            //int n = 5;
            string indent = Console.ReadLine();
            //string indent = "....";
            string[] array = new string[n];
            for (int i = 0; i < n; i++)
                array[i] = Console.ReadLine();
            /*string[] array = new string[] { "using System;  namespace Stars",
            "{class Program{",
            "static string[] separators",
            "= new string[] { \" \"};}",
            "}"};*/
            int numberIndents = 0;
            bool isNewLine = false;
            for (int i = 0; i < n; i++)
            {                
                string line = array[i];
                StringBuilder lineNew = new StringBuilder();
                bool isSpace = false;
                bool isWrittenMeaningful=false;
                if ((!isNewLine) && (i != 0))
                {
                    if (lineNew[lineNew.Length - 1] == ' ')
                        lineNew.Remove(lineNew.Length - 1, 1);
                    Console.WriteLine(lineNew);
                    lineNew.Clear();
                }
                for (int j = 0; j < line.Length; j++)
                {
                    if (isNewLine)
                    {
                        if (line[j] == '}') numberIndents--;
                        for (int m = 0; m < numberIndents; m++)
                            lineNew.Append(indent);
                        isNewLine = false;
                    }
                    /*if ((isNewLine)&&(i!=0))
                    {
                        isNewLine = false;
                        for (int m = 0; m < numberIndents; m++)
                            Console.Write(indent);
                    }*/
                    if (line[j] == '{')
                    {
                        if (isWrittenMeaningful)
                        {
                            if (lineNew[lineNew.Length - 1] == ' ')
                                lineNew.Remove(lineNew.Length - 1, 1);
                            Console.WriteLine(lineNew);
                            lineNew.Clear();
                            for (int m = 0; m < numberIndents; m++)
                                lineNew.Append(indent);
                            if (j != line.Length - 1)
                                Console.WriteLine(lineNew.Append(line[j]));
                            else
                                Console.WriteLine(lineNew.Append(line[j]));
                            numberIndents++;
                            isWrittenMeaningful = false;
                            isNewLine = true;
                            lineNew.Clear();
                            continue;
                        }
                        else
                        {
                            if ((lineNew.Length!=0)&&(lineNew[lineNew.Length - 1] == ' '))
                                lineNew.Remove(lineNew.Length - 1, 1);
                            lineNew.Append(line[j]);
                            Console.WriteLine(lineNew);
                            lineNew.Clear();
                            numberIndents++;
                            isNewLine = true;
                            isWrittenMeaningful = false;
                            continue;
                        }
                    }
                    else if (line[j]=='}')
                    {
                        if (isWrittenMeaningful)
                        {
                            if ((lineNew.Length != 0) && (lineNew[lineNew.Length - 1] == ' '))
                                lineNew.Remove(lineNew.Length - 1, 1);
                            Console.WriteLine(lineNew);
                            lineNew.Clear();
                            numberIndents--;
                            for (int m = 0; m < numberIndents; m++)
                                lineNew.Append(indent);
                            lineNew.Append(line[j]);
                            if ((lineNew.Length != 0) && (lineNew[lineNew.Length - 1] == ' '))
                                lineNew.Remove(lineNew.Length - 1, 1);
                            Console.WriteLine(lineNew);
                            isWrittenMeaningful = false;
                            isNewLine = true;
                            lineNew.Clear();
                            continue;
                        }
                        else
                        {
                            lineNew.Append(line[j]);
                            if ((lineNew.Length != 0) && (lineNew[lineNew.Length - 1] == ' '))
                                lineNew.Remove(lineNew.Length - 1, 1);
                            Console.WriteLine(lineNew);
                            numberIndents--;
                            lineNew.Clear();
                            isNewLine = true;
                            continue;
                        }
                    }
                    else
                    {
                        if (line[j] != ' ')
                        {

                            lineNew.Append(line[j]);
                            isWrittenMeaningful = true;
                            isSpace = false;
                        }
                        else
                        {
                            if (isSpace)
                            {
                                if (j == line.Length - 1)
                                {
                                    isNewLine = true;
                                    if ((lineNew.Length != 0) && (lineNew[lineNew.Length - 1] == ' '))
                                        lineNew.Remove(lineNew.Length - 1, 1);
                                    Console.WriteLine(lineNew);
                                    lineNew.Clear();
                                }
                                continue;
                            }
                            else
                            {
                                isSpace = true;
                                if ((lineNew.Length != 0) && (lineNew[lineNew.Length - 1] == ' '))
                                    lineNew.Remove(lineNew.Length - 1, 1);
                                lineNew.Append(line[j]);
                            }
                            if (j==line.Length-1)
                            {
                                isNewLine=true;
                                if ((lineNew.Length != 0) && (lineNew[lineNew.Length - 1] == ' '))
                                    lineNew.Remove(lineNew.Length - 1, 1);
                                Console.WriteLine(lineNew);
                                lineNew.Clear();
                            }
                        }
                        if (j == line.Length - 1)
                        {
                            isNewLine = true;
                            if ((lineNew.Length != 0) && (lineNew[lineNew.Length - 1] == ' '))
                                lineNew.Remove(lineNew.Length - 1, 1);
                            Console.WriteLine(lineNew);
                            lineNew.Clear();
                        }
                    }


                }
            }
        }
    }
}
