using System;
using System.Collections.Generic;

class JoroTheRabbit
{
    static void Main()
    {
        List<int> used = new List<int>();
        char[] separators = { ',', ' ' };
        string[] str = Console.ReadLine().Split(separators, StringSplitOptions.RemoveEmptyEntries);
        int[] input = new int[str.Length * str.Length];
        int fillCounter = 0;
        for (int i = 0; i < input.Length; i++)
        {
            input[i] = int.Parse(str[fillCounter]);
            fillCounter++;
            if (fillCounter == str.Length)
            {
                fillCounter = 0;
            }
        }

        bool isPath = true;
        int walk = 0;
        int maxWalk = 1;
        int counter = 0;

        for (int start = 0; start < str.Length; start++)
        {
            for (int jump = 0; jump < str.Length; jump++)
            {
                isPath = true;
                counter = start;
                while (isPath && walk < str.Length)
                {
                    if (!used.Contains(input[counter]))
                    {
                        if (input[counter] < input[counter + jump])
                        {
                            walk++;
                            used.Add(input[counter]);
                            counter = counter + jump;
                        }
                        else
                        {
                            isPath = false;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
                if (walk > maxWalk)
                {
                    maxWalk = walk;
                    walk = 1;
                    counter = start;
                    used.Clear();
                }
            }
        }
        Console.WriteLine(maxWalk);
    }
}