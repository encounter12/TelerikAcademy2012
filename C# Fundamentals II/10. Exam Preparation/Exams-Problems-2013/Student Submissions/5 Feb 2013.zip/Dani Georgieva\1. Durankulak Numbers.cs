using System;
using System.Numerics;
using System.Collections.Generic;
 
class DurankulakNumbers
{
    static void Main()
    {
        string[] letters = new string[168];
        FillArray(letters);
        string input = Console.ReadLine();      
        List<string> number = new List<string>();
        SplitInputToNumbers(input, number);
        number.Reverse();
        BigInteger temp = 0;
        BigInteger result = 0;
        for (int i = 0; i < number.Count; i++)
        {
            for (int j = 0; j < letters.Length; j++)
            {
                if (letters[j] == number[i])
                {
                    temp = j;
                }
            }
            if (i == 0)
            {
                result = result + temp;
            }
            else
            {
                for (int power = 0; power < i; power++)
                {
                    temp = temp * 168;
                }
                result = result + temp;
            }
        }
        Console.WriteLine(result);
    }
 
 
    private static void SplitInputToNumbers(string input, List<string> number)
    {
        char[] symbols = input.ToCharArray();
        string temp = string.Empty;
        for (int i = 0; i < symbols.Length; i++)
        {
            if (symbols[i] >= 65 && symbols[i] <= 90)
            {
                temp = symbols[i].ToString();
                number.Add(temp);
            }
            else
            {
                temp = symbols[i].ToString() + symbols[i + 1].ToString();
                number.Add(temp);
                i++;
            }
        }
    }
 
    private static void FillArray(string[] letters)
    {
        char temp = 'A';
        for (int i = 0; i <= 25; i++)
        {
            temp = (char)(i + 65);
            letters[i] = temp.ToString();
        }
 
        temp = 'A';
        for (int i = 26; i <= 51; i++)
        {
            letters[i] = "a" + temp.ToString();
            temp++;
        }
 
        temp = 'A';
        for (int i = 52; i <= 77; i++)
        {
            letters[i] = "b" + temp.ToString();
            temp++;
        }
 
        temp = 'A';
        for (int i = 78; i <= 103; i++)
        {
            letters[i] = "c" + temp.ToString();
            temp++;
        }
 
        temp = 'A';
        for (int i = 104; i <= 129; i++)
        {
            letters[i] = "d" + temp.ToString();
            temp++;
        }
 
        temp = 'A';
        for (int i = 130; i <= 155; i++)
        {
            letters[i] = "e" + temp.ToString();
            temp++;
        }
 
        temp = 'A';
        for (int i = 156; i <= 167; i++)
        {
            letters[i] = "f" + temp.ToString();
            temp++;
        }
    }
}