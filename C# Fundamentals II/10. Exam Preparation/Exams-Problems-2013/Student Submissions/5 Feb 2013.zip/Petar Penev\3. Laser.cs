using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThirdTask
{
    class Program
    {
        static void Main()
        {
            string[] dimensions = Console.ReadLine().Split(' ');
            int w = int.Parse(dimensions[0]), h = int.Parse(dimensions[1]), d = int.Parse(dimensions[2]);
            bool[, ,] visited = new bool[w, h, d];
            string[] start = Console.ReadLine().Split(' ');
            int currentW = int.Parse(start[0])-1, currentH = int.Parse(start[1])-1, currentD = int.Parse(start[2])-1;
            string[] vector = Console.ReadLine().Split(' ');
            int vectorW = int.Parse(vector[0]), vectorH = int.Parse(vector[1]), vectorD = int.Parse(vector[2]);
            visited[currentW,currentH,currentD]=true;
            for (int i=0;i<w;i++)
                visited[i,0,0]=true;
            for (int i=0;i<w;i++)
                visited[i,h-1,0]=true;
            for (int i=0;i<h;i++)
                visited[0,i,0]=true;
            for (int i=0;i<h;i++)
                visited[w-1,i,0]=true;
            for (int i=0;i<d;i++)
                visited[0,h-1,i]=true;
            for (int i=0;i<d;i++)
                visited[0,0,i]=true;
            for (int i=0;i<d;i++)
                visited[w-1,0,i]=true;
            for (int i=0;i<d;i++)
                visited[w-1,h-1,i]=true;
            for (int i=0;i<h;i++)
                visited[w-1,i,d-1]=true;
            for (int i=0;i<h;i++)
                visited[0,i,d-1]=true;
            for (int i=0;i<w;i++)
                visited[i,0,d-1]=true;
            for (int i=0;i<w;i++)
                visited[i,h-1,d-1]=true;
            while (true)
            {
                if (IsOutsideArray(currentW+vectorW,currentH+vectorH,currentD+vectorD,w,h,d))
                {
                    if ((currentW==0) || (currentW==w-1))
                        vectorW=-vectorW;
                    else if ((currentH==0) || (currentH==h-1))
                        vectorH=-vectorH;
                    else if ((currentD==0) || (currentD==d-1))
                        vectorD=-vectorD;
                }
                if (visited[currentW+vectorW,currentH+vectorH,currentD+vectorD]==true)
                    break;
                currentW+=vectorW;
                currentH+=vectorH;
                currentD+=vectorD;
                visited[currentW,currentH,currentD]=true;
            }
            Console.WriteLine("{0} {1} {2}", currentW+1,currentH+1,currentD+1);
        }

        static bool IsOutsideArray(int curW, int curH, int curD, int w, int h, int d)
        {
            return !((0 <= curW) && (curW < w) && (0 <= curH) && (curH < h) && (0 <= curD) && (curD < d));
        }
    }
}