using System;

class Laser
{
    static void Main()
    {
        string[] firstLine = Console.ReadLine().Split(' ');
        int width = int.Parse(firstLine[0]);
        int heght = int.Parse(firstLine[1]);
        int depth = int.Parse(firstLine[2]);
        string[] secondLine = Console.ReadLine().Split(' ');
        int startW = int.Parse(secondLine[0]);
        int startH = int.Parse(secondLine[1]);
        int startD = int.Parse(secondLine[2]);
        string[] thirdLine = Console.ReadLine().Split(' ');
        int dirW = int.Parse(thirdLine[0]);
        int dirH = int.Parse(thirdLine[1]);
        int dirD = int.Parse(thirdLine[2]);

        int[, ,] cube = new int[width, heght, depth];
        cube[0, 0, 0] = 1;
        cube[width - 1, 0, 0] = 1;
        cube[0, 0, depth - 1] = 1;
        cube[0, heght - 1, 0] = 1;
        cube[width - 1, heght - 1, 0] = 1;
        cube[width - 1, 0, depth - 1] = 1;
        cube[0, heght - 1, depth - 1] = 1;
        cube[width - 1, heght - 1, depth - 1] = 1;

        int curPosW = startW - 1, curPosH = startH - 1, curPosD = startD - 1;
        while (true)
        {
            if (cube[curPosW, curPosH, curPosD] == 1)
            {
                break;
            }
            else
            {
                if (curPosW == width - 1)
                {
                    dirW = -1;
                }
                else if (curPosW == 0)
                {
                    dirW = 1;
                }

                if (curPosH == heght - 1)
                {
                    dirH = -1;
                }
                else if (curPosH == 0)
                {
                    dirH = 1;
                }

                if (curPosD == depth - 1)
                {
                    dirD = -1;
                }
                else if (curPosD == 0)
                {
                    dirD = 1;
                }

                if (cube[curPosW + dirW, curPosH + dirH, curPosD + dirD] == 1)
                {
                    break;
                }
                else
                {
                    cube[curPosW, curPosH, curPosD] = 1;
                    curPosW += dirW;
                    curPosH += dirH;
                    curPosD += dirD;
                }
            }
        }

        Console.WriteLine("{0} {1} {2}", curPosW + 1, curPosH + 1, curPosD + 1);
    }
}