using System;
using System.Text;

class Program
{
    public static bool hasSpace = false;
    public static bool closedBracket = false;
    public static bool newLine = false;
    public static bool firstLine = true;

    static void Main(string[] args)
    {
        char nextChar = '.';
        int numberOfLines = int.Parse(Console.ReadLine());
        string delimiter = Console.ReadLine();
        StringBuilder allDelimiters = new StringBuilder();
        allDelimiters.Append("");
        bool newLineNext = false;
        char currentChar;
        for (int i = 0; i < numberOfLines; i++)
        {
            if (i == 0)
            {
                firstLine = true;
            }
            else
            {
                firstLine = false;
            }
            string currentLine = Console.ReadLine();
            if (i!=0)
            {
                newLine = true;                
            }
            for (int j = 0; j < currentLine.Length; j++)
            {
                if (j < currentLine.Length - 1)
                {
                    nextChar = currentLine[j + 1];
                }
                if (j == currentLine.Length - 1)
                {
                    newLineNext = true;
                }
                else
                {
                    newLineNext = false;
                }
                currentChar = currentLine[j];
                if (currentChar == '{')
                {
                    if (firstLine)
                    {
                        Console.Write(currentChar);
                        allDelimiters.Append(delimiter);
                        firstLine = false;
                        newLine = true;
                    }
                    else
                    {
                        Console.Write("\n{0}{1}", allDelimiters, currentChar);
                        allDelimiters.Append(delimiter);
                        newLine = true;
                    }
                }
                else if (currentChar == '}')
                {
                    allDelimiters.Remove(0, delimiter.Length);
                    Console.Write("\n{0}{1}", allDelimiters, currentChar);
                    newLine = true;
                }
                else
                {
                    if (currentChar == ' ')
                    {
                        if (nextChar == '{' || hasSpace || newLineNext || newLine)
                        {
                        }
                        else if (!hasSpace)
                        {
                            hasSpace = true;
                            if (newLine)
                            {
                                Console.Write("\n{0}",allDelimiters);
                                newLine = false;
                            }
                            Console.Write(currentChar);
                        }
                    }

                    //if (currentChar == ' ' && nextChar == '{')
                    //{
                    //}

                    //if (currentChar == ' ' && !hasSpace)
                    //{
                    //    hasSpace = true;
                    //    if (newLine)
                    //    {
                    //        Console.Write(allDelimiters);
                    //        newLine = false;
                    //    }
                    //    Console.Write(currentChar);
                    //}
                    //else if (currentChar == ' ' && hasSpace)
                    //{
                    //}
                    else if (currentChar != ' ')
                    {
                        hasSpace = false;
                        if (newLine)
                        {
                            Console.Write("\n{0}", allDelimiters);
                            newLine = false;
                        }
                        Console.Write(currentChar);
                    }
                }
                if (allDelimiters.Length == 0)
                {
                    firstLine = true;
                }
            }
        }
    }
}