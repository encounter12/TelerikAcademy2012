using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

class TwoIsBetterThanOne
{
    static void Main()
    {
        string inputFirstTast = Console.ReadLine();
        string[] strInter = inputFirstTast.Split(' ');
        BigInteger a = BigInteger.Parse(strInter[0]);
        BigInteger b = BigInteger.Parse(strInter[1]);


        string inputSecondTask = Console.ReadLine();
        string[] strList = inputSecondTask.Split(',');
        List<int> list = new List<int>();
        foreach (string el in strList)
        {
            list.Add(int.Parse(el));
        }
        string strPer = Console.ReadLine();
        decimal perc = decimal.Parse(strPer);

        ///first task
        ///
        BigInteger count = 0;
        for (BigInteger number = a; number <= b; number++)
        {
            BigInteger currNum = number;
            while ((currNum%10==3)||(currNum%10==5))
            {
                currNum = currNum / 10;
            }
            if (currNum==0)
            {
                string currWord = number.ToString();
                int start = 0;
                int end = currWord.Length - 1;
                bool isPalin = true;
                while (start < end)
                {
                    if (currWord[start] != currWord[end])
                    {
                        isPalin = false;
                        break;
                    }
                    start++;
                    end--;
                }
                if (isPalin)
                {
                    count++;
                        if ((number % 555 == 0)&&(number/555)==0)
                        {
                           
                            number += 2778;
                        }
                        else if ((number % 5555 == 0)&&(number/5555)==0)
                        {
                            number += 27778;
                        }
                        else if ((number % 55555 == 0) && (number / 55555) == 0)
                        {
                            number += 277778;
                        }
                        else if ((number % 555555 == 0) && (number / 555555) == 0)
                        {
                            number += 27777778;
                        }
                        else if ((number % 5555555 == 0) && (number / 5555555) == 0)
                        {
                            number += 277777778;
                        }
                    }
                
            }
        }
        Console.WriteLine(count);

        //second task

        list.Sort();
        decimal percent= perc/100;
        int result = 0;
        for (int index = 0; index < list.Count-1; index++)
        {
            if (list[index]==list[index+1])
            {
                continue;
            }
            else
            {
                if (index+1>=(percent*list.Count))
                {
                    result = list[index];
                    break;
                }
            }
        }
        if ((result==0)&&(list.Count>= (percent * list.Count)))
        {
            result = list[list.Count-1];
    
        }
        Console.WriteLine(result);
    }

}
