using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Brackets
{
    static void Main()
    {
        int lines = int.Parse(Console.ReadLine());
        string separator = Console.ReadLine().Trim();
        string[] arrayText = new string[lines];
        for (int i = 0; i < lines; i++)
        {
            arrayText[i] = Console.ReadLine().Trim();
        }
        int brackets = 0;
        //int open;
        //int close;

        for (int i = 0; i < lines; i++)
        {
            string line = arrayText[i];
            int symbNo = 0;
            foreach (char el in line)
            {
                if (el == '{')
                {
                    if (brackets > 0)
                    {
                        for (int j = 0; j < brackets; j++)
                        {
                            Console.WriteLine();
                            Console.Write(separator);
                            Console.Write('{');
                            Console.WriteLine();
                            brackets++;
                        }
                    }
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine('{');
                        brackets++;
                    }
                    symbNo = 0;
                }
                else if (el == '}')
                {
                    if (brackets > 0)
                    {
                        for (int j = 0; j < brackets; j++)
                        {
                            Console.WriteLine();
                            Console.Write(separator);
                            Console.WriteLine('}');
                            brackets--;
                        }
                    }
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine('}');
                        brackets--;
                    }
                    symbNo = 0;

                }
                else
                {
                    if (symbNo == 0)
                    {
                        if (brackets > 0)
                        {
                            for (int j = 0; j < brackets; j++)
                            {
                                Console.Write(separator);
                            }

                        }
                        Console.Write(el);
                        symbNo++;
                    }
                    else
                    {
                        /*for (int j = 0; j < brackets; j++)
                        {
                            Console.WriteLine();
                            Console.Write(separator);
                            Console.WriteLine(el);
                        }*/
                        Console.Write(el);
                        symbNo++;
                    }
                }
            }
        }
    }
}




/* switch (el)
        {
            case '{':
                if (brackets > 0)
                {
                    for (int j = 0; j < brackets; j++)
                    {
                        Console.Write(separator);
                        Console.Write('{');
                        Console.WriteLine();
                        brackets++;
                    }
                }
                else
                {
                    Console.WriteLine('{');
                    brackets++;
                }
                symbNo = 0;
                ; break;
            case '}':
                if (brackets > 0)
                {
                    for (int j = 0; j <= brackets; j++)
                    {
                        Console.WriteLine();
                        Console.Write(separator);
                        Console.WriteLine('}');
                        brackets--;
                    }
                }
                else
                {
                    Console.WriteLine('}');
                    brackets--;
                }
                symbNo = 0;
                ; break;

            default:
                if (symbNo >= 0)
                {
                    Console.Write(el);
                }
                else
                {
                    for (int j = 0; j < brackets; j++)
                    {
                        Console.WriteLine();
                        Console.Write(separator);
                        Console.WriteLine(el);
                    }
                    symbNo++;
                }
                break;
        }
    }
    symbNo = 0;
} */