using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Problem05
{
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
#endif

        //variables
        long first, second;
        long counter = 0;
        int[] arr;

        string task1 = Console.ReadLine();
        string task2 = Console.ReadLine();
        int percent = int.Parse(Console.ReadLine());


        #region task1
        first = long.Parse(task1.Split(' ')[0]);
        second = long.Parse(task1.Split(' ')[1]);

        string f = first.ToString();
        Regex match = new Regex("^(3|5)+$");
        for (long i = first; i < second; i++)
        {
            string current = i.ToString();
            if (i % 5 == 0 || i % 3 == 0)
            {
                if (match.IsMatch(current))
                {
                    if (current == ReverseStrings(current))
                    {
                        counter++;
                    }

                }
            }
        }
        #endregion

        #region task2
        string[] temp = task2.Split(',');
        arr = new int[temp.Length];
        for (int i = 0; i < temp.Length; i++)
        {
            arr[i] = int.Parse(temp[i]);
        }

        Array.Sort(arr);

        #endregion

        //print
        Console.WriteLine(counter);

        int percentile = (percent * arr.Length) / 100;
        int result = arr[percentile];
        if (result < 0)
        {
            Console.WriteLine(arr[percentile - 1]);
        }
        else
        {
            Console.WriteLine(arr[percentile]);
        }

    }

    public static string ReverseStrings(string s)
    {
        char[] arr = s.ToCharArray();
        Array.Reverse(arr);
        return new string(arr);
    }
}
