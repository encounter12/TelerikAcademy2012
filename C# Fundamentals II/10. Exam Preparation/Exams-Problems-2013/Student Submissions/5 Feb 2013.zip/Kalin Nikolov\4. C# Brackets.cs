using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpBrackets
{
    class CSharpBrackets
    {
        static void Main()
        {

            int N = int.Parse(Console.ReadLine().Trim());

            string indentString = Console.ReadLine().Trim();

            string[] codeLines = new string[N];

            for (int i = 0; i < N; i++)
            {
                codeLines[i] = Console.ReadLine().Trim();
            }

            int count = 0;
            int indentCount = 0;
            string output = "";
            char lastChar = ' ';
            char currChar;

            while (count < N)
            {
                for (int i = 0; i < codeLines[count].Length; i++)
                {
                    currChar = codeLines[count][i];
                    if (lastChar == ' ' && currChar == ' ')
                        continue;

                    if (output.EndsWith("\n") && currChar != '{' && currChar != '}')
                        output += getIndents(indentString, indentCount);

                    if (currChar == '{')
                    {
                        output += "\n" + getIndents(indentString, indentCount) + "{\n";
                        indentCount++;
                        continue;
                    }
                    else
                        if (currChar == '}')
                        {
                            indentCount--;
                            output += "\n" + getIndents(indentString, indentCount) + "}\n";

                            continue;
                        }

                    lastChar = currChar;

                    output += lastChar;


                }

                output += "\n";
                count++;
            }

            string[] outs = output.Split(new char[] { '\n' });

            for (int i = 0; i < outs.Length; i++)
            {
                if (!string.IsNullOrEmpty(outs[i]))
                    Console.WriteLine(outs[i]);
            }

        }

        static string getIndents(string indentString, int indentCount)
        {
            string ret = "";
            for (int i = 0; i < indentCount; i++)
                ret += indentString;

            return ret;
        }
    }
}
