using System;
 
class JoroTheRabbit
{
    static void Main()
    {
        string[] words = ReadAndSplitInput();
 
        int[] numbers = new int[words.Length];
        ConvertToIntArray(words, numbers);
        int maxPossibleStep = numbers.Length;
        int[] visited = new int[numbers.Length];
        int currPos = 0;
        int currStep = 1;
        int currentMaxSequence = 1;
        int result = 1;
 
        for (int i = 0; i < numbers.Length; i++)
        {
            currPos = i;
            for (int j = 1; j <= maxPossibleStep; j++)
            {
                currStep = j;
                while (true)
                {
                    visited[currPos] = 1;
                    if ((currPos + currStep) < numbers.Length)
                    {
                        if (numbers[currPos] < numbers[currPos + currStep])
                        {
                            if (visited[currPos + currStep] == 0)
                            {
                                currentMaxSequence++;
                                currPos = currPos + currStep;
                            }
                            else
                            {
                                IsCurrentResultSmaller(numbers, ref visited, ref currPos, ref currentMaxSequence, ref result, i);
                                break;
                            }
                        }
                        else
                        {
                            IsCurrentResultSmaller(numbers, ref visited, ref currPos, ref currentMaxSequence, ref result, i);
                            break;
                        }
                    }
                    else
                    {
                        if (numbers[currPos] < numbers[currPos + currStep - numbers.Length])
                        {
                            if (visited[currPos + currStep - numbers.Length] == 0)
                            {
                                currentMaxSequence++;
                                currPos = currPos + currStep - numbers.Length;
                            }
                            else
                            {
                                IsCurrentResultSmaller(numbers, ref visited, ref currPos, ref currentMaxSequence, ref result, i);
                                break;
                            }
                        }
                        else
                        {
                            IsCurrentResultSmaller(numbers, ref visited, ref currPos, ref currentMaxSequence, ref result, i);
                            break;
                        }
                    }
                }
            }
        }
        Console.WriteLine(result);
    }
 
    private static void IsCurrentResultSmaller(int[] numbers, ref int[] visited, ref int currPos, ref int currentMaxSequence, ref int result, int i)
    {
        if (result < currentMaxSequence)
        {
            result = currentMaxSequence;
             
        }
        currPos = i;
        currentMaxSequence = 1;
        visited = new int[numbers.Length];
    }
 
    private static void ConvertToIntArray(string[] words, int[] numbers)
    {
        for (int i = 0; i < words.Length; i++)
        {
            numbers[i] = int.Parse(words[i]);
        }
    }
 
    private static string[] ReadAndSplitInput()
    {
        string input = Console.ReadLine();
        char[] separators = { ' ', ',' };
        string[] words = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        return words;
    }
}