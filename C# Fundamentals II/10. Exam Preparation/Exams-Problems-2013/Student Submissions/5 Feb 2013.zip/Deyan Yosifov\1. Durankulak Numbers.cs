using System;
using System.Numerics;
using System.Collections.Generic;

class DurankulakNumbers
{
    static void Main()
    {
        Dictionary<string, BigInteger> digits = new Dictionary<string, BigInteger>();
        GenerateDictionary(digits);
        //PrintDictionary(digits);

        string input = Console.ReadLine().Trim();
        Console.WriteLine(ReadInput(input, digits));
    }

    private static BigInteger ReadInput(string input, Dictionary<string, BigInteger> digits)
    {
        BigInteger result = 0;
        BigInteger multiplier = 1;

        for (int i = input.Length - 1; i >= 0; i--)
        {
            if (i > 0)
            {
                if (input[i - 1] >= 'a' && input[i - 1] <= 'f')
                {
                    result += digits[String.Format("{0}{1}", input[i - 1], input[i])] * multiplier;
                    i--;
                }
                else
                {
                    result += digits[input[i].ToString()] * multiplier;
                }
            }
            else
            {
                if (input[i] != '-')
                {
                    result += digits[input[i].ToString()] * multiplier;
                }
                else
                {
                    result *= -1;
                }
            }
            multiplier *= 168;
        }

        return result;
    }

    private static void GenerateDictionary(Dictionary<string, BigInteger> digits)
    {
        for (int i = 0; i <= 25; i++)
        {
            digits.Add(((char)('A' + i)).ToString(), digits.Count);
        }

        for (int j = (int)'a'; j <= (int)'f'; j++)
        {
            for (int i = 0; i <= 25; i++)
            {
                digits.Add(String.Format("{0}{1}", (char)j, (char)('A' + i)), digits.Count);
                if(digits.Count == 168) break;
            }
        }
    }

    private static void PrintDictionary(Dictionary<string, BigInteger> digits)
    {
        foreach (string key in digits.Keys)
        {
            Console.WriteLine("{0} = {1}", key, digits[key]);
        }
    }
}