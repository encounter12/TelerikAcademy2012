using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LuckyNumbers
{
    class Program
    {
    //    public static string ReverseString(string s)
    //{
    //char[] arr = s.ToCharArray();
    //Array.Reverse(arr);
    //return new string(arr);
    //}
        static void Main(string[] args)
        {
            string[] str = Console.ReadLine().Split(' ');
            int A = int.Parse(str[0]);
            int B = int.Parse(str[1]);

           string List  = Console.ReadLine();
            int P = int.Parse(Console.ReadLine());
           

            for (int i = A; i <= B; i++)
            {
                string next = A.ToString();
                char[] arr = next.ToCharArray();
                foreach (var digit in arr)
                {
                    if ((digit != '5') | (digit != '3'))
                    {
                        break;
                    }
                }
                Array.Reverse(arr);

     
                

               // foreach (var digit in next)
               // {
               //     if ((digit != '5') | (digit != '3'))
               //     {
               //         break;
               //     }
               //     else sb.Append(digit);
               // }
               // char [] some = sb.ToChar();
               // Array.Reverse(some);
               // return new string(some);
               //string.Compare(reverse, next);
               //   int lucky = +1;
                
                }
            }
        }
    }

