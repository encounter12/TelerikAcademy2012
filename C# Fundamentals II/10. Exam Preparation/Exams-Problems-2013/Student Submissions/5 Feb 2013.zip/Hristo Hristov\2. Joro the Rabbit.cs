using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoroTheRabbit
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Replace(" ", "").Split(',');
            int[] arr = new int[input.Length];

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = Convert.ToInt32(input[i]);
            }

            int maxJups = 0;

            for (int step = 1; step < arr.Length; step++)
            {
                for (int nexDigit = 0; nexDigit < arr.Length; nexDigit++)
                {
                    int currentDigit = nexDigit;
                    int jups = 0;
                    while (true)
                    {
                        if (arr[currentDigit] < arr[(currentDigit + step) % arr.Length])
                        {
                            jups++;
                            currentDigit = (currentDigit + step) % arr.Length;
                        }
                        else
                        {
                            if (jups > maxJups)
                            {
                                maxJups = jups;
                            }
                            break;
                        }
                    }
                }
            }
            Console.WriteLine(maxJups + 1);
        }
    }
}
