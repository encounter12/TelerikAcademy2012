using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class JoroTheRabbit
{
    static void Main()
    {
        string consoleInput = Console.ReadLine();
        List<string> terrainStrNum = new List<string>();
        char[] separators = { ',', ' ' };
        terrainStrNum.AddRange(consoleInput.Split(separators, StringSplitOptions.RemoveEmptyEntries));
        int count = terrainStrNum.Count;
        int[] terrainInt = new int[count];
        int jumps = 1;

        // Convert to integer
        for (int i = 0; i < count; i++)
        {
            terrainInt[i] = int.Parse(terrainStrNum[i]);
        }

        // Start the search from the first cell
        for (int i = 0; i < count; i++)
        {
            int firstCell = terrainInt[i];
            int step = 0;

            if (i == count - 1)
            {
                if (jumps == count - 1)
                {
                    if ((terrainInt[i] < terrainInt[0]) || (terrainInt[i] > terrainInt[i - 1]))
                    {
                        jumps++;
                    }
                }
            }
            else
            {
                // Search for a bigger number
                for (int k = i + 1; k < count; k++)
                {
                    int nextCell = terrainInt[k];
                    int tempJumps = 1;

                    if (nextCell > firstCell)
                    {
                        step = k - i;

                        if (step > 0)
                        {
                            int index = i;
                            int nextIndex = index + step;

                            while (true)
                            {
                                if (terrainInt[nextIndex] > terrainInt[index])
                                {
                                    tempJumps++;

                                    // Check for overflow
                                    if ((nextIndex + step) >= count)
                                    {
                                        index = nextIndex;
                                        nextIndex = (nextIndex + step) - count;
                                    }
                                    else
                                    {
                                        index = nextIndex;
                                        nextIndex += step;
                                    }
                                }
                                else
                                {
                                    if (tempJumps > jumps)
                                    {
                                        jumps = tempJumps;
                                    }

                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        Console.WriteLine(jumps);
    }
}
