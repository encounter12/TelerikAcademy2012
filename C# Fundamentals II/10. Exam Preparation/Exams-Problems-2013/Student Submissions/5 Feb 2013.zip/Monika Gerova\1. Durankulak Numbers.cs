using System;
class NumbersOfDurankulak
{
    static void Main()
    {
        long num = long.Parse(Console.ReadLine());
        char[] upperLetters = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
        char[] lowerLetters = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
        string output;
        int temp = 0;
        
        if (num <=25)
        {
           Console.WriteLine(upperLetters[num]);
        }
        if (num >= 26 && num <= 51)
        {
             temp = 26;
            Console.Write(lowerLetters[0]);
            for (int i = 0; i < upperLetters.Length; i++)
            {
                if (num == temp)
                {
                    Console.Write(upperLetters[i]);
                    Console.WriteLine();
                    break;
                }
                else
                {
                    temp++;
                }
            }
        }
       
        if (num >= 52 && num <= 77)
        {
            temp = 52;
            Console.Write(lowerLetters[1]);
            for (int i = 0; i < upperLetters.Length; i++)
            {
                if (num == temp)
                {
                    Console.Write(upperLetters[i]);
                    Console.WriteLine();
                    break;
                }
                else
                {
                    temp++;
                }
            }
        }
        if (num >= 78 && num <= 103)
        {
            temp = 78;
            Console.Write(lowerLetters[2]);
            for (int i = 0; i < upperLetters.Length; i++)
            {
                if (num == temp)
                {
                    Console.Write(upperLetters[i]);
                    Console.WriteLine();
                    break;
                }
                else
                {
                    temp++;
                }
            }
        }
        if (num >= 104 && num <= 129)
        {
            temp = 104;
            Console.Write(lowerLetters[3]);
            for (int i = 0; i < upperLetters.Length; i++)
            {
                if (num ==temp)
                {
                    Console.Write(upperLetters[i]);
                    Console.WriteLine();
                    break;
                }
                else
                {
                    temp++;
                }
            }
        }
        if (num >= 130 && num <= 155)
        {
            temp = 130;
            Console.Write(lowerLetters[4]);
            for (int i = 0; i < upperLetters.Length; i++)
            {
                if (num == temp)
                {
                    Console.Write(upperLetters[i]);
                    Console.WriteLine();
                    break;
                }
                else
                {
                    temp++;
                }
            }
        }
        if (num >= 156 && num <= 167)
        {
            temp = 156;
            Console.Write(lowerLetters[5]);
            for (int i = 0; i < upperLetters.Length; i++)
            {
                if (num == temp)
                {
                    Console.Write(upperLetters[i]);
                    Console.WriteLine();
                    break;
                }
                else
                {
                    temp++;
                }
            }
        }
    }
}
