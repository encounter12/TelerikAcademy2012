using System;




namespace task1
{
    class Task1
    {

        static void Main(string[] args)
        {
            string newstr = Console.ReadLine();


            double digit = 0;
            int count = newstr.Length - 1;
            int digits = 3;
            if (newstr.Length == 1)
            {
                digit = GetLetterNumber(newstr[newstr.Length - 1]);
            }
            if (newstr.Length == 2)
            {
                digit = GetdbLetterNumber(newstr);
                Console.WriteLine(digit);
            }
            else
            {
                while (count > 0)
                {

                    if ('z' >= newstr[count - 1] && newstr[count - 1] >= 'a')
                    {
                        string test = newstr.Substring(count - 1, 2);
                        digit = GetDLetterNumber(test);
                        count -= 1;
                        digits += 1;
                    }
                    else
                    {
                        digit = GetLetterNumber(newstr[count - 1]) * Math.Pow(168, digits - 3) + digit;
                        count -= 1;
                        digits += 1;
                    }
                    if (('z' >= newstr[count - 1] && newstr[count - 1] >= 'a') && ('Z' >= newstr[count] && newstr[count] >= 'A'))
                    {
                       char[] str = { newstr[count - 1] , newstr[count]};

                       digit = GetdbLetterNumber(str.ToString()) * Math.Pow(168, digits-3) + digit;
                        count -= 1;
                      
                    }

                }
                Console.WriteLine(digit);
            }
        }

        private static int GetdbLetterNumber(string newstr)
        {
            return 26 * GetLetterNumber(newstr[0]) + GetLetterNumber(newstr[1]);
        }

        static int GetLetterNumber(char letter)
        {
            if ('z' >= letter && letter >= 'a') return 6 - ('f' - letter);
            return 25 - ('Z' - letter);
        }

        static int GetDLetterNumber(string str)
        {
            return 26 * GetLetterNumber(str[0]) + GetLetterNumber(str[1]);

        }
    }
}