using System;
using System.Collections.Generic;

class durankulakNumbers
{
    static void Main()
    {
        string input = Console.ReadLine();
        char[] inputChars = input.ToCharArray();
        int length = 0;
        if (inputChars.Length % 2 == 0)
        {
            length = inputChars.Length / 2;
        }
        else
        {
            length = inputChars.Length;
        }
        List<string> digits = new List<string>();
        int j = 0;
        for (int i = 0; i < inputChars.Length; i++)
        {
            string temp = "";
            switch (inputChars[i])
            {
                case 'a': temp = "a" + inputChars[i + 1]; i++; j++; break;
                case 'b': temp = "b" + inputChars[i + 1]; i++; j++; break;
                case 'c': temp = "b" + inputChars[i + 1]; i++; j++; break;
                case 'd': temp = "c" + inputChars[i + 1]; i++; j++; break;
                case 'e': temp = "e" + inputChars[i + 1]; i++; j++; break;
                case 'f': temp = "f" + inputChars[i + 1]; i++; j++; break;
                default: temp = inputChars[i].ToString(); j++; break;
            }
            digits.Add(temp);

        }
        digits.Reverse();
        digits.Remove(" ");
        double multiplier = 0;
        int value = 0;
        double sum = 0;
        double currentSum = 0;
        for (int i = 0; i < digits.Count; i++)
        {
            multiplier = Math.Pow(168, i);
            if (multiplier == 0)
            {
                multiplier = 1;
            }
            char[] number = digits[i].ToCharArray();
            if (number.Length == 1)
            {
                switch (number[0])
                {
                    case 'A': value = 0; break;
                    case 'B': value = 1; break;
                    case 'C': value = 2; break;
                    case 'D': value = 3; break;
                    case 'E': value = 4; break;
                    case 'F': value = 5; break;
                    case 'G': value = 6; break;
                    case 'H': value = 7; break;
                    case 'I': value = 8; break;
                    case 'J': value = 9; break;
                    case 'K': value = 10; break;
                    case 'L': value = 11; break;
                    case 'M': value = 12; break;
                    case 'N': value = 13; break;
                    case 'O': value = 14; break;
                    case 'P': value = 15; break;
                    case 'Q': value = 16; break;
                    case 'R': value = 17; break;
                    case 'S': value = 18; break;
                    case 'T': value = 19; break;
                    case 'U': value = 20; break;
                    case 'V': value = 21; break;
                    case 'W': value = 22; break;
                    case 'X': value = 23; break;
                    case 'Y': value = 24; break;
                    case 'Z': value = 25; break;
                    default: Console.WriteLine("There is a problem!"); ; break;
                }
            }
            else
            {
                switch (number[0])
                {
                    case 'a':
                        {
                            switch (number[1])
                            {
                                case 'A': value = 26; break;
                                case 'B': value = 27; break;
                                case 'C': value = 28; break;
                                case 'D': value = 29; break;
                                case 'E': value = 30; break;
                                case 'F': value = 31; break;
                                case 'G': value = 32; break;
                                case 'H': value = 33; break;
                                case 'I': value = 34; break;
                                case 'J': value = 35; break;
                                case 'K': value = 36; break;
                                case 'L': value = 37; break;
                                case 'M': value = 38; break;
                                case 'N': value = 39; break;
                                case 'O': value = 40; break;
                                case 'P': value = 41; break;
                                case 'Q': value = 42; break;
                                case 'R': value = 43; break;
                                case 'S': value = 44; break;
                                case 'T': value = 45; break;
                                case 'U': value = 46; break;
                                case 'V': value = 47; break;
                                case 'W': value = 48; break;
                                case 'X': value = 49; break;
                                case 'Y': value = 50; break;
                                case 'Z': value = 51; break;
                                default: Console.WriteLine("There is a problem!"); ; break;
                            }
                        } break;
                    case 'b':
                        switch (number[1])
                        {
                            case 'A': value = 52; break;
                            case 'B': value = 53; break;
                            case 'C': value = 53; break;
                            case 'D': value = 55; break;
                            case 'E': value = 56; break;
                            case 'F': value = 57; break;
                            case 'G': value = 58; break;
                            case 'H': value = 59; break;
                            case 'I': value = 60; break;
                            case 'J': value = 61; break;
                            case 'K': value = 62; break;
                            case 'L': value = 63; break;
                            case 'M': value = 64; break;
                            case 'N': value = 65; break;
                            case 'O': value = 66; break;
                            case 'P': value = 67; break;
                            case 'Q': value = 68; break;
                            case 'R': value = 69; break;
                            case 'S': value = 70; break;
                            case 'T': value = 71; break;
                            case 'U': value = 72; break;
                            case 'V': value = 73; break;
                            case 'W': value = 74; break;
                            case 'X': value = 75; break;
                            case 'Y': value = 76; break;
                            case 'Z': value = 77; break;
                            default: Console.WriteLine("There is a problem!"); ; break;
                        } break;
                    case 'c':
                        switch (number[1])
                        {
                            case 'A': value = 78; break;
                            case 'B': value = 79; break;
                            case 'C': value = 80; break;
                            case 'D': value = 81; break;
                            case 'E': value = 82; break;
                            case 'F': value = 83; break;
                            case 'G': value = 84; break;
                            case 'H': value = 85; break;
                            case 'I': value = 86; break;
                            case 'J': value = 87; break;
                            case 'K': value = 88; break;
                            case 'L': value = 89; break;
                            case 'M': value = 90; break;
                            case 'N': value = 91; break;
                            case 'O': value = 92; break;
                            case 'P': value = 93; break;
                            case 'Q': value = 94; break;
                            case 'R': value = 95; break;
                            case 'S': value = 96; break;
                            case 'T': value = 97; break;
                            case 'U': value = 98; break;
                            case 'V': value = 99; break;
                            case 'W': value = 100; break;
                            case 'X': value = 101; break;
                            case 'Y': value = 102; break;
                            case 'Z': value = 103; break;
                            default: Console.WriteLine("There is a problem!"); ; break;
                        } break;
                    case 'd':
                        switch (number[1])
                        {
                            case 'A': value = 104; break;
                            case 'B': value = 105; break;
                            case 'C': value = 106; break;
                            case 'D': value = 107; break;
                            case 'E': value = 108; break;
                            case 'F': value = 109; break;
                            case 'G': value = 110; break;
                            case 'H': value = 111; break;
                            case 'I': value = 112; break;
                            case 'J': value = 113; break;
                            case 'K': value = 114; break;
                            case 'L': value = 115; break;
                            case 'M': value = 116; break;
                            case 'N': value = 117; break;
                            case 'O': value = 118; break;
                            case 'P': value = 119; break;
                            case 'Q': value = 120; break;
                            case 'R': value = 121; break;
                            case 'S': value = 122; break;
                            case 'T': value = 123; break;
                            case 'U': value = 124; break;
                            case 'V': value = 125; break;
                            case 'W': value = 126; break;
                            case 'X': value = 127; break;
                            case 'Y': value = 128; break;
                            case 'Z': value = 129; break;
                            default: Console.WriteLine("There is a problem!"); ; break;
                        } break;
                    case 'e':
                        switch (number[1])
                        {
                            case 'A': value = 130; break;
                            case 'B': value = 131; break;
                            case 'C': value = 132; break;
                            case 'D': value = 133; break;
                            case 'E': value = 134; break;
                            case 'F': value = 135; break;
                            case 'G': value = 136; break;
                            case 'H': value = 137; break;
                            case 'I': value = 138; break;
                            case 'J': value = 139; break;
                            case 'K': value = 140; break;
                            case 'L': value = 141; break;
                            case 'M': value = 142; break;
                            case 'N': value = 143; break;
                            case 'O': value = 144; break;
                            case 'P': value = 145; break;
                            case 'Q': value = 146; break;
                            case 'R': value = 147; break;
                            case 'S': value = 148; break;
                            case 'T': value = 149; break;
                            case 'U': value = 150; break;
                            case 'V': value = 151; break;
                            case 'W': value = 152; break;
                            case 'X': value = 153; break;
                            case 'Y': value = 154; break;
                            case 'Z': value = 155; break;
                            default: Console.WriteLine("There is a problem!"); ; break;
                        } break;
                    case 'f':
                        switch (number[1])
                        {
                            case 'A': value = 156; break;
                            case 'B': value = 157; break;
                            case 'C': value = 158; break;
                            case 'D': value = 159; break;
                            case 'E': value = 160; break;
                            case 'F': value = 161; break;
                            case 'G': value = 162; break;
                            case 'H': value = 163; break;
                            case 'I': value = 164; break;
                            case 'J': value = 165; break;
                            case 'K': value = 166; break;
                            case 'L': value = 167; break;
                            default: Console.WriteLine("There is a problem!"); ; break;
                        } break;
                    default: Console.WriteLine("There is something wrong!"); break;
                }
            }
            currentSum = multiplier * value;
            sum += currentSum;
            multiplier = 0;
            value = 0;
            currentSum = 0;
        }
        Console.WriteLine(sum);
    }

}
