using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

class DurankulakNumbers
{
    static void Main(string[] args)
    {
        string number = Console.ReadLine();
        string[] numTable = FillArray();

        string[] splitDigits = FindDigits(number);
        BigInteger digit = 0;
        BigInteger decNumber = 0;
        BigInteger power = 1;

        for (int i = splitDigits.Length - 1; i >= 0; i--)
        {            
            digit = MatchDecValue(splitDigits[i], numTable);
            decNumber += digit * power;
            power *= 168;
        }
        Console.WriteLine(decNumber);
    }

    static string[] FillArray()
    {
        string[] numTable = new string[168];

        //Fill the array with digits
        for (int i = 0; i < 26; i++)
        {
            numTable[i] = ((char)(i + (int)('A'))).ToString();
        }

        for (int i = 26; i <= 167; i++)
        {
            if (i >= 26 && i <= 51)
            {
                numTable[i] = "a" + numTable[i % 26];
            }
            else if (i >= 52 && i <= 77)
            {
                numTable[i] = "b" + numTable[i % 26];
            }
            else if (i >= 78 && i <= 103)
            {
                numTable[i] = "c" + numTable[i % 26];
            }
            else if (i >= 104 && i <= 129)
            {
                numTable[i] = "d" + numTable[i % 26];
            }
            else if (i >= 130 && i <= 155)
            {
                numTable[i] = "e" + numTable[i % 26];
            }
            else if (i >= 156 && i <= 167)
            {
                numTable[i] = "f" + numTable[i % 26];
            }
        }
        return numTable;
    }


    static string[] FindDigits(string number)
    {
        string digits = "";

        int i = number.Length - 1;
        
        do
        {
            if (i == 0)
            {
                digits =  number[i] + " " + digits;
                i--;
            }
            else if (char.IsLower(number[i - 1]) && char.IsUpper(number[i]))
            {
                digits = number[i - 1] + "" + number[i] + " " + digits;
                i = i - 2;
            }
            else
            {
                digits = number[i] + " " + digits;
                i = i - 1;
            }
        }
        while(i >= 0);

        string[] splitDigits = (digits.Trim()).Split(' ');
        return splitDigits;
    }

    static int MatchDecValue(string digit, string[] numTable)
    {
        int i;
        for (i = 0; i < numTable.Length - 1; i++)
        {
            if (digit == numTable[i])
            {
                return i;                
            }
        }
        return i;
    }
}
