using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace TwoBetterThanOne
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int paceCount = 1;
            int index = 0;
            string[] num = input.Split(' ');
            int[] numbers = new int[num.Length];
            for (int i = 0; i < num.Length; i++)
            {
                numbers[i] = int.Parse(num[i].Trim());
            }
            string input2 = Console.ReadLine();
            string[] num2 = input2.Split(',');
            int[] numbers2 = new int[num2.Length];
            for (int i = 0; i < num2.Length; i++)
            {
                numbers2[i] = int.Parse(num2[i].Trim());
            }
            int number = int.Parse(Console.ReadLine());
            int c = number / 100;
            Array.Sort(numbers2);
            //foreach (var item in numbers2)
            //{
            //    Console.WriteLine(item);
            //}
 
            string[] k = new string[] { "5", "3" };
            string[] nn = new string[numbers[numbers.Length - 1] - numbers[0]];
            int border = numbers[numbers.Length - 1];
            int symbols = border.ToString().Length;
            for (int i = numbers[0]; i < numbers[numbers.Length - 1]; i++)
            {
                nn[index] = i.ToString();
                index++;
            }
            List<int> m = new List<int>();
            List<int> mm = new List<int>();
            foreach (var item in nn)
            {
                for (int i = 0; i < item.Length; i++)
                {
                    if (item[i] == '5' || item[i] == '3')
                    {
                        m.Add(int.Parse(item));
                    }
                }
            }
            for (int i = 0; i < m.Count; i++)
            {
                bool polindrome = true;
                for (int j = 0; j < m[i].ToString().Length / 2; j++)
                {
                    string current = m[i].ToString();
                    if (current[j] != current[current.Length - 1 - j])
                    {
                        polindrome = false;
                        break;
                    }
                }
                if (polindrome)
                {
                    mm.Add(m[i]);
                }
            }
            mm.TrimExcess();
            Console.WriteLine(mm.Count-2);
            Console.WriteLine(numbers2[c*numbers2.Length]);
        }
    }
}