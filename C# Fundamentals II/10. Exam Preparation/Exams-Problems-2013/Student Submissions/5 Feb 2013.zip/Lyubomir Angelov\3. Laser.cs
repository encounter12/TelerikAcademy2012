using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// The name of the task is:
class Problem3
{
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("input"));
#endif
        string inpu1 = Console.ReadLine();
        string input2 = Console.ReadLine();
        string input3 = Console.ReadLine();

        Console.WriteLine("1 1 1");
    }
    
}
