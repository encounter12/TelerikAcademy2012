using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace _4.Brackets
{
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            string tab = Console.ReadLine();
            string[] code = ReadInput(n);
            string result = Tabber(code, tab);
            result = Regex.Replace(result, @"\r\n" + @"(\s+)" + @"\r\n", "\r\n");
            result = Regex.Replace(result, @"\r\n\r\n", "\r\n");
            if (result.StartsWith("\r\n"))
            {
                result = result.Substring(result.IndexOf('\n') + 1);
            }
            Console.Write(result);
            
        }

        private static string Tabber(string[] lines, string tab)
        {
            int count = 0;
            StringBuilder result = new StringBuilder();
            char c;
            bool appendedC = false;
            bool beginSpaces = true;

            for (int i = 0; i < lines.Length; i++)
            {
                string code = lines[i];
                beginSpaces = true;
                for (int j = 0; j < code.Length; j++)
                {
                    c = code[j];

                    if (beginSpaces)
                    {
                        if (c == ' ')
                        {
                            continue;
                        }
                        else
                        {
                            beginSpaces = false;
                        }
                    }

                    if (c == ' ' && j + 1 < code.Length)
                    {
                        if (code[j + 1] == ' ')
                        {
                            continue;
                        }
                    }

                    if (c == '\r' && j + 1 < code.Length)
                    {
                        if (code[j + 1] == '\n')
                        {
                            appendedC = false;
                            j++;
                            result.AppendLine();
                        }
                    }

                    if (c == '{')
                    {
                        result.AppendLine();
                        for (int z = 0; z < count; z++)
                        {
                            result.Append(tab);
                        }
                        result.AppendLine("{");
                        count++;
                        appendedC = false;
                        continue;
                    }

                    if (c == '}')
                    {
                        count--;
                        result.AppendLine();
                        for (int z = 0; z < count; z++)
                        {
                            result.Append(tab);
                        }
                        result.Append("}");
                        result.AppendLine();
                        appendedC = false;
                        continue;
                    }

                    if (!appendedC)
                    {
                        for (int x = 0; x < count; x++)
                        {
                            result.Append(tab);
                        }
                    }
                    
                    result.Append(c);
                    appendedC = true;
                }
                result.AppendLine();
                appendedC = false;
            }

            return result.ToString();
        }

        private static string[] ReadInput(int n)
        {
            string[] lines = new string[n];
            string currentLine = string.Empty;
            for (int i = 0; i < n; i++)
            {
                lines[i] = Console.ReadLine().TrimEnd();
            }
            return lines;
        }
    }
}
