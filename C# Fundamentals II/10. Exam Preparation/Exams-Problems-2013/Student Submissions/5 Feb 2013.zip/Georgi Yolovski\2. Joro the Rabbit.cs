using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2.JoroTheRabbit
{
    class Program
    {
        private static int total = 0;

        static void FindSteps(short index, short step, short[] route)
        {
            List<int> visited = new List<int>();
            visited.Add(index);

            short count = 0;
            while (true)
            {
                short nextIndex = (short)((index + step < route.Length) ? index + step
                    : index + step - route.Length);

                if (route[index] < route[nextIndex] && !visited.Contains(nextIndex))
                {
                    count++;
                    visited.Add(nextIndex);
                    index = nextIndex;
                }
                else
                {
                    break;
                }
            }

            if(count > total)
            {
                total = count;
            }
        }

        static void Main(string[] args)
        {
            short[] numbers = Console.ReadLine().Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => short.Parse(x)).ToArray();

            short n = (short)numbers.Count();
            for (short i = 0; i < n; i++)
            {
                for (short j = 1; j <= n; j++)
                {
                    FindSteps(i, j, numbers);

                }
            }
            Console.WriteLine(total + 1);
        }
    }
}