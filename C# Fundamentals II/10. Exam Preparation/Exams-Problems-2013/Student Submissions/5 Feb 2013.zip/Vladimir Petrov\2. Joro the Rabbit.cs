using System;
using System.Collections.Generic;
using System.Text;

class Program
{
    static void Main()
    {
        string input = Console.ReadLine();
        string[] splitInput = input.Split(',');
        string[] trimmedInput = new string[splitInput.Length];
        for (int i = 0; i < splitInput.Length; i++)
        {
            trimmedInput[i] = splitInput[i].Trim();
        }
        int[] numeralInput = new int[trimmedInput.Length];
        for (int j = 0; j < trimmedInput.Length; j++)
        {
            numeralInput[j] = int.Parse(trimmedInput[j]);
        }
        Array.Sort(numeralInput);
        int count = 0;
        int maxCount = 0;
        int difference = 1;
        for (int i = 0; i < numeralInput.Length-1; i++)
        {
            if (numeralInput[i + 1] - numeralInput[i] == difference)
            {
                count++;
            }
            
        }
        if (count > maxCount)
        {
            maxCount = count;
            if (count != numeralInput.Length - 1)
            {
            difference++;
            }
        }
        if (difference == 1)
        {
            Console.WriteLine(maxCount + 1);
        }
        else
        {
            Console.WriteLine(numeralInput.Length / maxCount);
        }
    }
}
