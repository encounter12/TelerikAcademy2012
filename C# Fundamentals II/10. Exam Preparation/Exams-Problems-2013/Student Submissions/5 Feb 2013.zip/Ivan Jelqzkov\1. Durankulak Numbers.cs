using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;

class DurankulakNumbers
{
    static void Main()
    {
        string inputDurankulakNumber = Console.ReadLine();
        GenerateTable();
        Console.WriteLine( AnyToOtherNumeralSystem(SplitDurankulakNumber(inputDurankulakNumber), 168));
    }

    static string[] table = new string[168];

    static List<string> SplitDurankulakNumber(string durankulakNumber)
    {
        List<string> result = new List<string>();
        if (durankulakNumber.Length ==1)
        {
            result.Add(Convert.ToString(durankulakNumber[0]));
            return result;
        }
        for (int i =0 ; i < durankulakNumber.Length-1; i++)
        {
            if (durankulakNumber[i] > 91) // small letter
            {
                result.Add(String.Concat(durankulakNumber[i], durankulakNumber[i+1]));
                i++;
            }
            else
            {
                result.Add(Convert.ToString(durankulakNumber[i]));
            }
        }
        if ((durankulakNumber[durankulakNumber.Length-1] < 91)&&(durankulakNumber[durankulakNumber.Length-2] < 91))
        {
            result.Add(Convert.ToString(durankulakNumber[durankulakNumber.Length-1]));
        }
        return result;
    }

    static void GenerateTable()
    {
        int counter = 0;
        for (char j = 'A'; j <= 'Z'; j++)
        {
            table[counter++] = j.ToString();
        }
        for (char i = 'a'; i <= 'e'; i++)
        {
            for (char j = 'A'; j <= 'Z'; j++)
            {

                table[counter++] = String.Concat(i.ToString(),j.ToString());
            }
        }
        for (char j = 'A'; j <= 'L'; j++)
        {
            table[counter++] = String.Concat("f", j.ToString());
        }
    }

    static string AnyToOtherNumeralSystem(List<string> durankulakDigits, int baseOfnumber)
    {
        StringBuilder result = new StringBuilder();
        BigInteger asDecimal = 0;
        BigInteger power = 1;
        for (int i = durankulakDigits.Count - 1; i >= 0; i--)
        {
            asDecimal += (Array.IndexOf(table, durankulakDigits[i])) * power;
            power *= baseOfnumber;
        }
       
        return Convert.ToString(asDecimal);
    }
}