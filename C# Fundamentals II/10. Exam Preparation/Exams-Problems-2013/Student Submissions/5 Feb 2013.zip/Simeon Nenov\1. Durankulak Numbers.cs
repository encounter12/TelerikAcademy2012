using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Durankulak
{
    class Program
    {
        static void Main(string[] args)
        {
            //char[] input = File.ReadAllText(@"C:\Test4.txt").ToCharArray();
            char[] input = Console.ReadLine().ToCharArray();
            int buff=1;
            for (int i = 0; i < input.Length; i++)
            {
                bool small = false;
                if(char.IsLower(input[i]))
                {
                    buff *= ((int)input[i] - 96) * ((int)input[i+1] - 65);
                    small = true;
                }
                if (char.IsUpper(input[i]))
                {
                    if (!small)
                    {
                        buff *= ((int)input[i] - 65);
                    }
                    else
                    {
                        buff *= ((int)input[i] - 64);
                    }
                }
            }
            Console.Write(buff);
            //Console.ReadLine();
        }
    }
}
