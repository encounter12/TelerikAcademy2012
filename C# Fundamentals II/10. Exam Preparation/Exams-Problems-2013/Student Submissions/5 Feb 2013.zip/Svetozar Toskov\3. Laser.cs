using System;
using System.IO;
using System.Linq;

namespace EX03Laser
{
	class EX03Laser
	{
		//private static void Laser(bool[,,] cube, int startW, int startH, int startD, out int endW, out int endH, out int endD)
		//{
		//	count = 0;
		//	//Loop on each element and count its sequence
		//	for (int row = 0; row < cube.GetLength(0); row++)
		//	{
		//		for (int column = 0; column < cube.GetLength(1); column++)
		//		{
		//			for (int depth = 0; depth < cube.GetLength(2); depth++)
		//			{
		//				if (IsStarRoot(cube[row, column, depth], cube, row, column, depth))
		//				{
		//					count++;
		//					int currentCount;
		//					if (stars.TryGetValue(cube[row, column, depth], out currentCount))
		//					{
		//						currentCount++;
		//					}
		//					else
		//					{
		//						currentCount = 1;
		//					}
		//					stars[cube[row, column, depth]] = currentCount ;
		//				}
		//			}
		//		}
		//	}
		//}
		//private static bool IsStarRoot(string currentElement, string[,,] cube, int currentElementRow, int currentElementColumn, int currentElementDepth)
		//{
		//	//If the indexes are out of the matrix, the cell has apready been visited or the value is not in the same sequence skip the step
		//	if (currentElementRow <= 0 || currentElementRow >= cube.GetLength(0) - 1 ||
		//		currentElementColumn <= 0 || currentElementColumn >= cube.GetLength(1) - 1 ||
		//		currentElementDepth <= 0 || currentElementDepth >= cube.GetLength(2) - 1)
		//	{
		//		return false;
		//	}
		//	bool isStarRoot =
		//					 (currentElement == cube[currentElementRow - 1, currentElementColumn, currentElementDepth]) &&
		//					 (currentElement == cube[currentElementRow + 1, currentElementColumn, currentElementDepth]) &&
		//					 (currentElement == cube[currentElementRow, currentElementColumn - 1, currentElementDepth]) &&
		//					 (currentElement == cube[currentElementRow, currentElementColumn + 1, currentElementDepth]) &&
		//					 (currentElement == cube[currentElementRow, currentElementColumn, currentElementDepth - 1]) &&
		//					 (currentElement == cube[currentElementRow, currentElementColumn, currentElementDepth + 1]);
		//	return isStarRoot;
		//}
		static void Main()
		{
//			string inputText = @"5 10 5
//2 6 3
//1 0 1";
		
//			StringReader input = new StringReader(inputText);
//			Console.SetIn(input);

			string[] cubeParametersString = Console.ReadLine().Split(' ');
			int width = int.Parse(cubeParametersString[0]);
			int height = int.Parse(cubeParametersString[1]);
			int depth = int.Parse(cubeParametersString[2]);	

			string[] startCellParameters = Console.ReadLine().Split(' ');
			int startWidth = int.Parse(startCellParameters[0]) - 1;
			int startHeight = int.Parse(startCellParameters[1]) - 1;
			int startDepth = int.Parse(startCellParameters[2]) - 1;	

			string[] directionParameters = Console.ReadLine().Split(' ');
			int directionW = int.Parse(directionParameters[0]);
			int directionH = int.Parse(directionParameters[1]);
			int directionD = int.Parse(directionParameters[2]);	

			bool[,,] cube = new bool[width, height, depth];

			bool finished = false;
			
			int currentCellW = startWidth;
			int currentCellH = startHeight;
			int currentCellD = startDepth;
			
			int nextCellW = startWidth;
			int nextCellH = startHeight;
			int nextCellD = startDepth;

			cube[currentCellW, currentCellH, currentCellD] = true;

			while (!finished)
			{
				nextCellW = currentCellW + directionW;
				nextCellH = currentCellH + directionH;
				nextCellD = currentCellD + directionD;

				if (cube[nextCellW, nextCellH, nextCellD])
				{
					finished = true;
					break;
				}

				if (nextCellW <= 0 || nextCellW >= cube.GetLength(0) - 1)
				{
					directionW = -1 * directionW;
				}
				
				if (nextCellH <= 0 || nextCellH >= cube.GetLength(1) - 1)
				{
					directionH = -1 * directionH;
				}

				if (nextCellD <= 0 || nextCellD >= cube.GetLength(2) - 1)
				{
					directionD = -1 * directionD;
				}

				currentCellW = nextCellW;
				currentCellH = nextCellH;
				currentCellD = nextCellD;

				cube[currentCellW, currentCellH, currentCellD] = true;
			}

			Console.WriteLine("{0} {1} {2}", currentCellW + 1, currentCellH + 1, currentCellD + 1);
		}
	}
}