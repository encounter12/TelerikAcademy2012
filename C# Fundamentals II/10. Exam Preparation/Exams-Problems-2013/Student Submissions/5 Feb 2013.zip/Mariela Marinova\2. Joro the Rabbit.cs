using System;


class JoroTheRabbit
{
    static void Main()
    {
        string line = Console.ReadLine();
        string[] separators = new string[] { ", " };
        string[] arraystr = line.Split(separators, StringSplitOptions.None);
        int length = arraystr.Length;
        int[] arrayTerrian = new int[length];
        for (int i = 0; i < length; i++)
        {
            arrayTerrian[i] = int.Parse(arraystr[i]);
        }

        int startSearch = 0;
        int maxJump;
        int bestJump = 1;
        int step = 1;
        //int check;

        //int MaxEl = FindPozMax(arrayTerrian);

        while (startSearch < length)
        {
            while (step < length)
            {
                maxJump = CheckMaxJump(arrayTerrian, length, startSearch, step);
                if (bestJump < maxJump)
                {
                    bestJump = maxJump;
                }
                step++;
            }
            step = 0;
            startSearch++;
        }
        Console.WriteLine(bestJump);
    }



    static int FindPozMax(int[] array)
    {
        int max = 0;
        for (int i = 0; i < array.Length; i++)
        {
            if (array[i] > array[max])
            {
                max = i;
            }
        }
        return max;
    }



    static int CheckMaxJump(int[] arrayTerrian, int length, int pos, int step)
    {
        bool[] booleanArr = new bool[length];
        bool isOK = true;
        //int pos = startSearch;
        int check;
        int stepNumber = 1;
        while (isOK)
        {
            if (pos + step < length)
            {
                check = pos + step;
            }
            else
            {
                check = pos + step - length;
            }
            if (arrayTerrian[pos] < arrayTerrian[check] && !booleanArr[check])
            {
                pos = check;
                booleanArr[check] = true;
                stepNumber++;
            }
            else
            {
                isOK = false;
            }
        }
        return stepNumber;
    }
}