using System;
using System.Collections.Generic;
using System.Numerics;
 
class DurankulakNumbers
{
    static void Main()
    {
        char[] input = Console.ReadLine().ToCharArray();
        Array.Reverse(input);
         
        #region
 
        Dictionary<char, BigInteger> dict = new Dictionary<char, BigInteger>();
         
        dict.Add('a', 26);
        dict.Add('b', 52);
        dict.Add('c', 78);
        dict.Add('d', 104);
        dict.Add('e', 130);
        dict.Add('f', 156);
         
        dict.Add('A', 0);
        dict.Add('B', 1);
        dict.Add('C', 2);
        dict.Add('D', 3);
        dict.Add('E', 4);
        dict.Add('F', 5);
        dict.Add('G', 6);
        dict.Add('H', 7);
        dict.Add('I', 8);
        dict.Add('J', 9);
        dict.Add('K', 10);
        dict.Add('L', 11);
        dict.Add('M', 12);
        dict.Add('N', 13);
        dict.Add('O', 14);
        dict.Add('P', 15);
        dict.Add('Q', 16);
        dict.Add('R', 17);
        dict.Add('S', 18);
        dict.Add('T', 19);
        dict.Add('U', 20);
        dict.Add('V', 21);
        dict.Add('W', 22);
        dict.Add('X', 23);
        dict.Add('Y', 24);
        dict.Add('Z', 25);
         
        #endregion
         
        BigInteger num = 0;
        ulong power = 1;
        for (int i = 0; i < input.Length; i++)
        {
            if ((i < input.Length-1) && (Char.IsLower(input[i + 1])))
            {
                if (i != 0)
                {
                    num = num + ((dict[input[i]] + dict[input[i + 1]]) * (BigInteger)Math.Pow(168,power));
 
                    i++;
                    power++;
                    continue;
                }
                num = num + dict[input[i]] + dict[input[i + 1]];
                i += 1;
            }
            else
            {
                if (i != 0)
                {
                    num = num + (dict[input[i]]) * (BigInteger)Math.Pow(168, power);
                    power++;
                    continue;
                }
                num = num + dict[input[i]];
            }
        }
        Console.WriteLine(num);
    }
}