using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slides
{
    class Program
    {
        static int getW(char c) {
            int ret = 0;
            if (c == 'L') ret = -1;
            if (c == 'R') ret = 1;
            return ret;
        }
        static int getD(char c) {
            int ret = 0;
            if (c == 'B') ret = 1;
            if (c == 'F') ret = -1;
            return ret;
        }
        static void Main(string[] args)
        {
            string[] s1 = {" | " };
            char[] s2 = { ')', '(' };
            char[] s3 = { ' ' };

            string[] input = Console.ReadLine().Split(' ');
            int W = int.Parse(input[0]);
            int H = int.Parse(input[1]);
            int D = int.Parse(input[2]);

            int[, , ,] dir = new int[W, H, D, 3];
            int[, ,] type = new int[W, H, D];

            for (int h = 0; h < H; h++) {
                input = Console.ReadLine().Split(s1, StringSplitOptions.RemoveEmptyEntries);
                for (int d = 0; d < D; d++) {
                    string[] input2 = input[d].Split(s2, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < W; w++) {
                        string[] input3 = input2[w].Split(s3, StringSplitOptions.RemoveEmptyEntries);
                        char c = input3[0][0];
                        if (c == 'S') {
                            type[w, h, d] = 0;
                            string sdir = input3[1];
                            dir[w, h, d, 1] = 1;
                            for (int i = 0; i < sdir.Length; i++) {
                                dir[w, h, d, 0] += getW(sdir[i]);
                                dir[w, h, d, 2] += getD(sdir[i]);
                            }
                        }
                        else if (c == 'E') {
                            type[w, h, d] = 0;
                            dir[w, h, d, 0] = 0; dir[w, h, d, 1] = 1; dir[w, h, d, 2] = 0;
                        }
                        else if (c == 'T') {
                            type[w, h, d] = 1;
                            dir[w, h, d, 0] = int.Parse(input3[1]);
                            dir[w, h, d, 1] = h;
                            dir[w, h, d, 2] = int.Parse(input3[2]);
                        }
                        else if (c == 'B') {
                            type[w, h, d] = 2;
                        }
                        else throw new Exception("Error Parsing");
                    }
                }
            }
            string[] start = Console.ReadLine().Split(' ');
            int sw = int.Parse(start[0]);
            int sd = int.Parse(start[1]);
            int sh = 0;
            int nw=0, nh=0, nd=0;
            bool ballOut = false;
            while (true) {
                nw = sw; nd = sd; nh = sh;
                if (type[sw, sh, sd] == 0) {
                    nw += dir[sw, sh, sd, 0];
                    nh += dir[sw, sh, sd, 1];
                    nd += dir[sw, sh, sd, 2];
                }
                else if (type[sw, sh, sd] == 1) {
                    nw = dir[sw, sh, sd, 0];
                    nh = dir[sw, sh, sd, 1];
                    nd = dir[sw, sh, sd, 2];
                }
                else if (type[sw, sh, sd] == 2) {
                    ballOut = true;
                    break;
                }
                if (nh == H) {
                    ballOut = true;
                    break;
                }
                else if (nw<0 || nw>=W || nd<0 || nd>=D){
                    break;
                }
                sw = nw; sh = nh; sd = nd;
                //Console.WriteLine(sw + " " + sh + " " + sd);
            }
            if (ballOut) Console.WriteLine("Yes");
            else Console.WriteLine("No");
            Console.WriteLine("{0} {1} {2}", sw, sh, sd);
        }
    }
}
