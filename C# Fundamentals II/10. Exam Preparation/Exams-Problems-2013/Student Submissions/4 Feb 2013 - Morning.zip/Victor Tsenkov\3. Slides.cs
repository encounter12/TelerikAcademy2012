using System;

class Slides
{
    static void Main()
    {
        string[] inputLine = Console.ReadLine().Split(' ');
        int width = int.Parse(inputLine[0]);
        int height = int.Parse(inputLine[1]);
        int depth = int.Parse(inputLine[2]);

        string[,,] cuboid = new string[width, height, depth];

        for (int h = 0; h < height; h++)
        {
            string line = Console.ReadLine();
            string[] singleLine = line.Split('|');
            
            for (int d = 0; d < depth; d++)
            {
                string[] inBrackets = singleLine[d].Split(')');

                for (int w = 0; w < width; w++)
                {
                    cuboid[w, h, d] = inBrackets[w].TrimStart(new char[] { ' ', '(' });
                }
            }
        }

        //for (int d = 0; d < depth; d++)
        //{
        //    for (int h = 0; h < height; h++)
        //    {
        //        for (int w = 0; w < width; w++)
        //        {
        //            Console.Write(cuboid[w,h,d] + " ");
        //        }
        //        Console.WriteLine();
        //    }
        //    Console.WriteLine();
        //}

        string[] ballCoordinates = Console.ReadLine().Split(' ');
        int ballW = int.Parse(ballCoordinates[0]);
        int ballD = int.Parse(ballCoordinates[1]);
        int ballH = 0;
        int currentW = ballW, currentH = ballH, currentD = ballD;
        bool win = false;

        while (true)
        {
            if (ballW >= width || ballH >= height || ballD >= depth)
            {
                break;
            }

            if (ballW < 0 || ballH < 0 || ballD < 0)
            {
                break;
            }

            currentW = ballW; currentH = ballH; currentD = ballD;
            string[] command = cuboid[ballW, ballH, ballD].Split(' ');
            if (command[0] == "S")
            {
                if (currentH == height - 1)
                {
                    win = true;
                    break;
                }

                ballH++;

                if (command[1] == "L")
                {
                    ballW--;
                }
                if (command[1] == "R")
                {
                    ballW++;
                }
                if(command[1] == "F")
                {
                    ballD--;
                }
                if (command[1] == "B")
                {
                    ballD++;
                }
                if (command[1] == "FL")
                {
                    ballW--;
                    ballD--;
                }
                if (command[1] == "FR")
                {
                    ballW++;
                    ballD--;
                }
                if (command[1] == "BL")
                {
                    ballW--;
                    ballD++;
                }
                if (command[1] == "BR")
                {
                    ballW++;
                    ballD++;
                }
            }

            if (command[0] == "T")
            {
                ballW = int.Parse(command[1]);
                ballD = int.Parse(command[2]);
            }


            if (command[0] == "B")
            {
                break;
            }

            if (command[0] == "E")
            {
                ballH++;
                if (ballH == height)
                {
                    win = true;
                    break;
                }
            }

        }

        if (win)
        {
            Console.WriteLine("Yes");
        }
        else
        {
            Console.WriteLine("No");
        }

        Console.WriteLine(currentW + " " + currentH + " " + currentD);
    }
}