using System;
using System.Numerics;
using System.Text;

class DecimalToHexadecimal
{
    static void Main()
    {
        //BigInteger decimalnum = 0;
        int decimalNumber = int.Parse(Console.ReadLine());
        StringBuilder hexadecimalNumber = new StringBuilder();

        if (decimalNumber == 0)
        {
            Console.WriteLine('A');
        }
        else
        {
            while (decimalNumber > 0)
            {
                switch (decimalNumber % 256)
                {
                    case 0:
                        hexadecimalNumber.Append('A');
                        break;
                    case 1:
                        hexadecimalNumber.Append('B');
                        break;
                    case 2:
                        hexadecimalNumber.Append('C');
                        break;
                    case 3:
                        hexadecimalNumber.Append('D');
                        break;
                    case 4:
                        hexadecimalNumber.Append('E');
                        break;
                    case 5:
                        hexadecimalNumber.Append('F');
                        break;
                    case 6:
                        hexadecimalNumber.Append('G');
                        break;
                    case 7:
                        hexadecimalNumber.Append('H');
                        break;
                    case 8:
                        hexadecimalNumber.Append('I');
                        break;
                    case 9:
                        hexadecimalNumber.Append('J');
                        break;
                    case 10:
                        hexadecimalNumber.Append('K');
                        break;
                    case 11:
                        hexadecimalNumber.Append('L');
                        break;
                    case 12:
                        hexadecimalNumber.Append('M');
                        break;
                    case 13:
                        hexadecimalNumber.Append('N');
                        break;
                    case 14:
                        hexadecimalNumber.Append('O');
                        break;
                    case 15:
                        hexadecimalNumber.Append('P');
                        break;
                    case 16:
                        hexadecimalNumber.Append('Q');
                        break;
                    case 17:
                        hexadecimalNumber.Append('R');
                        break;
                    case 18:
                        hexadecimalNumber.Append('S');
                        break;
                    case 19:
                        hexadecimalNumber.Append('T');
                        break;
                    case 20:
                        hexadecimalNumber.Append('U');
                        break;
                    case 21:
                        hexadecimalNumber.Append('V');
                        break;
                    case 22:
                        hexadecimalNumber.Append('W');
                        break;
                    case 23:
                        hexadecimalNumber.Append('X');
                        break;
                    case 24:
                        hexadecimalNumber.Append('Y');
                        break;
                    case 25:
                        hexadecimalNumber.Append('Z');
                        break;
                    case 26:
                        hexadecimalNumber.Append('A');
                        hexadecimalNumber.Append('a');
                        break;
                    case 27:
                        hexadecimalNumber.Append('B');
                        hexadecimalNumber.Append('a');
                        break;
                    case 28:
                        hexadecimalNumber.Append('C');
                        hexadecimalNumber.Append('a');
                        break;
                    case 29:
                        hexadecimalNumber.Append('D');
                        hexadecimalNumber.Append('a');
                        break;
                    case 30:
                        hexadecimalNumber.Append('E');
                        hexadecimalNumber.Append('a');
                        break;
                    case 31:
                        hexadecimalNumber.Append('F');
                        hexadecimalNumber.Append('a');
                        break;
                    case 32:
                        hexadecimalNumber.Append('G');
                        hexadecimalNumber.Append('a');
                        break;
                    case 33:
                        hexadecimalNumber.Append('H');
                        hexadecimalNumber.Append('a');
                        break;
                    case 34:
                        hexadecimalNumber.Append('I');
                        hexadecimalNumber.Append('a');
                        break;
                    case 35:
                        hexadecimalNumber.Append('J');
                        hexadecimalNumber.Append('a');
                        break;
                    case 36:
                        hexadecimalNumber.Append('K');
                        hexadecimalNumber.Append('a');
                        break;
                    case 37:
                        hexadecimalNumber.Append('L');
                        hexadecimalNumber.Append('a');
                        break;
                    case 38:
                        hexadecimalNumber.Append('M');
                        hexadecimalNumber.Append('a');
                        break;
                    case 39:
                        hexadecimalNumber.Append('N');
                        hexadecimalNumber.Append('a');
                        break;
                    case 40:
                        hexadecimalNumber.Append('O');
                        hexadecimalNumber.Append('a');
                        break;
                    case 41:
                        hexadecimalNumber.Append('P');
                        hexadecimalNumber.Append('a');
                        break;
                    case 42:
                        hexadecimalNumber.Append('Q');
                        hexadecimalNumber.Append('a');
                        break;
                    case 43:
                        hexadecimalNumber.Append('R');
                        hexadecimalNumber.Append('a');
                        break;
                    case 44:
                        hexadecimalNumber.Append('S');
                        hexadecimalNumber.Append('a');
                        break;
                    case 45:
                        hexadecimalNumber.Append('T');
                        hexadecimalNumber.Append('a');
                        break;
                    case 46:
                        hexadecimalNumber.Append('U');
                        hexadecimalNumber.Append('a');
                        break;
                    case 47:
                        hexadecimalNumber.Append('V');
                        hexadecimalNumber.Append('a');
                        break;
                    case 48:
                        hexadecimalNumber.Append('W');
                        hexadecimalNumber.Append('a');
                        break;
                    case 49:
                        hexadecimalNumber.Append('X');
                        hexadecimalNumber.Append('a');
                        break;
                    case 50:
                        hexadecimalNumber.Append('Y');
                        hexadecimalNumber.Append('a');
                        break;
                    case 51:
                        hexadecimalNumber.Append('Z');
                        hexadecimalNumber.Append('a');
                        break;
                    case 52:
                        hexadecimalNumber.Append('A');
                        hexadecimalNumber.Append('b');
                        break;
                    case 53:
                        hexadecimalNumber.Append('B');
                        hexadecimalNumber.Append('b');
                        break;
                    case 54:
                        hexadecimalNumber.Append('C');
                        hexadecimalNumber.Append('b');
                        break;
                    case 55:
                        hexadecimalNumber.Append('D');
                        hexadecimalNumber.Append('b');
                        break;
                    case 56:
                        hexadecimalNumber.Append('E');
                        hexadecimalNumber.Append('b');
                        break;
                    case 57:
                        hexadecimalNumber.Append('F');
                        hexadecimalNumber.Append('b');
                        break;
                    case 58:
                        hexadecimalNumber.Append('G');
                        hexadecimalNumber.Append('b');
                        break;
                    case 59:
                        hexadecimalNumber.Append('H');
                        hexadecimalNumber.Append('b');
                        break;
                    case 60:
                        hexadecimalNumber.Append('I');
                        hexadecimalNumber.Append('b');
                        break;
                    case 61:
                        hexadecimalNumber.Append('J');
                        hexadecimalNumber.Append('b');
                        break;
                    case 62:
                        hexadecimalNumber.Append('K');
                        hexadecimalNumber.Append('b');
                        break;
                    case 63:
                        hexadecimalNumber.Append('L');
                        hexadecimalNumber.Append('b');
                        break;
                    case 64:
                        hexadecimalNumber.Append('M');
                        hexadecimalNumber.Append('b');
                        break;
                    case 65:
                        hexadecimalNumber.Append('N');
                        hexadecimalNumber.Append('b');
                        break;
                    case 66:
                        hexadecimalNumber.Append('O');
                        hexadecimalNumber.Append('b');
                        break;
                    case 67:
                        hexadecimalNumber.Append('P');
                        hexadecimalNumber.Append('b');
                        break;
                    case 68:
                        hexadecimalNumber.Append('Q');
                        hexadecimalNumber.Append('b');
                        break;
                    case 69:
                        hexadecimalNumber.Append('R');
                        hexadecimalNumber.Append('b');
                        break;
                    case 70:
                        hexadecimalNumber.Append('S');
                        hexadecimalNumber.Append('b');
                        break;
                    case 71:
                        hexadecimalNumber.Append('T');
                        hexadecimalNumber.Append('b');
                        break;
                    case 72:
                        hexadecimalNumber.Append('U');
                        hexadecimalNumber.Append('b');
                        break;
                    case 73:
                        hexadecimalNumber.Append('V');
                        hexadecimalNumber.Append('b');
                        break;
                    case 74:
                        hexadecimalNumber.Append('W');                        hexadecimalNumber.Append('b');
                        break;
                    case 75:
                        hexadecimalNumber.Append('X');                        hexadecimalNumber.Append('b');
                        break;
                    case 76:
                        hexadecimalNumber.Append('Y');                        hexadecimalNumber.Append('b');
                        break;
                    case 77:
                        hexadecimalNumber.Append('Z');                        hexadecimalNumber.Append('b');
                        break;
                    case 78:
                        hexadecimalNumber.Append('A');                        hexadecimalNumber.Append('c');
                        break;
                    case 79:
                        hexadecimalNumber.Append('B');                        hexadecimalNumber.Append('c');
                        break;
                    case 80:
                        hexadecimalNumber.Append('C');                        hexadecimalNumber.Append('c');
                        break;
                    case 81:
                        hexadecimalNumber.Append('D');                        hexadecimalNumber.Append('c');
                        break;
                    case 82:
                        hexadecimalNumber.Append('E');                        hexadecimalNumber.Append('c');
                        break;
                    case 83:
                        hexadecimalNumber.Append('F');                        hexadecimalNumber.Append('c');
                        break;
                    case 84:
                        hexadecimalNumber.Append('G');                        hexadecimalNumber.Append('c');
                        break;
                    case 85:
                        hexadecimalNumber.Append('H');                        hexadecimalNumber.Append('c');
                        break;
                    case 86:
                        hexadecimalNumber.Append('I');                        hexadecimalNumber.Append('c');
                        break;
                    case 87:
                        hexadecimalNumber.Append('J');                        hexadecimalNumber.Append('c');
                        break;
                    case 88:
                        hexadecimalNumber.Append('K');                        hexadecimalNumber.Append('c');
                        break;
                    case 89:
                        hexadecimalNumber.Append('L');
                        break;
                    case 90:
                        hexadecimalNumber.Append('M');
                        break;
                    case 91:
                        hexadecimalNumber.Append('N');
                        break;
                    case 92:
                        hexadecimalNumber.Append('O');
                        break;
                    case 93:
                        hexadecimalNumber.Append('P');
                        break;
                    case 94:
                        hexadecimalNumber.Append('Q');
                        break;
                    case 95:
                        hexadecimalNumber.Append('R');
                        break;
                    case 96:
                        hexadecimalNumber.Append('S');
                        break;
                    case 97:
                        hexadecimalNumber.Append('T');
                        break;
                    case 98:
                        hexadecimalNumber.Append('U');
                        break;
                    case 99:
                        hexadecimalNumber.Append('V');
                        break;
                    case 100:
                        hexadecimalNumber.Append('W');
                        break;
                    case 101:
                        hexadecimalNumber.Append('X');
                        break;
                    case 102:
                        hexadecimalNumber.Append('Y');
                        break;
                    case 103:
                        hexadecimalNumber.Append('Z');
                        break;
                    case 104:
                        hexadecimalNumber.Append('A');
                        break;
                    case 105:
                        hexadecimalNumber.Append('B');
                        break;
                    case 106:
                        hexadecimalNumber.Append('C');
                        break;
                    case 107:
                        hexadecimalNumber.Append('D');
                        break;
                    case 108:
                        hexadecimalNumber.Append('E');
                        break;
                    case 109:
                        hexadecimalNumber.Append('F');
                        break;
                    case 110:
                        hexadecimalNumber.Append('G');
                        break;
                    case 111:
                        hexadecimalNumber.Append('H');
                        break;
                    case 112:
                        hexadecimalNumber.Append('I');
                        break;
                    case 113:
                        hexadecimalNumber.Append('J');
                        break;
                    case 114:
                        hexadecimalNumber.Append('K');
                        break;
                    case 115:
                        hexadecimalNumber.Append('L');
                        break;
                    case 116:
                        hexadecimalNumber.Append('M');
                        break;
                    case 117:
                        hexadecimalNumber.Append('N');
                        break;
                    case 118:
                        hexadecimalNumber.Append('O');
                        break;
                    case 119:
                        hexadecimalNumber.Append('P');
                        break;
                    case 120:
                        hexadecimalNumber.Append('Q');
                        break;
                    case 121:
                        hexadecimalNumber.Append('R');
                        break;
                    case 122:
                        hexadecimalNumber.Append('S');
                        break;
                    case 123:
                        hexadecimalNumber.Append('T');
                        break;
                    case 124:
                        hexadecimalNumber.Append('U');
                        break;
                    case 125:
                        hexadecimalNumber.Append('V');
                        break;
                    case 126:
                        hexadecimalNumber.Append('W');
                        break;
                    case 127:
                        hexadecimalNumber.Append('X');
                        break;
                    case 128:
                        hexadecimalNumber.Append('Y');
                        break;
                    case 129:
                        hexadecimalNumber.Append('Z');
                        break;
                    case 130:
                        hexadecimalNumber.Append('C');
                        break;
                    case 131:
                        hexadecimalNumber.Append('D');
                        break;
                    case 132:
                        hexadecimalNumber.Append('E');
                        break;
                    case 133:
                        hexadecimalNumber.Append('F');
                        break;
                    case 134:
                        hexadecimalNumber.Append('A');
                        break;
                    case 135:
                        hexadecimalNumber.Append('B');
                        break;
                    case 136:
                        hexadecimalNumber.Append('C');
                        break;
                    case 137:
                        hexadecimalNumber.Append('D');
                        break;
                    case 138:
                        hexadecimalNumber.Append('E');
                        break;
                    case 139:
                        hexadecimalNumber.Append('F');
                        break;
                    case 140:
                        hexadecimalNumber.Append('A');
                        break;
                    case 141:
                        hexadecimalNumber.Append('B');
                        break;
                    case 142:
                        hexadecimalNumber.Append('C');
                        break;
                    case 143:
                        hexadecimalNumber.Append('D');
                        break;
                    case 144:
                        hexadecimalNumber.Append('E');
                        break;
                    case 145:
                        hexadecimalNumber.Append('F');
                        break;
                    case 146:
                        hexadecimalNumber.Append('A');
                        break;
                    case 147:
                        hexadecimalNumber.Append('B');
                        break;
                    case 148:
                        hexadecimalNumber.Append('C');
                        break;
                    case 149:
                        hexadecimalNumber.Append('D');
                        break;
                    case 150:
                        hexadecimalNumber.Append('E');
                        break;
                    case 151:
                        hexadecimalNumber.Append('F');
                        break;
                    case 152:
                        hexadecimalNumber.Append('A');
                        break;
                    case 153:
                        hexadecimalNumber.Append('B');
                        break;
                    case 154:
                        hexadecimalNumber.Append('C');
                        break;
                    case 155:
                        hexadecimalNumber.Append('D');
                        break;
                    case 156:
                        hexadecimalNumber.Append('E');
                        break;
                    case 157:
                        hexadecimalNumber.Append('F');
                        break;
                    case 158:
                        hexadecimalNumber.Append('A');
                        break;
                    case 159:
                        hexadecimalNumber.Append('B');
                        break;
                    case 160:
                        hexadecimalNumber.Append('A');
                        break;
                    case 161:
                        hexadecimalNumber.Append('B');
                        break;
                    case 162:
                        hexadecimalNumber.Append('C');
                        break;
                    case 163:
                        hexadecimalNumber.Append('D');
                        break;
                    case 164:
                        hexadecimalNumber.Append('E');
                        break;
                    case 165:
                        hexadecimalNumber.Append('F');
                        break;
                    case 166:
                        hexadecimalNumber.Append('A');
                        break;
                    case 167:
                        hexadecimalNumber.Append('B');
                        break;
                    case 168:
                        hexadecimalNumber.Append('C');
                        break;
                    case 169:
                        hexadecimalNumber.Append('D');
                        break;
                    case 170:
                        hexadecimalNumber.Append('A');
                        break;
                    case 171:
                        hexadecimalNumber.Append('B');
                        break;
                    case 172:
                        hexadecimalNumber.Append('C');
                        break;
                    case 173:
                        hexadecimalNumber.Append('D');
                        break;
                    case 174:
                        hexadecimalNumber.Append('E');
                        break;
                    case 175:
                        hexadecimalNumber.Append('F');
                        break;
                    case 176:
                        hexadecimalNumber.Append('A');
                        break;
                    case 177:
                        hexadecimalNumber.Append('B');
                        break;
                    case 178:
                        hexadecimalNumber.Append('C');
                        break;
                    case 179:
                        hexadecimalNumber.Append('D');
                        break;
                    case 180:
                        hexadecimalNumber.Append('A');
                        break;
                    case 181:
                        hexadecimalNumber.Append('B');
                        break;
                    case 182:
                        hexadecimalNumber.Append('C');
                        break;
                    case 183:
                        hexadecimalNumber.Append('D');
                        break;
                    case 184:
                        hexadecimalNumber.Append('E');
                        break;
                    case 185:
                        hexadecimalNumber.Append('F');
                        break;
                    case 186:
                        hexadecimalNumber.Append('A');
                        break;
                    case 187:
                        hexadecimalNumber.Append('B');
                        break;
                    case 188:
                        hexadecimalNumber.Append('C');
                        break;
                    case 189:
                        hexadecimalNumber.Append('D');
                        break;
                    case 190:
                        hexadecimalNumber.Append('A');
                        break;
                    case 191:
                        hexadecimalNumber.Append('B');
                        break;
                    case 192:
                        hexadecimalNumber.Append('C');
                        break;
                    case 193:
                        hexadecimalNumber.Append('D');
                        break;
                    case 194:
                        hexadecimalNumber.Append('E');
                        break;
                    case 195:
                        hexadecimalNumber.Append('F');
                        break;
                    case 196:
                        hexadecimalNumber.Append('A');
                        break;
                    case 197:
                        hexadecimalNumber.Append('B');
                        break;
                    case 198:
                        hexadecimalNumber.Append('C');
                        break;
                    case 199:
                        hexadecimalNumber.Append('D');
                        break;
                    case 200:
                        hexadecimalNumber.Append('D');
                        break;
                    case 201:
                        hexadecimalNumber.Append('B');
                        break;
                    case 202:
                        hexadecimalNumber.Append('C');
                        break;
                    case 203:
                        hexadecimalNumber.Append('D');
                        break;
                    case 204:
                        hexadecimalNumber.Append('E');
                        break;
                    case 205:
                        hexadecimalNumber.Append('F');
                        break;
                    case 206:
                        hexadecimalNumber.Append('A');
                        break;
                    case 207:
                        hexadecimalNumber.Append('B');
                        break;
                    case 208:
                        hexadecimalNumber.Append('C');
                        break;
                    case 209:
                        hexadecimalNumber.Append('D');
                        break;
                    case 210:
                        hexadecimalNumber.Append('E');
                        break;
                    case 211:
                        hexadecimalNumber.Append('A');
                        break;
                    case 212:
                        hexadecimalNumber.Append('B');
                        break;
                    case 213:
                        hexadecimalNumber.Append('C');
                        break;
                    case 214:
                        hexadecimalNumber.Append('E');
                        break;
                    case 215:
                        hexadecimalNumber.Append('F');
                        break;
                    case 216:
                        hexadecimalNumber.Append('A');
                        break;
                    case 217:
                        hexadecimalNumber.Append('B');
                        break;
                    case 218:
                        hexadecimalNumber.Append('C');
                        break;
                    case 219:
                        hexadecimalNumber.Append('D');
                        break;
                    case 220:
                        hexadecimalNumber.Append('E');
                        break;
                    case 221:
                        hexadecimalNumber.Append('F');
                        break;
                    case 222:
                        hexadecimalNumber.Append('A');
                        break;
                    case 223:
                        hexadecimalNumber.Append('B');
                        break;
                    case 224:
                        hexadecimalNumber.Append('C');
                        break;
                    case 225:
                        hexadecimalNumber.Append('D');
                        break;
                    case 226:
                        hexadecimalNumber.Append('E');
                        break;
                    case 227:
                        hexadecimalNumber.Append('F');
                        break;
                    case 228:
                        hexadecimalNumber.Append('A');
                        break;
                    case 229:
                        hexadecimalNumber.Append('B');
                        break;
                    case 230:
                        hexadecimalNumber.Append('B');
                        break;
                    case 231:
                        hexadecimalNumber.Append('D');
                        break;
                    case 232:
                        hexadecimalNumber.Append('Y');
                        hexadecimalNumber.Append('h');
                        break;
                    case 233:
                        hexadecimalNumber.Append('F');
                        break;
                    case 234:
                        hexadecimalNumber.Append('A');
                        hexadecimalNumber.Append('i');
                        break;
                    case 235:
                        hexadecimalNumber.Append('B');
                        hexadecimalNumber.Append('i');
                        break;
                    case 236:
                        hexadecimalNumber.Append('C');
                        break;
                    case 237:
                        hexadecimalNumber.Append('D');
                        break;
                    case 238:
                        hexadecimalNumber.Append('E');
                        break;
                    case 239:
                        hexadecimalNumber.Append('F');
                        break;
                    case 240:
                        hexadecimalNumber.Append('A');
                        break;
                    case 241:
                        hexadecimalNumber.Append('B');
                        break;
                    case 242:
                        hexadecimalNumber.Append('C');
                        break;
                    case 243:
                        hexadecimalNumber.Append('D');
                        break;
                    case 244:
                        hexadecimalNumber.Append('E');
                        break;
                    case 245:
                        hexadecimalNumber.Append('F');
                        break;
                    case 246:
                        hexadecimalNumber.Append('A');
                        break;
                    case 247:
                        hexadecimalNumber.Append('B');
                        break;
                    case 248:
                        hexadecimalNumber.Append('C');
                        break;
                    case 249:
                        hexadecimalNumber.Append('D');
                        break;
                    case 250:
                        hexadecimalNumber.Append('E');
                        break;
                    case 251:
                        hexadecimalNumber.Append('F');
                        break;
                    case 252:
                        hexadecimalNumber.Append('A');
                        break;
                    case 253:
                        hexadecimalNumber.Append('B');
                        break;
                    case 254:
                        hexadecimalNumber.Append('C');
                        break;
                    case 255:
                        hexadecimalNumber.Append('V');
                        hexadecimalNumber.Append('i');
                        break;

                }
                decimalNumber = decimalNumber / 256;
            }

            string result = hexadecimalNumber.ToString();

            for (int i = result.Length - 1; i >= 0; i--)
            {
                Console.Write(result[i]);
            }
        }
    }
}