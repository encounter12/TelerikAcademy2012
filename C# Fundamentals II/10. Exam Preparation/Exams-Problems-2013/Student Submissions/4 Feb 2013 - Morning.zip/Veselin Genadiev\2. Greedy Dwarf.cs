using System;

namespace GreedyDwarf
{
	class GreedyDwarf
	{
		static void Main(string[] args)
		{
			string[] vall = Console.ReadLine().Split(new char[] {','}, StringSplitOptions.RemoveEmptyEntries);
			int[] valley = new int[vall.GetLength(0)];
			for(int i=0;i<valley.Length;i++)
			{
				valley[i]=int.Parse(vall[i]);
			}
			int m = int.Parse(Console.ReadLine());
			string[] patterns = new string[m];
			for (int i = 0; i < m; i++)
			{
				patterns[i] = Console.ReadLine();
			}
			int sum = 0;
			int fullSum = 0;
			int maxSum = 0;
			int[] patt = new int[m];
			string[] pattr;
			bool[] visited = new bool[valley.Length];
			foreach (string pattern in patterns)
			{
				pattr = pattern.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
				patt = new int[pattr.GetLength(0)];
				for (int i = 0; i < pattr.GetLength(0); i++)
				{
					patt[i] = int.Parse(pattr[i]);
				}
				bool flag = false;
				int pos = 0;
				int j = 0;
				while (!flag)
				{
					if (j == patt.Length)
					{
						j = 0;
						fullSum += sum;
						sum = 0;
					}
					else if (pos >= visited.Length || pos < 0)
					{
						flag = true;
					}
					else if (visited[pos])
					{
						flag = true;
					}
					else
					{
						sum += valley[pos];
						visited[pos] = true;
						pos += patt[j];
						j++;
					}
				}
				if (maxSum < fullSum)
				{
					maxSum = fullSum;
				}
				sum = 0;
				fullSum = 0;
				visited = new bool[valley.Length];
			}
			Console.WriteLine(maxSum);
		}
	}
}