using System;
using System.Text.RegularExpressions;

class Slides
{
    static void Main(string[] args)
    {

        string line = Console.ReadLine();
        string[] tempTokens = line.Split(' ');
        int width = int.Parse(tempTokens[0]);
        int height = int.Parse(tempTokens[1]);
        int depth = int.Parse(tempTokens[2]);
        string[, ,] cube = new string[width, height, depth];
        for (int curHeight = 0; curHeight < height; curHeight++)
        {
            line = Console.ReadLine();
            tempTokens = line.Split('|');
            for (int curDepth = 0; curDepth < tempTokens.Length; curDepth++)
            {
                string oneWidth = tempTokens[curDepth].Trim(' ');
                string[] tokens3 = oneWidth.Split(new char[] { '(', ')' }, StringSplitOptions.RemoveEmptyEntries);
                for (int curWidth = 0; curWidth < tokens3.Length; curWidth++)
                {
                    cube[curWidth, curHeight, curDepth] = tokens3[curWidth];
                }
            }
        }

        line = Console.ReadLine();
        string[] ballTokens = line.Split(' ');
        int ballWidth = int.Parse(ballTokens[0]);
        int ballHeight = 0;
        int ballDepth = int.Parse(ballTokens[1]);



        //int width = 3;
        //int height = 3;
        //int depth = 3;
        //string[,,] cube = new string[width, height, depth];
        //hardInput(cube);
        //int ballWidth = 1;
        //int ballHeight = 0;
        //int ballDepth = 0;

        while (true)
        {
            string currentPositionText = cube[ballWidth, ballHeight, ballDepth];
            if (currentPositionText.StartsWith("E"))
            {
                ballHeight++;
                if (ballHeight == height)
                {
                    Console.WriteLine("Yes");
                    Console.WriteLine("{0} {1} {2}", ballWidth, ballHeight-1, ballDepth);
                    return;
                }
            }
            else if (currentPositionText.StartsWith("S"))
            {
                string[] tokens = currentPositionText.Split(' ');
                int lastWidth = ballWidth, lastHeight = ballHeight, lastDepth = ballDepth;
                switch (tokens[1])
                {
                    case "F":
                        if (ballDepth - 1 < 0)
                        {
                            Console.WriteLine("No");
                            Console.WriteLine("{0} {1} {2}", lastWidth, lastHeight, lastDepth);
                            return;
                        }
                        ballDepth--;
                        break;
                    case "FL":
                        if (ballDepth - 1 < 0 || ballWidth - 1 < 0)
                        {
                            Console.WriteLine("No");
                            Console.WriteLine("{0} {1} {2}", lastWidth, lastHeight, lastDepth);
                            return;
                        }
                        ballDepth--;
                        ballWidth--;
                        break;
                    case "FR":
                        if (ballDepth - 1 < 0 || ballWidth + 1 >= width)
                        {
                            Console.WriteLine("No");
                            Console.WriteLine("{0} {1} {2}", lastWidth, lastHeight, lastDepth);
                            return;
                        }
                        ballDepth--;
                        ballWidth++;
                        break;
                    case "B":
                        if (ballDepth + 1 >= depth)
                        {
                            Console.WriteLine("No");
                            Console.WriteLine("{0} {1} {2}", lastWidth, lastHeight, lastDepth);
                            return;
                        }
                        ballDepth++;
                        break;
                    case "BL":
                        if (ballDepth + 1 >= depth || ballWidth-1 < 0)
                        {
                            Console.WriteLine("No");
                            Console.WriteLine("{0} {1} {2}", lastWidth, lastHeight, lastDepth);
                            return;
                        }
                        ballDepth++;
                        ballWidth--;
                        break;
                    case "BR":
                        if (ballDepth + 1 >= depth || ballWidth + 1 >= width)
                        {
                            Console.WriteLine("No");
                            Console.WriteLine("{0} {1} {2}", lastWidth, lastHeight, lastDepth);
                            return;
                        }
                        ballDepth++;
                        ballWidth++;
                        break;
                    case "L":
                        if (ballWidth - 1 < 0)
                        {
                            Console.WriteLine("No");
                            Console.WriteLine("{0} {1} {2}", lastWidth, lastHeight, lastDepth);
                            return;
                        }
                        ballWidth--;
                        break;
                    case "R":
                        if (ballWidth + 1 >= width)
                        {
                            Console.WriteLine("No");
                            Console.WriteLine("{0} {1} {2}", lastWidth, lastHeight, lastDepth);
                            return;
                        }
                        ballWidth++;
                        break;
                }
                ballHeight++;
                if (ballHeight == height)
                {
                    Console.WriteLine("Yes");
                    Console.WriteLine("{0} {1} {2}", lastWidth, lastHeight, lastDepth);
                    return;
                }
            }
            else if (currentPositionText.StartsWith("T"))
            {
                string[] tokens = currentPositionText.Split(' ');
                ballWidth = int.Parse(tokens[1]);
                ballDepth = int.Parse(tokens[2]);
            }
            else if (currentPositionText.StartsWith("B"))
            {
                Console.WriteLine("No");
                Console.WriteLine("{0} {1} {2}", ballWidth, ballHeight, ballDepth);
                return;

            }
        }

        
    }

    //public static void hardInput(string[, ,] cube)
    //{
    //    // top row
    //    cube[0, 0, 0] = "S L";
    //    cube[1, 0, 0] = "E";
    //    cube[2, 0, 0] = "S L";
    //    cube[0, 0, 1] = "S L";
    //    cube[1, 0, 1] = "S R";
    //    cube[2, 0, 1] = "S L";
    //    cube[0, 0, 2] = "B";
    //    cube[1, 0, 2] = "S F";
    //    cube[2, 0, 2] = "S L";

    //    //middle row
    //    cube[0, 1, 0] = "S B";
    //    cube[1, 1, 0] = "S R";
    //    cube[2, 1, 0] = "E";
    //    cube[0, 1, 1] = "S B";
    //    cube[1, 1, 1] = "S F";
    //    cube[2, 1, 1] = "T 1 1";
    //    cube[0, 1, 2] = "S L";
    //    cube[1, 1, 2] = "S R";
    //    cube[2, 1, 2] = "B";

    //    //bottom row
    //    cube[0, 2, 0] = "S FL";
    //    cube[1, 2, 0] = "S FL";
    //    cube[2, 2, 0] = "B";
    //    cube[0, 2, 1] = "S FL";
    //    cube[1, 2, 1] = "S FL";
    //    cube[2, 2, 1] = "S FR";
    //    cube[0, 2, 2] = "S F";
    //    cube[1, 2, 2] = "S BR";
    //    cube[2, 2, 2] = "S FR";

    //}

    public static void hardInput(string[,,] cube)
    {
        // top row
        cube[0, 0, 0] = "S L";
        cube[1, 0, 0] = "E";
        cube[2, 0, 0] = "S L";

        cube[0, 0, 1] = "S L";
        cube[1, 0, 1] = "S R";
        cube[2, 0, 1] = "S L";

        cube[0, 0, 2] = "B";
        cube[1, 0, 2] = "S F";
        cube[2, 0, 2] = "S L";

        //middle row
        cube[0, 1, 0] = "S B";
        cube[1, 1, 0] = "S R";
        cube[2, 1, 0] = "E";

        cube[0, 1, 1] = "S B";
        cube[1, 1, 1] = "S F";
        cube[2, 1, 1] = "T 1 1";

        cube[0, 1, 2] = "S L";
        cube[1, 1, 2] = "S R";
        cube[2, 1, 2] = "B";

        //bottom row
        cube[0, 2, 0] = "S FL";
        cube[1, 2, 0] = "S FL";
        cube[2, 2, 0] = "B";

        cube[0, 2, 1] = "S FL";
        cube[1, 2, 1] = "S FL";
        cube[2, 2, 1] = "S FR";

        cube[0, 2, 2] = "S F";
        cube[1, 2, 2] = "S BR";
        cube[2, 2, 2] = "S FR";
    }
}
