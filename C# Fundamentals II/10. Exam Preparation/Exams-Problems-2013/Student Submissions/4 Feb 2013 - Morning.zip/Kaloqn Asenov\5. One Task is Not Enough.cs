using System;
 
class OneTaskIsNotEnough
{
    static void Main()
    {
        int arrayLength = int.Parse(Console.ReadLine());
        string firstInstructions = Console.ReadLine();
        string secondInstructions = Console.ReadLine();
        //int arrayLength = 12;
 
        bool[] shiningLights = new bool[arrayLength];
 
        for (int i = 0; i < arrayLength; i++)
        {
            shiningLights[i] = false;
        }
 
        int step = 1;
        int lastLightLightened = 0;
        bool notASingleLightLightened = false;
 
        while (!notASingleLightLightened) // lights shining
        {
            step++;
 
            int temp = step;
            notASingleLightLightened = true;
 
            for (int i = 0; i < arrayLength; i++, temp--)
            {
                bool lighted = false;
 
                if (temp == 0)
                {
                    temp = step;
                }
 
                if ((shiningLights[i] == false) && (temp == step))
                {
                    shiningLights[i] = true;
                    lastLightLightened = i;
                    lighted = true;
                    notASingleLightLightened = false;
                }
 
                if ((shiningLights[i] == true) && (lighted == false))
                {
                    temp++;
                }
            }
        }
 
        Console.WriteLine(lastLightLightened + 1);
        Console.WriteLine("bounded");
        Console.WriteLine("bounded");
    }
}