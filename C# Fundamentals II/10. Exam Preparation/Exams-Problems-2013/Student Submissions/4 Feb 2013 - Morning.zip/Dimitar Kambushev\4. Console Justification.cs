using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class Program
{
    static void Main(string[] args)
    {
        int lines = int.Parse(Console.ReadLine());
        int symbols = int.Parse(Console.ReadLine());

        List<string> file = new List<string>();
        for (int i = 0; i < lines; i++)
        {
            string red = Console.ReadLine();
            string[] dumi = red.Split(new Char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            for (int j = 0; j < dumi.Length; j++)
            {
                file.Add(dumi[j]);
            }
        }
        //Console.WriteLine(file);
        int emptySpaces;
        int numberWords = 0;
        int counterElem = 0;
        int counterSym = 0;
        StringBuilder write = new StringBuilder();
        while (counterElem < file.Count)
        {
            while (counterSym + file[counterElem].Length <= symbols)
            {
                counterSym += file[counterElem].Length + 1;
                numberWords++;
                counterElem++;
                if (counterElem == file.Count)
                {
                    break;
                }
            }
            if (numberWords == 1)
            {
                write.Append(file[counterElem - 1]);
            }
            else
            {
                int onlyW = 0;
                for (int i = 0; i < numberWords; i++)
                {
                    onlyW += file[counterElem - 1 - i].Length;
                }
                emptySpaces = symbols - onlyW;
                for (int i = 0; i < numberWords; i++)
                {
                    write.Append(file[counterElem - numberWords + i]);
                    if (i != numberWords - 1)
                    {
                        if (i < emptySpaces % (numberWords - 1))
                        {
                            write.Append(new String(' ', emptySpaces / (numberWords - 1) + 1));
                        }
                        else
                        {
                            write.Append(new String(' ', emptySpaces / (numberWords - 1)));
                        }
                    }
                }
                onlyW = 0;
            }
            Console.WriteLine(write);
            numberWords = 0;
            counterSym = 0;
            write = new StringBuilder();
        }
    }
}