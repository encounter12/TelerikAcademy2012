using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        StringBuilder sb =new StringBuilder();
        while (true)
        {
            char ch = Convert.ToChar(Console.Read());
            sb.Append(ch);
            if (ch == '\n')
            {
                break;
            }
        }
        string valleyInput = sb.ToString();
        string[] separator = { " ", ",","\n","\r"};
        string[] result = new string[100000];
        result =  valleyInput.Split(separator, StringSplitOptions.RemoveEmptyEntries);
        int[] valley = new int[100000];
        for (int i = 0; i < result.Length; i++)
        {
            valley[i] = int.Parse(result[i]);
        }
        List<int> collectedSum = new List<int>();
        int m = int.Parse(Console.ReadLine());
        int maxSum = 0;
        while (m > 0)
        {
            bool[] visited = new bool[100000];
            string patternInput = Console.ReadLine();
            string[] patternRes = patternInput.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            int[] pattern = new int[100000];
            for (int i = 0; i < patternRes.Length; i++)
            {
                pattern[i] = int.Parse(patternRes[i]);
            }
            int patternIndex = 0;
            int currIndex = 0;
            int temp = 0;
            collectedSum.Add(valley[currIndex]);
            visited[currIndex] = true;
            while (true)
            {
                temp = pattern[patternIndex++];
                currIndex += temp;
                if (!visited[currIndex])
                {
                    visited[currIndex] = true;
                }
                else
                {
                    int sum = 0;
                    for (int i = 0; i < collectedSum.Count; i++)
                    {
                        sum += collectedSum[i];
                    }
                    if (sum > maxSum)
                    {
                        maxSum = sum;
                    }
                    collectedSum.Clear();
                    break;
                }
                if (currIndex < 0 || currIndex > valley.Length)
                {
                    int sum = 0;
                    for (int i = 0; i < collectedSum.Count; i++)
                    {
                        sum += collectedSum[i];
                    }
                    if (sum > maxSum)
                    {
                        maxSum = sum;
                    }
                    collectedSum.Clear();
                    break;
                }
                collectedSum.Add(valley[currIndex]);
                if (patternIndex == pattern.Length)
                {
                    patternIndex = 0;
                }
            }
            m--;
        }
        Console.WriteLine(maxSum);
    }
}