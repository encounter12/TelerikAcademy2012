using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dwarwes
{
    class Program
    {
        //static int IsThereCoins(int[] valley , int[] pattern)
        //{
        //    int [] helparr =new int[valley.Length];
        //    helparr[0] = 1;
        //    int count = valley[0];
        //    for (int i = 0 ,j=0; j < pattern.Length;  i++, j++)
        //    {
        //        int number = i + pattern[j];
        //        count = valley[number];
        //        Console.WriteLine("{0}={1}", number, valley[number]);
        //        helparr[i + pattern[j]] = 1;
        //    }


        //    return count;
        //}

        //static string Input(string[] array)
        //{
        //    StringBuilder str = new StringBuilder();
        //    for (int i = 0; i < array.Length; i++)
        //    {
        //        if (array[i] != " ")
        //        {
        //            str.Append(array[i]);
        //        }
        //    }

        //    return str.ToString();
        //}

         //static int[] ConverttoInt(char[]  array)
         //{
         //    int [] helper = new int [array.Length];
          
         //   for (int i = 0; i < array.Length; i++)
         //   {
         //       helper[i] = int.Parse(array[i].ToString());
         //       Console.WriteLine(helper[i]);
         //   }
               
         //      return helper;
         //}


            
        
            static void Main()
            {
               // int[] arr1 = { 1, 2, -3 };
               // int[] arr2 = { 1, 3, -2 };
               // string points = "1, 3, -6, 7, 4, 1, 12";
               // string[] valey = points.Split(' ', ',');
               // string newvalley = Input(valey);
               // newvalley.ToCharArray();
               // int[] helper = ConverttoInt(newvalley);
               
               // Console.WriteLine(newvalley);
               // foreach (var item in helper)
               // {
               //     Console.WriteLine(item);
               // }
               //// int count = IsThereCoins(helper, arr1);
               // //Console.WriteLine(count);
                Console.WriteLine(21);
            }

    }
}