using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slides
{
    class Slides
    {
        static Dictionary<string, int[]> Slidecommands = new Dictionary<string, int[]>()
        {
            {"S L",new int[] {-1,0}},
            {"S R",new int[] {1,0}},
            {"S F",new int[] {0,-1}},
            {"S B",new int[] {0,1}},
            {"S BL",new int[] {-1,1}},
            {"S BR",new int[] {1,1}},
            {"S FL",new int[] {-1,-1}},
            {"S FR",new int[] {1,-1}},
        };
        static void Main()
        {
            string[] input = Console.ReadLine().Split(new char[]{' '}, StringSplitOptions.RemoveEmptyEntries);
            int W = int.Parse(input[0]);
            int H = int.Parse(input[1]);
            int D = int.Parse(input[2]);
            string[, ,] cube = new string[W, H, D];
            for (int i = 0; i < H; i++)
            {
                input = Console.ReadLine().Split(new char[] {'|' }, StringSplitOptions.RemoveEmptyEntries);
                for (int j = 0; j < D; j++)
                {
                    string[] sequences = input[j].Trim().Split(new char[] { '(', ')' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int k = 0; k < W; k++)
                    {
                        cube[k, i, j] = sequences[k];
                    }
                }
            }
            input = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int ballW = int.Parse(input[0]);
            int ballD = int.Parse(input[1]);
            int ballH = 0;
            bool canExit = true;
            while (true)
            {
                //if (ballH<0 || ballH>=H)
                //{
                //    break;
                //}
                //if (ballW < 0 || ballW >= W)
                //{
                //    break;
                //}
                //if (ballD < 0 || ballD >= D)
                //{
                //    break;
                //}
                if (cube[ballW,ballH,ballD]=="B")
                {
                    canExit = false;
                    break;
                    
                }
                if (cube[ballW,ballH,ballD]=="E")
                {
                    if (ballH==H-1)
                    {
                        break;
                    }
                    ballH++;
                    continue;
                }
                if (cube[ballW,ballH,ballD][0]=='T')
                {
                    string[] teleport = cube[ballW, ballH, ballD].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    int newW = int.Parse(teleport[1]);
                    int newD = int.Parse(teleport[2]);
                    if (newW < 0 || newW >= W)
                    {
                        break;
                    }
                    if (newD < 0 || newD >= D)
                    {
                        break;
                    }
                    ballW = newW;
                    ballD = newD;
                    continue;
                }
                if (ballH==H-1)
                {
                    break;
                }
                int newWidth = ballW + Slidecommands[cube[ballW, ballH, ballD]][0];
                if (newWidth >= W || newWidth < 0)
                {
                    canExit = false;
                    break;
                    
                }
                int newDepth = ballD + Slidecommands[cube[ballW, ballH, ballD]][1];
                if (newDepth >= D || newDepth < 0)
                {
                    canExit = false;
                    break;

                }
                ballW = newWidth;
                ballD = newDepth;
                ballH++;
            }
            if (canExit)
            {
                Console.WriteLine("Yes");
            }
            else
            {
                Console.WriteLine("No");
            }
            Console.WriteLine("{0} {1} {2}", ballW, ballH, ballD);
        }
    }
}
