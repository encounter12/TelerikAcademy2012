using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace greedydwarf
{
    class Program
    {
        static void Main()
        {
            string text = Console.ReadLine();
            char[] delimiterChars = { ',', ' ' };//obrabotkata na stringa (i za patternite shte e sashtia)
            string[] words = text.Split(delimiterChars, StringSplitOptions.RemoveEmptyEntries);
            int[] valley = new int[words.Length];
            for (int i = 0; i < words.Length; i++)
            {
                valley[i] = int.Parse(words[i]);
            }
            //int[] valley = { 1, 3, -6, 7, 4, 1, 12 };
            int sum = 0; //sumata na konkretnia pattern
            int[] results = new int[100];
            int patternNumber = int.Parse(Console.ReadLine()); //Console.ReadLine(); //broi na patternite

            for (int p = 1; p <= patternNumber; p++)//ot edno do broya v primera 3 pati
            {
                string textPattern = Console.ReadLine();//4eta parvia pattern i go proveriavam kolko dava, maxa go returnvam izvan cikala :)
                string[] wordsPattern = textPattern.Split(delimiterChars, StringSplitOptions.RemoveEmptyEntries);
                int[] pattern = new int[wordsPattern.Length];
                for (int i = 0; i < wordsPattern.Length; i++)
                {
                    pattern[i] = int.Parse(wordsPattern[i]);
                }

                int[] pattern1000 = new int[1000];//pravia masiv s pattern do kraya, za da se povtaria sas sigurnost :)
                int counter = 0;
                for (int j = 0; j < pattern1000.Length; )//da napravia array ot patterna do 1000
                {
                    if (counter < pattern.Length)
                    { pattern1000[j] = pattern[counter]; counter++; j++; }
                    else { counter = 0; }
                }

                //Tragvam s patterna iz dolinata//
                int currPosition = 0;
                int nextMove = pattern1000[0];

                if (NextMoveInRange(valley, currPosition, nextMove) == true)//vtoria metod da e true
                {
                    if (NotBeenThere(valley, currPosition) == true)
                    {

                        for (int k = 0; k < valley.Length; k++)//pove4e iteracii ot valey niama kak da pravi
                        {
                            sum += valley[currPosition];//sumata e sbora na vsiki pozicii koito sa ok
                            valley[currPosition] = 0; //kato sumiram si nuliram :)
                            currPosition += pattern1000[k];//sledvahtata stapka e tekushtta pozicia + stoinostta na patterna...
                        }
                    }
                }
            }
            Console.WriteLine(sum);

        }

        static bool NotBeenThere(int[] valley, int currentPosition)//proveriavam dali sam stapval na tazi pozicia, sire4 e nuli4ka
        {
            if (valley[currentPosition] != 0) { return true; }
            else { return false; }
        }

        static bool NextMoveInRange(int[] valley, int currentPosition, int nextMove)//proveriavam dali sledvashtata stapka niama da me hvarli izvan masiva
        {                                                              //dali da gledam nazad....
            if (((currentPosition + nextMove) <= valley.Length) && ((currentPosition + nextMove) >= 0)) { return true; }
            else { return false; }//out of range- prikluchvame
        }
    }
}
