using System;
using System.Collections.Generic;
using System.Text;

class Justification
{
    static void Main()
    {
        int lines = int.Parse(Console.ReadLine());
        int symbolsOnLine = int.Parse(Console.ReadLine());
        List<string> wordsList = new List<string>();
        string textString = "1";
        for (int i = 0; i < lines; i++)
        {
            textString = Console.ReadLine();
            string[] words = textString.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            wordsList.AddRange(words);
        }
        StringBuilder sb = new StringBuilder();
        StringBuilder sbFinal = new StringBuilder();
        int maxIndex = 0;
        int spaces= 0;
        for (int i = 0; wordsList.Count > 0; i++)
        {
            spaces = 0;
            for (int j = 0; j < wordsList.Count; j++)
            {
                if (sb.Length + wordsList[j].Length > symbolsOnLine)
                {
                    break;
                }
                sb.Append(wordsList[j]);
                sb.Append(" ");
                spaces++;                
                maxIndex = j;
            }

            int moreSpaces = symbolsOnLine - sb.Length + 1;
            sb.Clear();
            for (int j = 0; j <= maxIndex; j++)
            {
                if (wordsList.Count == 1)
                {
                    sb.Append(wordsList[j]);
                }
                else if (maxIndex == 0)
                {
                    sb.Append(wordsList[j]);                    
                }
                else
                {
                    sb.Append(wordsList[j]);
                    for (int k = 0; k < spaces % maxIndex; k++)
                    {
                        if (sb.Length < symbolsOnLine)
                        {
                            sb.Append(" ");
                        }
                    }
                    int num = moreSpaces;
                    int dobavka = 0;
                    //if (moreSpaces%spaces != 0  && moreSpaces > 0 )
                    //{
                    //    dobavka = moreSpaces / spaces;
                    //}
                    for (int r = 0; r <= num/spaces; r++)
                    {
                        sb.Append(" ");
                        moreSpaces--;
                    }
                    if (dobavka > 0)
                    {
                        sb.Append(" ");
                        dobavka--;
                    }

                    //if (moreSpaces > 0 && sb.Length <= symbolsOnLine)
                    //{
                    //    sb.Append(" ");
                    //}
                    //moreSpaces--;
                    //if (moreSpaces > 0)
                    //{
                        
                    //}
                    
                }
            }
            wordsList.RemoveRange(0, maxIndex+1);
            sbFinal.Append(sb.ToString());
            sbFinal.Append("\n");
            sb.Clear();
        }
        Console.WriteLine(sbFinal.ToString());
    }
}

