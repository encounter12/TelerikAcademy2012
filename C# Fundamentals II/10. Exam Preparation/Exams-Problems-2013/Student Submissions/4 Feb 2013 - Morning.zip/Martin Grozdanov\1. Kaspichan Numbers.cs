using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;


class problem1
{
    private static string digit (BigInteger digit)
    {
        string final = "";
        long lower = (long)digit / 26;
        long upper = (long)digit % 26;
        switch (lower)
        {
            case 0:
                break;
            case 1:
                final += 'a';
                break;
            case 2:
                final += 'b';
                break;
            case 3:
                final += 'c';
                break;
            case 4:
                final += 'd';
                break;
            case 5:
                final += 'e';
                break;
            case 6:
                final += 'f';
                break;
            case 7:
                final += 'g';
                break;
            case 8:
                final += 'h';
                break;
            case 9:
                final += 'i';
                break;
            default:
                break;
        }
        switch (upper)
        {
            case 0:
                final += 'A';
                break;
            case 1:
                final += 'B';
                break;
            case 2:
                final += 'C';
                break;
            case 3:
                final += 'D';
                break;
            case 4:
                final += 'E';
                break;
            case 5:
                final += 'F';
                break;
            case 6:
                final += 'G';
                break;
            case 7:
                final += 'H';
                break;
            case 8:
                final += 'I';
                break;
            case 9:
                final += 'J';
                break;
            case 10:
                final += 'K';
                break;
            case 11:
                final += 'L';
                break;
            case 12:
                final += 'M';
                break;
            case 13:
                final += 'N';
                break;
            case 14:
                final += 'O';
                break;
            case 15:
                final += 'P';
                break;
            case 16:
                final += 'Q';
                break;
            case 17:
                final += 'R';
                break;
            case 18:
                final += 'S';
                break;
            case 19:
                final += 'T';
                break;
            case 20:
                final += 'U';
                break;
            case 21:
                final += 'V';
                break;
            case 22:
                final += 'W';
                break;
            case 23:
                final += 'X';
                break;
            case 24:
                final += 'Y';
                break;
            case 25:
                final += 'Z';
                break;
            default:
                break;
        }
        return final;
    }

    static void calculate(BigInteger number)
    {
        List<string> output = new List<string>();
        for (BigInteger i = number; i > 0; i /= 256)
        {
            long d = (long)i % 256;
            output.Add(digit(d));
        }
        for (int i = output.Count - 1; i >= 0; i--)
        {
            Console.Write(output[i]);
        }
    }

    static void Main(string[] args)
    {
        BigInteger number = BigInteger.Parse(Console.ReadLine());
        
        calculate(number);
       
    }

    
}
