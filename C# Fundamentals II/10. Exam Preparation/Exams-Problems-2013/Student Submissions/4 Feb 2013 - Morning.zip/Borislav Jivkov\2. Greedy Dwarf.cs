using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Greedy
{
    class Greedy
    {
        static void Main(string[] args)
        {
            BigInteger[] valley = GetValley();
            int n = int.Parse(Console.ReadLine());
            List<BigInteger> sums = new List<BigInteger>();
            for (int i = 0; i < n; i++)
            {
                int[] pattern = GetPattern();
                sums.Add(GetPatternSum(valley,pattern));
            }
            Console.WriteLine(sums.Max());
        }

        static BigInteger[] GetValley()
        {
            string[] input = Console.ReadLine().Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            BigInteger[] result = new BigInteger[input.Length];
            for (int i = 0; i < input.Length; i++)
            {
                result[i] = int.Parse(input[i]);
            }
            return result;
        }

        static int[] GetPattern()
        {
            string[] tmp = Console.ReadLine().Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            int[] result = new int[tmp.Length];
            for (int i = 0; i < tmp.Length; i++)
            {
                result[i] = int.Parse(tmp[i]);
            }
            return result;
        }

        static BigInteger GetPatternSum(BigInteger[] v, int[] p)
        {
            bool exit = false;
            BigInteger curSum1 = v[0];
            BigInteger maxSum1 = -100000000000;
            BigInteger curSum2 = v[v.Length - 1];
            BigInteger maxSum2 = -10000000000000;
            int visited = 101010;
            int start1 = 0;
            int start2 = (int)v[v.Length - 1];
            for (int i = 0; i < p.Length; i++)
            {
                if (exit)
                {
                    break;
                }
                else
                {
                    start1 += p[i];
                    if ((v[start1] == visited) || (start1 >= v.Length))
                    {
                        exit = true;
                        break;
                    }
                    else
                    {
                        curSum1 += v[start1];
                        v[start1] = visited;
                        if (curSum1 > maxSum1)
                        {
                            maxSum1 = curSum1;
                        }
                    }
                }
            }
            if (exit == false)
            {
                for (int i = 0; i < p.Length; i++)
                {
                    if (exit)
                    {
                        break;
                    }
                    else
                    {
                        start2 -= p[i];
                        if ((v[start1] == visited) || (start1 >= v.Length) || (start1 < 0))
                        {
                            exit = true;
                            break;
                        }
                        else
                        {
                            curSum2 += v[start2];
                            v[start2] = visited;
                            if (curSum2 > maxSum2)
                            {
                                maxSum2 = curSum2;
                            }
                        }
                    }
                }
            }
            if (maxSum2 >= 0)
            {
                return maxSum1 + maxSum2;
            }
            else
            {
                return maxSum1;
            }
        }
    }
}
