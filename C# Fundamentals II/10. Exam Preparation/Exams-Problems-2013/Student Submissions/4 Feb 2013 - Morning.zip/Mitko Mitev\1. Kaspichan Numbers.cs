using System;
using System.Numerics;
using System.Text;

    class Program
    {
        static void Main()
        {

            BigInteger number = BigInteger.Parse(Console.ReadLine());
            BigInteger originalNum = number;

            StringBuilder kaspNum = new StringBuilder();
            StringBuilder bigKaspNum = new StringBuilder();
            if (number <26)
            {
                number=number+'A';
                Console.Write((char)number);
            }


            else if (number < 256)
            {
                while (number > 0)
                {
                    if (number < 26)
                    {
                        kaspNum.Append((char)((number - 1) + 'a'));
                        number /= 26;
                    }
                    else
                    {
                        kaspNum.Append((char)((number % 26) + 'A'));
                        number /= 26;
                    }
                }
            }

            else
            {
                while (number >= 256)
                {
                    bigKaspNum.Append((char)((number / 256) + 'A'));
                    number %= 256;
                }

                while (number > 0)
                {
                    if (number < 26)
                    {
                        if (originalNum > 512)
                        {
                            kaspNum.Append((char)((number-1) + 'a'));
                            number /= 26;
                        }
                        else
                        {
                            kaspNum.Append((char)((number) + 'A'));
                            number /= 26;
                        }
                    }
                    else
                    {
                        kaspNum.Append((char)((number % 26) + 'A'));
                        number /= 26;
                    }
                }
            }
            if (originalNum < 256)
            {
                string stringNum = kaspNum.ToString();
                string endNum=null;
                for (int i = stringNum.Length - 1; i > -1; i--)
                {
                    endNum = endNum + stringNum[i];
                }
                Console.WriteLine(endNum);
            }
            else
            {
                string firstPart = bigKaspNum.ToString();
              
                string firstEndNum = null;
                for (int j = 0; j < firstPart.Length; j++)
                {
                    firstEndNum = firstEndNum + firstPart[j];
                }

                string stringNum = kaspNum.ToString();
                string endNum = null;
                for (int i = stringNum.Length - 1; i > -1; i--)
                {
                    endNum = endNum + stringNum[i];
                }
                Console.WriteLine(firstEndNum+endNum);
            }

            

        }
    }
