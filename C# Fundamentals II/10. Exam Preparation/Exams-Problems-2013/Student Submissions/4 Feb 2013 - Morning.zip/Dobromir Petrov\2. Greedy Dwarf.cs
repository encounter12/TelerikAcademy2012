using System;
using System.Collections.Generic;

class GreedyDwarf
{
    static void Main()
    {
        string[] valleyArrStr = Console.ReadLine().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        long[] valleyArray = new long[valleyArrStr.Length];
        for (int i = 0; i < valleyArrStr.Length; i++)
        {
            valleyArray[i] = int.Parse(valleyArrStr[i]);
        }
        //top int array of valley;

        int numberOfPatterns = int.Parse(Console.ReadLine());
        var indexes = new List<int>[numberOfPatterns] ;

        for (int i = 0; i < numberOfPatterns; i++)
        {
            indexes[i] = new List<int>();
            string patternStr = Console.ReadLine();
            if (patternStr == "")
            {
                continue;
            }
            string[] patternArr = patternStr.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            for (int j = 0; j < patternArr.Length; j++)
            {
                indexes[i].Add(int.Parse(patternArr[j]));
            }
        }
        //top array of lists

        //calculation
        long maxSum = 0;

        for (int i = 0; i < numberOfPatterns; i++)
        {
            int currentIndex = 0, lastIndex = 0, j = 0;
            long sum = valleyArray[0];
            bool[] visited = new bool[valleyArrStr.Length];

            while (true)
            {
                j %= indexes[i].Count;

                visited[0] = true;
                currentIndex = indexes[i][j] + lastIndex;
                if (currentIndex > valleyArray.Length - 1 || currentIndex < 0)
                {
                    break;
                }
                if (!visited[currentIndex])
                {
                    if (currentIndex > valleyArray.Length - 1)
                    {
                        break;
                    }

                    sum += valleyArray[currentIndex];
                    visited[currentIndex] = true;
                    lastIndex = currentIndex;
                    j++;
                    
                }
                else
                    break;
            }
            if (sum > maxSum)
            {
                maxSum = sum;
            }
        }
        Console.WriteLine(maxSum);
    }
}