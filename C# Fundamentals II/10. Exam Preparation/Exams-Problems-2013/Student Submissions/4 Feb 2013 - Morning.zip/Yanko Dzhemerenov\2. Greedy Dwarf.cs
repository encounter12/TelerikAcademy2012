using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        string[] forParse = Console.ReadLine().Split(',');
        int[] valey = new int[forParse.Length];
        for (int i = 0; i < forParse.Length; i++)
        {
            valey[i] = int.Parse(forParse[i]);
        }
        int countOfPatterns = int.Parse(Console.ReadLine());
        int[][] patterns = new int[countOfPatterns][];
        
        for (int i = 0; i < countOfPatterns; i++)
        {
            forParse = Console.ReadLine().Split(new char[]{','}, StringSplitOptions.RemoveEmptyEntries);
            patterns[i] = new int[forParse.Length];
            
            for (int c = 0; c < forParse.Length; c++)
            {
                patterns[i][c] = int.Parse(forParse[c]);
            }
        }
        bool[] notPassed = new bool[valey.Length];
        int maxSum = int.MinValue;
        for (int i = 0; i < patterns.Length; i++)
        {
            int sum = 0;
            int pos = 0;
            int pattPos = 0;
            for (int c = 0; c < valey.Length; c++)
            {
                notPassed[c] = true;
            }
            while (pos < valey.Length && pos >= 0 && notPassed[pos])
            {
                notPassed[pos] = false; 
                sum += valey[pos];
                pos += patterns[i][pattPos];
                pattPos++;
                if (pattPos >= patterns[i].Length)
                    pattPos = 0;
                

            }
            if (sum > maxSum)
            {
                maxSum = sum;
            }
        }
        Console.WriteLine(maxSum);
    }
}
