using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoInOne
{
    public class Node
    {
        public static Node root;
        public Node(int val, Node b, Node n)
        {
            value = val;
            prev = b;
            next = n;
        }
        public void Remove() {
            if (prev == null) root = next;
            if (next!=null) next.prev = prev;
            if (prev!=null) prev.next = next;
            next = null;
            prev = null;
           // Console.WriteLine("removing" + value);
        }
        public int value;
        public Node prev;
        public Node next;
    }
    class Program
    {
        static int solve2(int N,bool[] right,int seen) {
            int result = -1;
            int next = 5;
            
            {
                Node[] nodes = new Node[N];
                int ij = 1;
                for (int i = 0; i < N; i++) {
                    while (right[ij]) ij++;
                    nodes[i] = new Node(ij, null, null);
                    //Console.WriteLine(ij);
                    ij++;
                }
                for (int i = 0; i + 1 < N; i++) nodes[i].next = nodes[i + 1];
                for (int i = 1; i < N; i++) nodes[i].prev = nodes[i-1];
                Node.root = nodes[0];
                while (true)
                {
                    //if (next == 4) Console.WriteLine("4 " + seen);
                    if (seen == N - 1)
                    {
                        result = Node.root.value;
                        break;
                    }
                    //Console.Write("next"+Node.root.value + " leftSeen"+(N-seen)+"many");
                    //Console.Write("s "+Node.root.value + " ");
                    Node.root.Remove();
                    seen++;
                    int cnt = 0;
                    Node iter = Node.root;
                    
                    if (N - seen >= next) {
                        while (iter != null) {
                            Node itnext = iter.next;
                            cnt++;
                            if (cnt == next) {
                                cnt = 0;
                                //Console.Write(iter.value + " ");
                                iter.Remove();
                                seen++;
                            }
                            if (seen == N) result = iter.value;
                            iter = itnext;
                        }
                        next++;
                    }
                    else {
                        //Console.WriteLine(next);
                        //Console.WriteLine("{0}, next{1}", seen, next);
                        while (iter.next != null) iter = iter.next;
                        result = iter.value;
                        break;
                    }
                    
                   //Console.WriteLine();
                    
                }
            }
            return result;
        }
        static int solve1(int n, bool[] ok) {
            int[] nextVal = { 2, 6, 12 };
            int lastFirst = 1;
            for (int next = 2; next <= 4; next++) {
                int first = lastFirst;
                while (ok[first]) first++;
                lastFirst = first;
                //Console.WriteLine("next first " + first);
                for (int j = first; j <= n; j+=nextVal[next-2]) {
                    //Console.WriteLine("ex " + j);
                    seen1++;
                    if (seen1 == n) return j;
                    ok[j] = true;
                    //Console.WriteLine("elim " + j);
                }
            }
            return -1;
        }
        static int seen1;
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            seen1 = 0;
            bool[] ok = new bool[N+1];
            int result = solve1(N, ok);
            if (result > 0) Console.WriteLine(result);
            else {
                Console.WriteLine(solve2(N - seen1, ok, 0));
                
            }
            //Console.WriteLine("solver2 " + solve2(N,ok,seen));
            
            //return;
            string[] robot = new string[2];
            robot[0] = Console.ReadLine();
            robot[1] = Console.ReadLine();
            int[] dy = {0,-1,0,1};
            int[] dx = {1,0,-1,0};
            int did = 0;
            for (int r = 0; r < 2; r++)
            {
                int x = 0;
                int y = 0;
                for (int j = 0; j < 4; j++)
                {
                    for (int i = 0; i < robot[r].Length; i++)
                    {
                        if (robot[r][i] == 'S')
                        {
                            x += dx[did];
                            y += dy[did];
                        }
                        else if (robot[r][i] == 'R') did = (did + 1) % 4;
                        else did = (did + 3) % 4;
                    }
                }
                if (x == 0 && y == 0) Console.WriteLine("bounded");
                else Console.WriteLine("unbounded");
            }
        }
    }
}
