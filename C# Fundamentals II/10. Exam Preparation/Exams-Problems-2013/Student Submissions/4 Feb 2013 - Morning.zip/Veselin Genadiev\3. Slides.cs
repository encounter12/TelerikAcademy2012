using System;
using System.Text;

namespace Slides
{
	public enum Operation{S, T, E, B};
	public enum SlidePos{L, R, F, B, FL, FR, BL, BR};
	class Slides
	{
		public static int cubeW;
		public static int cubeH;
		public static int cubeD;
		static void Main(string[] args)
		{
			string[] cube = Console.ReadLine().Split(' ');
			cubeW = int.Parse(cube[0]);
			cubeH = int.Parse(cube[1]);
			cubeD = int.Parse(cube[2]);
			Cube[, ,] Cuboid = new Cube[cubeW, cubeH, cubeD];
			string input;
			string[] line;
			string[] elements={};
			for (int i = 0; i < cubeH; i++)
			{
				int j = 0;
				input = Console.ReadLine();
				line = input.Split(new char[]{'|'}, StringSplitOptions.RemoveEmptyEntries);
				foreach(string lin in line)
				{
					elements = lin.Split(new[] { ")(" }, StringSplitOptions.None);
					for (int h = 0; h < cubeW; h++)
					{
							Cuboid[i, j, h] = new Cube(i, j, h, elements[h]);
					}
					j++;
				}
			}
			cube = Console.ReadLine().Split(' ');
			int ballW = int.Parse(cube[0]);
			int ballD = int.Parse(cube[1]);
			SlidingResult(ballW, 0, ballD, Cuboid);
		}

		private static void SlidingResult(int ballW, int ballH, int ballD, Cube[, ,] Cuboid)
		{
			switch (Cuboid[ballW, ballH, ballD].Opera)
			{
				case Operation.B: Console.WriteLine("No\n{0}, {1}, {2}", ballW, ballH, ballD); break;
				case Operation.E: if (ballH == cubeH - 1) Console.WriteLine("Yes\n{0}, {1}, {2}", ballW, ballH, ballD);
					else
						SlidingResult(ballW, ballH + 1, ballD, Cuboid); break;
				case Operation.T: SlidingResult(Cuboid[ballW, ballH, ballD].Teleport[0], ballH, Cuboid[ballW, ballH, ballD].Teleport[1], Cuboid);
					break;
				case Operation.S: if (ballH == cubeH - 1) Console.WriteLine("Yes\n{0}, {1}, {2}", ballW, ballH, ballD); 
				else 
					switch (Cuboid[ballW, ballH, ballD].Slide)
					{
						case SlidePos.R: SlidingResult(ballW + 1, ballH + 1, ballD, Cuboid); break;
						case SlidePos.B: SlidingResult(ballW, ballH + 1, ballD + 1, Cuboid); break;
						case SlidePos.BL: SlidingResult(ballW - 1, ballH + 1, ballD + 1, Cuboid); break;
						case SlidePos.BR: SlidingResult(ballW + 1, ballH + 1, ballD + 1, Cuboid); break;
						case SlidePos.F: SlidingResult(ballW, ballH + 1, ballD - 1, Cuboid); break;
						case SlidePos.FL: SlidingResult(ballW - 1, ballH + 1, ballD - 1, Cuboid); break;
						case SlidePos.FR: SlidingResult(ballW + 1, ballH + 1, ballD - 1, Cuboid); break;
						case SlidePos.L: SlidingResult(ballW - 1, ballH + 1, ballD, Cuboid); break;
					}; break;
			};
		}
	}
	class Cube
	{
		public int W;
		public int H;
		public int D;
		public Operation Opera;
		string OperationSpecific = "";
		public SlidePos Slide;
		public int[] Teleport = new int[2];
		public Cube(int w, int h, int d, string operationSpecific)
		{
			W=w;
			H=h;
			D=d;
			OperationSpecific = operationSpecific;
			StringBuilder op = new StringBuilder(operationSpecific);
			op.Replace("(", "");
			op.Replace(")", "");
			operationSpecific = op.ToString().Trim();
			string[] operation = operationSpecific.Split(new char[] {' '},StringSplitOptions.RemoveEmptyEntries);
			Opera = (Operation)Enum.Parse(typeof(Operation), operation[0]);
			if(operation.GetLength(0)==2)
			{
				Slide = (SlidePos)Enum.Parse(typeof(SlidePos), operation[1]);
			}
			else if(operation.GetLength(0)==3)
			{
				Teleport[0]=int.Parse(operation[1].ToString());
				Teleport[1]=int.Parse(operation[2].ToString());
			}
		}
	}
}
