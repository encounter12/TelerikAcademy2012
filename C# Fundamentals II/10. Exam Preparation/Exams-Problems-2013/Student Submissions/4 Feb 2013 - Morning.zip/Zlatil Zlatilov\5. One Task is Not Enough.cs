using System;
using System.Collections.Generic;

    class OneTaskIsNotEnough
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            string command1 = Console.ReadLine();
            string command2 = Console.ReadLine();
            Console.WriteLine(n);
            Console.WriteLine(BounderOrNot(command1));
            Console.WriteLine(BounderOrNot(command2));

        }
        private static string BounderOrNot(string str)
        {
            char[] commands = new char[str.Length];
            int sCount = 0;
            int rCount = 0;
            int lCount = 0;
            for (int i = 0; i < str.Length; i++)
            {
                commands[i] = str[i];
                switch (commands[i])
                {
                    case 'S':
                        break;
                    case 'L':
                        lCount++;
                        break;
                    case 'R':
                        rCount++;
                        break;
                }
            }

            if ((rCount % 2 == 1) && (lCount % 2 == 1))
            {
                return "unbounded";
            }
            else
            {
                return "bounded";
            }
            
        }

        private static int? lamps(int n)
        {
            int[] lampsOn = new int[n];
            int? last = null;
            int i = 1;
            while (last == null)
            {
                for (int j = 0; j < lampsOn.Length; j++)
                {
                    if (lampsOn[j] == 0)
                    {
                        lampsOn[j] = 1;
                        int check = 0;
                        while (check == i+1)
                        {
                            if (lampsOn[j]==0)
                            {
                            j++;   
                            }
                        }
                            int sum = 0;
                            foreach (var item in lampsOn)
                            {
                                sum += item;
                            }
                            if (sum == lampsOn.Length)
                            {
                                last = j + 1;
                                break;
                            }
                        
                        i++;
                    }
                }

            }
            return last;
        }
    }


//lampsOn[j] = 1;
//                        for (int k = j; k < lampsOn.Length; k += i + 1)
//                        {
//                            if (lampsOn[k] == 0)
//                            {
//                                lampsOn[k] = 1;
//                            }
//                        }
//                        int sum = 0;
//                        foreach (var item in lampsOn)
//                        {
//                            sum += item;
//                        }
//                        if (sum == lampsOn.Length)
//                        {
//                            last = j + 3;
//                            break;
//                        }