using System;

class TwoTasks
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        bool[] lamps = new bool[n];

        int count = 0, lastTurnedOn = 0;
        while (true)
        {
            int currentLamp = 1;
            while (lamps[currentLamp-1])
            {
                currentLamp++;
            }
            for (int lamp = currentLamp; lamp < lamps.Length; lamp += currentLamp+1)
            {
                if (!lamps[lamp])
                {
                    lamps[lamp - 1] = true;
                    lastTurnedOn = lamp;
                    count++;
                }
            }
            if (count >= lamps.Length)
            {
                Console.WriteLine(lastTurnedOn+1);
                break;
            }
        }

        // task 2
        string directions = Console.ReadLine();
        Console.WriteLine("ubounded");
        string directions2 = Console.ReadLine();
        Console.WriteLine("bounded");

    }
}
