using System;
using System.Collections.Generic;

namespace KaspichanNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            ulong n = ulong.Parse(Console.ReadLine());
            //Console.WriteLine(ConvertToKaspichan(255));
            string newNum = ConvertDecToKaspichan(n);
            Console.WriteLine(newNum);
        }

        static string ConvertToKaspichan(ulong a)
        {
            string result = null;
            if(a < 26)
            {
                result = ((char)(65 + a)).ToString();
            }
            else if (a >= 26 && a < 52)
            {
                result = "a" + ((char)(a - 26 + 65)).ToString();
            }
            else if (a >= 52 && a < 78)
            {
                result = "b" + ((char)(a - (2 * 26) + 65)).ToString();
            }
            else if (a >= 78 && a < 104)
            {
                result = "c" + ((char)(a - (3 * 26) + 65)).ToString();
            }
            else if (a >= 104 && a < 130)
            {
                result = "d" + ((char)(a - (4 * 26) + 65)).ToString();
            }
            else if (a >= 130 && a < 156)
            {
                result = "e" + ((char)(a - (5 * 26) + 65)).ToString();
            }
            else if (a >= 156 && a < 182)
            {
                result = "f" + ((char)(a - (6 * 26) + 65)).ToString();
            }
            else if (a >= 182 && a < 208)
            {
                result = "g" + ((char)(a - (7 * 26) + 65)).ToString();
            }
            else if (a >= 208 && a < 234)
            {
                result = "h" + ((char)(a - (8 * 26) + 65)).ToString();
            }
            else if (a >= 234)
            {
                result = "i" + ((char)(a - (9 * 26) + 65)).ToString();
            }

            return result;
        }

        static string ConvertDecToKaspichan(ulong n)
        {
            ulong nCopy = n;
            List<string> res = new List<string>();

            while (nCopy > 0)
            {
                ulong currentNum = nCopy % 256;

                res.Add(ConvertToKaspichan(currentNum));

                nCopy /= 256;
            }

            if (n == 0)
            {
                res.Add("A");
            }

            string newNum = null;
            for (int i = res.Count - 1; i >= 0; i--)
            {
                newNum += res[i];
            }
            return newNum;
        }
    }
}
