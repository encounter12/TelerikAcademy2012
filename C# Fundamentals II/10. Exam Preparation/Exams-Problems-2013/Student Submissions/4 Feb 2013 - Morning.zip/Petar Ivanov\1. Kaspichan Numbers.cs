using System;

class KaspichanNumbers
{

    static void Main()
    { 
        ulong inputNumber = ulong.Parse(Console.ReadLine());
        char[] letter = new char[26];
        ulong count = 0, cicle = 0;
        char firstLetter, lastLetter = 'A';
        string outputData = "", outputCicleData = "";
        for (int i = 0; i <= 25; i++)
			{
			    letter[i] = (char)(i + 'A');
			}
        if (inputNumber <= 25)
        {
            lastLetter = letter[inputNumber];
            Console.WriteLine("{0}", lastLetter);
        }
        else if (inputNumber > 25 && inputNumber <= 255)
        {
            for (ulong c = inputNumber; c >= 0; c = c - 256)
            {
                count = 0;
                for (int i = 0; i <= 10; i++)
                {
                    for (int j = 0; j <= 25; j++)
                    {
                        if(count <= inputNumber && count <= 255)
                        {
                              lastLetter = letter[j];
                        }
                        count++;
                        if (count > inputNumber)
                        {
                            break;
                        }
                    }
                    if (i != 0)
                    {
                        firstLetter = letter[i - 1];
                        outputCicleData = Convert.ToString(firstLetter).ToLower() + lastLetter;
                        if (count > inputNumber)
                        {
                            break;
                        }
                    }
                    cicle++;
                }
                outputData = outputCicleData + outputData;
                if (count > inputNumber)
                {
                    break;
                }
            }
            Console.WriteLine(outputData);
        }
    }
}