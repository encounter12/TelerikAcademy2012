using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class Program
{
    static void Main()
    {
        string[] input = Console.ReadLine().Split(new char[] {' '}, StringSplitOptions.RemoveEmptyEntries);
        int width = int.Parse(input[0]);
        int height = int.Parse(input[1]);
        int depth = int.Parse(input[2]);
        string[, ,] cuboid = new string[height, depth, width];
        for (int h = 0; h < height; h++)
        {
            input = Console.ReadLine().Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
            for (int d = 0; d < depth; d++)
            {
                input[d] = input[d].Trim();
                string[] cell = input[d].Split(new char[] { '(', ')' }, StringSplitOptions.RemoveEmptyEntries);
                for (int w = 0; w < width; w++)
                {
                    cuboid[h, d, w] = cell[w];
                }
            }
        }
        input = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        int ballW = int.Parse(input[0]);
        int ballD = int.Parse(input[1]);

        int cellH = 0;
        int cellD = ballD;
        int cellW = ballW;
        bool isPossible = false;
        while (cellH < height - 1 && cellD < depth && cellW < width )
        {
            if (cuboid[cellH, cellD, cellW] == "B")
            {
                isPossible = false;
                return;
            }
            else if (cuboid[cellH, cellD, cellW] == "E")
            {
                cellH++;
            }
            else if (cuboid[cellH, cellD, cellW] == "S F")
            {
                if (cellD != 0)
                {
                    cellH++;
                    cellD--;
                }
                else
                {
                    return;
                }
            }
            else if (cuboid[cellH, cellD, cellW] == "S B")
            {
                if (cellD != depth - 1)
                {
                    cellH++;
                    cellD++;
                }
                else
                {
                    return;
                }
            }
            else if (cuboid[cellH, cellD, cellW] == "S L")
            {
                if (cellW != 0)
                {
                    cellH++;
                    cellW--;
                }
                else
                {
                    return;
                }
            }
            else if (cuboid[cellH, cellD, cellW] == "S R")
            {
                if (cellW != width - 1)
                {
                    cellH++;
                    cellW++;
                }
                else { return; }
            }
            else if (cuboid[cellH, cellD, cellW] == "S FL")
            {
                if (cellD != 0 && cellW != 0)
                {
                    cellH++;
                    cellD--;
                    cellW--;
                }
                else { return; }
            }
            else if (cuboid[cellH, cellD, cellW] == "S FR")
            {
                if (cellD != 0 && cellW != width - 1)
                {
                    cellH++;
                    cellD--;
                    cellW++;
                }
                else { return; }
            }
            else if (cuboid[cellH, cellD, cellW] == "S BL")
            {
                if (cellD != depth - 1 && cellW != 0)
                {
                    cellH++;
                    cellD++;
                    cellW--;
                }
                else { return; }
            }
            else if (cuboid[cellH, cellD, cellW] == "S BR")
            {
                if (cellD != depth-1 && cellW != width-1)
                {cellH++;
                cellD++;
                cellW++;}else{return;}
            }
            else
            {
                string[] teleport = cuboid[cellH, cellD, cellW].Split(new char[] {' ', 'T'}, StringSplitOptions.RemoveEmptyEntries);
                cellW = int.Parse(teleport[0]);
                cellW = int.Parse(teleport[1]);
            }

        }
        if (cellH == height - 1 && cuboid[cellH, cellD, cellW] != "B")
        {
            isPossible = true;
        }

        if (isPossible)
        {
            Console.WriteLine("Yes");
        }
        else
        {
            Console.WriteLine("No");
        }
        Console.WriteLine(cellW + " " + cellH + " " + cellD);
    }
}