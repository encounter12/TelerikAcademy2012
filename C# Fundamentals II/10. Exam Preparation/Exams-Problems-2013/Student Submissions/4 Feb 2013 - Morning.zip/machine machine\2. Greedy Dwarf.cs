using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class GreedyDwarf
{
    public static string[] spltrs = new string[1]{", "};
    public static bool checkRepetition(int index,List<int> indeces)
    {
        for (int i = 0; i < indeces.Count; i++)
        {
            if (indeces[i] == index)
            {
                return true;
            }
        }
        return false;
    }
    public static int GetCoins(string ptrnsStr, int[] val)
    {
        string[] split = ptrnsStr.Split(spltrs, StringSplitOptions.RemoveEmptyEntries);
        int[] ptrn = Valley2Int(split);
        int sum = val[0];
        int index = 0;
        List<int> indeces = new List<int>();

        indeces.Add(0);
        int i = 0;
        while(true)
        {
            if (i > ptrn.Length - 1)
            {
                i = 0;
            }
            index += ptrn[i];
            if (index > val.Length - 1 || index < 0)
            {
                break;
            }
            if (checkRepetition(index, indeces))
            {
                break;
            }
            indeces.Add(index);
            sum += val[index];
            i++;
        }
        return sum;
    }

    public static int[] Valley2Int(string[] valley)
    {
        int[] val = new int[valley.Length];
        for (int i = 0; i < val.Length; i++)
        {
            val[i] = int.Parse(valley[i]);
        }
        return val;
    }

    static void Main(string[] args)
    {
        string valley = Console.ReadLine();
        string[] split = valley.Split(spltrs, StringSplitOptions.RemoveEmptyEntries);
        int[] val = Valley2Int(split);

        int N = int.Parse(Console.ReadLine());


        string ptrnsStr;

        int coins = int.MinValue;
        for (int i = 0; i < N; i++)
        {
            ptrnsStr = Console.ReadLine();
            coins = Math.Max(coins, GetCoins(ptrnsStr, val));
            //Console.WriteLine(coins);
        }
        Console.WriteLine(coins);
    }
}