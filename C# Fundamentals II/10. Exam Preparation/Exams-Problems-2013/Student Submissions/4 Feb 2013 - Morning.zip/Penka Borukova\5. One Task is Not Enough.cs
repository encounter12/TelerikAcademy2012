using System;
using System.Collections.Generic;
class TwoTasks
{
    static bool IsInRange(int x, int y, int n)
    {
        return ((x <= n && x >= 0) && (y <= 2 * n && y >= 0));

    }


    static bool Bounded(string instruction)
    {
        bool[,] visited = new bool[instruction.Length + 1, 2 * instruction.Length + 1];


        int x = 0;
        int y = instruction.Length;
        int currentDirection = 0;
        while (true)
        {
            for (int i = 0; i < instruction.Length; i++)
            {
                if (!IsInRange(x, y, instruction.Length))
                {
                    return false;
                }
                //Console.WriteLine("x is {0} and y is {1}", x, y);
                if (visited[x, y])
                {
                    return true;
                }
                if (instruction[i] == 'S')
                {
                    if (currentDirection == 0)
                    {
                        x++;
                    }
                    else if (currentDirection == 1) //
                    {
                    }
                }
                else if (instruction[i] == 'L')
                {
                    y++;
                }
                else
                {
                    y--;
                }
            }
        }

    }


    static bool AllLapmsTurnedOn(bool[] visited)
    {
        for (int i = 0; i < visited.Length; i++)
        {
            if (!visited[i])
            {
                return false;
            }
        }
        return true;
    }

    static int find(bool[] used)
    {
        int index = 0;
        for (int i = 0; i < used.Length; i++)
        {
            if (!used[i])
            {
                return i;
            }
        }
        return -1;
    }
    static int TurnOnLamps(bool[] visited, int lampsCount)
    {
        int step = 2;
        int lastTurnedOnLamp = 0;
        for (int j = 0; j < visited.Length; j++)
        {
            if (AllLapmsTurnedOn(visited))
            {
                return lastTurnedOnLamp + 1;
            }
            for (int i = find(visited); i < lampsCount; i += step)
            {
                if (!visited[i])
                {
                    visited[i] = true;
                    lastTurnedOnLamp = i;
                }

                step++;
            }
        }
        return lastTurnedOnLamp;
    }

    static bool Unbounded(string instruction)
    {
        int lCount = 0;
        int rCount = 0;


        int index = instruction.IndexOf("LLLL");

        if (index != -1)
        {
            return false;
        }
        index = instruction.IndexOf("RRRR");
        if(index != -1)
        {
            return false;
        }
        for (int i = 0; i < instruction.Length; i++)
        {
            if (instruction[i] == 'L')
            {
                lCount++;
            }
            else if (instruction[i] == 'R')
            {
                rCount++;
            }
        }
        if (lCount == 0 && rCount == 0)
        {
            return true;
        }
        return lCount == rCount;
    }

    static void Main(string[] args)
    {
        int lampsCount = int.Parse(Console.ReadLine());
        string firstInstruction = Console.ReadLine();
        string secondInstruction = Console.ReadLine();

        bool[] visited = new bool[lampsCount];

        for (int i = 0; i < lampsCount; i++)
        {
            visited[i] = false;
        }

        int count = TurnOnLamps(visited, lampsCount);
        Console.WriteLine(count);
        bool t = Unbounded(firstInstruction);
        if (t)
        {
            Console.WriteLine("unbounded");
        }
        else
        {
            Console.WriteLine("bounded");
        }
        t = Unbounded(secondInstruction);
        if (t)
        {
            Console.WriteLine("unbounded");
        }
        else
        {
            Console.WriteLine("bounded");
        }

    }
}
