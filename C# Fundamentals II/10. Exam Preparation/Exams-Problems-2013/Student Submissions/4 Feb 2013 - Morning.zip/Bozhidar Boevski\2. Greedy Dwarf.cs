using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreedyDwarf
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] valley;
            string[] valleyStr;
            string cInput;
            int patterns;
            string result;

            cInput = Console.ReadLine();
            valleyStr = cInput.Split(',');

            valley = new int[valleyStr.Length];
            for (int i = 0; i < valleyStr.Length; i++)
            {
                valley[i] = Convert.ToInt32(valleyStr[i]);
            }

            cInput = Console.ReadLine();
            patterns = Convert.ToInt32(cInput);

            result = Solve(valley, patterns);

            Console.WriteLine(result);
        }
        static string Solve(int[] valley, int mPatterns)
        {
            string result;
            string inputStr;
            string[] currentPatternStr;
            int[] currentPattern;
            List<int[]> allPatterns = new List<int[]>();

            for (int i = 0; i < mPatterns; i++)
            {
                inputStr = Console.ReadLine();
                currentPatternStr = inputStr.Split(',');
                currentPattern = new int[currentPatternStr.Length];
                for (int k = 0; k < currentPatternStr.Length; k++)
                {
                    currentPattern[k] = Convert.ToInt32(currentPatternStr[k]);
                }

                allPatterns.Add(currentPattern);
            }

            int sum = valley[0];
            int biggestSum = 0;
            int position = 0;
            foreach (var item in allPatterns)
            {
                for (int i = 0; i < item.Length; i++)
                {
                    if (position + item[i] > valley.Length)
                    {
                        break;
                    }
                    if (position + item[i] < 0)
                    {
                        break;
                    }
                    sum += valley[position + item[i]];
                }
                if (sum > biggestSum)
                {
                    biggestSum = sum;
                }
                sum = 0;
            }



            result = biggestSum.ToString();
            return result;
        }
    }
}
