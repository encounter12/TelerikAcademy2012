using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;



class Program
{
    static void Main()
    {
       
         BigInteger number = BigInteger.Parse(Console.ReadLine());
        BigInteger num2;
       BigInteger num3;
        BigInteger number2 = 0;
        int first=26;
        BigInteger ex1;
        BigInteger ex2;


        if ((number >= 0) && (number <= 25))
        {
            num2 = 65 + number;
            number = (char)num2;
            Console.WriteLine((char)number);

        }




        else if ((number >= 26) && (number <= 51))
        {


            num3 = 97;
            num2 = 65 + number - first;
            number = (char)num2;
            number2 = (char)num3;

            Console.WriteLine((char)number2 + "" + (char)number);
        }


        else if ((number >= 52) && (number <= 77))
        {


            num3 = 98;
            num2 = 65 + number - (first * 2);
            number = (char)num2;
            number2 = (char)num3;

            Console.WriteLine((char)number2 + "" + (char)number);
        }


        else if ((number >= 78) && (number <= 103))
        {


            num3 = 99;
            num2 = 65 + number - (first * 3);
            number = (char)num2;
            number2 = (char)num3;

            Console.WriteLine((char)number2 + "" + (char)number);
        }


        else if ((number >= 104) && (number <= 129))
        {


            num3 = 100;
            num2 = 65 + number - (first * 4);
            number = (char)num2;
            number2 = (char)num3;

            Console.WriteLine((char)number2 + "" + (char)number);
        }

        else if ((number >= 130) && (number <= 152))
        {


            num3 = 101;
            num2 = 65 + number - (first * 5);
            number = (char)num2;
            number2 = (char)num3;

            Console.WriteLine((char)number2 + "" + (char)number);
        }

        else if ((number >= 153) && (number <= 178))
        {


            num3 = 102;
            num2 = 65 + number - (first * 6);
            number = (char)num2;
            number2 = (char)num3;

            Console.WriteLine((char)number2 + "" + (char)number);
        }

        else if ((number >= 179) && (number <= 204))
        {


            num3 = 103;
            num2 = 65 + number - (first * 7);
            number = (char)num2;
            number2 = (char)num3;

            Console.WriteLine((char)number2 + "" + (char)number);
        }

        else if ((number >= 205) && (number <= 230))
        {


            num3 = 104;
            num2 = 65 + number - (first * 8);
            number = (char)num2;
            number2 = (char)num3;

            Console.WriteLine((char)number2 + "" + (char)number);
        }

        else if ((number >= 231) && (number <= 255))
        {


            num3 = 105;
            num2 = 65 + number - (first * 9);
            number = (char)num2;
            number2 = (char)num3;

            Console.WriteLine((char)number2 + "" + (char)number);
        }



        else if (number > 255)
        {
            ex1 = number % 256;
            ex2 = number / 256;

            number = 65 + number;
            number = (char)ex1;

            ex2 = 65 + ex2;
            number2 = (char)ex2;


            num2 = 65 + number;
            number = (char)num2;
            //Console.WriteLine((char)number);
            Console.WriteLine((char)number2+""+(char)number);

        }
    }


}

