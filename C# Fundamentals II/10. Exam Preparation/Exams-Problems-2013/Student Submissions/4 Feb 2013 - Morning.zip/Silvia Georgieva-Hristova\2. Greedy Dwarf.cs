using System;
using System.Text;

class GreedyDwarf
{
    
    static void Main()
    {
        char[] separator = {',',' '};
        string line = Console.ReadLine();
        string[] inputLine = line.Split(separator, StringSplitOptions.RemoveEmptyEntries);
        int lengthValley = inputLine.GetLength(0);
        int[] valley = new int[lengthValley];
        for (int i =0; i<lengthValley; i++)
        {
            valley[i]=Convert.ToInt32(inputLine[i]);
        }
        int countPatterns = Convert.ToInt32(Console.ReadLine());
        int[][] patterns = new int[countPatterns][];
        ReadInput(countPatterns, patterns);
        int maxCoins = FindMaxCoins(valley, patterns, countPatterns);
        Console.WriteLine(maxCoins);
    }
    static void ReadInput(int countPatterns, int[][] patterns)
    {
        for (int i = 0; i < countPatterns; i++)
        {
            char[] separator = { ',', ' ' };
            string line = Console.ReadLine();
            string[] tempPattern = line.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            int length = tempPattern.Length;
            patterns[i] = new int[length];
            for (int j = 0; j < length; j++)
            {
                patterns[i] [j] = Convert.ToInt32(tempPattern[j]);
            }
        }
    }
    static int FindMaxCoins(int[] valley, int[][] patterns, int countPatterns)
    {
        int maxCoins = int.MinValue;
        for (int i = 0; i < countPatterns; i++)
        {
            int currCoins = FindCoins(valley, patterns[i]);
            if (currCoins > maxCoins)
            {
                maxCoins = currCoins;
            }
        }
        return maxCoins;
    }
    static int FindCoins(int[] valley, int[] pattern)
    {
        int coins = 0;
        int vLength = valley.Length;
        bool[] isVisistedValley = new bool[vLength];
        int currIndex = 0;
        int pLength = pattern.Length;
        int pIndex = 0;
        do
        {
            coins += valley[currIndex];
            isVisistedValley[currIndex] = true;
            currIndex += pattern[pIndex];
            pIndex++;
            if (pIndex == pLength)
            {
                pIndex = 0;
            }
        }
        while (currIndex >= 0 && currIndex < vLength && isVisistedValley[currIndex] == false);
        return coins;
    }
}
