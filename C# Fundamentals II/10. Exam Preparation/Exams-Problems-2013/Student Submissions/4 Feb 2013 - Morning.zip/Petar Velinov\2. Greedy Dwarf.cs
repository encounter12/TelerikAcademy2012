using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class GreedyDwarf
{
    static void Main()
    {
        string input = Console.ReadLine();
        int M = 3;//int.Parse(Console.ReadLine());

        int[] valley = Clear(input);

        int collected = 0;
        for (int i = 0; i < 3; i++)
        {
            string pat = Console.ReadLine();
            int[] pattern = Clear(pat);
            collected += CollectCoins(valley, pattern);
        }

        Console.WriteLine(collected);

    }

    static int[] Clear(string toClear)
    {

        string[] cleared = toClear.Split(',');
        string[] finalclear = new string[cleared.Length];

        for (int i = 0; i < cleared.Length; i++)
        {
            finalclear[i] = cleared[i].TrimStart();
        }
        
        int[] valley = new int[cleared.Length];

        for (int i = 0; i < cleared.Length; i++)
        {
            if (cleared[i] != null)
            {
                valley[i] = int.Parse(cleared[i].ToString());
            }
            
        }
        return valley;
    }

    static int CollectCoins(int[] valley, int[] pattern)
    {
        int collected = 0;
        int step = 0;

        for (int i = 0; i < pattern.Length; i++)
        {
            
            collected += valley[step];
            step = step + pattern[i];
        }

        return collected;

    }

}

