using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.GreedyDwarf
{
    class GreedyDwarf
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a string: ");
            string valley = Console.ReadLine();
            Console.WriteLine("Enter a pattern:");
            string pattern = Console.ReadLine();


            StringBuilder drow = new StringBuilder();
            string[] separators = new string[] { ", " };
            char[] trimChars = new char[] { ',', ' ' };

            string[] parts = valley.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < parts.Length; i++)
            {
                Console.WriteLine(parts[i]);
            }

            int length = valley.Length;

            int index = valley.IndexOf("1");
            
            Console.WriteLine(index);
            
            {
                
            }
            
        }
    }

}