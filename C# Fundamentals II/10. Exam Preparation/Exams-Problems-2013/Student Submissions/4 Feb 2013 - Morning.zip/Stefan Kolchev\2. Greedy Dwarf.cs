using System;

class GreedyDwarfs
{
    static void Main()
    {
        // Input
        string input = Console.ReadLine();
        string[] nums = input.Split(new char[] { ',' });
        int[] coins = new int[nums.Length];
        for (int i = 0; i < nums.Length; i++)
        {
            coins[i] = int.Parse(nums[i]);
        }        
        int numberOfPatterns = int.Parse(Console.ReadLine());
        int[][] jagged = new int[numberOfPatterns][];
        for (int read = 0; read < numberOfPatterns; read++)
        {
            string path = Console.ReadLine();
            string[] pathArr = path.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            jagged[read] = new int[pathArr.Length];
            for (int i = 0; i < pathArr.Length; i++)
            {
                jagged[read][i] = int.Parse(pathArr[i]);
            }            
        }

        int tempSum = 0;
        int bestSum = 0;
        bool visited = false;
        bool retry = false;
        int currentPosition = 0;
        for (int i = 0; i < numberOfPatterns; i++)
        {
            bool[] steps = new bool[coins.Length];
            tempSum = coins[0];
            steps[0] = true;
            currentPosition = 0;
            visited = false;
            for (int j = 0; j < jagged[i].Length; j++)
            {
                currentPosition = currentPosition + jagged[i][j];
                if ((currentPosition) >= coins.Length || (currentPosition) < 0)
                {
                    break;
                }
                else if (steps[currentPosition] == false)
                {
                    steps[currentPosition] = true;
                    tempSum += coins[currentPosition];
                }
                else
                {
                    visited = true;
                    break;
                }

                if ((j == jagged[i].Length - 1) && visited == false)
                {
                    j = -1;
                }
            }
            if (tempSum > bestSum)
                bestSum = tempSum;            
        }
        Console.WriteLine(bestSum);
    }
}
