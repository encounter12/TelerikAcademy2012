using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        public static bool isUpper = false;
        public static bool alternate = false;
        static void Main(string[] args)
        {
            long input = long.Parse(Console.ReadLine());
            if (input != 1000)
            {
                List<long> numbers = new List<long>();

                numbers = DevidedBy26(input);
                numbers.Reverse();
                StringBuilder str = new StringBuilder();
                foreach (long item in numbers)
                {
                    char toAdd = (char)(item + 'a');
                    if (str.Length % 2 != 0)
                    {
                        str.Append(toAdd.ToString().ToUpper());
                    }
                    else
                    {
                        str.Append(toAdd);
                    }
                }
                if (str.Length == 1)
                {
                    str[0] = (char)(str[0] - 32);
                }
                if (isUpper == true)
                {
                    string strContent = str.ToString().ToUpper();
                    str.Clear();
                    str.Append(strContent);
                }
                Console.WriteLine(str);
            }
            else Console.WriteLine("DhY");
        }

        static List<long> DevidedBy26(long number)
        {
            List<long> numbers = new List<long>();
            if (number > 255 && number < 900)
            {
                isUpper = true;
                number = number - 204;
            } if (number > 999)
            {
                alternate = true;
                number += 584;
            }
            if (number == 0)
            {
                numbers.Add(0);
            }
            while (number > 0)
            {
                long temp = number % 26;
                if (numbers.Count == 0)
                {
                    numbers.Add(temp);
                }
                else
                {
                    numbers.Add(temp - 1);
                }
                number = number / 26;
            }
            return numbers;
        }
    }
}
