using System;

class GreedyDwarf
{
    static void Main()
    {
        string valley = Console.ReadLine();
        int patternsCount = int.Parse(Console.ReadLine());
        string[] patterns = new string[patternsCount];
        for (int i = 0; i < patternsCount; i++)
        {
            patterns[i] = Console.ReadLine();
        }
        //string valley = "1, 3, -6, 7, 4, 1, 12";
        ////int patternsCount = 3;
        //string[] patterns = new string[3] { "1, 2, -3", "1, 3, -2", "1" };

        string[] separator = new string[1] { ", " };
        string[] valleyParsed = valley.Split(separator, StringSplitOptions.None);
        int[] valleySteps = new int[valleyParsed.Length];
        bool[] visitedSteps = new bool[valleyParsed.Length]; // to pass a shallow copy

        for (int i = 0; i < valleyParsed.Length; i++)
        {
            valleySteps[i] = int.Parse(valleyParsed[i]);
            visitedSteps[i] = false;
        }

        int[][] paths = new int[patterns.Length][];

        for (int i = 0; i < patterns.Length; i++)
        {
            string[] patternParsed = patterns[i].Split(separator, StringSplitOptions.None);
            int[] pattern = new int[patternParsed.Length];

            for (int j = 0; j < patternParsed.Length; j++)
            {
                pattern[j] = int.Parse(patternParsed[j]);
            }

            paths[i] = pattern;
        }

        int[] collectedCoinsPerPath = new int[paths.Length];

        for (int i = 0; i < paths.Length; i++)
        {
            int currentStep = 0;
            int coinsCollected = 0;
            int j = 0;
            bool[] visitedStepsInstance = (bool[])visitedSteps.Clone();

            while ((currentStep >= 0) && (currentStep < valleySteps.Length) && (visitedStepsInstance[currentStep] == false))
            {
                coinsCollected += valleySteps[currentStep];
                visitedStepsInstance[currentStep] = true;
                currentStep += paths[i][j++];

                if (j >= paths[i].Length)
                {
                    j = 0;
                }
            }

            collectedCoinsPerPath[i] = coinsCollected;
        }

        int maxCoins = int.MinValue;

        for (int i = 0; i < collectedCoinsPerPath.Length; i++)
        {
            if (collectedCoinsPerPath[i] > maxCoins)
            {
                maxCoins = collectedCoinsPerPath[i];
            }
        }

        Console.WriteLine(maxCoins);
    }
}