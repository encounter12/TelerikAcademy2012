using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OneTaskIsNotEnough
{
    class OneTaskIsNotEnough
    {
        public static int GetFirstOffLamp(string[] lampArr, int count)
        {
            int br = 1, indexFirstOffLamp = 0;
            /*for (int i = 0; i < lampArr.Length; i++)
            {
                if (lampArr[i] == "off" && count == br)
                {
                    indexFirstOffLamp = i;
                    lampArr[i] = "on";
                    break;
                }
                br++;
            }*/
            while (true)
            {
                if (br >= lampArr.Length)
                {
                    break;
                }
                if (lampArr[br] == "off" && count == br)
                {
                    indexFirstOffLamp = br;
                    lampArr[br] = "on";
                    break;
                }
                br++;    
            }
            return indexFirstOffLamp;
        }
        static void Main()
        {
            int lampSize = int.Parse(Console.ReadLine());
            int controlSize = lampSize;
            int lastIndex = 0;
            string[] lampArr = new string[lampSize];
            for (int i = 0; i < lampSize; i++)
            {
                lampArr[i] = "off";
            }

            lampArr[0] = "on";


            int turn = 1;
            for (int j = 1; j < lampSize; j++)
            {
                
                for (int i = 0; i < lampSize; i = i + turn)
                {
                    int turnOnI = 0;
                    turnOnI = GetFirstOffLamp(lampArr, turn + i);
                    //Console.WriteLine(turnOnI);
                    lastIndex = turnOnI;
                }
                turn = turn + j;
                if (turn > lampSize || turn < 0)
                {
                    break;
                }
            }
            Console.WriteLine(lastIndex);
            


        }
    }
}