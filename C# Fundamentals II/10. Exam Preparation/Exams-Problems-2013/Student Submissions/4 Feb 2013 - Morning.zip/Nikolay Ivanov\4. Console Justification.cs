using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem4
{
    class Problem4
    {
        static void Main(string[] args)
        {
            int index, indT=0, iN=0, i;
            int N = int.Parse(Console.ReadLine());
            int W = int.Parse(Console.ReadLine());
            string tmpStr = "";
            string[] wordsArr = new string[N];
            string[] wordsArrNew;
            wordsArrNew = new string[N];
            for (i = 0; i < N; i++)
            {
                wordsArr[i]=Console.ReadLine();
            }
            for ( i = 0; i < N; i++)
            {
                tmpStr = tmpStr+wordsArr[i];
            }
            while (tmpStr.Length>W)
            {
                index = tmpStr.IndexOf(' ');
                while (index < W)
                {
                    indT = index;
                    index = tmpStr. IndexOf(' ', index+1);
                    //index = strArr[i].IndexOf(word); 
                }
                iN++;
                wordsArrNew[iN] = tmpStr.Substring(0, indT - 1);
                tmpStr = tmpStr.Substring(indT + 1, tmpStr.Length);
            }
            for (i = 0; i < iN; i++)
            {
                Console.WriteLine(wordsArrNew[i]);
            }

        }
    }
}