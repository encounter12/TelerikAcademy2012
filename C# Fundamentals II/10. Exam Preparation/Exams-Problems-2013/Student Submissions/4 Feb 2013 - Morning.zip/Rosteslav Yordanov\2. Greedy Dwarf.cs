using System;
using System.Numerics;

class Program
{
    static void Main()
    {
        string valleysStr = Console.ReadLine();
        int numPatterns = int.Parse(Console.ReadLine());
        string[] patternsStr = new string[numPatterns];
        for (int index = 0; index < numPatterns; index++)
        {
            patternsStr[index] = Console.ReadLine();
        }
        string[] valleyStr = valleysStr.Split(new char[] { ' ', ',' },StringSplitOptions.RemoveEmptyEntries);
        int?[] valley = new int?[valleyStr.Length];
        for (int index = 0; index < valleyStr.Length; index++)
        {
            valley[index] = int.Parse(valleyStr[index]);
        }
        BigInteger maxSum = long.MinValue;
        foreach (var patternStr in patternsStr)
	    {
            int?[] v = new int?[valley.Length];
            v = (int?[])valley.Clone();
            BigInteger sum = Result(patternStr, v);
		    if ( sum > maxSum)
	        {
                maxSum = sum;
	        }
	    }
        Console.WriteLine(maxSum);
    }

    private static BigInteger Result(string patternStr, int?[] valley)
    {
        
        string[] vStr = patternStr.Split(new char[] { ' ', ',' },StringSplitOptions.RemoveEmptyEntries);
        int[] pattern = new int[vStr.Length];
        for (int index = 0; index < vStr.Length; index++)
        {
            pattern[index] = int.Parse(vStr[index]);
        }
        BigInteger sum = 0;
        int paternIndex = 0;
        int maxPaternIndex = pattern.Length;
        int valleyIndex = 0;
        sum += valley[valleyIndex].Value;
        valley[valleyIndex] = null;
        while (true)
	    {
            paternIndex %= maxPaternIndex;
            valleyIndex += pattern[paternIndex]; 
            if (valleyIndex >= valley.Length)
            {
                break;
            }
            if (valleyIndex < 0)
            {
                break;
            }
            if (valley[valleyIndex] == null)
	        {
		        break;
	        }
            sum += valley[valleyIndex].Value;
            valley[valleyIndex] = null;
            paternIndex++;
        }
        return sum;
    }
}