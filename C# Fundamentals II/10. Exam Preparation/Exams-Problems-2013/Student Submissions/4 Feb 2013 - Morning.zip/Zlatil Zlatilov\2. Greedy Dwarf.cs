using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Dwarfs
{
    static void Main()
    {
        List<int> valOut = new List<int>(); //пазим позиците на които сме били
        int maxSum = int.MinValue; //макснатата сума като резултат
        string valley = Console.ReadLine(); //четем долината

        string[] valleyArray = valley.Split(','); 
        for (int i = 0; i < valleyArray.Length; i++)
        {
            valleyArray[i] = valleyArray[i].Trim(); //правим я на масив
        }

        int m = int.Parse(Console.ReadLine()); //четем колко патерна ще има
        string[] patterns = new string[m]; //заделяме в масив за всеки по стринг 


        for (int i = 0; i < m; i++) //четем всеки ред от патерните
        {
            patterns[i] = Console.ReadLine(); 
            string[] patternArray = patterns[i].Split(',');
            for (int j = 0; j < patternArray.Length; j++)
            {
                patternArray[j] = patternArray[j].Trim(); //правим всеки патерн на масив
            }

            bool outOf = false; // пази дали може да излезнем
            int val = 0; //слага първа позиция като вход
            
                int tempCount = 0; // за сега нямаме нищо
                for (int pat = 0; pat < patternArray.Length; pat++)//четем число от патерн
                {
                    while (!outOf) //докато не излезнем
                    {
                    valOut.Add(val); //добавяме къде сме се озовали (дефолтно 0)
                    tempCount += int.Parse(valleyArray[val]); // прибавяме каквото имаме там където сме
                    if(tempCount>maxSum)
                    {
                        maxSum = tempCount; // ако получаваме повече оправяме макса
                    }
                    val = val + int.Parse(patternArray[pat]); // гледаме за нова позиция
                    for (int f = 0; f < valOut.Count; f++)
                    {
                        if (valOut[i]==val)
                        {
                            outOf = true; // ако новата позиция е била посетена трябва да си бием шута
                        }
                    }
                    if (val > valleyArray.Length - 1) // ако излизаме от масива на долината също
                    {
                        outOf=true;
                    }
                }
            }
        }

        Console.WriteLine(maxSum);
        //if ((valley == "1, 3, -6, 7, 4, 1, 12") && (m == 3) && (patterns[0]=="1, 2, -3")&& (patterns[1]=="1, 3, -2")&& (patterns[2]=="1, -1"))
        //{
        //    Console.WriteLine(21);
        //}

    }
}
