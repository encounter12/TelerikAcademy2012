using System;

class KaspitschanNumbers
{
    static void Main()
    {
        string[] codes = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "G", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "aA", "aB", "aC", "aD", "aE", "aF", "aG", "aH", "aI", "aG", "aK", "aL", "aM", "aN", "aO", "aP", "aQ", "aR", "aS", "aT", "aU", "aV", "aW", "aX", "aY", "aZ", "bA", "bB", "bC", "bD", "bE", "bF", "bG", "bH", "bI", "bG", "bK", "bL", "bM", "bN", "bO", "bP", "bQ", "bR", "bS", "bT", "bU", "bV", "bW", "bX", "bY", "bZ", "cA", "cB", "cC", "cD", "cE", "cF", "cG", "cH", "cI", "cG", "cK", "cL", "cM", "cN", "cO", "cP", "cQ", "cR", "cS", "cT", "cU", "cV", "cW", "cX", "cY", "cZ", "dA", "dB", "dC", "dD", "dE", "dF", "dG", "dH", "dI", "dG", "dK", "dL", "dM", "dN", "dO", "dP", "dQ", "dR", "dS", "dT", "dU", "dV", "dW", "dX", "dY", "dZ", "eA", "eB", "eC", "eD", "eE", "eF", "eG", "eH", "eI", "eG", "eK", "eL", "eM", "eN", "eO", "eP", "eQ", "eR", "eS", "eT", "eU", "eV", "eW", "eX", "eY", "eZ", "fA", "fB", "fC", "fD", "fE", "fF", "fG", "fH", "fI", "fG", "fK", "fL", "fM", "fN", "fO", "fP", "fQ", "fR", "fS", "fT", "fU", "fV", "fW", "fX", "fY", "fZ", "gA", "gB", "gC", "gD", "gE", "gF", "gG", "gH", "gI", "gG", "gK", "gL", "gM", "gN", "gO", "gP", "gQ", "gR", "gS", "gT", "gU", "gV", "gW", "gX", "gY", "gZ", "hA", "hB", "hC", "hD", "hE", "hF", "hG", "hH", "hI", "hG", "hK", "hL", "hM", "hN", "hO", "hP", "hQ", "hR", "hS", "hT", "hU", "hV", "hW", "hX", "hY", "hZ", "iA", "iB", "iC", "iD", "iE", "iF", "iG", "iH", "iI", "iG", "iK", "iL", "iM", "iN", "iO", "iP", "iQ", "iR", "iS", "iT", "iU", "iV" };
        long casp=long.Parse(Console.ReadLine());
        string result = "";
        long num=0;
        do
        {
        num = casp % 256;
        casp = casp / 256;
        result = codes[num]+result;
        } while (casp>0);
        Console.WriteLine(result);
    }
}