using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreedyDwarf
{
    class GreedyDwarf
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] inputArr = input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            int[] valley = new int[inputArr.Length];
            for (int i = 0; i < inputArr.Length; i++)
            {
                valley[i] = int.Parse(inputArr[i]);
            }

            int n = int.Parse(Console.ReadLine());
            List<int>[] routes = new List<int>[n];

            for (int i = 0; i < n; i++)
            {
                routes[i] = new List<int>();
                string inputRoute = Console.ReadLine();
                string[] inputRouteArr = inputRoute.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var routeNum in inputRouteArr)
                {
                    routes[i].Add(int.Parse(routeNum));
                }
            }

            //int n = 3;
            //int[] valley = new int[] {1,3,-6,7,4,1,12 };
            //List<int>[] routes = new List<int>[]
            //{
            //     new List<int>{1,2,-3},
            //    new List<int>{1,3,-2},
            //    new List<int>{1,-1},
            //};

            int[] results = new int[n];
            for (int i = 0; i < n; i++)
            {
                results[i] += valley[0];
            }
            List<int> visited = new List<int>();

            int index = 0;

            for (int i = 0; i < routes.Length; i++)
			{
                visited.Clear();
                visited.Add(0);
                index = 0;
                List<int> currRoute = routes[i];
                for (int routePos = 0; routePos < routes[i].Count; routePos++)
                {
                    index += currRoute[routePos];
                    if (index<0||index>=valley.Length||visited.Contains(index))
                    {
                        break;
                    }
                    results[i] += valley[index];
                    visited.Add(index);

                    if (routePos==routes[i].Count-1)
                    {
                        routePos = -1;
                    }
                }			 
			}            
            Console.WriteLine(results.Max());            
        }
    }
}
