 using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {  
            //First Task
            int N = int.Parse(Console.ReadLine());
            int lastLamp = 0;
            int[] lamp = new int[N];

            for (int i = 0; i < N; i++)
            {
                lamp[i] = 0;
            }

            for (int i = 0; i < N; i++)
            {
                int k = 2;

                if (lamp[i] == 0)
                {
                    lamp[i] = 1;
                                        
                    for (int j = 0; j< N - k; j++, k++)
                    {
                        if (lamp[j + k] == 0)
                        {
                            lamp[j + k] = 1;
                            lastLamp = j + k;
                        }

                        else
                        {
                            lastLamp = i -1;
                        }
                    }                    
                }
                
            }
            Console.WriteLine(lastLamp);

            //Second Task
            string firstCommands = Console.ReadLine();
            string secondCommands = Console.ReadLine();

            bool bounded = false;
            for (int i = 0; i < firstCommands.Length - 3; i++)
            {
                if (firstCommands[i] == 'S')
                {
                    if (firstCommands[i + 1] == 'R')
                    {
                        if (firstCommands[i + 2] == 'S')
                        {
                            if (firstCommands[i + 3] == 'L')
                            {
                                Console.WriteLine("\"unbounded\"");
                            }
                        }
                    }
                    else if (firstCommands[i + 1] == 'L')
                    {
                        if (firstCommands[i + 2] == 'S')
                        {
                            if (firstCommands[i + 3] == 'R')
                            {
                                Console.WriteLine("\"unbounded\"");
                            }
                        }
                    }
                    else
                    {
                       // Console.WriteLine("\"bounded\"");
                        bounded = true;
                    }
                }
                if (bounded)
                {
                    Console.WriteLine("\"bounded\"");
                }
            }

            for (int i = 0; i < secondCommands.Length - 3; i++)
            {
                if (secondCommands[i] == 'S')
                {
                    if (secondCommands[i + 1] == 'R')
                    {
                        if (secondCommands[i + 2] == 'S')
                        {
                            if (secondCommands[i + 3] == 'L')
                            {
                                Console.WriteLine("\"unbounded\"");
                            }
                        }
                    }
                    else if (secondCommands[i + 1] == 'L')
                    {
                        if (secondCommands[i + 2] == 'S')
                        {
                            if (secondCommands[i + 3] == 'R')
                            {
                                Console.WriteLine("\"unbounded\"");
                            }
                        }
                    }
                    else
                    {
                       // Console.WriteLine("\"bounded\"");
                        bounded = true;
                    }
                }
                if (bounded)
                {
                    Console.WriteLine("\"bounded\"");
                }
            }

            
        }
    }
}
