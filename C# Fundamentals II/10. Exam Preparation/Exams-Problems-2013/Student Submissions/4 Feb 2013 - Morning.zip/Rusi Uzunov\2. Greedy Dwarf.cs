
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Linq;

class Program
{
    static void Main()
    {
        
        int[] valey = new int[10000];
        int[] copyOfvaley = new int[10000];
        string subjectString = Console.ReadLine();
        int m = int.Parse(Console.ReadLine());
        List<int>[] pattern = new List<int>[m];
        for (int i = 0; i < m; i++)
        {
            pattern[i] = StringToInts(Console.ReadLine()).OfType<int>().ToList();
        }
        
        valey = StringToInts(subjectString);
        
        

        bool[] empty = new bool[valey.Length];
        int mostCoins = 0;
        for (int i = 0; i < m; i++)
        {
            for (int j = 0; j < empty.Length; j++)
            {
                empty[j] = false;
            }
            empty[0] = true;
            bool notEmpty = true;
            int lastStep = 1;
            int coins = valey[0];
            
            while (notEmpty)
            {
                try
                {
                    foreach (int step in pattern[i])
                    {
                        int nextStep = lastStep + step - 1;
                        if (empty[nextStep] == true) { notEmpty = false; break; }
                        coins += valey[nextStep];
                       
                        empty[nextStep] = true;
                        lastStep += step;
                    }
                }
                catch (IndexOutOfRangeException)
                {
                    notEmpty = false;
                }
            }
            if (mostCoins < coins) mostCoins = coins;
            
        }
        Console.WriteLine(mostCoins);
        
    }
    public static int[] StringToInts(string myString)
    {
        List<int> ints = new List<int>();
        string[] strings = myString.Split(',');

        foreach (string s in strings)
        {
            int i;
            if (int.TryParse(s.Trim(), out i))
            {
                ints.Add(i);
            }
        }
        return ints.ToArray();
    }
}
