using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem2
{
    class GreedyDwarf
    {
        
        static void Main()
        {

            // input
            string strValey = Console.ReadLine();
            string[] valey = strValey.Split(',');

            int pattersLength = int.Parse(Console.ReadLine());
            string[] paterns = new string[pattersLength];
            for (int counter = 0; counter < paterns.Length; counter++)
            {
                paterns[counter] = Console.ReadLine();
            }
            // end of input

            //Console.WriteLine();

            int sum=0;
            for (int pattertCounter = 0; pattertCounter < pattersLength; pattertCounter++)
            {
                string[] strPatterIndexes = paterns[pattertCounter].Split(',');
                for (int indexer = 0; indexer < strPatterIndexes.Length; indexer++)
                {
                    int previousIndexer = new int();
                    int nextIndexer = int.Parse(strPatterIndexes[indexer]);
                    if(indexer==0)
                    {
                        previousIndexer=0;
                        sum += int.Parse(strPatterIndexes[indexer]);
                    }
                    else
	                {
                        previousIndexer = int.Parse(strPatterIndexes[indexer-1]);
	                }

                    if (int.Parse(strPatterIndexes[indexer]) < 0)
                    {
                        nextIndexer = (nextIndexer * (-1)) ;
                        previousIndexer = indexer - nextIndexer;
                    }

                    
                    // calculate if this could be executed again.
                    bool continueLoop = false;
                    int summary = 0;
                    int summary2 = 0;

                    foreach (var item in strPatterIndexes)
                    {
                         
                        int index = int.Parse(item);
                        if (index>0)
                        {
                            summary += index;
                        }
                        summary2 += index;
                        if (valey.Length % (summary+1)>1 && summary2>=0)
                        {
                            continueLoop = true;
                        }
                    }
                    //if (valey.Length - int.Parse(strPatterIndexes[indexer]) > 0 && valey.Length - int.Parse(strPatterIndexes[indexer]) < valey.Length)
                   // {
                        
                    //}

                    if (valey.Length == int.Parse(strPatterIndexes[indexer]))
                    {
                        break;
                    }
                    if (!continueLoop)
                    {
                  
                        break;
                    }
                    sum += int.Parse(valey[nextIndexer]);
                }
            }
            Console.WriteLine(sum+1);
        }
    }
}
