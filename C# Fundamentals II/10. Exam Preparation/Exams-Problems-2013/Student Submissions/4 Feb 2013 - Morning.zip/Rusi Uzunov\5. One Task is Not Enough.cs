using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        int N = int.Parse(Console.ReadLine());
        

        
        string text = (Console.ReadLine());
        string text2 = (Console.ReadLine());

        bool[] lampsON = new bool[N];
        for (int i = 0; i < lampsON.Length; i++)
        {
            lampsON[i] = false;
        }
        for (int i = 2; i <= N; i++)
        {
            ShutLamp(lampsON, i);
        }
        if (Check(text)) Console.WriteLine("unbounded");
        else Console.WriteLine("bounded");
        if (Check(text2)) Console.WriteLine("unbounded");
        else Console.WriteLine("bounded");

        
    }
    static bool[] ShutLamp(bool[] lamps, int n)
    {
        bool check = false;
        
        for (int i = 2; i < lamps.Length; i++)
        {
            if (lamps[i] == false) 
            {
                check = true;
                break;
            }
        }
        if (check)
        {
            for (int i = n-1; i < lamps.Length; i += n)
            {
                lamps[i] = true;
            }
        }
        else 
        {
            Console.WriteLine(n);

        } 
        return lamps;
    }

    static bool Check(string expression)
    {
        
        bool cont = false;
        bool cont2 = false;
        for (int i = 1; i < expression.Length; i++)
        {
            if (expression[i].Equals('R') && expression[i - 1].Equals('S')) cont = true;
            if (expression[i].Equals('L') && expression[i - 1].Equals('S')) cont2 = true;
            if (cont && cont2) return true;
        }

        return false;
    }
}
 
