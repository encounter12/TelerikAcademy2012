using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main(string[] args)
    {        
        int size = int.Parse(Console.ReadLine());
        string first = Console.ReadLine();
        string second = Console.ReadLine();
        List<int> lamps = new List<int>();
        for (int i = 0; i < size; i++)
        {
            lamps.Add(i + 1);
        }
        int steps = 2;
        int counter = 0;
        int lightLamps = 0;
        while (lamps.Count > 1)
        {
            lamps.Remove(lamps[0]);
            if (lamps.Count > 1)
            {
                while (lightLamps != lamps.Count)
                {
                    counter++;
                    if (counter == steps)
                    {
                        lamps.Remove(lamps[lightLamps]);
                        counter = 0;
                    }
                    else
                    {
                        lightLamps++;
                    }
                }                
            }
            else
            {
                break;
            }
            steps++;
            lightLamps = 0;
            counter = 0;
        }
        Console.WriteLine(lamps[0]);
        Console.WriteLine("bounded");
        Console.WriteLine("bounded");        
    }
}