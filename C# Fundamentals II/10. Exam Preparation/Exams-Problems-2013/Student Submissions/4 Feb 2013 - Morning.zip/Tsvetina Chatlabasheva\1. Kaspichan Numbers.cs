using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace _1.KaspichanNumbers
{
    class Program
    {
        static string CreateNumbers0to255(int num)
        {
            char[] smallLetters = new char[] {'\0','a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
            char[] bigLetters = new char[] { 'A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            StringBuilder b = new StringBuilder();
 
            int indexSmall = num / 26;
            int indexBig = num % 26;
 
            b.Append(smallLetters[indexSmall]);
            b.Append(bigLetters[indexBig]);
 
            return b.ToString();
 
        }
 
        static void Main(string[] args)
        {
            char[] smallLetters = new char[] { '\0', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
            char[] bigLetters = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            int number = int.Parse(Console.ReadLine());
            StringBuilder b = new StringBuilder();
 
            if (number <= 255)
            {
                Console.WriteLine(CreateNumbers0to255(number));
            }
            else
            {
                int num1 = number / 256;
                int num2 = number % 256;
                Console.Write(bigLetters[num1]);
                Console.WriteLine(CreateNumbers0to255(num2));
            }
        }
    }
}