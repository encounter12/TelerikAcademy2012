using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slides
{
    class Program
    {
        static string[, ,] cuboid;
        static int[] ballCoordinates = { 0, 0, 0 };
        static int[] previousBallLocation = { 0, 0, 0 };
        static bool isBallStuck = false;
        static bool isBallOut = false;
        static void FillCuboid(int width, int height, int depth)
        {
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] rowsStr = line.Split('|');
                for (int i = 0; i < rowsStr.Length; i++)
                {
                    rowsStr[i] = rowsStr[i].Trim();
                }
                for (int d = 0; d < depth; d++)
                {
                    int openingBracketIndex = 0;
                    int closingBracketIndex = 0;
                    for (int w = 0; w < width; w++)
                    {
                        openingBracketIndex = rowsStr[d].IndexOf('(', closingBracketIndex);
                        closingBracketIndex = rowsStr[d].IndexOf(')', openingBracketIndex);
                        cuboid[w, h, d] = rowsStr[d].Substring(openingBracketIndex+1, closingBracketIndex - openingBracketIndex-1);
                    }
                }
            }
        }

        static void PrintCuboid()
        {
            for (int d = 0; d < cuboid.GetLength(2); d++)
            {
                for (int h = 0; h < cuboid.GetLength(1); h++)
                {
                    for (int w = 0; w < cuboid.GetLength(0); w++)
                    {
                        Console.Write(cuboid[w,h,d]);
                        Console.Write(" | ");
                    }
                    Console.WriteLine();
                }
                Console.WriteLine();
            }
        }

        static void SlideInstruction(string instruction)
        {
            if (instruction.Contains("FL"))
            {
                ballCoordinates[2]--;
                ballCoordinates[0]--;
            }
            else if (instruction.Contains("FR"))
            {
                ballCoordinates[2]--;
                ballCoordinates[0]++;
            }
            else if (instruction.Contains("BL"))
            {
                ballCoordinates[2]++;
                ballCoordinates[0]--;
            }
            else if (instruction.Contains("BR"))
            {
                ballCoordinates[2]++;
                ballCoordinates[0]++;
            }
            else if (instruction.Contains("L"))
            {
                ballCoordinates[0]--;
            }
            else if (instruction.Contains("R"))
            {
                ballCoordinates[0]++;
            }
            else if (instruction.Contains("F"))
            {
                ballCoordinates[2]--;
            }
            else if (instruction.Contains("B"))
            {
                ballCoordinates[2]++;
            }
            ballCoordinates[1]++;
        }

        static void TeleportInstruction(string instruction)
        {
            int indexOfT = instruction.IndexOf('T');
            string coordsStr = instruction.Substring(indexOfT+1);
            coordsStr = coordsStr.Trim();
            string[] coordsStrings = coordsStr.Split(' ');
            ballCoordinates[0] = int.Parse(coordsStrings[0]);
            ballCoordinates[2] = int.Parse(coordsStrings[1]);
        }

        static void CoordinateBallThroughCuboid(string instruction)
        {
            if(instruction.StartsWith("S "))
            {
                SlideInstruction(instruction);
            }
            else if (instruction.StartsWith("T "))
            {
                TeleportInstruction(instruction);
            }
            else if (string.Compare(instruction, "E")==0)
            {
                ballCoordinates[1]++;
            }
            else if(string.Compare(instruction, "B")==0)
            {
                isBallStuck=true;
            }
        }

        static void IsBallStuckOrFallen()
        {
            if (ballCoordinates[1] >= cuboid.GetLength(1) - 1 && !(string.Compare(cuboid[ballCoordinates[0], ballCoordinates[1], ballCoordinates[2]], "B") == 0))
            {
                isBallOut = true;
            }
            else if (ballCoordinates[0] > cuboid.GetLength(0)-1 || ballCoordinates[0] < 0 || (string.Compare(cuboid[ballCoordinates[0],ballCoordinates[1],ballCoordinates[2]],"B")==0))
            {
                isBallStuck=true;
            }
            else if (ballCoordinates[2] > cuboid.GetLength(2) - 1 || ballCoordinates[2] < 0 || (string.Compare(cuboid[ballCoordinates[0], ballCoordinates[1], ballCoordinates[2]], "B") == 0))
            {
                isBallStuck = true;
            }
        }

        static bool BallPositionOutOfSides()
        {
            bool isBesidesCuboid = false;
            if (ballCoordinates[0] > cuboid.GetLength(0)-1 || ballCoordinates[0] < 0)
            {
                isBesidesCuboid = true;
            }
            else if (ballCoordinates[2] > cuboid.GetLength(2) - 1 || ballCoordinates[2] < 0)
            {
                isBesidesCuboid = true;
            }
            return isBesidesCuboid;
        }
        static bool AreCoordsPositive()
        {
            bool positive = false;
            if (ballCoordinates[0] > 0 && ballCoordinates[1] > 0 && ballCoordinates[2]>0)
            {
                positive = true;
            }
            return positive;
        }

        static void Main(string[] args)
        {
            string sideInput = Console.ReadLine();
            string[] sidesStr = sideInput.Split(' ');
            int width = int.Parse(sidesStr[0]);
            int height = int.Parse(sidesStr[1]);
            int depth = int.Parse(sidesStr[2]);
            cuboid = new string[width, height, depth];
            FillCuboid(width, height, depth);

            string ballInput = Console.ReadLine();
            string[] ballStrIn = ballInput.Split(' ');
            ballCoordinates[0] = int.Parse(ballStrIn[0]);
            ballCoordinates[2] = int.Parse(ballStrIn[1]);

            while (!isBallOut || !isBallStuck)
            {
                if (!BallPositionOutOfSides())
                {
                    previousBallLocation[0] = ballCoordinates[0];
                    previousBallLocation[1] = ballCoordinates[1];
                    previousBallLocation[2] = ballCoordinates[2];
                }
                if (isBallStuck || isBallOut)
                {
                    break;
                }
                CoordinateBallThroughCuboid(cuboid[ballCoordinates[0], ballCoordinates[1], ballCoordinates[2]]);
                IsBallStuckOrFallen();
            }
            if(isBallOut)
            {
                Console.WriteLine("Yes");
                Console.WriteLine("{0} {1} {2}",previousBallLocation[0],previousBallLocation[1],previousBallLocation[2]);
            }
            if(isBallStuck)
            {
                Console.WriteLine("No");
                Console.WriteLine("{0} {1} {2}",previousBallLocation[0],previousBallLocation[1],previousBallLocation[2]);
            }
        }
    }
}
