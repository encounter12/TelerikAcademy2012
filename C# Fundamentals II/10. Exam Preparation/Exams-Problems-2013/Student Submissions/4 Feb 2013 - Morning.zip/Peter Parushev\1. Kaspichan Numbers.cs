using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4._2.exam
{
    class Program
    {
        public static char[,] initialiseDigits()
        {
            char[,] digits = new char[256, 2];
            for (int i = 0; i < 256; i++)
            {
                int indexOne = i / 26;
                int indexTwo = i % 26;
                if (indexOne != 0)
                {
                    digits[i, 0] += (char)('`' + indexOne);
                }
                digits[i, 1] += (char)('A' + indexTwo);
            }
            return digits;

        }


        static void Main(string[] args)
        {
            char[,] digits = initialiseDigits();
            ulong input = ulong.Parse(Console.ReadLine());
            string resultString = "";
            if (input == 0)
            {
                Console.WriteLine("A");
            }
            else
            {
                for (int i = 7; i >= 0; i --)
                {
                    int indexOne = (int)(input / (ulong)Math.Pow(256, i));
                    int indexTwo = (int)((input / (ulong)Math.Pow(256, i))%256);

                    if (indexOne != 0)
                    {
                        if (indexTwo>25)
                        {
                            resultString += digits[indexTwo, 0];
                        }

                        resultString += digits[indexOne, 1];
                        input %= (ulong)Math.Pow(256, i);
                    }
                }
            }
            Console.WriteLine(resultString);
        }
    }
}
