using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Numerics;

class ProblemOne
{
    static string ModuloConverter(BigInteger modulo)
    {
        string outExit = string.Empty;
        while (true)
        {
            BigInteger subModulo = modulo % 26;
            if (modulo / 26 != 0)
            {
                outExit = outExit + (char)((modulo / 26) + 96);
            }
            outExit = outExit + (char)(subModulo  + 'A');
            modulo = modulo / 26;
            break;
            //if (modulo <= 0)
            //{
            //    break;
            //}
            //subModulo = modulo % 26;
            //outExit = outExit + (char)(subModulo + 'A');
            //modulo = modulo / 26;
        }

        return outExit;
    }
    static void Main()
    {
        BigInteger input = BigInteger.Parse(Console.ReadLine());
        List<string> endNumber = new List<string>();

        //for (int i = 0; i < 255; i++)
        //{
        //    Console.WriteLine("{0} {1}", i, ModuloConverter(i));
        //}

        if (input > 0)
        {
            while (input > 0)
            {
                BigInteger modulo = input % 256;
                endNumber.Add(ModuloConverter(modulo));
                input = input / 256;
            }

            string end = endNumber.ToString();

            endNumber.Reverse();
            foreach (var digit in endNumber)
            {
                Console.Write(digit);
            }
            Console.WriteLine();
        }
        else
        {
            Console.WriteLine('A');
        }
    }
}
