using System;
using System.Text;

class KaspichanNumbers
{
    static void Main()
    {
        ulong myNumber = Convert.ToUInt64(Console.ReadLine());
        string digitsHex = DecimalTo16(myNumber);
        string digitsKaspichan = HexToK256(digitsHex);
        Console.WriteLine(digitsKaspichan);
    }
    static String DecimalTo16(ulong number)
    {
        StringBuilder digitsFromLast = new StringBuilder();
        if (number > 0)
        {
            do
            {
                ulong remainder = number & (ulong)15;
                char digit = '0';
                if (remainder > 9)
                {
                    digit = (char)('A' + remainder - 10);
                }
                else
                {
                    digit = (char)('0' + remainder);
                }
                digitsFromLast.Append(digit);
                number = number / (ulong)16;
            }
            while (number > 0);
            int length = digitsFromLast.Length;
            int halfLength = length / 2;
            for (int i = 0; i < halfLength; i++)
            {
                char tempChar = digitsFromLast[i];
                digitsFromLast[i] = digitsFromLast[length - 1 - i];
                digitsFromLast[length - 1 - i] = tempChar;
            }
            return digitsFromLast.ToString();
        }
        if (number == 0) return "0";
        else return "Mistake!";
    }
    static int GetDecDigitFromHex(string s, int i)
    {
        if (s[i] >= 'A') return s[i] - 'A' + 10;
        else return s[i] - '0';
    }

    static int HexToDec(string h)
    {
        int d = 0;

        for (int i = h.Length - 1, p = 1; i >= 0; i--, p *= 16)
            d += GetDecDigitFromHex(h, i) * p;

        return d;
    }
    static string HexToK256(string hexNumber)
    {
        int length = hexNumber.Length;
        StringBuilder digitsReversed = new StringBuilder();
        byte digit=0;
        int index = 0;
        for (index = length-1; index > 0; index -= 2)
        {
            digit = (byte)(HexToDec(hexNumber.Substring(index-1,2)));
            digitsReversed.Append((char)(digit % 26 + 'A'));
            digit /= 26;
            if (digit > 0)
            {
                digitsReversed.Append((char)(digit - 1 + 'a'));
            }
        }
        if (index == 0)
        {
            digit = (byte)(HexToDec(hexNumber.Substring(0,1)));
            digitsReversed.Append((char)(digit % 26 + 'A'));
        }
        int resultLength = digitsReversed.Length;
        int resultHalfLength = length  / 2;
        for (int i = 0; i < resultHalfLength; i++)
        {
            char tempChar = digitsReversed[i];
            digitsReversed[i] = digitsReversed[resultLength - 1 - i];
            digitsReversed[resultLength - 1 - i] = tempChar;
        }
        return digitsReversed.ToString();
    }
}

