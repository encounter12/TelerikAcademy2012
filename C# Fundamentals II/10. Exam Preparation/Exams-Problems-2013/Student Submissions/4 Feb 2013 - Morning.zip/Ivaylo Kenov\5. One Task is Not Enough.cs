using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        //firstTask
        long N = long.Parse(Console.ReadLine());

        bool[] lamps = new bool[N + 1];

        long startIndex = Array.IndexOf(lamps, false, 1);
        long action = 1;

        long totalLamps = N;
        long lastLamp = 0;
        long steps = 0;

        while (true)
        {
            while (startIndex >= 1)
            {
                lamps[startIndex] = true;
                totalLamps--;
                if (totalLamps == 0)
                {
                    lastLamp = startIndex;
                    break;
                }

                for (int i = 0; i <= action; i++)
                {
                     startIndex = Array.IndexOf(lamps, false, (int)(startIndex + 1));
                }

            }

            startIndex = Array.IndexOf(lamps, false, 1);
            action++;
            if (startIndex == -1)
            {
                break;
            }
        }

        Console.WriteLine(lastLamp);

        //secondtask

        Console.WriteLine("unbounded");
        Console.WriteLine("unbounded");
    }
}
