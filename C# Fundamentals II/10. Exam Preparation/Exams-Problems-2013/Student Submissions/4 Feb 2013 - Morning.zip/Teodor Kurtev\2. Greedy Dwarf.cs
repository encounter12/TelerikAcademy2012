using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

class ProblemTwo
{
    static bool isPossoble(int[] vally, int nextPostion)
    {
        if (nextPostion > vally.Length - 1 || nextPostion < 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    static int patternProsses(int[] vally, int[] pattern)
    {
        int currentAmount = 0;
        bool[] viseted = new bool[vally.Length];
        bool isStoped = false;

        currentAmount = vally[0];
        viseted[0] = true;
        int nextDigit = 0;

        while (!isStoped)
        {
            

            for (int i = 0; i < pattern.Length; i++)
            {
                nextDigit = nextDigit + pattern[i];
                if (!isPossoble(vally, nextDigit) || viseted[nextDigit] == true)
                {
                    isStoped = true;
                    break;
                }
                currentAmount = currentAmount + vally[nextDigit];
                viseted[nextDigit] = true;
            }
        }

        return currentAmount;

    }
    static void Main()
    {
        string[] vallyStr = Console.ReadLine().Split(',');
        int[] vally = new int[vallyStr.Length];
        for (int i = 0; i < vally.Length; i++)
        {
            vally[i] = int.Parse(vallyStr[i]);
        }

        int numOfPatterns = int.Parse(Console.ReadLine());
        int maxNumber = int.MinValue;

        for (int i = 0; i < numOfPatterns; i++)
        {
            string[] patternStr = Console.ReadLine().Split(',');
            int[] pattern = new int[patternStr.Length];
            for (int j = 0; j < patternStr.Length; j++)
            {
                pattern[j] = int.Parse(patternStr[j]);
            }

            maxNumber = Math.Max(patternProsses(vally, pattern), maxNumber);
        }
        Console.WriteLine(maxNumber);
    }
}
