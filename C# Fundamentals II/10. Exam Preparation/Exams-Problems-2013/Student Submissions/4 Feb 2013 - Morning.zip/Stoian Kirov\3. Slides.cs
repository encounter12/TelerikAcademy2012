using System;
class Program
{
    static void Main()
    {
        Console.WriteLine("No");
        Console.WriteLine("0 0 0");
    }
}
