using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoroBounds
{
    class Program
    {
        static void Main()
        {
            int a = int.Parse(Console.ReadLine());
            Console.ReadLine();
            Console.ReadLine();
            bool[] lamps = new bool[a + 1];
            lamps[0] = true;
            int i = 2;
            int lastLampTurnedOn = 1;
            while (true)
            {
                int startIndex = Array.IndexOf(lamps, false);
                if (startIndex==-1)
                {
                    break;
                }
                for (int j = startIndex; j <= a; j+=i)
                {
                    if (!lamps[j])
                    {
                        lamps[j] = true;
                        lastLampTurnedOn = j;
                    }
                }
                i++;
            }
            Console.WriteLine(lastLampTurnedOn);
            Console.WriteLine("bounded");
            Console.WriteLine("unbounded");
        }
    }
}
