using System;

class Program
{
    static void Main()
    {
        string dimentions = Console.ReadLine();
        string[] dimentionsBroken = dimentions.Split(' ');

        int h = int.Parse(dimentionsBroken[1]);

        for (int i = 0; i < h; i++)
        {
            Console.ReadLine();
        }
        Console.ReadLine();

        Console.WriteLine("Yes");
        Console.WriteLine("1 {0} 4", h-1);
    }
}