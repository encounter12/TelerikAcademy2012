using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sutrin
{
    class Program
    {
        static void Main(string[] args)
        {
            ulong convert = ulong.Parse(Console.ReadLine());
            string result="";
            if (convert == 0) Console.WriteLine("A");
            else
            {
                while (convert > 0)
                {
                    int next = (char)(convert % 256);
                    int big = (int)(next / 26);
                    char second = (char)('A' + (next % 26));
                    result = second + result;
                    if (big > 0) result = (char)('a'-1+big) + result;
                    convert /= 256;
                }
                Console.WriteLine(result);
            }

        }
    }
}
