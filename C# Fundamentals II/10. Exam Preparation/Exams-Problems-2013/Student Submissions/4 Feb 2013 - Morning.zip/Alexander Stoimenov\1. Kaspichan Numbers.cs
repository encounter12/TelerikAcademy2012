using System;

class Task1
{
    static void Main()
    {
        ulong number = ulong.Parse(Console.ReadLine());
        ulong remainder = 0;
        String converted = "";
        if (number < 256)
        {
            remainder = number % 26;
            converted = (char)(remainder + 'A') + converted;
            number = (number - remainder) / 26;
            if (number > 0)
            {
                do
                {
                    remainder = number % 26;
                    converted = (char)(remainder + '`') + converted;
                    number = (number - remainder) / 26;
                } while (number > 0);
            }
            Console.WriteLine(converted);
        }
        else if (number > 255 && number < 65280)
        {
            number %= 256;
            remainder = number % 26;
            converted = (char)(remainder + 'A') + converted;
            number = ((number - remainder) / 26) + 1;
            if (number > 0)
            {
                do
                {
                    remainder = number % 26;
                    converted = (char)(remainder + 'A') + converted;
                    number = (number - remainder) / 26;
                } while (number > 0);
            }
            Console.WriteLine(converted);
        }
        else if (number > 65279)
        {
            number %= 65536;
            remainder = number % 26;
            converted = (char)(remainder + 'A') + converted;
            number = (number - remainder) / 26;
            if (number > 0)
            {
                do
                {
                    remainder = number % 26;
                    converted = (char)(remainder + 'A') + converted;
                    number = (number - remainder) / 26;
                } while (number > 0);
            }
            Console.WriteLine(converted);
        }
    }
}