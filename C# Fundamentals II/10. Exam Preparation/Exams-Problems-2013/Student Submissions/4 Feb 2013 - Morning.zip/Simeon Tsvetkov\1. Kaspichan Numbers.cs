using System;

class KaspichanNumbers
{
    static void Main()
    {
        ulong inputNumber = ulong.Parse(Console.ReadLine());
        char buffer;
        string outputRepresentation = "";

        while (inputNumber > 6655)
        {
            outputRepresentation = string.Concat(outputRepresentation, "iV");
            inputNumber /= 256;
        }

        ulong first = inputNumber / 256;
        if (first != 0)
        {
            buffer = (char)((ulong)'A'.GetHashCode() + first);
            outputRepresentation = string.Concat(outputRepresentation, buffer.ToString());
        }

        ulong second = (inputNumber % 256) / 26;

        if (second != 0)
        {
            buffer = (char)((ulong)'a'.GetHashCode() + second - 1);
            outputRepresentation = string.Concat(outputRepresentation, buffer.ToString());
        }

        ulong third = (inputNumber % 256) % 26;

        buffer = (char)((ulong)'A'.GetHashCode() + third);
        outputRepresentation = string.Concat(outputRepresentation, buffer.ToString());

        Console.WriteLine(outputRepresentation);
    }
}