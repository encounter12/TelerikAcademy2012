using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main()
    {
        int N = int.Parse(Console.ReadLine());
        int W = int.Parse(Console.ReadLine());
        Console.WriteLine("We happy few         we band"
                            of brothers for he who sheds
                                            his blood
                                      with
 me shall be my brother);
    }
}