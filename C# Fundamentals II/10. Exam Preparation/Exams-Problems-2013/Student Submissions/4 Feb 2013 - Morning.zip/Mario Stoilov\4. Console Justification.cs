using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleJustifications
{
    class ConsoleJustification
    {
        static void Main()
        {
            int N = int.Parse(Console.ReadLine());
            int W = int.Parse(Console.ReadLine());
            List<string> words = new List<string>();
            for (int i = 0; i < N; i++)
            {
                string[] input = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var word in input)
                {
                    words.Add(word);
                }
            }
            while (words.Count>0)
            {
                
                
                //start adding words
                if (words.Count == 1)
                {
                    Console.WriteLine(words[0]);
                    break;
                }
                int GapSize = 1;
                int LastUsedWord = 0;
                int usedLength = words[0].Length;
                //add words until they dont fit
                while (usedLength < W && LastUsedWord < words.Count-1)
                {
                    usedLength += 1 + words[LastUsedWord+1].Length;
                    LastUsedWord++;
                    

                }
                
                if (usedLength==W)
                {
                    Console.Write(words[0]);
                    words.RemoveAt(0);
                    for (int i = 1; i <= LastUsedWord; i++)
                    {
                        Console.Write("{0}{1}", new string(' ',GapSize), words[0]);
                        words.RemoveAt(0);
                    }
                    Console.WriteLine();
                    continue;
                }
                // two words only, they don't fit
                if (LastUsedWord==1)
                {
                    Console.WriteLine(words[0]);
                    words.RemoveAt(0);
                    continue;
                }
                //remove one word
                
                usedLength -= (1 + words[LastUsedWord].Length);
                usedLength -= words[0].Length;
                LastUsedWord--;
                int[] spaces = new int[LastUsedWord];
                int sum = 0;
                for (int i = 0; i < spaces.Length; i++)
                {
                    spaces[i] = 1;
                    sum += spaces[i];
                }
                usedLength = 0;
                for (int i = 0; i <=LastUsedWord; i++)
                {
                    usedLength += words[i].Length;
                }
                usedLength += sum;
                int index = 0;
                while (usedLength!=W)
                {
                    spaces[index]++;
                    usedLength++;
                    index++;
                    if (index>=spaces.Length)
                    {
                        index = 0;
                    }
                }

                Console.Write(words[0]);
                words.RemoveAt(0);
                for (int i = 1; i <= LastUsedWord; i++)
                {

                    Console.Write("{0}{1}", new string(' ', spaces[i-1]), words[0]);
                    words.RemoveAt(0);
                }
                Console.WriteLine();


                ////increase gap size while they fit
                //while (usedLength + words[0].Length < W)
                //{
                //    usedLength = 0;
                //    GapSize++;
                //    for (int i = 1; i <=LastUsedWord; i++)
                //    {
                //        usedLength += GapSize + words[i].Length;
                //    }
                //}
                //if (usedLength  == W - words[0].Length)
                //{
                //    Console.Write(words[0]);
                //    words.RemoveAt(0);
                //    for (int i = 1; i <= LastUsedWord; i++)
                //    {
                //        Console.Write("{0}{1}", new string(' ', GapSize), words[0]);
                //        words.RemoveAt(0);
                //    }
                //    Console.WriteLine();
                //    continue;
                //}
                ////calculate gaps
                //usedLength = 0;
                //for (int i = 0; i <=LastUsedWord; i++)
                //{
                //    usedLength += words[i].Length;
                //}
                //int gapChangeIndex = 0;
                //for (int i = 1; i <=LastUsedWord; i++)
                //{
                //    if ((i)*GapSize+(LastUsedWord-i)*(GapSize-1)+usedLength==W)
                //    {
                //        gapChangeIndex = i;
                //        break;
                //    }
                //}
                //Console.Write(words[0]);
                //words.RemoveAt(0);
                //for (int i = 1; i <= LastUsedWord; i++)
                //{
                    
                //    Console.Write("{0}{1}", new string(' ', GapSize), words[0]);
                //    words.RemoveAt(0);
                //    if (i == gapChangeIndex)
                //    {
                //        GapSize--;
                //    }
                //}
                //Console.WriteLine();
            }
        }
    }
}
