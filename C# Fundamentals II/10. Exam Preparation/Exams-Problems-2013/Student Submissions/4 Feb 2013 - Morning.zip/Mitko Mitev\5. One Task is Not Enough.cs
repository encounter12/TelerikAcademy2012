using System;

    class Program
    {
        static void Main()
        {

            int numLamps = int.Parse(Console.ReadLine());

            char[] lamps = new char[numLamps];
            int step=2;
            int start=0;
            int last = 0;
            int k = 0;
            for (int i = 0; i < lamps.Length; i++)
            {
                lamps[i] = '.';
            }

            for (int j = 0; j < lamps.Length; j++)
            {
                for (int l = 0; l < lamps.Length; l++)
                {
                    if (lamps[l] == '.')
                    {
                        start = l;
                        break;
                    }
                }
                for (k = start; k < lamps.Length; k = k + step)
                {
                    if (lamps[k] == '.')
                    {
                        lamps[k] = '!';

                        last = k;
                    }
                }
                
                step++;
            }
            Console.WriteLine(last+1);

            

            

        }
    }
