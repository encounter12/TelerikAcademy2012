using System;

class GreedyDwarf
{
    static void Main()
    {
        string userInput = Console.ReadLine();
        string[] inpToInt = userInput.Split(',');
        int[] valley = new int[inpToInt.Length];
        for (int i = 0; i < inpToInt.Length; i++)
        {
            valley[i] = int.Parse(inpToInt[i]);
        }

        short M = short.Parse(Console.ReadLine());
        int[][] pattern = new int[M][];

        for (int i = 0; i < M; i++)
        {
            string input = Console.ReadLine();
            string[] inputInArray = input.Split(',');
            pattern[i] = new int[inputInArray.Length];

            for (int j = 0; j < inputInArray.Length; j++)
            {
                pattern[i][j] = int.Parse(inputInArray[j]);
            }

        }

        //int[] valley = new int[] { 1, 3, -6, 7, 4, 1, 12 };
        //int[][] pattern = new int[3][];
        //pattern[0] = new int[] { 1, 2, 2, };
        //pattern[1] = new int[] { 1, 3, -2, };
        //pattern[2] = new int[] { 1, -1, };

        GetGold(valley, pattern);
    }
    static void GetGold(int[] valley, int[][] pattern)
    {
        long sum = 0;
        long index = 0;
        long bestSum = long.MinValue;
        long[] visited = new long[valley.Length];
        long visitedInd = 0;
        for (int i = 0; i < pattern.GetLength(0); i++)
        {
            sum = 0;
            index = 0;
            visitedInd = 0;
            visited = new long[valley.Length];
            for (int j = 0; j < pattern[i].GetLength(0); j++)
			{
                if (index < 0 || index > valley.Length)
                {
                    break;
                }
                sum = sum + valley[index];
                visited[visitedInd] = index;
                visitedInd++;
                index = index + pattern[i][j];

                if(j==pattern[i].GetLength(0)-1)
                {
                    j = -1;

                }               
                for (int l = 0; l < visited.Length; l++)
                    {
                        if (index==visited[l])
                        {
                            j = 3;
                        break;
                        }                            
                    }
			}

            if (sum > bestSum)
            {
                bestSum = sum;
            } 
        }
        Console.WriteLine(bestSum);
    }
}

