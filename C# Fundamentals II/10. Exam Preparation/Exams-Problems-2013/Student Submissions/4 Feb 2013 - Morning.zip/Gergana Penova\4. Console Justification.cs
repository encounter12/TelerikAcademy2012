using System;
using System.Text;

class ConsoleJustification
{
         static string ExtractText1(string text)//метод, който извлича стринг от 0 до последния срещан символ .
    {
        string text1 = "";
        int interval = text.LastIndexOf(" ");
        if (interval != -1)
        {
            text1 = text.Remove(interval, 1);
        }
        return text1;
    }

    static void Main()
    {   
        //int interval = 0;
        Console.WriteLine("Please input count of line");
        int N = int.Parse(Console.ReadLine());
        Console.WriteLine("Please width of line");
        int W = int.Parse(Console.ReadLine());
        string[] line = new string[N];
        for(int i=0; i <= N-1; i++)
        {
           line[i] = Console.ReadLine();
        }

        for (int i = 0; i < N; i++)
        {
            line[i] = ExtractText1(line[i]);
        }

        StringBuilder sb = new StringBuilder();
        
        for (int i = line.Length - 1; i >= 0; i--)
        {
            sb.Append(line[i]);
        }
        Console.WriteLine(sb);

        char[] masiveChar = new char[sb.Length];

        for (int i = 0; i <= sb.Length - 1; i++)
        {
            masiveChar[i] = sb[i];
        }

        char[,] matrixChar = new char[N, W];

        for (int m = 0; m <= N-1; m++)
        {
            for (int n = 0; n <= W-1; n++)

            {
                matrixChar[m,n] = masiveChar[m + n];
                Console.Write(matrixChar[m, n]);
            }
            Console.WriteLine();
        }
    }
}