using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
 
class Kaspichan
{
    static void Main(string[] args)
    {
        ulong division = 0;
        ulong input = ulong.Parse(Console.ReadLine());
        StringBuilder result = new StringBuilder();
        StringBuilder final = new StringBuilder();
        while (input >= 0)
        {
            if (input >= 256)
            {
                division = input % 256;
                result.Append(ConvertNumbers((int)(division)));
                input = input / 256;
 
            }
            else
            {
                result.Append(ConvertNumbers((int)(input)));
                break;
            }
        }
        for (int i = result.Length -1; i >=0; i--)
        {
            final.Append(result[i]);
        }
        Console.WriteLine(final);
    }
    static string ConvertNumbers(int i)
    {
        int temp = 0;
        StringBuilder tempResult = new StringBuilder();
        if (i < 26)
        {
            tempResult.Append(ConvertSmallNumbers(i));
        }
        else if (i >= 26 && i <= 51)
        {
            temp = i - 26;
            tempResult.Append(ConvertSmallNumbers(temp));
            tempResult.Append('a');
        }
        else if (i >= 52 && i <= 77)
        {
            temp = i - 52;
            tempResult.Append(ConvertSmallNumbers(temp));
            tempResult.Append('b');
        }
        else if (i >= 78 && i <= 103)
        {
            temp = i - 78;
            tempResult.Append(ConvertSmallNumbers(temp));
            tempResult.Append('c');
        }
        else if (i >= 104 && i <= 129)
        {
            temp = i - 104;
            tempResult.Append(ConvertSmallNumbers(temp));
            tempResult.Append('d');
        }
        else if (i >= 130 && i <= 155)
        {
            temp = i - 130;
            tempResult.Append(ConvertSmallNumbers(temp));
            tempResult.Append('e');
        }
        else if (i >= 156 && i <= 181)
        {
            temp = i - 156;
            
            tempResult.Append(ConvertSmallNumbers(temp));
             tempResult.Append('f');
        }
        else if (i >= 182 && i <= 207)
        {
            temp = i - 182;
            tempResult.Append(ConvertSmallNumbers(temp));
             tempResult.Append('g');
        }
        else if (i >= 208 && i <= 233)
        {
            temp = i - 208;
            tempResult.Append(ConvertSmallNumbers(temp));
            tempResult.Append('h');
        }
        else if (i >= 234 && i <= 255)
        {
            temp = i - 234;
            tempResult.Append(ConvertSmallNumbers(temp));
            tempResult.Append('i');
        }
 
        return tempResult.ToString();
    }
    static char ConvertSmallNumbers(int i)
    {
        char numberCh;
        switch (i)
        {
            case 0: numberCh = 'A'; break;
            case 1 : numberCh = 'B'; break;
            case 2 : numberCh = 'C'; break;
            case 3: numberCh = 'D'; break;
            case 4: numberCh = 'E'; break;
            case 5: numberCh = 'F'; break;
            case 6: numberCh = 'G'; break;
            case 7: numberCh = 'H'; break;
            case 8: numberCh = 'I'; break;
            case 9: numberCh = 'J'; break;
            case 10: numberCh = 'K'; break;
            case 11: numberCh = 'L'; break;
            case 12: numberCh = 'M'; break;
            case 13: numberCh = 'N'; break;
            case 14: numberCh = 'O'; break;
            case 15: numberCh = 'P'; break;
            case 16: numberCh = 'Q'; break;
            case 17: numberCh = 'R'; break;
            case 18: numberCh = 'S'; break;
            case 19: numberCh = 'T'; break;
            case 20: numberCh = 'U'; break;
            case 21: numberCh = 'V'; break;
            case 22: numberCh = 'W'; break;
            case 23: numberCh = 'X'; break;
            case 24: numberCh = 'Y'; break;
            case 25: numberCh = 'Z'; break;
            default: numberCh = '*'; break;
       }
        return numberCh;
    }
}