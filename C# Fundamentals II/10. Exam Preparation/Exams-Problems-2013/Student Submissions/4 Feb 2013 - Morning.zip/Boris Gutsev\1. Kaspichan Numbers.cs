using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class KaspichanNumbers
{
    static void Main(string[] args)
    {
        string[] kaspichanNumbers = GenerateKaspichanNumbers();
        ulong number = ulong.Parse(Console.ReadLine());
        List<string> result = new List<string>();
        ulong kaspichanBase = 256;

        while (true)
        {
            ulong remainder = number % kaspichanBase;
            if (remainder < kaspichanBase)
            {
                result.Add(kaspichanNumbers[(int)remainder]);               
            }
            number = number / kaspichanBase;
            if (number == 0)
            {
                break;
            }
        }
        result.Reverse();
        StringBuilder sb = new StringBuilder();
        foreach (string item in result)
        {
            sb.Append(item);
        }
        Console.WriteLine(sb);
    }
  
    private static string[] GenerateKaspichanNumbers()
    {
        char[] upperCaseAlphabet = new char[((int)'Z' - (int)'A') + 1];
        for (int count = 0; count < upperCaseAlphabet.Length; count++)
        {
            upperCaseAlphabet[count] = (char)((int)'A' + count);
        }
        char[] lowerCaseAlphabet = new char[((int)'z' - (int)'a') + 1];
        for (int count = 0; count < lowerCaseAlphabet.Length; count++)
        {
            lowerCaseAlphabet[count] = (char)((int)'a' + count);
        }

        string[] kaspichanNumbers = new string[256];        
        for (int i = 0, k = -1, j = 0; i < kaspichanNumbers.Length; i++,j++)
        {
            if (k >= 0)
            {
                kaspichanNumbers[i] = lowerCaseAlphabet[k].ToString() + upperCaseAlphabet[j];
            }
            else
            {
                kaspichanNumbers[i] = upperCaseAlphabet[i].ToString();
            }
            if (j == upperCaseAlphabet.Length - 1)
            {
                k++;
                j = -1;
            }
        }
        return kaspichanNumbers;
    }
}

