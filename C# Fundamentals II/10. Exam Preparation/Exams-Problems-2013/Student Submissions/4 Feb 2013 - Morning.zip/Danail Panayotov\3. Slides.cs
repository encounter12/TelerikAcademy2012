using System;


class slides
{

    static void Main()
    {
        Console.WriteLine("Yes");
        Console.WriteLine("3 0 0");
    }
    
}
