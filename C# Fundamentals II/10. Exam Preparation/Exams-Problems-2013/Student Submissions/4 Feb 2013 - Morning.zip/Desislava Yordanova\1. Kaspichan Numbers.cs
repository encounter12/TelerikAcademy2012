using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustExamPartII
{
    class JustExamPartII
    {
        static void Main(string[] args)
        {
            ulong number = ulong.Parse(Console.ReadLine());
            ulong baseKaspichan = 256;
            ulong utilityNum = number/baseKaspichan;
            ulong utilityReminder;
            StringBuilder kaspichanNumber = new StringBuilder();
            Stack<ulong> stackNumber = new Stack<ulong>();

            if (number<baseKaspichan)
            {
                kaspichanNumber = Convert(number);
            }
            else
            {
                while (utilityNum>0)
                { 
                    utilityReminder = utilityNum % baseKaspichan;
                    utilityNum /= baseKaspichan;
                    stackNumber.Push(utilityReminder);
                    
                }
                foreach (var currentNum in stackNumber)
                {
                    kaspichanNumber.Append(Convert(currentNum));
                }
                
                kaspichanNumber.Append(Convert(number%256));
            }

            Console.WriteLine(kaspichanNumber);
        }

        private static StringBuilder Convert(ulong number)
        {
            ulong decimalPart = number / 26;
            ulong reminder = number % 26;
            StringBuilder converted = new StringBuilder();


            converted.Append(ConvertKaspichan(decimalPart-1).ToLower());
            converted.Append(ConvertKaspichan(reminder));

            return converted;

        }

        private static string ConvertKaspichan(ulong decimalPart)
        {
            switch (decimalPart)
            {
                case 0: return "A";
                case 1: return "B";
                case 2: return "C";
                case 3: return "D";
                case 4: return "E";
                case 5: return "F";
                case 6: return "G";
                case 7: return "H";
                case 8: return "I";
                case 9: return "J";
                case 10: return "K";
                case 11: return "L";
                case 12: return "M";
                case 13: return "N";
                case 14: return "O";
                case 15: return "P";
                case 16: return "Q";
                case 17: return "R";
                case 18: return "S";
                case 19: return "T";
                case 20: return "U";
                case 21: return "V";
                case 22: return "W";
                case 23: return "X";
                case 24: return "Y";
                case 25: return "Z";
                default: return string.Empty;

            }
        }
    }
}
