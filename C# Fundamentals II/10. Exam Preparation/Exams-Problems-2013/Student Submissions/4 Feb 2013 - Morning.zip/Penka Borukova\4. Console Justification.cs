using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

class Justification
{
    static int[] Spaces(int gaps, int len)
    {
        int[] array = new int[gaps];
        int spacesCount;
        int rest;
        if (gaps == 0)
        {
            spacesCount = len;
            rest = 0;
        }
        else
        {
            spacesCount = len / gaps;
            rest = len % gaps;
        }
        
        for (int i = 0; i <rest; i++)
        {
            array[i] = spacesCount + 1;
        }
        for (int i = rest; i < gaps; i++)
        {
            array[i] = spacesCount;
        }
        return array;
    }

    static void Main(string[] args)
    {
        int rowsCount = int.Parse(Console.ReadLine());
        int maxLength = int.Parse(Console.ReadLine());

        string[] seq = new string[rowsCount];
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < rowsCount; i++)
        {

            seq[i] = Console.ReadLine();
            sb.Append(seq[i]);
            sb.Append(" ");
        }
        string text = sb.ToString();
        MatchCollection matches = Regex.Matches(text, @"\w+");
        sb.Clear();
        foreach (Match match in matches)
        {
            sb.Append(match.ToString() + " ");
        }
        text = sb.ToString();
        sb.Clear();
        for (int i = 0; i < matches.Count; i++)
        {
            int wordsCount = 0;
            if (sb.ToString().Length + 1 + matches[i].ToString().Length <= maxLength)
            {
                if (sb.ToString().Length == 0)
                {
                    sb.Append(matches[i]);
                    wordsCount++;
                }
                else
                {
                    sb.Append(" " + matches[i]);
                    wordsCount++;
                }
                if (sb.ToString().Length != 0)
                {
                    if (i == matches.Count - 1)
                    {
                        sb.Append(matches[i]);
                        string str = sb.ToString();
                        string[] words = str.Split(' ');
                        if (words.Length == 1)
                        {
                            Console.WriteLine(str);
                        }
                        else
                        {
                            int spaces = words.Length - 1;
                            int diff = maxLength - str.Length + spaces;

                            int[] s = new int[spaces];
                            s = Spaces(spaces, diff);
                            Console.Write(words[0]);
                            for (int j = 0; j < s.Length; j++)
                            {
                                Console.Write(new string(' ', s[j]) + words[j + 1]);
                            }
                            Console.WriteLine();
                        }
                    }
                }
            }
            else
            {
               
                string str = sb.ToString();
                //Console.WriteLine("string is {0}", str);
                sb.Clear();
                sb.Append(matches[i]);
                if (str.Length == maxLength)
                {
                    Console.WriteLine(str);
                }
                else
                {
                    Words(wordsCount, str, maxLength);
                    
                }
                if (i == matches.Count - 1)
                {
                    Words(1, sb.ToString(), maxLength);
                    //Console.WriteLine(sb.ToString());
                }
            }
        }
        
    }

    static void Words(int wordsCount, string str, int maxLength)
    {
        if (wordsCount == 1)
        {
            Console.WriteLine(str);
        }
        else
        {
            string[] words = str.Split(' ');
            int spaces = words.Length - 1;
            int diff = maxLength - str.Length + spaces;

            int[] s = new int[spaces];
            s = Spaces(spaces, diff);
            Console.Write(words[0]);
            for (int j = 0; j < s.Length; j++)
            {
                Console.Write(new string(' ', s[j]) + words[j + 1]);
            }
            Console.WriteLine();
        }
    }
}
