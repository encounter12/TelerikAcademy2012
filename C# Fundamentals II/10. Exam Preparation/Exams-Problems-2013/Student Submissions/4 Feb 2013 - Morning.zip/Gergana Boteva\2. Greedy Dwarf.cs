using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class GreedyDwarf
{
    static void Main(string[] args)
    {
        string line = Console.ReadLine();
        string[] valleyStr = line.Split(',');
        int[] valley = new int[valleyStr.Length];
        for (int i = 0; i < valleyStr.Length; i++)
        {
            valley[i] = int.Parse(valleyStr[i]);
        }
        
        int patternNumber = int.Parse(Console.ReadLine());
        int[][] patterns = new int[patternNumber][];
        for (int i = 0; i < patternNumber; i++)
        {
            string linePatt = Console.ReadLine();
            string[] linePattStr = linePatt.Split(',');
            patterns[i] = new int[linePattStr.Length];
            for (int j = 0; j < linePattStr.Length; j++)
            {
                patterns[i][j] = int.Parse(linePattStr[j]);
            }
        }
        bool[] check = new bool[valley.Length];
        FilngBool(check);
        int index = 0;
        int[] bestresult = new int[patternNumber];
        int coins = valley[index];
        check[index] =true;
        bool ch = true;
            for (int i = 0; i < patterns.Length; i++)
			{
                while (ch)
                {
                    for (int j = 0; j < patterns[i].Length; j++)
                    {
                        index += patterns[i][j];
                        if (index > valley.Length || index<0 ||check[index] == true)
                        {
                            bestresult[i] = coins;
                            ch = false;
                            break;
                        }
                        else if (check[index] == false)
                        {
                            coins += valley[index];
                            check[index] = true;
                        }

                    }
                }
                ch = true;
                FilngBool(check);
                index = 0;
                coins = valley[index];
                check[index] =true;
			}
            Console.WriteLine(bestresult.Max());
       }
    static void FilngBool(bool[] check)
    {
        for (int i = 0; i < check.Length; i++)
        {
            if (check[i] != false)
            {
                check[i] = false;
            }
        }
     }
}

