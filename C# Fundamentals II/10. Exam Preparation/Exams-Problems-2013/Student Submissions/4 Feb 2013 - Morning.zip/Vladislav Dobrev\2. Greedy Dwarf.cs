using System;
using System.Collections.Generic;

namespace GreedyDwarf
{
    class Program
    {
        static void Main()
        {
            string strValley = Console.ReadLine();
            string[] strValleySplit = strValley.Split(',');
            int[] valley = new int[strValleySplit.Length];
            for (int i = 0; i < strValleySplit.Length; i++)
            {
                valley[i] = int.Parse(strValleySplit[i].Trim());
            }

            int numberOfPatterns = int.Parse(Console.ReadLine());

            List<List<int>> patterns = new List<List<int>>();
            for (int i = 0; i < numberOfPatterns; i++)
            {
                string pattern = Console.ReadLine();
                string[] patternSplit = pattern.Split(',');
                List<int> temp = new List<int>();
                for (int j = 0; j < patternSplit.Length; j++)
                {
                    temp.Add(int.Parse(patternSplit[j].Trim()));
                }

                patterns.Add(temp);
            }

            int max = -1000;
            for (int i = 0; i < patterns.Count; i++)
            {
                List<int> visitedInd = new List<int>();
                visitedInd.Add(0);
                int lastInd = 0;
                int count = valley[lastInd];
                int patternInd = 0;
                while (true)
                {
                    lastInd += patterns[i][patternInd];

                    if (lastInd < 0 || lastInd >= valley.Length)
                    {
                        break;
                    }

                    if (visitedInd.Contains(lastInd))
                    {
                        break;
                    }
                    else
                    {
                        visitedInd.Add(lastInd);
                    }

                    count += valley[lastInd];
                    patternInd++;

                    if (patternInd == patterns[i].Count)
                    {
                        patternInd = 0;
                    }
                }

                if (count > max)
                {
                    max = count;
                }
            }

            Console.WriteLine(max);
        }
    }
}
