using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;

namespace exam
{
    static class Program
    {
        static void Main() {
            var reader = Console.In;

            if (false) {
                reader = new StringReader(
@"12
SSSSR
SRSL");


            }

            var lamps = int.Parse(reader.ReadLine());
            var hs = new HashSet<int>();
            var ix = 2;
            var last_lamp = 0;
            int turn = 2;
            while (hs.Count < lamps) {
                //var arr = hs.ToArray().OrderBy(_i => _i).ToArray();
                //Console.WriteLine(arr);
                var first_lamp = 0;
                for (int ii = 1; ii <= lamps; ii++) {
                    if (!hs.Contains(ii)) {
                        first_lamp = ii;
                        break;
                    }
                }
                var cnt = 0;
                for (int ii = first_lamp; ii <= lamps; ii++) {
                    if (!hs.Contains(ii)) {
                        if (cnt == 0) {
                            last_lamp = ii;
                            hs.Add(ii);
                        }
                        cnt++;
                        cnt %= turn;
                        
                  
                    }
                }

                turn += 1;
            }
            Console.WriteLine(last_lamp);
            Console.WriteLine(Bounded(reader.ReadLine()) ? "bounded" : "unbounded");
            Console.WriteLine(Bounded(reader.ReadLine()) ? "bounded" : "unbounded");
        }

        static bool Bounded(string str) {

            var x = 0;
            var y = 0;

            foreach (var dir1 in new[] { 'D', 'R', 'U', 'L' }) {
                var dx = 1;// 1,0  0,1 -1,0 0,-1
                var dy = 0;
                var dir = dir1;

                switch (dir1) {
                    case 'R':
                        dx = 0;
                        dy = 1;
                        dir = 'U';
                        break;
                    case 'U':
                        dx = -1;
                        dy = 0;
                        dir = 'L';
                        break;
                    case 'L':
                        dx = 0;
                        dy = -1;
                        dir = 'D';
                        break;
                    case 'D':
                        dx = 1;
                        dy = 0;
                        dir = 'R';
                        break;
                    default:
                        break;
                }

                foreach (var ch in dir + str) {
                    if (ch == 'S') {
                        x += dx;
                        y += dy;
                    }
                    else if (ch == 'L') {
                        switch (dir) {
                            case 'R':
                                dir = 'U';
                                break;
                            case 'U':
                                dir = 'L';
                                break;
                            case 'L':
                                dir = 'D';
                                break;
                            case 'D':
                                dir = 'R';
                                break;
                        }
                        GetDir(ch, ref dx, ref dy);
                    }
                    else if (ch == 'R') {
                        switch (dir) {
                            case 'R':
                                dir = 'D';
                                break;
                            case 'D':
                                dir = 'L';
                                break;
                            case 'L':
                                dir = 'U';
                                break;

                            case 'U':
                                dir = 'R';
                                break;

                        }
                        GetDir(ch, ref dx, ref dy);
                    }

                }
                if (x == 0 && y == 0)
                    return true;
            }

            return false;

        }
        static void GetDir(char dir, ref int dx, ref int dy) {
            switch (dir) {
                case 'U':
                    dx = 0;
                    dy = 1;

                    break;
                case 'L':
                    dx = -1;
                    dy = 0;

                    break;
                case 'D':
                    dx = 0;
                    dy = -1;

                    break;
                case 'R':
                    dx = 1;
                    dy = 0;

                    break;
                default:
                    break;
            }
        }

    }
}