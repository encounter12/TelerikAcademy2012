using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static string ReverseString(string str)
    {
        char[] charArr = str.ToCharArray();
        Array.Reverse(charArr);
        return new string(charArr);
    }
    static void Main(string[] args)
    {
        string[] digits = new string[256];
        int indicator = -1;
        for (int i = 'A'; i <= 'Z'; i++)
        {
            indicator++;
            digits[indicator] = ((char)i).ToString();
        }
        int count=25;
        for (int i = 'a'; i <='i'; i++)
		{
            for (int j = 0; j <= 25; j++)
            {
                count++;
                indicator++;
                digits[indicator] = ((char)i).ToString() + digits[j];
                if (count == 255)
                {
                    break;
                }
            }
            if (count==255)
            {   
                break;
            }
		}
     
        ulong num = ulong.Parse(Console.ReadLine());
        if (num==0)
        {   
            Console.WriteLine("A");
            return;
        }
        StringBuilder strBuild = new StringBuilder();
        List<string> list = new List<string>();
        while (num>0)
        {
            ulong index = num % 256;
            list.Add(digits[(int)index]);
            num = num / 256;
        }
        for (int i = list.Count-1; i >= 0; i--)
			{
			 strBuild.Append(list[i]);
			}
        Console.WriteLine(strBuild);
    }
}

