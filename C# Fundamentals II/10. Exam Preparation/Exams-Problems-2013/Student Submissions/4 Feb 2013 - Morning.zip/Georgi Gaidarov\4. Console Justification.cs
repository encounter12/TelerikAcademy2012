using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


/*
5
20
We happy few            we band 
of brothers for he who sheds 
his blood 
with 
me shall be my brother 
 * 
 * 
10
18
Beer beer beer im going for
   a
beer
Beer beer beer im gonna
drink some beer
I love drinkiiiiiiiiing
beer
lovely
lovely
beer
 * */


namespace zad4
{
    class Program
    {
        static List<string> wds;
        static int rmdwds;
        static int w;

        static string[] mapout;

        static string greed()
        {
            int x = 0;
            int l = 0;
            int wordlonly = 0;
            List<string> wo = new List<string>();

            while (x < wds.Count - rmdwds)
            {
                if ((l == 0 ? 0 : l + 1) + wds[rmdwds+x].Length > w)
                    break;

                if (l > 0) l++; // space after prev word
                l += wds[x + rmdwds].Length;
                wordlonly += wds[x + rmdwds].Length;
                wo.Add(wds[x + rmdwds]);
                x++;
            }


            StringBuilder sb = new StringBuilder();
            if (wo.Count == 1)
            {
                rmdwds++;
                sb.Append(wo[0]);
                sb.Append('\n');
                return sb.ToString();
            }

            int spacestoadd = w - wordlonly;
            int spacesbetw = (int)Math.Floor((double)spacestoadd / (double)(wo.Count - 1));
            int leftspaces = spacestoadd;


            int[] spacer = new int[wo.Count]; // no -1 for safety
            for (int i = 0; i < wo.Count - 1; i++)
            {
                spacer[i] += spacesbetw;
            }
            leftspaces -= (wo.Count - 1) * spacesbetw;
            int inter = 0;
            while (leftspaces > 0)
            {
                spacer[inter]++;
                inter++;
                leftspaces--;
            }




            for (int i = 0; i < wo.Count; i++)
            {
                sb.Append(wo[i]);
                sb.Append(mapout[spacer[i]]);
            }
            rmdwds += wo.Count;

            sb.Append('\n');
            return sb.ToString();
        }

        static void Main(string[] args)
        {
            rmdwds = 0;
            int n = int.Parse(Console.ReadLine());
            w = int.Parse(Console.ReadLine());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < n; i++)
                sb.Append(Console.ReadLine()+'\n');

            wds = sb.ToString().Split(new char[] { ' ', '\n' }, StringSplitOptions.RemoveEmptyEntries).ToList();

            mapout = new string[w];
            mapout[0] = "";
            for(int i=1; i<w; i++)
            {
                StringBuilder sbj = new StringBuilder();
                sbj.Append(mapout[i - 1]);
                sbj.Append(' ');
                mapout[i] = sbj.ToString();
            }
            /*
            foreach(string s in wds)
                Console.WriteLine(s);
            Console.WriteLine();
            */

            StringBuilder sb2 = new StringBuilder();
            while (wds.Count > rmdwds)
                sb2.Append(greed());

            Console.WriteLine(sb2.ToString());
        }
    }
}
