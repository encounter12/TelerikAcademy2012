using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace justification
{
    class Program
    {

        static string splitEqually(string line, int maxWidth)
        {
            string[] words = line.Split(' ');
            int lengthOfWOrds = 0;
            int howManyWords = 0;
            for (int i = 0; i < words.Length ; i++)
            {
               
                lengthOfWOrds += words[i].Length;
                if (lengthOfWOrds > maxWidth)
                {
                    lengthOfWOrds = lengthOfWOrds - words[i].Length;
                    howManyWords = i+1;
                    break;
                }
            }

            int whitespace = maxWidth - lengthOfWOrds;
            if (whitespace!=0)
            {
                whitespace = whitespace % howManyWords;
            }
            
            string newLine = "";
            for (int i = 0; i < words.Length; i++)
            {
                if (i == words.Length - 1)
                {
                    newLine += new string(' ', whitespace) + words[i];
                }
                else
                {
                    newLine += words[i] + new string(' ', whitespace);
                }
                
            }
            return newLine;
        }
        static void Main(string[] args)
        {
            int rows = int.Parse(Console.ReadLine());
            int myLimit = int.Parse(Console.ReadLine());
            string[] sentences = new string[rows];
            
            for (int i = 0; i < rows; i++)
            {
                sentences[i] = Console.ReadLine();
            }

            IList<string> sentenceParts = new List<string>();
            for (int counter = 0; counter < sentences.Length; counter++)
            {

                string sentence = sentences[counter];
                string[] words = sentence.Split(new char[] { ' ','\n','\t' }, StringSplitOptions.RemoveEmptyEntries);
                
                sentenceParts.Add(string.Empty);

                int partCounter = 0;

                foreach (string word in words)
                {
                    string trimmedWords = word.Trim();
                    if ((sentenceParts[partCounter] + trimmedWords).Length > myLimit)
                    {
                        partCounter++;
                        sentenceParts.Add(string.Empty);
                    }

                    sentenceParts[partCounter] += trimmedWords + " ";
                }

                
                    //
            }
            foreach (string x in sentenceParts)
            {
                //Console.WriteLine(splitEqually(x,myLimit));
                Console.WriteLine(x);
            }
        }
    }
}
