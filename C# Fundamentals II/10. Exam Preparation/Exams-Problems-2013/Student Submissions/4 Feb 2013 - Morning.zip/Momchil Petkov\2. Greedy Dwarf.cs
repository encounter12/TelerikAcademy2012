using System;
using System.Text;

class Program
{
    static void Main()
    {
        //string valleyNumbers = Console.ReadLine();
        string valleyNumbers = "1, 3, -6, 7, 4, 1, 12";
        string[] vNumbers = valleyNumbers.Split(new[] {',', ' '}, StringSplitOptions.RemoveEmptyEntries);
        int[] values = new int[vNumbers.Length];
        for (int x = 0; x < vNumbers.Length; x++)
        {

            values[x] = Convert.ToInt32(vNumbers[x].ToString());

        }
        int patterns = int.Parse(Console.ReadLine());
        string[] inputPatterns = new string[patterns];
        int sum = values[0];
        int bestSum = 0;
        StringBuilder visitedPositions = new StringBuilder();
        string temp;
        for (int i = 0; i < patterns; i++)
        {
            inputPatterns[i] = Console.ReadLine();
            temp = inputPatterns[i];
            for (int j = 0; j < temp.Length; j++)
            {
                string temparr = "";
                temparr += temp[j];
                string[] stringarr = temparr.Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                int[] values1 = new int[stringarr.Length];
                for (int x = 0; x < stringarr.Length; x++)
                {

                    values1[x] = Convert.ToInt32(stringarr[x].ToString());

                }
                for (int k = 0; k < values.Length; k++)
                {
                    int tempPos = Array.IndexOf(values, values1[k]);
                    sum += values[values1[k]];
                    visitedPositions.Append(tempPos);
                    for (int l = 0; l < visitedPositions.Length; l++)
                    {
                        
                    }
                }
                if (sum > bestSum)
                {
                    bestSum = sum;
                }
            }
        }
        Console.WriteLine(bestSum);


    }
}
