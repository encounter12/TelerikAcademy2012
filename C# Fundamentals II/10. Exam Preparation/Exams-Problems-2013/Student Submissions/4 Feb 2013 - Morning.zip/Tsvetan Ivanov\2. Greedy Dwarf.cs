using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreedyDwarf
{
    class Program
    {
        static int GetSum(int[] road, int[] path) //road mi e dolnoto  path mi e golemiq masiv
        {
            bool[] visited = new bool[path.Length];
            int currentSum = 0;

            int roadPointer = 0;
            int pathPointer = 0;

            currentSum += path[0];
            visited[0] = true;

            while (true)
            {
                if ((pathPointer + road[roadPointer] >= path.Length ||
                     pathPointer + road[roadPointer] < 0) || visited[pathPointer + road[roadPointer]]
                )
                {
                    return currentSum;
                }
                //Console.WriteLine(path[pathPointer + road[roadPointer]]);
                currentSum += path[pathPointer + road[roadPointer]];
                visited[pathPointer + road[roadPointer]] = true;
                pathPointer = pathPointer + road[roadPointer];
                roadPointer++;

                roadPointer %= road.Length;
            }
        }

        static void Main(string[] args)
        {
            string cost = Console.ReadLine();
            string[] tokens = cost.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            int[] costArray = new int[tokens.Length];
            for (int index = 0; index < tokens.Length; index++)
            {
                costArray[index] = int.Parse(tokens[index]);
            }

            int numberOfPaths = int.Parse(Console.ReadLine());

            int currentBestSum = int.MinValue;

            for (int index = 0; index < numberOfPaths; index++)
            {
                string road = Console.ReadLine();
                string[] token = road.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
                int[] roadArray = new int[token.Length];
                for (int index2 = 0; index2 < token.Length; index2++)
                {
                    roadArray[index2] = int.Parse(token[index2]);
                }
                int sum = GetSum(roadArray, costArray);
                if (sum > currentBestSum)
                {
                    currentBestSum = sum;
                }
            }
            Console.WriteLine(currentBestSum);
        }
    }
}