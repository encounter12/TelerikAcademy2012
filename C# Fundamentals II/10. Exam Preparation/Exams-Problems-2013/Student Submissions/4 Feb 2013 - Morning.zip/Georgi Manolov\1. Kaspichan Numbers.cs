using System;
using System.Collections.Generic;
using System.Text;



class KaspichanNumbers
{
    static void Main()
    {
        ulong number = ulong.Parse(Console.ReadLine());

        StringBuilder kasp = new StringBuilder();

        while (number > 0)
        {
            switch (number % 256)
            {
                case 0: kasp.Append('A');
                    break;
                case 1: kasp.Append('B');
                    break;
                case 2: kasp.Append('C');
                    break;
                case 3: kasp.Append('D');
                    break;
                case 4: kasp.Append('E');
                    break;
                case 5: kasp.Append('F');
                    break;
                case 6: kasp.Append('G');
                    break;
                case 7: kasp.Append('H');
                    break;
                case 8: kasp.Append('I');
                    break;
                case 9: kasp.Append('J');
                    break;
                case 10: kasp.Append('K');
                    break;
                case 11: kasp.Append('L');
                    break;
                case 12: kasp.Append('M');
                    break;
                case 13: kasp.Append('N');
                    break;
                case 14: kasp.Append('O');
                    break;
                case 15: kasp.Append('P');
                    break;
                case 16: kasp.Append('Q');
                    break;
                case 17: kasp.Append('R');
                    break;
                case 18: kasp.Append('S');
                    break;
                case 19: kasp.Append('T');
                    break;
                case 20: kasp.Append('U');
                    break;
                case 21: kasp.Append('V');
                    break;
                case 22: kasp.Append('W');
                    break;
                case 23: kasp.Append('X');
                    break;
                case 24: kasp.Append('Y');
                    break;
                case 25: kasp.Append('Z');
                    break;
                default: kasp.Append(number % 256);
                    break;
            }
            number = number / 256;
        }
        for (int i = kasp.Length - 1; i >= 0; i--)
        {
            Console.Write(kasp[i]);
        }
        Console.WriteLine();
    }
}

