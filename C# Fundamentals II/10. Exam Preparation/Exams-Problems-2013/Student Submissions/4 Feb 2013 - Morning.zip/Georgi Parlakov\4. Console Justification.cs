using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4.Justify
{
    class Justify
    {
        static List<string> words = new List<string>();
        static void Main()
        {
            string[] splitters = { " " };
            int linesInitial = int.Parse(Console.ReadLine());  //     10;// 
            int textWidth = int.Parse(Console.ReadLine());//18;//
            string[] lines = new string[linesInitial];
            int nextLine = 0,index = 0;
            for (int i = 0; i < linesInitial; i++)
            {
                lines[i] = Console.ReadLine();
            }
            //lines[0] = "Beer beer beer Im going for";
            //lines[1] = "a";
            //lines[2] = "beer";
            //lines[3] = "Beer beer beer Im gonna";
            //lines[4] = "drink some beer";
            //lines[5] = "I love drinkiiiiiiiiing";
            //lines[6] = "beer";
            //lines[7] = "levely";
            //lines[8] = "levely";
            //lines[9] = "beer";

            
            for (int i = 0; i < lines.Length; i++)
            {
                words.AddRange(lines[i].Split(splitters,StringSplitOptions.RemoveEmptyEntries));
            }
            //do{

            int start =index;
            for (index = 0; index < words.Count; index++)
            {
                if (start == words.Count - 1)
                {
                    WriteLine(start, start, words[start].Length);
                }
                else
                {
                    nextLine += words[index].Length;
                    if (nextLine+(index-start-1) >= textWidth)
                    {
                        index--;
                        WriteLine(start, index, textWidth);
                        nextLine = 0;
                        start = index + 1;
                    }
                    if (index == words.Count - 1)
                    {
                        WriteLine(start, index, textWidth);
                        break;
                    }
                }                
               
            }
            //}while(index<words.Count-1);
        }

        private static void WriteLine(int startindex,int index,int LineLength)
        {
            string largeSpace=" ",smallSpace="";
            StringBuilder line = new StringBuilder();
            do
            {

                for (int i = startindex; i <= index; i++)
                {
                    line.Append(words[i] + largeSpace);
                    if (i == index)
                    {
                        line.Remove(line.Length - largeSpace.Length, largeSpace.Length);
                    }
                }
                if (line.Length == LineLength)
                {
                    break;
                }
                else
                {                    
                    smallSpace += " ";
                    int indexNextWordToInsertSpase = startindex;
                    int spacer = 0;
                    do
                    {
                        if (startindex==index)
                        {                            
                            break;
                        }
                        else
                        {
                            spacer += words[indexNextWordToInsertSpase].Length + smallSpace.Length;
                            line.Insert(spacer, " ");
                            indexNextWordToInsertSpase++;
                        } 
                        spacer++;
                        if (line.Length == LineLength)
                        {
                            break;
                        }
                        if (indexNextWordToInsertSpase==index)
                        {
                            indexNextWordToInsertSpase = startindex;
                            smallSpace += " ";
                            spacer = 0;
                        }
                    } while (indexNextWordToInsertSpase < index);
                    if (line.Length == LineLength || startindex == index)
                    {
                        
                        break;
                    }
                }
                if (line.Length == LineLength || startindex == index)
                {
                    break;
                }               
            } while (true);
            Console.WriteLine(line);

        }
    }
}
