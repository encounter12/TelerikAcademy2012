using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;
namespace exam
{
    class Program
    {
        static void Main() {
            var reader = Console.In;

            if (false) {
                reader = new StringReader(
    @"3 3 3
(S L)(E)(S L) | (S L)(S R)(S L) | (B)(S F)(S L)
(S L)(S F)(E) | (S B)(S F)(T 0 0) | (S L)(S R)(B)
(S FL)(T 0 0)(S FR) | (S FL)(S FL)(S FR) | (S F)(S BR)(S FR)
1 1");

            }
            var line1 = reader.ReadLine().Split(' ');
            var w = int.Parse(line1[0]);
            var h = int.Parse(line1[1]);
            var d = int.Parse(line1[2]);
            var list = new List<Option[,]>();
            var rx = new Regex(@"\(([BEST])\s*([0-9]+\s+|[LRBF])?([0-9]+|[LRBF])?\s*\)", RegexOptions.Compiled);

            for (int ii = 0; ii < h; ii++) {
                var line = reader.ReadLine().ToUpper();
                var layer = new Option[w, d];
                list.Add(layer);
                var ii_d = 0;

                if (line.Split('|').Length != d) {
                    throw new ArgumentException();
                }
                foreach (var row in line.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries)) {
                    var ii_w = 0;
                    if (rx.Matches(row).Count != w) {
                        throw new Exception("blah");
                    }

                    foreach (var mm in rx.Matches(row).Cast<Match>()) {
                        var option = new Option();
                        if (mm.Groups[1].Value == "S") {

                            option.option = 'S';
                            if (mm.Groups[2].Success) {
                                option.s1 = mm.Groups[2].Value[0];
                            }
                            if (mm.Groups[3].Success) {
                                option.s2 = mm.Groups[3].Value[0];
                            }

                        }
                        else if (mm.Groups[1].Value == "T") {
                            option.option = 'T';
                            option.t1 = int.Parse(mm.Groups[2].Value.Trim());
                            option.t2 = int.Parse(mm.Groups[3].Value);
                        }
                        else {
                            option.option = mm.Groups[1].Value[0];
                        }

                        layer[ii_w, ii_d] = option;
                        ii_w += 1;

                    }
                    ii_d += 1;
                }





            }

            var linee = reader.ReadLine().Split(' ');
            var bw = int.Parse(linee[0]);
            var bd = int.Parse(linee[1]);
            var bh = 0;
            var prev_pos = new { bw, bh, bd };
            Action no = () => {
                Console.WriteLine("No");
                Console.WriteLine("{0} {1} {2}", prev_pos.bw, prev_pos.bh, prev_pos.bd);
            };
            Action yes = () => {
                Console.WriteLine("Yes");
                Console.WriteLine("{0} {1} {2}", prev_pos.bw, prev_pos.bh, prev_pos.bd);
            };
   
           
            while (true) {
                
                var option = list[bh][bw, bd];

                if (option.option == 'B') {
                    no();
                    return;
                }
                prev_pos = new { bw, bh, bd };
  
                if (option.option == 'E') {
                    if (bh >= h - 1) {
                        yes();
                        return;
                    }
                    bh += 1;

                    continue;
                }
                if (option.option == 'S') {
                    
                    if (bh >= h - 1) {
                        yes();
                        return;
                    }
                    if (option.s1 == 'F' || option.s2 == 'F') {
                        if (bd <= 0) {
                            no();
                            return;
                        }
                        bd -= 1;
                    }
                    if (option.s1 == 'B' || option.s2 == 'B') {
                        if (bd >= d - 1) {
                            no();
                            return;
                        }
                        bd += 1;
                    }
                    if (option.s1 == 'L' || option.s2 == 'L') {
                        if (bw <= 0) {
                            no();
                            return;
                        }
                        bw -= 1;
                    }
                    if (option.s1 == 'R' || option.s2 == 'R') {
                        if (bw >= w - 1) {
                            no();
                            return;
                        }
                        bw += 1;
                    }
                    //if (bd < 0 || bd >= d) {
                    //    no();
                    //    return;
                    //}
                    //if (bw < 0 || bw >= w) {
                    //    no();
                    //    return;
                    //}
                    bh += 1;
                    continue;
                }
                if (option.option == 'T') {
                    
                    if (option.t1 < 0 || option.t1 >= w) {
                        no();
                        return;
                    }
                    if (option.t2 < 0 || option.t2 >= d) {
                        no();
                        return;
                    }
                    bw = option.t1;
                    bd = option.t2;
                }
            }

        }

    }
}

struct Option
{
    public char option;
    public int t1;
    public int t2;
    public char s1;
    public char s2;

}


