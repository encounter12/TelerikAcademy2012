using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dwarfs
{
    class Program
    {
        static void Main(string[] args)
        {
            long bestSum = 0;
            char[] split = {',',' '};
            string[] input = Console.ReadLine().Split(split, StringSplitOptions.RemoveEmptyEntries);
            int N = input.Length;
            int[] map = new int[N];
            for (int i = 0; i < N; i++) map[i] = int.Parse(input[i]);
            int M = int.Parse(Console.ReadLine());
            int[][] patterns = new int[M][];
            for (int i = 0; i < M; i++)
            {
                input = Console.ReadLine().Split(split, StringSplitOptions.RemoveEmptyEntries);
                int P = input.Length;
                patterns[i] = new int[P];
                for (int j = 0; j < P; j++)
                {
                    patterns[i][j] = int.Parse(input[j]);
                }
            }
            bool[] visited = new bool[N];
            for(int i=0;i<M;i++) {
                for(int j=0;j<visited.Length;j++)visited[j] = false;
                int tempSum = map[0];
                visited[0] = true;
                int start = 0;
                int id = 0;
                while(true) {
                    int next = start+patterns[i][id];
                    if(next<0 || next>=N || visited[next])break;
                    tempSum+=map[next];
                    //Console.WriteLine("next"+next+"collected "+map[next]);
                    visited[next] = true;
                    id = (id+1)%patterns[i].Length;
                    start = next;
                }
                //Console.WriteLine("end");
                if(i==0 || tempSum>bestSum)bestSum = tempSum;
            }
            Console.WriteLine(bestSum);
        }
    }
}
