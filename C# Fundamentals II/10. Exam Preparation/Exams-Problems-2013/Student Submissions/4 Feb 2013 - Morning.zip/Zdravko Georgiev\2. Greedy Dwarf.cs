using System;

namespace exam
{
    class Program
    {
        static void Input()
        {
            string input = Console.ReadLine();

            //strings
            string[] valleyContainer = input.Split(',');
            int[] valley = new int[valleyContainer.Length];
            for (int i = 0; i < valley.Length; i++)
            {
                valley[i] = short.Parse(valleyContainer[i]);
            }

            //pattern count
            int M = int.Parse(Console.ReadLine());

            //strings
            string[][] patternsContainer = new string[M][];
            int[][] patterns = new int[M][];
            for (int i = 0; i < M; i++)
            {
                patternsContainer[i] = Console.ReadLine().Split(',');
                patterns[i] = new int[patternsContainer[i].Length];
                for (int j = 0; j < patternsContainer[i].Length; j++)
                {

                    patterns[i][j] = short.Parse(patternsContainer[i][j]);
                }
            }
            int bestCoins = 0;
            for (int i = 0; i < M; i++)
            {
                int coins = PatternResult(valley, patterns[i]);
                if (coins > bestCoins)
                {
                    bestCoins = coins;
                }
            }
            Console.WriteLine(bestCoins);

        }

        static int PatternResult(int[] valley, int[] pattern)
        {
            bool[] visited = new bool[valley.Length];
            //current sum
            int coins = 0;
            //indexes
            int valleyPosition = 0;
            int patternPosition = 0;
            while (true)
            {
                if (valleyPosition >= valley.Length || valleyPosition < 0 || visited[valleyPosition] == true)
                {
                    break;
                }
                else
                {
                    if (patternPosition >= pattern.Length)
                    {
                        patternPosition = 0;
                    }
                    coins = coins + valley[valleyPosition];
                    visited[valleyPosition] = true;
                    valleyPosition = valleyPosition +  pattern[patternPosition];
                    patternPosition++;
                }
            }
            return coins;
        }
        static void Main()
        {
            Input();
        }
    }
}
