using System;



class Program
{
    static void PrintLoop(string[] alphabet, char toch,int decnum,int length)
    {
        for (int i = 0; i < alphabet.Length; i++)
        {
            
                alphabet[i] = toch + alphabet[i];
            
            
        }
        Console.WriteLine(alphabet[length]);
    }
    static void condition(string[] alphabet, char toch, int decnum, int length) 
    {
         if (decnum==1000)
        {
            toch='D';
            length = decnum - alphabet.Length*13;
            PrintLoop(alphabet, toch, decnum, length);
        }
        else if (decnum>302)
        {
            toch='C';
            length = decnum - alphabet.Length*12;
            PrintLoop(alphabet, toch, decnum, length);
        }
         else if (decnum>277)
        {
            toch = 'B';
            length = decnum-25 - alphabet.Length / 10;
            PrintLoop(alphabet, toch, decnum, length);
        }
        else if (decnum>252)
        {
            toch='A';
            length = decnum - alphabet.Length/10;
            PrintLoop(alphabet, toch, decnum, length);
        }
        else if (decnum>227)
        {
            toch='i';
            length = decnum - alphabet.Length*9;
            PrintLoop(alphabet, toch, decnum, length);
        }
        else if (decnum>202)
        {
            toch='h';
            length = decnum - alphabet.Length*8;
            PrintLoop(alphabet, toch, decnum, length);
        }
        else if (decnum>177)
        {
            toch='g';
            length = decnum - alphabet.Length*7;
            PrintLoop(alphabet, toch, decnum, length);
        }
         else if (decnum>152)
        {
            toch='f';
           length = decnum - alphabet.Length*6;
            PrintLoop(alphabet, toch, decnum,length);
        }
         else if (decnum>127)
        {
            toch='e';
            length = decnum - alphabet.Length*5;
            PrintLoop(alphabet, toch, decnum, length);
        }
         else if (decnum>102)
        {
            toch='d';
            length = decnum - alphabet.Length*4;
            PrintLoop(alphabet, toch, decnum, length);
        }
         else if (decnum>77)
        {
            toch='c';
            length = decnum - alphabet.Length*3;
            PrintLoop(alphabet, toch, decnum, length);
        }
        else if (decnum>51)
        {
            toch='b';
            length = decnum - alphabet.Length*2;
            PrintLoop(alphabet, toch, decnum, length);
        }
        else if (decnum>alphabet.Length)
        {

            toch = 'a';
            length = decnum - alphabet.Length;
            PrintLoop(alphabet, toch, decnum,length);
        }
        else
        {
            Console.WriteLine(alphabet[decnum]);
        }

    }
    static void Main()
    {
        
        int decnum = int.Parse(Console.ReadLine());
        string[] alphabet = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        //string[] smallalphabet = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
        char toch='a';
        int length = 0;
        condition(alphabet, toch, decnum, length);
        
    
    }
}
