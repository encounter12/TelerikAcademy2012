using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _01.KaspichanNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            ulong inputNumber = ulong.Parse(Console.ReadLine());
            
            string[] letterArray = new string[26];
            for (int i = 0; i <= 25; i++)
            {
                for (char letter = 'A'; letter <= 'Z'; letter ++, i++)
                {
                    letterArray[i] =letter.ToString();
                }
            }
            string[] numbers = new string[256];
            for (int i = 0; i < 26; i++)
            {
                numbers[i] = ((char)(i + 'A')).ToString();
            }
            char letters = (char)('a' - 1);
            for (int i = 26; i < 256; i++)
            {
                if (i % 26 == 0)
                    letters++;
                numbers[i] = (letters).ToString() + (char)(i % 26 + 'A');
            }

            StringBuilder resultNumber = new StringBuilder();
            string result = "";
            if (inputNumber == 0)
            {
                Console.WriteLine('A');
            }
            else
            {
                while (inputNumber != 0)
                {
                    resultNumber.Append(numbers[inputNumber % 256]);
                    result = resultNumber.ToString() + result.ToString();
                    resultNumber.Clear();
                    inputNumber /= 256;
                }
            }
            Console.WriteLine(result.ToString());
        }
    }
}
