using System;

class GreedyDwarf
{
    static void Main()
    {
        string inputValley = Console.ReadLine();
        int m = int.Parse(Console.ReadLine());
        string[] patterns = new string[m];

        for (int i = 0; i < m; i++)
        {
            patterns[i] = Console.ReadLine();
        }

        char[] separators = { ',', ' ' };
        string[] valley = inputValley.Split(separators, StringSplitOptions.RemoveEmptyEntries);

        int[] newValley = new int[valley.Length];

        for (int j = 0; j < valley.Length; j++)
		{
			 newValley[j] = int.Parse(valley[j]);
		}


        int total = 0;
        int bestTotal = int.MinValue;

        for (int i = 0; i < patterns.Length; i++)
		{
            string[] currentPattern = patterns[i].Split(separators, StringSplitOptions.RemoveEmptyEntries);

            int[] currentValley = new int[valley.Length];

            for (int k = 0; k < valley.Length; k++)
			{
                currentValley[k] = newValley[k];
			}

            total = 0;
            total += currentValley[0];
            currentValley[0] = 0;
            int currentIndex = 0;
            int patternIndex = 0;

            while (true)
            {
                currentIndex += int.Parse(currentPattern[patternIndex]);
                if ((currentIndex >= currentValley.Length) || ((currentIndex < 0)) || (currentValley[currentIndex] == 0))
                {
                    break;
                }
                else
                {
                    total += currentValley[currentIndex];
                    currentValley[currentIndex] = 0;
                }
                patternIndex++;
                if (patternIndex == currentPattern.Length)
                {
                    patternIndex = 0;
                }
            }
            if (bestTotal < total)
            {
                bestTotal = total;
            }
        }
        Console.WriteLine(bestTotal);



    }
}
