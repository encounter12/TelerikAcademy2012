using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class Kaspichan_Numbers
{
    private static int currentNumSystem;
    private static string[] D = new string[256];
    private static string[] C = new string[26] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
    private static string[] S = new string[26] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };

    public static void Full_D()
    {
        for (int i = 0; i < 26; i++)
        {
            D[i] = C[i];
            //Console.WriteLine(D[i]);
        }

        for (int j = 0; j < 26; j++)
        {
            for (int i = 0; i < 26; i++)
            {
                if (j * 26 + i + 26 > 255)
                {
                    return;
                }
                D[j * 26 + i + 26] = S[j] + C[i];
                //Console.WriteLine(D[j * 26 + i]);
            }
        }

    }

    public static string[] ConvertNumber(string numStr, int system, int systemToConv)
    {
        currentNumSystem = system;
        //string numStr = num.ToString();
        BigInteger sum = BigInteger.Parse(numStr);
        int k = 0;


        string currentString = "0";
        List<string> resStr = new List<string>();
        while (sum != 0)
        {
            currentString = GetDigit(sum % systemToConv);
            sum = sum / systemToConv;
            resStr.Add(currentString);
            k++;
        }
        //string result = new string(numChar.ToArray());

        return (resStr.ToArray());
    }

    private static int GetInt(char c)
    {
        int result = 0;
        switch (c)
        {
            case 'A': result = 10; break;
            case 'a': result = 10; break;

            case 'B': result = 11; break;
            case 'b': result = 11; break;

            case 'C': result = 12; break;
            case 'c': result = 12; break;

            case 'D': result = 13; break;
            case 'd': result = 13; break;

            case 'E': result = 14; break;
            case 'e': result = 14; break;

            case 'F': result = 15; break;
            case 'f': result = 15; break;

            default:
                result = int.Parse(c.ToString());
                break;
        }
        if (result >= currentNumSystem)
        {
            throw new ArgumentException
                ("Current numeral system does not accept current digit \"{0}\" !", "result");
        }
        return result;
    }

    private static string GetDigit(BigInteger c)
    {
        return D[(int)c];
    }



    static void Main(string[] args)
    {
        Full_D();
        string strNum = Console.ReadLine();
        if (strNum == "0" || strNum == "0 " || strNum == " 0")
        {
            Console.WriteLine("0");
            return;
        }
        string[] myNum = ConvertNumber(strNum, 10, 256);

        for (int i = myNum.Length - 1; i >= 0; i--)
        {
            Console.Write(myNum[i]);
        }
        Console.WriteLine();
    }
}
