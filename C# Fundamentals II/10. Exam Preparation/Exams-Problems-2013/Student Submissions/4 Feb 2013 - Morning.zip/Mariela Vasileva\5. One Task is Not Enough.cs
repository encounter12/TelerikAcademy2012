using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


    class ConsoleJustification
    {
        static void Main()
        {
            int N = int.Parse(Console.ReadLine());
            int[] arr=new int[N];
            int num = 1;

            for (int i = 0; i < N; i++)
            {
                arr[i] = num;
                num++;
            }

            for (int i = 0; i < N/2; i++)
            {
                arr[i] = arr[i] + i;
                
                    
                
                

                
               
            }
            Console.WriteLine(arr[N / 2 + 1]);
        }
    }
