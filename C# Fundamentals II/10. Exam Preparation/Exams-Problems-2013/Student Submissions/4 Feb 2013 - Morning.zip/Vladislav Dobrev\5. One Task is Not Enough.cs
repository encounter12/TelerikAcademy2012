using System;

namespace OneTaskIsNotEnough
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string a = Console.ReadLine();
            string b = Console.ReadLine();

            int nResult = AlgoSOE(n);
            string aResult = IsBounded(a);
            string bResult = IsBounded(b);

            Console.WriteLine(nResult);
            Console.WriteLine(aResult);
            Console.WriteLine(bResult);
        }

        static int AlgoSOE(int range, int start = 0)
        {
            bool[] result = new bool[range + 1];
            int lastInd = 0;
            for (int i = start; i < range; i++)
            {
                if (result[i] == false)
                {
                    for (int j = i; j < range; j += i + 2)
                    {
                        result[j] = true;
                        lastInd = j + 1;
                    }
                }
            }

            return lastInd;
        }

        private static string IsBounded(string a)
        {
            int[] startInd = new int[] { 0, 0 };
            int[] ind = new int[2];
            startInd.CopyTo(ind, 0);
            bool up = true;
            bool down = false;
            bool left = false;
            bool right = false;
            int countR = 0;
            int countL = 0;
            int countS = 0;
            for (int j = 0; j < a.Length; j++)
            {
                char currChar = a[j];

                if (up)
                {
                    if (currChar == 'S')
                    {
                        countS++;
                        ind[1]++;
                    }
                    else if (currChar == 'L')
                    {
                        countL++;
                        left = true;
                        up = false;
                        continue;
                    }
                    else if (currChar == 'R')
                    {
                        countR++;
                        right = true;
                        up = false;
                        continue;
                    }
                }
                else if (left)
                {
                    if (currChar == 'S')
                    {
                        countS++;
                        ind[0]--;
                    }
                    else if (currChar == 'L')
                    {
                        countL++;
                        down = true;
                        left = false;
                        continue;
                    }
                    else if (currChar == 'R')
                    {
                        countR++;
                        up = true;
                        left = false;
                        continue;
                    }
                }
                else if (down)
                {
                    if (currChar == 'S')
                    {
                        countS++;
                        ind[1]--;
                    }
                    else if (currChar == 'L')
                    {
                        countL++;
                        right = true;
                        down = false;
                        continue;
                    }
                    else if (currChar == 'R')
                    {
                        countR++;
                        left = true;
                        down = false;
                        continue;
                    }
                }
                else if (right)
                {
                    if (currChar == 'S')
                    {
                        countS++;
                        ind[0]++;
                    }
                    else if (currChar == 'L')
                    {
                        countL++;
                        up = true;
                        right = false;
                        continue;
                    }
                    else if (currChar == 'R')
                    {
                        countR++;
                        down = true;
                        right = false;
                        continue;
                    }
                }
            }

            if (countS != 0)
            {
                return "unbounded";
            }
            else
            {
                return "bounded";
            }
        }
    }
}
