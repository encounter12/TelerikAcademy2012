using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gd
{

    //for (int i = 0; i < a.Length; i++)
    //{
    //    a[i] = Console.ReadLine();
    //    spl = spl = a[i];
    //    //sb = sb.Append(spl.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries));


    //    for (int j = 0; j < sb.Capacity; j++)
    //    {
    //        arr[j] = Convert.ToInt32(sb[j]);
    //    }
    //}
    //for (int j = 0; j < arr.Length; j++)
    //{
    //    Console.WriteLine(arr[j]);
    //}


    class Program
    {
        static void Main(string[] args)
        {
            string map = "";
            string input = Console.ReadLine();
            string[] splitInput = input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            int[] intInput = new int[splitInput.Length];
            bool flag = true;
            int n = int.Parse(Console.ReadLine());
            int[] sumArr = new int[n];
            int sum = 0;
            int x = 0;
            int y = 0;
            int p = 0;
            // nachalniq string e splitnat i sega go wkarwam w INT masiw
            for (int i = 0; i < splitInput.Length; i++)
            {
                intInput[i] = Int32.Parse(splitInput[i]);
            }

            // inicializiram posetenite mesta na false -> nikoe ne e poseteno
            bool[] visited = new bool[intInput.Length];
           
           
            // reshenie na zadachata 
            for (int i = 0; i < n; i++)
            {
                map = Console.ReadLine();
                string[] splitLine = map.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
                int[] mapArr = new int[splitLine.Length];
                for (int j = 0; j < mapArr.Length; j++)
                {
                    mapArr[j] = Int32.Parse(splitLine[j]);
                }
                flag = true;
                x = 0;
                y = 0;
                sum = 0;

                while (flag == true)
                {
                    // ako NE e poseten
                    if (visited[x] == false)
                    {
                        visited[x] = true;
                        sum = sum + intInput[x];
                      
                        // ako SME w masiwa 
                        if ((x + mapArr[y] < intInput.Length) && (x + mapArr[y] > -1))
                            // tuk mai shte failna... da prowerq dali e y ili y + 1
                        {
                            x = x + mapArr[y];
                            if (y < mapArr.Length - 1)
                            {
                                y = y + 1;
                            }
                            else
                            {
                                y = 0;
                            }
                        }
                        // ako NE sme w masiwa
                        else
                        {
                            sumArr[p] = sum;
                            p = p + 1;
                            flag = false;
                            for (int q = 0; q < visited.Length; q++)
                            {
                                visited[q] = false;
                            }
                            break;
                        }
                    }
                        // ako E poseteno
                    else
                    {
                        sumArr[p] = sum;
                        p = p + 1;
                        flag = false;
                        for (int q = 0; q < visited.Length; q++)
                        {
                            visited[q] = false;
                        }
                        break;
                    }

                }
            }
            Array.Sort(sumArr);
            Console.WriteLine(sumArr[sumArr.Length - 1]);
        }
    }
}