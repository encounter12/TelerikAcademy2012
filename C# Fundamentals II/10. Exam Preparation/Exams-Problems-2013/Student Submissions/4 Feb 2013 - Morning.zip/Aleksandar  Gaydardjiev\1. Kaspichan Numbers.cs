﻿using System;
using System.Numerics;

class Program
{
    static string GetChar(BigInteger i)
    {
        if (i<=25) return ((char)('A' + i)).ToString();
        else if (i>25&&i<=51) 
        {
            return (((char)('a')).ToString() + ((char)('A' + i-26)).ToString());
        }
        else if (i > 51 && i <= 77)
        {
            return (((char)('b')).ToString() + ((char)('A' + i - 52)).ToString());
        }
        else if (i > 77 && i <= 103)
        {
            return (((char)('c')).ToString() + ((char)('A' + i - 78)).ToString());
        }
        else if (i > 103 && i <= 129)
        {
            return (((char)('d')).ToString() + ((char)('A' + i - 104)).ToString());
        }
        else if (i > 129 && i <= 155)
        {
            return (((char)('e')).ToString() + ((char)('A' + i - 130)).ToString());
        }
        else if (i > 155 && i <= 181)
        {
            return (((char)('f')).ToString() + ((char)('A' + i - 156)).ToString());
        }
        else if (i > 181 && i <= 207)
        {
            return (((char)('g')).ToString() + ((char)('A' + i - 182)).ToString());
        }
        else if (i > 207 && i <= 233)
        {
            return (((char)('h')).ToString() + ((char)('A' + i - 208)).ToString());
        }
        else if (i > 233 && i <= 255)
        {
            return (((char)('i')).ToString() + ((char)('A' + i - 234)).ToString());
        }
        else
        {
            return "";
        }

    }


    static string Base10ToBaseX(BigInteger d, int x)
    {
        string h = String.Empty;

        if (d==0)
        {
            return h += GetChar(d);
        }
        for (; d != 0; d /= x) h = GetChar(d % x) + h;
        

        return h;
    }


    static void Main()
    {

        BigInteger number = BigInteger.Parse(Console.ReadLine());
        Console.WriteLine(Base10ToBaseX(number, 256));

        
    }
}