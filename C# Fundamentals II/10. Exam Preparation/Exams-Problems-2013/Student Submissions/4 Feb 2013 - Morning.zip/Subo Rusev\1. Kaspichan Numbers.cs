using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
 
class Program
{
    static void Main(string[] args)
    {
        ulong input = ulong.Parse(Console.ReadLine());
        bool isZero = (input == 0);
        Dictionary<int, string> letters = new Dictionary<int, string>();
        int index = 0;
        for (int i = 0; i < 26; i++)
        {
            letters.Add(i, ((char)(i+'A')).ToString());
        }
        index = 26;
        for (int j = 0; j < 10; j++)
        {
            for (int z = 0; z < 26; z++)
            {
                string letter = ((char)(j + 'a')).ToString() + ((char)(z + 'A')).ToString();
                letters.Add(index, letter);
                index++;
            }
             
          
        }
        string result = "";
        while (input != 0)
        {
            int num = (int)(input % 256);
            result = letters[num] + result;
            input /= 256;
        }
        //foreach (var item in letters)
        //{
        //    Console.WriteLine(item.Key + "->" + item.Value);
        //}
        if (isZero)
        {
            Console.WriteLine("A");
        }
        else
        {
            Console.WriteLine(result);
        }
         
 
    }
}