using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
5
20
We happy few        we band
of brothers for he who sheds
his blood
with
me shall be my brother

10
18
Beer beer beer Im going for
   a
beer
Beer beer beer Im gonna
drink some beer
I love drinkiiiiiiiiing
beer
lovely
lovely
beer
 */

class Program
{
    static void Main()
    {
        int numberOfLines = int.Parse(Console.ReadLine());
        int width = int.Parse(Console.ReadLine());

        List<string> words = new List<string>();

        for (int i = 0; i < numberOfLines; i++)
        {
            string[] currentLine = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var item in currentLine)
            {
                words.Add(item);
            }
        }

        List<string> currentLineOutput = new List<string>();

        int currentLenght = 0;
        int wordCount = 0;
        int currentWord = 0;

        StringBuilder output = new StringBuilder();

        while (true)
        {
            if (currentWord == words.Count)
            {
                break;
            }

            while (currentLenght <= width && currentWord < words.Count)
            {
                wordCount++;
                currentLenght += words[currentWord].Length;

                if (currentLenght > width)
                {
                    wordCount--;
                    currentLenght -= words[currentWord].Length;
                    break;
                }

                if (currentLenght == width)
                {
                    currentLineOutput.Add(words[currentWord]);
                    currentWord++;
                    currentLenght++;
                    break;
                }

                currentLineOutput.Add(words[currentWord]);

                currentLenght++;

                currentWord++;
            }

            currentLenght--;

            currentLenght -= (wordCount - 1);

            if (wordCount > 1)
            {
                int whiteSpace = width - currentLenght;
                int fullWhite = whiteSpace / (wordCount - 1);
                int leftWhite = whiteSpace % (wordCount - 1);
                int indexLeft = 0;

                for (int j = 0; j < currentLineOutput.Count; j++)
                {
                    output.Append(currentLineOutput[j]);

                    if (j != currentLineOutput.Count - 1)
                    {
                        output.Append(new string(' ', fullWhite));

                        if (indexLeft < leftWhite)
                        {
                            output.Append(' ');
                            indexLeft++;
                        }
                    }
                }
            }
            else
            {
                output.Append(currentLineOutput[0]);
            }

            output.AppendLine();

            currentLenght = 0;
            wordCount = 0;
            currentLineOutput.Clear();
        }

        output.Remove(output.Length - 2, 2);

        string[] result = output.ToString().Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

        Console.WriteLine(output.ToString());


        //for (int i = 0; i < result.Length; i++)
        //{
        //    if (
        //}




        //for (int i = 0; i < words.Count; i++)
        //{
        //    if (words[i].Length == width && wordCount == 0)
        //    {
        //        output.Append(words[i]);
        //        output.Append("\n\r");

        //        currentLenght = 0;
        //        currentLineOutput.Clear();
        //        wordCount = 0;
        //        continue;
        //    }

        //    currentLenght += words[i].Length;

        //    wordCount++;

        //    currentLineOutput.Add(words[i]);

        //    if (currentLenght < width)
        //    {
        //        currentLenght++;
        //        continue;
        //    }

        //    //todo: one word per line case

        //    if (wordCount <= 2 && currentLenght > width)
        //    {
        //        output.Append(words[0]);
        //        output.Append("\n\r");

        //        wordCount -= 1;
        //        currentLenght = words[i].Length + 1;
        //        currentLineOutput.Clear();
        //        currentLineOutput.Add(words[i]);
        //        continue;
        //    }

        //    if (currentLenght == width)
        //    {
        //        for (int j = 0; j < currentLineOutput.Count; j++)
        //        {
        //            output.Append(currentLineOutput[j]);
        //            if (j != currentLineOutput.Count - 1)
        //            {
        //                output.Append(' ');
        //            }
        //        }

        //        output.Append("\n\r");
        //        currentLenght = 0;
        //        wordCount = 0;
        //        currentLineOutput.Clear();
        //        continue;
        //    }

        //    if (currentLenght > width)
        //    {
        //        currentLenght -= (words[i].Length + 1);
        //        wordCount--;

        //        currentLenght -= wordCount;
        //        currentLenght++;

        //        int whiteSpace = width - currentLenght;

        //        int whiteFull = whiteSpace / (wordCount - 1);
        //        int whiteLeft = whiteSpace % (wordCount - 1);
        //        int leftIndex = 0;

        //        for (int j = 0; j < currentLineOutput.Count - 1; j++)
        //        {
        //            output.Append(currentLineOutput[j]);

        //            if (j != currentLineOutput.Count - 2)
        //            {
        //                output.Append(new string(' ', whiteFull));

        //                if (leftIndex < whiteLeft)
        //                {
        //                    output.Append(' ');
        //                    leftIndex++;
        //                }
        //            }
        //        }

        //        output.Append("\n\r");
        //        currentLenght = words[i].Length + 1;
        //        wordCount = 1;
        //        currentLineOutput.Clear();
        //        currentLineOutput.Add(words[i]);
        //    }
        //}



        //output.Remove(output.Length - 2, 2);
        //Console.WriteLine(output.ToString());
    }
}
