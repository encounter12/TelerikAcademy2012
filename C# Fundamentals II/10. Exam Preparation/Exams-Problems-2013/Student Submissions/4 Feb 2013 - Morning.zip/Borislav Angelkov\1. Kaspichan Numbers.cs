using System;

class Program
{
    static void Main()
    {
        ulong input = ulong.Parse(Console.ReadLine());

        string kaspichan = "";
        string reversed = "";
        char symbol;
        char bigSymbol;

        if (input == 0)
        {
            kaspichan = "A";
        }
        while (input > 0)
        {
            if (input % 256 >= 0 && input % 256 <= 25)
            {
                symbol = (char)((input % 256) + 65);
                kaspichan += symbol;
            }
            if (input % 256 >= 26 && input % 256 <= 51)
            {
                symbol = (char)97;
                bigSymbol = (char)((input % 256) + 65 - 26);
                kaspichan += bigSymbol;
                kaspichan += symbol;

            }
            if (input % 256 >= 52 && input % 256 <= 77)
            {
                symbol = (char)98;
                bigSymbol = (char)((input % 256) + 65 - 52);
                kaspichan += bigSymbol;
                kaspichan += symbol;
            }
            if (input % 256 >= 78 && input % 256 <= 103)
            {
                symbol = (char)99;
                bigSymbol = (char)((input % 256) + 65 - 78);
                kaspichan += bigSymbol;
                kaspichan += symbol;
                
            }
            if (input % 256 >= 104 && input % 256 <= 129)
            {
                symbol = (char)100;
                bigSymbol = (char)((input % 256) + 65 - 104);
                kaspichan += bigSymbol;
                kaspichan += symbol;
            }
            if (input % 256 >= 130 && input % 256 <= 155)
            {
                symbol = (char)101;
                bigSymbol = (char)((input % 256) + 65 - 130);
                kaspichan += bigSymbol;
                kaspichan += symbol;
            }
            if (input % 256 >= 156 && input % 256 <= 181)
            {
                symbol = (char)102;
                bigSymbol = (char)((input % 256) + 65 - 156);
                kaspichan += bigSymbol;
                kaspichan += symbol;
            }
            if (input % 256 >= 182 && input % 256 <= 207)
            {
                symbol = (char)103;
                bigSymbol = (char)((input % 256) + 65 - 182);
                kaspichan += bigSymbol;
                kaspichan += symbol;
            }
            if (input % 256 >= 208 && input % 256 <= 233)
            {
                symbol = (char)104;
                bigSymbol = (char)((input % 256) + 65 - 208);
                kaspichan += bigSymbol;
                kaspichan += symbol;
            }
            if (input % 256 >= 234 && input % 256 <= 255)
            {
                symbol = (char)105;
                bigSymbol = (char)((input % 256) + 65 - 234);
                kaspichan += bigSymbol;
                kaspichan += symbol;
            }
            input = input / 256;
            
        }
        for (int index = 0; index < kaspichan.Length; index++)
        {
            reversed += kaspichan[kaspichan.Length - index - 1];
        }
        Console.WriteLine(reversed);
    }
}

