using System;
  
  
class GreedyDwarves
{
    static void Main()
    {
        string input = Console.ReadLine();
        input = input.Trim();
        string[] numbers = input.Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
  
        int[] valley = new int[numbers.Length];
        for (int i = 0; i < numbers.Length; i++)
        {
            valley[i] = int.Parse(numbers[i]);
        }
  
        bool[] visited = new bool[valley.Length];
  
        int count = 0;
        int biggest = 0;
        int position = 0;
        int movement = 0;
  
        int patterns = int.Parse(Console.ReadLine());
  
        for (int i = 0; i < patterns; i++)
        {
            string patternString = Console.ReadLine();
            patternString = patternString.Trim();
            string[] steps = patternString.Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            int[] pattern = new int[steps.Length];
            for (int j = 0; j < steps.Length; j++)
            {
                pattern[j] = int.Parse(steps[j]);
            }
         
            while (visited[position] != true)
            {
                count += valley[position];
                visited[position] = true;
                position += pattern[movement];
                if (position > valley.Length)
                {
                    break;
                }
                movement++;
                if (movement == pattern.Length)
                {
                    movement = 0;
                }
            }
  
            if (biggest < count)
            {
                biggest = count;
                count = 0;
            }
        }
  
        Console.WriteLine(biggest);
    }
}