using System;
using System.Collections.Generic;

class GreedyDwarf
{
    static void Main()
    {
        string valley = Console.ReadLine();
        char[] separators = {' ', ',' };
        string[] valleyArray = valley.Split(separators,StringSplitOptions.RemoveEmptyEntries);
        int M = int.Parse(Console.ReadLine());
        string[] patterns = new string[M];
        for (int i = 0; i < M; i++)
        {
            patterns[i] = Console.ReadLine();
        }
        string[][] patternsArray = new string[M][];
        for (int i = 0; i < M; i++)
        {
            patternsArray[i] = patterns[i].Split(separators, StringSplitOptions.RemoveEmptyEntries);
        }
        int sum = 0;
        int bestSum = 0;
        for (int i = 0; i < M; i++)
        {
            int[] checkPosition = new int[valleyArray[i].Length];
            for (int j = 0, k = 0; j <= valleyArray[i].Length; k++, j += Convert.ToInt32(patternsArray[i][k]))
            {  
                checkPosition[j] = 1;
                if (k>patternsArray[i].Length)
                {
                    k = 0;
                }
                sum += Convert.ToInt32(valleyArray[j]);
                //j += Convert.ToInt32(patternsArray[i][k]);
                if (j>valleyArray[i].Length)
                {
                    break;
                }
                if (checkPosition[j]==1)
                {
                    break;
                }
            }
            if (sum>bestSum)
            {
                bestSum = sum;
            }
        }
        Console.WriteLine(bestSum);
    }
}
