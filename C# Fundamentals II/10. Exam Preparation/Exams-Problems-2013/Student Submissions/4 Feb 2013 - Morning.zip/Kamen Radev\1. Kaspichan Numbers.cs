using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main()
    {
        ulong number = ulong.Parse(Console.ReadLine());
        StringBuilder kaspichanNum = new StringBuilder();
        if (number == 0)
        {
            Console.WriteLine("A");
            return;
        }
        while (number > 0)
        {
            ulong rest = number % 256;
            string restToString;
            
            if (rest < 26)
            {
                char digit = 'A';
                digit += (char)rest;
                kaspichanNum = kaspichanNum.Insert(0, digit);
            }
            else
            {
                ulong secondSymbol = rest % 26;         
                char digit = 'A';
                digit += (char)secondSymbol;
                kaspichanNum = kaspichanNum.Insert(0, digit);
                ulong firstSymbol = rest / 26;
                digit = '`';
                digit += (char)firstSymbol;
                kaspichanNum = kaspichanNum.Insert(0, digit);
            }


            number /= 256;
            
        }
        Console.WriteLine(kaspichanNum);
    
    }
}