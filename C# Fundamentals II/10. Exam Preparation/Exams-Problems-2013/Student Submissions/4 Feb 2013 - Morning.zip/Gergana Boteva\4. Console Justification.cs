using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class ConsoleJustification
{
    static void Main(string[] args)
    {
        int N = int.Parse(Console.ReadLine());
        int W = int.Parse(Console.ReadLine());
        string[] words;
        for (int i = 0; i < N; i++)
        {
            string lines = Console.ReadLine();
            words = lines.Split(' ');
        }
    }
}