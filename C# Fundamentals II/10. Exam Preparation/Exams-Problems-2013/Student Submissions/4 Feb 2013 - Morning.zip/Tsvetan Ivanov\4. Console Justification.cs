using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleJustification
{
    class Program
    {
        static StringBuilder AddWhiteSpaces(StringBuilder input, int size, List<int> whiteSpaceIndeces)
        {
            int currentIndexInWhiteSpaceArray = 0;
            if (whiteSpaceIndeces.Count == 0)
            {
                whiteSpaceIndeces.Add(input.Length);   
            }
            while (input.Length < size)
            {
                input.Insert( whiteSpaceIndeces[currentIndexInWhiteSpaceArray],' ');
                currentIndexInWhiteSpaceArray++;
                if (currentIndexInWhiteSpaceArray == whiteSpaceIndeces.Count)
                {
                    currentIndexInWhiteSpaceArray = 0;
                }
                for (int index = currentIndexInWhiteSpaceArray; index < whiteSpaceIndeces.Count; index++)
                {
                    whiteSpaceIndeces[index]++; 
                }
            }
            return input;
        }

        static void Justification(string[] words, int lineSize)
        {

            StringBuilder result = new StringBuilder(lineSize);
            int wordPointer = 0;
            while (wordPointer < words.Length )
            {
                List<int> whiteSpaceIndex = new List<int>();
                if (words[wordPointer].Length == lineSize)
                {
                    Console.WriteLine(words[wordPointer]);
                    wordPointer++;
                    continue;
                }
                while (result.Length <= lineSize && wordPointer < words.Length )
                {
                    if (result.Length > 0)
                    {
                        result.Append(' ').Append(words[wordPointer++]);
                    }
                    else
                    {
                        result.Append(words[wordPointer++]);
                    }
                    if (result.Length < lineSize)
                    {
                        whiteSpaceIndex.Add(result.Length);
                    }
                    
                }

                if (result.Length == lineSize)
                {
                    Console.WriteLine(result);
                    result.Clear();
                    continue;
                }
                if (result.Length > lineSize)
                {
                    while (result.Length > lineSize)
                    {                      
                        wordPointer--;
                        result.Remove(result.Length - words[wordPointer].Length - 1 , words[wordPointer].Length + 1 );                                              
                        whiteSpaceIndex.RemoveAt(whiteSpaceIndex.Count - 1);
                    }
                    
                }
                if (result.Length != lineSize)
                {
                   result = AddWhiteSpaces(result, lineSize, whiteSpaceIndex); 
                }
                
                Console.WriteLine(result.ToString().Trim());
                result.Clear();
            }
        }
            
        static void Main(string[] args)
        {
            int sizeOfInput = int.Parse(Console.ReadLine());
            int justificationSize = int.Parse(Console.ReadLine());

            StringBuilder input = new StringBuilder();
            for (int index = 0; index < sizeOfInput; index++)
            {
                input.Append(Console.ReadLine() + " ");
            }
            string[] words = input.ToString().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            //Console.WriteLine();
            Justification(words, justificationSize);
            //StringBuilder a = new StringBuilder("as sym ");
            //a.Remove(2, 3);
            //Console.WriteLine(a);
        }
    }
}