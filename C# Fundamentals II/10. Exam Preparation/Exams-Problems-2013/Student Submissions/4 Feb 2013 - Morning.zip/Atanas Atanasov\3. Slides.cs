using System;
using System.Text;

class Slides
{
	static void Main()
	{
		string sizes = Console.ReadLine();
		string[] sizesAsStr = sizes.Split();
		int cubeW = int.Parse(sizesAsStr[0]);
		int cubeH = int.Parse(sizesAsStr[1]);
		int cubeD = int.Parse(sizesAsStr[2]);

		StringBuilder current = new StringBuilder();
		string[, ,] cube = new string[cubeW, cubeH, cubeD];
		for (int ha = 0; ha < cubeH; ha++)
		{
			string row = Console.ReadLine();
			string[] rowAsStr = row.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
			for (int da = 0; da < cubeD; da++)
			{
				for (int wa = 0; wa < cubeW;)
				{
					foreach (char symbol in rowAsStr[da])
					{
						if (symbol == '(')
						{
							current.Clear();
						}
						else if (symbol == ')')
						{
							cube[wa, ha, da] = current.ToString();
							wa++;
						}
						else
						{
							current.Append(symbol);
						}
					}
				}
			}            
		}

		//Console.WriteLine();
		//Console.WriteLine();
		//Console.WriteLine();
		//for (int he = 0; he < cubeH; he++)
		//{
		//    for (int de = 0; de < cubeD; de++)
		//    {
		//        for (int we = 0; we < cubeW; we++)
		//        {
		//            Console.Write("(" + cube[we, he, de] + ")");
		//        }
		//        Console.Write(" | ");
		//    }
		//    Console.WriteLine();
		//}
		current.Clear();
		string begin = Console.ReadLine();
		string[] beginAsStr = begin.Split();
		int w = int.Parse(beginAsStr[0]);
		int d = int.Parse(beginAsStr[1]);
		int h = 0;
		bool canMove = true;
		string answer = "Yes";
		while (canMove && h < cubeH)
		{
			string coord = cube[w, h, d];
			foreach (char symbol in coord)
			{
				if (symbol == 'S')
				{
					string[] inS = coord.Split();
					string direction = inS[1];
					switch (direction)
					{
						case "L":
							if (w > 0)
							{
								h++;
								w--;
								break;
							}
							else if  (h != cubeH - 1)
                            {
                                canMove = false;
                                answer = "No";
                                break;
                            }
                            h++;
							break;
						case "R":
							if (w != cubeW - 1)
							{
								h++;
								w++;
								break;
							}
							else if  (h != cubeH - 1)
                            {
                                canMove = false;
                                answer = "No";
                                break;
                            }
                            h++;
							break;
						case "F":
							if (d > 0)
							{
								h++; 
								d--;
								break;
							}
							else if  (h != cubeH - 1)
                            {
                                canMove = false;
                                answer = "No";
                                break;
                            }
                            h++;
							break;
						case "B":
							if (d < cubeD - 1)
							{
								h++;
								d++;
								break;
							}
							else if  (h != cubeH - 1)
                            {
                                canMove = false;
                                answer = "No";
                                break;
                            }
                            h++;
							break;
						case "FL":
							if (d > 0 && w > 0)
							{
								h++;
								d--;
								w--;
								break;
							}
                            else if  (h != cubeH - 1)
                            {
                                canMove = false;
                                answer = "No";
                                break;
                            }
                            h++;
							break;
						case "FR":
							if (d > 0 && w != cubeW - 1)
							{
								h++;
								d--;
								w++;
								break;
							}
							else if  (h != cubeH - 1)
                            {
                                canMove = false;
                                answer = "No";
                                break;
                            }
                            h++;
							break;
						case "BL":
							if (d < cubeD - 1 && w > 0)
							{
								h++;
								d++;
								w--;
								break;
							}
							else if  (h != cubeH - 1)
                            {
                                canMove = false;
                                answer = "No";
                                break;
                            }
                            h++;
							break;
						case "BR":
							if (d < cubeD - 1 && w != cubeW - 1)
							{
								h++;
								d++;
								w++;
								break;
							}
							else if  (h != cubeH - 1)
                            {
                                canMove = false;
                                answer = "No";
                                break;
                            }
                            h++;
							break;
					}

					break;
				}
				else if (symbol == 'T')
				{
					string[] inT = coord.Split();
					w = int.Parse(inT[1]);
					d = int.Parse(inT[2]);
					break;
				}
				else if (symbol == 'E')
				{
                    h++;
					break;
				}
				else if (symbol == 'B')
				{
					answer = "No";
					canMove = false;
					break;
				}
			}
		}
		if (h > cubeH - 1 && canMove)
		{
			h = cubeH - 1;
            answer = "Yes";
		}
		
		 Console.WriteLine(answer);
		Console.WriteLine("{0} {1} {2}", w, h, d);
	}
}
