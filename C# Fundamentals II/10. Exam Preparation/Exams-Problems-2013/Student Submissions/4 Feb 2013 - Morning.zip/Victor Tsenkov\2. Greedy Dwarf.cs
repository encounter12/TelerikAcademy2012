using System;

class GreedyDwarf
{
    static void Main()
    {
        string[] firstLine = Console.ReadLine().Split(',');
        int[] coins = new int[firstLine.Length];

        for (int i = 0; i < firstLine.Length; i++)
        {
            coins[i] = int.Parse(firstLine[i]);
        }

        int m = int.Parse(Console.ReadLine());

        int[,] pattern = new int[m, 100];

        for (int row = 0; row < m; row++)
        {
            string[] line = Console.ReadLine().Split(',');

            for (int col = 0; col < 100; col++)
            {
                if (col == line.Length)
                {
                    pattern[row, col] = int.MaxValue;
                    break;
                }
                pattern[row, col] = int.Parse(line[col]);
            }
        }

        bool[] visited = new bool[coins.Length];

        int sum = 0;
        int maxSum = int.MinValue;
        int k = 0;
        bool continuePattern = false;

        for (int i = 0; i < m; i++)
        {
            sum = 0;
            k = 0;
            sum += coins[0];
            visited[0] = true;

            int patternLoop = 0;

            for (int j = 0; j < 100; j++)
            {
                if (pattern[i, j] == int.MaxValue)
                {
                    j = -1;
                    continue;
                }
                else
                {
                    k += pattern[i, j];
                    if (k < 0 || k >= coins.Length || visited[k])
                    {
                        break;
                    }

                    if (!visited[k])
                    {
                        continuePattern = true;
                        sum += coins[k];
                        visited[k] = true;
                    }
                }
            }

            if (maxSum < sum)
            {
                maxSum = sum;
            }

            for (int v = 0; v < visited.Length; v++)
            {
                visited[v] = false;
            }
        }

        Console.WriteLine(maxSum);
    }
}