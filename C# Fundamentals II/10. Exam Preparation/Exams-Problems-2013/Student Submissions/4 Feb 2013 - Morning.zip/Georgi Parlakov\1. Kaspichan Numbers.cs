using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace parlakov
{
    class Program
    {
        static void Main()
        {
            string[] KaspichanianDigits = new string[256];
            List<int> newDigits = new List<int>();
            int digit;
            int index = 0;
            StringBuilder temp = new StringBuilder();
            for (int i = 'a'-1; i <= 'z'; i++)
            {
                if (i!='a'-1)
                {
                    temp.Append((char)i); 
                }
                if (index == 256)
                {
                    break;
                }
                for (int b = 'A'; b <= 'Z'; b++)
                {
                    temp.Append((char)b);
                    KaspichanianDigits[index]=temp.ToString();
                    index++;
                    if (index==256)
                    {
                        break;
                    }
                    temp.Remove(temp.Length - 1,1);
                }
                temp.Clear();
            }
            // Console.WriteLine(KaspichanianDigits[255]);
            //Console.WriteLine(ulong.MaxValue);
            ulong bigInt = ulong.Parse(Console.ReadLine());
            if (bigInt<=255)
            {
                digit = int.Parse((bigInt % 256).ToString());
                Console.WriteLine(KaspichanianDigits[digit]);
                return;
            }
            do
            {
                digit = int.Parse((bigInt % 256).ToString());
                newDigits.Add(digit);
                bigInt /= 256;

            } while (bigInt>0);
            temp.Clear();
            for (int i = newDigits.Count-1; i >= 0; i--)
            {
                temp.Append(KaspichanianDigits[newDigits[i]]);
            }
            Console.WriteLine(temp.ToString());
            
            
        }

    }
}
