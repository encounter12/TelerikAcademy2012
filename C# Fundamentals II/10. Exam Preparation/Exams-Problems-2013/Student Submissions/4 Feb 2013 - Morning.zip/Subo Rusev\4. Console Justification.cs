using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    public static String Justify(String s, Int32 count)
    {
        if (count <= 0)
            return s;

        Int32 middle = s.Length / 2;
        IDictionary<Int32, Int32> spaceOffsetsToParts = new Dictionary<Int32, Int32>();
        String[] parts = s.Split(' ');
        for (Int32 partIndex = 0, offset = 0; partIndex < parts.Length; partIndex++)
        {
            spaceOffsetsToParts.Add(offset, partIndex);
            offset += parts[partIndex].Length + 1; // +1 to count space that was removed by Split
        }
        foreach (var pair in spaceOffsetsToParts.OrderBy(entry => Math.Abs(middle - entry.Key)))
        {
            count--;
            if (count < 0)
                break;
            parts[pair.Value] += ' ';
        }
        return String.Join(" ", parts);
    }

    static void Main(String[] args)
    {
        int numberOfLines = int.Parse(Console.ReadLine());
        int lengthOfLines = int.Parse(Console.ReadLine());
        List<string> allWords = new List<string>();
        for (int i = 0; i < numberOfLines; i++)
        {
            string line = Console.ReadLine();
            char[] splitter = { ' ' };
            string[] tokens = line.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
            foreach (var word in tokens)
            {
                allWords.Add(word.Trim());
            }
        }

        StringBuilder lines = new StringBuilder();
        int length = 0;
        int index = 0;

        List<StringBuilder> wordsOnLine = new List<StringBuilder>();
        wordsOnLine.Add(new StringBuilder());
        foreach (var word in allWords)
        {
            length += word.Length + 1;
            if (length < lengthOfLines)
            {
                wordsOnLine[index].Append(word + " ");
            }
            else
            {
                length = word.Length + 1;
                wordsOnLine.Add(new StringBuilder());
                wordsOnLine[index+1].Append(word + " ");
                index++;
            }

        }
        //Console.WriteLine(lines);
        foreach (var item in wordsOnLine)
        {
            Console.WriteLine(Justify(item.ToString(),lengthOfLines));
        }
    }
}