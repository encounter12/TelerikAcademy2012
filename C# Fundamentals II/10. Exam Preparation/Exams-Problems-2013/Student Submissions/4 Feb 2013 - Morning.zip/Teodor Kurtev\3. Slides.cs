using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
 
class Ball
{
    public int width { get; set; }
    public int height { get; set; }
    public int depth { get; set; }
}
class ProblemThree
{
    static int width, height, depth;
    static Ball ball = new Ball();
 
    static string[, ,] ReadInput()
    {
        string[] dimentions = Console.ReadLine().Split();
        width = int.Parse(dimentions[0]);
        height = int.Parse(dimentions[1]);
        depth = int.Parse(dimentions[2]);
 
        string[, ,] cube = new string[width, height, depth];
 
        for (int h = 0; h < height; h++)
        {
            string[] lineSplit = Console.ReadLine().Split('|');
            for (int d = 0; d < depth; d++)
            {
                string[] subLines = lineSplit[d].Trim().Split(new char[] { '(', ')' }, StringSplitOptions.RemoveEmptyEntries);
                for (int w = 0; w < width; w++)
                {
                    cube[w, h, d] = subLines[w];
                }
            }
        }
 
        return cube;
    }
 
    static bool isPassable(int w, int h, int d)
    {
        bool pass = d >= 0 && w >= 0 && h >= 0 && w < width && h < height && d < depth;
        return pass;
    }
 
    static void Commands(string value)
    {
        if (value == "E")
        {
            ball.height++;
        }
        else if (value.StartsWith("T"))
        {
            string[] subValues = value.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            ball.width = int.Parse(subValues[1]);
            ball.depth = int.Parse(subValues[2]);
        }
        else if (value.StartsWith("S"))
        {
            string[] subValues = value.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string command = subValues[1];
            if (command.StartsWith("L"))
            {
                ball.height++;
                ball.width--;
            }
            else if (command.StartsWith("R"))
            {
                ball.height++;
                ball.width++;
            }
            else if (command.StartsWith("F"))
            {
                ball.height++;
                ball.depth--;
            }
            else if (command.StartsWith("B"))
            {
                ball.height++;
                ball.depth++;
            }
            else if (command.StartsWith("FL"))
            {
                ball.width--;
                ball.height++;
                ball.depth--;
            }
            else if (command.StartsWith("FR"))
            {
                ball.width++;
                ball.height++;
                ball.depth--;
            }
            else if (command.StartsWith("BL"))
            {
                ball.width--;
                ball.height++;
                ball.depth++;
            }
            else if (command.StartsWith("BR"))
            {
                ball.width++;
                ball.height++;
                ball.depth++;
            }
        }
    }
 
    static bool StuckCheck(string[, ,] cube, int w, int h, int d)
    {
        bool isStuck = false;
        string value = cube[w, h, d];
        if (value.StartsWith("B"))
        {
            isStuck = true;
        }
 
        return isStuck;
    }
 
    static void Main()
    {
        string[, ,] cube = ReadInput();
        // ball init
        string[] ballCoord = Console.ReadLine().Split();
        ball.width = int.Parse(ballCoord[0]);
        ball.height = 0;
        ball.depth = int.Parse(ballCoord[1]);
        //init
 
        int currentW = 0;
        int currentH = 0;
        int currentD = 0;
        bool isStuck = false;
 
        while (true)
        {
            currentW = ball.width;
            currentH = ball.height;
            currentD = ball.depth;
            string value = cube[currentW, currentH, currentD];
            Commands(value);
 
            // the basket
            if (isPassable(ball.width, ball.height, ball.depth) && StuckCheck(cube, ball.width, ball.height, ball.depth))
            {
                Console.WriteLine("No");
                Console.WriteLine("{0} {1} {2}", ball.width, ball.height, ball.depth);
                break;
            }
 
            // hit a wall
            if (!isPassable(ball.width, ball.height, ball.depth) && currentH != height - 1)
            {
                Console.WriteLine("No");
                Console.WriteLine("{0} {1} {2}", currentW, currentH, currentD);
                break;
 
            }
 
            // end of the cube
            if (!isPassable(ball.width, ball.height, ball.depth) && currentH == height - 1)
            {
                Console.WriteLine("Yes");
                Console.WriteLine("{0} {1} {2}", currentW, currentH, currentD);
                break;
 
            }
        }
    }
}