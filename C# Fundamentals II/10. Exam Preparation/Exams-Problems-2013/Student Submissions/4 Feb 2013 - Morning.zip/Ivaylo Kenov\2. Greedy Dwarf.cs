using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
test 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000
3
1000,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300
1000,300,-200,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300
1000,-1000,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300,200,-300
 */

class Dwarf
{
    static void Main()
    {
        string[] valleyInput = Console.ReadLine().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

        int[] valley = new int[valleyInput.Length];


        for (int i = 0; i < valleyInput.Length; i++)
        {
            valley[i] = int.Parse(valleyInput[i].Trim());
        }

        int numberOfPatters = int.Parse(Console.ReadLine());

        long maxCoins = long.MinValue;

        for (int i = 0; i < numberOfPatters; i++)
        {

            bool[] wasHere = new bool[valleyInput.Length];

            string[] currentPatternInput = Console.ReadLine().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

            int[] currentPattern = new int[currentPatternInput.Length];

            for (int j = 0; j < currentPattern.Length; j++)
            {
                currentPattern[j] = int.Parse(currentPatternInput[j].Trim());
            }

            long currentCoins = CheckMaxCoins(valley, currentPattern, wasHere);

            if (currentCoins > maxCoins)
            {
                maxCoins = currentCoins;
            }
        }

        Console.WriteLine(maxCoins);
    }

    private static long CheckMaxCoins(int[] valley, int[] currentPattern, bool[] wasHere)
    {
        long coins = 0;

        long currentStep = 0;
        long patternIndex = 0;

        while (true)
        {
            if (patternIndex >= currentPattern.Length || patternIndex < 0)
            {
                patternIndex = 0;
            }

            if (currentStep >= valley.Length || currentStep < 0)
            {
                break;
            }

            if (wasHere[currentStep])
            {
                break;
            }

            coins += valley[currentStep];
            wasHere[currentStep] = true;

            currentStep += currentPattern[patternIndex];

            patternIndex++;
        }

        return coins;
    }
}