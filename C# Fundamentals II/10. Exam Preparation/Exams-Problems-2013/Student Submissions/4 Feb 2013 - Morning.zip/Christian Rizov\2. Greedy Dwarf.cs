using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



class GreedyDwarf
{
    
    static void Main()
    {
        string valleyInput = Console.ReadLine();
        string[] strValley = valleyInput.Split(',');
        int[] valley = new int[strValley.Length];
        for (int i = 0; i < strValley.Length; i++)
        {
            valley[i] = int.Parse(strValley[i]);
        }

        // Razbit e valley.

        int M = int.Parse(Console.ReadLine()); // M
        int[][] allPatterns = new int[M][];
        for (int row = 0; row < M; row++)
        {
            string inputPattern = Console.ReadLine();
            string[] strPatterns = inputPattern.Split(',');
            int[] patterns = new int[strPatterns.Length];
            for (int j = 0; j < strPatterns.Length; j++)
            {
                patterns[j] = int.Parse(strPatterns[j]);
            }

            allPatterns[row] = new int[patterns.Length];
            for (int i = 0; i < patterns.Length; i++)
            {
                allPatterns[row][i] = patterns[i];
            }
        }

        ////printing the valley.
        //for (int i = 0; i < valley.Length; i++)
        //{
        //    Console.Write("{0} ",valley[i]);
        //}
        //Console.WriteLine();
        //// Printing the jagged array.
        //for (int i = 0; i < M; i++)
        //{
        //    int length = allPatterns[i].Length;
        //    for (int j = 0; j < length; j++)
        //    {
        //        Console.Write("{0} ", allPatterns[i][j]);
        //    }
        //    Console.WriteLine();
        //}
        ////input is done.

        int finalSum = 0;
        int pCol = 0;
        for (int row = 0; row < M; row++)
        {
            int currentSum = valley[0];
            
            for (int i = 0; i < allPatterns[row].Length; i++)
            {
                if (pCol < i)
                {
                    pCol++;
                }
                else
                {
                    pCol = 0;
                }

                currentSum = currentSum + allPatterns[row][pCol];
                if (currentSum > finalSum)
                {
                    finalSum = currentSum;
                }
            }
        }

        Console.WriteLine(finalSum);

                                                                                                                                                                                                
    }
}
