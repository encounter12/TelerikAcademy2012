using System;
using System.Text;

    class KaspNumber
    {
        //static int SUM;
        static int[] ConvertToInt(string[] StrArray)
        {
            int[] TheArray = new int[StrArray.Length];
            for(int i = 0; i<TheArray.Length; i++)
            {
                TheArray[i] = int.Parse(StrArray[i]);
            }

            return TheArray;
        }

        static int[] ConvertTheStrings(string str)
        { 
            string[] TheString = str.Split(',');
            int[] IntString = ConvertToInt(TheString);

            return IntString; 
        }

        static void MakeThePaths(int NumberPaths)
        {   

            
        }

        // Prashta mi ARRAy i VALLEY;
        static void FindTheSolution()
        {
            
        }

        static void Main()
        {
            Console.Write("Please enter the valley (numbers separated by \" , \")");
            string str = Console.ReadLine().Replace(" ","");
            int[] TheArray = ConvertTheStrings(str);
            Console.WriteLine(TheArray.Length);
            
            int[] Pattern = new int[3]{ 1, 3, -2};
            bool[] CoinsGet = new bool[7] { true, true, true, true, true, true, true }; // { false, false, true, false, true, true, true }           
            int TheIndex = 0;
            int TheSum = TheArray[TheIndex];
            int ValueElement = 0;
            bool TheLastIndexVisited = true;
           //////////////////////////////////////////

            while (TheLastIndexVisited)
            {
                for (int i = 0; i < Pattern.Length; i++)
                {
                    ValueElement = TheIndex + Pattern[i]; // 3 - 3 = 0
                    
                    if (ValueElement != 0 && CoinsGet[ValueElement])
                    {
                        TheSum += TheArray[ValueElement];
                        if (CoinsGet[ValueElement] == true)
                        {
                            CoinsGet[ValueElement] = false;
                            TheIndex = TheIndex + Pattern[i]; // 0 + 3 = 3
                            TheLastIndexVisited = true;
                        }
                        else
                        {

                            TheLastIndexVisited = false;
                            break;

                        }

                    }
                    else 
                    {
                        TheLastIndexVisited = false;
                        break;
                     }
                }

            }
                Console.WriteLine(TheSum);
            
        }
    }
