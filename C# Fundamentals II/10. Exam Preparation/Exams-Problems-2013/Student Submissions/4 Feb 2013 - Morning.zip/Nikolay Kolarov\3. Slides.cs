using System;
using System.Text.RegularExpressions;

class Slides
{
    static void Main(string[] args)
    {
        string inputStr = Console.ReadLine();
        string[] input = inputStr.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        int width = int.Parse(input[0]);
        int height = int.Parse(input[1]);
        int depth  = int.Parse(input[2]);

        string[, ,] cube = new string[height, depth, width];

        for (int d = 0; d < height; d++)
        {
            string line = Console.ReadLine();
            string[] data = line.Split('|');


            for (int h = 0; h < depth; h++)
            {
                int w = 0;
                string buff = data[w].Trim();
                Regex regex = new Regex(@"[^(]*[)$]");
                //Match m = Regex.Match(buff, @"[^\(]*[\)]",RegexOptions.None);
                foreach (Match match in regex.Matches(buff))
                {
                    string matched = match.Value.Remove(match.Value.LastIndexOf(')'));
                    cube[d, h, w] = matched;
                    w++;
                    //Console.WriteLine(match.Value.Remove(match.Value.LastIndexOf(')')));
                }
            } 
        }

        int currDepth = 0;
        string lineStr = Console.ReadLine();
        string[] lineInt = lineStr.Split(' ');
        int currWidth = int.Parse(lineInt[0]);
        int currHeight = int.Parse(lineInt[1]);
        int beforeWidth = 0;
        int beforeHeight = 0;
        int beforeDepth = 0;
        
        do
        {
            if (cube[currHeight, currDepth, currWidth] == "S L")
            {
                beforeDepth = currDepth;
                beforeHeight = currHeight;
                beforeWidth = currWidth;
                currWidth = currWidth - 1;
                currDepth++;
                

            }
            else if (cube[currHeight, currDepth, currWidth] == "S R")
            {
                beforeDepth = currDepth;
                beforeHeight = currHeight;
                beforeWidth = currWidth;
                currWidth = currWidth + 1;
                currDepth++;
            }
            else if (cube[currHeight, currDepth, currWidth] == "S F")
            {
                beforeDepth = currDepth;
                beforeHeight = currHeight;
                beforeWidth = currWidth;
                currHeight = currHeight - 1;
                currDepth++;
            }
            else if (cube[currHeight, currDepth, currWidth] == "S B")
            {
                beforeDepth = currDepth;
                beforeHeight = currHeight;
                beforeWidth = currWidth;
                currHeight = currHeight + 1;
                currDepth++;
            }
            else if (cube[currHeight, currDepth, currWidth] == "S FL")
            {
                beforeDepth = currDepth;
                beforeHeight = currHeight;
                beforeWidth = currWidth;
                currHeight = currHeight - 1;
                currWidth = currWidth - 1;
                currDepth++;
            }
            else if (cube[currHeight, currDepth, currWidth] == "S FR")
            {
                beforeDepth = currDepth;
                beforeHeight = currHeight;
                beforeWidth = currWidth;
                currHeight = currHeight - 1;
                currWidth = currWidth + 1;
                currDepth++;
            }
            else if (cube[currHeight, currDepth, currWidth] == "S BL")
            {
                beforeDepth = currDepth;
                beforeHeight = currHeight;
                beforeWidth = currWidth;
                currHeight = currHeight + 1;
                currWidth = currWidth - 1;
                currDepth++;
            }
            else if (cube[currHeight, currDepth, currWidth] == "S BR")
            {
                beforeDepth = currDepth;
                beforeHeight = currHeight;
                beforeWidth = currWidth;
                currHeight = currHeight + 1;
                currWidth = currWidth + 1;
                currDepth++;
            }
            else if (cube[currHeight, currDepth, currWidth] == "E")
            {
                beforeDepth = currDepth;
                beforeHeight = currHeight;
                beforeWidth = currWidth;
                currDepth += 1;
            }
            else if (cube[currHeight, currDepth, currWidth] == "B")
            {
                Console.WriteLine("No");
                Console.WriteLine("{0} {1} {2}", currWidth, currHeight+2, 0);
                break;
            }
            else
            {//Only Teleport
              //  Console.WriteLine(cube[currDepth, currHeight, currWidth]);
                string[] teleport = cube[currHeight, currDepth, currWidth].Split(' ');
                if (teleport[0] != "T")
                {
                    Console.WriteLine("Greda");
                    break;
                }
                beforeHeight = currHeight;
                beforeWidth = currWidth;
               // Console.WriteLine(teleport[1]);
             //   Console.WriteLine(teleport[2]);
                currWidth = int.Parse(teleport[1]);
                currHeight = int.Parse(teleport[2]);
            }

            if (currDepth > depth-1)
            {
                Console.WriteLine("Yes");
                Console.WriteLine("{0} {1} {2}",  beforeWidth, beforeHeight+2,0);
                break;
            }
            if (currDepth == depth-1 && currHeight > height-1)
            {
                Console.WriteLine("Yes");
                Console.WriteLine("{0} {1} {2}", beforeWidth, beforeHeight+2, 0);
                break;
            }
            if (currDepth == depth-1 && currWidth > width-1)
            {
                Console.WriteLine("Yes");
                Console.WriteLine("{0} {1} {2}", beforeWidth, beforeHeight+2, 0);
                break;
            }
            if (currHeight > height-1 || currWidth > width-1)
            {
                Console.WriteLine("No");
                break;
            }
            if (currHeight < 0 || currWidth < 0)
            {
                Console.WriteLine("No");
                break;
            }
        }
        while (true);

    }
}