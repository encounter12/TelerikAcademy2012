using System;
using System.Text;
using System.Numerics;
class GreadyDwarf
{
    static void nullTheBool(ref bool[] valleyPath)
    {
        for (int i = 0; i < valleyPath.Length; i++)
        {
            valleyPath[i] = false;
        }
    }
    static void Main()
    {
        char [] spl = {',', ' '};
        string[] s = {", "};
        String[] valStr = Console.ReadLine().Split(s, StringSplitOptions.RemoveEmptyEntries);

        bool[] valleyPath = new bool[valStr.Length];
        short[] valley = new short[valStr.Length];
        for (int i = 0; i < valStr.Length; i++)
        {
            valley[i] = short.Parse(valStr[i]);
        }
        
        short numberPatterns = short.Parse(Console.ReadLine());
        short[][] patterns = new short[numberPatterns][];
        for (int i = 0; i < numberPatterns; i++)
        {
            String[] strPatt = Console.ReadLine().Split(s, StringSplitOptions.RemoveEmptyEntries);
            patterns[i] = new short[strPatt.Length];
            for (int j = 0; j < strPatt.Length; j++)
            {
                patterns[i][j] = short.Parse(strPatt[j]);
            }
        }
        BigInteger res = -1;
        int position = 0;
        BigInteger coins = 0;
        int nextPositon = 0;
        bool breakPattern = false;

        for (int i = 0; i < patterns.Length; i++)
        {
            nullTheBool(ref valleyPath);
            coins = patterns[0][0];
            position = 0;
            valleyPath[0] = true;
            breakPattern = false;
            while (true)
            {
                for (int j = 0; j < patterns[i].Length; j++)
                {
                    nextPositon = position + patterns[i][j];
                    if (nextPositon < 1 || nextPositon >= valley.Length || valleyPath[nextPositon])
                    {
                        breakPattern = true;
                        break;
                    }
                    else
                    {
                        coins += valley[nextPositon];
                        position = nextPositon;
                        valleyPath[position] = true;
                        
                    }
                }
                if (breakPattern)
                {
                    break;
                }
            }
            if (res < coins)
            {
                res = coins;
            }
        }
        Console.Write(res);
    }
}
