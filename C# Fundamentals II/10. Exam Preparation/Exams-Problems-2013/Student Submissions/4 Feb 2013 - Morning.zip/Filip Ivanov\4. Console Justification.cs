using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

class programme
{

    static void Main(string[] args)
    {

        int initialLines = int.Parse(Console.ReadLine());

        int numberOfSymbols = int.Parse(Console.ReadLine());

        string[][] lines = new string[initialLines][];

        for (int i = 0; i < initialLines; i++)
        {

            lines[i] = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

        }

        List<string> words = new List<string>();

        foreach (string[] item in lines)
        {

            foreach (string item2 in item)
            {

                words.Add(item2);

            }

        }





        int startIndex = 0;

        int lastWordIndex = 0;

        int currentLength = 0;

        List<string> linesReady = new List<string>();

        StringBuilder lineReady = new StringBuilder();

        int wordsAdded = 0;

        while (wordsAdded != words.Count)
        {

            for (int i = startIndex; i < words.Count; i++)
            {

                currentLength += words[i].Length + 1;

                if (currentLength <= numberOfSymbols + 1)
                {

                    lineReady.Append(words[i] + " ");

                    wordsAdded++;

                }

                else
                {

                    lastWordIndex = i;

                    lineReady.Remove(lineReady.Length - 1, 1);

                    linesReady.Add(lineReady.ToString());

                    lineReady.Clear();

                    startIndex = lastWordIndex;

                    currentLength = 0;

                    break;

                }

            }

        }

        if (lineReady.Length != 0)
        {

            string finalLine = lineReady.ToString();

            linesReady.Add(finalLine.Substring(0, lineReady.Length - 1));

        }



        //Padd Lines


        StringBuilder currentStr = new StringBuilder();

        foreach (string lineForPadding in linesReady)
        {

            bool isFinalPrinted = false;

            currentStr.Clear();
            currentStr.Append(lineForPadding);

            int startIndexer = 0;

            while (currentStr.Length < numberOfSymbols && !isFinalPrinted)
            {

                for (int i = startIndexer; i < currentStr.Length && currentStr.Length < numberOfSymbols; i++)
                {

                    int indexOfGap = currentStr.ToString().IndexOf(' ', startIndexer);

                    if (indexOfGap != -1)
                    {

                        while (currentStr[indexOfGap] == ' ')
                        {

                            indexOfGap++;

                        }

                        currentStr.Insert(indexOfGap, " ");

                    }

                    if (indexOfGap + 1 == 0)
                    {

                        i = currentStr.Length + 1;

                    }

                    if (currentStr.ToString() == linesReady[linesReady.Count - 1] && indexOfGap == -1)
                    {

                        // Console.WriteLine(currentStr);

                        isFinalPrinted = true;

                        break;

                    }

                    else
                    {

                        startIndexer = indexOfGap + 1;

                    }

                }



            }

            Console.WriteLine(currentStr);

        }

    }

}