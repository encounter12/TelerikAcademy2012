using System;
using System.Collections.Generic;
class KaspichanNumbers
{
    static void Main()
    {
        ulong input = ulong.Parse(Console.ReadLine());
        ulong resultTemp = input;
        ulong baseKasp = 256;
        ulong baseLittle = 26;
        List<char> output = new List<char>();

        if (resultTemp != 0)
        {
            while (resultTemp > 0)
            {
                if (resultTemp % baseKasp < baseLittle)
                {
                    output.Add(ConvertToChar(resultTemp % baseKasp));
                }
                else
                {
                    ulong resultDouble = resultTemp % baseKasp;
                    output.Add(ConvertToChar(resultDouble % baseLittle));
                    output.Add(ConvertToLittleChar(resultDouble / baseLittle));
                }
                resultTemp /= baseKasp;
            }
        }
        else 
        {
            output.Add('A');
        }

        for (int i = output.Count - 1; i >= 0; i--)        
        {
            Console.Write(output[i]);
        }
        Console.WriteLine();
    }

    private static char ConvertToLittleChar(ulong p)
    {
        char character = '*';
        switch (p)
        {
            case 1: character = 'a'; break;
            case 2: character = 'b'; break;
            case 3: character = 'c'; break;
            case 4: character = 'd'; break;
            case 5: character = 'e'; break;
            case 6: character = 'f'; break;
            case 7: character = 'g'; break;
            case 8: character = 'h'; break;
            case 9: character = 'i'; break;
            default: break;
        }
        return character;
    }

    private static char ConvertToChar(ulong p)
    {
        char character = '*';
        switch (p)
        {
            case 0: character = 'A'; break;
            case 1: character = 'B'; break;
            case 2: character = 'C'; break;
            case 3: character = 'D'; break;
            case 4: character = 'E'; break;
            case 5: character = 'F'; break;
            case 6: character = 'G'; break;
            case 7: character = 'H'; break;
            case 8: character = 'I'; break;
            case 9: character = 'J'; break;
            case 10: character = 'K'; break;
            case 11: character = 'L'; break;
            case 12: character = 'M'; break;
            case 13: character = 'N'; break;
            case 14: character = 'O'; break;
            case 15: character = 'P'; break;
            case 16: character = 'Q'; break;
            case 17: character = 'R'; break;
            case 18: character = 'S'; break;
            case 19: character = 'T'; break;
            case 20: character = 'U'; break;
            case 21: character = 'V'; break;
            case 22: character = 'W'; break;
            case 23: character = 'X'; break;
            case 24: character = 'Y'; break;
            case 25: character = 'Z'; break;
            default: break;
        }
        return character;
    }
}