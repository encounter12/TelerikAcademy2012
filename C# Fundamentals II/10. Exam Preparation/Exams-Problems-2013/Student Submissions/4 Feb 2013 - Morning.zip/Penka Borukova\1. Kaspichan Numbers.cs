using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;

class KaspichanNumbers
{

    //static StringBuilder sb = new StringBuilder();

    static List<string> answer = new List<string>();

    static char ReturnInChar(int n)
    {
        return (char)(n + 'A');
    }


    static void ResultIfLessThan256(int currentReminder)
    {
        //Console.WriteLine("entering with result {0}", currentReminder);
        if (currentReminder < 26)
        {
            //sb.Append(ReturnInChar((int)currentReminder).ToString());
            answer.Add(ReturnInChar((int)currentReminder).ToString());
            currentReminder = currentReminder / 26;
        }
        else
        {
            BigInteger r = currentReminder % 26;
            currentReminder = currentReminder / 26;
            //sb.Append(ReturnInChar((int)currentReminder - 1).ToString().ToLower());
            //sb.Append(ReturnInChar((int)r).ToString());
            answer.Add(ReturnInChar((int)currentReminder - 1).ToString().ToLower() + ReturnInChar((int)r).ToString());
            //answer.Add(ReturnInChar((int)r).ToString());
        }
        currentReminder = currentReminder / 26;
    }


    static void ReturnNormalNumber(BigInteger number)
    {
        if (number < 256)
        {
            ResultIfLessThan256((int)number);
            return;
        }
        int s = 1;
        BigInteger b = number;
        while (b >= 256)
        {
            b = b / 256;
            s = s * 256;
        }

        //ResultIfLessThan256((int)(b));
        ResultIfLessThan256((int)(number % 256));

        //sb.Append(ReturnInChar((int)b));
        //if (number / 256 > 256)
        //{
        //    ReturnNormalNumber(number / 256);
        //}
        //else
        //{
        //    ReturnNormalNumber(number % 256);
        //}
        ReturnNormalNumber(number / 256);
    }
    static void Main(string[] args)
    {
        BigInteger n = BigInteger.Parse(Console.ReadLine());

        // ResultIfLessThan256((int) n);
        ReturnNormalNumber(n);
        //Console.WriteLine(sb.ToString());

        answer.Reverse();

        for (int i = 0; i < answer.Count; i++)
        {
            Console.Write(answer[i]);
        }
        Console.WriteLine();

    }
}
