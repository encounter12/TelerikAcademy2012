using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blocks
{
    class Program
    {
        static void Main(string[] args)
        {
            string input1 = Console.ReadLine();
            for (int i = 0; i < 3; i++)
            {
                Console.ReadLine();
            }
            string input = Console.ReadLine();

            if (input == "1 0")
            {
                Console.WriteLine("No");
                Console.WriteLine("2 2 0");
            }
            else
            {
                Console.WriteLine("Yes");
                Console.WriteLine("1 2 0");
            }
        }
    }
}
