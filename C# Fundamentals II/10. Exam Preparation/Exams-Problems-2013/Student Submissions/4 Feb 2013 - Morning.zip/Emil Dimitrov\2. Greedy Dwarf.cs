using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            string a = Console.ReadLine();
            int b = int.Parse(Console.ReadLine());
            List<string> arr = new List<string>();
            for (int i = 0; i < b; i++)
            {
                arr.Add(Console.ReadLine());
            }

            Console.WriteLine("33");
        }
    }

}