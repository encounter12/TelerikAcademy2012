using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.Coins
{
    class Program
    {

        static int[] Split(string text)
        {
            char[] separator = new char[] { ',',' ' };
            string[] numbers = text.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            int[] arrOfnum = new int [100];
            for (int i = 0; i < numbers.Length; i++)
            {
                arrOfnum[i] = int.Parse(numbers[i]);
            }
            return arrOfnum;
        }
        static int CountCoins(int[] valley,int[] pattern)
        {
            int vaLLeyIndex=0;
            int count = valley[0];
            for (int i = 0; i < pattern.Length; i++)
            {
                if (pattern[i]>0)
                {
                    vaLLeyIndex=vaLLeyIndex+pattern[i];
                }
                else
                {
                    vaLLeyIndex=vaLLeyIndex-pattern[i];
                }
                while (vaLLeyIndex < valley.Length && vaLLeyIndex>=0)
                {
                    count += valley[vaLLeyIndex];
                }  
            }

            return count;
        }


        static void Main(string[] args)
        {
            string v = Console.ReadLine(); 
            int M = int.Parse(Console.ReadLine());
            string []p = new string [M];
            for (int i = 0; i < p.Length; i++)
            {
                p[i] = Console.ReadLine();
            }
            
            int[] valley = Split(v);
            int [] CoinsFrompatterns = new int [M];
            
            while (M != 0)
            {
                
                M--;
                for (int i = 0; i <CoinsFrompatterns.Length; i++)
                {
                    CoinsFrompatterns[i] = CountCoins(valley,Split(p[i]));
                }
               
            }
           
            Console.WriteLine(CoinsFrompatterns.Max().ToString());
        }
    }
}
