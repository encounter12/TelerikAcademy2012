using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.KaspichanNumbers
{
    class KaspichanNumbers
    {
        static void Main()
        {
            long number = long.Parse(Console.ReadLine());
            string cas = string.Empty;
            long modulo;

            if (number < 51)
            {
                while (number > 0)
                {
                    modulo = number % 26;
                    cas = Convert.ToChar(65 + modulo).ToString() + cas;
                    number = (int)((number - modulo) / 26);
                }
            }
            else
            {
                while (number > 0)
                {
                    modulo = number % 256;
                    cas = Convert.ToChar(65 + modulo).ToString() + cas;
                    number = (int)((number - modulo) / 256);
                }
            }
            Console.WriteLine(cas);
            
            
        }
    }
}
