using System;
using System.Numerics;


class Program
{
    static void Main()
    {
        BigInteger input = int.Parse(Console.ReadLine());
        string str = input.ToString();
        char[] matrix = str.ToCharArray();
        foreach (char letter in matrix)
        {
            // Get the integral value of the character.
            int value = Convert.ToInt32(letter);
            // Convert the decimal value to a hexadecimal value in string form.
            string hexOutput = String.Format("{0:X}", value);
            //Console.WriteLine("Hexadecimal value of {0} is {1}", letter, hexOutput);

            int[] letterIndexes = new int[53];
            for (int i = 1; i < letterIndexes.Length / 2 + 1; i++)
            {
                letterIndexes[i] = ('a' - 1) + i;
            }
            for (int i = letterIndexes.Length / 2 + 1, k = 0; i < letterIndexes.Length; i++, k++)
            {
                letterIndexes[i] = 'A' + k;
            }

            string testWord = hexOutput;
            for (int i = 0; i < testWord.Length; i++)
            {
                for (int j = 0; j < letterIndexes.Length; j++)
                {
                    if (testWord[i] == letterIndexes[j])
                    {
                        Console.WriteLine("Leter {0} has index: {1}", testWord[i], j);
                        break;
                    }
                }
            }
        }
    }
}
