using System;
using System.Collections.Generic;
 
class KaspichanNumerals
{
    static List<string> kasp = new List<string>();
 
    static List<string> Before255(ulong input)
    {
            switch (input)
            {
                case 0:
                    kasp.Add("A");
                    break;
                case 1:
                    kasp.Add("B");
                    break;
                case 2:
                    kasp.Add("C");
                    break;
                case 3:
                    kasp.Add("D");
                    break;
                case 4:
                    kasp.Add("E");
                    break;
                case 5:
                    kasp.Add("F");
                    break;
                case 6:
                    kasp.Add("G");
                    break;
                case 7:
                    kasp.Add("H");
                    break;
                case 8:
                    kasp.Add("I");
                    break;
                case 9:
                    kasp.Add("J");
                    break;
                case 10:
                    kasp.Add("K");
                    break;
                case 11:
                    kasp.Add("L");
                    break;
                case 12:
                    kasp.Add("M");
                    break;
                case 13:
                    kasp.Add("N");
                    break;
                case 14:
                    kasp.Add("O");
                    break;
                case 15:
                    kasp.Add("P");
                    break;
                case 16:
                    kasp.Add("Q");
                    break;
                case 17:
                    kasp.Add("R");
                    break;
                case 18:
                    kasp.Add("S");
                    break;
                case 19:
                    kasp.Add("T");
                    break;
                case 20:
                    kasp.Add("U");
                    break;
                case 21:
                    kasp.Add("V");
                    break;
                case 22:
                    kasp.Add("W");
                    break;
                case 23:
                    kasp.Add("X");
                    break;
                case 24:
                    kasp.Add("Y");
                    break;
                case 25:
                    kasp.Add("Z");
 
 
                    break;
                case 26:
                    kasp.Add("aA");
                    break;
                case 27:
                    kasp.Add("aB");
                    break;
                case 28:
                    kasp.Add("aC");
                    break;
                case 29:
                    kasp.Add("aD");
                    break;
                case 30:
                    kasp.Add("aE");
                    break;
                case 31:
                    kasp.Add("aF");
                    break;
                case 32:
                    kasp.Add("aG");
                    break;
                case 33:
                    kasp.Add("aH");
                    break;
                case 34:
                    kasp.Add("aI");
                    break;
                case 35:
                    kasp.Add("aJ");
                    break;
                case 36:
                    kasp.Add("aK");
                    break;
                case 37:
                    kasp.Add("aL");
                    break;
                case 38:
                    kasp.Add("aM");
                    break;
                case 39:
                    kasp.Add("aN");
                    break;
                case 40:
                    kasp.Add("aO");
                    break;
                case 41:
                    kasp.Add("aP");
                    break;
                case 42:
                    kasp.Add("aQ");
                    break;
                case 43:
                    kasp.Add("aR");
                    break;
                case 44:
                    kasp.Add("aS");
                    break;
                case 45:
                    kasp.Add("aT");
                    break;
                case 46:
                    kasp.Add("aU");
                    break;
                case 47:
                    kasp.Add("aV");
                    break;
                case 48:
                    kasp.Add("aW");
                    break;
                case 49:
                    kasp.Add("aX");
                    break;
                case 50:
                    kasp.Add("aY");
                    break;
                case 51:
                    kasp.Add("aZ");
                    break;
 
                case 52:
                    kasp.Add("bA");
                    break;
                case 53:
                    kasp.Add("bB");
                    break;
                case 54:
                    kasp.Add("bC");
                    break;
                case 55:
                    kasp.Add("bD");
                    break;
                case 56:
                    kasp.Add("bE");
                    break;
                case 57:
                    kasp.Add("bF");
                    break;
                case 58:
                    kasp.Add("bG");
                    break;
                case 59:
                    kasp.Add("bH");
                    break;
                case 60:
                    kasp.Add("bI");
                    break;
                case 61:
                    kasp.Add("bJ");
                    break;
                case 62:
                    kasp.Add("bK");
                    break;
                case 63:
                    kasp.Add("bL");
                    break;
                case 64:
                    kasp.Add("bM");
                    break;
                case 65:
                    kasp.Add("bN");
                    break;
                case 66:
                    kasp.Add("bO");
                    break;
                case 67:
                    kasp.Add("bP");
                    break;
                case 68:
                    kasp.Add("bQ");
                    break;
                case 69:
                    kasp.Add("bR");
                    break;
                case 70:
                    kasp.Add("bS");
                    break;
                case 71:
                    kasp.Add("bT");
                    break;
                case 72:
                    kasp.Add("bU");
                    break;
                case 73:
                    kasp.Add("bV");
                    break;
                case 74:
                    kasp.Add("bW");
                    break;
                case 75:
                    kasp.Add("bX");
                    break;
                case 76:
                    kasp.Add("bY");
                    break;
                case 77:
                    kasp.Add("bZ");
                    break;
 
                case 78:
                    kasp.Add("cA");
                    break;
                case 79:
                    kasp.Add("cB");
                    break;
                case 80:
                    kasp.Add("cC");
                    break;
                case 81:
                    kasp.Add("cD");
                    break;
                case 82:
                    kasp.Add("cE");
                    break;
                case 83:
                    kasp.Add("cF");
                    break;
                case 84:
                    kasp.Add("cG");
                    break;
                case 85:
                    kasp.Add("cH");
                    break;
                case 86:
                    kasp.Add("cI");
                    break;
                case 87:
                    kasp.Add("cJ");
                    break;
                case 88:
                    kasp.Add("cK");
                    break;
                case 89:
                    kasp.Add("cL");
                    break;
                case 90:
                    kasp.Add("cM");
                    break;
                case 91:
                    kasp.Add("cN");
                    break;
                case 92:
                    kasp.Add("cO");
                    break;
                case 93:
                    kasp.Add("cP");
                    break;
                case 94:
                    kasp.Add("cQ");
                    break;
                case 95:
                    kasp.Add("cR");
                    break;
                case 96:
                    kasp.Add("cS");
                    break;
                case 97:
                    kasp.Add("cT");
                    break;
                case 98:
                    kasp.Add("cU");
                    break;
                case 99:
                    kasp.Add("cV");
                    break;
                case 100:
                    kasp.Add("cW");
                    break;
                case 101:
                    kasp.Add("cX");
                    break;
                case 102:
                    kasp.Add("cY");
                    break;
                case 103:
                    kasp.Add("cZ");
                    break;
 
                case 104:
                    kasp.Add("dA");
                    break;
                case 105:
                    kasp.Add("dB");
                    break;
                case 106:
                    kasp.Add("dC");
                    break;
                case 107:
                    kasp.Add("dD");
                    break;
                case 108:
                    kasp.Add("dE");
                    break;
                case 109:
                    kasp.Add("dF");
                    break;
                case 110:
                    kasp.Add("dG");
                    break;
                case 111:
                    kasp.Add("dH");
                    break;
                case 112:
                    kasp.Add("dI");
                    break;
                case 113:
                    kasp.Add("dJ");
                    break;
                case 114:
                    kasp.Add("dK");
                    break;
                case 115:
                    kasp.Add("dL");
                    break;
                case 116:
                    kasp.Add("dM");
                    break;
                case 117:
                    kasp.Add("dN");
                    break;
                case 118:
                    kasp.Add("dO");
                    break;
                case 119:
                    kasp.Add("dP");
                    break;
                case 120:
                    kasp.Add("dQ");
                    break;
                case 121:
                    kasp.Add("dR");
                    break;
                case 122:
                    kasp.Add("dS");
                    break;
                case 123:
                    kasp.Add("dT");
                    break;
                case 124:
                    kasp.Add("dU");
                    break;
                case 125:
                    kasp.Add("dV");
                    break;
                case 126:
                    kasp.Add("dW");
                    break;
                case 127:
                    kasp.Add("dX");
                    break;
                case 128:
                    kasp.Add("dY");
                    break;
                case 129:
                    kasp.Add("dZ");
                    break;
 
                case 130:
                    kasp.Add("eA");
                    break;
                case 131:
                    kasp.Add("eB");
                    break;
                case 132:
                    kasp.Add("eC");
                    break;
                case 133:
                    kasp.Add("eD");
                    break;
                case 134:
                    kasp.Add("eE");
                    break;
                case 135:
                    kasp.Add("eF");
                    break;
                case 136:
                    kasp.Add("eG");
                    break;
                case 137:
                    kasp.Add("eH");
                    break;
                case 138:
                    kasp.Add("eI");
                    break;
                case 139:
                    kasp.Add("eJ");
                    break;
                case 140:
                    kasp.Add("eK");
                    break;
                case 141:
                    kasp.Add("eL");
                    break;
                case 142:
                    kasp.Add("eM");
                    break;
                case 143:
                    kasp.Add("eN");
                    break;
                case 144:
                    kasp.Add("eO");
                    break;
                case 145:
                    kasp.Add("eP");
                    break;
                case 146:
                    kasp.Add("eQ");
                    break;
                case 147:
                    kasp.Add("eR");
                    break;
                case 148:
                    kasp.Add("eS");
                    break;
                case 149:
                    kasp.Add("eT");
                    break;
                case 150:
                    kasp.Add("eU");
                    break;
                case 151:
                    kasp.Add("eV");
                    break;
                case 152:
                    kasp.Add("eW");
                    break;
                case 153:
                    kasp.Add("eX");
                    break;
                case 154:
                    kasp.Add("eY");
                    break;
                case 155:
                    kasp.Add("eZ");
                    break;
 
                case 156:
                    kasp.Add("fA");
                    break;
                case 157:
                    kasp.Add("fB");
                    break;
                case 158:
                    kasp.Add("fC");
                    break;
                case 159:
                    kasp.Add("fD");
                    break;
                case 160:
                    kasp.Add("fE");
                    break;
                case 161:
                    kasp.Add("fF");
                    break;
                case 162:
                    kasp.Add("fG");
                    break;
                case 163:
                    kasp.Add("fH");
                    break;
                case 164:
                    kasp.Add("fI");
                    break;
                case 165:
                    kasp.Add("fJ");
                    break;
                case 166:
                    kasp.Add("fK");
                    break;
                case 167:
                    kasp.Add("fL");
                    break;
                case 168:
                    kasp.Add("fM");
                    break;
                case 169:
                    kasp.Add("fN");
                    break;
                case 170:
                    kasp.Add("fO");
                    break;
                case 171:
                    kasp.Add("fP");
                    break;
                case 172:
                    kasp.Add("fQ");
                    break;
                case 173:
                    kasp.Add("fR");
                    break;
                case 174:
                    kasp.Add("fS");
                    break;
                case 175:
                    kasp.Add("fT");
                    break;
                case 176:
                    kasp.Add("fU");
                    break;
                case 177:
                    kasp.Add("fV");
                    break;
                case 178:
                    kasp.Add("fW");
                    break;
                case 179:
                    kasp.Add("fX");
                    break;
                case 180:
                    kasp.Add("fY");
                    break;
                case 181:
                    kasp.Add("fZ");
                    break;
 
                case 182:
                    kasp.Add("gA");
                    break;
                case 183:
                    kasp.Add("gB");
                    break;
                case 184:
                    kasp.Add("gC");
                    break;
                case 185:
                    kasp.Add("gD");
                    break;
                case 186:
                    kasp.Add("gE");
                    break;
                case 187:
                    kasp.Add("gF");
                    break;
                case 188:
                    kasp.Add("gG");
                    break;
                case 189:
                    kasp.Add("gH");
                    break;
                case 190:
                    kasp.Add("gI");
                    break;
                case 191:
                    kasp.Add("gJ");
                    break;
                case 192:
                    kasp.Add("gK");
                    break;
                case 193:
                    kasp.Add("gL");
                    break;
                case 194:
                    kasp.Add("gM");
                    break;
                case 195:
                    kasp.Add("gN");
                    break;
                case 196:
                    kasp.Add("gO");
                    break;
                case 197:
                    kasp.Add("gP");
                    break;
                case 198:
                    kasp.Add("gQ");
                    break;
                case 199:
                    kasp.Add("gR");
                    break;
                case 200:
                    kasp.Add("gS");
                    break;
                case 201:
                    kasp.Add("gT");
                    break;
                case 202:
                    kasp.Add("gU");
                    break;
                case 203:
                    kasp.Add("gV");
                    break;
                case 204:
                    kasp.Add("gW");
                    break;
                case 205:
                    kasp.Add("gX");
                    break;
                case 206:
                    kasp.Add("gY");
                    break;
                case 207:
                    kasp.Add("gZ");
                    break;
 
                case 208:
                    kasp.Add("hA");
                    break;
                case 209:
                    kasp.Add("hB");
                    break;
                case 210:
                    kasp.Add("hC");
                    break;
                case 211:
                    kasp.Add("hD");
                    break;
                case 212:
                    kasp.Add("hE");
                    break;
                case 213:
                    kasp.Add("hF");
                    break;
                case 214:
                    kasp.Add("hG");
                    break;
                case 215:
                    kasp.Add("hH");
                    break;
                case 216:
                    kasp.Add("hI");
                    break;
                case 217:
                    kasp.Add("hJ");
                    break;
                case 218:
                    kasp.Add("hK");
                    break;
                case 219:
                    kasp.Add("hL");
                    break;
                case 220:
                    kasp.Add("hM");
                    break;
                case 221:
                    kasp.Add("hN");
                    break;
                case 222:
                    kasp.Add("hO");
                    break;
                case 223:
                    kasp.Add("hP");
                    break;
                case 224:
                    kasp.Add("hQ");
                    break;
                case 225:
                    kasp.Add("hR");
                    break;
                case 226:
                    kasp.Add("hS");
                    break;
                case 227:
                    kasp.Add("hT");
                    break;
                case 228:
                    kasp.Add("hU");
                    break;
                case 229:
                    kasp.Add("hV");
                    break;
                case 230:
                    kasp.Add("hW");
                    break;
                case 231:
                    kasp.Add("hX");
                    break;
                case 232:
                    kasp.Add("hY");
                    break;
                case 233:
                    kasp.Add("hZ");
                    break;
 
                case 234:
                    kasp.Add("iA");
                    break;
                case 235:
                    kasp.Add("iB");
                    break;
                case 236:
                    kasp.Add("iC");
                    break;
                case 237:
                    kasp.Add("iD");
                    break;
                case 238:
                    kasp.Add("iE");
                    break;
                case 239:
                    kasp.Add("iF");
                    break;
                case 240:
                    kasp.Add("iG");
                    break;
                case 241:
                    kasp.Add("iH");
                    break;
                case 242:
                    kasp.Add("iI");
                    break;
                case 243:
                    kasp.Add("iJ");
                    break;
                case 244:
                    kasp.Add("iK");
                    break;
                case 245:
                    kasp.Add("iL");
                    break;
                case 246:
                    kasp.Add("iM");
                    break;
                case 247:
                    kasp.Add("iN");
                    break;
                case 248:
                    kasp.Add("iO");
                    break;
                case 249:
                    kasp.Add("iP");
                    break;
                case 250:
                    kasp.Add("iQ");
                    break;
                case 251:
                    kasp.Add("iR");
                    break;
                case 252:
                    kasp.Add("iS");
                    break;
                case 253:
                    kasp.Add("iT");
                    break;
                case 254:
                    kasp.Add("iU");
                    break;
                case 255:
                    kasp.Add("iV");
                    break;
            }
            kasp.Reverse();
            return kasp;
    }
 
    static List<string> After255(ulong input)
    {
        while(input>0)
        {
            switch (input % 256)
            {
                case 0:
                    kasp.Add("A");
                    break;
                case 1:
                    kasp.Add("B");
                    break;
                case 2:
                    kasp.Add("C");
                    break;
                case 3:
                    kasp.Add("D");
                    break;
                case 4:
                    kasp.Add("E");
                    break;
                case 5:
                    kasp.Add("F");
                    break;
                case 6:
                    kasp.Add("G");
                    break;
                case 7:
                    kasp.Add("H");
                    break;
                case 8:
                    kasp.Add("I");
                    break;
                case 9:
                    kasp.Add("J");
                    break;
                case 10:
                    kasp.Add("K");
                    break;
                case 11:
                    kasp.Add("L");
                    break;
                case 12:
                    kasp.Add("M");
                    break;
                case 13:
                    kasp.Add("N");
                    break;
                case 14:
                    kasp.Add("O");
                    break;
                case 15:
                    kasp.Add("P");
                    break;
                case 16:
                    kasp.Add("Q");
                    break;
                case 17:
                    kasp.Add("R");
                    break;
                case 18:
                    kasp.Add("S");
                    break;
                case 19:
                    kasp.Add("T");
                    break;
                case 20:
                    kasp.Add("U");
                    break;
                case 21:
                    kasp.Add("V");
                    break;
                case 22:
                    kasp.Add("W");
                    break;
                case 23:
                    kasp.Add("X");
                    break;
                case 24:
                    kasp.Add("Y");
                    break;
                case 25:
                    kasp.Add("Z");
                    break;
                default:
                    string combindedString = string.Empty;
                    foreach (var item in Before255(input%256))
                    {
                        combindedString += item;
                    }
                    break;
            }
            input /= 256;
        }
        kasp.Reverse();
        return kasp;
    }
                               
    static void Main()
    {
        ulong input = ulong.Parse(Console.ReadLine());
 
 
        if (input<=255)
        {
            foreach (var item in Before255(input))
            {
                Console.Write(item);
            }
        }
        else
        {
            foreach (var item in After255(input))
            {
                Console.Write(item);
            }
        }
                          
    }
}