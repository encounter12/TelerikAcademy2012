using System;
using System.Text;
using System.Numerics;
 
class Program
{
    static void Main()
    {
        char[] smallLetters = {' ','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
        char[] bigLetters = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
        BigInteger number = BigInteger.Parse(Console.ReadLine());
        StringBuilder sb = new StringBuilder();
        do
        {
            int sumNumber = (int)(number % 256);
            sb.Append(bigLetters[sumNumber % 26]);
            if (sumNumber > 25)
            {
                sb.Append(smallLetters[sumNumber / 26]);
            }
            number /= 256;
        }
        while (number > 0);
        string result = sb.ToString();
        StringBuilder revStr = new StringBuilder();
        for (int count = result.Length - 1; count > -1; count--)
        {
            revStr.Append(result[count]);
        }
        Console.WriteLine(revStr.ToString());
    }
}