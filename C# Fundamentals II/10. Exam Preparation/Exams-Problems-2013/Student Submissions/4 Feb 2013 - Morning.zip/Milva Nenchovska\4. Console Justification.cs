using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Enter N :");
            int N = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter W: ");
            int W = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter text:");
            string text = Console.ReadLine();
            StringBuilder str = new StringBuilder();

            for (int i = 0; i < text.Length - 1; i++)
            {                
                if (!(text[i] == text[i + 1]) && !(text[i].Equals(" ")))
                {
                    str.Append(text[i]);
                }                                
            }

            int spaces = 0;
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i].Equals(' '))
                {
                    spaces++;
                }
            }

            //Console.WriteLine(str);
            //Console.WriteLine("{0}", spaces);
            int p = 0;       
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < W; j++)
                {
                    int Wcount = 0;

                    while ((Wcount <= W) && (!(str[p].Equals(' '))))
                    {
                        Wcount++;
                        Console.Write(str[p]);
                        p++;
                    }
                    Wcount++;                  
                                      
                    if (Wcount > W)
                    {
                        continue;
                    }
                }
                Console.WriteLine();
            }
            
        }
    }
}
