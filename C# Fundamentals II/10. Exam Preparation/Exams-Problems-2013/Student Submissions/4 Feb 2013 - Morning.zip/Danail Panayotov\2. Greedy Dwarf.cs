using System;
using System.Collections.Generic;
class GreedyDwarf
{
    static void Main()
    {
        // Read the input data
        string inputValley = Console.ReadLine();
        string[] numbers = inputValley.Split(
                    new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);        
        int[] valley = new int[numbers.Length];
        for (int i = 0; i < numbers.Length; i++)
        {
            short numOfCoins = short.Parse(numbers[i]);
            valley[i] = numOfCoins;
        }

        List<int[]> patherns = new List<int[]>();
        int numOfPaths = int.Parse(Console.ReadLine());
        for (int i = 0; i < numOfPaths; i++)
        {
            string inputPathern = Console.ReadLine();
            string[] steps = inputPathern.Split(
                    new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            int[] pathern = new int[steps.Length];
            for (int p = 0; p < steps.Length; p++)
            {
                short step = short.Parse(steps[p]);
                pathern[p] = step;                
            }
            patherns.Add(pathern);
        }

        bool[,] isVisit = new bool[numOfPaths + 1, numbers.Length + 100];
        int bestSumOfCoins = int.MinValue;
        int row = 0;

        foreach (var pathern in patherns)
        {
            int col = 0;
            int sumOfCoins = 0;
            for (int step = 0; col >= 0 && !isVisit[row, col]; step++)
            {
                
                if (col < 0 || col >= numbers.Length)
                {
                    break;
                }

                isVisit[row, col] = true;
                sumOfCoins += valley[col];
                col += pathern[step]; 
               
                if (step == pathern.Length - 1)
                {
                    step = -1;
                }

            }

            if (bestSumOfCoins < sumOfCoins)
            {
                bestSumOfCoins = sumOfCoins;
            }

            row++;
        }

        Console.WriteLine(bestSumOfCoins);
    }
}
