using System;

class GreedyDwarf
{
    static void Main()
    {
        string line = Console.ReadLine();
        char[] separators = new char[] {','};
        string[] lines = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        int[] valley = new int[lines.Length];

        for (int index = 0; index < lines.Length; index++)
        {
            valley[index] = int.Parse(lines[index]);
        }

        int M = int.Parse(Console.ReadLine());
        int maxPattern = 100;
        int[,] pattern = new int[M, maxPattern];

        for (int index = 0; index < M; index++)
        {
            line = Console.ReadLine();
            lines = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            for (int jindex = 0; jindex < lines.Length; jindex++)
            {
                pattern[index, jindex] = int.Parse(lines[jindex]);
                if (pattern[index, jindex] == 0)
                {
                    break;
                }
            }
        }

        int maxSum = 0, sum = 0, maxPath = 0;
        for (int index = 0; index < M; index++)
        {
            for (int jindex = 0; jindex < maxPattern; jindex++)
            {
                if (pattern[index, jindex] == 0)
                {
                    break;
                }
                sum += pattern[index, jindex];
            }
            if (sum > maxSum)
            {
                maxSum = sum;
                maxPath = index;
            }
            sum = 0;
        }

        int cnt = 0, indexer = 0;
        while (true)
        {
            if (pattern[maxPath, cnt] == 0)
            {
                cnt = 0;
                continue;
            }
            try
            {
                sum += valley[indexer];
                if (indexer + 1 == valley.Length)
                {
                    Console.WriteLine(sum);
                    break;
                }
                indexer += pattern[maxPath, cnt];
                cnt++;
            }
            catch (System.IndexOutOfRangeException ex)
            {
                Console.WriteLine(sum);
                break;
            }
        }
    }
}
