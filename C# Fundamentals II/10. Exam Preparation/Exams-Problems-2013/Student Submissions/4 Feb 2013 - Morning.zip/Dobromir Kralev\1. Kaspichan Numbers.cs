using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KaspichanNumbers
{
    class Program
    {
        static string ParseNumber(ulong number)
        {
            StringBuilder parseResult = new StringBuilder();
            if (number < 26)
            {
                parseResult.Append((char)('A'+number));
            }
            else if (number < 256)
            {
                parseResult.Append((char)('a' + number / 26 - 1) + "" + (char)('A' + number % 26));
            }
            return parseResult.ToString();
        }
        
        static StringBuilder result = new StringBuilder();

        static void ParseRecursive(ulong number)
        {
            if (number > 256)
            {
                ulong devisor = number / 256;
                ulong remainder = number % 256;
                if (devisor > 256)
                {
                    ParseRecursive(devisor);
                    if (remainder > 256)
                    {
                        ParseRecursive(remainder);
                    }
                    else
                    {
                        result.Append(ParseNumber(remainder));
                    }
                }
                else
                {
                    result.Append(ParseNumber(devisor));
                    if (remainder > 256)
                    {
                        ParseRecursive(remainder);
                    }
                    else
                    {
                        result.Append(ParseNumber(remainder));
                    }
                }
            }
            else
            {
                result.Append(ParseNumber(number));
            }
        }

        static void Main(string[] args)
        {
            ulong number = ulong.Parse(Console.ReadLine());
            ParseRecursive(number);
            Console.WriteLine(result.ToString());
        }
    }
}
