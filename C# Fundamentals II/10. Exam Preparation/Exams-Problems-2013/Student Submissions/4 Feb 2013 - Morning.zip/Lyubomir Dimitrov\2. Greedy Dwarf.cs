using System;
using System.Collections.Generic;

class Program
{
    static int Greedy(List<int> list, List<int> subList)
    {
        int result = 0;
        int count = 0;
        bool flag = true;
        while(flag)
        {
            for (int index = 0; index < subList.Count; index++)
            {  
                if ((count < 0 && count > subList.Count-1))
                {
                    result = result + list[count];
                    flag = false;
                    break;
                }
                else  
                {
                    result = result + list[count];
                    count = count + subList[index];
                }
                if (count == 0 || count == list.Count-1) 
                {
                    result = result + list[count];
                    flag = false;
                    break;
                }
            }
                
        }
        return result;
    }
    static List<int> ReadDate(String str)
    {
        List<int> list = new List<int>();
        char digit;
        int number = 0;
        int step = 1;
        int count = str.Length-1;
        while(count >= 0)
        {
            digit = str[count];
            if (digit == ' ')
            {
                count--;
                list.Add(number);
                number = 0;
                step = 1;
            }
            else
            {
                if (digit == '-') number = -1 * number;
                else
                {
                    number = number + (digit - '0') * step;
                    step = step * 10;
                }
            }
            count--;
        }
        list.Add(number);
        list.Reverse();
        return list;
        
    }
    static void Main()
    {

        int result = 0;
        int tempResult = 0;
        string str = Console.ReadLine();
        List<int> list = ReadDate(str);
        str = Console.ReadLine();
        int number = int.Parse(str);
        for (int i = 0; i < number; i++)
        {
            str = Console.ReadLine();
            List<int> subList = ReadDate(str);
            tempResult = Greedy(list, subList);
            if (result < tempResult) result = tempResult;

        }
        Console.WriteLine(result);
    }
}