using System;

class Dwarf
{
    static void Main(string[] args)
    {
        string valleyStr = Console.ReadLine();
        string[] tokens = valleyStr.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
        short[] valley = new short[tokens.Length];
        for (int i = 0; i < tokens.Length; i++)
        {
            valley[i] = short.Parse(tokens[i]);
        }

        short m = short.Parse(Console.ReadLine());
        short[][] patterns = new short[m][];
        string pathStr;
        for (int i = 0; i < m; i++)
        {
            pathStr = Console.ReadLine();
            tokens = pathStr.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            patterns[i] = new short[tokens.Length];
            for (int p = 0; p < tokens.Length; p++)
            {
                patterns[i][p] = short.Parse(tokens[p]);
            }

        }

        //short[] valley = new short[] { 1, 3, -6, 7, 4, 1, 12 };
        //short[][] patterns = new short[][]
        //{
        //    new short[] { -2 },
        //    new short[] { 2 },
        //    new short[] { 3 },
        //};

        int bestResult = int.MinValue;
        for (int i = 0; i < patterns.Length; i++)
        {
            int result = RunPattern(valley, patterns[i]);
            if (result > bestResult)
            {
                bestResult = result;
            }
        }
        Console.WriteLine(bestResult);
    }

    static int RunPattern(short[] valley, short[] pattern)
    {
        int result = valley[0];
        bool[] visited = new bool[valley.Length];
        visited[0] = true;
        int currentIndex = 0, patternIndex = 0;
        while (true)
        {
            currentIndex += pattern[patternIndex];
            if (currentIndex < 0 || currentIndex >= valley.Length)
            {
                return result;
            }
            if (visited[currentIndex])
            {
                return result;
            }
            result += valley[currentIndex];
            visited[currentIndex] = true;
            patternIndex++;
            if (patternIndex == pattern.Length)
            {
                patternIndex = 0;
            }
        }
    }

}
