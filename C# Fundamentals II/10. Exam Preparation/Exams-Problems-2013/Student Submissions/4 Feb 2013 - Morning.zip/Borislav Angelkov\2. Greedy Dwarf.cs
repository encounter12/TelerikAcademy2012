using System;
using System.Text;


 class Program
 {
     static void Main()
     {
         StringBuilder v = new StringBuilder();
         v.Append(Console.ReadLine());
         long m = long.Parse(Console.ReadLine());

         char[] separators = { ' ', ',' };
         string vv = v.ToString();
         string[] valley = vv.Split(separators, StringSplitOptions.RemoveEmptyEntries);

         long pos = 0;
         long max = 0;

         long[] intValley = new long[valley.Length];
         for (int i = 0; i < valley.Length; i++)
         {
             intValley[i] = long.Parse(valley[i]);
         }

         for (int i = 0; i < m; i++)
         {
             StringBuilder patt = new StringBuilder();
             patt.Append(Console.ReadLine());
             string stringPatt = patt.ToString();
             string[] pattern = stringPatt.Split(separators, StringSplitOptions.RemoveEmptyEntries);

             long[] intPattern = new long[pattern.Length];

             for (int index = 0; index < pattern.Length; index++)
             {
                 intPattern[index] = long.Parse(pattern[index]);
             }

             long counter = intValley[0];
             for (int k = 0; k < intPattern.Length; k++)
             {
                 pos += intPattern[k];
                 if (pos == 0 || pos > intValley.Length)
                 {
                     break;
                 }
                 else
                 {
                     counter += intValley[pos];
                 }             
              
             }
             if (counter > max)
             {
                 max = counter;
                 counter = intValley[0];
             }
             else
             {
                 counter = intValley[0];
             }
         }
         Console.WriteLine(max);
     }
 }

