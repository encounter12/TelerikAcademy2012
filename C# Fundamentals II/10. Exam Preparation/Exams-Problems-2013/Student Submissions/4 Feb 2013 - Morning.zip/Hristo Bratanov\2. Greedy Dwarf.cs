using System;
using System.Collections.Generic;

class GreedyDwarf
{
    static long maxSum = 0;
    
    static void Main()
    {
        List<int> pattern = new List<int>();
        string valley = Console.ReadLine();
        List<int> vallList = EjectNumbers(valley);
        int M = int.Parse(Console.ReadLine());
        for (int i = 0; i < M; i++)
        {
            string patternWithSepar = Console.ReadLine();
            pattern = EjectNumbers(patternWithSepar);
            if (pattern[0] < 0 || pattern[0] > vallList.Count)
            {
                continue;
            }
            CalculateCoins(vallList, pattern);
        }
        Console.WriteLine(maxSum);
    }

    static void CalculateCoins(List<int> vall, List<int> patt)
    {
        long sum = vall[0];
        int position = 0;
        List<int> recordPositions = new List<int>();
        recordPositions.Add(0);
        bool exit = true;
        bool samePosition = false;

        while (exit == true)
        {
            samePosition = false;
            for (int i = 0; i < patt.Count; i++)
            {
                int nextStep = patt[i];
                if (nextStep < - vall.Count || nextStep > vall.Count)
                {
                    exit = false;
                    break;
                }
                position = position + nextStep;
                if (position >= vall.Count || position < 0)
                {
                    exit = false;
                    break;
                }
                int index = recordPositions.BinarySearch(position);
                if (index > -1)
                {
                    if (i == patt.Count - 1)
                    {
                        exit = false;
                    }
                    break;
                }
                else
	            {
                    recordPositions.Add(position);
                    sum = sum + vall[position];
                }
                
            }
        }
        
        if (sum > maxSum)
        {
            maxSum = sum;
        }
    }

    static List<int> EjectNumbers(string patt)
    {
        
        char[] separators = new char[] { ' ', ','};
        string[] nums = patt.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        List<int> steps = new List<int>();
        for (int i = 0; i < nums.Length; i++)
        {
            steps.Add(int.Parse(nums[i]));
        }

        return steps;
    }
}
