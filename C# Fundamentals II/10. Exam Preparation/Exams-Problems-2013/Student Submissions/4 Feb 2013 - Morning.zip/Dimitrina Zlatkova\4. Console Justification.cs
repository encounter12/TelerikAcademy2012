using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleJustification
{
    class ConsoleJustification
    {
        static void Main(string[] args)
        {
            List<string> words = new List<string>();

            int n = int.Parse(Console.ReadLine());
            int w = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string line = Console.ReadLine();
                string[] lineArr = line.Split(new char[] { ' ', '\t', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var word in lineArr)
                {
                    words.Add(word);
                }
            }

            //int n = 10;
            //int w = 19;
//            string input = @"Beer beer beer Im going for
//	a
//beer
//Beer beer beer Im gonna 
//drink some beer
//I love drinkiiiiiiiiing
//beer
//lovely
//lovely
//beer";
//            string input = @"We happy few	we band
//of brothers for he who sheds
//his blood   
//with
//me shall be my brother";
//            string[] inputArr = input.Split(new char[] { ' ', '\t', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
//            words = new List<string>(inputArr);

            int wordCount = 0;
            while (wordCount < words.Count)
            {
                List<string> currWords = new List<string>();
                while (wordCount<words.Count-1&&String.Concat(currWords).Length+words[wordCount].Length+currWords.Count<=w)
                {
                    currWords.Add(words[wordCount]);
                    wordCount++;                                  
                }
                if (wordCount == words.Count - 1)
                {
                    if (currWords.Count==0)
                    {
                        currWords.Add(words[wordCount]);
                        wordCount++;                        
                    }
                    else
                    {
                        if (String.Concat(currWords).Length+words[wordCount].Length+currWords.Count<=w)
                        {
                            currWords.Add(words[wordCount]);
                            wordCount++;
                        }
                    }
                }                
                if (currWords.Count==1)
                {
                    Console.Write(currWords[0]);
                }
                else
                {
                    int gaps = w - String.Concat(currWords).Length;
                    int added = gaps % (currWords.Count - 1);
                    for (int i = 0; i < currWords.Count - 1; i++)
                    {
                        Console.Write(currWords[i]);
                        int gapsToPut = gaps / (currWords.Count-1);
                        if (added>0)
                        {
                            gapsToPut++;
                            added--;
                        }
                        for (int j = 0; j < gapsToPut; j++)
                        {
                            Console.Write(' ');
                        } 
                    }
                    Console.Write(currWords[currWords.Count-1]);
                }   
                Console.WriteLine();
            }
        }
    }
}
