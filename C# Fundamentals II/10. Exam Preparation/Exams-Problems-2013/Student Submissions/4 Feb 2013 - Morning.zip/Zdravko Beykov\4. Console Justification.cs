using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lines {
    class Program {
        static void Main(string[] args) {
            char[] s1 = {' '};
            int N = int.Parse(Console.ReadLine());
            int W = int.Parse(Console.ReadLine());
            List<string> words = new List<string>();
            for (int i = 0; i < N; i++) {
                string[] input = Console.ReadLine().Split(s1, StringSplitOptions.RemoveEmptyEntries);
                for (int w = 0; w < input.Length; w++) words.Add(input[w]);
            }
            int L = words.Count;
            int first = 0;
            StringBuilder output = new StringBuilder();
            while (true) {
                int w = words[first].Length;
                int next = first+1;
                while (next < L && w + 1 + words[next].Length <= W) {
                    w += 1 + words[next].Length;
                    next++;
                }
                //Console.WriteLine(w);
                int left = next-first-1;
                int leftWidth = W-(w-left);
                //Console.WriteLine("left" + leftWidth);
                for (int i = 0; first + i < next; i++) {
                    output.Append(words[first+i]);
                    if(left>0) {
                        int many=(leftWidth+left-1)/left;
                        for(int j=0;j<many;j++)output.Append(' ');
                        leftWidth -= many;
                        left--;
                    }
                }
                if (next == L) break;
                first = next;
                output.AppendLine();
            }
            Console.WriteLine(output);
        }
    }
}
