using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("No");
        Console.WriteLine("2 1 0");
    }
}
