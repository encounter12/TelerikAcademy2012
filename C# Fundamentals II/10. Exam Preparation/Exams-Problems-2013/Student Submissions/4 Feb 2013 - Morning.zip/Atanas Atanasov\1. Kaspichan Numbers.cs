using System;
using System.Collections.Generic;
using System.Text;

class KaspichanNumbers
{
    static string GiveNumber(ulong number)
    {
        StringBuilder result = new StringBuilder();
        while (number >= 26)
        {
            ulong newNumber = number / 26;
            char letter = (char)(newNumber + 96);
            result.Append(letter);
            number %= 26;
        }

        char newLetter = (char)(number + 65);
        result.Append(newLetter);
        return result.ToString();
    }

    static void Main()
    {
        ulong number = ulong.Parse(Console.ReadLine());
        List<string> result = new List<string>();
        while (number >= 256)
        {
            ulong newNumber = number % 256;
            result.Add(GiveNumber(newNumber));
            number /= 256;
        }

        result.Add(GiveNumber(number));
        for (int index = result.Count - 1; index >= 0; index--)
        {
            Console.Write(result[index]);
        }

        Console.WriteLine();
    }
}
