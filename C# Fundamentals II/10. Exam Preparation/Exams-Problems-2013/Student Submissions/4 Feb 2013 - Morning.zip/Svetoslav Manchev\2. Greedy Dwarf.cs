using System;
using System.Collections.Generic;

class GreedyDwarf
{
    static void Main()
    {
        string input = Console.ReadLine();
        char[] separator = new char[] { ' ', ',' };
        string[] clearStr = input.Split(separator, StringSplitOptions.RemoveEmptyEntries);
        int valleyLength = clearStr.Length;
        int[] valley = new int[valleyLength];
        for (int i = 0; i < valleyLength; i++)
        {
            valley[i] = int.Parse(clearStr[i]);
        }

        // Input numbers

        int lines = int.Parse(Console.ReadLine());
        int maxSum = int.MinValue;
        int currentSum = 0;
        List<int> track = new List<int>();
        for (int i = 0; i < lines; i++)
        {
            input = Console.ReadLine();
            string[] clearPattern = input.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            int PatternLength = clearPattern.Length;
            int[] currentPattern = new int[PatternLength];

            for (int j = 0; j < PatternLength; j++)
            {
                currentPattern[j] = int.Parse(clearPattern[j]);
            }
            int index = 0;
            int midSum = 0;
            int count = 0;
            currentSum = valley[index];
            while (true)
            {
                midSum = 0;
                bool step = false;
                track.Clear();
                track.Add(0);
                for (int j = 0; j < PatternLength; j++)
                {
                    index += currentPattern[j];
                    count = track.Count;
                    for (int s = 0; s < count; s++)
                    {
                        if (index == track[s])
                        {
                            step = true;
                            break;
                        }
                    }
                    
                    if (index > 0 && index < valleyLength - 1)
                    {
                        midSum += valley[index];
                    }
                    else
                    {
                        break;
                    }
                    track.Add(index);
                }
                if (step)
                {
                    currentSum += midSum;
                    break;
                }
                else if (index < valleyLength-1)
                {
                    currentSum += midSum;
                }
                else if (index == valleyLength - 1)
                {
                    currentSum += midSum + valley[valleyLength - 1];
                }
                else
                {
                    if (index >= valleyLength)
                    {
                        break;
                    }
                }
            }
            if (currentSum > maxSum)
            {
                maxSum = currentSum;
            }
        }
        Console.WriteLine(maxSum);
    }
}
