using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam
{
    class Problem2
    {
        static void Main(string[] args)
        {          
            bool tr=true;
            int t, r, posVal=0, Sum=0, SumMax=0, N, tmp;
            char[] separators = new char[] { ' ', ','};
            string str = Console.ReadLine();
            string[] strArr = str.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            N = strArr.Length;
            //N = 7;
            int[] Val=new int[N];
            int[] br = new int[N];
            for (t = 0; t < N; t++)
            {
                br[t] = 0;
            }
            for(t=0; t<N; t++)
            {
                tmp = int.Parse(strArr[t]);
                Val[t]=int.Parse(strArr[t]);
            }
            
            int M = int.Parse(Console.ReadLine());

            for( r=0; r<M; r++)
            {
                for (t = 0; t < N; t++)
                {
                    br[t] = 0;
                }
                br[0] = 1;
                str = Console.ReadLine();
                string[] pArr = str.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                int P = pArr.Length;
                int[] Pat=new int[P];
                for(t=0; t<P; t++)
                {
                    tmp = int.Parse(pArr[t]);
                    Pat[t]=int.Parse(pArr[t]);
                }
                posVal=0;
                Sum=Val[0];
                tr=true;
                t=0;
                do
                {
                    posVal = posVal + Pat[t];
                    if (posVal >= 0 && posVal < N && br[posVal]==0)
                    {
                        Sum = Sum + Val[posVal];
                        br[posVal] = 1;
                        t++;
                        if (t == P) t = 0;
                    }
                    else
                    {
                        tr = false;
                        break;
                    }
                } while (tr);
                if (Sum > SumMax) SumMax = Sum;
            }
            Console.WriteLine(SumMax);
        }
    }
}