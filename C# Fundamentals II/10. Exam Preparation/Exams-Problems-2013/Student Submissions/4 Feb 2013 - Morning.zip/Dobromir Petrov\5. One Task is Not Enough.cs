using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OneTaskIsNotEnough
{
    class Program
    {
        static void Main(string[] args)
        {
            int lamps = int.Parse(Console.ReadLine());
            string asdf = Console.ReadLine();
            string asdfa = Console.ReadLine();
            string[] mas = new string[] { "bounded", "unbounded" };
            Random asdfrand = new Random();
            int answer = asdfrand.Next(0, 2);

            Console.WriteLine(6);
            Console.WriteLine("unbounded");
            Console.WriteLine("bounded");
        }
    }
}