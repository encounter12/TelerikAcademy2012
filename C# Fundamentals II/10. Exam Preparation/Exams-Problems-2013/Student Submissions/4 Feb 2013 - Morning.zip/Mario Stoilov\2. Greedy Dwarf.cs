using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreedyDwarf
{
    class GreedyDwarf
    {
        static int CalculatePattern(int[] valley, int[] pattern)
        {
            int patternIndex = 0;
            int index = 0;
            int coins = 0;
            bool[] visited = new bool[valley.Length];
            while (index>=0 && index<valley.Length)
            {
                if (visited[index])
                {
                    break;
                }
                coins += valley[index];
                visited[index] = true;
                index += pattern[patternIndex];
                patternIndex++;
                if (patternIndex>=pattern.Length)
                {
                    patternIndex = 0;
                }
            }
            return coins;
        }
        static void Main()
        {
            string[] input = Console.ReadLine().Split(new char[]{',',' '}, StringSplitOptions.RemoveEmptyEntries);
            int[] valley = new int[input.Length];
            for (int i = 0; i < valley.Length; i++)
            {
                valley[i] = int.Parse(input[i]);
            }
            int M = int.Parse(Console.ReadLine());
            int[][] pattern = new int[M][];
            for (int i = 0; i < M; i++)
            {
                input = Console.ReadLine().Split(new char[]{',',' '}, StringSplitOptions.RemoveEmptyEntries);
                pattern[i] = new int[input.Length];
                for (int j = 0; j < input.Length; j++)
                {
                    pattern[i][j] = int.Parse(input[j]);
                }
            }
            int max = int.MinValue;
            foreach (var path in pattern)
            {
                int current = CalculatePattern((int[])valley.Clone(), path);
                if (current>max)
                {
                    max = current;
                }
            }
            Console.WriteLine(max);
        }
    }
}
