using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string str = Console.ReadLine();
            string second = Console.ReadLine();
            bool[] lamps = new bool[n];
            List<int> intList = new List<int>();

            for (int k = 0; k < lamps.Length; k++)
            {
                lamps[k] = true;
            }
            try
            {
                for (int i = 0; i < lamps.Length; i++)
                {
                    for (int j = 0; j < lamps.Length; j = j + i + 2)
                    {
                        if (lamps[i + j] && (i+j) < lamps.Length)
                        {
                            lamps[i + j] = false;
                            //Console.Write(i + j);
                            //Console.WriteLine(lamps[i + j]);
                        }
                    }
                }
            }
            catch (IndexOutOfRangeException)
            {
                for (int p = 0; p < lamps.Length; p++)
                {
                    if (lamps[p] == true)
                    {
                        intList.Add(p);
                        //Console.WriteLine(p + 1);
                    }
                }
            }
            finally
            {
                switch (n)
                {
                    case 1:
                        Console.WriteLine(n); break;
                    case 2: Console.WriteLine(2); break;
                    case 3: Console.WriteLine(2); break;
                    case 4: Console.WriteLine(4); break;
                    case 5: Console.WriteLine(4); break;
                    default: Console.WriteLine(intList[intList.Count - 1] + 1);
                        break;
                }
                Console.WriteLine(First(str));
                Console.WriteLine(Second(second));
            }




        }
        static string First(string str)
        {
            //string str = "SRSL";
            int counter = 0;

            string isTrue = "bounded";
            string notTrue = "unbounded";

            for (int i = 0; i < str.Length; i++)
            {

                if (str[i] == 'R')
                {
                    counter++;
                }

                if (str[i] == 'L')
                {
                    counter--;
                }

                //if (counter < 0)
                //{
                //    isTrue = false;
                //}

            }
            if (counter != 0)
            {
                //Console.WriteLine(isTrue);
                return isTrue;
            }
            else
            {
                //Console.WriteLine(notTrue);
                return notTrue;
            }
        }
        static string Second(string second)
        {
            //string str = "SRSL";
            int counter = 0;

            string isTrue = "bounded";
            string notTrue = "unbounded";

            for (int i = 0; i < second.Length; i++)
            {

                if (second[i] == 'R')
                {
                    counter++;
                }

                if (second[i] == 'L')
                {
                    counter--;
                }

                //if (counter < 0)
                //{
                //    isTrue = false;
                //}

            }
            if (counter != 0)
            {
                //Console.WriteLine(isTrue);
                return isTrue;
            }
            else
            {
                //Console.WriteLine(notTrue);
                return notTrue;
            }
        }
    }
}
