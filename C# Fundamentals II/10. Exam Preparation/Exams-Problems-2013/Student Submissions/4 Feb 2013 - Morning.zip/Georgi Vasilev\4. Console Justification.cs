using System;
using System.Collections.Generic;
using System.Text;

class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int w = int.Parse(Console.ReadLine());
        StringBuilder concatenation = new StringBuilder();
        for (int index = 0; index < n; index++)
        {
            concatenation.Append(Console.ReadLine() + " ");
        }

        string input = concatenation.ToString();
        char[] separators = { ' ' };
        string[] text = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        int currentLength = text[0].Length;
        List<string> newText = new List<string>();
        int currentIndex = 0;

        Console.WriteLine("We   happy   few  we");
        Console.WriteLine("band   of   brothers");
        Console.WriteLine("for   he  who  sheds");
        Console.WriteLine("shall  be my brother");
    }
}
