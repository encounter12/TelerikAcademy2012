using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Dwarf
{
    static bool Succes(int[] pattern, int[] valley, int[] passed, int currValPosition)
    {
        bool ok = true;
        for (int i = 0; i < pattern.Length; i++)
        {
            if (passed[currValPosition] == -1)
            {
                return false;
            }

            currValPosition += pattern[i];
            if (currValPosition < valley.Length)
            {
                ok = ok & true;
            }
            else
            {
                ok = ok & false;
            }
        }
        return ok;
    }


    static int resultOfPattern(int[] pattern, int[] valley, int[] passed)
    {
        int step = 0;
        int totalCoins = valley[0];
        int currentPos = 0;
        while (true)
        {
            currentPos = currentPos + pattern[step % 3];
            totalCoins += valley[currentPos];
            passed[currentPos] = -1;
            step++;
        }

        return 1;
    }

    static void Main()
    {
        int[] valley = new int[] { 1, 3, -6, 7, 4, 1, 12 };
        int[] pattern = new int[] { 1, 3, -2 }; // int[,]
        int[] patternResult = new int[pattern.Length];
        int[] passed = new int[valley.Length];

        //Console.WriteLine(Succes(pattern, valley, 4));
        //Console.WriteLine(resultOfPattern(pattern, valley));


    }
}
