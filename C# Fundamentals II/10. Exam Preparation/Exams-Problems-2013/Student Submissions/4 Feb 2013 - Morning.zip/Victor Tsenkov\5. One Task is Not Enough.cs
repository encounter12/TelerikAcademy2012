using System;

class Point
{
    public int X { get; set; }
    public int Y { get; set; }
    public int Direction { get; set; }
}


class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string secondLine = Console.ReadLine();
        string thirdLine = Console.ReadLine();

        int index = FindLastLamp(n);
        Console.WriteLine(index+1);

        if (IsBounded(secondLine))
        {
            Console.WriteLine("bounded");
        }
        else
        {
            Console.WriteLine("unbounded");
        }

        if (IsBounded(thirdLine))
        {
            Console.WriteLine("bounded");
        }
        else
        {
            Console.WriteLine("unbounded");
        }
    }

    private static bool IsBounded(string command)
    {
        Point step1 = ExecuteCommands(command, 0, 0, 0);
        Point step2 = new Point();
        double currentDistance = PointDistance(step1);
        double nextDistance = PointDistance(step2);
        
        for (int i = 0; i < 100; i++)
        {
            currentDistance = PointDistance(step1);
            step2 = ExecuteCommands(command, step1.X, step1.Y, step1.Direction);
            nextDistance = PointDistance(step2);
            step1.X = step2.X; step1.Y = step2.Y; step1.Direction = step2.Direction;

            if (currentDistance >= nextDistance)
            {
                return true;
            }
        }

        return false;
    }

    private static double PointDistance(Point step1)
    {
        return (double) step1.X * step1.X + step1.Y * step1.Y;
    }

    private static Point ExecuteCommands(string command, int startX, int startY, int direction)
    {
        Point start = new Point();
        start.X = startX; start.Y = startY;

        for (int i = 0; i < command.Length; i++)
        {
            if (command[i] == 'L')
            {
                if (direction == 0)
                {
                    direction = 3;
                }
                else
                {
                    direction--;
                }
            }

            if (command[i] == 'R')
            {
                direction = (direction + 1) % 4;
            }

            if (command[i] == 'S')
            {
                switch (direction)
                {
                    case 0:
                        start.Y++;
                        break;
                    case 1:
                        start.X++;
                        break;
                    case 2:
                        start.Y--;
                        break;
                    case 3:
                        start.X--;
                        break;
                    default:
                        break;
                }
            }
        }
        start.Direction = direction;
        return start;
    }

    private static int FindLastLamp(int n)
    {
        int lastLamp = 0;

        bool[] lamps = new bool[n];
        int i = 1;
        int k = 0;
        while (true)
        {
            k = FindFalseLamp(lamps);
            if (k == -1)
            {
                break;
            }
            
            while (k < lamps.Length)
            {
                if (!lamps[k])
                {
                    lamps[k] = true;
                    lastLamp = k;
                }
                k += i+1;
            }

            i++;
        }

        return lastLamp;
    }

    private static int FindFalseLamp(bool[] lamps)
    {
        for (int i = 0; i < lamps.Length; i++)
        {
            if (!lamps[i])
            {
                return i;
            }
        }

        return -1;
    }
}