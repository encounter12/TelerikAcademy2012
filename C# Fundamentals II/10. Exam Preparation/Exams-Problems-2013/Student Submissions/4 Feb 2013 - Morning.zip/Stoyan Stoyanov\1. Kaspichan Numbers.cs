using System;
using System.Collections.Generic;
using System.Numerics;

class Program
{

    static char[] cha = { ' ', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    static List<char> ConvertDecTo256(BigInteger intV)
    {
        char rest;
        List<char> chRes = new List<char>();
        while (true)
        {
            if (intV == 0)
            {
                break;
            }
            rest = (char)(intV % 256L);
            byte chI = (byte)(rest % 26);
            byte chi = (byte)(rest / 26);

            chRes.Add((char)(chI + 'A'));
            if (chi != 0)
            {
                chRes.Add(cha[chi]);
            }

            intV = intV / 256;
        }
        return chRes;
    }
    static void Main()
    {
        BigInteger word = BigInteger.Parse(Console.ReadLine());

        List<char> res = new List<char>();
        res = ConvertDecTo256(word);
        res.Reverse();

        for (int i = 0; i < res.Count; i++)
        {
            Console.Write(res[i]);
        }
    }
}
