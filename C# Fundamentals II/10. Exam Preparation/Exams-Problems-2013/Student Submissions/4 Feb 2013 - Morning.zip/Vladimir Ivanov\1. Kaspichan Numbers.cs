using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class Program
{
    static void Main()
    {
        uint number = uint.Parse(Console.ReadLine());
        switch (number)
        {
            case 0: Console.WriteLine("A"); break;
            case 1: Console.WriteLine("B"); break;
            case 2: Console.WriteLine("C"); break;
            case 3: Console.WriteLine("D"); break;
            case 4: Console.WriteLine("E"); break;
            case 5: Console.WriteLine("F"); break;
            case 6: Console.WriteLine("G "); break;
            case 7: Console.WriteLine("H"); break;
            case 8: Console.WriteLine("I"); break;
            case 9: Console.WriteLine("J"); break;
            case 10: Console.WriteLine("K"); break;
            case 11: Console.WriteLine("L"); break;
            case 12: Console.WriteLine("M"); break;
            case 13: Console.WriteLine("N"); break;
            case 14: Console.WriteLine("O"); break;
            case 15: Console.WriteLine("P"); break;
            case 16: Console.WriteLine("Q"); break;
            case 17: Console.WriteLine("R"); break;
            case 18: Console.WriteLine("S"); break;
            case 19: Console.WriteLine("T"); break;
            case 20: Console.WriteLine("U"); break;
            case 21: Console.WriteLine("V"); break;
            case 22: Console.WriteLine("W"); break;
            case 23: Console.WriteLine("X"); break;
            case 24: Console.WriteLine("Y"); break;
            case 25: Console.WriteLine("Z"); break;
            case 26: Console.WriteLine("aA "); break;
            case 27: Console.WriteLine("aB"); break;
            case 28: Console.WriteLine("aC"); break;
            case 29: Console.WriteLine("aD"); break;
        }
    }
}