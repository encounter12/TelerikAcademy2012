using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Problem_4
{
    public static String Justify(String s, Int32 count)
    {
        if (count <= 0)
            return s;

        Int32 middle = s.Length / 2;
        IDictionary<Int32, Int32> spaceOffsetsToParts = new Dictionary<Int32, Int32>();
        String[] parts = s.Split(' ');
        for (Int32 partIndex = 0, offset = 0; partIndex < parts.Length; partIndex++)
        {
            spaceOffsetsToParts.Add(offset, partIndex);
            offset += parts[partIndex].Length + 1;
        }
        foreach (var pair in spaceOffsetsToParts.OrderBy(entry => Math.Abs(middle - entry.Key)))
        {
            count--;
            if (count < 0)
                break;
            parts[pair.Value] += ' ';
        }
        return String.Join(" ", parts);
    }

    static void Main()
    {

        StringBuilder text = new StringBuilder();
        int n = 5; // int.Parse(Console.ReadLine());
        int w = 20; // int.Parse(Console.ReadLine());
        string buffer = string.Empty;
        int line = 0;

        while (true)
        {
            int ch = Console.Read();
            if (ch == -1)
            {
                break;
            }

            if (ch == 13) line++;
            if (line == 1 && ch == 13)
            {
                buffer = text.ToString();
                n = int.Parse(buffer);
                text.Clear();
                continue;
            }
            if (line == 2 && ch == 13)
            {
                buffer = text.ToString();
                w = int.Parse(buffer);
                text.Clear();
                continue;
            }
           
            char nextChar = (char)ch;
            if (nextChar == '\r' || nextChar == '\n') nextChar = ' ';

            text.Append(nextChar);
        }

        buffer = text.ToString();
        buffer = buffer.Trim();
        //buffer = "We happy few        we band of brothers for he who sheds his blood with me shall be my brother";

        StringBuilder result = new StringBuilder();
        String[] parts = buffer.Split(' ');
        text.Clear();
        int lineChars = 0;

        for (int i = 0; i < parts.Length; i++)
        {
            if (parts[i] == " " || parts[i] == "") continue;

            if (lineChars + (parts[i].Length + 1) > w)
            {
                string part = string.Empty;
                part = text.ToString();
                part = part.Substring(0, part.Length - 1);
                result.Append(Justify(part, w - part.Length));
                result.Append("\r\n");
                text.Clear();
                lineChars = 0;
            }
            text.Append(parts[i] + " ");
            lineChars += parts[i].Length + 1;
        }

        Console.WriteLine(result);
    }

}