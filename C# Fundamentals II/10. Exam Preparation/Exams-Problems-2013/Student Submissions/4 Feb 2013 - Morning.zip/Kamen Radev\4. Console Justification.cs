using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main()
    {
        int numLines = int.Parse(Console.ReadLine());
        int symbols = int.Parse(Console.ReadLine());
        List<string> words = new List<string>();
        for (int i = 0; i < numLines; i++)
        {
            string[] lineContent = Console.ReadLine().Split(new char[] {' '}, StringSplitOptions.RemoveEmptyEntries);
            for (int k = 0; k < lineContent.Length; k++)
            {
                words.Add(lineContent[k]);
            }
        }
        StringBuilder finalText = new StringBuilder();
        while (words.Count > 0)
        {
            StringBuilder newLine = new StringBuilder().Append(words[0]);
            words.Remove(words[0]);
            while (newLine.Length <= symbols && words.Count > 0)
            {
                if (newLine.Length + 1 + words[0].Length <= symbols)
                {
                    newLine.Append(' ');
                    newLine.Append(words[0]);
                    words.Remove(words[0]);
                }
                else
                {
                    break;
                }               
            }
            int numberOfWords = 1;
            int index = newLine.ToString().IndexOf(' ');
            while (index > -1)
            {
                numberOfWords++;
                index = newLine.ToString().IndexOf(' ', index + 1);
            }
            if (numberOfWords > 1)
            {
                int numWhiteSpacesToAdd = symbols - newLine.Length;
                int[] inBetween = new int[numberOfWords - 1];
                int counter = 0;
                while (numWhiteSpacesToAdd > 0)
                {
                    inBetween[counter]++;
                    numWhiteSpacesToAdd--;
                    counter++;
                    if (counter == numberOfWords - 1)
                        counter = 0;
                }
                index = newLine.ToString().IndexOf(' ');
                for (int i = 0; i < inBetween.Length; i++)
                {
                    newLine.Insert(index, new string(' ', inBetween[i]));
                    index = newLine.ToString().IndexOf(' ', index + 1 + inBetween[i]);
                }
            }

            finalText.AppendLine(newLine.ToString());
        }
        Console.WriteLine(finalText);
    }
}