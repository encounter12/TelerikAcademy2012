using System;
using System.Collections.Generic;
using System.Text;

class ConsoleJustification
{
    static void Main()
    {
        int lines = int.Parse(Console.ReadLine());
        int symbols = int.Parse(Console.ReadLine());

        StringBuilder inputText = new StringBuilder();

        for (int line = 0; line < lines; line++)
        {
            string readLine = Console.ReadLine();
            inputText.Append(readLine + " ");
        }


        string inputText1 = inputText.ToString();
        string inputText2 = inputText1.Trim();
        string[] validWords = inputText2.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

        int position = 0;
        for (int allLines = 0; allLines < lines; allLines++)
        {
            
            StringBuilder fillLine = new StringBuilder();
            
            for (int i = position; i < validWords.Length; i++)
			    {
			        //char[] ch = validWords[i].ToCharArray();
                    
                    fillLine.Append(validWords[i]);
                    char space = ' ';
                    if (fillLine.Length < symbols - 2)
                    {
                        fillLine.Append(space);
                        continue;
                    }
                    else
                    {
                        position = i + 1;
                        break;
                    }
			    }
            
            Console.WriteLine(fillLine);
            fillLine.Clear();
        }
    }
}

