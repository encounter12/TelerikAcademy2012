using System;
class Program
{
    static int sum = 0;
    static int maxSum = int.MinValue;
    static void CalcPoints(int[] input, int[] path, int currentPos, bool inRec)
    {
        if (inRec == true)
        {
            sum -= input[currentPos];
        }

        for (int i = 0; i < path.Length + 1; i++)
        {

            if (currentPos >= input.Length || currentPos < 0)
            {
                break;
            }
            if (input[currentPos] != 10001)
            {
                sum += input[currentPos];

                if (i == path.Length)
                {
                    break;
                }
                else
                {
                    input[currentPos] = 10001;
                    currentPos += path[i];
                }
            }
            else
            {
                if (sum > maxSum)
                {
                    maxSum = sum;
                }
                sum = 0;
                return;
            }
        }
        if (currentPos < input.Length && currentPos > 0)
        {
            if (input[currentPos] != 10001)
            {
                CalcPoints(input, path, currentPos, true);
            }
            else
            {
                sum = 0;
                return;
            }
        }
    }
    static void Main()
    {
        string[] userInput = Console.ReadLine().Split(',');



        int numberOfPaths = int.Parse(Console.ReadLine());


        for (int i = 0; i < numberOfPaths; i++)
        {
            int[] input = new int[userInput.Length];

            for (int s = 0; s < userInput.Length; s++)
            {
                input[s] = int.Parse(userInput[s].Trim());
            }
            string[] userPath = Console.ReadLine().Split(',');
            int[] path = new int[userPath.Length];
            for (int j = 0; j < userPath.Length; j++)
            {
                path[j] = int.Parse(userPath[j].Trim());
            }
            CalcPoints(input, path, 0, false);
        }
        Console.WriteLine(maxSum);
    }
}

//1,3,-6,7,4,1,12