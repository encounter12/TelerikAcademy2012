using System;

class Program
{
    static string[] CreateKaspichan(ulong number)
    {
        string[] kasp = new string[256];
        int count = 0;
        for (char i = 'A'; i <= 'Z'; i++)
        {
            kasp[count] = i.ToString();
            count++;
        }
        for (char i = 'a'; i <= 'i'; i++)
            for (char j = 'A'; j <= 'Z'; j++)
            {
                kasp[count] = i.ToString()+j.ToString();                        
                count++;
                if (count == 256) break;
            }
        return kasp;
    }
    static string Kaspichan(ulong number)
    {
        string result="";
        string[] kasp = CreateKaspichan(number);
        while(number > 0)
        {
            result = kasp[number%256]+ result;
            number = number / 256;
        }
        return result;
    }
    
    static void Main()
    {
        ulong number = ulong.Parse(Console.ReadLine());
        if(number ==0 )
            Console.WriteLine("A");
        else
            Console.WriteLine(Kaspichan(number));
        
    }
}