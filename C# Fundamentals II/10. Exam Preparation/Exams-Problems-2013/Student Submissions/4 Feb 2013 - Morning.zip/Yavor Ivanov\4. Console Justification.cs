using System;
using System.Text.RegularExpressions;
using System.Collections.Generic;

class ConsoleJuat
{
    static void Main()
    {
        int lines = int.Parse(Console.ReadLine());
        int index = 0;
        List<string> wrds = new List<string>();
        int symbols = int.Parse(Console.ReadLine());
        string[] afterLines = new string[lines];
        string[] everyWord = new string[symbols];
        string[] liness = new string[lines];
        for (; index < lines; index++)
        {
            liness[index] = Console.ReadLine();
        }
        index = 0;
        for (; index < liness.Length; index++)
        {
            everyWord = liness[index].Split(' ');
            foreach (var item in everyWord)
            {
                if (item == "")
                {

                }
                else 
                {
                    wrds.Add(item.Trim());
                }
            }
        }
        index = 0;
        int spaces = 0;
        for (; index < wrds.Count; index++)
        {
            spaces += wrds[index].Length;
            if (spaces >= symbols)
            {
                Console.WriteLine();
                spaces = 0;
            }
            if (index == wrds.Count)
            {
                Console.Write((wrds[index]));
            }
            else 
            {
                Console.Write(wrds[index] + " ");
            }
        }

    }
}