using System;

class GreedyDwarf
{
    static void Main()
    {
        string[] input = Console.ReadLine().Split(
            new char[] { ' ', ',' },
            StringSplitOptions.RemoveEmptyEntries);

        int[] valley = new int[input.Length];
        for (int i = 0; i < valley.Length; i++)
        {
            valley[i] = int.Parse(input[i]);
        }

        int m = int.Parse(Console.ReadLine());
        string[] patternLines = new string[m];
        for (int i = 0; i < patternLines.Length; i++)
		{
			 patternLines[i] = Console.ReadLine();
		}

        long bestSum = long.MinValue;

        foreach (var pattern in patternLines)
        {
            long curSum = Calc(valley, pattern);
            if (bestSum < curSum) bestSum = curSum;
        }
        Console.WriteLine(bestSum);
    }

    private static long Calc(int[] valley, string pattern)
    {
        string[] split = pattern.Split(
            new char[] { ' ', ',' },
            StringSplitOptions.RemoveEmptyEntries);

        if (split.Length == 0) return 0;

        bool[] visited = new bool[valley.Length];
        int[] map = new int[split.Length];
        for (int i = 0; i < map.Length; i++)
        {
            map[i] = int.Parse(split[i]);
        }

        int mapIndex = 0;
        int valleyPosition = 0;

        long curSum = valley[valleyPosition];

        while (true)
        {
            if (map[mapIndex] == 0) return curSum;

            int nextPosition = valleyPosition + map[mapIndex];
            if (nextPosition < 0 || nextPosition >= valley.Length)
            {
                return curSum;
            }
            if (visited[nextPosition])
            {
                return curSum;
            }

            curSum += valley[nextPosition];
            visited[nextPosition] = true;

            valleyPosition = nextPosition;

            if (mapIndex < map.Length - 1)
            {
                mapIndex++;
            }
            else
            {
                mapIndex = 0;
            }
        }
    }
}