using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Greedy
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] valeyStr = input.Split(',');
            int[] valey = new int[valeyStr.Length];
            bool[] isVisited = new bool[valeyStr.Length];
            for (int i = 0; i < valey.Length; i++)
            {
                valey[i] = int.Parse(valeyStr[i]);
            }
            int pathsCount = int.Parse(Console.ReadLine());
            List<int[]> paths = new List<int[]>();
            for (int i = 0; i < pathsCount; i++)
            {
                input = Console.ReadLine();
                string[] pathStr = input.Split(',');
                int[] path = new int[pathStr.Length];
                for (int j = 0; j < pathStr.Length; j++)
                {
                    path[j] = int.Parse(pathStr[j]);
                }
                paths.Add(path);
            }
            long maxSum = long.MinValue;
            foreach (int[] path in paths)
            {
                int index = 0;
                long sum = 0;
                int stepIndex = 0;
                isVisited = new bool[isVisited.Length];
                while (true)
                {
                    if (index >= valey.Length || index < 0)
                    {
                        break;
                    }
                    else if (isVisited[index])
                    {
                        break;
                    }
                    else
                    {
                        isVisited[index] = true;
                        if (index >= valey.Length || index < 0)
                        {
                            break;
                        }
                        sum += valey[index];
                        index += path[stepIndex];
                        stepIndex++;
                        if (stepIndex == path.Length)
                        {
                            stepIndex = 0;
                        }
                    }
                }
                if (sum > maxSum)
                {
                    maxSum = sum;
                }
            }
            Console.WriteLine(maxSum);
        }
    }
}
