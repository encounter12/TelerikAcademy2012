using System;
using System.Text;

    class KaspNumber
    {
        public static int SUM; 
        public static int[] Valley;
        public static bool[] CoinsGet;

        static bool[] GetTheCoinOrNot(int TheLength)
        {
            bool[] TheArray = new bool[TheLength];
            TheArray[0] = false;
            for (int i = 1; i < TheLength; i++)
            {
                TheArray[i] = true;
            }

            return TheArray;
        }


        static void TheBestSum(int TheSum)
        {
            if (TheSum > SUM)
            {
                SUM = TheSum;
            }
        }

        static void SearchThruThePaths(int NumberPaths)
        {

            for (int i = 0; i < NumberPaths; i++)
            {
                Console.Write("Write Path {0}: ", i + 1);
                string str = Console.ReadLine().Replace(" ", "");
                int[] TheArray = ConvertTheStrings(str);

                if (i == 0)
                {
                    SUM = FindTheSolution(TheArray);
                }

                TheBestSum(FindTheSolution(TheArray));

            }

            Console.WriteLine(SUM);
        }


        static int[] ConvertToInt(string[] StrArray)
        {
            int[] TheArray = new int[StrArray.Length];
            for(int i = 0; i<TheArray.Length; i++)
            {
                TheArray[i] = int.Parse(StrArray[i]);
            }

            return TheArray;
        }

        static int[] ConvertTheStrings(string str)
        { 
            string[] TheString = str.Split(',');
            int[] IntString = ConvertToInt(TheString);

            return IntString; 
        }


        // Prashta mi ARRAy i VALLEY;
        static int FindTheSolution(int[] Pattern)
        {
            int TheIndex = 0;
            int[] TheArray = Valley;
            int TheSum = TheArray[TheIndex];
            int ValueElement = 0;
            bool TheLastIndexVisited = true;
           //////////////////////////////////////////

            while (TheLastIndexVisited)
            {
                

                for (int i = 0; i < Pattern.Length; i++)
                {
                    ValueElement = TheIndex + Pattern[i]; // 3 - 3 = 0
                    try
                    {
                        if (CoinsGet[ValueElement])
                        {
                            TheSum += TheArray[ValueElement];
                            if (CoinsGet[ValueElement] == true)
                            {
                                CoinsGet[ValueElement] = false;
                                TheIndex = TheIndex + Pattern[i]; // 0 + 3 = 3
                                TheLastIndexVisited = true;
                            }
                            else
                            {

                                TheLastIndexVisited = false;
                                break;

                            }

                        }
                        else
                        {
                            TheLastIndexVisited = false;
                            break;
                        }
                    }
                    catch(IndexOutOfRangeException)
                    {
                        Console.WriteLine("The index is out of range!");
                    }
                }

            }
                return TheSum;
            
        }
        

        static void Main()
        {
            Console.Write("Please enter the valley (numbers separated by \" , \")");
            string str = Console.ReadLine().Replace(" ","");
            Valley = ConvertTheStrings(str);
            CoinsGet = GetTheCoinOrNot(Valley.Length);
            Console.Write("Please write how many pathrs:");
            int NumberOfPaths = int.Parse(Console.ReadLine());
            SearchThruThePaths(NumberOfPaths);


            
        }
            
    }
