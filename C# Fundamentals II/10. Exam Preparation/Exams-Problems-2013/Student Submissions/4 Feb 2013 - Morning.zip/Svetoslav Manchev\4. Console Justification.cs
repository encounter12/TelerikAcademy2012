using System;
using System.Text;

class Justification
{
    static void Main()
    {
        int lines = int.Parse(Console.ReadLine());
        int wordsPerRow = int.Parse(Console.ReadLine());
        StringBuilder temp = new StringBuilder();
        StringBuilder justifiedText = new StringBuilder();
        string line = "";
        for (int i = 0; i < lines; i++)
        {
            line = Console.ReadLine();
            line += ' ';
            temp.Append(line);
        }

        char[] splitter = new char[] { ' ', '\n', '\r' };
        // string[] text = temp.ToString().Split(new char[0], StringSplitOptions.RemoveEmptyEntries);
        string[] text = temp.ToString().Split(new char[0],StringSplitOptions.RemoveEmptyEntries);
        int length = text.Length;


        // Justify text
        temp.Clear();
        temp.Append(text[0]);
        for (int i = 1; i < length; i++)
        {
            if (wordsPerRow - temp.Length - text[i].Length > 0)
            {
                temp.Append(" " + text[i]);
            }
            else
            {
                if (wordsPerRow == temp.Length)
                {
                    string nextLine = temp.ToString();
                    justifiedText.Append(nextLine + "\n");
                    temp.Clear();
                    temp.Append(text[i]);
                }
                else
                {
                    string nextLine = Justify(temp, wordsPerRow);
                    justifiedText.Append(nextLine + "\n");
                    temp.Clear();
                    temp.Append(text[i]);
                }
            }
        }
        justifiedText.Append(text[length - 1]);
        Console.WriteLine(justifiedText.ToString());

    }

    private static string Justify(StringBuilder temp, int W)
    {
        //StringBuilder toJustify = new StringBuilder();
        string tempStr = temp.ToString();
        int index = tempStr.IndexOf(' ');
        if (index < 0)
        {
            return tempStr;
        }
        while (true)
        {
            temp.Insert(index, ' ');
            tempStr = temp.ToString();
            index += 2;

            if (temp.Length >= W)
            {
                return temp.ToString();
            }

            while (true)
            {
                if (tempStr[index] != ' ')
                {
                    index = tempStr.IndexOf(' ', index);
                    if (index < 0)
                    {
                        index = tempStr.IndexOf(' ');
                    }
                    break;
                }
                else
                {
                    index++;
                }
            }
        }
        return temp.ToString();
    }
}
