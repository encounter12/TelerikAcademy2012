using System;
using System.Collections.Generic;
using System.Text;

class Problem01
{
    static void Main()
    {
        ulong inpN = ulong.Parse(Console.ReadLine());
        // fillup printout matrix
        string[] kD = new string[256];
        for (int j = 0; j < 26; j++)
            {
                kD[j] = ((char)(65 + j)).ToString();
            }
        int f = 25;
        for (int i = 0; i <= 8; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    f++;
                    if (f > 255) break;
                    kD[f] = ((char)(97 + (i))).ToString() + ((char)(65 + j)).ToString();
                }
            }
        /*
        for (int i = 0; i < 256; i++)
        {
            Console.WriteLine("kD[{0}]= {1}", i, kD[i]);
        }
         */
        // calculate in Kaspichan
        List<ulong> kaspNum = new List<ulong>();
        bool ended = false;
        ulong work;
        do
        {
            work = inpN / 256;
            if (work == 0)
            {
                kaspNum.Add(inpN % 256);
                ended = true;
            }
            else
            {
                kaspNum.Add(inpN % 256);
                inpN = inpN / 256; 
            }
        }
        while (!ended);
            /* if (inpN / 256 != 0) kaspNum.Add(inpN % 256);
            
            if (inpN / 256 < 256)
            {
                kaspNum.Add(inpN % 256);
                ended = true;
            }
            else inpN = inpN / 256;
        }
        while (!ended);
             */
        if (inpN < 0) Console.Write("-");
        for (int i = kaspNum.Count - 1; i >= 0; i--)
        {
            Console.Write(kD[kaspNum[i]]);
        }
        Console.WriteLine();
    }
}
