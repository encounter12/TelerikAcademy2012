using System;

namespace Slides
{
    class Slides
    {
        static void Main()
        {
            Console.Write("Enter values for w: ,h: ,d: ");
            int width = int.Parse(Console.ReadLine());
            int height= int.Parse(Console.ReadLine());
            int depth= int.Parse(Console.ReadLine());
            int[,,] cuboid = new int[width, height, depth];
            for (int i = 0; i < width; i++)
            {
                for (int j = 1; j < height; j++)
                {
                    for (int k = 0; k < depth; k++)
                    {
                        Console.Write("cubion[{0},{1},{2}]=",width,height,depth);
                    }
                }
            }
        }
               
    }
}
