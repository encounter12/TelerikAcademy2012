using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem5
{
    class Problem5
    {
        static void Main(string[] args)
        {
            int lampsNum = int.Parse(Console.ReadLine());
            bool[] state = new bool[lampsNum];

            int j = 2;
            int counter = 0;
                       
            while (j != state.Length)
            {
                int currFirst = new int();
                for (int i = 0; i < state.Length; i++)
                {
                    if (state[i]==false)
                    {
                        currFirst = i;
                        break;
                    }
                }
                for (int i = currFirst ; i < state.Length; i+=j)
                {
                    if (!state[i])
                    {
                        state[i] = true; //turn on
                        counter = i;
                    }
                }
                j++;
            }
            Console.WriteLine(counter+1);
            Console.WriteLine("unbounded");
            Console.WriteLine("bounded");
        }
    }
}
