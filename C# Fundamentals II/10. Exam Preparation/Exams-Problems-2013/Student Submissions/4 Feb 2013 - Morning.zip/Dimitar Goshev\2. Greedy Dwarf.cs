using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_1
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] separators = {',', ' ' };
            string input = Console.ReadLine();
            int n = int.Parse(Console.ReadLine());
            string[] valley = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            List<int> inputNumbers = new List<int>();


            for (int p = 0; p < valley.Length; p++)
                {
                        inputNumbers.Add(int.Parse(valley[p]));
                }
            //List<int[]> collection = new List<int[]>();

            int[,] matrix = new int[n, 100];
            for (int i = 0; i < n; i++)
            {

                string pattern = Console.ReadLine();
                string[] pattentNum = pattern.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                for (int j = 0; j < pattentNum.Length; j++)
                {
                    matrix[i,j] = int.Parse(pattentNum[j]);
                }

            }

            int collected = inputNumbers[1];
            int max = collected;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < 100; j++)
                {
                    if (matrix[i, j] != 0)
	                {
                     collected += inputNumbers[1 + matrix[i, j]] ;
	                }

                }
                if (max< collected)
                {
                    max = collected;
                }

            }
            Console.WriteLine(max);


            //for (int i = 0; i < n; i++)
            //{
            //    for (int j = 0; j < 100; j++)
            //    {
            //        Console.WriteLine(matrix[i, j]);
            //    }

            //}
        }
    }
}
