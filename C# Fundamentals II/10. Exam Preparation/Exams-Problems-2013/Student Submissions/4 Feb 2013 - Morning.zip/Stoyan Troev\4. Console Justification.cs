using System;
namespace ConsoleJustification
{
    class ConsoleJustification
    {
        static void Main()
        {
            Console.Write("Enter the number of text's lines n:");
            int n = int.Parse(Console.ReadLine());
            Console.Write("Enter the number of symbols on a line w:");
            int w = int.Parse(Console.ReadLine());

        }
    }
}
