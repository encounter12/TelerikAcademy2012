using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _04.ConsoleJustification
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int W = int.Parse(Console.ReadLine());
            string[] inputLines = new string[N];
            for (int i = 0; i < N; i++)
            {
                inputLines[i] = Console.ReadLine();
            }
            for (int i = 0; i < N; i++)
            {
                Console.WriteLine(inputLines[i]);
            }
            
        }
    }
}
