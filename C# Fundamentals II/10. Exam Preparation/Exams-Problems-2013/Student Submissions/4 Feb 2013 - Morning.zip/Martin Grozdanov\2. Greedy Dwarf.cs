using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
 
class problem2
{
 
 
    private static List<int> toint(string arr)
    {
        List<int> array = new List<int>();
        char[] separ = { ' ', ',' };
        string[] split = arr.Split(separ);
        int s;
        for (int i = 0; i < split.Length; i++)
        {
            if (int.TryParse(split[i], out s))
            {
                array.Add(s);
            }
        }
        return array;
    }
 
    static void Main(string[] args)
    {
        string val =  Console.ReadLine();
        int num = int.Parse(Console.ReadLine());
        int max = 0;
        int k = 0;
        string[] paths = new string[num];
        List<int> valey = toint(val);
        for (int i = 0; i < num; i++)
        {
            paths[i] = Console.ReadLine();
             
        }
        for (int i= 0; i < num; i++)
        {
            List<int> path = toint(paths[i]);
            int coins = 0;
            List<int> visited = new List<int>();
            try
            {
                while (k < valey.Count)
                {
                    if (k == 0)
                    {
                        coins += valey[k];
                        visited.Add(k);
                    }
                    for (int j = 0; j < path.Count; j++)
                    {
 
                        k += path[j];
                        if (visited.Contains(k))
                        {
                            if (coins > max)
                            {
                                max = coins;
                            }
                            throw new Exception();
                        }
                        coins += valey[k];
                        visited.Add(k);
                    }
                     
                }
                
            }
            catch (Exception)
            {
                if (coins > max)
                {
                    max = coins;
                }
            }
             
        }
        Console.WriteLine(max);
    }
 
    
}