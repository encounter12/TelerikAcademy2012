using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        int N = int.Parse(Console.ReadLine());
        int W = int.Parse(Console.ReadLine());
        string[] lines = new string[N];
        List<string> words = new List<string>();
        for (int i = 0; i < N; i++)
        {
            lines[i] = Console.ReadLine();
            string[] split = lines[i].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string word in split)
                words.Add(word);            
        }

        int symbols = 0;
        for (int i = 0; i < words.Count; i++)
        {
            symbols += words[i].Length;
        }

        int index = 0;
        int counter = 0;
        int leftOver = W;
        for (int i = 1; i <= N; i++)
        {
            counter = 0;
            for (; index < words.Count; index++)
            {
                leftOver = W - counter;
                if (leftOver > words[index].Length)
                    Console.Write(words[index] + " ");
                else if (leftOver == words[index].Length)
                    Console.Write(words[index]);
                else
                    break;
                counter += words[index].Length + 1;
                //index++;
                //if (counter > 20) break;
            }
            if (leftOver >= 0)
                Console.Write(new string(' ', leftOver));
            Console.WriteLine();
        }
     }
}
