using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class ConsoleJustification
{
    static void Main()
    {
        //int linesNumber = 5;
        //int width = 20;
        int linesNumber = int.Parse(Console.ReadLine());
        int width = int.Parse(Console.ReadLine());

        char[] splitArray = new char[] { ' ', '\n' };

        StringBuilder inputText = new StringBuilder();
        while (linesNumber >= 1)
        {
            inputText.Append(Console.ReadLine() + '\n');
            linesNumber--;
        }

        string alltext = inputText.ToString();
        string[] splittedText = alltext.Split(splitArray, StringSplitOptions.RemoveEmptyEntries);


        int i = 0;
        string curretnLineText = "";

        while (i < splittedText.Length)
        {
            string currentLine = "";

            // get words for current line
            int k = i;
            int countOfWords = 0;
            while ((currentLine.Length - 1 < width) && (k <= splittedText.Length - 1))
            {
                currentLine = currentLine + splittedText[k] + " ";
                countOfWords++;
                k++;
            }



            if ((countOfWords > 1) && (currentLine.Length - 1 > width))
            {
                countOfWords--;
            }
            // ??? one word 

            // Console.WriteLine();


            // calc lenght of the words 
            string buffer = "";
            for (int j = i; j < i + countOfWords; j++)
            {
                buffer = buffer + splittedText[j];
            }
            int totalSpaces = width - buffer.Length;


            int cqlaChast = 1;
            int reminder = 1;
            if (countOfWords > 1)
            {
                cqlaChast = totalSpaces / (countOfWords - 1);
                reminder = totalSpaces % (countOfWords - 1);

                reminder = totalSpaces - (countOfWords - 1) * cqlaChast;
                reminder = reminder + cqlaChast;
                //if (reminder == 0)
                //{
                //    reminder = cqlaChast;
                //}
            }
            else
            {
                cqlaChast = 0;
                reminder = 0;
            }

            curretnLineText = "";
            int currentWordNumber = 0;
            for (int j = i; j < i + countOfWords; j++)
            {
                currentWordNumber++;
                if (currentWordNumber == 1)
                {
                    curretnLineText = curretnLineText + splittedText[j] + new String(' ', (reminder));
                }
                else if (currentWordNumber < (countOfWords - 1))
                {
                    curretnLineText = curretnLineText + splittedText[j] + new String(' ', cqlaChast);
                }
                else if (currentWordNumber == (countOfWords - 1))
                {
                    curretnLineText = curretnLineText + splittedText[j] + new String(' ', cqlaChast);
                }
                else
                {
                    curretnLineText = curretnLineText + splittedText[j];
                }

            }
            Console.WriteLine(curretnLineText);
            i = i + countOfWords;
        }






    }
}
