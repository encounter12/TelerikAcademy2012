using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace ConsoleJustification
{
    class ConsoleJustification
    {
        static int N, W;
        static List<string> Words = new List<string>();

        static void Main(string[] args)
        {
            //using (StreamReader sr = new StreamReader("../../text.txt"))
            //{
                N = int.Parse(Console.ReadLine());
                W = int.Parse(Console.ReadLine());
                //N = int.Parse(sr.ReadLine());
                //W = int.Parse(sr.ReadLine());

                string line;
                for (int i = 0; i < N; i++)
                {
                    line = Console.ReadLine();
                    //line = sr.ReadLine();
                    //Console.WriteLine(line);
                    string[] words = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int j = 0; j < words.Length; j++)
                    {
                        Words.Add(words[j]);
                        //Console.WriteLine(words[j]);
                    }
                }

                for (int i = 0; i < Words.Count; i++)
                {
                    int size = 0;
                    int cnt = 0;
                    while (cnt + i < Words.Count && size + Words[i + cnt].Length <= W)
                    {
                        size += Words[i + cnt].Length;
                        size++;
                        cnt++;
                    }
                    size--;
                    int left = W - size;
                    //Console.WriteLine(cnt + " " + size + " " + left);
                    
                    if (cnt == 1)
                    {
                        Console.Write(Words[i]);
                    }
                    else
                    {
                        int spacesAfterEachWord = left / (cnt - 1);

                        int j;
                        for (j = 0; j < left % (cnt - 1); j++)
                        {
                            Console.Write(Words[i + j]);
                            Console.Write(" ");
                            for (int k = 0; k < spacesAfterEachWord; k++)
                            {
                                Console.Write(" ");
                            }
                            Console.Write(" ");
                        }
                        for (; j < cnt - 1; j++)
                        {
                            Console.Write(Words[i + j]);
                            Console.Write(" "); 
                            for (int k = 0; k < spacesAfterEachWord; k++)
                            {
                                Console.Write(" ");
                            }
                        }
                        Console.Write(Words[i + cnt - 1]);
                    }
                    i += cnt - 1;

                    Console.WriteLine();
                }
            //}
        }
    }
}
