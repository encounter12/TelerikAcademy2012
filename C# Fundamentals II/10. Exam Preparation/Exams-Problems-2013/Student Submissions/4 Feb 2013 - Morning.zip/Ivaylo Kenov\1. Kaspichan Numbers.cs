using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KaspichanNUmbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] digits = new string[256];

            int firstIndex = 0;
            int capitalIndex = 0;

            StringBuilder result = new StringBuilder();

            while (true)
            {
                if (firstIndex == 256)
                {
                    break;
                }

                if (firstIndex / 26 == 1)
                {
                    result.Append('a');
                }
                if (firstIndex / 26 == 2)
                {
                    result.Append('b');
                }
                if (firstIndex / 26 == 3)
                {
                    result.Append('c');
                }
                if (firstIndex / 26 == 4)
                {
                    result.Append('d');
                }
                if (firstIndex / 26 == 5)
                {
                    result.Append('e');
                }
                if (firstIndex / 26 == 6)
                {
                    result.Append('f');
                }
                if (firstIndex / 26 == 7)
                {
                    result.Append('g');
                }
                if (firstIndex / 26 == 8)
                {
                    result.Append('h');
                }
                if (firstIndex / 26 == 9)
                {
                    result.Append('i');
                }

                if (capitalIndex == 26)
                {
                    capitalIndex = 0;
                }

                result.Append((char)(65 + capitalIndex));

                digits[firstIndex] = result.ToString();

                firstIndex++;
                capitalIndex++;
                result.Clear();
            }

            ulong input = ulong.Parse(Console.ReadLine());

            if (input == 0)
            {
                Console.WriteLine("A");
                return;
            }

            List<string> output = new List<string>();

            while (input != 0)
            {
                ulong currentDigit = input % 256;

                output.Add(digits[currentDigit]);

                input /= 256;
            }

            output.Reverse();

            for (int i = 0; i < output.Count; i++)
            {
                Console.Write(output[i]);
            }
        }
    }
}
