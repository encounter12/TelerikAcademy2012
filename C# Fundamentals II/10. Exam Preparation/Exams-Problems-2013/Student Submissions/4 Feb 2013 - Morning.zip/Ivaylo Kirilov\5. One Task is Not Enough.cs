using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OneTaskIsNotEnough
{
    class OneTaskIsNotEnough
    {
        static int N;

        static void SolveBulbs()
        {
            bool[] on = new bool[N];
            int step = 2;
            int last = 0;

            for (int i = 0; i < N; i++)
            {
                if (!on[i])
                {
                    //Console.WriteLine(i);
                    int at = 0;
                    for (int j = i + 1; j < N; j++)
                    {
                        if (!on[j])
                        {
                            at++;
                            if (at % (step) == 0)
                            {
                                //Console.WriteLine(j.ToString().PadLeft(10));
                                on[j] = true;
                            }
                        }
                    }
                    on[i] = true;
                    last = i;
                    step++;
                }
            }

            Console.WriteLine(last + 1);
        }

        static void SolveRobotRoute()
        {
            string line = Console.ReadLine();
            int leftTurns = 0, rightTurns = 0;
            int straight = 0;

            for (int i = 0; i < line.Length; i++)
            {
                if (line[i] == 'L')
                {
                    leftTurns++;
                }
                else if (line[i] == 'R')
                {
                    rightTurns++;
                }
                else
                {
                    straight++;
                }
            }

            if (straight > 0)
            {
                if (rightTurns == leftTurns)
                {
                    Console.WriteLine("unbounded");
                }
                else
                {
                    Console.WriteLine("bounded");
                }
            }
            else
            {
                Console.WriteLine("bounded");
            }
        }

        static void Main(string[] args)
        {
            N = int.Parse(Console.ReadLine());
            SolveBulbs();
            SolveRobotRoute();
            SolveRobotRoute();
        }
    }
}
