using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KaspichanNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            ulong number = ulong.Parse(Console.ReadLine());
            char[] capital = Enumerable.Range('A', 'Z' - 'A' + 1).Select(i => (Char)i).ToArray();
            char[] little = Enumerable.Range('a', 'z' - 'a' + 1).Select(i => (Char)i).ToArray();
            //Console.WriteLine(ulong.MaxValue);
            //foreach (var item in little)
            //{
            //    Console.WriteLine(item);
            //}

            StringBuilder digitsInKaspichan = new StringBuilder();
            for (int index = 0; index < capital.Length; index++)
            {
                
                digitsInKaspichan.Append(' ').Append(capital[index]);
            }
            for (int index = 0; index < 8; index++)
            {
                char currentChar = (char)(index + 97);
                for (int index2 = 0; index2 < 26; index2++)
                {
                   digitsInKaspichan.Append(' ').Append(currentChar).Append(capital[index2]); 
                }                       
            }
            char otherCurrentChar = (char)(8 + 97);
            for (int index2 = 0; index2 < 22; index2++)
            {
                digitsInKaspichan.Append(' ').Append(otherCurrentChar).Append(capital[index2]);
            }  
            string[] tokens = digitsInKaspichan.ToString().Split(new char[]{' '}, StringSplitOptions.RemoveEmptyEntries);
            //Console.WriteLine(tokens.Length);
            //Console.WriteLine(tokens[17]);

            //foreach (var item in tokens)
            //{
            //    Console.WriteLine(item);
            //}
           // Console.WriteLine(tokens.Length);

            StringBuilder result = new StringBuilder();
            List<ulong> remainders = new List<ulong>();

            while (number > 255)
            {
                ulong remainder = number % 256;
                remainders.Add(remainder);


                //result.Append(tokens[remainder]);
                    number /= 256;
            }

            remainders.Add(number);
            for (int index = remainders.Count - 1; index >=0; index--)
            {
                Console.Write(tokens[remainders[index]]);
            }
            Console.WriteLine(result);


           // Console.WriteLine(digitsInKaspichan);
            //StringBuilder test = new StringBuilder();
            //char a = 'a';
            //test.Append(a);
           // Console.WriteLine(test);
            //for (int index = 0; index < 51; index++)
            //{
            //    Console.WriteLine(digitsInKaspichan[index]);
            //}

        }
    }
}
