using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


    class Exam02
    {
        static int[] steps, work;
        static void Main(string[] args)
        {
            string vhod = Console.ReadLine();
            string[] pattnum = vhod.Split(',');
            int z = pattnum.Length;
            int[] pattern = new int[z];
            for (int i = 0; i < z; i++)
            {
                pattern[i] = int.Parse(pattnum[i]);
            }
            int coins = 0;
            int coinsMax = int.MinValue;            
            int counter = 0;
            int fields = 0;

            int routes = int.Parse(Console.ReadLine());
            string[] danni = new string[routes];
            for (int i = 0; i < routes; i++)
            {
                danni[i] = Console.ReadLine();
            }

            copy(pattern);

            for (int i = 0; i < routes; i++)
            {
                InArray(danni[i]);
                coins += work[fields];
                work[fields] = 12345;

                while (true)
                {                    
                    fields += steps[counter];
                    if (fields < pattern.Length && fields >= 0)
                    {
                        if (work[fields] != 12345)
                        {
                            coins += work[fields];
                            work[fields] = 12345;
                            counter++;                            
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                    if (counter == steps.Length)
                    {
                        counter = 0;
                    }
                }                
                if (coins > coinsMax)
                {
                    coinsMax = coins;
                }
                coins = 0;
                fields = 0;
                counter = 0;
                copy(pattern);
            }
            Console.WriteLine(coinsMax);
        }

        static void InArray(string input)
        {
            string[] drops = input.Split(',');
            int k = drops.Length;
            steps = new int[k];
            for (int i = 0; i < k; i++)
            {
                steps[i] = int.Parse(drops[i]);
            }
        }

        static void copy(int[] original)
        {
            int xx = original.Length;
            work = new int[xx];
            for (int i = 0; i < xx; i++)
            {
                work[i] = original[i];
            }
        }
    }