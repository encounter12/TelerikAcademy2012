using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class GreedyDwarf
{
    private static double FindSum(int[] patternToCheck, double[] numbersValley)
    {
        int indexValley = 0;
        int indexForPattern = 0;
        double sum = 0;
        bool[] visited = new bool[numbersValley.Length];

        visited[0] = true;
        sum += numbersValley[0];
        for (int i = 1; i < visited.Length; i++)
        {
            visited[i] = false;
        }
        while (indexValley >= 0 && indexValley < numbersValley.Length) //&& procceed
        {
            indexForPattern = indexForPattern % (patternToCheck.Length);
            indexValley += patternToCheck[indexForPattern];
            if (indexValley <= 0 || indexValley >= numbersValley.Length)
            {
                break;
            }
            indexForPattern++;
         //   Console.WriteLine("index for valley {0}", indexValley);
        //    Console.WriteLine("number {0}",numbersValley[indexValley]);
            if (visited[indexValley] == true)
            {
                break;
            }
            sum += numbersValley[indexValley];
            visited[indexValley] = true;
        }
        return sum;
    }


    static void Main()
    {
        string inputValley = Console.ReadLine();
        string[] tokens = inputValley.Split(',');
        double[] numbersValley = new double[tokens.Length];
        for (int i = 0; i < numbersValley.Length; i++)
        {
            numbersValley[i] = double.Parse(tokens[i]);
        }

        short M = short.Parse(Console.ReadLine());

        string inputPattern = Console.ReadLine();
        string[] tokensPattern = inputPattern.Split(',');
        int[] patternToCheck = new int[tokensPattern.Length];
        for (int j = 0; j < patternToCheck.Length; j++)
        {
            patternToCheck[j] = int.Parse(tokensPattern[j].Trim());
            //     Console.WriteLine(patternToCheck[j]);

        }

        double maxSum = FindSum(patternToCheck,numbersValley); //long? nope...
        for (int i = 1; i < M; i++)
        {
            inputPattern = Console.ReadLine();
            tokensPattern = inputPattern.Split(',');
            patternToCheck = new int[tokensPattern.Length];
            for (int j = 0; j < patternToCheck.Length; j++)
            {
                patternToCheck[j] = int.Parse(tokensPattern[j].Trim());
                //     Console.WriteLine(patternToCheck[j]);

            }

            double sum = FindSum(patternToCheck, numbersValley);
            if (maxSum < sum)
            {
                maxSum = sum;
            }
        }

            Console.WriteLine(maxSum);
        

    }


}
