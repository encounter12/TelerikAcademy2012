using System;
using System.Collections.Generic;

class GreedyDwarf
{
    static void Main()
    {
        int bestSum = 0;
        int times = 8;
        string valley = Console.ReadLine();
        valley = valley.Replace(",", "");
        string[] exValley = valley.Split(' ');
        times = int.Parse(Console.ReadLine());
        while (times != 0)
        {
            int sum = 0;
            int currentIndex = 0;
            int index = 0;
            string patt = Console.ReadLine();
            patt = patt.Replace(",", "");
            string[] exPattern = patt.Split(' ');
       
            sum = int.Parse(exValley[0]);
            for (; index < exPattern.Length-1; index++)
            {
                currentIndex = (int.Parse(exValley[index + int.Parse(exPattern[index])]));
                sum += currentIndex;
            }
            if (sum > bestSum)
            {
                bestSum = sum;
            }
            times--;
        }
        Console.WriteLine(bestSum);
     }
}
