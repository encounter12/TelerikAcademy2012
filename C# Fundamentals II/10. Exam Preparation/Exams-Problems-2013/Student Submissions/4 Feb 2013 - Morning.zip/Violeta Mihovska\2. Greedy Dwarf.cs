using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Greedy_Dwarf
{
    class Program
    {
        static void Main(string[] args)
        {            
            int n = int.Parse(Console.ReadLine());
            int[] valley = new int[n];
            for (int i = 0; i < n; i++)
            {
                valley[i] = int.Parse(Console.ReadLine());
            }
            int numberOfPatterns = int.Parse(Console.ReadLine());

            int m = int.Parse(Console.ReadLine());
            int[] patterns = new int[m];
            for (int i = 0; i < m; i++)
            {
                patterns[i] = int.Parse(Console.ReadLine());
            }
            
            //int[] valley = { 1, 3, -6, 7, 4, 1, 12 };
            //int[] patterns = { 1, 2, -3 };
            //int numberOfPatterns = 3;


            int startPosition = valley[0];
            int collectCoins = 0;

            for (int i = 0; i < patterns.Length; i++)
            {
                for (int j = 0; j <= valley.Length; j++)
                {                    
                    //startPosition += patterns[i];
                    collectCoins += valley[j];
                }
            }
            Console.WriteLine(collectCoins);
            
        }
    }
}
