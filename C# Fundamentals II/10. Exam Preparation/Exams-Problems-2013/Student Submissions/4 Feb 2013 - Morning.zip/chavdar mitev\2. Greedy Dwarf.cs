using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace greedy
{
    class greedy
    {
        static void Main(string[] args)
        {
            int bestSum = 0;
            
            string enter = Console.ReadLine();
            string[] newEnter = enter.Split(',');
            int[] masiv = new int[newEnter.Length];
            for (int i = 0; i < newEnter.Length; i++)
            {
                masiv[i] = int.Parse(newEnter[i].Trim());
                
            }

            int numberOfPatern = int.Parse(Console.ReadLine());
            for (int i = 0; i < numberOfPatern; i++)
            {
                int[] masivZero = new int[masiv.Length];
                for (int n = 0; n < masiv.Length; n++)
                {
                    masivZero[n] = masiv[n];

                }
                
                string enterTwo = Console.ReadLine();
                string[] newEnterTwo = enterTwo.Split(',');
                int[] masivProba = new int[newEnterTwo.Length];
                
                for (int z = 0; z < newEnterTwo.Length; z++)
                {
                    masivProba[z] = int.Parse(newEnterTwo[z].Trim());
                }
                int index = 0; int sum = masiv[0]; masivZero[0] = 0;
                int y = 0;
                for (int z = 0; z < masiv.Length;z++ )
                {

                    index = index + masivProba[y];
                    if ((index > masiv.Length) || (index < 0)|| (masivZero[index]==0))
                        break;
                    sum = sum + masivZero[index];
                    masivZero[index] = 0;
                    y++;
                    if (y > masivProba.Length - 1)
                        y = 0;

                }
                if (sum > bestSum)
                    bestSum = sum;

            }
            Console.WriteLine(bestSum);
        }
    }
}
