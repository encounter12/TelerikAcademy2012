using System;

class Greedy
{
    static string[] valley;
    static bool[] visited;
    static long maxResult = int.MinValue;

    static void Main()
    {
        string inpValey = Console.ReadLine();
        valley = inpValey.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);

        visited = new bool[valley.Length];

        int patternCount = int.Parse(Console.ReadLine());

        for (int i = 0; i < patternCount; i++)
        {
            long tmp = GetCoins(ReadPattern());
            //Console.WriteLine(tmp);
            if (tmp > maxResult)
            {
                maxResult = tmp;
            }
        }

        Console.WriteLine(maxResult);
    }

    public static long GetCoins(int[] pattern)
    {

        int min = 0;
        int max = valley.Length-1;
        long currSum = int.Parse(valley[0]);
        //To start from first element
        int nextStart = 0;
        
        //Clear visits
        for (int i = 0; i < visited.Length; i++)
        {
            visited[i] = false;
        }

        visited[0] = true; 
        do
        {
            for (int i = 0; i < pattern.Length; i++)
            {
                //Out of valey
                if (nextStart + pattern[i] > max)
                {
                    return currSum;
                }
                if (nextStart + pattern[i] < min)
                {
                    return currSum;
                }
                //Already visited
                if (visited[nextStart + pattern[i]] == true)
                {
                    return currSum;
                }

                currSum += long.Parse(valley[nextStart+pattern[i]]);
                visited[nextStart + pattern[i]] = true;
                nextStart = nextStart + pattern[i];
                
            }
            
        } while (true);

    }

    public static int[] ReadPattern()
    {
        string buffer = Console.ReadLine();
        string[] patternStr = buffer.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        int[] pattern = new int[patternStr.Length];
        for (int i = 0; i < patternStr.Length; i++)
        {
            pattern[i] = int.Parse(patternStr[i]);
        }
        return pattern;
    }
}