using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace KaspichanNumbers
{
    class KaspichanNumbers
    {
        static void Main(string[] args)
        {

            string[] alphabet = new string[256];
          

            alphabet[0] = "A";
            alphabet[1] = "B";
            alphabet[2] = "C";
            alphabet[3] = "D";
            alphabet[4] = "E";
            alphabet[5] = "F";
            alphabet[6] = "G";
            alphabet[7] = "H";
            alphabet[8] = "I";
            alphabet[9] = "J";
            alphabet[10] = "K";
            alphabet[11] = "L";
            alphabet[12] = "M";
            alphabet[13] = "N";
            alphabet[14] = "O";
            alphabet[15] = "P";
            alphabet[16] = "Q";
            alphabet[17] = "R";
            alphabet[18] = "S";
            alphabet[19] = "T";
            alphabet[20] = "U";
            alphabet[21] = "V";
            alphabet[22] = "W";
            alphabet[23] = "X";
            alphabet[24] = "Y";
            alphabet[25] = "Z";
            alphabet[26] = "aA";
            alphabet[27] = "aB";
            alphabet[28] = "aC";
            alphabet[29] = "aD";
            alphabet[30] = "aE";
            alphabet[31] = "aF";
            alphabet[32] = "aG";
            alphabet[33] = "aH";
            alphabet[34] = "aI";
            alphabet[35] = "aJ";
            alphabet[36] = "aK";
            alphabet[37] = "aL";
            alphabet[38] = "aM";
            alphabet[39] = "aN";
            alphabet[40] = "aO";
            alphabet[41] = "aP";
            alphabet[42] = "aQ";
            alphabet[43] = "aR";
            alphabet[44] = "aS";
            alphabet[45] = "aT";
            alphabet[46] = "aU";
            alphabet[47] = "aV";
            alphabet[48] = "aW";
            alphabet[49] = "aX";
            alphabet[50] = "aY";
            alphabet[51] = "aZ";
            alphabet[52] = "bA";
            alphabet[53] = "bB";
            alphabet[54] = "bC";
            alphabet[55] = "bD";
            alphabet[56] = "bE";
            alphabet[57] = "bF";
            alphabet[58] = "bG";
            alphabet[59] = "bH";
            alphabet[60] = "bI";
            alphabet[61] = "bJ";
            alphabet[62] = "bK";
            alphabet[63] = "bL";
            alphabet[64] = "bM";
            alphabet[65] = "bN";
            alphabet[66] = "bO";
            alphabet[67] = "bP";
            alphabet[68] = "bQ";
            alphabet[69] = "bR";
            alphabet[70] = "bS";
            alphabet[71] = "bT";
            alphabet[72] = "bU";
            alphabet[73] = "bV";
            alphabet[74] = "bW";
            alphabet[75] = "bX";
            alphabet[76] = "bY";
            alphabet[77] = "bZ";
            alphabet[78] = "cA";
            alphabet[79] = "cB";
            alphabet[80] = "cC";
            alphabet[81] = "cD";
            alphabet[82] = "cE";
            alphabet[83] = "cF";
            alphabet[84] = "cG";
            alphabet[85] = "cH";
            alphabet[86] = "cI";
            alphabet[87] = "cJ";
            alphabet[88] = "cK";
            alphabet[89] = "cL";
            alphabet[90] = "cM";
            alphabet[91] = "cN";
            alphabet[92] = "cO";
            alphabet[93] = "cP";
            alphabet[94] = "cQ";
            alphabet[95] = "cR";
            alphabet[96] = "cS";
            alphabet[97] = "cT";
            alphabet[98] = "cU";
            alphabet[99] = "cV";
            alphabet[100] = "cW";
            alphabet[101] = "cX";
            alphabet[102] = "cY";
            alphabet[103] = "cZ";
            alphabet[104] = "dA";
            alphabet[105] = "dB";
            alphabet[106] = "dC";
            alphabet[107] = "dD";
            alphabet[108] = "dE";
            alphabet[109] = "dF";
            alphabet[110] = "dG";
            alphabet[111] = "dH";
            alphabet[112] = "dI";
            alphabet[113] = "dJ";
            alphabet[114] = "dK";
            alphabet[115] = "dL";
            alphabet[116] = "dM";
            alphabet[117] = "dN";
            alphabet[118] = "dO";
            alphabet[119] = "dP";
            alphabet[120] = "dQ";
            alphabet[121] = "dR";
            alphabet[122] = "dS";
            alphabet[123] = "dT";
            alphabet[124] = "dU";
            alphabet[125] = "dV";
            alphabet[126] = "dW";
            alphabet[127] = "dX";
            alphabet[128] = "dY";
            alphabet[129] = "dZ";
            alphabet[130] = "eA";
            alphabet[131] = "eB";
            alphabet[132] = "eC";
            alphabet[133] = "eD";
            alphabet[134] = "eE";
            alphabet[135] = "eF";
            alphabet[136] = "eG";
            alphabet[137] = "eH";
            alphabet[138] = "eI";
            alphabet[139] = "eJ";
            alphabet[140] = "eK";
            alphabet[141] = "eL";
            alphabet[142] = "eM";
            alphabet[143] = "eN";
            alphabet[144] = "eO";
            alphabet[145] = "eP";
            alphabet[146] = "eQ";
            alphabet[147] = "eR";
            alphabet[148] = "eS";
            alphabet[149] = "eT";
            alphabet[150] = "eU";
            alphabet[151] = "eV";
            alphabet[152] = "eW";
            alphabet[153] = "eX";
            alphabet[154] = "eY";
            alphabet[155] = "eZ";
            alphabet[156] = "fA";
            alphabet[157] = "fB";
            alphabet[158] = "fC";
            alphabet[159] = "fD";
            alphabet[160] = "fE";
            alphabet[161] = "fF";
            alphabet[162] = "fG";
            alphabet[163] = "fH";
            alphabet[164] = "fI";
            alphabet[165] = "fJ";
            alphabet[166] = "fK";
            alphabet[167] = "fL";
            alphabet[168] = "fM";
            alphabet[169] = "fN";
            alphabet[170] = "fO";
            alphabet[171] = "fP";
            alphabet[172] = "fQ";
            alphabet[173] = "fR";
            alphabet[174] = "fS";
            alphabet[175] = "fT";
            alphabet[176] = "fU";
            alphabet[177] = "fV";
            alphabet[178] = "fW";
            alphabet[179] = "fX";
            alphabet[180] = "fY";
            alphabet[185] = "fZ";
            alphabet[182] = "gA";
            alphabet[183] = "gB";
            alphabet[184] = "gC";
            alphabet[185] = "gD";
            alphabet[186] = "gE";
            alphabet[187] = "gF";
            alphabet[188] = "gG";
            alphabet[189] = "gH";
            alphabet[190] = "gI";
            alphabet[191] = "gJ";
            alphabet[192] = "gK";
            alphabet[193] = "gL";
            alphabet[194] = "gM";
            alphabet[195] = "gN";
            alphabet[196] = "gO";
            alphabet[197] = "gP";
            alphabet[198] = "gQ";
            alphabet[199] = "gR";
            alphabet[200] = "gS";
            alphabet[201] = "gT";
            alphabet[202] = "gU";
            alphabet[203] = "gV";
            alphabet[204] = "gW";
            alphabet[205] = "gX";
            alphabet[206] = "gY";
            alphabet[207] = "gZ";
            alphabet[208] = "hA";
            alphabet[209] = "hB";
            alphabet[210] = "hC";
            alphabet[211] = "hD";
            alphabet[212] = "hE";
            alphabet[213] = "hF";
            alphabet[214] = "hG";
            alphabet[215] = "hH";
            alphabet[216] = "hI";
            alphabet[217] = "hJ";
            alphabet[218] = "hK";
            alphabet[219] = "hL";
            alphabet[220] = "hM";
            alphabet[221] = "hN";
            alphabet[222] = "hO";
            alphabet[223] = "hP";
            alphabet[224] = "hQ";
            alphabet[225] = "hR";
            alphabet[226] = "hS";
            alphabet[227] = "hT";
            alphabet[228] = "hU";
            alphabet[229] = "hV";
            alphabet[230] = "hW";
            alphabet[231] = "hX";
            alphabet[232] = "hY";
            alphabet[233] = "hZ";
            alphabet[234] = "iA";
            alphabet[235] = "iB";
            alphabet[236] = "iC";
            alphabet[237] = "iD";
            alphabet[238] = "iE";
            alphabet[239] = "iF";
            alphabet[240] = "iG";
            alphabet[241] = "iH";
            alphabet[242] = "iI";
            alphabet[243] = "iJ";
            alphabet[244] = "iK";
            alphabet[245] = "iL";
            alphabet[246] = "iM";
            alphabet[247] = "iN";
            alphabet[248] = "iO";
            alphabet[249] = "iP";
            alphabet[250] = "iQ";
            alphabet[251] = "iR";
            alphabet[252] = "iS";
            alphabet[253] = "iT";
            alphabet[254] = "iU";
            alphabet[255] = "iV";

            //BigInteger num = new BigInteger();
            ulong num = ulong.Parse(Console.ReadLine());
            List<ulong> hex = new List<ulong>();
            if (num == 0)
            {
                hex.Add(0);
            }
            else
            {
                while (num != 0)
                {
                    hex.Add(num % 256);
                    num /= 256;
                }
            }

            
            //foreach (var a in hex)
            //{
            //    Console.WriteLine(a);
            //}

            StringBuilder output = new StringBuilder();
            for (int i = hex.Count-1; i >= 0; i--)
            {
                ulong number = hex[i];
                output.Append(Convert.ToString(alphabet[number]));
            }
            Console.WriteLine(output);
        }
    }
}
