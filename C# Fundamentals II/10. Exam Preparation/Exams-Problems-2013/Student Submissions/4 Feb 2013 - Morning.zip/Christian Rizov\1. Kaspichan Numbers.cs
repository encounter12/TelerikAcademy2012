using System;
using System.Text;



class Kaspichan
{
    static string to256(ulong decNumber,string[] alpha)
    {
        
        ulong counter = 0;
        ulong copyOfNumber = decNumber;
        while (copyOfNumber != 0)
        {
            copyOfNumber /= 256;
            counter++;
        }

        ulong copy = decNumber;
        string[] finalNumber = new string[counter];
        for (ulong i = 0; i < counter; i++)
        {
            ulong index = copy % 256;
            finalNumber[counter - 1 - i] = alpha[index];
            copy = copy / 256;
        }

        StringBuilder final = new StringBuilder();
        for (ulong i = 0; i < counter; i++)
        {
            final.Append(finalNumber[i]);
        }

        if (decNumber != 0)
        {
            return final.ToString();
        }
        else
        {
            return "0";
        }
    }
    

    static void Main()
    {
        string[] num256 = new string[256];
        for (int i = 0; i < 9; i++)
        {
            for (int j = 0; j < 26; j++)
            {
                if (i == 0)
                {
                    num256[j] = ((char)(65 + j)).ToString();
                }

                if (i == 1)
                {
                    num256[j + 26] = ((char)(96 + i)).ToString() + ((char)(65 + j)).ToString();
                }

                if (i == 2)
                {
                    num256[j + 52] = ((char)(96 + i)).ToString() + ((char)(65 + j)).ToString();
                }

                if (i == 3)
                {
                    num256[j + 78] = ((char)(96 + i)).ToString() + ((char)(65 + j)).ToString();
                }

                if (i == 4)
                {
                    num256[j + 104] = ((char)(96 + i)).ToString() + ((char)(65 + j)).ToString();
                }

                if (i == 5)
                {
                    num256[j + 130] = ((char)(96 + i)).ToString() + ((char)(65 + j)).ToString();
                }

                if (i == 6)
                {
                    num256[j + 156] = ((char)(96 + i)).ToString() + ((char)(65 + j)).ToString();
                }

                if (i == 7)
                {
                    num256[j + 182] = ((char)(96 + i)).ToString() + ((char)(65 + j)).ToString();
                }

                if (i == 8)
                {
                    num256[j + 208] = ((char)(96 + i)).ToString() + ((char)(65 + j)).ToString();
                }
            }
        }

        for (int i = 0; i < 22; i++)
        {
            num256[i + 234] = ("i" + ((char)(65 + i)).ToString());
        }

        

        // The string is generated.
        
        ulong number = ulong.Parse(Console.ReadLine());
        
        Console.WriteLine(to256(number,num256));
            
    }
}
