using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace robot
{
    class Program
    {
        static void Main(string[] args)
        {
            string bounden = "bounded";
            string unbounded = "unbounded";
            Console.WriteLine(bounden, unbounded);
        }
    }
}
