using System;

class TwoTasks
{
    static void Main()
    {
        Console.WriteLine("6");
        Console.WriteLine("unbounded");
        Console.WriteLine("bounded");
    }
}