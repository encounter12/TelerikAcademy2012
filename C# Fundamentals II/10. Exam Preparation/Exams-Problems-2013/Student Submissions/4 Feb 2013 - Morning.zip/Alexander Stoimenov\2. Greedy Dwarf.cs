using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Task2
{
    static void Main()
    {
        string numbers = Console.ReadLine();
        string[] valley = numbers.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        int m = int.Parse(Console.ReadLine());
        string[] patt = null;
        for (int i = 0; i < m; i++)
        {
            string pat = Console.ReadLine();
            patt = pat.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        }
        int sum = int.Parse(valley[int.Parse(patt[0])]) + int.Parse(valley[int.Parse(patt[1])]) + int.Parse(valley[int.Parse(patt[2])]);
        Console.WriteLine(sum);
    }
}
