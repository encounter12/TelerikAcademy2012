using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string[] str = new string[2];
        for (int i = 0; i < 2; i++)
        {
            str[i] = Console.ReadLine();
        }
        int lastLamp = -1;
        int tmp = 2;
        List<int> lamp = new List<int>();
        for (int i = 1; i <= n; i++)
        {
            lamp.Add(i);
        }
        while (lamp.Count > 0)
        {
            for (int i = 0; i < lamp.Count; i += tmp)
            {
                lastLamp = lamp[i];
                lamp[i] = 0;
            }
            while (lamp.Contains(0))
            {
                lamp.Remove(0);
            }
            tmp++;
        }
        Console.WriteLine(lastLamp);
        for (int i = 0; i < 2; i++)
        {
            
            int result = 0;
            for (int c = 0; c < str[i].Length; c++)
            {
                if (str[i][c] == 'S')
                {
                    result += 1;
                }
                else 
                {
                    result -= 1;
                }
            }
            if (result != 0)
            {
                Console.WriteLine("bounded");
            }
            else 
            {
                Console.WriteLine("unbounded");
            }
        }
    }
}
