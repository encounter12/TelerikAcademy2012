using System;

namespace GreedyDwarf
{
    class GreedyDwarf
    {
        static void Main()
        {
            int[] valley = new int[] { 1, 3, -6, 7, 4, 1, 12 };
        }
    }
}
