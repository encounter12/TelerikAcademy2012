using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace KaspichanNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string cInput;
            string result;

            cInput = Console.ReadLine();

            result = ConvertToKasp(cInput);

            Console.WriteLine(result);
        }
        static string ConvertToKasp(string str)
        {
            BigInteger num = BigInteger.Parse(str);
            string result = "";
            BigInteger reminder;
            char letter = ' ';
            int temp = 65;

            if (num == 0)
            {
                result = "A";
            }
            while (num > 0)
            {
                reminder = num % 256;
                num = num / 256;
                if (reminder >= 0 && reminder <= 25)
                {
                     result += Convert.ToString((char)(reminder + temp)) + "@";
                } 
                else if (reminder >= 26 && reminder <= 51)
                {
                    letter = 'a';
                    result += letter + Convert.ToString((char)(reminder + temp - 26)) + "@";
                }
                else if (reminder >= 52 && reminder <= 77)
                {
                    letter = 'b';
                    result += letter + Convert.ToString((char)(reminder + temp - 52)) + "@";
                }
                else if (reminder >= 78 && reminder <= 103)
                {
                    letter = 'c';
                    result += letter + Convert.ToString((char)(reminder + temp - 78)) + "@";
                }
                else if (reminder >= 104 && reminder <= 129)
                {
                    letter = 'd';
                    result += letter + Convert.ToString((char)(reminder + temp - 104)) + "@";
                }
                else if (reminder >= 130 && reminder <= 155)
                {
                    letter = 'e';
                    result += letter + Convert.ToString((char)(reminder + temp - 130)) + "@";
                }
                else if (reminder >= 156 && reminder <= 181)
                {
                    letter = 'f';
                    result += letter + Convert.ToString((char)(reminder + temp - 156)) + "@";
                }
                else if (reminder >= 182 && reminder <= 207)
                {
                    letter = 'g';
                    result += letter + Convert.ToString((char)(reminder + temp - 182)) + "@";
                }
                else if (reminder >= 208 && reminder <= 233)
                {
                    letter = 'h';
                    result += letter + Convert.ToString((char)(reminder + temp - 208)) + "@";
                }
                else if (reminder >= 234 && reminder <= 255)
                {
                    letter = 'i';
                    result += letter + Convert.ToString((char)(reminder + temp - 234)) + "@";
                }
            }
            string[] arr = result.Split('@');
            Array.Reverse(arr);
            StringBuilder sb = new StringBuilder();
            foreach (var item in arr)
            {
                sb.Append(item);
            }
            result = sb.ToString();
            return result;
        }
    }
}
