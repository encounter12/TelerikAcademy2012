using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


    class GreedyDwarf
    {
        static void Main(string[] args)
        {
            string inputValueNumbers = Console.ReadLine();
            char[] separators = new char[] { ',', ' ' };
            string[] numberStr = inputValueNumbers.Split(separators, StringSplitOptions.RemoveEmptyEntries);
           
            int[] numbers = new int[numberStr.Length];
            for (int i = 0; i < numberStr.Length; i++)
            {
                 numbers[i] = int.Parse(numberStr[i]);
            }
           
            int M = int.Parse(Console.ReadLine());
            checked
            {
                decimal maxSum = 0;

                for (int i = 0; i < M; i++)
                {
                    bool[] isVisitet = new bool[numberStr.Length];
                    string patternStr = Console.ReadLine();
                    string[] patterns = patternStr.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                    int[] patternDigits = new int[patterns.Length];
                    for (int index = 0; index < patterns.Length; index++)
                    {
                        patternDigits[index] = int.Parse(patterns[index]);
                    }
                    decimal currentSum = 0;
                    int numberIndex = 0;
                    bool isEndedIteration = false;

                    //for first digit of array
                    currentSum = numbers[numberIndex];
                    isVisitet[numberIndex] = true;

                    while (!isEndedIteration)
                    {
                        for (int patternIndex = 0; patternIndex < patternDigits.Length; patternIndex++)
                        {
                            numberIndex += patternDigits[patternIndex];
                            if (numberIndex < 0 || numberIndex > numberStr.Length - 1)
                            {
                                isEndedIteration = true;
                                break;
                            }
                            else if (isVisitet[numberIndex] == true)
                            {
                                isEndedIteration = true;
                                break;
                            }
                            else
                            {
                                currentSum += numbers[numberIndex];
                                isVisitet[numberIndex] = true;
                            }
                        }
                    }
                    if (currentSum > maxSum)
                    {
                        maxSum = currentSum;
                    }
                }
                Console.WriteLine(maxSum);
            }
            
        }
    }

