using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.KaspichanNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            ulong input = ulong.Parse(Console.ReadLine());
            if (input == 0)
            {
                Console.WriteLine('A');
                return;
            }
            string[] numbers = new string[256];
            for (int i = 0; i < 26; i++)
            {
                numbers[i] = ((char)(i + 'A')).ToString();
            }
            char letter = (char)('a'-1);
            for (int i = 26; i < 256; i++)
            {
                if (i % 26 == 0)
                    letter++;
                numbers[i] = (letter).ToString() + (char)(i%26 + 'A');
            }
            List<ulong> result = new List<ulong>();
            while (input != 0)
            {
                result.Add(input % 256);
                input /= 256;
            }
            for (int i = result.Count - 1; i >= 0; i--)
            {
                Console.Write(numbers[result[i]]);
            }
            Console.WriteLine();
            
        }


    }
}
