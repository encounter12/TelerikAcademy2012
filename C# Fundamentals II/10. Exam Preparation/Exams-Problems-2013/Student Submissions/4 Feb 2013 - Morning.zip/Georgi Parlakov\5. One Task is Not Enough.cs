using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5.TwoTasks
{
    class Program
    {
        static Dictionary<string, int> keeperX = new Dictionary<string, int>();
        static Dictionary<string, int> keeperY = new Dictionary<string, int>();
        static Dictionary<string, int> changerX;
        static Dictionary<string, int> changerY;
        static void Main()
        {
            int S = 1;
            int Sminus = -1;
            int R=1;
            int L = -1;

            keeperX = new Dictionary<string,int>();
            keeperX.Add("S", 1);
            keeperX.Add("Sminus", -1);
            keeperY = new Dictionary<string, int>();
            keeperY.Add("R", 1);
            keeperY.Add("L", -1);

             changerX = keeperX;
             changerY = keeperY;

            int Lamps = int.Parse(Console.ReadLine());
            int[] lampsArray = new int[Lamps];
            int i=0,indexModify = 2;
            int lastiIndex=0;
            for (i = 0; i < lampsArray.Length; i++)
            {
                int index = i;
                lastiIndex = i;
                do
                {
                    if (lampsArray[index] != 1)
                    {
                        lampsArray[index] = 1;
                    }
                    lastiIndex = index;
                    index += indexModify;                    
                } while (index < lampsArray.Length);
                indexModify++;                 
            }

            Console.WriteLine(lastiIndex);
            string command1 = Console.ReadLine();
            string command2 = Console.ReadLine();

          
            Console.WriteLine(Execute(command1));
            Console.WriteLine(Execute(command2));
        }

        private static string Execute(string command)
        {
            int repetitions = command.Length;
            int x=0, y = 0;
            do
            {
                for (int i = 0; i < command.Length; i++)
                {
                    if (keeperX.ContainsKey(command[i].ToString()))
                    {
                        x += changerX[command[i].ToString()];
                    }
                    else if (keeperY.ContainsKey(command[i].ToString()))
                    {
                        y += changerY[command[i].ToString()];
                    }

                    if (command[i] == 'L')
                    {
                        changerY["R"] *= changerX["S"];
                        changerX["S"] *= changerY["L"];
                        changerY["L"] *= changerX["Sminus"];
                    }
                    if (command[i] == 'R')
                    {
                        changerY["L"] *= changerX["S"];
                        changerX["S"] *= changerY["R"];
                        changerY["R"] *= changerX["Sminus"];
                    }

                }
                repetitions--;
            } while (repetitions >= 0);
            if (x==0&&y==0)
            {
                return "bounded"; 
            }
            else
            {
                return "unbounded";
            }
        }
    }
}
