using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _1.KaspichanNumbers
{
    class KaspichanNumbers
    {
        static char FindUpperDigit(ulong remainder)
        {
            switch (remainder)
            {
                case 0: return 'A';
                case 1: return 'B';
                case 2: return 'C';
                case 3: return 'D';
                case 4: return 'E';
                case 5: return 'F'; 
                case 6: return 'G';
                case 7: return 'H';
                case 8: return 'I';
                case 9: return 'J';
                case 10: return 'K'; 
                case 11: return 'L'; 
                case 12: return 'M'; 
                case 13: return 'N'; 
                case 14: return 'O'; 
                case 15: return 'P'; 
                case 16: return 'Q'; 
                case 17: return 'R'; 
                case 18: return 'S'; 
                case 19: return 'T'; 
                case 20: return 'U'; 
                case 21: return 'V'; 
                case 22: return 'W'; 
                case 23: return 'X'; 
                case 24: return 'Y'; 
                case 25: return 'Z'; 
                default: if (remainder >= 26 && remainder <= 51)
                    {
                        return 'a';
                    }
                    else if (remainder >= 52 && remainder <= 77)
                    {
                        return 'b';
                    }
                    else if (remainder >= 78 && remainder <= 103)
                    {
                        return 'c';
                    }
                    else if (remainder >= 104 && remainder <= 129)
                    {
                        return 'd';
                    }
                    else if (remainder >= 130 && remainder <= 155)
                    {
                        return 'e';
                    }
                    else if (remainder >= 156 && remainder <= 181)
                    {
                        return 'f';
                    }
                    else if (remainder >= 182 && remainder <= 207)
                    {
                        return 'g';
                    }
                    else if (remainder >= 208 && remainder <= 233)
                    {
                        return 'h';
                    }
                    else if (remainder >= 234 && remainder <= 255)
                    {
                        return 'i';
                    } break;
            }
            return ' ';
        }
        static StringBuilder ConvertToKaspichan(ulong number)
        {
            ulong remainder = 0;
            StringBuilder value = new StringBuilder();
            while (number > 0)
            {
                remainder = (ulong)number % 256;
                switch (remainder)
                {
                    case 0: value.Insert(0,"A"); break;
                    case 1: value.Insert(0,"B"); break;
                    case 2: value.Insert(0, "C"); break;
                    case 3: value.Insert(0, "D"); break;
                    case 4: value.Insert(0, "E"); break;
                    case 5: value.Insert(0, "F"); break;
                    case 6: value.Insert(0, "G"); break;
                    case 7: value.Insert(0, "H"); break;
                    case 8: value.Insert(0, "I"); break;
                    case 9: value.Insert(0, "J"); break;
                    case 10: value.Insert(0, "K"); break;
                    case 11: value.Insert(0, "L"); break;
                    case 12: value.Insert(0, "M"); break;
                    case 13: value.Insert(0, "N"); break;
                    case 14: value.Insert(0, "O"); break;
                    case 15: value.Insert(0, "P"); break;
                    case 16: value.Insert(0, "Q"); break;
                    case 17: value.Insert(0, "R"); break;
                    case 18: value.Insert(0, "S"); break;
                    case 19: value.Insert(0, "T"); break;
                    case 20: value.Insert(0, "U"); break;
                    case 21: value.Insert(0, "V"); break;
                    case 22: value.Insert(0, "W"); break;
                    case 23: value.Insert(0, "X"); break;
                    case 24: value.Insert(0, "Y"); break;
                    case 25: value.Insert(0, "Z"); break;
                    default: value.Insert(0,FindUpperDigit(remainder));
                             value.Insert(1, FindUpperDigit(remainder % 26));
                        break;
                }
                number = number / 256;
            }
            return value;
        }
        static void Main()
        {
            ulong number = ulong.Parse(Console.ReadLine());
            if (number == 0)
            {
                Console.WriteLine("A");
                return;
            }
            Console.WriteLine(ConvertToKaspichan(number));
        }
    }
}
