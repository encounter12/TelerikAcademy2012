using System;
using System.Linq;
using System.Text;

class TestCSharp_2_KaspichanNumbers
{
    static void ConvertNumberBase10ToD(int d, long decimalNumber)//метода, който обръща десетичното число е число в бройна система с база d
    {
        long remainder = 0;
        StringBuilder result = new StringBuilder();
        while (decimalNumber != 0)
        {
            switch (decimalNumber % 26)
            {
                case 0:
                    result.Append('A'); break;
                case 1:
                    result.Append('B'); break;
                case 2:
                    result.Append('C'); break;
                case 3:
                    result.Append('D'); break;
                case 4:
                    result.Append('E'); break;
                case 5:
                    result.Append('F'); break;
                case 6:
                    result.Append('G'); break;
                case 7:
                    result.Append('H'); break;
                case 8:
                    result.Append('I'); break;
                case 9:
                    result.Append('J'); break;
                case 10:
                    result.Append('K'); break;
                case 11:
                    result.Append('L'); break;
                case 12:
                    result.Append('M'); break;
                case 13:
                    result.Append('N'); break;
                case 14:
                    result.Append('O'); break;
                case 15:
                    result.Append('P'); break;
                case 16:
                    result.Append('Q'); break;
                case 17:
                    result.Append('R'); break;
                case 18:
                    result.Append('S'); break;
                case 19:
                    result.Append('T'); break;
                case 20:
                    result.Append('U'); break;
                case 21:
                    result.Append('V'); break;
                case 22:
                    result.Append('W'); break;
                case 23:
                    result.Append('X'); break;
                case 24:
                    result.Append('Y'); break;
                case 25:
                    result.Append('Z'); break;

                default:
                    result.Append(remainder);
                    break;
            }
            decimalNumber = decimalNumber / 26;
        }
        string endNumber1 = result.ToString();

        for (int i = endNumber1.Length - 1; i > -1; i--)
        {
            Console.Write(endNumber1[i]);
        }
        Console.WriteLine();
    }

    static void ConvertNumberBase10ToD1(int d, long decimalNumber)//метода, който обръща десетичното число е число в бройна система с база d
    {
        long remainder = 0;
        long decimalNumber1 = decimalNumber;
        string endNumber = String.Empty;
        StringBuilder result = new StringBuilder();
        while (decimalNumber != 0)
        {
            switch (decimalNumber / 26)
            {
                case 1:
                    result.Append('a'); break;
                case 2:
                    result.Append('b'); break;
                case 3:
                    result.Append('c'); break;
                case 4:
                    result.Append('d'); break;
                case 5:
                    result.Append('e'); break;
                case 6:
                    result.Append('f'); break;
                case 7:
                    result.Append('g'); break;
                case 8:
                    result.Append('h'); break;
                case 9:
                    result.Append('i'); break;
                case 10:
                    result.Append('j'); break;
                case 11:
                    result.Append('k'); break;
                case 12:
                    result.Append('l'); break;
                case 13:
                    result.Append('m'); break;
                case 14:
                    result.Append('n'); break;
                case 15:
                    result.Append('o'); break;
                case 16:
                    result.Append('p'); break;
                case 17:
                    result.Append('q'); break;
                case 18:
                    result.Append('r'); break;
                case 19:
                    result.Append('s'); break;
                case 20:
                    result.Append('t'); break;
                case 21:
                    result.Append('u'); break;
                case 22:
                    result.Append('v'); break;
                case 23:
                    result.Append('w'); break;
                case 24:
                    result.Append('x'); break;
                case 25:
                    result.Append('y'); break;
                case 26:
                    result.Append('z'); break;
                default:
                    result.Append(remainder);
                    break;
            }
            decimalNumber = decimalNumber / 26;

            string endNumber1 = result.ToString();
            for (int i = 0; i < endNumber1.Length - 1; i++)
            {
                Console.Write(endNumber1[i]);
            }
        }   
    }

    static void ConvertNumberBase10ToD2(int d, long decimalNumber)//метода, който обръща десетичното число е число в бройна система с база d
    {
        long remainder = 0;
        long decimalNumber1 = decimalNumber;
        string endNumber = String.Empty;
        StringBuilder result = new StringBuilder();
        while (decimalNumber != 0)
        {
            switch (decimalNumber / 256)
            {
                case 1:
                    result.Append('B'); break;
                case 2:
                    result.Append('C'); break;
                case 3:
                    result.Append('D'); break;
                case 4:
                    result.Append('E'); break;
                case 5:
                    result.Append('F'); break;
                case 6:
                    result.Append('G'); break;
                case 7:
                    result.Append('H'); break;
                case 8:
                    result.Append('I'); break;
                case 9:
                    result.Append('J'); break;
                case 10:
                    result.Append('K'); break;
                case 11:
                    result.Append('L'); break;
                case 12:
                    result.Append('M'); break;
                case 13:
                    result.Append('N'); break;
                case 14:
                    result.Append('O'); break;
                case 15:
                    result.Append('P'); break;
                case 16:
                    result.Append('Q'); break;
                case 17:
                    result.Append('R'); break;
                case 18:
                    result.Append('S'); break;
                case 19:
                    result.Append('T'); break;
                case 20:
                    result.Append('U'); break;
                case 21:
                    result.Append('V'); break;
                case 22:
                    result.Append('W'); break;
                case 23:
                    result.Append('X'); break;
                case 24:
                    result.Append('Y'); break;
                case 25:
                    result.Append('Z'); break;
                default:
                    result.Append(remainder);
                    break;
            }
            decimalNumber = decimalNumber / 256;

            string endNumber2 = result.ToString();
            for (int i = 0; i < endNumber2.Length - 1; i++)
            {
                Console.Write(endNumber2[i]);
            }
        }
    }

    static void ConvertNumberBase10ToD3(int d, long decimalNumber)//метода, който обръща десетичното число е число в бройна система с база d
    {
        long remainder = 0;
        long decimalNumber1 = decimalNumber;
        string endNumber = String.Empty;
        StringBuilder result = new StringBuilder();
        while (decimalNumber != 0)
        {
            switch (decimalNumber / 6400)
            {
                case 1:
                    result.Append('B'); break;
                case 2:
                    result.Append('C'); break;
                case 3:
                    result.Append('D'); break;
                case 4:
                    result.Append('E'); break;
                case 5:
                    result.Append('F'); break;
                case 6:
                    result.Append('G'); break;
                case 7:
                    result.Append('H'); break;
                case 8:
                    result.Append('I'); break;
                case 9:
                    result.Append('J'); break;
                case 10:
                    result.Append('K'); break;
                case 11:
                    result.Append('L'); break;
                case 12:
                    result.Append('M'); break;
                case 13:
                    result.Append('N'); break;
                case 14:
                    result.Append('O'); break;
                case 15:
                    result.Append('P'); break;
                case 16:
                    result.Append('Q'); break;
                case 17:
                    result.Append('R'); break;
                case 18:
                    result.Append('S'); break;
                case 19:
                    result.Append('T'); break;
                case 20:
                    result.Append('U'); break;
                case 21:
                    result.Append('V'); break;
                case 22:
                    result.Append('W'); break;
                case 23:
                    result.Append('X'); break;
                case 24:
                    result.Append('Y'); break;
                case 25:
                    result.Append('Z'); break;
                default:
                    result.Append(remainder);
                    break;
            }
            decimalNumber = decimalNumber / 6400;

            string endNumber3 = result.ToString();
            for (int i = 0; i < endNumber3.Length - 1; i++)
            {
                Console.Write(endNumber3[i]);
            }
        }
    }

    static void ConvertNumberBase10ToD4(int d, long decimalNumber)//метода, който обръща десетичното число е число в бройна система с база d
    {
        long remainder = 0;
        long decimalNumber1 = decimalNumber;
        string endNumber = String.Empty;
        StringBuilder result = new StringBuilder();
        while (decimalNumber != 0)
        {
            switch (decimalNumber / 160000)
            {
                case 1:
                    result.Append('B'); break;
                case 2:
                    result.Append('C'); break;
                case 3:
                    result.Append('D'); break;
                case 4:
                    result.Append('E'); break;
                case 5:
                    result.Append('F'); break;
                case 6:
                    result.Append('G'); break;
                case 7:
                    result.Append('H'); break;
                case 8:
                    result.Append('I'); break;
                case 9:
                    result.Append('J'); break;
                case 10:
                    result.Append('K'); break;
                case 11:
                    result.Append('L'); break;
                case 12:
                    result.Append('M'); break;
                case 13:
                    result.Append('N'); break;
                case 14:
                    result.Append('O'); break;
                case 15:
                    result.Append('P'); break;
                case 16:
                    result.Append('Q'); break;
                case 17:
                    result.Append('R'); break;
                case 18:
                    result.Append('S'); break;
                case 19:
                    result.Append('T'); break;
                case 20:
                    result.Append('U'); break;
                case 21:
                    result.Append('V'); break;
                case 22:
                    result.Append('W'); break;
                case 23:
                    result.Append('X'); break;
                case 24:
                    result.Append('Y'); break;
                case 25:
                    result.Append('Z'); break;
                default:
                    result.Append(remainder);
                    break;
            }
            decimalNumber = decimalNumber / 160000;

            string endNumber4 = result.ToString();
            for (int i = 0; i < endNumber4.Length - 1; i++)
            {
                Console.Write(endNumber4[i]);
            }
        }
    }

    static void ConvertNumberBase10ToD5(int d, long decimalNumber)//метода, който обръща десетичното число е число в бройна система с база d
    {
        long remainder = 0;
        long decimalNumber1 = decimalNumber;
        string endNumber = String.Empty;
        StringBuilder result = new StringBuilder();
        while (decimalNumber != 0)
        {
            switch (decimalNumber / 4000000)
            {
                case 1:
                    result.Append('B'); break;
                case 2:
                    result.Append('C'); break;
                case 3:
                    result.Append('D'); break;
                case 4:
                    result.Append('E'); break;
                case 5:
                    result.Append('F'); break;
                case 6:
                    result.Append('G'); break;
                case 7:
                    result.Append('H'); break;
                case 8:
                    result.Append('I'); break;
                case 9:
                    result.Append('J'); break;
                case 10:
                    result.Append('K'); break;
                case 11:
                    result.Append('L'); break;
                case 12:
                    result.Append('M'); break;
                case 13:
                    result.Append('N'); break;
                case 14:
                    result.Append('O'); break;
                case 15:
                    result.Append('P'); break;
                case 16:
                    result.Append('Q'); break;
                case 17:
                    result.Append('R'); break;
                case 18:
                    result.Append('S'); break;
                case 19:
                    result.Append('T'); break;
                case 20:
                    result.Append('U'); break;
                case 21:
                    result.Append('V'); break;
                case 22:
                    result.Append('W'); break;
                case 23:
                    result.Append('X'); break;
                case 24:
                    result.Append('Y'); break;
                case 25:
                    result.Append('Z'); break;
                default:
                    result.Append(remainder);
                    break;
            }
            decimalNumber = decimalNumber / 4000000;

            string endNumber4 = result.ToString();
            for (int i = 0; i < endNumber4.Length - 1; i++)
            {
                Console.Write(endNumber4[i]);
            }
        }
    }

    static void ConvertNumberBase10ToD6(int d, long decimalNumber)//метода, който обръща десетичното число е число в бройна система с база d
    {
        long remainder = 0;
        long decimalNumber1 = decimalNumber;
        string endNumber = String.Empty;
        StringBuilder result = new StringBuilder();
        while (decimalNumber != 0)
        {
            switch (decimalNumber / 100000000)
            {
                case 1:
                    result.Append('B'); break;
                case 2:
                    result.Append('C'); break;
                case 3:
                    result.Append('D'); break;
                case 4:
                    result.Append('E'); break;
                case 5:
                    result.Append('F'); break;
                case 6:
                    result.Append('G'); break;
                case 7:
                    result.Append('H'); break;
                case 8:
                    result.Append('I'); break;
                case 9:
                    result.Append('J'); break;
                case 10:
                    result.Append('K'); break;
                case 11:
                    result.Append('L'); break;
                case 12:
                    result.Append('M'); break;
                case 13:
                    result.Append('N'); break;
                case 14:
                    result.Append('O'); break;
                case 15:
                    result.Append('P'); break;
                case 16:
                    result.Append('Q'); break;
                case 17:
                    result.Append('R'); break;
                case 18:
                    result.Append('S'); break;
                case 19:
                    result.Append('T'); break;
                case 20:
                    result.Append('U'); break;
                case 21:
                    result.Append('V'); break;
                case 22:
                    result.Append('W'); break;
                case 23:
                    result.Append('X'); break;
                case 24:
                    result.Append('Y'); break;
                case 25:
                    result.Append('Z'); break;
                default:
                    result.Append(remainder);
                    break;
            }
            decimalNumber = decimalNumber / 100000000;

            string endNumber5 = result.ToString();
            for (int i = 0; i < endNumber5.Length - 1; i++)
            {
                Console.Write(endNumber5[i]);
            }
        }
    }

    static void Main()
    {
        long number = long.Parse(Console.ReadLine());
        int d = 26;
        if (number <= 25)
        {
            ConvertNumberBase10ToD(d, number);
        }
        if ((number > 25)&&( number <=255))
        {
            ConvertNumberBase10ToD1(d, number);
            number = number - (number/26)*26;
            ConvertNumberBase10ToD(d, number);
        }
        if ((number > 255) && (number <= 6655))
        {
            ConvertNumberBase10ToD2(d, number);
            number = number - (number / 256) * 256;
            ConvertNumberBase10ToD1(d, number);
            number = number - (number / 26) * 26;
            ConvertNumberBase10ToD(d, number);
        }
        if ((number > 6655) && (number <= 160255))
        {
            ConvertNumberBase10ToD3(d, number);
            number = number - (number / 6400) * 6400;
            ConvertNumberBase10ToD2(d, number);
            number = number - (number / 256) * 256;
            ConvertNumberBase10ToD1(d, number);
            number = number - (number / 26) * 26;
            ConvertNumberBase10ToD(d, number);
        }
        if ((number > 160256) && (number <= 4000255))
        {
            ConvertNumberBase10ToD4(d, number);
            number = number - (number / 160000) * 160000;
            ConvertNumberBase10ToD3(d, number);
            number = number - (number / 6400) * 6400;
            ConvertNumberBase10ToD2(d, number);
            number = number - (number / 256) * 256;
            ConvertNumberBase10ToD1(d, number);
            number = number - (number / 26) * 26;
            ConvertNumberBase10ToD(d, number);
        }
        if ((number > 4000256) && (number <= 100000255))
        {
            ConvertNumberBase10ToD5(d, number);
            number = number - (number / 4000000) * 4000000;
            ConvertNumberBase10ToD4(d, number);
            number = number - (number / 160000) * 160000;
            ConvertNumberBase10ToD3(d, number);
            number = number - (number / 6400) * 6400;
            ConvertNumberBase10ToD2(d, number);
            number = number - (number / 256) * 256;
            ConvertNumberBase10ToD1(d, number);
            number = number - (number / 26) * 26;
            ConvertNumberBase10ToD(d, number);
        }
        if ((number > 100000255) && (number <= 25000000255))
        {
            ConvertNumberBase10ToD6(d, number);
            number = number - (number / 100000000) * 10000000;
            ConvertNumberBase10ToD5(d, number);
            number = number - (number / 4000000) * 4000000;
            ConvertNumberBase10ToD4(d, number);
            number = number - (number / 160000) * 160000;
            ConvertNumberBase10ToD3(d, number);
            number = number - (number / 6400) * 6400;
            ConvertNumberBase10ToD2(d, number);
            number = number - (number / 256) * 256;
            ConvertNumberBase10ToD1(d, number);
            number = number - (number / 26) * 26;
            ConvertNumberBase10ToD(d, number);
        }
    }
}