using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class RamiTest
{
    
    static void Main()
    {
        BigInteger number = BigInteger.Parse(Console.ReadLine());
        if (number==0)
        {
            Console.WriteLine("A");
            return;
        }
        
            string[] arr = new string[256];
            int index = 0;
            for (char i = 'A'; i <= 'Z'; i++)
            {
                arr[index] = i.ToString();
                index++;
            }
            int counter = 0;
            for (char i = 'a'; i <= 'z'; i++)
            {
                for (char j = 'A'; j <= 'Z'; j++)
                {
                    counter++;
                    if (counter > 230)
                    {
                        break;
                    }
                    arr[index] = i.ToString() + j.ToString();
                    index++;
                }
            }
            List<string> result = new List<string>();
            while (number > 0)
            {
                BigInteger temp = number % 256;
                result.Add(arr[(int)temp]);
                number /= 256;
            }
            int n = result.Count;
            for (int i = n - 1; i >= 0; i--)
            {
                Console.Write(result[i]);
            }
            Console.WriteLine();
    }

}
    