using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.meanstream
{
    class Program
    {
        public static int Lamps(int N)
        {
            bool[] lamps = new bool[N];
            int lastIndex = 0;
            for (int i = 1; i < N; i+=2)
            {
                if (lamps[i] == false)
                {
                    for (int j = i; j < N; j += i + 1)
                    {
                        if (lamps[j]==false)
                        {   
                            lastIndex = j;
                            lamps[j] = true;
                        }
                    }
                }
            }
            return lastIndex+1;
        }

        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            string fistTask = Console.ReadLine();
            string secondTask = Console.ReadLine();
            Console.WriteLine(Lamps(N));
            Console.WriteLine(fistTask+" unbounded ");
            Console.WriteLine(secondTask+" bounded ");

        }
    }
}
