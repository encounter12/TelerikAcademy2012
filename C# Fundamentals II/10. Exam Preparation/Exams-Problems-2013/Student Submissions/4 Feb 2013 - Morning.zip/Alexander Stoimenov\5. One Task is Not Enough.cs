using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Task5
{
    static void Main()
    {
        int number = int.Parse(Console.ReadLine());
        List<int> numbers = new List<int>();
        for (int i = 1; i < number + 1; i++)
        {
            numbers.Add(i);
        }
        for (int i = 0; i < numbers.Count; i++)
        {
            numbers.RemoveAt(i);
        }
        for (int i = 0; i < numbers.Count; i += 2)
        {
            numbers.RemoveAt(i);
        }
        for (int i = 0; i < numbers.Count; i += 3)
        {
            numbers.RemoveAt(i);
        }
        for (int i = 0; i < numbers.Count; i += 4)
        {
            numbers.RemoveAt(i);
        }

        Console.WriteLine(numbers[0]);
    }
}
