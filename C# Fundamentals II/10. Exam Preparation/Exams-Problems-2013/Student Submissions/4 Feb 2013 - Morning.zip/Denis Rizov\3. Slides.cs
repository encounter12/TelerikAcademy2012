using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Cuboid
{
    static bool BallStuck(int w, int d)
    {
        if (w < 0 || w >= width)
        {
            return true;
        }
        if (d < 0 || d >= depth)
        {
            return true;
        }

        return false;
    }

    static int width;
    static int height;
    static int depth;

    static void Main(string[] args)
    {
        string[] dimentions = Console.ReadLine().Split();
        width = int.Parse(dimentions[0]);
        height = int.Parse(dimentions[1]);
        depth = int.Parse(dimentions[2]);

        string[, ,] cuboid = new string[width, height, depth];

        for (int h = 0; h < height; h++)
        {
            string line = Console.ReadLine();
            string[] sequences = line.Split(new string[] { " | " }, StringSplitOptions.RemoveEmptyEntries);

            for (int d = 0; d < depth; d++)
            {
                string[] rules = sequences[d].Split(new char[] { ')', '(' }, StringSplitOptions.RemoveEmptyEntries);

                for (int w = 0; w < width; w++)
                {
                    cuboid[w, h, d] = rules[w];
                }
            }
        }

        string[] ballCoordinates = Console.ReadLine().Split();
        int ballWidth = int.Parse(ballCoordinates[0]);
        int ballDepth = int.Parse(ballCoordinates[1]);

        bool exitReached = false;
        bool stuck = false;
        int lastWidth = 0;
        int lastHeight = 0;
        int lastDepth = 0;
        int level = 0;

        string rule;

        while (true)
        {
            rule = cuboid[ballWidth, level, ballDepth];

            if (rule.Length == 1)
            {
                if (rule == "E")
                {
                    lastWidth = ballWidth;
                    lastHeight = level;
                    lastDepth = ballDepth;
                    level++;

                    if (level >= height)
                    {
                        exitReached = true;
                        break;
                    }
                }
                if (rule == "B")
                {
                    lastWidth = ballWidth;
                    lastHeight = level;
                    lastDepth = ballDepth;

                    stuck = true;
                    break;
                }
            }
            else
            {
                string[] subString = rule.Split();

                if (subString[0] == "S")
                {
                    if (subString[1] == "L")
                    {
                        lastWidth = ballWidth;
                        lastHeight = level;
                        lastDepth = ballDepth;
                        level++;
                        ballWidth--;

                        if (level >= height)
                        {
                            exitReached = true;
                            break;
                        }
                        if (BallStuck(ballWidth, ballDepth))
                        {
                            stuck = true;
                            break;
                        }
                    }
                    else if (subString[1] == "R")
                    {
                        lastWidth = ballWidth;
                        lastHeight = level;
                        lastDepth = ballDepth;
                        level++;
                        ballWidth++;

                        if (level >= height)
                        {
                            exitReached = true;
                            break;
                        }
                        if (BallStuck(ballWidth, ballDepth))
                        {
                            stuck = true;
                            break;
                        }
                    }
                    else if (subString[1] == "F")
                    {
                        lastWidth = ballWidth;
                        lastHeight = level;
                        lastDepth = ballDepth;
                        level++;
                        ballDepth--;

                        if (level >= height)
                        {
                            exitReached = true;
                            break;
                        }
                        if (BallStuck(ballWidth, ballDepth))
                        {
                            stuck = true;
                            break;
                        }
                    }
                    else if (subString[1] == "B")
                    {
                        lastWidth = ballWidth;
                        lastHeight = level;
                        lastDepth = ballDepth;
                        level++;
                        ballDepth++;

                        if (level >= height)
                        {
                            exitReached = true;
                            break;
                        }
                        if (BallStuck(ballWidth, ballDepth))
                        {
                            stuck = true;
                            break;
                        }
                    }
                    else if (subString[1] == "FL")
                    {
                        lastWidth = ballWidth;
                        lastHeight = level;
                        lastDepth = ballDepth;
                        level++;
                        ballWidth--;
                        ballDepth--;

                        if (level >= height)
                        {
                            exitReached = true;
                            break;
                        }
                        if (BallStuck(ballWidth, ballDepth))
                        {
                            stuck = true;
                            break;
                        }
                    }
                    else if (subString[1] == "FR")
                    {
                        lastWidth = ballWidth;
                        lastHeight = level;
                        lastDepth = ballDepth;
                        level++;
                        ballWidth++;
                        ballDepth--;

                        if (level >= height)
                        {
                            exitReached = true;
                            break;
                        }
                        if (BallStuck(ballWidth, ballDepth))
                        {
                            stuck = true;
                            break;
                        }
                    }
                    else if (subString[1] == "BL")
                    {
                        lastWidth = ballWidth;
                        lastHeight = level;
                        lastDepth = ballDepth;
                        level++;
                        ballWidth--;
                        ballDepth++;

                        if (level >= height)
                        {
                            exitReached = true;
                            break;
                        }
                        else if (BallStuck(ballWidth, ballDepth))
                        {
                            stuck = true;
                            break;
                        }
                    }

                    else if (subString[1] == "BR")
                    {
                        lastWidth = ballWidth;
                        lastHeight = level;
                        lastDepth = ballDepth;
                        level++;
                        ballWidth++;
                        ballDepth++;

                        if (level >= height)
                        {
                            exitReached = true;
                            break;
                        }
                        if (BallStuck(ballWidth, ballDepth))
                        {
                            stuck = true;
                            break;
                        }
                    }
                }
                else if (subString[0] == "T")
                {
                    ballWidth = int.Parse(subString[1]);
                    ballDepth = int.Parse(subString[2]);

                    if (BallStuck(ballWidth, ballDepth))
                    {
                        stuck = true;
                        break;
                    }
                }
            }
        }

        if (exitReached == true)
        {
            Console.WriteLine("Yes");
            Console.WriteLine("{0} {1} {2}", lastWidth, lastHeight, lastDepth);
        }
        else if (stuck == true)
        {
            Console.WriteLine("No");
            Console.WriteLine("{0} {1} {2}", lastWidth, lastHeight, lastDepth);
        }
    }
}