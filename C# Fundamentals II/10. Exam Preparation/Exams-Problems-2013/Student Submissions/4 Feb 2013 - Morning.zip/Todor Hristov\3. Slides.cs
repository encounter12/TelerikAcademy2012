using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace Stars3d {
    class Program {
        static int W, H, D;
        static bool ok(int w, int h, int d) {
            return w >= 0 && w < W && h >= 0 && h < H && d >= 0 && d < D;
        }
        static void Main(string[] args) {
            string[] input = Console.ReadLine().Split(' ');
            W = int.Parse(input[0]);
            H = int.Parse(input[1]);
            D = int.Parse(input[2]);
 
            char[, ,] cube = new char[W, H, D];
 
            for (int h = 0; h < H; h++) {
                input = Console.ReadLine().Split(' ');
                for (int d = 0; d < D; d++) {
                    for (int w = 0; w < W; w++) {
                        cube[w, h, d] = input[d][w];
                    }
                }
            }
 
            int[] dw = { -1, 1, 0, 0, 0, 0 };
            int[] dh = { 0, 0, -1, 1, 0, 0 };
            int[] dd = { 0, 0, 0, 0, -1, 1 };
 
            SortedDictionary<char, int> res = new SortedDictionary<char, int>();
 
            for(int w=0;w<W;w++)
                for(int h=0;h<H;h++)
                    for (int d = 0; d < D; d++) {
                        char c = cube[w, h, d];
                        bool cok = true;
                        for (int i = 0; i < 6; i++) {
                            int nw = w + dw[i];
                            int nh = h + dh[i];
                            int nd = d + dd[i];
                            if (!ok(nw, nh, nd) || cube[nw, nh, nd] != c) {
                                cok = false;
                                break;
                            }
                        }
                        if (cok) {
                            if (!res.ContainsKey(c)) res.Add(c, 0);
                            res[c]++;
                        }
                    }
 
            int sum = 0;
 
            foreach (KeyValuePair<char, int> p in res) {
                sum += p.Value;
            }
            Console.WriteLine(sum);
            foreach (KeyValuePair<char, int> p in res) {
                Console.WriteLine("{0} {1}", p.Key, p.Value);
            }
        }
    }
}