using System;
using System.Text;

class KaspichanNumbers
{
    static readonly ushort systemBase = 256;

    static void Main(string[] args)
    {
        ulong number = ulong.Parse(Console.ReadLine());
        StringBuilder result = new StringBuilder();
        ulong temp = number;

        while (temp != 0)
        {
            ulong remainder = temp % systemBase;
            if (remainder != 0)
            {
                result.Append(ConvertToKaspichanNumber(temp % systemBase));
            }
            else
            {
                result.Append("A");
            }
            temp /= systemBase;
        }
        
        if (number == 0)
        {
            Console.WriteLine("A");
        }
        else
        {
            Console.WriteLine(ReverseString(result));
        }
    }

    private static string ConvertToKaspichanNumber(ulong decimalNumber)
    {
        if ((decimalNumber + 1) > 26)
        {
            char last = (char)(((decimalNumber + 1) % 26) + 64);
            char first = (char)(((decimalNumber + 1) / 26) + 96);
            if (((decimalNumber + 1) % 26) == 0)
            {
                last = 'Z';
                first--;
            }
            return last.ToString() + first.ToString();
        }
        else
        {
            char last = (char)(((decimalNumber + 1) % 26) + 64);
            if (last == '@')
            {
                last = 'Z';
            }
            return last.ToString();
        }
    }

    static string ReverseString(StringBuilder str)
    {
        char[] arr = (str.ToString()).ToCharArray();
        Array.Reverse(arr);

        return new string(arr);
    }
}