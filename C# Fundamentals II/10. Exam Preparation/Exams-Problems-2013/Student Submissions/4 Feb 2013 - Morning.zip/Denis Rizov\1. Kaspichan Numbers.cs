using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class KaspichanNumbers
{
    static void Main(string[] args)
    {
        List<string> digits = new List<string>();
        for (int i = 'A'; i <= 'Z'; i++)
        {
            digits.Add(((char)i).ToString());
        }

        int count = 0;
        for (int i = 'a'; i <= 'i'; i++)
        {
            for (int j = 'A'; j <= 'Z' && count < 230; j++)
            {
                digits.Add(((char)i).ToString() + ((char)j).ToString());
                count++;
            }
        }

        ulong number = ulong.Parse(Console.ReadLine());

        if (number >=0 && number <= 255)
        {
            Console.WriteLine(digits[(int)number]);
            return;
        }

        string kasp = "";

        while (number != 0)
        {
            kasp = digits[(int)(number % 256)] + kasp;
            number = number / 256;
        }

        Console.WriteLine(kasp);
    }
}