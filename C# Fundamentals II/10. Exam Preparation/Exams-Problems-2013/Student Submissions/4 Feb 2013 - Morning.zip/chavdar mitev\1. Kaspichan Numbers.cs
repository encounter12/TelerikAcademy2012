using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace izpit
{
    class Program
    {
        static void Main(string[] args)
        {
            // string kas;
            var number = long.Parse(Console.ReadLine());
            long first = 0;
            long second = 0;
            long third = 0;
            if ((number < 26))
            {
                first = (number % 26) + 65;
                Console.WriteLine((char)first);
            }
                
            if ((number < 256)&&(number>25))
            {
                first = (number % 26) + 65;
                second = (number / 26) + 96;
                Console.WriteLine((char)second + "" + (char)first);
            }
            if((number < 512)&&(number >256))
            {
                first = (number % 256) + 65;
                second = (number / 256) + 65;
                Console.WriteLine((char)second + "" + (char)first);
            }
            if(number > 512)
            {
                first = ((number % 256)%26) + 65;
                second =( (number % 256)/26) + 96;
                third = (number / 256) + 65;
                Console.WriteLine((char)third + "" +(char)second + "" + (char)first);
            }

            

        }
    }
}
