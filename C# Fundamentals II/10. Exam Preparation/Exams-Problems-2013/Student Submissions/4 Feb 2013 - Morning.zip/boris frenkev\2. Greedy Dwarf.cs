using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void PrintList(List<int> list)
    {
        foreach (var item in list)
        {
            Console.Write(item);
        }
    }
    static int[] GetNumbers(string str)
    {
        char[] separators = new char[] { ' ',',' };
        string[] numbers = str.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        int[] result = new int[numbers.Length];
        for (int i = 0; i < result.Length; i++)
        {
            result[i] = int.Parse(numbers[i]);
        }
        return result;
    }
    static int GetCurrentSum(int[] pattern, int[] arr)
    {
        int sum = arr[0];
        int petLen = pattern.Length;
        bool[] visited = new bool[arr.Length];
        visited[0]=true;
        int index = -1;

        int indArr = 0;
        while (true)
        {
            index = (index + 1) % petLen;
            indArr = indArr + pattern[index];
            if ((indArr < 0) || (indArr > arr.Length - 1)) 
            {
                break;
            }
            if (visited[indArr])
            {
                break;
            }
            visited[indArr] = true;
            sum = sum + arr[indArr];
        }
        return sum;
    }

    static void Main(string[] args)
    {


        string line = Console.ReadLine();
        int[] arr = GetNumbers(line);
        int m = int.Parse(Console.ReadLine());
        int max = 0;
        bool isSet = false;
        for (int i = 0; i < m; i++)
        {
            line = Console.ReadLine();
            int[] pattern = GetNumbers(line);
            if (!isSet)
            {
                max = GetCurrentSum(pattern, arr);
                isSet = true;
                continue;
            }
            int current = GetCurrentSum(pattern, arr);
            if (current > max)
            {
                max = current;
            }
        }
        Console.WriteLine(max);
    }
}