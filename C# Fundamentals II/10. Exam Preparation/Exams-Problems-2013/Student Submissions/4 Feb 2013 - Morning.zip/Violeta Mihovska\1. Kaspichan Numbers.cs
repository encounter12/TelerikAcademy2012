public String ConvertToBase(int num, int nbase)
{
    String chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    // check if we can convert to another base
    if(nbase < 2 || nbase > chars.Length)
        return "";

    int r;
    String newNumber = "";

    // in r we have the offset of the char that was converted to the new base
    while(num >= nbase)
    {
        r = num % nbase;
        newNumber = chars[r] + newNumber;
        num = num / nbase;
    }
    // the last number to convert
    newNumber = chars[num] + newNumber;

    return newNumber;
}
