using System;
using System.Collections.Generic;

/*
 * 2.  Greedy Dwarf
 */
class Program
{
    // gets coins from valley by given pattern
    static int getCoinsFromvalley(int[] patterns, int[] valley)
    {
        int coinsCollected = valley[0];
        int valleyIndex = 0;
        int patternsIndex = 0;
        // hold visited valley indexes
        List<int> visitedValleyIndexes = new List<int>();
        //visitedValleyIndexes.Add(0);


        while (true)
        {
            valleyIndex += patterns[patternsIndex];
            if (visitedValleyIndexes.Contains(valleyIndex)
                || valleyIndex >= valley.Length
                || valleyIndex < 1)
            {
                break;
            }
            visitedValleyIndexes.Add(valleyIndex);
            coinsCollected += valley[valleyIndex];
            if (patternsIndex >= patterns.Length-1)
            {
                patternsIndex = 0;
            }
            else
            {
                patternsIndex++;
            }
        }

        return coinsCollected;
    }

    // main
    static void Main()
    {
        /* input */

        // get valley
        string[] valleyStr = Console.ReadLine().Split(',');
        int[] valley = new int[valleyStr.Length];

        for (int i = 0; i < valleyStr.Length; i++)
        {
            valley[i] = int.Parse(valleyStr[i]);
        }

        // get patterns
        int numberOfPatterns = int.Parse(Console.ReadLine());
        string[][] patternsStrArr = new string[numberOfPatterns][];

        for (int i = 0; i < numberOfPatterns; i++)
        {
            patternsStrArr[i] = Console.ReadLine().Split(',');
        }

        int[][] patterns = new int[numberOfPatterns][];
        for (int i = 0; i < numberOfPatterns; i++)
        {
            patterns[i] = new int[patternsStrArr[i].Length];
            for (int j = 0; j < patternsStrArr[i].Length; j++)
            {
                patterns[i][j] = int.Parse(patternsStrArr[i][j]);
            }
        }

        // do the job
        int maxCoins = 0;

        for (int i = 0; i < patterns.Length; i++)
        {
            int[] currentPattern = patterns[i];
            int coinsFromValley = getCoinsFromvalley(currentPattern, valley);
            //Console.WriteLine(coinsFromValley);
            if (maxCoins < coinsFromValley)
            {
                maxCoins = coinsFromValley;
            }
        }

        Console.WriteLine(maxCoins);
    }
}