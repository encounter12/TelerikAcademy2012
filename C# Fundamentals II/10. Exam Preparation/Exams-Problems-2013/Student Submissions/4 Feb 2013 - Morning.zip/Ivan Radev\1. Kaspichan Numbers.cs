using System;
using System.Text;

class KaspichanNumbers
{
    static void Main()
    {
        ulong number = ulong.Parse(Console.ReadLine());

        string[] digits = new string[256];
        for (int index = 0; index < 26; index++)
            digits[index] = ((char)('A' + index)).ToString();
        for (int index = 26; index < digits.Length; index++)
            digits[index] = (char)('a' - 1 + index / 26) + "" + (char)('A' + index % 26);


        int size = 1;
        ulong reminder = number;
        while (true)
        {
            if (reminder / 256 == 0) break;
            else
            {
                reminder /= 256;
                size++;
            }
        }

        StringBuilder result = new StringBuilder();

        for (int digit = 0; digit < size; digit++)
        {
            ulong curNumber = number % 256;
            result.Insert(0, digits[curNumber]);
            number = (number / 256);
        }
        Console.WriteLine(result);
    }
}