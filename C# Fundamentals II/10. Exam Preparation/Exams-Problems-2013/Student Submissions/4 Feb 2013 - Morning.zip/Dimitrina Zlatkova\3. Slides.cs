using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Slides
{
    class Slides
    {
        static void SplitWidth(string[,,] cuboid, int h, int d, string str)
        {
            int index = 1;
            int width = 0;
            while (index<str.Length)
            {
                if (str[index-1]=='(')
                {
                    while (str[index]!=')')
                    {
                        cuboid[h, d, width] += str[index];
                        index++;
                    }
                    width++;
                }
                else
                {
                    index++;
                }
            }
        }

        static void Main(string[] args)
        {


            string diment = Console.ReadLine();
            string[] dimentArr = diment.Split(' ');
            int h = int.Parse(dimentArr[0]);
            int d = int.Parse(dimentArr[1]);
            int w = int.Parse(dimentArr[2]);
            string[, ,] cuboid = new string[h, d, w];
            for (int i = 0; i < h; i++)
            {
                string line = Console.ReadLine();
                string[] lineArr = line.Split(new string[] { " | " }, StringSplitOptions.RemoveEmptyEntries);
                for (int j = 0; j < d; j++)
                {
                    SplitWidth(cuboid, i, j, lineArr[j]);
                }
            }

            string start = Console.ReadLine();
            string[] startArr = start.Split(' ');
            int ballW = int.Parse(startArr[0]);
            int ballD = int.Parse(startArr[1]);
            int ballH = 0;

            bool isStuck = false;
            bool hasExit = false;
            while (!isStuck && !hasExit)
            {
                if (ballD < 0 || ballD >= d || ballW < 0 || ballW >= w || ballH < 0 || ballH >= h)
                {
                    isStuck = true;
                }
                else if (ballH == h - 1)
                {
                    hasExit = true;
                }
                else
                {
                    string position = cuboid[ballH, ballD, ballW];
                    if (position.StartsWith("B"))
                    {
                        isStuck = true;
                    }
                    else if (position.StartsWith("E"))
                    {
                        ballH++;
                    }
                    else if (position.StartsWith("T"))
                    {
                        string[] coord = position.Split(' ');
                        ballW = int.Parse(coord[1]);
                        ballD = int.Parse(coord[2]);
                    }
                    else
                    {
                        if (position.EndsWith("BL"))
                        {
                            ballD++;
                            ballH++;
                            ballW--;
                        }
                        else if (position.EndsWith("FL"))
                        {
                            ballD--;
                            ballH++;
                            ballW--;
                        }
                        else if (position.EndsWith("L"))
                        {
                            ballW--;
                        }
                        else if (position.EndsWith("FR"))
                        {
                            ballD--;
                            ballH++;
                            ballW++;
                        }
                        else if (position.EndsWith("BR"))
                        {
                            ballD++;
                            ballH++;
                            ballW++;
                        }
                        else if (position.EndsWith("R"))
                        {
                            ballW++;
                        }
                        else if (position.EndsWith("B"))
                        {
                            ballD++;
                        }
                        else if (position.EndsWith("F"))
                        {
                            ballD--;
                        }
                    }
                }
            }

            Console.WriteLine(hasExit);
            //for (int i = 0; i < h; i++)
            //{
            //    for (int j = 0; j < d; j++)
            //    {
            //        for (int k = 0; k < w; k++)
            //        {
            //            Console.Write(cuboid[i,j,k]);
            //            Console.Write('*');
            //        }
            //        Console.WriteLine();
            //    }
            //    Console.WriteLine();
            //}

        }
    }
}
