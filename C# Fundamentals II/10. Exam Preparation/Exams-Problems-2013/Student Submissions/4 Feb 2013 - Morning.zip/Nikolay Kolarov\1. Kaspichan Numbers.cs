using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;

class Kaspichan
{
    static void Main()
    {
        BigInteger n = BigInteger.Parse(Console.ReadLine());

        if (n==0)
        {
            Console.WriteLine('A');
            return ;
        }

        List<BigInteger> reminders = new List<BigInteger>();
        StringBuilder result = new StringBuilder();

        while (n > 0)
        {
            reminders.Add(n % 256);
            n = n / 256;
        }
        for (int i = reminders.Count - 1; i >= 0; i--)
        {
            {
               // Console.WriteLine((int)((char)(reminders[i] % 26 + (int)'A')));
                result.Append(((char)(reminders[i] / 26 + (int)'a' - 1) != (char)96 ? ((char)(reminders[i] / 26 + (int)'a' - 1)).ToString() : "") + "" + (char)(reminders[i] % 26 + (int)'A'));
            }
        }

        Console.WriteLine(result.ToString().Trim());

    }
}
