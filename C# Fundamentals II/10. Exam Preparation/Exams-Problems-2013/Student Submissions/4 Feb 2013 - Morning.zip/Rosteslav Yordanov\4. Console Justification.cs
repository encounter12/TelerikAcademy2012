using System;
using System.Collections.Generic;
using System.Text;

class Program
{
    static void Main()
    {
        int linesNum = int.Parse(Console.ReadLine());
        int charLimit = int.Parse(Console.ReadLine());
        string[] lines = new string[linesNum];
        for (int i = 0; i < linesNum; i++)
        {
            lines[i] = Console.ReadLine();
        }
        List<string> words = new List<string>();
        foreach (string line in lines)
	    {
		    words.AddRange(line.Split(new char[] {' '},StringSplitOptions.RemoveEmptyEntries));
	    }
        int index = 0;
        int countSize = 0;
        int countWords = 0;
        StringBuilder sb = new StringBuilder();
        while (index < words.Count)
        {
            countSize += words[index].Length;
            countWords++;
            if (countSize + (countWords - 1) > charLimit)
            {
                countSize -= words[index].Length;
                countWords--;
                if (countWords == 1)
                {
                    Console.WriteLine(words[index-1]);
                }
                else
                {
                    int intervalsNeeded = charLimit - countSize;
                    int commanInterval = intervalsNeeded / (countWords-1);
                    int remeiningInterval = intervalsNeeded % (countWords - 1);
                    for (int i = index-countWords ; i < index ; i++)
                    {
                        sb.Append(words[i]);
                        if (i!=index-1)
                        {
                            string intervals = new string(' ', commanInterval);
                            sb.Append(intervals);
                            if (i < index - countWords + remeiningInterval)
                            {
                                sb.Append(' ');
                            }
                        }
                    }
                    Console.WriteLine(sb.ToString());
                }
                countSize = 0;
                countWords = 0;
                index--;
                sb.Clear();
            }
            else if (index == words.Count - 1)
            {
                if (countWords == 1)
                {
                    Console.WriteLine(words[index]);
                }
                else
                {
                    int intervalsNeeded = charLimit - countSize;
                    int commanInterval = intervalsNeeded / (countWords - 1);
                    int remeiningInterval = intervalsNeeded % (countWords - 1);
                    for (int i = index - countWords +1 ; i <= index; i++)
                    {
                        sb.Append(words[i]);
                        if (i != index)
                        {
                            string intervals = new string(' ', commanInterval);
                            sb.Append(intervals);
                            if (i < index - countWords + remeiningInterval + 1)
                            {
                                sb.Append(' ');
                            }
                        }
                    }
                    Console.WriteLine(sb.ToString());
                }
            }
            index++;
        }
    }
}