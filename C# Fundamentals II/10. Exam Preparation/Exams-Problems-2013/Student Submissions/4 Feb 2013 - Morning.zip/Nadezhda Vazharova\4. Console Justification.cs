using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Ex1
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int W = int.Parse(Console.ReadLine());
            StringBuilder text = new StringBuilder();
            for (int i = 0; i < N; i++)
            {
                text.Append(Console.ReadLine() + " ");
            }
            string inputText = text.ToString();
            string patSpaces = @"\s+";
            inputText = Regex.Replace(inputText, patSpaces, " ");

            

            
            int startIndex = 0;

            
                Func(inputText, W, startIndex);    
                
            

            
            for (int i = 0; i < result.Count; i++)
            {
                Console.WriteLine(result[i].PadRight(W));
            }




        }

        static List<string> result = new List<string>();

        static void Func(string inputText, int W, int startIndex)
        {
            while (startIndex<inputText.Length-W)
            {            
                if (inputText.Substring(startIndex, W + 1).LastIndexOf(' ') != -1)
                {
                    result.Add(inputText.Substring(startIndex, W));
                    startIndex = startIndex + W;
                }
                else
                {
                    Func(inputText, W - 1, startIndex);
                }
            }
        }
    }
}

