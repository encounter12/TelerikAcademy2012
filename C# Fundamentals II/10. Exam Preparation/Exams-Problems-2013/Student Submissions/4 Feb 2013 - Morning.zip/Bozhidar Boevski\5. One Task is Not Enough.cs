using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace OneTaskIsNotEnough
{
    class Program
    {
        static void Main(string[] args)
        {
            string cInput;
            string firstComm;
            string secondComm;
            int firstTask;

            cInput = Console.ReadLine();
            firstTask = Convert.ToInt32(cInput);
            firstComm = Console.ReadLine();
            secondComm = Console.ReadLine();

            FirstTask(firstTask);
            SecondTask(firstComm, secondComm);

        }
        static void FirstTask(int n)
        {
            int[] arr = new int[n];
            int temp = 1;
            int step = 2;
            int tempStep = 2;

            for (int i = 0; i < (n - 1) / 2; i++)
            {
                if (arr[i] == 1)
                {
                    continue;
                }
                arr[0] = 1;
                step = tempStep;
                for (int j = 0; j < arr.Length; j++)
                {
                    if (j == step)
                    {
                        arr[j] = 1;
                        temp = j;
                        step += step;
                    }

                }
                tempStep++;
            }

            Console.WriteLine(temp);
        }
        static void SecondTask(string firstCommands, string secondCommands)
        {
            int countR = 0;
            int countL = 0;

            countR = Regex.Matches(firstCommands, "R").Count;
            countL = Regex.Matches(firstCommands, "L").Count;

            if (countR - countL == 0)
            {
                Console.WriteLine("unbounded");
            }
            else
            {
                Console.WriteLine("bounded");
            }

            countR = Regex.Matches(secondCommands, "R").Count;
            countL = Regex.Matches(secondCommands, "L").Count;

            if (countR - countL == 0)
            {
                Console.WriteLine("unbounded");
            }
            else
            {
                Console.WriteLine("bounded");
            }
        }
    }
}
