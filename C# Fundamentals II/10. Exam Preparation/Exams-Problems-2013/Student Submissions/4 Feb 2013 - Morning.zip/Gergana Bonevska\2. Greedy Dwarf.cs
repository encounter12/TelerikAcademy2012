using System;


namespace GreedyDwarf
{
    class GreedyDwarf
    {
        static void Main()
        {
            string valeyStr = Console.ReadLine();
            valeyStr = valeyStr.Trim();
            string[] valey = valeyStr.Split(',');

            int mNumbersPatterns = int.Parse(Console.ReadLine());
            int maxCoins = 0;

            for (int i = 0; i < mNumbersPatterns; i++)
            {
                //read patterns
                string patternsStr = Console.ReadLine();
                patternsStr = patternsStr.Trim();
                string[] currentPattern = patternsStr.Split(',');
                int[] currentPatternInt = new int[currentPattern.Length];
                for (int j = 0; j < currentPattern.Length; j++)
                {
                    currentPatternInt[j] = int.Parse(currentPattern[j]);
                }


                int currentCoins = GetMaxCoins(currentPatternInt, valey);
                if (currentCoins > maxCoins)
                {
                    maxCoins = currentCoins;
                }
            }

            Console.WriteLine(maxCoins);

        }

        private static int GetMaxCoins(int[] pattern, string[] valey)
        {
            int[] valeyTemp = new int [valey.Length];
            for (int i = 0; i < valeyTemp.Length; i++)
			{
                valeyTemp[i] = int.Parse(valey[i]);
			}

            int collected = int.Parse(valey[0]);
            int step = 0;
            int stepOfPattern = 0;
            int j = 0;

            while (true)
            {
                if (j < pattern.Length)
                {
                    stepOfPattern = pattern[j];
                    step += stepOfPattern;
                    if ((step < valeyTemp.Length && step > 0) && valeyTemp[step] != 0) //|| (j > 0 && j < pattern.Length)
                    {
                        collected += valeyTemp[step];
                        valeyTemp[step] = 0;
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    if (step < valeyTemp.Length || step > 0)
                    {
                        j = -1;
                    }
                }

                if (step == valeyTemp.Length - 1 || step == 0)
                {
                    break;
                }

                j++;
            }
            return collected;           
        }
    }
}
