using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OneTask
{
    class Program
    {
        static void Main(string[] args)
        {

            int lastVisit=0;
            int number;
            number = int.Parse(Console.ReadLine());
            bool[] on = new bool[number];
            int count, capacity;
            int [] lamps = new int [number];


            lastVisit = Lamps(lastVisit, on, lamps);

            string input = Console.ReadLine();
            char [] str = input.ToCharArray();

        }

        private static int Lamps(int lastVisit, bool[] on, int[] lamps)
        {
            for (int i = 0; i < lamps.Length; i++)
            {
                lamps[i] = i + 1;
            }
            for (int i = 0; i < lamps.Length; i++)
            {
                for (int k = i; k < lamps.Length; k++)
                {

                    if (lamps[k] != lamps[i] && lamps[k] % lamps[i] != 0)
                    {
                        on[i] = true;
                        lastVisit = i;
                    }
                }
            }
            Console.WriteLine(lastVisit);
            return lastVisit;
        }
    }
}