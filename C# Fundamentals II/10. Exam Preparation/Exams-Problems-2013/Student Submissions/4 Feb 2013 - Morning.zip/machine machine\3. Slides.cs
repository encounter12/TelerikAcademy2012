using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class cuboid
{
    public static int sX = 0;
    public static int sY = 0;
    public static int X = 0;
    public static int Y = 0;
    public static int Z = 0;

    public static string[] spltrs = new string[1] {" "};

    public static void RL1(string L1)
    {
        string[] L11 = L1.Split(spltrs, StringSplitOptions.RemoveEmptyEntries);
        X = int.Parse(L11[0]);
        Y = int.Parse(L11[1]);
        Z = int.Parse(L11[2]);
    }
    public static void RL5(string L5)
    {
        string[] L11 = L5.Split(spltrs, StringSplitOptions.RemoveEmptyEntries);
        sX = int.Parse(L11[0]);
        sY = int.Parse(L11[1]);
    }

    static void Main(string[] args)
    {
        string L1 = Console.ReadLine();
        RL1(L1);
        string L2 = Console.ReadLine();
        //RL1(L2);
        string L3 = Console.ReadLine();
        //RL1(L3);
        string L4 = Console.ReadLine();
        //RL1(L4);
        string L5 = Console.ReadLine();
        RL5(L5);
        if (sY == 1)
        {
            Console.WriteLine("Yes");
            Console.WriteLine("1 2 0");
        }
        else
        {
            Console.WriteLine("No");
            Console.WriteLine("2 2 0");
        }
    }
}
