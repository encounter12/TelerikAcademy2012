using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class dwarfs
{
    static void Main()
    {
        int[] valley = { 1, 3, -6, 7, 4, 1, 12 };
        int[] pattern = { 1, 3, -2 };
        int coins = 0;
        coins += valley[0];
        coins += valley[0 + pattern[0]];
        coins += valley[0 + pattern[0] + pattern[1]];
        coins += valley[0 + pattern[0] + pattern[1] + pattern[2]];
        coins += valley[0 + pattern[0] + pattern[1] + pattern[2] + pattern[0]];
        coins += valley[0 + pattern[0] + pattern[1] + pattern[2] + pattern[0] + pattern[1]];
        Console.WriteLine(coins);
    }
}