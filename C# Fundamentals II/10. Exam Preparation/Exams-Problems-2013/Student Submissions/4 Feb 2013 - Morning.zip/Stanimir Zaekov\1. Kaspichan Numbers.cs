using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Problem_1
{
    static string GetSymbols(ulong dividend)
    {
        string result = String.Empty;
        ulong modulo;

        while (dividend > 0)
        {
            modulo = dividend % 26;
            if (result.Length > 0)
                result = Convert.ToChar(96 + modulo).ToString() + result;
            else
                result = Convert.ToChar(65 + modulo).ToString() + result;
            dividend = (dividend - modulo) / 26;
        }

        return result;
    }

    static void Main()
    {

        ulong dividend = ulong.Parse(Console.ReadLine());
        ulong remainder = 0;
        ulong decNumber = dividend;
        string result = string.Empty;
        string resultTotal = string.Empty;

        while (true)
        {
            remainder = decNumber % 256;
            result = GetSymbols(remainder);
            resultTotal = result + resultTotal;
            decNumber = decNumber / 256;
            if (decNumber == 0) break;
        }

        char[] display = resultTotal.ToCharArray();
        Console.WriteLine(display);

    }
}
