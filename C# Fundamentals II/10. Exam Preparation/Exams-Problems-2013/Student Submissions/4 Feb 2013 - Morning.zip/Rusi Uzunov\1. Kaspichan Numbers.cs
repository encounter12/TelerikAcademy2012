using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        int m = int.Parse(Console.ReadLine());
        string x =(Number2String(m,false));
        x=x.ToUpper();
        Console.WriteLine(x);
    }
    public static String Number2String(int number, bool isCaps)
    {
        Char c = (Char)((isCaps ? 65 : 97) + (number));
        return c.ToString();
    }
}
