using System;

class ConsoleJustification
{
    static void Main()
    {
        Console.WriteLine("test");
    }
}
