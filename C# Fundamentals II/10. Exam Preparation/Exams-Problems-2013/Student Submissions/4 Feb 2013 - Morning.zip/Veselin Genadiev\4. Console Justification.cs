using System;
using System.Text;
using System.Text.RegularExpressions;

namespace ConsoleJustification
{
	class ConsoleJustification
	{
		static void Main(string[] args)
		{
			int n = int.Parse(Console.ReadLine());
			int m = int.Parse(Console.ReadLine());
			string[] list = new string[n];
			for (int i = 0; i < n; i++)
			{
				list[i] = Console.ReadLine();
			}
			Regex words = new Regex(@"\W+");
			string[][] mywords={};
			for (int i = 0; i < n; i++)
			{
				mywords[i] = words.Split(list[i]);
			}
			Regex whiteSpaces = new Regex(@"\w+");
			int gapcount = 0;
			for (int i = 0; i < n; i++)
			{
				gapcount += whiteSpaces.Split(list[i]).Length;
			}
			StringBuilder[] lines = new StringBuilder[n];
			int j = 0;
			for (int i = 0; i < mywords.GetLength(0); i++)
			{
				if (lines.Length + mywords[i].Length + 1 <= m)
				{
					lines[j].Append(mywords[i] + " ");
				}
				else
				{
					lines[j].Remove(lines[i].Length - 1, 1);
					j++;
				}
			}
			for (int i = 0; i < lines.GetLength(0); i++)
			{
				int h = lines[i].Length - 1;
				while (lines[i].Length < m)
				{
					if (h == 0)
					{
						h = lines[i].Length - 1;
					}
					if (lines[i][h] == ' ')
					{
						lines[i].Insert(h, " ");
					}
					h--;
				}
			}
		}
	}
}