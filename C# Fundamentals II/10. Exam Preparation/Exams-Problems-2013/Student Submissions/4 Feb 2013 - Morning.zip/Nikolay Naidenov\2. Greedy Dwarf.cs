using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class GreedyDwarf
    {
        static void Main(string[] args)
        {
            string inputNum = Console.ReadLine();
            int numPatterns = int.Parse(Console.ReadLine());
            List<string> patterns = new List<string>();
            int[] maxCoins = new int[numPatterns];
            int coins = 0;

            string[] sepInput = inputNum.Split(',');
            int[] numbers = new int[sepInput.Length];
            

            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = Convert.ToInt32(sepInput[i]);
            }

            for (int i = 0; i < numPatterns; i++)
            {
                patterns.Add(Console.ReadLine());
            }
            
            //Use every One pattern
            for (int i = 0; i < patterns.Count; i++)
            {
                
                string[] patternStr = patterns[i].Split(',');
                int[] patternInt = new int[patternStr.Length];
                for (int j = 0; j < patternInt.Length; j++)
                {
                    patternInt[j] = Convert.ToInt32(patternStr[j]);
                }

                coins = 0;
                int position = 0;
                int patternPos = 0;
                bool[] isGoHere = new bool[numbers.Length];
                while (true)
                {
                    
                    if (position >= 0 && position < numbers.Length)
                    {
                        if (patternPos >= patternInt.Length)
                        {
                            patternPos = 0;
                        }
                        if (isGoHere[position] == true)
                        {
                            maxCoins[i] = coins;
                            break;
                        }
                        else
                        {
                            isGoHere[position] = true;
                            coins += numbers[position];
                            position += patternInt[patternPos];
                            patternPos++;
                        }
                    }
                    else
                    {
                        maxCoins[i] = coins;
                        break;
                    }
                }
            }
            Array.Sort(maxCoins);
            
            Console.WriteLine(maxCoins[maxCoins.Length-1]);
        }
    }
}
