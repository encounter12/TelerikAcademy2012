using System;
using System.Text;
using System.Collections.Generic;
using System.Numerics;


namespace exam
{
    class Program
    {
        static void Main()
        {
            ulong number = ulong.Parse(Console.ReadLine());
            string[] numbers = new string[256];
            if (number < 0)
            {
                throw new System.ArgumentException();
            }


            for (int i = 0; i < 26; ++i)
            {
                numbers[i] = ((char)(i + 'A')).ToString();
            }

            char symbol = (char)('a' - 1);

            for (int i = 26; i <= 255; ++i)
            {
                if (i % 26 == 0)
                {
                    symbol++;
                }
                numbers[i] = (symbol).ToString() + (char)(i % 26 + 'A');
            }
            //StringBuilder result = new StringBuilder();

            List<ulong> result = new List<ulong>();

            while (number > 0)
            {
                result.Add(number % 256);
                number = number / 256;
            }
            result.Reverse();

            for (int i = 0; i < result.Count; ++i)
            {
                Console.Write(numbers[result[i]]);
            }
        }
    }
}
