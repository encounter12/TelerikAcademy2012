using System;
using System.Collections.Generic;

class GreedyDwarf
{
    private static int[] ReadArray(string input)
    {
        string[] inputAsStr = input.Split(new char[] {' ', ','}, StringSplitOptions.RemoveEmptyEntries);
        int[] output = new int[inputAsStr.Length];
        for (int index = 0; index < inputAsStr.Length; index++)
        {
            output[index] = int.Parse(inputAsStr[index]);
        }

        return output;
    }

    static void Main()
    {
        //// read input 
        int[] valley = ReadArray(Console.ReadLine());
        int m = int.Parse(Console.ReadLine());
        int[][] patterns = new int[m][];
        for (int patIndex = 0; patIndex < m; patIndex++)
        {
            string patAsStr = Console.ReadLine();
            string[] stepsAsStr = patAsStr.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            patterns[patIndex] = new int[stepsAsStr.Length];
            for (int index = 0; index < stepsAsStr.Length; index++)
            {
                patterns[patIndex][index] = int.Parse(stepsAsStr[index]);
            }
        }
        
        int[] results = new int[m];

        for (int row = 0; row < m; row++)
        {
            int position = 0, patIndex = 0, sum = 0;
            bool[] visited = new bool[valley.Length];
            while (position >= 0 && position < valley.Length && !visited[position])
            {
                sum += valley[position];
                visited[position] = true;
                position += patterns[row][patIndex];
                patIndex++;
                if (patIndex >= patterns[row].Length)
                {
                    patIndex = 0;
                }
            }

            results[row] = sum;
        }

        Array.Sort(results);
        Console.WriteLine(results[results.Length - 1]);
    }

    
}