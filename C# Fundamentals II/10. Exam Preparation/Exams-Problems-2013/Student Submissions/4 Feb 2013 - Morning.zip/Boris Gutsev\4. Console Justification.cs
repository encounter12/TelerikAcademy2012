using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class ConsoleJustification
{
    static void Main(string[] args)
    {
        int lines = int.Parse(Console.ReadLine());
        int width = int.Parse(Console.ReadLine());
        char[] spliters = new char[] { ' ' };
        Queue<string> words = new Queue<string>();
        for (int i = 0; i < lines; i++)
        {
            string currentLine = Console.ReadLine();
            string[] currentLineArr = currentLine.Split(spliters, StringSplitOptions.RemoveEmptyEntries);
            foreach (string item in currentLineArr)
            {
                words.Enqueue(item);
            }
        }
        StringBuilder result = new StringBuilder();
        StringBuilder sb = new StringBuilder();         
        while (words.Count > 0)
        {
            string currentWord = words.Dequeue();
           
            if (currentWord.Length < width)
            {
                if (sb.Length + currentWord.Length <= width)
                {                        
                    sb.Append(currentWord);                                            
                }
                else
                {
                    if (sb[sb.Length-1] == ' ')
                    {
                            sb.Remove(sb.Length - 1, 1);
                    }                       
                    int neadWithStapce = width - sb.Length;                  

                    bool isAlreadyAdd = false;
                    bool isNexAdd = true;
                    bool isAddlastTime = false;
                    int countAdded = 0;

                    while (countAdded < neadWithStapce)
                    {
                        for (int i = 0; i < sb.Length; i++)
                        {
                            if (isAlreadyAdd)
                            {
                                if(sb[i] != ' ')
                                {
                                    isAlreadyAdd = false;
                                    isNexAdd = true;
                                }
                            }
                            if (isNexAdd)
                            {
                                if (sb[i] == ' ')
                                {                                   
                                    if (countAdded<neadWithStapce)
                                    { 
                                        isNexAdd = false;
                                        isAlreadyAdd = true;
                                        sb.Insert(i, " ");
                                        countAdded++;
                                        isAddlastTime = true;
                                    }                                 
                                }
                            }                          
                        }
                        if (countAdded==neadWithStapce)
                        {
                            break;
                        }
                        if (!isAddlastTime)
                        {
                            break;
                        }
                        else
                        {
                            isAddlastTime = false;
                        }
                    }
                    result.Append(sb.ToString().Trim());
                    result.AppendLine();
                    sb.Clear();                   
                    sb.Append(currentWord);
                }
                if (sb.Length<width)
                {
                    sb.Append(" ");
                }
            }
            else
            {
                throw new ArgumentException("incorect word !!! - " + currentWord + " width is " + width);
            }               
        }
        result.Append(sb.ToString().Trim());
        Console.WriteLine(result.ToString());
    }
}

