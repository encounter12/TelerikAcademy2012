using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

    class Kaspichan
    {
        static void Main(string[] args)
        {
            long n =long.Parse(Console.ReadLine());
            StringBuilder result = new StringBuilder();
            char letter;
            for (int i = 0; i < n; i++)
            {
                if (n <= 25)
                {
                    while (n >= 0)
                    {
                        letter = (char)((n % 25) + 65);
                        n = n / 25;
                        result.Append(letter);
                    }
                }
             }
            Console.WriteLine(result);

            }
                       
            
        }
    

