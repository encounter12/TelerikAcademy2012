using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04.Justifyonsole
{
    class Program
    {
        static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());
            int width = int.Parse(Console.ReadLine());
            string[][] initialLines = new string[lines][];
            List<string> words = new List<string>();
            for (int i = 0; i < lines; i++)
            {
                initialLines[i] = Console.ReadLine().Split(new []{' '}, StringSplitOptions.RemoveEmptyEntries);
                foreach (var item in initialLines[i])
                {
                    words.Add(item);
                }
            }



            List<StringBuilder> result = new List<StringBuilder>();
            
            int indexLine = 0;
            int indexWord = 0;
            while(indexWord <words.Count)
            {
                if (result.Count == indexLine)
                {
                    result.Add(new StringBuilder());
                }
                if (result[indexLine].Length + words[indexWord].Length  < width)
                {
                    result[indexLine].Append(result[indexLine].Length == 0 ? "" : " ");
                    result[indexLine].Append(words[indexWord]);
                    indexWord++;
                }
                else
                {
                    indexLine++;
                }
            }

            //foreach(var line in result)
            //{
            //    Console.WriteLine(line);
            //}
            //Console.WriteLine();
            List<StringBuilder> realResult = new List<StringBuilder>();
            for (int i = 0; i < result.Count; i++)
            {
                int letterCount = 0;
                int gapsCount = 0;
                int wordCount = CountWords(result[i], out gapsCount, out letterCount);
                if (wordCount != 1)
                {
                    string[] wordsOnLine = result[i].ToString().Split();
                    StringBuilder[] gaps = new StringBuilder[gapsCount];
                    for (int k = 0; k < gaps.Length; k++)
                    {
                        gaps[k] = new StringBuilder();
                    }
                    for (int k = 0; k < width - letterCount; k++)
                    {
                        gaps[ShortestGap(gaps)].Append(' ');
                    }
                    realResult.Add(new StringBuilder(width));
                    for (int k = 0; k < wordCount - 1; k++)
                    {
                        realResult[i].Append(wordsOnLine[k]).Append(gaps[k]);
                    }
                    realResult[i].Append(wordsOnLine[wordCount - 1]);
                }
                else
                {
                    realResult.Add(new StringBuilder(width));
                    realResult[i].Append(result[i].ToString());
                }
            }

            foreach (var line in realResult)
            {
                Console.WriteLine(line);
            }
            //Console.WriteLine();
        }

        static int CountWords(StringBuilder line, out int gapsCount, out int lettersCount)
        {
            int words = line.ToString().Split().Length;
            lettersCount = 0;
            for (int i = 0; i < line.Length; i++)
            {
                if ((line[i] >= 'a' && line[i] <= 'z') || (line[i] >= 'A' && line[i] <= 'Z'))
                    lettersCount++;
            }
            gapsCount = words - 1;
            return words;
        }

        static int ShortestGap(StringBuilder[] gaps)
        {
            int index = 0;
            int smallestLength = int.MaxValue;
            for (int i = 0; i < gaps.Length; i++)
            {
                if (gaps[i].Length < smallestLength)
                {
                    smallestLength = gaps[i].Length;
                    index = i;
                }
            }
            return index;

        }
    }
}
