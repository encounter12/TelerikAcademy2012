using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;

class kaspichanNumbers
{
    static List<string> reminders = new List<string>();

    static void Main()
    {
        List<string> que = new List<string>();
        BigInteger num = BigInteger.Parse(Console.ReadLine());
        while (num > 255)
        {
            BigInteger reminder = num / 256;
            if (reminder < 256)
            {
                que = IfBellow256(reminder);
                num = num % 256;
            }
        }

        if (num < 256)
        {
            que = IfBellow256(num);   
        }
        Console.WriteLine(String.Concat(reminders));
    }

    static List<string> IfBellow256(BigInteger num)
    {
        
        if (num > 26)
        {
            BigInteger reminder = num / 26;
            char symbol = (char)(reminder + 64);
            string symbolString = symbol.ToString();
            symbolString = symbolString.ToLower();
            reminders.Add(symbolString);
        }
        num = num % 26;
        char symbol2 = (char)(num + 65);
        reminders.Add(symbol2.ToString());
        return reminders;
    }

    

    //Console.Write((char)(reminder+65));
}
