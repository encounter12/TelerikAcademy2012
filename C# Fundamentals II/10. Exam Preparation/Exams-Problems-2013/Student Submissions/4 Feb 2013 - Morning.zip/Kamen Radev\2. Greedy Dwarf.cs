using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class Program
{
    static void Main()
    {
        string[] input = Console.ReadLine().Split(new char[]{',', ' '}, StringSplitOptions.RemoveEmptyEntries);
        int?[] valley = new int?[input.Length];
        for (int i = 0; i < valley.Length; i++)
        {
            valley[i] = int.Parse(input[i]);
        }

        int patternNum = int.Parse(Console.ReadLine());

        int[][] patterns = new int[patternNum][];
        for (int i = 0; i < patternNum; i++)
        {
            input = Console.ReadLine().Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            patterns[i] = new int[input.Length];
            for (int k = 0; k < input.Length; k++)
            {
                patterns[i][k] = int.Parse(input[k]);
            }
        }
        
        int? maxCoins = int.MinValue;

        for (int i = 0; i < patterns.GetLength(0); i++)
        {
            int?[] clonedValley = (int?[])valley.Clone();
            int? coinsCollected = PassThruValley(clonedValley, patterns, i);
            if (maxCoins < coinsCollected)
            {
                maxCoins = coinsCollected;
            }
        }
        Console.WriteLine(maxCoins);
    }

    static int? PassThruValley(int?[] valley, int[][] pattern, int pass)
    {
        int? coin = valley[0];
        valley[0] = null;
        int index = 0;
        for (int i = 0; i<pattern[pass].Length; )
        {
            index += pattern[pass][i];
            if (index < 0 || index >= valley.Length || valley[index] == null)
            {
                break;
            }
            else
            {
                coin += valley[index];
                valley[index] = null;
            }
            i++;
            if (i == pattern[pass].Length)
            {
                i = 0;
            }
        }
        return coin;
    }
}
