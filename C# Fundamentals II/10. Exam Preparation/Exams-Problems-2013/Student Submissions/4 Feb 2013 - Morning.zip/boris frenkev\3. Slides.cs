using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    
     static string GetLast(string str)
    {
        int index = str.IndexOf(' ');
        return ((str.Substring(index + 1)));
    }

    static int[] GetNumbers(string str)
    {
        char[] separators = new char[] { ' ' };
        string[] numbers = str.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        int[] result = new int[numbers.Length];
        for (int i = 0; i < result.Length; i++)
        {
            result[i] = int.Parse(numbers[i]);
        }
        return result;
    }

    static int[] GetCoor(string str)
    {
        string temp = GetLast(str);
        return GetNumbers(temp);
    }
    static void NewCoord( string str,int i, int j, int k, out int newI, out int newJ, out int newK)
    {
        newI = i;
        newJ = j;
        newK = k;
        if (str[0] == 'S')
        {
            newI++;
            string last = GetLast(str);
            if (last == "F")
            {
                newJ--;
            }
            if (last == "B")
            {
                newJ++;
            }
            if (last == "L")
            {
                newK--;
            }
            if (last == "R")
            {
                newK++;
            }

            if (last == "FL")
            {
                newJ--;
                newK--;
            }
            if (last == "FR")
            {
                newJ--;
                newK++;
            }
            if (last == "BL")
            {
                newJ++;
                newK--;
            }
            if (last == "BR")
            {
                newJ++;
                newK++;
            }
        }
        if (str[0] == 'T')
        {
            int[] coord = GetCoor(str);
            newJ =  GetCoor(str)[1];
            newK =  GetCoor(str)[0];
        }
        if (str[0] == 'E')
        {
            newI++;
        }
    }

    static void Main(string[] args)
    {
        //string coord1 = "T 1 1";
        ////int x = 1;
        ////int y = 0;
        ////int z = 0;
        //int newI1 = 0;
        //int newJ1 = 0;
        //int newK1 = 0;
        //NewCoord(coord1, 1, 1, 2, out newI1, out newJ1, out newK1);
        //Console.WriteLine(newI1);
        //Console.WriteLine(newJ1);
        //Console.WriteLine(newK1);
        //string str = "S BR";new
        //string str1 = "T 1 1";
        //Console.WriteLine(GetLast(str));
        //Console.WriteLine(GetCoor(str1)[0]);
        string lineDim = Console.ReadLine();
        int[] dimen = GetNumbers(lineDim);
        int w = dimen[0];
        int h = dimen[1];
        int d = dimen[2];
        string[, ,] cuboid = new string[h, d, w];
        char[] separators = new char[] { '|' };
        for (int i = 0; i < h; i++)
        {
            string line = Console.ReadLine();
            string[] rows = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            for (int j = 0; j < d; j++)
            {
              char [] sepBrack = new char[]{'(',')'};
              string[] cubes = rows[j].Trim().Split(sepBrack, StringSplitOptions.RemoveEmptyEntries);
                for (int k = 0; k < w; k++)
                {
                    cuboid[i, j, k] =cubes[k];
                }
            }
        }
         string dimens = Console.ReadLine();
         int[] starts = GetNumbers(dimens);
         int startI = 0;
         int startJ = starts[1];
         int startK = starts[0];
         string coord = cuboid[startI, startJ, startK];
         if (coord[0] == 'B')
         {
             Console.WriteLine("No");
             Console.WriteLine("{0} {1} {2}", startK, startI, startJ);
             return;
         }
       //  Console.WriteLine(coord);
         while (true)
         {
             int newI = 0;
             int newJ = 0;
             int newK = 0;         
             NewCoord(coord, startI, startJ, startK, out newI, out newJ, out newK);
            
             if ((newJ < 0) || (newJ > cuboid.GetLength(1) - 1) || (newK < 0) || (newK > cuboid.GetLength(2) - 1))
             {
                 Console.WriteLine("No");
                 Console.WriteLine("{0} {1} {2}", startK, startI, startJ);
                 break;
             }
             if (cuboid[newI, newJ, newK] == "B")
             {
                 Console.WriteLine("No");
                 Console.WriteLine("{0} {1} {2}", newK, newI, newJ);
                 break;
             }
             if (newI == cuboid.GetLength(0) - 1)
             {
                 Console.WriteLine("Yes");
                 Console.WriteLine("{0} {1} {2}", newK, newI, newJ);
                 break;
             }
            
             coord = cuboid[newI, newJ, newK];
             startI = newI;
             startJ = newJ;
             startK = newK;
             //Console.WriteLine("{0} {1} {2}", startI, startJ, startK);
         }
        //for (int i = 0; i < h ; i++)
        //{
        //    for (int j = 0; j < d; j++)
        //    {
        //        for (int k = 0; k < w; k++)
        //        {

        //            Console.Write("{0}  ",cuboid[i,j,k]);
        //        }
        //        Console.Write('|');
        //    }
        //    Console.WriteLine();
        //}
     
    }
}