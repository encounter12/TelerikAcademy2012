using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5.OneTaskIsNotEnough
{
    class OneTaskIsNotEnough
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            string command1 = Console.ReadLine();
            string command2 = Console.ReadLine();

            FindLasLamp(N);
            ExecuteCommand(command1);
            ExecuteCommand(command2);

        }

        private static void ExecuteCommand(string command1)
        {
            if (command1.IndexOf('S') < 0)
            {
                Console.WriteLine("bounded");
            }
            else
            {
                int lCount = 0;
                int rCount = 0;

                foreach (var item in command1)
                {
                    if (item == 'L')
                    {
                        lCount++;
                    }
                    else if (item == 'R')
                    {
                        rCount++;
                    }
                }

                if (lCount == 1 && rCount == 0 || lCount == 0 && rCount == 1)
                {
                    Console.WriteLine("bounded");
                }
                else
                {
                    Console.WriteLine("unbounded");
                }
            }
        }

        private static void FindLasLamp(int N)
        {
            int[] lamps = new int[N];
            int lastLamp = 0;
            int lamp = 0;
            int step = 1;
            int target = 0;
            int j = 0;

            for (int i = 0; i < N; i++)
            {
                target = i;
                if (lamps[target] == 0)
                {
                    step++;

                    do
                    {
                        lastLamp = target;
                        lamps[target] = 1;

                        int emptyCount = 0;

                        for (j = target; j < N; j++)
                        {
                            if (lamps[j] == 0)
                            {
                                emptyCount++;
                            }

                            if (emptyCount == step)
                            {
                                 target = j;
                                 break;
                            }
                        }

                        if (j >= N)
                        {
                            break;
                        }

                    } while (target < N);
                }
            }

            Console.WriteLine(lastLamp + 1);
        }
    }
}
