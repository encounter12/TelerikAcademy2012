using System;
using System.Collections.Generic;
using System.Text;

class Problem02
{
    static void Main()
    {
        string[] delimiter = new string[] { "," };
        string[] valStr = Console.ReadLine().Split(delimiter, StringSplitOptions.RemoveEmptyEntries);
        int arrLen = valStr.GetLength(0);
        int[] valArr = new int[arrLen];
        // Parse the array
        for (int i = 0; i < arrLen; i++)
        {
            valArr[i] = int.Parse(valStr[i]);
        }
        int nP = int.Parse(Console.ReadLine());
        int bestColl = 0;
        int workColl = 0;
        for (int i = 0; i < nP; i++)
        {
            string[] patStr = Console.ReadLine().Split(delimiter, StringSplitOptions.RemoveEmptyEntries);
            int patLen = patStr.GetLength(0);
            int[] patArr = new int[patLen];
            // Parse the array
            for (int j = 0; j < patLen; j++)
            {
                patArr[j] = int.Parse(patStr[j]);
            }

            for (int si = 0; si < arrLen; si++)
            {
                workColl = valArr[si];
                int currInd = si;
                for (int k = 0; k < patLen; k++)
                {
                    try
                    {
                        if (patArr[k] >= 0)
                        {
                            workColl += valArr[currInd + patArr[k]];
                            currInd += patArr[k];
                        }
                        else
                        {
                            workColl += valArr[currInd - patArr[k]];
                            currInd -= patArr[k];
                        } k  -= 1;
                    }
                    catch (IndexOutOfRangeException)
                    {
                        k = patLen;
                        workColl = 0;
                        break;
                    }
                    catch (OutOfMemoryException)
                    {
                        k = patLen;
                        workColl = 0;
                        break;
                    }
                    if (workColl > bestColl) bestColl = workColl;

                }
            }
        }
        Console.WriteLine(bestColl);
    }
}
/*
1, 3, -6, 7, 4, 1, 12
3
1, 2, -3
1, 3, -2
1, -1
*/