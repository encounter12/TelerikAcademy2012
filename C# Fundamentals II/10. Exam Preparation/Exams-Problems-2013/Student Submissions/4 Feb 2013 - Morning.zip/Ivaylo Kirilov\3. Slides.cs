using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Slides
{
    class Slides
    {
        static int W, H, D, ballW, ballD;
        static string[, ,] cuboid;

        static void ReadInput()
        {
            //using (StreamReader sr = new StreamReader("../../cuboid.txt")){
                string line = Console.ReadLine();
                //string line = sr.ReadLine();
                string[] dimensions = line.Split(' ');

                W = int.Parse(dimensions[0]);
                H = int.Parse(dimensions[1]);
                D = int.Parse(dimensions[2]);
                cuboid = new string[W, H, D];

                for (int i = 0; i < H; i++)
                {
                    line = Console.ReadLine();
                    //line = sr.ReadLine();
                    string[] depthSplit = line.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int j = 0; j < D; j++)
                    {
                        depthSplit[j] = depthSplit[j].Trim();
                        //Console.WriteLine(depthSplit[0]);
                        string[] widthSplit = depthSplit[j].Split(new char[] { ')', '(' }, StringSplitOptions.RemoveEmptyEntries);
                        for (int k = 0; k < W; k++)
                        {
                            //Console.WriteLine(widthSplit[k]);
                            cuboid[k, i, j] = widthSplit[k];
                        }
                    }
                }

                line = Console.ReadLine();
                //line = sr.ReadLine();
                string[] ball = line.Split(' ');
                ballW = int.Parse(ball[0]);
                ballD = int.Parse(ball[1]);
            //}
        }

        static void WriteOutput(bool isStuck, int w, int h, int d)
        {
            if (isStuck)
            {
                Console.WriteLine("No");
            }
            else
            {
                Console.WriteLine("Yes");
            }
            Console.WriteLine(w + " " + h + " " + d);
        }

        static bool IsOutside(int w, int h, int d)
        {
            if (w < 0 || w >= W)
            {
                return true;
            }
            if (h < 0 || h >= H)
            {
                return true;
            }
            if (d < 0 || d >= D)
            {
                return true;
            }
            return false;
        }

        static void MoveInCuboid()
        {
            int currW = ballW, currD = ballD, currH = 0;
            while (true)
            {
                string at = cuboid[currW, currH, currD];
                if (at == "B")
                {
                    WriteOutput(true, currW, currH, currD);
                    break;
                }
                else if (at == "E")
                {
                    currH++;
                    if (IsOutside(currW, currH, currD))
                    {
                        WriteOutput(false, currW, currH - 1, currD);
                        break;
                    }
                }
                else if (at[0] == 'T')
                {
                    string newW = "", newD = "";
                    int i;
                    for (i = 2; at[i] != ' '; i++)
                    {
                        newW += at[i];
                    }
                    for (i = i + 1; i < at.Length; i++)
                    {
                        newD += at[i];
                    }
                    int w = int.Parse(newW);
                    int d = int.Parse(newD);

                    if (IsOutside(w, currH, d))
                    {
                        WriteOutput(true, currW, currH, currD);
                        break;
                    }
                    currW = w;
                    currD = d;
                }
                else
                {
                    at = at.Substring(2);
                    if (currH == H - 1)
                    {
                        WriteOutput(false, currW, currH, currD);
                        break;
                    }
                    else if (at == "BL")
                    {
                        currW--;
                        currH++;
                        currD++;
                        if (IsOutside(currW, currH, currD))
                        {
                            WriteOutput(true, currW + 1, currH - 1, currD - 1);
                            break;
                        }
                    }
                    else if (at == "BR")
                    {
                        currW++;
                        currH++;
                        currD++;
                        if (IsOutside(currW, currH, currD))
                        {
                            WriteOutput(true, currW - 1, currH - 1, currD - 1);
                            break;
                        }
                    }
                    else if (at == "FL")
                    {
                        currW--;
                        currH++;
                        currD--;
                        if (IsOutside(currW, currH, currD))
                        {
                            WriteOutput(true, currW + 1, currH - 1, currD + 1);
                            break;
                        }
                    }
                    else if (at == "FR")
                    {
                        currW++;
                        currH++;
                        currD--;
                        if (IsOutside(currW, currH, currD))
                        {
                            WriteOutput(true, currW - 1, currH - 1, currD + 1);
                            break;
                        }
                    }
                    else if (at == "L")
                    {
                        currW--;
                        currH++;
                        if (IsOutside(currW, currH, currD))
                        {
                            WriteOutput(true, currW + 1, currH - 1, currD);
                            break;
                        }
                    }
                    else if (at == "R")
                    {
                        currW++;
                        currH++;
                        if (IsOutside(currW, currH, currD))
                        {
                            WriteOutput(true, currW - 1, currH - 1, currD);
                            break;
                        }
                    }
                    else if (at == "F")
                    {
                        currD--;
                        currH++;
                        if (IsOutside(currW, currH, currD))
                        {
                            WriteOutput(true, currW, currH - 1, currD + 1);
                            break;
                        }
                    }
                    else if (at == "B")
                    {
                        currD++;
                        currH++;
                        if (IsOutside(currW, currH, currD))
                        {
                            WriteOutput(true, currW, currH - 1, currD - 1);
                            break;
                        }
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            ReadInput();
            MoveInCuboid();
        }
    }
}
