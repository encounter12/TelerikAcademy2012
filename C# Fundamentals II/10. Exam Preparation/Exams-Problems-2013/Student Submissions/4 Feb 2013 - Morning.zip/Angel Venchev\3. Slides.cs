using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.Slides
{
    class Program
    {
        static void Main(string[] args)
        {
            string sides = Console.ReadLine();
            string[] sideSeparated = sides.Split(new []{' '},StringSplitOptions.RemoveEmptyEntries);
            int W;
            int H;
            int D;
            W = int.Parse(sideSeparated[0]);
            H = int.Parse(sideSeparated[1]);
            D = int.Parse(sideSeparated[2]);
            string[] inputLines = new string[H];
            for (int i = 0; i < H; i++)
            {
                inputLines[i] = Console.ReadLine();
            }
            string[][] lastAttempt = new string[H][];
            for (int i = 0; i < H; i++)
            {
                lastAttempt[i] = new string[D];
                lastAttempt[i] = inputLines[i].Split(new[] { " | "}, StringSplitOptions.RemoveEmptyEntries);
                lastAttempt[i] = lastAttempt[i].Where(str => !string.IsNullOrWhiteSpace(str) && !string.IsNullOrEmpty(str)).ToArray();
                for (int k = 0; k < lastAttempt[i].Length; k++)
                {
                    lastAttempt[i][k] = lastAttempt[i][k].Trim();
                }
             }
            string[][][] Cube = new string[H][][];
            for (int i = 0; i < H; i++)
            {
                Cube[i] = new string[D][];
                for (int k = 0; k < D; k++)
                {
                    Cube[i][k] = lastAttempt[i][k].Split(new []{"(",")"}, StringSplitOptions.RemoveEmptyEntries);
                    Cube[i][k] = Cube[i][k].Where(str => !string.IsNullOrWhiteSpace(str) && !string.IsNullOrEmpty(str)).ToArray();
                    for(int j = 0; j < Cube[i][k].Length; j++)
                    {
                        Cube[i][k][j] = Cube[i][k][j].Trim();
                    }
                }
            }
            int x;
            int y;
            string[] initialDrop = Console.ReadLine().Split(new []{" "},StringSplitOptions.RemoveEmptyEntries);
            if (initialDrop.Length == 1)
            {
                initialDrop[0] = initialDrop[0].Trim();
                x = int.Parse(initialDrop[0][0].ToString());
                y = int.Parse(initialDrop[0][1].ToString());

            }
            else
            {
                x = int.Parse(initialDrop[0]);
                y = int.Parse(initialDrop[1]);
            }



            int[] result = DropBall(Cube, x, y, 0);
            //for (int i = 0; i < H; i++)
            //{
            //    for (int k = 0; k < D; k++)
            //    {
            //        for (int j = 0; j < W; j++)
            //        {
            //            Console.Write(Cube[i][k][j].PadRight(5,' '));
            //        }
            //        Console.Write("  ");
            //    }
            //    Console.WriteLine();
            //}
            Console.WriteLine(result[0] == 1 ? "Yes" : "No");
            Console.Write(result[1].ToString() + " ");
            Console.Write(result[2].ToString() + " ");
            Console.WriteLine(result[3]);
            
        }

        static int[] DropBall(string[][][] cube, int x, int y, int z)
        {
            if (cube[z][y][x][0] == 'B')
            {
                return new []{0,x,z,y};
            }
            else if (cube[z][y][x][0] == 'S')
            {
                if (z == cube.Length - 1)
                {
                    return new[] { 1, x, z, y };
                }
                string[] slide = cube[z][y][x].Split(new []{' '}, StringSplitOptions.RemoveEmptyEntries);
                if (slide[1].Length == 1)
                {
                    switch (slide[1].First())
                    {
                        case 'F':
                            if (y - 1 < 0)
                            {
                                return new[] { 0, x, z, y };
                            }
                            return DropBall(cube, x, y - 1, z+1);
                        case 'B':
                            if (y + 1 >= cube[z][y + 1].Length)
                            {
                                return new[] { 0, x, z, y };
                            }
                            return DropBall(cube, x, y + 1, z+1);
                        case 'L':
                            if (x - 1 < 0)
                            {
                                return new[] { 0, x, z, y };
                            }
                            return DropBall(cube, x - 1, y, z + 1);
                        case 'R':
                            if (x + 1 >= cube[z][y][x].Length)
                            {
                                return new[] { 0, x, z, y };
                            }
                            return DropBall(cube, x + 1, y, z + 1);
                        default:
                            return new []{0,0,0,0};
                    }
                }
                else
                {
                    switch (slide[1])
                    {
                        case "FL":
                            if (y - 1 < 0 || x < 0)
                            {
                                return new[] { 0, x, z, y };
                            }
                            return DropBall(cube, x - 1, y - 1, z + 1);
                        case "FR":
                            if (y - 1 < 0 || x >= cube[z][y][x].Length)
                            {
                                return new[] { 0, x, z, y };
                            }
                            return DropBall(cube, x + 1, y - 1, z + 1);
                        case "BL":
                            if (y + 1 >= cube[z][y + 1].Length || x < 0)
                            {
                                return new[] { 0, x, z, y };
                            }
                            return DropBall(cube, x - 1, y + 1, z + 1);
                        case "BR":
                            if (y + 1 >= cube[z][y + 1].Length || x >= cube[z][y][x].Length)
                            {
                                return new[] { 0, x, z, y };
                            }
                            return DropBall(cube, x + 1, y + 1, z + 1);
                        default:
                            return new []{0,0,0,0};
                    }
                }
            }
            else if (cube[z][y][x][0] == 'T')
            {
                string[] teleport = cube[z][y][x].Split(new []{' '}, StringSplitOptions.RemoveEmptyEntries);
                {
                    return DropBall(cube, int.Parse(teleport[1]), int.Parse(teleport[2]), z);
                }
            }
            else if (cube[z][y][x][0] == 'E')
            {
                if (z == cube.Length-1)
                {
                    return new[] { 1, x, z, y };
                }
                else
                {
                    return DropBall(cube, x, y, z + 1);
                }
            }
            else
                throw new Exception();

        }
    }
}
