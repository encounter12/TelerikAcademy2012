using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreedyDwarf
{
    class Program
    {
        static void Main(string[] args)
        {
            int result=0;
            string input  = Console.ReadLine();
            string[] numb = input.Split(',');
            int[] valley = new int [numb.Length];
            int maxCount = int.MinValue;
            
            for (int i = 0; i < valley.Length; i++)
            {
                valley[i] = int.Parse(numb[i]);
            }
            int patterns = int.Parse(Console.ReadLine()); ;



            for (int l = 0; l < patterns; l++)
			{
                string pattern = Console.ReadLine();
                string[] pattern2 = pattern.Split(',');
                int[] path = new int[pattern2.Length];

                for (int i = 0; i < path.Length; i++)
                {
                    path[i] = int.Parse(pattern2[i]);
                }

			     result =    PatternMove(valley, path);
               
                 if (maxCount < result)
                 {
                     maxCount = result;
                 }
			}
    
       
            Console.WriteLine(maxCount);


        }

        private static int PatternMove(int[] valley,  int[] pat)
        {
            bool[] vis = new bool[valley.Length];
            int maxCount = int.MinValue;
            int count = 0;
            int j = 0;
            for (int i = 0, k = 0; i < valley.Length; )
            {
                if (vis[i] == false)
                {
                    if (i >= 0)
                    {
                        count += valley[i];
                        k++;
                        vis[i] = true;
                        i = i + pat[j];
                        if (j < pat.Length - 1)
                        {
                            j++;
                        }
                        else
                        {
                            j = 0;
                        }
                    }
                }
                else
                {
                    break;
                }
            }

            //if (maxCount<count)
            //{
            //    maxCount = count;
            //}
            return count;
        }

    }
}
