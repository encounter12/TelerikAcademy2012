using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Greedy
{
    static bool IsInRange(int len, int index)
    {
        return (index >= 0 && index < len);
    }

    static int GreedyCoins(List<int> coins, List<int> path)
    {
        List<bool> visited = new List<bool>(coins.Count);
        visited.Add(true);
        for (int i = 1; i < coins.Count; i++)
        {
            visited.Add(false);
        }
        int coinsCount = coins[0];
        int index = 0;
        while (true)
        {
            for (int i = 0; i < path.Count; i++)
            {

                if (!IsInRange(coins.Count, index + path[i]))
                {
                    return coinsCount;
                }

                index = index + path[i];

                if (visited[index])
                {
                    return coinsCount;
                }
                coinsCount += coins[index];

                visited[index] = true;


                // index = index + path[i];
            }
        }
        return coinsCount;
    }

    static void Main(string[] args)
    {

        string[] separator = new string[] { ", " };

        string coinsInput = Console.ReadLine();

        int n = int.Parse(Console.ReadLine());


        string[] pathsInput = new string[n];

        for (int i = 0; i < n; i++)
        {
            pathsInput[i] = Console.ReadLine();
        }


        string[] c = coinsInput.Split(separator, StringSplitOptions.None);
        List<int> coins = new List<int>();
        for (int i = 0; i < c.Length; i++)
        {
            coins.Add(int.Parse(c[i]));
        }



        List<List<int>> paths = new List<List<int>>();
        for (int i = 0; i < pathsInput.Length; i++)
        {
            List<int> l = new List<int>();

            string[] p = pathsInput[i].Split(separator, StringSplitOptions.None);
            for (int j = 0; j < p.Length; j++)
            {
                l.Add(int.Parse(p[j]));
            }
            paths.Add(l);
        }

        int max = GreedyCoins(coins, paths[2]);
        for (int i = 1; i < paths.Count; i++)
        {
            int m = GreedyCoins(coins, paths[i]);
            if (m > max)
            {
                max = m;
            }
        }
        Console.WriteLine(max);

    }
}
