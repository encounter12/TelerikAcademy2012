using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem5
{
    class Problem5
    {
        static void firsttask(int n)
        {

            int s = 0;
            int m = 2;
            int res = 0;
            short count = 0;
            byte[] lamps = new byte[n];
            while (m <= n)
            {
               
                for (int k = s; k < n; k += m)
                {

                    if (lamps[k] == 0)
                    {
                        res = k + 1;
                        lamps[k] = 1;
                        count++;
                    }
                    if (count == n)
                    {
                        break;
                    }
                }
                s++;
                m++;
            }
            Console.WriteLine(res);  
            
        }

        static void secondtask(string path)
        {
            int countS = 0;
            int countR = 0;
            int countL = 0;
            for (int i = 0; i < path.Length; i++)
            {
                switch (path[i])
                {
                    case 'S':
                        countS++;
                        break;
                    case 'R':
                        countR++;
                        break;
                    case 'L':
                        countL++;
                        break;
                    default:
                        break;
                }
                
            }
            if (countR > countL && countS % countR == 0)
            {
                Console.WriteLine("bounded");
            }
            else if (countL > countR && countS % countL == 0)
            {
                Console.WriteLine("bounded");
            }
            else
            {
                Console.WriteLine("unbounded");
            }
        }

        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());

            string s1 = Console.ReadLine();

            string s2 = Console.ReadLine();
            firsttask(num);
            secondtask(s1);
            secondtask(s2);
        }
    }
}