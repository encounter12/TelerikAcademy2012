using System;
using System.Text;
class KaspichanNumbers
{
    static void Main()
    {
        // 0 -25 Alphabet 25 
        // 26 - 51 aAlphabet 25 
        //int sum = 0;
        //for (int i = 0; i < 10; i++)
        //{
        //    sum += 26;
        //    Console.WriteLine(sum);
        //}
        //int input = int.Parse(Console.ReadLine());


        string[] AlphabetCapital = new string[30];
        string[] AlphabetLower = new string[30];
        string[] result = new string[1000];
        string[] result1 = new string[1000];
        int ABC = 0x41;
        int abc = 0x61;
        //int dif = 57;
        //Console.WriteLine(97-41);

        //Console.WriteLine((char)abc);
        for (int i = ABC, index = 0, j = abc; i < ABC + 26; i++, index++)
        {
            AlphabetCapital[index] = ((char)i).ToString();
            AlphabetLower[index] = ((char)j).ToString();
            result[index] = AlphabetCapital[index];
            result1[index] = result[index];
            j++;
        }
        //while (true)
        //      {


        //for (int i = 0; i < 100; i++)
        //{
        //    for (int j = i; j < 26; j++)
        //    {

        //        result1[j] = AlphabetLower[i] + AlphabetCapital[j];
        //    }
        //}
        int input = int.Parse(Console.ReadLine());
        //for (int a = 0; a < 260; a++)
        //{
        //    input = a;
            if (input >= 26)
            {
                if (input < 51)
                {
                    // 26 - aA
                    // 27 - aB
                    // 28 - aC
                    // 29 - aD
                    for (int i = 0; i < 26; i++)
                    {
                        result[i + 26] = AlphabetLower[0] + AlphabetCapital[i];
                    }
                    Console.WriteLine(result[input]);
                }
                if (input >= 51 && input < 78)
                {
                    // 26 - aA
                    // 27 - aB
                    // 28 - aC
                    // 29 - aD
                    for (int i = 0; i < 26; i++)
                    {
                        result[i + 52] = AlphabetLower[1] + AlphabetCapital[i];
                    }
                    Console.WriteLine(result[input]);
                }
                if (input >= 78 && input < 104)
                {
                    // 26 - aA
                    // 27 - aB
                    // 28 - aC
                    // 29 - aD
                    for (int i = 0; i < 26; i++)
                    {
                        result[i + 78] = AlphabetLower[2] + AlphabetCapital[i];
                    }
                    Console.WriteLine(result[input]);
                }
                if (input >= 105 && input < 130)
                {
                    // 26 - aA
                    // 27 - aB
                    // 28 - aC
                    // 29 - aD
                    for (int i = 0; i < 26; i++)
                    {
                        result[i + 105] = AlphabetLower[3] + AlphabetCapital[i];
                    }
                    Console.WriteLine(result[input]);
                }
                if (input >= 130 && input < 156)
                {
                    // 26 - aA
                    // 27 - aB
                    // 28 - aC
                    // 29 - aD
                    for (int i = 0; i < 26; i++)
                    {
                        result[i + 130] = AlphabetLower[4] + AlphabetCapital[i];
                    }
                    Console.WriteLine(result[input]);
                }
                if (input >= 156 && input < 182)
                {
                    // 26 - aA
                    // 27 - aB
                    // 28 - aC
                    // 29 - aD
                    for (int i = 0; i < 26; i++)
                    {
                        result[i + 156] = AlphabetLower[5] + AlphabetCapital[i];
                    }
                    Console.WriteLine(result[input]);
                }
                if (input >= 182 && input < 208)
                {
                    // 26 - aA
                    // 27 - aB
                    // 28 - aC
                    // 29 - aD
                    for (int i = 0; i < 26; i++)
                    {
                        result[i + 182] = AlphabetLower[6] + AlphabetCapital[i];
                    }
                    Console.WriteLine(result[input]);
                }
                if (input >= 208 && input < 234)
                {
                    // 26 - aA
                    // 27 - aB
                    // 28 - aC
                    // 29 - aD
                    for (int i = 0; i < 26; i++)
                    {
                        result[i + 208] = AlphabetLower[7] + AlphabetCapital[i];
                    }
                    Console.WriteLine(result[input]);
                }
                if (input >= 234 && input < 260)
                {
                    // 26 - aA
                    // 27 - aB
                    // 28 - aC
                    // 29 - aD
                    for (int i = 0; i < 26; i++)
                    {
                        result[i + 234] = AlphabetLower[8] + AlphabetCapital[i];
                    }
                    Console.WriteLine(result[input]);
                }
                if (input >= 260 && input < 286)
                {
                    // 26 - aA
                    // 27 - aB
                    // 28 - aC
                    // 29 - aD
                    for (int i = 0; i < 26; i++)
                    {
                        result[i + 260] = AlphabetLower[9] + AlphabetCapital[i];
                    }
                    Console.WriteLine(result[input]);
                }


            }
            else
            {
                Console.WriteLine(AlphabetCapital[input]);
            }
        }
    }
//}

//}