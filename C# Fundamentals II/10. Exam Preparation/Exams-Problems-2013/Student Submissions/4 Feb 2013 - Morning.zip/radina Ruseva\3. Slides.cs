using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.Slides
{
    class Slides
    {
        static void Main()
        {
            string cubeSize = Console.ReadLine();
            string[] cubeDimensions = cubeSize.Split();
            int width = int.Parse(cubeDimensions[0]);
            int height = int.Parse(cubeDimensions[1]);
            int depth = int.Parse(cubeDimensions[2]);
            char[, ,] cube = new char[width, height, depth];
            // reads the cube from the console
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] letters = line.Split('|');
                for (int d = 0; d < depth; d++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        cube[w, h, d] = letters[d][w];
                    }
                }
            }
            string ballPosition = Console.ReadLine();
            string[] ball = ballPosition.Split();
            int ballW = int.Parse(cubeDimensions[0]);
            int ballD = int.Parse(cubeDimensions[1]);
            //for (int h = 0; h < height; h++)
            //{
            //    for (int d = 0; d < depth; d++)
            //    {
            //        for (int w = 0; w < width; w++)
            //        {
            //            Console.WriteLine(cube[w, h, d]);
            //        }
            //    }
            //}
            bool isInBasket = false;
            bool isInEmptyCube = false;
            bool isInTeleport = false;
            bool isInSlide = false;
            int currentH=0, currentD=ballD, currentW=ballW;
            int lastH = 0, lastW = 0, lastD = 0;
            while (currentH<=height)
            {
                        if (cube[currentW, currentH, currentD] == 'B') 
                        {
                            isInBasket = true;
                            lastD = currentD;
                            lastH = currentH;
                            lastW = currentW;
                            break;
                        }
                        if (cube[currentW, currentH, currentD] == 'E')
                        {
                            currentH = currentH + 1;
                           
                        }
                    
                
            }
            if (isInBasket)
            { 
                Console.WriteLine("No");
                Console.WriteLine("{0} {1} {2}", lastW, lastH, lastD);
            }
        }
    }
}