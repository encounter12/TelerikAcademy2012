using System;
using System.Text;

class Justification
{
    static void Main(string[] args)
    {
        StringBuilder text = new StringBuilder();
        int n = int.Parse(Console.ReadLine());
        int w = int.Parse(Console.ReadLine());
        for (int p = 0; p < n; p++)
        {
            text.AppendLine(Console.ReadLine());
        }

        //int n = 5;
        //int w = 20;
        //string text = "We happy few      we band\n of brothers for he who sheds\nhis blood\nwith\nme shall be my brother";

        string[] words = text.ToString().Split(new char[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
        StringBuilder wholeText = new StringBuilder();
        StringBuilder currentLine = new StringBuilder();

        int i = 0, currentLineWordCount = 0;
        if (words.Length == 0) return;
        while (true)
        {
            if (currentLine.Length + words[i].Length <= w)
            {
                currentLine.Append(words[i] + ' ');
                currentLineWordCount++;
                if (++i >= words.Length)
                {
                    currentLine.Remove(currentLine.Length - 1, 1);
                    Justify(currentLine, w, currentLineWordCount);
                    wholeText.AppendLine(currentLine.ToString());
                    break;
                }
            }
            else
            {
                currentLine.Remove(currentLine.Length - 1, 1);
                Justify(currentLine, w, currentLineWordCount);
                wholeText.AppendLine(currentLine.ToString());

                currentLineWordCount = 0;
                currentLine.Clear();
            }
        }
        Console.WriteLine(wholeText.ToString());
        
    }

    static void Justify(StringBuilder sb, int w, int currentLineWordCount)
    {
        if (currentLineWordCount == 1)
        {
            return;
        }
        if (sb.Length == w)
        {
            return;
        }
        int i = 0;
        while (i < sb.Length && sb.Length < w)
        {
            if (sb[i++] == ' ')
            {
                sb.Insert(i, " ", 1);
                while (sb[i] == ' ')
                {
                    i++;
                }
            }
        }
        Justify(sb, w, currentLineWordCount);

        
    }
}
