using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;


class GreedyDwarf
{
    static string valley = Console.ReadLine();
    static List<int> numValleys = new List<int>();
    static int M = int.Parse(Console.ReadLine());
    static string[] patterns = new string[M];
    static int[] numPatterns = new int[100];
    static int[] numPatterns1 = new int[100];
    static List<int> numPat = new List<int>();

    static int sum = 0;
    
    static List<int> sums = new List<int>();
    

    static void Main()
    {
        valley = valley.Replace(" ", string.Empty);
        //Console.WriteLine(valley);
        string[] valleys = valley.Split(',');

        for (int i = 0; i < valleys.Length; i++)
        {
            if (valleys[i] != "-")
            {
                numValleys.Add(int.Parse(valleys[i]));
            }
            else
            {
                numValleys.Add((int.Parse(valleys[i + 1])) * -1);
                i++;
            }
        }

        for (int i = 0; i < M; i++)
        {
            numPat.Clear();
            Read(M);
            WorkIt(numPat);
            sums.Add(sum);               
        }
        
        Console.WriteLine(sums.Max());
    }

   

     private static int[] Read(int M)
     {
        
        
        string str = Console.ReadLine();


        patterns = str.Split(',');
         
        for (int i = 0; i < patterns.Length; i++)
        {
            
            numPatterns[i] = int.Parse(patterns[i]);
            numPat.Add(numPatterns[i]);
            //Console.WriteLine(numPat[i]);
        }

        /*
        for (int j = 0, k = 0; j < patterns.Length; j++, k++)
        {
            if (patterns[k] != "-")
            {
                numPatterns[k] = int.Parse(patterns[k]);
            }
            else
            {
                numPatterns[k] = (int.Parse(patterns[k]) * -1);
                k++;
            }
           // Console.Write(numPatterns[j]);            
        } */
         return numPatterns;
     }
     
    

    private static int WorkIt(List<int> numPat)
    {
        sum = 0;
        List<int> walk = new List<int>();
        bool[] visited = new bool[10000];
        int index = 0;     
        
        walk.Add(numValleys[0]);
        visited[0] = true;
            
        for (int i = 1, j = 0; true; j++)
        {
            if (j == numPat.Count)
            {
                j = 0;
            }
            
            index += numPat[j];
            i = index;
            if (i < 0)
            {
                break;
            }


            if (visited[i] || i < 0)
            {
                break;
            }
            else { }                         

            visited[index] = true;

            if (index >= numValleys.Count || index < 0)
            {
                break;
            }
            walk.Add(numValleys[index]);
        }
            
        for (int i = 0; i < walk.Count; i++)
		{
			sum += walk[i];
		}

        return sum;
    }
   
}
