using System;
using System.Text.RegularExpressions;

class Slides
{
    static int posW = 0;
    static int posH = 0;
    static int posD = 0;
    static bool exit = true;

    static void Main()
    {
        string[, ,] cube = GetInputData();

        bool more = false;
        do
        {
            more = NextMove(cube);
        }
        while (more);

        Console.WriteLine(exit ? "Yes" : "No");
        Console.WriteLine("{0} {1} {2}", posW, posH, posD);
    }

    private static bool NextMove(string[, ,] cube)
    {
        string value = cube[posW, posH, posD];

        if (value == "E")
        {
            if (InBounderies(cube, posW, posH + 1, posD))
            {
                posH += 1;
                return true;
            }
            else
            {
                return false;
            }
        }
        else if (value == "B")
        {
            exit = false;
            return false;
        }
        else if (value.StartsWith("T"))
        {
            string pattern = @"\d+";
            MatchCollection matches = Regex.Matches(value, pattern);
            int width = int.Parse(matches[0].Value);
            int depth = int.Parse(matches[1].Value);

            //if (InBounderies(cube, width, posH, depth))
            //{
                posW = width;
                posD = depth;
                return true;
            //}
            //else
            //{
            //    exit = false;
            //    return false;
            //}
        }
        else if (value.StartsWith("S"))
        {
            int width = 0;
            int depth = 0;

            if (value.Contains("F")) depth -= 1;
            if (value.Contains("B")) depth += 1;
            if (value.Contains("L")) width -= 1;
            if (value.Contains("R")) width += 1;

            if (posH == cube.GetLength(1) - 1) return false;

            if (InBounderies(cube, posW + width, posH, posD + depth))
            {
                posW += width;
                posD += depth;
            }
            else
            {
                if (posH < cube.GetLength(1) - 1)
                {
                    exit = false;
                }
                return false;
            }

            if (InBounderies(cube, posW, posH + 1, posD))
            {
                posH += 1;
                return true;
            }
            else
            {
                return false;
            }
        }
        return false;
    }

    private static bool InBounderies(string[, ,] cube, int w, int h, int d)
    {
        return (w >= 0 && w < cube.GetLength(0) && h >= 0 && h < cube.GetLength(1) && d >= 0 && d < cube.GetLength(2));
    }

    private static string[, ,] GetInputData()
    {
        string[] dimensions = Console.ReadLine().Split(' ');
        int width = int.Parse(dimensions[0]);
        int height = int.Parse(dimensions[1]);
        int depth = int.Parse(dimensions[2]);

        string[, ,] cube = new string[width, height, depth];

        string pattern = @"\((?<value>.*?)\)";
        Regex re = new Regex(pattern);

        for (int h = 0; h < height; h++)
        {
            string[] dSequences = Console.ReadLine().Split('|');

            for (int d = 0; d < depth; d++)
            {
                MatchCollection matches = re.Matches(dSequences[d]);
                for (int w = 0; w < width; w++)
                {
                    cube[w, h, d] = matches[w].Groups["value"].Value;
                }
            }
        }

        string[] positions = Console.ReadLine().Split(' ');
        posW = int.Parse(positions[0]);
        posD = int.Parse(positions[1]);
        return cube;
    }
}