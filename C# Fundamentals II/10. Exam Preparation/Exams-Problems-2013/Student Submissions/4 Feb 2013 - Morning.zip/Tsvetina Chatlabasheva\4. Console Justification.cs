using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4.Text
{
    class Program
    {
        static string MakeStr(string[] words, int len)
        {
            StringBuilder b = new StringBuilder();
            b.Append(words[0]);
            b.Append(" ");
            while (b.Length<len)
            {
                for (int i = 1; i < words.Length; i++)
                {
                    if (b.Length + words[i].Length + 1 < len)
                    {
                        b.Append(words[i]);
                        b.Append(" ");
                    }
                    else
                    {
                        string result = b.ToString();
                        return result.Trim();

                    }
                }
                
            }
            string r = b.ToString();
            return r.Trim();
        }
        
        static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());
            int symbols = int.Parse(Console.ReadLine());
            string text = Console.ReadLine();
            char[] separator = new char[] { ' ', '\t', '\n' };
            string [] words = text.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            StringBuilder b = new StringBuilder();

            for (int i = 0; i < lines; i++)
            {
                Console.WriteLine(MakeStr(words, symbols));

            }
            

        }
    }
}