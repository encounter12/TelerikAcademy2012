using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
 * 
3 3 3
(S L)(E)(S L) | (S L)(S R)(S L) | (B)(S F)(S L)
(S B)(S F)(E) | (S B)(S F)(T 1 1) | (S L)(S R)(B)
(S FL)(S FL)(S FR) | (S FL)(S FL)(S FR) | (S F)(S BR)(S FR)
1 1
 * */


namespace za3
{
    class Program
    {
        static int ballW;
        static int ballD;
        static int ballH;
        static int w;
        static int h;
        static int d;

        static int prevW, prevD, prevH;
        static void setprev()
        {
            prevW = ballW;
            prevD = ballD;
            prevH = ballH;
        }

        static void tely(string x)
        {
            string[] rez = x.Split(' ');
            ballW = int.Parse(rez[1]);
            ballD = int.Parse(rez[2]);
        }

        static bool slid(string x)
        {
            string[] rez = x.Split(' ');
            string dir = rez[1];
            bool stuck = false;

            ballH++;

            if (h == ballH)
                return false;

            if (dir.Contains('L'))
            {
                ballW--;
                stuck = ballW < 0;
            }
            if (!stuck && dir.Contains('R'))
            {
                ballW++;
                stuck = ballW >= w;
            }
            if (!stuck && dir.Contains('F'))
            {
                ballD--;
                stuck = ballD < 0;
            }
            if (!stuck && dir.Contains('B'))
            {
                ballD++;
                stuck = ballD >= d;
            }


            return stuck;
        }

        static void Main(string[] args)
        {
            string[] sp = Console.ReadLine().Split(' ');
            w = int.Parse(sp[0]);
            h = int.Parse(sp[1]);
            d = int.Parse(sp[2]);

            string[, ,] m = new string[w, h, d];
            for (int i = 0; i < h; i++)
            {
                string input = Console.ReadLine();
                string[] i2 = input.Split(new string[]{" | "}, StringSplitOptions.None);
                for(int dep=0; dep<i2.Length; dep++)
                {
                    string[] roww = i2[dep].Split(new char[] { '(' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int wed = 0; wed < roww.Length; wed++)
                    {
                        m[wed,i,dep] = roww[wed].Trim(')');
                    }
                }
            }

            /*
            for (int ih = 0; ih < h; ih++)
            {
                for (int id = 0; id < d; id++)
                {
                    for(int iw=0; iw<w; iw++)
                        Console.Write(m[iw, ih, id]+" ");
                    Console.WriteLine();
                }
                Console.WriteLine("\n");
            }
            */
            string[] inpz = Console.ReadLine().Split(' ');
            ballW = int.Parse(inpz[0]);
            ballD = int.Parse(inpz[1]);
            ballH = 0;

            bool kil = false;
            while (ballH < h && !kil)
            {
                //Console.WriteLine("at position w{0} d{1} h{2}", ballW, ballD, ballH);
                string cmd = m[ballW, ballH, ballD];
                setprev();
                
                switch (cmd[0])
                {
                    case 'E': ballH++; break;
                    case 'B': kil = true; break;
                    case 'T': tely(cmd); break;
                    case 'S': kil = slid(cmd); break;
                }
            }

            Console.WriteLine("{0}\n{1} {2} {3}", kil ? "No" : "Yes", prevW, prevH, prevD);
        }
    }
}
