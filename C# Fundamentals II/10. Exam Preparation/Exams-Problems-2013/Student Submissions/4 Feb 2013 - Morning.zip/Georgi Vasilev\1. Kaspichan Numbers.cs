using System;

class KaspichanNumbers
{
    static void Main()
    {
        ulong input = ulong.Parse(Console.ReadLine());
        ulong final = input; 
        char[] capital = new char[26];
        for (int index = 0; index < capital.Length; index++)
        {
            capital[index] = (char)(index + 65);
        }

        char[] letters = new char[9];

        for (int index = 0; index < letters.Length; index++)
        {
            letters[index] = (char)(index + 97);
        }

        int pow = 1;
        ulong current = input;

        while (true)
        {
            current = current / 256;
            if (current > 256)
            {
                pow++;
            }
            else
            {
                break;
            }
        }
        string result = string.Empty;
        ulong digit = 1;
        if (input == 0)
        {
            Console.WriteLine("A");
        }
        else
        {
            for (int index = pow; index >= 0; index--)
            {
                digit = 1;
                for (int i = 0; i < index; i++)
                {
                    digit *= 256;
                }
                ulong factor = input / digit;
                input = input % digit;
                if (factor < 26)
                {
                    if (factor != 0)
                    {
                        result += capital[factor];
                    }
                }
                else
                {
                    result += letters[factor / 26 - 1];
                    result += capital[factor % 26];
                }
            }
            if (final % 256 == 0)
            {
                Console.WriteLine(result + "A");
            }
            else
            {
                Console.WriteLine(result);
            }
        }
    }
}
