using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KaspichanNumbers
{
    class KaspichanNumbers
    {
        static Dictionary<ulong, string> converter = new Dictionary<ulong,string>();

        static void Initialize()
        {
            for (uint i = 0; i <= 'i' - 'a' + 1; i++)
            {
                for (uint j = 0; j < 26; j++)
                {
                    string representation = "";
                    if (i == 0)
                    {
                        representation += (char)('A' + j);
                        //Console.WriteLine(i + " " + (i * 26 + j) + " " + representation);
                        converter.Add(i * 26 + j, representation);
                    }
                    else
                    {
                        representation += (char)('a' + i - 1);
                        representation += (char)('A' + j);
                        //Console.WriteLine(i + " " + (i * 26 + j) + " " + representation);
                        converter.Add(i * 26 + j, representation);
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            Initialize();

            ulong N = ulong.Parse(Console.ReadLine());

            ulong currNum = N;
            const int MOD = 256;
            StringBuilder numberInKaspichanDigits = new StringBuilder();

            if (currNum == 0)
            {
                Console.WriteLine(converter[currNum]);
            }
            else
            {

                while (currNum != 0)
                {
                    //Console.WriteLine(converter[currNum % MOD]);
                    numberInKaspichanDigits.Insert(0, converter[currNum % MOD]);
                    currNum /= MOD;
                }

                Console.WriteLine(numberInKaspichanDigits.ToString());
            }
        }
    }
}
