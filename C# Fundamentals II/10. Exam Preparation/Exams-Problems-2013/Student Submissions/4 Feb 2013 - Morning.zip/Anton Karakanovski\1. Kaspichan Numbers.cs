using System;

class Program
{
    static void Main()
    {
        decimal n = decimal.Parse(Console.ReadLine());
        
            decimal a = n % 256;
            decimal b = n / 256;
            decimal d;
        decimal c=0;
            while (b > 255)
            {
                c = b % 256;
                b = b / 256;
                if (c > 25)
                {
                    d = c % 26;
                    decimal small = c / 26;
                    Console.Write((char)(small + 96));
                    Console.Write((char)(d + 65));
                }
                else
                {
                    d = c % 26;
                    Console.Write((char)(d + 65));
                }
            }
        
            if (b >= 1 && b < 256)
            {
                Console.Write((char)(b + 65));
                if (a > 25)
                {
                    d = a % 26;
                    decimal small = a / 26;
                    Console.Write((char)(small + 96));
                    Console.Write((char)(d + 65));
                }
                else
                {
                    d = a % 26;
                    Console.Write((char)(d + 65));
                }
            }
            else
            {
                if (a > 25)
                {
                    d = a % 26;
                    decimal small = a / 26;
                    Console.Write((char)(small + 96));
                    Console.Write((char)(d + 65));
                }
                else
                {
                    d = a % 26;
                    Console.Write((char)(d + 65));
                }
            }
        
        Console.WriteLine();
    }
}