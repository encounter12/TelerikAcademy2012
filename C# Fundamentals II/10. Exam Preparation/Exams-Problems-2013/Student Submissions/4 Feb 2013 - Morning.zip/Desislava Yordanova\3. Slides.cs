using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
   
namespace JustExamPartII
{
    class JustExamPartII
    {
        class Coordinate
        {
            private int x;
            private int y;
            private int z;
   
            public Coordinate(int x, int y, int z)
            {
                this.x = x;
                this.y = y;
                this.z = z;
            }
            public int X
            {
                get
                {
                    return this.x;
                }
                set
                {
                    this.x = value;
                }
            }
   
            public int Y
            {
                get
                {
                    return this.y;
                }
                set
                {
                    this.y = value;
                }
            }
   
            public int Z
            {
                get
                {
                    return this.z;
                }
                set
                {
                    this.z = value;
                }
            }
        }
        static void Main(string[] args)
        {
            string dimensions = Console.ReadLine();
            string[] dimensionsList = dimensions.Split(' ');
            int width = int.Parse(dimensionsList[0]);
            int height = int.Parse(dimensionsList[1]);
            int depth = int.Parse(dimensionsList[2]);
            string[, ,] cuboid = new string[height, width, depth];
            string line;
            string[] lineDepth = new string[depth];
            string[] lineWidth = new string[width];
            for (int i = 0; i < height; i++)//Fill the rectangular cuboid from the console
            {
                line = Console.ReadLine();
                lineDepth = line.Split(new string[] { " | " }, StringSplitOptions.RemoveEmptyEntries);
                for (int k = 0; k < lineDepth.Length; k++)
                {
                    lineWidth = lineDepth[k].Trim().Split(new char[] {')'},StringSplitOptions.RemoveEmptyEntries);
                    for (int j = 0; j < lineWidth.Length; j++)
                    {
                        cuboid[i, j, k] = lineWidth[j].TrimStart('(');
                    }
                }
            }
   
            int ballW, ballD, ballH = 0;
            string[] ballPosition = Console.ReadLine().Split(' ');
            ballW =int.Parse(ballPosition[0]);
            ballD = int.Parse(ballPosition[1]);
            bool outBall = true;
            Coordinate cell = new Coordinate(ballH, ballW, ballD);
            Coordinate lastCell = cell;
            bool canGoOn = true;
            bool outside = false;
   
   
            while (true)
            {
   
                if (cell.X>=0 && cell.X<height && cell.Y>=0 && cell.Y<width && cell.Z>=0 && cell.Z<depth)
                {
                    cell = GoToNext(cell,cuboid,out canGoOn);
                    if (canGoOn && cell.X >= 0 && cell.X < height && cell.Y >= 0 && cell.Y < width && cell.Z >= 0 && cell.Z < depth)
                    {
                        lastCell = cell;
                    }
                    else
                    {
                        outside = true;
                    }
                      
                }
   
                if (!canGoOn)
                {
                    outBall=false;
                    break;
                }
   
                if (cell.Z < 0)
                {
                    outBall = true;
                    break;
                }
                if (outside)
                {
                    outBall = false;
   
                    break;
                }
   
                   
            }
            Console.WriteLine(outBall?"Yes":"No");
            Console.WriteLine("{0} {1} {2}", lastCell.Y, lastCell.X, lastCell.Z);
        }
   
        private static Coordinate GoToNext(Coordinate cell, string[, ,] cuboid,out bool move)
        {
            string direction = cuboid[cell.X, cell.Y, cell.Z];
            int newX = cell.X, newY=cell.Y, newZ=cell.Z;
            bool go = true;
   
            if (direction=="E")
            {
                newX++;
            }
            else if (direction=="B")
            {
                go = false;
            }
            else if (direction.StartsWith("T"))
            {
                string[] teleports = direction.Split(' ');
                newY = int.Parse(teleports[1]);
                newZ = int.Parse( teleports[2]);
            }
            else
            {
                string[] slides = direction.Split(' ');
                string newDirection = slides[1];
                if (newDirection.Length==1)
                {
                    if (newDirection=="R")
                    {
                        newY++;
                        newX++;
                    }
                    else if (newDirection=="L")
                    {
                        newY--;
                        newX++;
                    }
                    else if (newDirection=="B")
                    {
                        newX--;
                        newZ--;
                    }
                    else// newDirection=="F"
                    {
                        newX++;
                        newZ--;
                    }
                }
                else
                {
                    foreach (char symbol in slides[1])
                    {
                        if (symbol=='L')
                        {
                            newY--;
                        }
                        else if (symbol=='R')
                        {
                            newY++;
                        }
                        else if (symbol=='B')
                        {
                            newX--;
                            newZ--;
                        }
                        else if (symbol=='F')
                        {
                            newX++;
                            newZ--;
                        }
                    }
                }
                   
            }
               
            move = go;
               
            return new Coordinate(newX,newY,newZ);
        }
    }
}