using System;
using System.Collections.Generic;

namespace Slides
{
    class Program
    {
        static void Main(string[] args)
        {
            string dim = Console.ReadLine();
            string[] dimSplit = dim.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            int width = int.Parse(dimSplit[0].Trim());
            int height = int.Parse(dimSplit[1].Trim());
            int depth = int.Parse(dimSplit[2].Trim());

            string[, ,] cube = new string[height, depth, width];
            for (int h = 0; h < height; h++)
            {
                string row = Console.ReadLine();
                string[] rowSplit = row.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

                for (int d = 0; d < depth; d++)
                {
                    rowSplit[d] = rowSplit[d].Replace('(', '*').Trim();
                    rowSplit[d] = rowSplit[d].Replace(')', '*').Trim();
                    string[] contents = rowSplit[d].Split(new char[] { '*' }, StringSplitOptions.RemoveEmptyEntries);

                    for (int w = 0; w < width; w++)
                    {
                        cube[h, d, w] = contents[w];
                    }
                }
            }

            string ballWD = Console.ReadLine();
            string[] ballCoords = ballWD.Split(' ');
            int ballH = 0;
            int ballW = int.Parse(ballCoords[0]);
            int ballD = int.Parse(ballCoords[1]);

            while (true)
            {
                int h = ballH;
                int d = ballD;
                int w = ballW;
                string currPos = cube[h, d, w];
                
                if (currPos[0] == 'B')
                {
                    Console.WriteLine("No");
                    Console.WriteLine("{0} {1} {2}", w, h, d);
                    break;
                }
                else if (currPos[0] == 'E')
                {
                    h++;
                }
                else if (currPos[0] == 'T')
                {
                    string[] strSplit = currPos.Split(' ');
                    w = int.Parse(strSplit[1]);
                    d = int.Parse(strSplit[2]);
                }
                else
                {
                    h++;
                    string[] strSplit = currPos.Split(' ');
                    for (int i = 0; i < strSplit[1].Length; i++)
                    {
                        switch (strSplit[1][i])
                        {
                            case 'B':
                                d++;
                                break;
                            case 'L':
                                w--;
                                break;
                            case 'R':
                                w++;
                                break;
                            case 'F':
                                d--;
                                break;
                        }
                    }
                }

                if ((d < 0 || d == depth) && h != height)
                {
                    Console.WriteLine("No");
                    Console.WriteLine("{0} {1} {2}", ballW, ballH, ballD);
                    break;
                }
                else if ((w < 0 || w == width) && h != height)
                {
                    Console.WriteLine("No");
                    Console.WriteLine("{0} {1} {2}", ballW, ballH, ballD);
                    break;
                }
                else if ((d < 0 || d == depth) && h == height)
                {
                    Console.WriteLine("Yes");
                    Console.WriteLine("{0} {1} {2}", ballW, ballH, ballD);
                    break;
                }
                else if ((w < 0 || w == width) && h == height)
                {
                    Console.WriteLine("Yes");
                    Console.WriteLine("{0} {1} {2}", ballW, ballH, ballD);
                    break;
                }
                else if (h == height)
                {
                    Console.WriteLine("Yes");
                    Console.WriteLine("{0} {1} {2}", ballW, ballH, ballD);
                    break;
                }

                ballH = h;
                ballW = w;
                ballD = d;
            }
        }
    }
}
