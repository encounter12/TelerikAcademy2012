using System;
using System.Text;
using System.Numerics;

class KaspichanNumbers
{
    static void Main()
    {
        string input = Console.ReadLine();
        BigInteger number = BigInteger.Parse(input);
        BigInteger temp = number;
        char[] code = new char[]
        { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 
          'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
        char[] lower = new char[]
        { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };

        StringBuilder[] digits = new StringBuilder[256];
        for (int i = 0; i < 256; i++)
        {
            digits[i] = new StringBuilder();
        }
        for (int j = 26; j < 256; j++)
        {
            digits[j].Append(lower[j / 26 - 1]);
        }
        for (int i = 0; i < 256; i++)
        {
            digits[i].Append(code[i % 26]);
        }
        

        string result = "";
        BigInteger digit = 0;

        
        while (number != 0)
        {
            digit = number % 256;
            result = result.Insert(0, Convert.ToString(digits[(int)digit]));
            number /= 256;
        }
        if (temp == 0)
        {
            Console.WriteLine("A");
        }
        else
        {
            Console.WriteLine(result);

        }
    }
}
