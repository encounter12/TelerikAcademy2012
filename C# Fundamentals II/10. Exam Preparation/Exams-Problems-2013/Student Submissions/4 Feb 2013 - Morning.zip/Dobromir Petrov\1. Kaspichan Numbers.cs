using System;
using System.Collections.Generic;

class KaspichanNumbers
{
    static void Main()
    {
        ulong input = ulong.Parse(Console.ReadLine());
        string result = DecimalTo256Converter(input);
        Console.WriteLine(result);
    }
  
    private static void oldFromFirstExam()
    {
        sbyte N = sbyte.Parse(Console.ReadLine());
        int[] mas = new int[N];
        for (int i = 0; i < N; i++)
        {
            char tempVar = char.Parse(Console.ReadLine());
            mas[i] = (int)tempVar - '@';
        }

        double temp = 0;
        for (int i = 0, j = N - 1; i < N; i++, j--)
        {
            temp = temp + (double)mas[i] * Math.Pow(26, (double)j);
        }
        Console.WriteLine(temp);
    }

    static string DecimalTo256Converter(ulong number)
    {
        string result = string.Empty;
        List<string> reminder = new List<string>();
        char[] alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".ToCharArray();

        for (; number > 0; number /= 256)
        {
            ulong i = number % 256;
            if (i < 52)
            {
                
                if (i > 25 && i < 52)
                {
                    i = number % 26;
                    reminder.Add(alphabet[i].ToString());
                    i = i / 26;
                    reminder.Add(alphabet[i + 26].ToString());
                    continue;
                }
                reminder.Add(alphabet[i].ToString());
            }
            else if (i >= 52 && i < 256)
            {
                i = number % 26;
                reminder.Add(alphabet[i].ToString());
                i = i / 26;
                reminder.Add(alphabet[i + 26].ToString());
                continue;
            }
        }
       
        reminder.Reverse();
        result = string.Join("", reminder.ToArray());

        return result;
    }
}