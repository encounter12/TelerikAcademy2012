using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dw
{
    class dwarfs
    {
        static long maxSum = 0, currSum = 0;
        static List<int[]> mapsNumbers = new List<int[]>();
        static int[] valleyNumbers ;
        static int[] valleyVisited ;
        static int visitedIndex = 1;
        
        static void Main(string[] args)
        {
            
            string[] mapsNumString;
            string[] separators = {","," "};            
            //int currIndex = 0;
            string[] valleyNumsString = Console.ReadLine().Split(separators, StringSplitOptions.RemoveEmptyEntries);//"1,3,-6,7,4,1,12".Split(separators, StringSplitOptions.RemoveEmptyEntries);//
            valleyNumbers = new int[valleyNumsString.Length];
            valleyVisited = new int[valleyNumsString.Length];

            int[] map = new int[0];
            for (int i = 0; i < valleyNumsString.Length; i++)
            {
                valleyNumbers[i] = int.Parse(valleyNumsString[i]);
            }

            int numberMaps = int.Parse(Console.ReadLine());
            
            for (int i = 0; i < numberMaps; i++)
            {
                mapsNumString = Console.ReadLine().Split(separators, StringSplitOptions.RemoveEmptyEntries);
                map = new int[mapsNumString.Length];
                for (int next = 0; next < mapsNumString.Length; next++)
                {
                    map[next] = int.Parse(mapsNumString[next]);                    
                }
                CountCoins(map);
                
            }            
            Console.WriteLine(maxSum);

        }

        static void CountCoins(int[] map)
        {
            //for (int i = 0; i < mapsNumbers.Count; i++)
            //{
            int currIndex = 0 ;
                currSum = valleyNumbers[currIndex];
                valleyVisited[currIndex] = visitedIndex;

                for (int mapIndex = 0; mapIndex >= 0; mapIndex++)
                {
                    currIndex += map[mapIndex];
                    if (currIndex >= 0 && currIndex < valleyNumbers.Length)
                    {
                        if (valleyVisited[currIndex] != visitedIndex)
                        {
                            currSum += valleyNumbers[currIndex];
                            valleyVisited[currIndex] = visitedIndex;
                        }
                        else
                        {
                            if (currSum > maxSum)
                            {
                                maxSum = currSum;
                            }                            
                            visitedIndex++;
                            break;
                        }
                        if (mapIndex >= map.Length - 1)
                        {
                            mapIndex = -1;
                        }


                    }
                    else
                    {
                        if (currSum > maxSum)
                        {
                            maxSum = currSum;
                        }                        
                        visitedIndex++;
                        break;
                    }

                    
                }
            //}
        }
    }
}
