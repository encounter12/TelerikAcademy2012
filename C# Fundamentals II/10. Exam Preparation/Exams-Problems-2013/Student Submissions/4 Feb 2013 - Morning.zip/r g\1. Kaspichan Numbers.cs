using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication11
{
    class Program
    {
        static void Main()
        {
            char[] bigLetters = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            char[] smallLetters = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
            int number =  int.Parse(Console.ReadLine());

            int ans = 0;
            for (int i = 256; i < number; i = i + 256)
            {
                ans = number % i;
                Console.WriteLine(ans);
              
            }
            int one = 0;
            int devider = 0;
            string tursen = " ";
            if (ans ==0 && number >=0 && number <=25)
            {
                tursen = bigLetters[number].ToString();
            }

            else if (ans == 0 &&  number >= 25)
            {
                for (int i = 26; i < number; i=i+26)
                {
                    one = devider % i;
                    devider = devider / i;
                    if (one != 0 && devider != 0)
                    {
                        tursen = smallLetters[devider - 1].ToString() + bigLetters[one].ToString();
                    }
                }
            }

            if (ans != 0 && number >= 0 && number <= 25)
            {
                tursen = tursen = smallLetters[devider - 1].ToString() + bigLetters[one].ToString();
            }
            Console.WriteLine(tursen);
        }
    }
}