using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4._2._02.greedydwarf
{
    class Program
    {
        public static int calculateCoins(string[] valleyValues, string[] pattern)
        {
            int currentCoins = 0;
            int currentPos = 0;

            int valleyLength = valleyValues.Length;

            bool[] visited = new bool[valleyLength];
            int i = 0;

            while (visited[currentPos] == false)
            {
                visited[currentPos] = true;
                currentCoins += int.Parse(valleyValues[currentPos]);
                currentPos += int.Parse(pattern[i]);
                if (currentPos < 0 || currentPos > valleyLength-1)
                {
                    break;
                }
                i++;
                if (i >= pattern.Length)
                {
                    i = 0;
                }
            }
            return currentCoins;
        }


        static void Main(string[] args)
        {
            string valley = Console.ReadLine();
            int M = int.Parse(Console.ReadLine());
            string[] patterns = new string[M];
            for (int i = 0; i < M; i++)
            {
                patterns[i] = Console.ReadLine();
            }
            char[] delimeters = {',',' '};
            string[] valleyValues = valley.Split(delimeters, StringSplitOptions.RemoveEmptyEntries);
            string[] currentPattern = patterns[0].Split(delimeters, StringSplitOptions.RemoveEmptyEntries);
            int maximumCoins = calculateCoins(valleyValues, currentPattern);
            int currentCoins = 0;
            for (int i = 1; i < M; i++)
            {
                currentPattern = patterns[i].Split(delimeters, StringSplitOptions.RemoveEmptyEntries);
                currentCoins = calculateCoins(valleyValues, currentPattern);
                if (currentCoins > maximumCoins)
                {
                    maximumCoins = currentCoins;
                }
                currentCoins = 0;
            }
            Console.WriteLine(maximumCoins);

        }
    }
}
