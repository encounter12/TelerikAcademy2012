using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

class KaspichanNumbers
{
    static StringBuilder Add(BigInteger checker)
    {
        StringBuilder fucku = new StringBuilder();
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 26; j++)
            {
                if ((checker % 256) == (26 * i + j))
                {
                    if (i == 0)
                    {
                        fucku.Append((char)(((int)'A') + j));
                    }
                    else
                    {
                        fucku.Append((char)(((int)'a'-1) + i));
                        fucku.Append((char)(((int)'A') + j));
                    }
                }
            }
        }
        return fucku;
    }

    static void Main()
    {
        //BigInteger inputNumber = BigInteger.Parse(Console.ReadLine());
        List<string> kasp = new List<string>();
        BigInteger checker = BigInteger.Parse(Console.ReadLine());
        BigInteger clone = checker;       
        
        while (checker != 0)
        {
            kasp.Add(Add(checker).ToString());
            checker /= 256;
        }
        kasp.Reverse();
        foreach (var item in kasp)
        {
            Console.Write(item);
        }
        if (clone == 0)
        {
            Console.Write("A");
        }
        Console.WriteLine();
    }
}
