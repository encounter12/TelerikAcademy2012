using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
3 3 3
(S L)(E)(S L) | (S L)(S R)(S L) | (B)(S F)(S L)
(S B)(S F)(E) | (S B)(S F)(T 1 1) | (S L)(S R)(B)
(S FL)(S FL)(S FR) | (S FL)(S FL) (S FR) | (S F)(S BR)(S FR)
1 1
 */

class Program
{
    static void Main()
    {
        string[] dimensions = Console.ReadLine().Split(new char[] {' '}, StringSplitOptions.RemoveEmptyEntries);

        int W = int.Parse(dimensions[0]);
        int H = int.Parse(dimensions[1]);
        int D = int.Parse(dimensions[2]);

        string[, ,] cuboid = new string[W, H, D];

        for (int i = 0; i < H; i++)
        {
            string[] line = Console.ReadLine().Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

            for (int j = 0; j < D; j++)
            {
                string[] currentDepth = line[j].Split(new char[] {')'}, StringSplitOptions.RemoveEmptyEntries);

                for (int k = 0; k < W; k++)
                {
                    string temp = currentDepth[k].Trim();
                    cuboid[k, i, j] = temp.Substring(1);
                }
            }
        }

        string[] ballCoordinates = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        int ballW = int.Parse(ballCoordinates[0]);
        int ballD = int.Parse(ballCoordinates[1]);

        int currentHeight = 0;

        bool canExit = false; ;

        while (true)
        {
            string currentCommand = cuboid[ballW, currentHeight, ballD];

            if (currentCommand == "E")
            {
                currentHeight++;
                if (currentHeight >= H)
                {
                    canExit = true;
                    break;
                }
            }
            else if (currentCommand == "B")
            {
                canExit = false;
                break;
            }
            else if (currentCommand.Substring(0, 1) == "S")
            {
                currentHeight++;

                if (currentHeight >= H)
                {
                    canExit = true;
                    break;
                }

                if (currentCommand.Substring(2) == "B")
                {
                    ballD++;
                    if (ballD >= D)
                    {
                        canExit = false;
                        ballD--;
                        break;
                    }
                }
                else if (currentCommand.Substring(2) == "F")
                {
                    ballD--;
                    if (ballD < 0)
                    {
                        canExit = false;
                        ballD++;
                        break;
                    }
                }
                else if (currentCommand.Substring(2) == "L")
                {
                    ballW--;
                    if (ballW < 0)
                    {
                        canExit = false;
                        ballW++;
                        break;
                    }
                }
                else if (currentCommand.Substring(2) == "R")
                {
                    ballW++;
                    if (ballW >= W)
                    {
                        canExit = false;
                        ballW--;
                        break;
                    }
                }
                else if (currentCommand.Substring(2) == "BL")
                {
                    ballD++;
                    ballW--;
                    if (ballD >= D || ballW < 0)
                    {
                        ballD--;
                        ballW++;
                        canExit = false;
                        break;
                    }
                }
                else if (currentCommand.Substring(2) == "BR")
                {
                    ballD++;
                    ballW++;
                    if (ballD >= D || ballW >= W)
                    {
                        ballD--;
                        ballW--;
                        canExit = false;
                        break;
                    }
                }
                else if (currentCommand.Substring(2) == "FL")
                {
                    ballD--;
                    ballW--;
                    if (ballD < 0 || ballW < 0)
                    {
                        ballD++;
                        ballW++;
                        canExit = false;
                        break;
                    }
                }
                else if (currentCommand.Substring(2) == "FR")
                {
                    ballD--;
                    ballW++;
                    if (ballD < 0 || ballW > W)
                    {
                        ballD++;
                        ballW--;
                        canExit = false;
                        break;
                    }
                }

                //check cuboid
            }
            else if (currentCommand.Substring(0, 1) == "T")
            {
                string[] teleportCoordinations = cuboid[ballW, currentHeight, ballD].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                ballW = int.Parse(teleportCoordinations[1]);
                ballD = int.Parse(teleportCoordinations[2]);
            }
        }

        if (canExit)
        {
            Console.WriteLine("Yes");
            Console.WriteLine("{0} {1} {2}", ballW, currentHeight - 1, ballD);
        }
        else
        {
            Console.WriteLine("No");
            Console.WriteLine("{0} {1} {2}", ballW, currentHeight - 1, ballD);
        }
    }
}
