using System;

class KaspichanNumbers
{
    static void Main()
    {
        string[] kaspNum = new string[256];
        char First = 'A';
        for (int i = 0; i < 26; i++)
        {
            kaspNum[i] = Convert.ToString(First);
            First++;

        }
        First = 'A';
        for (int i = 26; i < 52; i++)
        {
            kaspNum[i] = "a" + Convert.ToString(First);
            First++;
        }
        First = 'A';
        for (int i = 52; i < 78; i++)
        {
            kaspNum[i] = "b" + Convert.ToString(First);
            First++;
        }
        First = 'A';
        for (int i = 78; i < 104; i++)
        {
            kaspNum[i] = "c" + Convert.ToString(First);
            First++;
        }
        First = 'A';
        for (int i = 104; i < 130; i++)
        {
            kaspNum[i] = "d" + Convert.ToString(First);
            First++;
        }
        First = 'A';
        for (int i = 130; i < 156; i++)
        {
            kaspNum[i] = "e" + Convert.ToString(First);
            First++;
        }
        First = 'A';
        for (int i = 156; i < 182; i++)
        {
            kaspNum[i] = "f" + Convert.ToString(First);
            First++;
        }
        First = 'A';
        for (int i = 182; i < 208; i++)
        {
            kaspNum[i] = "g" + Convert.ToString(First);
            First++;
        }
        First = 'A';
        for (int i = 208; i < 234; i++)
        {
            kaspNum[i] = "h" + Convert.ToString(First);
            First++;
        }
        First = 'A';
        for (int i = 234; i < 256; i++)
        {
            kaspNum[i] = "i" + Convert.ToString(First);
            First++;
        }
        First = 'A';

        ulong input = ulong.Parse(Console.ReadLine());
        int counter = 0;
        ulong temp = input;

        while (temp>0)
        {
            temp=temp/ 256;
            counter++;
        }

        string[] result=new string[counter];
        int resultInd = 0;
        if(input==0)
        {
            Console.WriteLine('A');
        }
        while (input > 0)
        { 
            ulong index = input % 256;
            input = input / 256;
            result[resultInd] = kaspNum[index];
            resultInd++;
        }
        for (int i = result.Length-1; i >= 0; i--)
        {
            Console.Write(result[i]);
        }
        Console.WriteLine();

    }
}