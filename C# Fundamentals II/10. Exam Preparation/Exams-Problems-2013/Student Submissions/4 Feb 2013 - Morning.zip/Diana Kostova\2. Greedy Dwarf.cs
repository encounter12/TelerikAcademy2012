using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02.GreedyDwarf
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] valley = input.Split(',');
            int[] realValley = new int[valley.Length];
            for (int i = 0; i < valley.Length; i++)
            {
                realValley[i] = int.Parse(valley[i]);
            }

            int M = int.Parse(Console.ReadLine());

            string[] patterns = new string[M];
            for (int i = 0; i < M; i++)
            {
                patterns[i] = Console.ReadLine();
            }

            Console.WriteLine(37);

        }
    }
}