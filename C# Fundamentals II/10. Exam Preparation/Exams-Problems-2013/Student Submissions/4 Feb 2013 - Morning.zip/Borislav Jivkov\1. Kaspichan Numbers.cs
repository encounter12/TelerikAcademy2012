using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace KaspichanNumbers
{
    class KaspichanNumbers
    {
        static void Main(string[] args)
        {
            BigInteger input = BigInteger.Parse(Console.ReadLine());
            string[] numArray = FillArray();
            var remainders = new List<BigInteger>();
            if (input != 0)
            {
                while (input > 0)
                {
                    remainders.Add(input % 256);
                    input /= 256;
                }
                remainders.Reverse();
                for (int i = 0; i < remainders.Count; i++)
                {
                    Console.Write(numArray[(long)remainders[i]]);
                }
            }
            else
            {
                Console.Write(numArray[0]);
            }
            Console.WriteLine();
        }

        private static string[] FillArray()
        {
            string[] tempArr = new string[256 * 256];
            StringBuilder myBuilder = new StringBuilder();
            char filler = 'A';
            for (int i = 0; i < 26; i++)
            {
                myBuilder.Append(filler.ToString() + " ");
                filler++;
            }
            filler = 'A';
            for (int i = 26; i < 52; i++)
            {
                myBuilder.Append("a" + filler.ToString() + " ");
                filler++;
            }
            filler = 'A';
            for (int i = 52; i < 78; i++)
            {
                myBuilder.Append("b" + filler.ToString() + " ");
                filler++;
            }
            filler = 'A';
            for (int i = 78; i < 104; i++)
            {
                myBuilder.Append("c" + filler.ToString() + " ");
                filler++;
            }
            filler = 'A';
            for (int i = 104; i < 130; i++)
            {
                myBuilder.Append("d" + filler.ToString() + " ");
                filler++;
            }
            filler = 'A';
            for (int i = 130; i < 156; i++)
            {
                myBuilder.Append("e" + filler.ToString() + " ");
                filler++;
            }
            filler = 'A';
            for (int i = 156; i < 182; i++)
            {
                myBuilder.Append("f" + filler.ToString() + " ");
                filler++;
            }
            filler = 'A';
            for (int i = 182; i < 208; i++)
            {
                myBuilder.Append("g" + filler.ToString() + " ");
                filler++;
            }
            filler = 'A';
            for (int i = 208; i < 234; i++)
            {
                myBuilder.Append("h" + filler.ToString() + " ");
                filler++;
            }
            filler = 'A';
            for (int i = 234; i < 256; i++)
            {
                myBuilder.Append("i" + filler.ToString() + " ");
                filler++;
            }
            for (int i = 256; i < 65536; i++)
            {
                myBuilder.Append(tempArr[i - 256] + tempArr[i - 255] + " ");
            }
            string tmp = myBuilder.ToString();
            tempArr = tmp.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            return tempArr;
        }
    }
}