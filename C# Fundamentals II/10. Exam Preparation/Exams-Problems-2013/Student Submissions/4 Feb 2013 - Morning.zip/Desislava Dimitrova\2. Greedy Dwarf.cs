using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dwarf
{
    class Program
    {
        static void Main(string[] args)
        {
            string valley= Console.WriteLine();
            int m = int.Parse(Console.ReadLine());
            for (int i = 0; i < m; i++)
            {
                string pattern = Console.WriteLine();
                int[] patternArr = int.Parse(pattern.Split(new char[] { ',', ' ' }));
            }
            int[] valleyArr=int.Parse(valley.Split(new char[]{',',' '}));
            
            int[] pattArr;
            //int[] valley = { 1, 3, -6, 7, 4, 1, 12 };
            //int[] pattOne = { 1, 2, -3 };
            //int[] patTwo = { 1, 3, -2 };
            //int[] patThree = { 1, -1 };
            //int sum1 = 0;
            //int sum2 = 0;
            //int sum3 = 0;
            //int patLen = pattOne.Length - 1;
            //int count = patLen;
            //List<int> positions = new List<int>();
            
            //    for (int i = 0; i < valley.Length; i += patLen - count)
            //    {
            //        if (count >= 0)
            //        {
            //            sum1 = sum1 + valley[i];
            //            count--;
            //            positions.Add(i);
            //        }
            //    }                      


            //Console.WriteLine(sum1);
    }
        
    }
}
            


        