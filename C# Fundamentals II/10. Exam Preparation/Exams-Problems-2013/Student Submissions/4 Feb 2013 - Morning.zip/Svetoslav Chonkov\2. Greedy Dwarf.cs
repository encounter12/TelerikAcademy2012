using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dwarf
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] valley = Console.ReadLine().Split(new char[] { ' ',',' },
                    StringSplitOptions.RemoveEmptyEntries);
            int m = int.Parse(Console.ReadLine());
            string[] patterntosplit = new string[100];
            string[] pattern = new string[100];
            int counter = 0;
            int[,] coins = new int[5,5];
            int[,] coins1 = new int[5,5];
            int tempStep = 0;
            int red = 0;
            for (int row = 0; row < m; row++)
            {
                tempStep = 0;
                patterntosplit = Console.ReadLine().Split(new char[] { ' ', ',' },
                    StringSplitOptions.RemoveEmptyEntries);

                for (int j = 0; j < patterntosplit.Length; j++,counter++)
                {
                    if (patterntosplit[j] == null)
                    {
                        break;
                    }
                    else
                    {
                        pattern[counter] = patterntosplit[j];
                    }
                 
                }
                int tempmax = 0;
                //coins
                for (int i = 0; i < patterntosplit.Length; i++)
                {
                    
                    //coins1[row,i]=int.Parse(patterntosplit[i]) - ;
                    tempStep += int.Parse(patterntosplit[i]);
                    // int.Parse(patterntosplit[i]);
                    coins[row,i]+=int.Parse(valley[tempStep]);
                    
                    tempmax += coins[row, i];
                }
                
                tempStep = 0;
                red++;
            }

           
            //string[] valleyparts = valley.Split(',');

        }
    }
}
