using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;


class KaspichanNumbers
{
    static void Main()
    {
        BigInteger number = BigInteger.Parse(Console.ReadLine());
        int remainder = 0;
        int tempRemainder = 0;
        StringBuilder kaspichanNumber = new StringBuilder();

        if (number != 0)
        {
            while (number != 0)
            {
                remainder = (int)(number % 256);
                if (remainder >= 0 && remainder <= 26)
                {
                    char num = (char)(remainder + 65);
                    kaspichanNumber.Append(num);
                }
                else if (remainder > 26)
                {
                    tempRemainder = remainder % 26;
                    remainder = remainder / 26;
                    char num1 = (char)((96 + remainder));
                    char num2 = (char)(tempRemainder + 65);
                    kaspichanNumber.Append(num2);
                    kaspichanNumber.Append(num1);
                }
                number = number / 256;

            }
            StringBuilder result = new StringBuilder();
            for (int i = kaspichanNumber.Length - 1; i >= 0; i--)
            {
                result.Append(kaspichanNumber[i]);
            }
            Console.WriteLine(result);
        }
        else
            Console.WriteLine('A');
    }
}
