using System;
using System.Collections.Generic;
using System.Text;

class GreedyDraft
{
    static void Main()
    {
        string line = Console.ReadLine();
        string[] pathString = line.Split(new char[] {',', ' '}, StringSplitOptions.RemoveEmptyEntries);
        int[] path = new int[pathString.Length];
        for (int i = 0; i < pathString.Length; i++)
		{
            path[i] = int.Parse(pathString[i]);
		}
        
        int patterns = int.Parse(Console.ReadLine());
        long collect = path[0];
        long maxcollect = long.MinValue;
        while (patterns > 0)
	    {
            bool[] pathBool = new bool[path.Length];
            pathBool[0] = true;
            int startStep = 0;
            string patternLine = Console.ReadLine();
            string[] patternString = patternLine.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int[] pattern = new int[patternString.Length];
            for (int i = 0; i < patternString.Length; i++)
            {
                pattern[i] = int.Parse(patternString[i]);
            }
            while (true)
            {
                
                bool forCondition = false;
                for (int i = 0; i < pattern.Length; i++)
                {
                    if ((startStep + pattern[i] > path.Length-1) ||
                        (startStep + pattern[i] < 0) ||
                        (pathBool[startStep + pattern[i]] == true))
                    {
                        forCondition = true;
                        break;                        
                    }
                    else
                    {
                        collect += path[startStep + pattern[i]];
                        pathBool[startStep + pattern[i]] = true;
                        startStep += pattern[i];                        
                    }
                }
                if (forCondition)
                {
                    break;
                }                
            }
            if (maxcollect < collect)
            {
                maxcollect = collect;
                collect = path[0];
            }
            patterns--;
	    }
        Console.WriteLine(maxcollect);
    }
}

