using System;
using System.Collections.Generic;
using System.Text;

class ConsoleJustification
{
    static void Main(string[] args)
    {
        string[] splitS = {" "};
        int rows = int.Parse(Console.ReadLine());
        int line = int.Parse(Console.ReadLine());
        StringBuilder sb = new StringBuilder();
        StringBuilder textArr = new StringBuilder();
        List<string> ls = new List<string>();
        int index = 0;
        for (int i = 0; i < rows; i++)
        {
            textArr.Append(" ");
            textArr.Append(Console.ReadLine());
        }
        String[] str = textArr.ToString().Split(splitS,StringSplitOptions.RemoveEmptyEntries);

        int countWordOnLine = -1;
        int currentWord = 0;
        int countChars = 0;
        bool bre = false;
        while (currentWord < str.Length)
        {
            while (countChars < line)
            {
                if (countWordOnLine == str.Length)
                {
                    break;
                }
                countWordOnLine++;

                if (countWordOnLine == str.Length)
                {
                    bre = true;
                    break;
                }
                countChars += str[countWordOnLine].Length + 1;

            }
            currentWord = countWordOnLine - 1;
            countChars = 0;

            for (int i = 0; i < currentWord; i++)
            {
                Console.Write(str[i] + " ");
            }
            countWordOnLine = 0;
            countChars = 0;
            Console.WriteLine();
            if (bre)
            {
                break; 
            }
        }
    }
}
