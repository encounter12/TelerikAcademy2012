using System;
using System.Text;
using System.Numerics;

class Numbers
{
    static void Main(string[] args)
    {
        BigInteger n = BigInteger.Parse(Console.ReadLine());
        Console.WriteLine(Convert(n));
    }

    public static string Convert(BigInteger n)
    {
        StringBuilder sb = new StringBuilder();
        BigInteger remainder;
        if (n == 0)
        {
            return "A";
        }
        while (n > 0)
        {
            remainder = n % 256;
            sb.Insert(0, GetDigit(remainder));
            n /= 256;
        }
        return sb.ToString();
    }

    public static string GetDigit(BigInteger n)
    {
        if (n < 26)
        {
            return ((char)('A' + n)).ToString();
        }
        BigInteger i = 26;
        char ch = 'a';
        while ((i+26) <= n)
        {
            ch++;
            i += 26;
        }
        
        char chB = 'A';

        while ((i+1) <= n)
        {
            chB++;
            i += 1;
        }
        return ch.ToString() + chB;
    }
}
