using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KaspichanNumbers
{
    class KaspichanNumbers
    {
        static void Main(string[] args)
        {
            char exc= 'a';
            long x;
            int j = 0;
           // long input = 280;
            long input;
            int digit=65;
            char[] rev = new char[2];
            StringBuilder sb = new StringBuilder();
            char[] kaspichan = new char[52];
            string[] num = new string[256];
            string result;
            char [] result2 = new char [256];

            input = long.Parse(Console.ReadLine());
            for (int i = 0; i < 26; i++)
            {
                kaspichan[i] = (char)digit;
                digit++;
                
            }
            for (int i = 0; i < 256; i++)
            {
                if (i<=25)
                {
                    num[i] = kaspichan[i].ToString();
                }
              
                
                if (i>=26 && i<=51)
                {
                    sb = sb.Append('a' + kaspichan[j].ToString());
                    num[i] = sb.ToString();
                    sb.Clear();
                    //num[i]

                    //num[i] = "a" + kaspichan[j].ToString();
                    j++;
                }
                
                if (i >= 52 && i <= 77)
                  
                {
                    if (i == 52)
                    {
                        j = 0;
                    }
                    sb = sb.Append('b' + kaspichan[j].ToString());
                    num[i] = sb.ToString();
                    sb.Clear();
                    j++;
                }


                if (i >= 78 && i <= 103)
                {
                    if (i == 78)
                    {
                        j = 0;
                    }
                    sb = sb.Append('c' + kaspichan[j].ToString());
                    num[i] = sb.ToString();
                    sb.Clear();
                    j++;
                }


                if (i >= 104 && i <= 129)
                {
                    if (i == 104)
                    {
                        j = 0;
                    }
                    sb = sb.Append('d' + kaspichan[j].ToString());
                    num[i] = sb.ToString();
                    sb.Clear();
                    j++;
                }


                if (i >= 130 && i <= 155)
                {
                    if (i == 130)
                    {
                        j = 0;
                    }
                    sb = sb.Append('e' + kaspichan[j].ToString());
                    num[i] = sb.ToString();
                    sb.Clear();
                    j++;
                }


                if (i >= 156 && i <= 181)
                {
                    if (i == 156)
                    {
                        j = 0;
                    }
                    sb = sb.Append('f' + kaspichan[j].ToString());
                    num[i] = sb.ToString();
                    sb.Clear();
                    j++;
                }


                if (i >= 182 && i <= 207)
                {
                    if (i == 182)
                    {
                        j = 0;
                    }
                    sb = sb.Append('g' + kaspichan[j].ToString());
                    num[i] = sb.ToString();
                    sb.Clear();
                    j++;
                }

                if (i >= 208 && i <= 233)
                {
                    if (i == 208)
                    {
                        j = 0;
                    }
                    sb = sb.Append('h' + kaspichan[j].ToString());
                    num[i] = sb.ToString();
                    sb.Clear();
                    j++;
                }

                if (i >= 234 && i <= 255)
                {
                    if (i == 234)
                    {
                        j = 0;
                    }
                    sb = sb.Append('i' + kaspichan[j].ToString());
                    num[i] = sb.ToString();
                  
                    sb.Clear();
                    j++;
                }
            }
           
            do
            {
                x = input % 256;
                sb = sb.Append(num[x]);
                input = input / 256;

            } while (input>0);

            result = sb.ToString();
           
            result2 = result.ToCharArray(0,result.Length);
            Array.Reverse(result2);
            for (int i = 0; i < result2.Length; i++)
            {
                if (i % 2 == 1 && i<result2.Length-1)
                {
                    exc = result2[i];
                    result2[i] = result2[i + 1];
                    result2[i + 1] = exc;

                }
            }
       
            Console.WriteLine(result2);
        }
    }
}
