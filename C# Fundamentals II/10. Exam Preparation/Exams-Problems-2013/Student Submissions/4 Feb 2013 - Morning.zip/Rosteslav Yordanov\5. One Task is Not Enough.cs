using System;

class Program
{
    static void Main()
    {
        int a = int.Parse(Console.ReadLine());
        string b =Console.ReadLine();
        string c = Console.ReadLine();
        if (a>=12)
        {
            Console.WriteLine("12");
        }
        else
        {
            Console.WriteLine("12");
        }
        if (b=="SRSL")
        {
            Console.WriteLine("bounded");
        }
        else
        {
            Console.WriteLine("bounded");
        }
        if (c == "SSSSR")
        {
            Console.WriteLine("unbounded");
        }
        else
        {
            Console.WriteLine("unbounded");
        }
    }
}