using System;
namespace OneTaskIsNotEnough
{
    class OneTaskIsNotEnough
    {
        static void Main()
        {
            Console.WriteLine("Enter the number of lamps N: ");
            int n = int.Parse(Console.ReadLine());
            for (int i = 1; i < n; i+=2)
            {
                Console.WriteLine(i);              
               
            }
            Console.WriteLine();
            for (int k = 2; k < n; k+=3)
            {
                Console.WriteLine(k);
            }
        }
    }
}
