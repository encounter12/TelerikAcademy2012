using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slides
{
    class Program
    {

        static void ProcessCube(string[, ,] cube, int startWidth, int startDepth)
        {
            string currentCube = cube[startWidth, 0, startDepth];
            int width = startWidth;
            int height = 0;
            int depth = startDepth;
            
            while (true)
            {
                char ch = currentCube[1];
                if (currentCube == "(B")
                {                  
                    Console.WriteLine("No");
                    Console.WriteLine(width + " " + height  + " " + depth);
                    return;
                }
                if (height == cube.GetLength(1))
                {
                    Console.WriteLine("Yes");
                        Console.WriteLine(width + " " + height  + " " + depth);
                        return;
                }               

                if (currentCube == "(E")
                {
                    if (height + 1 == cube.GetLength(1) - 1 && cube[width, height + 1, depth] != "B")  // tuka ne sym siguren dali e to4no 1
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine(startWidth + " " + height + 1 + " " + startDepth);
                        return;
                    }
                    height++;
                    currentCube = cube[width, height, depth];
                    continue;
                }
                
                if (ch == 'T')
                {
                    string coord = currentCube.Substring(1);
                    string[] tokens = coord.Split();
                    int telWidth = int.Parse(tokens[0]);
                    int telHeight = int.Parse(tokens[1]);
                    currentCube = cube[telWidth, height, telHeight];
                    width = telWidth;
                    height = telWidth;
                    continue;
                }
                string direction = currentCube.Substring(2).Trim();

                if (direction == "R")
                {
                    //width    
                    if (width >= cube.GetLength(0))
                    {
                        Console.WriteLine("No");
                    Console.WriteLine(width + " " + height  + " " + depth);
                    return;
                    }
                    height++;
                    width++;
                    currentCube= cube[width, height, depth];
                    continue;
                }
                if (direction == "L")
                {
                    height++;
                    width--;
                    if (width <= 0)
                    {
                        Console.WriteLine("No");
                        Console.WriteLine(width + " " + height + " " + depth);
                        return;
                    }
                    currentCube = cube[width, height, depth];
                    continue;
                }
                if (direction == "F")
                {
                    if (depth <= 0)
                    {
                        Console.WriteLine("No");
                        Console.WriteLine(width + " " + height + " " + depth);
                        return;
                    }
                    height++;
                    depth--;
                    currentCube = cube[width, height, depth];
                    continue;
                }
                if (direction == "B")
                {
                    height++;
                    depth++;
                    currentCube = cube[width, height, depth];
                    continue;
                }
                if (direction == "BL")
                {
                    height++;
                    width--;
                    depth++;
                    currentCube = cube[width, height, depth];
                    continue;
                }
                if (direction == "BR")
                {
                    height++;
                    width++;
                    depth++;
                    currentCube = cube[width, height, depth];
                    continue;
                }
                if (direction == "FL")
                {
                    height++;
                    width--;
                    depth--;
                    currentCube = cube[width, height, depth];
                    continue;
                }
                if (direction == "FR")
                {
                    height++;
                    width++;
                    depth--;
                    currentCube = cube[width, height, depth];
                    continue;
                }

            }
        }

        static void Main(string[] args)
        {
            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            int width = int.Parse(sizes[0]);
            int height = int.Parse(sizes[1]);
            int depth = int.Parse(sizes[2]);
            // Read the cuboid content
            string[, ,] cuboid = new string[width, height, depth];
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] sequences = line.Split('|');
                for (int d = 0; d < depth; d++)
                {
                    string[] numbers = sequences[d].Split(
                        new char[] { ')' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < width; w++)
                    {
                        cuboid[w, h, d] = numbers[w];
                    }
                }
            }
            string te = Console.ReadLine();
            string[] ty = te.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int first = int.Parse(ty[0]);
            int second = int.Parse(ty[1]);
            ProcessCube(cuboid, first, second);
          

        }
    }
}
