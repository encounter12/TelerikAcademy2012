using System;

class Dwarf
{

    static string valley = Console.ReadLine();
    static string[] valleyArray = valley.Split(',');
    static int[] arr = new int[valleyArray.Length];
    static int sum = arr[0];
    static int Spatt = 0;
    static int before = 0;
    static int recArr(int[] arr, int[,] pattern , int j) {
        for (int i = 0; i < pattern.GetLength(0); i++)
        {
            Spatt = Spatt + pattern[j,i];
            sum += arr[Spatt];
            if (Spatt > arr.Length || Spatt < 0)
            {
                return sum;
            }
            if (Spatt == 0) {
                return sum;
            }
        }
        if (arr.Length - Spatt > Spatt) {
            return recArr(arr, pattern , j);
        }
        else return sum;
    }

    static void Main()
    {
        for (int i = 0; i < valleyArray.Length; i++)
        {
            arr[i] = int.Parse(valleyArray[i]);
        }
        //arr---------
        int num = int.Parse(Console.ReadLine());
        int[,] pattern = new int[num,100];
        for (int i = 0; i < num; i++)
        {
            string row = Console.ReadLine();
            string[] cell = row.Split(',');
        
            for (int j = 0; j < cell.Length; j++)
            {
                pattern[i, j] = int.Parse(cell[j]);
            }
        }

        for (int i = 0; i < num; i++)
        {
            for (int j = 0;  j < pattern.GetLength(1); j++)
            {
                Console.WriteLine(pattern[i, j]);
            }
        }

        int[] sums = new int[num];
        for (int j = 0; j < num; j++)
        {
            sums[j] = recArr(arr,pattern,j);
            Console.WriteLine(sums[j]);
        }

        int max = 0;
        for (int i = 0; i < sums.Length; i++)
        {
            if (sums[i] > max) {
                max = sums[i];
            }
        }
        Console.WriteLine(max);
        //Console.WriteLine(pattern[0,2]);
       //Console.Write(recArr(arr, second));
    }
}

