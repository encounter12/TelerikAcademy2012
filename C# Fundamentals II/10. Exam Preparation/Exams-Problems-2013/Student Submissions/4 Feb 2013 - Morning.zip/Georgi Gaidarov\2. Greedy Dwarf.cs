using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/*
1, 3, -6, 7, 4,1, 12
3
1, 2, -3
1, 3, -2
1, -1
 * */
namespace za2
{
    class Program
    {
        static int calc(string[] v, string[] p)
        {
            int sum = int.Parse(v[0]);
            int vals = v.Length;
            bool[] visited = new bool[v.Length];
            visited[0] = true;
            int atpos = 0;
            int i = 0;
            while(true)
            {
                string s = p[i];
                i++;
                i %= p.Length;
                int pat = int.Parse(s);
                if(atpos + pat >= 0 && atpos + pat < vals && !visited[atpos + pat])
                {
                    atpos += pat;
                    visited[atpos] = true;
                    sum += int.Parse(v[atpos]);

                }
                else break;
            }


            return sum;
        }
        static void Main(string[] args)
        {
            string[] v = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            int n = int.Parse(Console.ReadLine());
            int mx = int.MinValue;
            for (int i = 0; i < n; i++)
            {
                string[] p = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
                mx = Math.Max(mx, calc(v, p));
            }
            Console.WriteLine(mx);
        }
    }
}
