using System;
using System.Collections.Generic;
using System.Numerics;

class KaspichanNumbers
{
    static void Main()
    {
        string[] digits = new string[256];

        int counter = 0;
        char ch = (char)('a'-1);
        for (int i = 0; i < digits.Length; i++)
        {
            string temp = "";
            if (i > 25)
            {
                
                temp += ch;
                
            }

            if (counter == 25)
            {
                counter = -1;
                ch = (char)(ch + 1);
            }

            digits[i] = temp + (char) ('A' + (i%26));
            counter++;
        }

        BigInteger n = BigInteger.Parse(Console.ReadLine());
        List<string> result = new List<string>();
        if (n == 0)
        {
            result.Add("A");
        }
        while (n > 0)
        {
            result.Add(digits[(int)(n % 256)]);
            n = n / 256;
        }

        for (int j = result.Count-1; j >= 0; j--)
        {
            Console.Write(result[j]);
        }

        Console.WriteLine();
    }
}