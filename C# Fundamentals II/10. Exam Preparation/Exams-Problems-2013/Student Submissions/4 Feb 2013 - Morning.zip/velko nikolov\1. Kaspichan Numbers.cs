using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;
namespace exam
{
    class Program
    {
static void Main(string[] args) {
    var temp = ulong.Parse(Console.ReadLine());
    var ret = "";
    if (temp == 0) {
        Console.WriteLine("A");
    }
    while (temp > 0) {
        var digit = temp % 256;
        var low  = digit % 26;
        var high = (digit / 26) % 10;
        ret = (char)('A' + low) + ret;
        if (high > 0) {
            ret = (char)('a' + high - 1) + ret;
        }
        temp /= 256;
        /*ret = ("" + (char)('A' + (last % 26))) + ret;
        temp /= 26;
        if (temp > 0) {
            ret = ("" + (char)('a' + temp % 10 - 1)) + ret;
            temp /= 10;
        }*/
    }

    Console.WriteLine(ret);
}
    }
}

