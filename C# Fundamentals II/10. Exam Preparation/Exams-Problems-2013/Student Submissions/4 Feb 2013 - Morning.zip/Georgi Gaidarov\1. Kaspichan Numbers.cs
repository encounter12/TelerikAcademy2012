using System;

class Kaspichan
{
    static int count = 0;

    static char getID(int num){
        return Convert.ToChar(num + 65);
    }

    static char getFirstLetter(int num) {
        if (num <= 51 && num > 25)
        {
            return Convert.ToChar(count + 97);
        }
        else
        {
            count++;
            return getFirstLetter(num - 26);
        }
    }

    static void Main()
    {
        int num = int.Parse(Console.ReadLine());
        if (num >= 0 && num < 26)
        {
            Console.WriteLine(getID(num));
        }
        //Console.WriteLine(firstLetter);
        //Console.WriteLine(getID(num - (count+1) * 26));
        else
        {
            char firstLetter = getFirstLetter(num);
            char[] allLetters = new char[20];
            allLetters[0] = firstLetter;
            allLetters[1] = getID(num - (count + 1) * 26);
            Console.WriteLine(allLetters);
        }
    }
}

