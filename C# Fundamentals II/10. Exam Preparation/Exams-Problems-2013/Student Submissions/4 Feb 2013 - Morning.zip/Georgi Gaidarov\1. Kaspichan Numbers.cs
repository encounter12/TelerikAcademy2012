using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Telerik500_secondtime
{
    class Program
    {
        static string demap(int x)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append((char)(x % 26 + 'A'));
            x /= 26;
            if(x>0)
            sb.Append((char)(x % 26 -1 + 'a'));
            StringBuilder sb2 = new StringBuilder();
            for (int i = sb.ToString().Length - 1; i >= 0; i--)
                sb2.Append(sb.ToString()[i]);
            return sb2.ToString();

        }
        static void Main(string[] args)
        {
            /*
            Console.WriteLine(demap(1));
            Console.WriteLine(demap(26));
            Console.WriteLine(demap(255));
             * */
            ulong x = ulong.Parse(Console.ReadLine());
            StringBuilder sb = new StringBuilder();
            List<string> l = new List<string>();
            l.Add(demap((int)(x % 256)));
            x /= 256;
            while (x > 0)
            {
                l.Add(demap((int)(x % 256)));
                x /= 256;
            }
            for (int i = l.Count - 1; i >= 0; i--)
                sb.Append(l[i]);
            Console.WriteLine(sb.ToString());
        }
    }
}
