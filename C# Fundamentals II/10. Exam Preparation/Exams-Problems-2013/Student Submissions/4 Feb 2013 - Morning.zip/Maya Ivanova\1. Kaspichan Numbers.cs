using System;
using System.Collections.Generic;

class KaspichanNUmbers
{
    public static decimal GetTheCipher(decimal number)
    {
        Dictionary<decimal, string> dictionary = new Dictionary<decimal, string>();
        dictionary.Add(0, "A");
        dictionary.Add(1, "B");
        dictionary.Add(2, "C");
        dictionary.Add(3, "D");
        dictionary.Add(4, "E");
        dictionary.Add(5, "F");
        dictionary.Add(6, "G");
        dictionary.Add(7, "H");
        dictionary.Add(8, "I");
        dictionary.Add(9, "J");
        dictionary.Add(10, "K");
        dictionary.Add(11, "L");
        dictionary.Add(12, "M");
        dictionary.Add(13, "N");
        dictionary.Add(14, "O");
        dictionary.Add(15, "P");
        dictionary.Add(16, "Q");
        dictionary.Add(17, "R");
        dictionary.Add(18, "S");
        dictionary.Add(19, "T");
        dictionary.Add(20, "U");
        dictionary.Add(21, "V");
        dictionary.Add(22, "W");
        dictionary.Add(23, "X");
        dictionary.Add(24, "Y");
        dictionary.Add(26, "aA");
        dictionary.Add(27, "aB");
        dictionary.Add(28, "aC");
        dictionary.Add(29, "aD");
        dictionary.Add(30, "aE"); 
        dictionary.Add(31, "aF");
        dictionary.Add(32, "aG");
        dictionary.Add(33, "aH");
        dictionary.Add(34, "aI");
        dictionary.Add(35, "aJ");
        dictionary.Add(36, "aK");
        dictionary.Add(37, "aL");
        dictionary.Add(38, "aM");
        dictionary.Add(39, "aN");
        dictionary.Add(40, "aO");
        dictionary.Add(41, "aP");
        dictionary.Add(42, "aQ");
        dictionary.Add(43, "aR");
        dictionary.Add(44, "aS");
        dictionary.Add(45, "aT");
        dictionary.Add(46, "aU");
        dictionary.Add(47, "aV");
        dictionary.Add(48, "aW");
        dictionary.Add(49, "aX");
        dictionary.Add(50, "aY");
        dictionary.Add(51, "aY");

        foreach (var entry in dictionary)
        {
            if (entry.Key == number)
            {
                Console.WriteLine(entry.Value);
            }
        }
        return number;
    }


    static void Main()
    {
        decimal number = decimal.Parse(Console.ReadLine());

        if (number <= 255)
        {
            GetTheCipher(number);
        }

    }
}

