using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace _4. Console Justification
{
    class Program
    {
        static bool isQuoted = false;
        static bool isComment = false;
        static bool isLongComment = false;
 
        static void Main(string[] args)
        {
            int lengthLines = int.Parse(Console.ReadLine());
            string[] lines = new string[lengthLines];
            string[] editedLines = new string[lengthLines];
 
            for (int i = 0; i < lengthLines; i++)
            {
                lines[i] = Console.ReadLine();
            }
            for (int i = 0; i < lengthLines; i++)
            {
                editedLines[i] = RemoveComments(lines[i]);
                if (isLongComment == true)
                {
                    int start = i;
                    while (isLongComment == true)
                    {
                        editedLines[i] += RemoveComments(lines[start]);
                        start++;
                    }
                    i = start - 1;
                }
            }
            for (int i = 0; i < editedLines.Length; i++)
            {
                if (editedLines[i] != null && editedLines[i].Trim().Length != 0)
                {
                    Console.WriteLine(editedLines[i]);
                }
            }
        }
 
        private static string RemoveComments(string lines)
        {
            List<char> editedLine = new List<char>();
            int length = lines.Length;
            for (int i = 0; i < length; i++)
            {
                if (isQuoted == true)
                {
                    //string str2 = "/*no\"oo\\oo*/";
                    while (i < length && lines[i] != '"')
                    {
 
                        editedLine.Add(lines[i]);
                        if (lines[i] == '\\' && i + 1 < length && lines[i + 1] == '"')
                        {
                            editedLine.Add(lines[i + 1]);
                            i++;
                        }
                        i++;
                    }
                    if (i < length && lines[i] == '"')
                    {
                        editedLine.Add(lines[i]);
                        isQuoted = false;
                    }
                }
                else if (isLongComment == true)
                {
                    int index = lines.IndexOf("*/");
                    if (index == -1)
                    {
                        break;
                    }
                    else
                    {
                        i = index + 1;
                        isLongComment = false;
                    }
                }
                else if (lines[i] == '"')
                {
                    if (i-1>0 && lines[i-1] != '\\')
                    {
                        isQuoted = true;    
                    }
                   
                    editedLine.Add(lines[i]);
                }
                else if (lines[i] == '/')
                {
                    if (i + 1 < length && lines[i + 1] == '/')
                    {
                        if (i + 2 < length &&  lines[i + 2] == '/')
                        {
                            editedLine.Add(lines[i]);
                            editedLine.Add(lines[i]);
                            editedLine.Add(lines[i]);
                            i=i+2;
                        }
                        else
                        {
                            break;
                        }
                    }
                    else if (i + 1 < length && lines[i + 1] == '*')
                    {
                        isLongComment = true;
                    }
                    else
                    {
                        editedLine.Add(lines[i]);
                    }
 
                }
                else
                {
                    editedLine.Add(lines[i]);
                }
            }
 
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < editedLine.Count; i++)
            {
                result.Append(editedLine[i]);
            }
 
            return result.ToString();
        }
 
    }
}