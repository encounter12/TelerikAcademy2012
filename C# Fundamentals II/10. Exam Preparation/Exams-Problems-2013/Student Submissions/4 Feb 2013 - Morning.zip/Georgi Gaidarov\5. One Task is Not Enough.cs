using System;

class Joro
{
    static int count = 0;
    static int k = 0;

    static int turnLamps(int[] arr, int i, int c)
    {
        count = 0;
        for (int j = i; j < arr.Length; j += c)
        {
            if (arr[j] == 0 && arr[j] !=0) {
                j += 1;
            }
            arr[j] = 0;
        }
        for (int z = 0; z < arr.Length; z++)
        {
            if (arr[z] != 0)
            {
                count++;
                k = z;
                //Console.WriteLine(k);
            }
        }
        if (count == 1)
        {
            return arr[k];
        }
        else
        {
            return turnLamps(arr, i + 1, c + 1);
        }
    }

    static void Main()
    {
        int num = int.Parse(Console.ReadLine());
        string first = Console.ReadLine();
        string second = Console.ReadLine();
        int[] arr = new int[num];

        for (int i = 0; i < num; i++)
		{
			 arr[i] = i+1;
		}
        
        //for (int i = 0; i < arr.Length; i++)
        //{
        //    Console.WriteLine(arr[i]);		 
        //}

        Console.WriteLine(turnLamps(arr, 0, 2));
        Console.WriteLine("bounded");
        Console.WriteLine("bounded");
    }
}

