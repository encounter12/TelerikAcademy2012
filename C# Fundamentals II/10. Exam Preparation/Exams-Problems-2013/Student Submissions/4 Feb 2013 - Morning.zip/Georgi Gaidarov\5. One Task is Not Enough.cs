using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace za5
{
    class Program
    {
        static int solve1(int x)
        {
            if(x<=2) return x;
            List<int> q = new List<int>();
            for (int i = 2; i <= x; i += 2)
                q.Add(i);
 
            for(int i=2; i<=x && q.Count > 1; i++)
            {
                for (int j = 0; j < q.Count && q.Count > 1; j += i)
                    q.RemoveAt(j);
 
            }
 
            return q[0];
        }
        static string solve2(string x)
        {
            int sum = 0 ;
            foreach (char c in x)
                if (c == 'R')
                    sum++;
                else if (c == 'L')
                    sum--;
            return sum == 0 ? "unbounded" : "bounded";
        }
        static void Main(string[] args)
        {
            Console.WriteLine("{0}\n{1}\n{2}", solve1(int.Parse(Console.ReadLine())), solve2(Console.ReadLine()), solve2(Console.ReadLine()));
        }
    }}