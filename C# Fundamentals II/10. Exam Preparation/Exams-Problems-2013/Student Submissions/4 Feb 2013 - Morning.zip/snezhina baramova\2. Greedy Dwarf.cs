 class Program
    {
        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            int[] valleyNums = line.Split(',').Select(n => int.Parse(n.Trim())).ToArray();
            int start = valleyNums[0];
            int position = 0;

            int numOfPatterns = int.Parse(Console.ReadLine());
            int[][] numsInPattern = new int[numOfPatterns][];


            string onePattern;
            for (int i = 0; i < numOfPatterns; i++)
            {
                onePattern = Console.ReadLine();
                numsInPattern[i] = (onePattern.Split(',').Select(n => int.Parse(n.Trim())).ToArray());
            }

                    int bestSum = int.MinValue;
                    List<int> positions = new List<int>();
                    for (int k = 0; k < valleyNums.Length; k++)
                    {        
                        for (int i = 0; i < numsInPattern.Length; i++)
                    {
                        for (int j = 0; j < numsInPattern[i].Length; j++)
                    {
                        
                        start = valleyNums[0];
                        position += 0 + numsInPattern[i][j];
                        positions.Add(position);
                        int sum = start;
                        foreach (int pos in positions)
                        {
                            if (position != pos)
                            {
                                sum += valleyNums[position];
                            }
                            else
                            {
                                i++;
                                j = 0;
                                if (sum > bestSum)
                                {
                                    positions.Clear();
                                    bestSum = sum;
                                }
                            }
                        }
                    }

                }
            }

        }
    }