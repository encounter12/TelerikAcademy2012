using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02.GreedyDwarf
{
    class Program
    {
        static void Main(string[] args)
        {

            string valleyString = Console.ReadLine();
            string[] valleyStrings = valleyString.Split(new[] { ", " }, StringSplitOptions.None);
            short[] valley = new short[valleyStrings.Length];
            for (int i = 0; i < valley.Length; i++)
            {
                valley[i] = short.Parse(valleyStrings[i]);
            }
            int patternCount = int.Parse(Console.ReadLine());
            string[][] patternStrings = new string[patternCount][];
            short[][] patterns = new short[patternCount][];
            for (int i = 0; i < patternCount; i++)
            {
                patternStrings[i] = Console.ReadLine().Split(new[] { ", " }, StringSplitOptions.None);
                patterns[i] = new short[patternStrings[i].Length];
                for (int k = 0;     k < patternStrings[i].Length; k++)
                {
                    
                    patterns[i][k] = short.Parse(patternStrings[i][k]);
                }
            }

            int bestResult = int.MinValue;
            for (int i = 0; i < patternCount; i++)
            {
                int currentResult = PatternResult(valley, patterns[i]);
                if (currentResult > bestResult)
                {
                    bestResult = currentResult;
                }
            }
            Console.WriteLine(bestResult);


        }

        static int PatternResult(short[] valley, short[] pattern)
        {
            bool[] visited = new bool[valley.Length];
            int result = 0;
            short index = 0;
            short patternIndex = 0;
            while (true)
            {
                if (index >= valley.Length || index < 0 ||visited[index] == true )
                    break;
                else
                {
                    if (patternIndex >= pattern.Length)
                        patternIndex = 0;
                    result += valley[index];
                    visited[index] = true;
                    index += pattern[patternIndex];
                    patternIndex++;
                }
            }
            return result;
        }
    }
}
