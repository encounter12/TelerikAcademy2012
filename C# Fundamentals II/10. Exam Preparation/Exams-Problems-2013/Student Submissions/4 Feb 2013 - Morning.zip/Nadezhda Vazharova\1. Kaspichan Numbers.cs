using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KAsp
{
    class Program
    {
        static void Main(string[] args)
        {
            ulong number = ulong.Parse(Console.ReadLine());

            StringBuilder convertedNumber = new StringBuilder();
            int digit = 0;
            int letter = 0;
            while (number > 0)
            {
                digit = (int)(number % 256);
                number = (number / 256);
                
                
                if (digit > 25)
                {
                    
                    
                        letter = digit % 26;
                        digit = digit / 26;
                        
                        switch (letter)
                            {
                                case 0: convertedNumber.Append("A"); break;
                                case 1: convertedNumber.Append("B"); break;
                                case 2: convertedNumber.Append("C"); break;
                                case 3: convertedNumber.Append("D"); break;
                                case 4: convertedNumber.Append("E"); break;
                                case 5: convertedNumber.Append("F"); break;
                                case 6: convertedNumber.Append("G"); break;
                                case 7: convertedNumber.Append("H"); break;
                                case 8: convertedNumber.Append("I"); break;
                                case 9: convertedNumber.Append("J"); break;
                                case 10: convertedNumber.Append("K"); break;
                                case 11: convertedNumber.Append("L"); break;
                                case 12: convertedNumber.Append("M"); break;
                                case 13: convertedNumber.Append("N"); break;
                                case 14: convertedNumber.Append("O"); break;
                                case 15: convertedNumber.Append("P"); break;
                                case 16: convertedNumber.Append("Q"); break;
                                case 17: convertedNumber.Append("R"); break;
                                case 18: convertedNumber.Append("S"); break;
                                case 19: convertedNumber.Append("T"); break;
                                case 20: convertedNumber.Append("U"); break;
                                case 21: convertedNumber.Append("V"); break;
                                case 22: convertedNumber.Append("W"); break;
                                case 23: convertedNumber.Append("X"); break;
                                case 24: convertedNumber.Append("Y"); break;
                                case 25: convertedNumber.Append("Z"); break;
                                default: break;
                            } 
                        switch (digit)
                        {
                            case 1: convertedNumber.Append("a"); break;
                            case 2: convertedNumber.Append("b"); break;
                            case 3: convertedNumber.Append("c"); break;
                            case 4: convertedNumber.Append("d"); break;
                            case 5: convertedNumber.Append("e"); break;
                            case 6: convertedNumber.Append("f"); break;
                            case 7: convertedNumber.Append("g"); break;
                            case 8: convertedNumber.Append("h"); break;
                            case 9: convertedNumber.Append("i"); break;
                            default: break;
                        }
                        
                    }
                
                else 
                {
                    switch (digit)
                    {
                        case 0: convertedNumber.Append("A"); break;
                        case 1: convertedNumber.Append("B"); break;
                        case 2: convertedNumber.Append("C"); break;
                        case 3: convertedNumber.Append("D"); break;
                        case 4: convertedNumber.Append("E"); break;
                        case 5: convertedNumber.Append("F"); break;
                        case 6: convertedNumber.Append("G"); break;
                        case 7: convertedNumber.Append("H"); break;
                        case 8: convertedNumber.Append("I"); break;
                        case 9: convertedNumber.Append("J"); break;
                        case 10: convertedNumber.Append("K"); break;
                        case 11: convertedNumber.Append("L"); break;
                        case 12: convertedNumber.Append("M"); break;
                        case 13: convertedNumber.Append("N"); break;
                        case 14: convertedNumber.Append("O"); break;
                        case 15: convertedNumber.Append("P"); break;
                        case 16: convertedNumber.Append("Q"); break;
                        case 17: convertedNumber.Append("R"); break;
                        case 18: convertedNumber.Append("S"); break;
                        case 19: convertedNumber.Append("T"); break;
                        case 20: convertedNumber.Append("U"); break;
                        case 21: convertedNumber.Append("V"); break;
                        case 22: convertedNumber.Append("W"); break;
                        case 23: convertedNumber.Append("X"); break;
                        case 24: convertedNumber.Append("Y"); break;
                        case 25: convertedNumber.Append("Z"); break;
                        default: break;
                    }
                }
            }

            convertedNumber.ToString();
            for (int i = convertedNumber.Length - 1; i >= 0; i--)
            {
                Console.Write(convertedNumber[i]);
            }
            
                
        }
    }
}
