using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace KaspichanNumbers
{

    class KaspichanNumbers
    {
        static string Base10ToBaseX(int d, int x)
        {
            List<int> result = new List<int>();
            string h = String.Empty;

            for (; d != 0; d /= x)
            {
                result.Add(0);
                h = (d % x) + h;
            }

            return h;
        }

        static void Main(string[] args)
        {
            string[] digits = new string[256];
            for (int i = 0; i < 256; i++)
            {
                if (i<26)
                {
                    digits[i] = ((char)('A' + i)).ToString();
                }
                else if (i<52)
                {
                    digits[i]='a'+ ((char)('A' + i-26)).ToString();
                }
                else if (i<78)
                {
                    digits[i] = 'b' + ((char)('A' + i - 52)).ToString();
                }
                else if (i<104)
                {
                    digits[i] = 'c' + ((char)('A' + i - 78)).ToString();
                }
                else if (i<130)
                {
                    digits[i] = 'd' + ((char)('A' + i - 104)).ToString();
                }
                else if (i<156)
                {
                    digits[i] = 'e' + ((char)('A' + i - 130)).ToString();
                }
                else if (i<182)
                {
                    digits[i] = 'f' + ((char)('A' + i - 156)).ToString();
                }
                else if (i<208)
                {
                    digits[i] = 'g' + ((char)('A' + i - 182)).ToString();
                }
                else if (i<234)
                {
                    digits[i] = 'h' + ((char)('A' + i - 208)).ToString();
                }
                else
                {
                    digits[i] = 'i' + ((char)('A' + i - 234)).ToString();
                }
            }


            //Console.WriteLine(digits[Base10ToBaseX(num, 256)]);
            List<int> result = new List<int>();
            int index = 0;
            BigInteger num = BigInteger.Parse(Console.ReadLine());            
            
                if (num==0)
                {
                    result.Add(0);
                    result[index] = 0;
                }
                while (num > 0)
                {
                    result.Add(0);
                    result[index] = (int)(num % 256);
                    index++;
                    num /= 256;
                }
                result.Reverse();
                foreach (var digit in result)
                {
                    Console.Write(digits[digit]);
                }
                Console.WriteLine();
            }
        
    }
}
