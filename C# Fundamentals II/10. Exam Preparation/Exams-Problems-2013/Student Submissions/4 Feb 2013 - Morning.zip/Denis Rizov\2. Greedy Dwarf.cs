using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class GreedyDwarf
{
    static void Main(string[] args)
    {
        char[] separators = new char[] { ' ', ',' };
        string[] valley = Console.ReadLine().Split(separators, StringSplitOptions.RemoveEmptyEntries);
        int[] valleyNumbers = new int[valley.Length];

        for (int i = 0; i < valleyNumbers.Length; i++)
        {
            valleyNumbers[i] = int.Parse(valley[i]);
        }

        int M = int.Parse(Console.ReadLine());

        List<int[]> patters = new List<int[]>();

        for (int i = 0; i < M; i++)
        {
            string[] currentPatter = Console.ReadLine().Split(separators, StringSplitOptions.RemoveEmptyEntries);
            int[] patternNumbers = new int[currentPatter.Length];

            for (int j = 0; j < patternNumbers.Length; j++)
            {
                patternNumbers[j] = int.Parse(currentPatter[j]);
            }

            patters.Add(patternNumbers);
        }

        int coinsCount;
        int maxCoinsCount = int.MinValue;

        for (int patt = 0; patt < patters.Count; patt++)
        {
            coinsCount = 0;
            bool[] collectedCoins = new bool[valleyNumbers.Length];
            coinsCount += valleyNumbers[0];
            collectedCoins[0] = true;

            int position = 0;
            for (int i = 0; true; i++)
            {
                position += (patters[patt])[i];
                if (position < 0 || position >= valleyNumbers.Length)
                {
                    break;
                }
                else if (collectedCoins[position] == true)
                {
                    break;
                }

                coinsCount += valleyNumbers[position];
                collectedCoins[position] = true;

                if (i == patters[patt].Length - 1)
                {
                    i = -1;
                }
            }

            if (coinsCount > maxCoinsCount)
            {
                maxCoinsCount = coinsCount;
            }
        }

        Console.WriteLine(maxCoinsCount);
    }
}