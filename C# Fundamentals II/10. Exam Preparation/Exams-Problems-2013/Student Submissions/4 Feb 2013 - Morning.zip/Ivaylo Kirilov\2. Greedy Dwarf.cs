using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GreedyDwarf
{
    class GreedyDwarf
    {
        static int N;
        static int[] valley;

        static int GetCoins(int[] pattern)
        {
            bool[] used = new bool[N];
            int coins = valley[0];
            used[0] = true;
            int pos = 0;
            int at = 0;

            while (pos + pattern[at] >= 0 && pos + pattern[at] < N && !used[pos + pattern[at]])
            {
                pos += pattern[at];
                used[pos] = true;
                coins += valley[pos];

                at++;
                if (at == pattern.Length)
                {
                    at = 0;
                }
            }

            return coins;
        }

        static void Main(string[] args)
        {
            //using (StreamReader sr = new StreamReader("../../dwarf.txt")){
            string line = Console.ReadLine();

            string[] coins = line.Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            valley = new int[coins.Length];
            for (int i = 0; i < coins.Length; i++)
            {
                valley[i] = int.Parse(coins[i]);
            }
            N = valley.Length;

            int M = int.Parse(Console.ReadLine());

            string[] moves;
            int[] pattern;

            int maxCoins = int.MinValue;
            for (int i = 0; i < M; i++)
            {
                line = Console.ReadLine();
                moves = line.Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
                
                pattern = new int[moves.Length];

                for (int j = 0; j < moves.Length; j++)
                {
                    pattern[j] = int.Parse(moves[j]);
                }

                int currCoins = GetCoins(pattern);
                maxCoins = Math.Max(maxCoins, currCoins);
            }

            Console.WriteLine(maxCoins);
            
        //}
        }
    }
}
