using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class PrintAsciiTable
{
    static void Main()
    {
        string input = "tova e mnogo mnogo dalga duma,koqto trqbva da premine na drugiq red";
        if (input.Length > 20)
        {
            string input2 = input.Substring(0, 20);
            string novInput = input.Substring(20, 20);
            Console.WriteLine(input2);
            Console.WriteLine(novInput);

        }
        
    }
}