using System;

class KaspichanNumbers
{
    static void Main()
    {
        decimal someNumber = decimal.Parse(Console.ReadLine());
        string[] digits = new string[256];
        for (int i = 65; i <=90; i++)
        {
            digits[i-65] = Convert.ToString((char)i);
        }
        int count = 26;
        for (int i = 97; i <= 105; i++)
        {
            for (int j = 65; j <= 90; j++)
            {
                digits[count]= Convert.ToString((char)i)+Convert.ToString((char)j);
                count++;
                if (i==105 && j == 86)
                {
                    break;
                }
            }
        }
        int[] bits = new int[8];
        for (int i = 0; i <= 7; i++)
        {
            bits[i] = (int)(someNumber % 256);
            if ((someNumber / 256)==0)
            {
                continue;
            }
            someNumber /= 256;
        }
        string result = "";
        for (int i = 7; i >=0; i--)
        {
            if (bits[i]!=0)
            {
                result += digits[bits[i]];
            }
        }
        Console.WriteLine(result);
    }
}
