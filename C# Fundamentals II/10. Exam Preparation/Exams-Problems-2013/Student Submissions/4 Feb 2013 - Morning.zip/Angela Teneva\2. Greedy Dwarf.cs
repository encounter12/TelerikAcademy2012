using System;
using System.Collections.Generic;

class Dwarves
{
    static void Main()
    {
        string valnum = Console.ReadLine();     //  valley numbers
        int m= int.Parse(Console.ReadLine());   //  number of patterns 
        string[] p = new string [m];                 //  Strings of patterns
        string inp;
        for (int i = 0; i < m; i++)
        {
            inp = Console.ReadLine();
            p[i] = inp; 
        }
        char[] sep=new char[] {' ',','};
        string[] vn=valnum.Split(sep,StringSplitOptions.RemoveEmptyEntries);
        int ln=vn.Length;
        bool[] visited=new bool [ln];       // visited
        int[]sum=new int[m];
        int maxsum = 0;
        for (int i = 0; i < m; i++)
        {
            string[] pat=p[i].Split(sep,StringSplitOptions.RemoveEmptyEntries);
            int pl = pat.Length;
            int k=0;
 
            do{
                int index=0;
                for (int j = 0; j < pl; j++)
                {
                    index += int.Parse(pat[j]);

                    if (!(visited[index]))
                    {
                        sum[i] += int.Parse(vn[index]); 
                   
                        visited[index] = true;
                    }
                    else
                    {

                        break;
                    }    
                }

                k++;
            }while(!(visited[k]&&k<ln));
        }
        for (int i = 0; i < m; i++)
        {
            if (maxsum < sum[i])
            {
                maxsum = sum[i];
            }
        }

        Console.WriteLine(maxsum);
    }
}
