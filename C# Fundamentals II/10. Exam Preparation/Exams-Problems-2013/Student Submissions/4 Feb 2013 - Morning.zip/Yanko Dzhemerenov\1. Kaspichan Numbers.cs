using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int w = int.Parse(Console.ReadLine());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++)
        {
            sb.AppendLine(Console.ReadLine());
        }
        string[] words = sb.ToString().Split(new char[]{' ', '\n', '\r'}, StringSplitOptions.RemoveEmptyEntries);
        string line = "";
        string nextLine = "";
        int currWord = 0;
        int currLength = 0;
        sb.Clear();
        StringBuilder output = new StringBuilder();
        while (true)
        {
            currLength = 0;
            sb.Clear();
            while ((currLength  + words[currWord].Length) < w)
            {
                sb.Append(words[currWord] + " ");
                currWord++;
                currLength = sb.Length;
                if (currWord >= words.Length)
                    break;
            }
            sb.Remove(sb.Length - 1,1);
            //Console.WriteLine(sb + "#");
            //Console.WriteLine(sb.Length);
            int gapPos = 0;
            int gapLastPos = 0;
            while (sb.Length < w)
            {
                gapLastPos = sb.ToString().LastIndexOf(" ");
                gapPos = sb.ToString().IndexOf(" ", gapPos);
                sb.Insert(gapPos, " ");
                gapPos += 2;
                if (gapPos >= gapLastPos)
                    gapPos = 0;
                //Console.WriteLine(sb + "#");
                //Console.WriteLine(sb.Length);
            }
            output.AppendLine(sb.ToString());
            if (currWord >= words.Length)
                break;
        }

        output.Remove(output.Length - 2, 2);
        Console.WriteLine(output);

    }
}

