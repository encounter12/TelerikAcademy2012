using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class KaspichanNumbers
{
    static void Main()
    {
        string[] kaspichanDigits = new string[256];

        for (int i = 0; i <= 255; i++)
        {
            int rigthLetterNumber = (i % 26) + 65;
            string rightLetter = ((char)rigthLetterNumber).ToString();

            int leftLetterNumber = i / 26;
            string leftLetter;
            if (leftLetterNumber > 0)
            {
                leftLetter = ((char)(leftLetterNumber - 1 + 65)).ToString().ToLower();

            }
            else
            {
                leftLetter = "";
            }

            kaspichanDigits[i] = leftLetter + rightLetter;
        }



        int Base = 256;
        ulong decNumber = ulong.Parse(Console.ReadLine());

        List<string> hexNumber = new List<string>();
        if (decNumber == 0)
        {
            hexNumber.Add(kaspichanDigits[0]);
        }
        else
        {
            while (decNumber > 0)
            {
                byte reminder = (byte)(decNumber % (ulong)Base);
                hexNumber.Add(kaspichanDigits[reminder]);

                decNumber /= (ulong)Base;
            }
        }

        hexNumber.Reverse();

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < hexNumber.Count; i++)
        {
            builder.Append(hexNumber[i]);
        }

        Console.WriteLine(builder.ToString());

    }
}
