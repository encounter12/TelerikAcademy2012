using System;
using System.Text;

namespace KaspichanNumbers
{
	class KaspichanNumbers
	{
		static void Main(string[] args)
		{
			ulong input = ulong.Parse(Console.ReadLine());
			StringBuilder output = new StringBuilder();
			ulong counter = 0;
			string[] digits = new string[256];
			for(int i=0;i<256;i++)
			{
				char lastletter = (char)(i % 26 + 65);
				char firstletter= ' ';
				if(i>25)
				{
					firstletter = (char)(i/26 + 96);
				}
				digits[i] = firstletter.ToString().Trim() + lastletter.ToString();
				digits[i].Trim();
			}
			if (input == 0)
			{
				output.Append("A");
			}
			while (input > 0)
			{
				output.Insert(0, digits[input / (ulong)Math.Pow(256, counter) % 256]);
				if (input < (ulong)Math.Pow(256, counter))
					break;
				else
					input -= (ulong)Math.Pow(256, counter);
				counter++;
			}
			output.Remove(0, 1);
			Console.WriteLine(output.ToString().Trim());
		}
	}
}