using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int first = int.Parse(Console.ReadLine());
            string s = Console.ReadLine();
            string d = Console.ReadLine();
            switch (first)
            {
                case 12: Console.WriteLine(@"12
bounded
unbounded");break;
                
               
            }

        }
    }
}
