using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Task4
{
    static void Main()
    {
        int numOfLines = int.Parse(Console.ReadLine());
        int width = int.Parse(Console.ReadLine());
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < numOfLines; i++)
        {
            string line = Console.ReadLine();
            text.AppendLine(line);
        }
        string[] split = text.ToString().Split(' ');
        for (int i = 0; i < split.Length-1; i++)
        {
            if ((split[i].Trim().Length + split[i+1].Trim().Length) < width)
            {
                Console.WriteLine(split[i] + split[i+1]);
            }
        }
    }
}
