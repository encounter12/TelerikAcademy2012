using System;

class GreedyDwarf
{
    static void Main()
    {
        long coins = 0, maxCoins = long.MinValue;
        string valleyInput = Console.ReadLine();
        string[] valleyStr = valleyInput.Split(' ', ',');
        short[] valley = new short[valleyStr.Length/2 + 1];
        int index = 0;

        foreach (string nums in valleyStr)
        {
            if (nums != "")
            {
                valley[index] = short.Parse(nums);
                index++;
            }
        }
        int pattern = int.Parse(Console.ReadLine());
        for (int i = 1; i <= pattern; i++)
        {
                    coins = 0;
                    string patternInput = Console.ReadLine();
                    string[] patternStr = patternInput.Split(' ', ',');
                    short[] paternValues = new short[patternStr.Length/2 + 1];
                    index = 0;
                    foreach (string nums in patternStr)
                    {
                          if (nums != "")
                            {
                                paternValues[index] = short.Parse(nums);
                                index++;
                            }
                    }
                    int[] visitedPos = new int[valley.Length];
                    for (int p = 0; p < valley.Length;)
                    {
                        if (p < 0 || visitedPos[p] > 0)
                        {
                            break;
                        }                        
                        for (int j = 0; j < paternValues.Length; j++)
                        {
                            coins += valley[p];
                            visitedPos[p]++;
                            p += paternValues[j];
                            if (valley.Length == 1)
                            {
                                break;
                            }

                            if (p > paternValues.Length || p < 0 || visitedPos[p] > 0)
                            {
                                break;
                            }                                   
                        }
                    }
                    if (coins >= maxCoins)
                    {
                        maxCoins = coins;
                    }                                        
        }
        Console.WriteLine(maxCoins);
        /*
        1, 3, -6, 7, 4, 1, 12
        1, 2, -3
        1, 3, -2
        1, -1
        */
    }
}