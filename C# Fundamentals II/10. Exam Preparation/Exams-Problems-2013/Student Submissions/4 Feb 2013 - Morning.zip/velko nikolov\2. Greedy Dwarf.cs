using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;

namespace exam
{
    static class Program
    {
        static void Main() {
            var reader = Console.In;

            if (false) {
                reader = new StringReader(
@"1, 3, -6, 7, 4, 1, 12
3
1, 2, -3
1, 3, -2
1, -1");

            }

            var valley = reader.GetArray();
            var patcnt = int.Parse(reader.ReadLine());
            var pats = new List<int[]>();
            for (int ii = 0; ii < patcnt; ii++) {
                pats.Add(reader.GetArray());
            }

            long max_coins = 0;
            foreach (var pat in pats) {
                var set = new HashSet<long>();
                set.Add(0);
                long curr = 0;
                long coins = 0;

                while (true) {
                    foreach (var shift in pat) {
                        set.Add(curr);
                        if (curr >= valley.Length)
                            goto END;
                        if (curr < 0)
                            goto END;

                        coins += valley[curr];
                        curr += shift;

                        if (set.Contains(curr))
                            goto END;
                        
                    }


                }
            END:
                //if (curr != 0) {
                //    continue;
                //}
                if (max_coins < coins) {
                    max_coins = coins;
                }

            }


            Console.WriteLine(max_coins);

        }

        static int[] GetArray(this TextReader reader) {
            return reader.ReadLine().Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(_s => Convert.ToInt32(_s.Trim(), 10)).ToArray();
        }

    }
}



