using System;
using System.Collections.Generic;
using System.Text;

class ConsoleJustification
{
    static void Main()
    {
        int lines = int.Parse(Console.ReadLine());
        int symbolsPerLine = int.Parse(Console.ReadLine());
        string[] text = new string[lines];
        for (int i = 0; i < lines; i++)
        {
            text[i] = Console.ReadLine();
        }

        //int lines = 5;
        //int symbolsPerLine = 20;
        //string[] text = new string[lines];
        //text[0] = "We happy few          we band";
        //text[1] = "of brothers for he who sheds";
        //text[2] = "his blood";
        //text[3] = "with";
        //text[4] = "me shall be my brother";

        char[] delimiters = new char[] { ' ' };
        List<string> words = new List<string>();

        for (int i = 0; i < text.Length; i++)
        {
            string[] lineSplit = text[i].Split(delimiters, StringSplitOptions.RemoveEmptyEntries);

            for (int j = 0; j < lineSplit.Length; j++)
            {
                words.Add(lineSplit[j]);
            }
        }

        List<StringBuilder> justifiedLines = new List<StringBuilder>();
        int wordIndex = 0;

        while (true)
        { 
            string lineStr;
            StringBuilder line = new StringBuilder(symbolsPerLine);
            StringBuilder tempLine = new StringBuilder(symbolsPerLine * 2);
            lineStr = words[wordIndex++];
            tempLine.Append(lineStr);
            
            if (wordIndex >= words.Count)
            {
                line.Append(lineStr);
                justifiedLines.Add(line);
                break;
            }

            while (true)
            {
                tempLine.Append(" " + words[wordIndex++]);

                if (tempLine.Length > symbolsPerLine)
                {
                    wordIndex--;
                    break;
                }

                lineStr = tempLine.ToString();

                if (wordIndex >= words.Count)
                {
                    break;
                }
            }

            line.Append(lineStr);

            if (!IsOneWord(line))
            {
                while (line.Length < symbolsPerLine)
                {
                    if (AreSpacedConsistent(line.ToString()))
                    {
                        line.Insert(line.ToString().IndexOf(' '), ' ');
                    }
                    else
                    {
                        line.Insert(FindPlaceForSpaceInsertion(line.ToString()), ' ');
                    }
                }
            }

            justifiedLines.Add(line);

            if (wordIndex >= words.Count)
            {
                break;
            }
        }

        for (int i = 0; i < justifiedLines.Count; i++)
        {
            Console.WriteLine(justifiedLines[i]);
        }
    }
  
    private static int FindPlaceForSpaceInsertion(string line)
    {
        int numberOfSpaces = 1;
        int index = 0;

        index = line.IndexOf(' ');
        while (line[++index] == ' ')
        {
            numberOfSpaces++;
        }

        while ((index = line.IndexOf(' ', index)) != -1)
        {
            int temp = 1;
            while (line[++index] == ' ')
            {
                temp++;
            }

            if (temp < numberOfSpaces)
            {
                return index - 1;
            }
        }

        return 0;
    }

    private static bool AreSpacedConsistent(string line)
    {
        bool spacesAreConsitent = true;
        int numberOfSpaces = 1;
        int index = 0;

        index = line.IndexOf(' ');
        while (line[++index] == ' ')
        {
            numberOfSpaces++;
        }

        while ((index = line.IndexOf(' ', index)) != -1)
        {
            int temp = 1;
            while (line[++index] == ' ')
            {
                temp++;
            }

            if (temp != numberOfSpaces)
            {
                spacesAreConsitent = false;
                break;
            }
        }

        return spacesAreConsitent;
    }
  
    private static bool IsOneWord(StringBuilder line)
    {
        bool result = true;

        for (int i = 0; i < line.Length; i++)
        {
            if (line[i] == ' ')
            {
                result = false;
            }
        }

        return result;
    }
}