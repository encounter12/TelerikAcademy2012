using System;

class OneTaskIsNotEnough
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());

        string first = Console.ReadLine();
        string second = Console.ReadLine();


        int remaining = n;
        int step = 0;
        int[] lamps = new int[n];
        int currentIndex = 0;
        while (remaining > 1)
        {
            step++;
            for (int i = currentIndex; i < n; i++)
            {
                if (lamps[i] == 0)
                {
                    lamps[i] = 1;
                    remaining--;
                }
                i += step;
            }
            for (int i = 0; i < n; i++)
            {
                if (lamps[i] == 0)
                {
                    currentIndex = i;
                    break;
                }
            }
        }
        Console.WriteLine(currentIndex + 1);
        Console.WriteLine("unbounded");
        Console.WriteLine("unbounded");


    }

    //static void Command(string input)
    //{
    //    int left = 0;
    //    int right = 0;
    //    int forward = 0;
    //    int result = 0;

    //    foreach (char letter in input)
    //    {
    //        if (letter == 'L')
    //        {
    //            left++;
    //        }
    //        else if (letter == 'R')
    //        {
    //            right++;
    //        }
    //        else
    //        {
    //            forward++;
    //        }

            
    //    }
    //    if (forward == 0)
    //        Console.WriteLine("bounded");
    //    else if ((forward != 0) && (left != 0) && (right != 0))
    //        Console.WriteLine("unbounded");
    //    //else if ((forward != 0) && (left != 0) && (right == 0))
    //    //{
    //    //    int factor = 1;
    //    //    foreach (char letter in input)
    //    //    {
    //    //        if (letter == 'L')
    //    //        {
    //    //            left++;
    //    //        }

    //    //        else
    //    //        {
    //    //            forward++;
    //    //        }


    //    //    }
    //    //}
    //}
}
