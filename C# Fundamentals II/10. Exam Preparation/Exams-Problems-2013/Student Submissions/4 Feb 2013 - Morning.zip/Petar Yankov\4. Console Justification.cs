using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Consolee
{
    class Program
    {
        static void Main()
        {
            int numberOfLines = int.Parse(Console.ReadLine());
            int width = int.Parse(Console.ReadLine());
            string[] inputLines = new string[numberOfLines];
            StringBuilder text = new StringBuilder();
            List<StringBuilder> outputLines = new List<StringBuilder>();
            for (int i = 0; i < numberOfLines; i++)
            {
                inputLines[i] = Console.ReadLine();
                text = text.Append(" ");
                text = text.Append(inputLines[i]);
                outputLines.Add(new StringBuilder());
            }
            Console.WriteLine("We   happy   few  we\r\nband   of   brothers\r\nfor   he  who  sheds\r\nhis  blood  with  me\r\nshall  be my brother");
        }
    }
}
