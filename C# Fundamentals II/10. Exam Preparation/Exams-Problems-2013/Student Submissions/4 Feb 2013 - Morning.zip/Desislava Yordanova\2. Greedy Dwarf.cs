using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustExamPartII
{
    class JustExamPartII
    {
        static void Main(string[] args)
        {
            string[] valleyInput = Console.ReadLine().Split(new char[] {' ', ','},StringSplitOptions.RemoveEmptyEntries);
            int[] valley = new int[valleyInput.Length];
            long patternSum = 0;
            long maxSum = long.MinValue;

            for (int i = 0; i < valleyInput.Length; i++)//fill the valley
            {
                valley[i] = int.Parse(valleyInput[i]);
            }

            int m = int.Parse(Console.ReadLine());//patterns count
            List<int[]> patterns = new List<int[]>();
            

            for (int j = 0; j < m; j++)//fill the patterns
            {
                string[] patternInput = Console.ReadLine().Split(new char[] { ' ', ',' },StringSplitOptions.RemoveEmptyEntries);
                int[] patternInt = new int[patternInput.Length];
                for (int k = 0; k < patternInput.Length; k++)
                {
                   patternInt[k] = int.Parse(patternInput[k]);
                }
                patterns.Add(patternInt);
            }

            foreach (int[] patternItem in patterns)
            {
                bool[] visited = new bool[valley.Length];
                patternSum = CalcSum(patternItem, valley, visited);
                if (patternSum>maxSum)
                {
                    maxSum = patternSum;   
                }
            }

            Console.WriteLine(maxSum);
        }

        private static long CalcSum(int[] patternItem, int[] valley, bool[] visited)
        {
            long currentSum = 0;
            int currentIndex = 0;
            int indexCount = 0;
            int patternIndex = 0;


            while (true)
            {
                if (currentIndex >= 0 && currentIndex < valley.Length && !visited[currentIndex])
                {
                    currentSum += valley[currentIndex];
                    visited[currentIndex] = true;
                }
                else
                {
                    break;
                }
                
                patternIndex = indexCount % patternItem.Length;
                currentIndex += patternItem[patternIndex];
                indexCount++;
            }

            return currentSum;
        }
    }
}
