using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace GreedyDraft
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputValley = Console.ReadLine();
            int M = int.Parse(Console.ReadLine());
            
            
            
            var digits = Regex.Matches(inputValley, @"[\-]?\d+");
            int[] valley = new int[digits.Count];
            int k = 0;
            foreach (Match digit in digits)
            {
                valley[k] = int.Parse(digit.Value);
                k++;
            }


            List<int[]> patterns = new List<int[]>();
            for (int i = 0; i < M; i++)
            {
                string inputPattern = Console.ReadLine();
                digits = Regex.Matches(inputPattern, @"[\-]?\d+");
                int[] pattern = new int[digits.Count];
                int j = 0;
                foreach (Match digit in digits)
                {
                    pattern[j] = int.Parse(digit.Value);
                    j++;
                }
                patterns.Add(pattern);
            }


            int maxSum = int.MinValue;
            
            List<int> beenThere = new List<int>();

            for (int i = 0; i < M; i++)
            {
                int currentPosition = 0;
                int lastPosition = 0;
                int sum = valley[currentPosition];
                int p = 0, s = 0;
                try
                {
                    while (beenThere.IndexOf(currentPosition) == -1)
                    {
                        beenThere.Add(currentPosition);
                        lastPosition = currentPosition;
                        currentPosition += patterns[i][p];
                        sum = sum + valley[currentPosition];
                        s++;
                        p = s % patterns[i].Length;
                    }
                    sum = sum - valley[currentPosition];
                }
                catch (IndexOutOfRangeException)
                {
                    
                    continue;
                }
                finally
                {
                    
                    beenThere.Clear();
                    if (sum > maxSum)
                    {
                        maxSum = sum;
                    }
                }
            }
            Console.WriteLine(maxSum);


        
        }
    }
}
