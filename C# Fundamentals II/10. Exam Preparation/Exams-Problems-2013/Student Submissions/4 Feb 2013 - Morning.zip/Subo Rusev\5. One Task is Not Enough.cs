using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.JoroTheBot
{
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine(n);
            Console.WriteLine("bounded");
            Console.WriteLine("unbounded");
        }
    }
}
