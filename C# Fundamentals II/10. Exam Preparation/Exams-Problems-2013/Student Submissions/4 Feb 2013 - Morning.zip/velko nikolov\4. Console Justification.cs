
        using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;
namespace exam
{
    class Program
    {

        static void Main() {
            var reader = Console.In;
            /*
            reader = new StringReader(@"8
18
Beer  beer beer Im
going  for  a beer
Beer  beer beer Im
gonna  drink  some
beer     I    love
drinkiiiiiiiiing
beer        lovely
lovely        beer");
    //*/
            var sb_output = new StringBuilder();
            

            var temp = int.Parse(reader.ReadLine());
            var width = int.Parse(reader.ReadLine());

            var rem = width;

            var this_line = new List<string>();

            Action lline = () => {
                if (this_line.Count == 1) {
                    //Console.WriteLine(this_line[0]);
                    sb_output.AppendLine(this_line[0]);
                    this_line.Clear();
                    rem = width;
                    return;
                }
                var ws = rem / (this_line.Count - 1);
                var add = rem % (this_line.Count - 1);
                var spaces = new List<string>();

                // most whitespace
                for (int ii = 0; ii < this_line.Count - 1; ii++) {
                    spaces.Add(new string(' ', ws));
                }
                // distribute remaining whitespace
                for (var ii = 0; add > 0; ii += 1, ii %= spaces.Count) {
                    spaces[ii] += " ";
                    add -= 1;
                }

                using (var en = spaces.GetEnumerator()) {
                    foreach (var word in this_line) {
                        sb_output.Append(word);
                        if (en.MoveNext()) {
                            sb_output.Append(en.Current);
                        }
                    }
                }

                sb_output.AppendLine();
                this_line.Clear();
                rem = width;

                return;
            };

            Action<string> lpush = _word => {
                var len = _word.Length;
                if (len + this_line.Count > rem) {
                    lline();
                }

                this_line.Add(_word);
                rem -= _word.Length;

            };




            for (int ii = 0; ii < temp; ii++) {
                var line = reader.ReadLine();
                var state = false;
                var sb = new char[10000];
                int ix = 0;
                foreach (var ch in line) {
                    if (('a' <= ch && ch <= 'z') ||
                        ('A' <= ch && ch <= 'Z')) {
                        sb[ix++] = ch;
                        state = true;
                        continue;
                    }
                    else if (state) {
                        state = false;

                        lpush(new string(sb, 0, ix));
                        ix = 0;
                    }
                }
                if (state) {
                    lpush(new string(sb, 0, ix));
                }

            }
            if (this_line.Count > 0) {
                lline();
            }



            Console.WriteLine(sb_output.ToString());
            // Console.WriteLine(output);
        }
    }
}