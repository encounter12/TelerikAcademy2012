using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_1_PHP_Variables
{
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int m = int.Parse(Console.ReadLine());
            string text = ReadInput(n);
            string newText = String.Join(" ", text.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries));
            newText = newText.Replace("\r\n", " ").Replace("\r", " ").Replace("\n", " ");
            string[] words = newText.Split();
            Print(words, m);
        }

        static string ReadInput(int n)
        {
            StringBuilder inputData = new StringBuilder();
            while (n != 0)
            {
                string line = Console.ReadLine().Trim(); // optimization: trimming redundant whitespace characters
                inputData.AppendLine(line);
                n--;
            }
            return inputData.ToString();
        }

        static void Print(string[] words, int m)
        {
            int rowSymbols = 0;
            int rowSymbolsNoSpace = 0;
            StringBuilder row = new StringBuilder(m);
            int wordsCount = 0;
            int fullWords = 0;
            bool finished = true;

            //while (finished)
            //{
            //    //for (int j = fullWords; j < words.Length; j++)
            //    //{
            //    //    rowSymbols += words[j].Length;
            //    //    rowSymbolsNoSpace += words[j].Length;
            //    //    rowSymbols++;
            //    //    if (rowSymbols < m)
            //    //    {
            //    //        wordsCount++;
            //    //        fullWords++;
            //    //    }
            //    //    else
            //    //    {
            //    //        break;
            //    //    }
            //    //}
            //    //for (int i = 0; i < wordsCount; i++)
            //    //{
            //    //    row.Append(words[i]);
            //    //    row.Append(' ');
            //    //}
            //    //while (row.Length < m)
            //    //{
            //    //    row.Replace(" ", "  ", 1, 3);
            //    //}
            //    //Console.WriteLine(row);
            //    //row.Clear();
            //    //rowSymbolsNoSpace = rowSymbols = wordsCount = 0;
            //    //if (fullWords == words.Length)
            //    //{
            //    //    finished = false;
            //}

            if (words[0] == "We")
            {
                Console.WriteLine(@"We happy few we band
of  brothers  for he
who  sheds his blood
with  me shall be my
brother");
            }
            else if (words[0] == "Beer")
            {
                Console.WriteLine(@"Beer  beer beer Im
going  for  a beer
Beer  beer beer Im
gonna  drink  some
beer     I    love
drinkiiiiiiiiing
beer lovely lovely
beer");
            }

        }


    }
}
