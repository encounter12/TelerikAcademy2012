using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Problem2_BallinCuboid
{
    class BallinCuboid
    {
        static void Main(string[] args)
        {
            // Read the cuboid size
            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            int width = int.Parse(sizes[0]);
            int height = int.Parse(sizes[1]);
            int depth = int.Parse(sizes[2]);
            string[, ,] cuboid = new string[width, height, depth];
 
            // Read the cuboid data
            string[] lineSeparator = { " | " };
            string[] bracketsSeparator = { ")" };
 
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] depthItems = line.Split(lineSeparator, StringSplitOptions.RemoveEmptyEntries);
 
                for (int d = 0; d < depth; d++)
                {
                    string[] widthItems = depthItems[d].Split(bracketsSeparator, StringSplitOptions.RemoveEmptyEntries);
                     
                    for (int w = 0; w < width; w++)
                    {
                        cuboid[w, h, d] = widthItems[w].Replace('(', '\0');
                    }
                }
            }
 
            // Read ball starting position
            string ballPosInput = Console.ReadLine();
            string[] ballPosStr = ballPosInput.Split(' ');
 
            int ballPosW = int.Parse(ballPosStr[0]);
            int ballPosD = int.Parse(ballPosStr[1]);
            int ballPosH = 0;
 
            bool isStuck = false;
            bool hasArrived = false;
 
            while (!isStuck || !hasArrived)
            {
                // get content of cube
                string instruction = cuboid[ballPosW, ballPosH, ballPosD];
 
                //if empty -> pass down
                if (instruction[1] == 'E')
                {
                    ballPosH++;
                }
 
                // if in basket -> deadend
                if (instruction[1] == 'B')
                {
                    isStuck = true;
                    break;
                }
 
                //if teleport -> go to destination
                if (instruction[1] == 'T')
                {
                    string[] destinationStr = instruction.Split(' ');
                    int destinationW = int.Parse(destinationStr[1]);
                    int destinationD = int.Parse(destinationStr[2]);
 
                    ballPosW = destinationW;
                    ballPosD = destinationD;
                }
 
                // if slide -> move there
                if (instruction[1] == 'S')
                {
                    string[] destinationStr = instruction.Split(' ');
                    string direction = destinationStr[1];
                     
                    // left
                    if (direction == "L")
                    {
                        ballPosW--;
                        ballPosH++;
                    }
 
                    // right
                    if (direction == "R")
                    {
                        ballPosW++;
                        ballPosH++;
                    }
 
                    // front
                    if (direction == "F")
                    {
                        ballPosD--;
                        ballPosH++;
                    }
 
                    // back
                    if (direction == "B")
                    {
                        ballPosD++;
                        ballPosH++;
                    }
 
                    // front left
                    if (direction == "FL")
                    {
                        ballPosW--;
                        ballPosD--;
                        ballPosH++;
                    }
 
                    // front right
                    if (direction == "FR")
                    {
                        ballPosW++;
                        ballPosD--;
                        ballPosH++;
                    }
 
                    // back left
                    if (direction == "BL")
                    {
                        ballPosW--;
                        ballPosD++;
                        ballPosH++;
                    }
 
                    // back right
                    if (direction == "BR")
                    {
                        ballPosW++;
                        ballPosD++;
                        ballPosH++;
                    }
 
                    if (ballPosW >= width || ballPosH >= height || ballPosD >= depth)
                    {
                        isStuck = true;
                        break;
                    }
                }
 
                if (ballPosH == height - 1)
                {
                    hasArrived = true;
                    break;
                }
            }
 
            if (hasArrived)
            {
                Console.WriteLine("Yes");
            }
            else
            {
                Console.WriteLine("No");
            }
 
            Console.WriteLine("{0} {1} {2}", ballPosW, ballPosH, ballPosD);
        }
    }
}