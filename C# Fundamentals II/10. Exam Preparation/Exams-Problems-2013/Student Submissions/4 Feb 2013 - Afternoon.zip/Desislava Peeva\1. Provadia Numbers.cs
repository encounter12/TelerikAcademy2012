using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProvadiaNumbers
{
    class Program
    {
        static void Main()
        {
            // Make Collection of 256 elements 
            List<string> digitsList = new List<string>() { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", 
                                                            "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                                                "aA", "aB", "aC", "aD", "aE", "aF", "aG", "aH", "aI", "aJ", "aK", "aL", "aM", 
                                                "aN", "aO", "aP", "aQ", "aR", "aS", "aT", "aU", "aV", "aW", "aX", "aY", "aZ",
                                                "bA", "bB", "bC", "bD", "bE", "bF", "bG", "bH", "bI", "bJ", "bK", "bL", "bM", 
                                                "bN", "bO", "bP", "bQ", "bR", "bS", "bT", "bU", "bV", "bW", "bX", "bY", "bZ",
                                                "cA", "cB", "cC", "cD", "cE", "cF", "cG", "cH", "cI", "cJ", "cK", "cL", "cM", 
                                                "cN", "cO", "cP", "cQ", "cR", "cS", "cT", "cU", "cV", "cW", "cX", "cY", "cZ",
                                                "dA", "dB", "dC", "dD", "dE", "dF", "dG", "dH", "dI", "dJ", "dK", "dL", "dM", 
                                                "dN", "dO", "dP", "dQ", "dR", "dS", "dT", "dU", "dV", "dW", "dX", "dY", "dZ",
                                                "eA", "eB", "eC", "eD", "eE", "eF", "eG", "eH", "eI", "eJ", "eK", "eL", "eM", 
                                                "eN", "eO", "eP", "eQ", "eR", "eS", "eT", "eU", "eV", "eW", "eX", "eY", "eZ",
                                                "fA", "fB", "fC", "fD", "fE", "fF", "fG", "fH", "fI", "fJ", "fK", "fL", "fM", 
                                                "fN", "fO", "fP", "fQ", "fR", "fS", "fT", "fU", "fV", "fW", "fX", "fY", "fZ",
                                                "gA", "gB", "gC", "gD", "gE", "gF", "gG", "gH", "gI", "gJ", "gK", "gL", "gM", 
                                                "gN", "gO", "gP", "gQ", "gR", "gS", "gT", "gU", "gV", "gW", "gX", "gY", "gZ",
                                                "hA", "hB", "hC", "hD", "hE", "hF", "hG", "hH", "hI", "hJ", "hK", "hL", "hM", 
                                                "hN", "hO", "hP", "hQ", "hR", "hS", "hT", "hU", "hV", "hW", "hX", "hY", "hZ",
                                                "iA", "iB", "iC", "iD", "iE", "iF", "iG", "iH", "iI", "iJ", "iK", "iL", "iM", 
                                                "iN", "iO", "iP", "iQ", "iR", "iS", "iT", "iU", "iV"};

            // Take input number in range 0 - 18 446 744 073 709 551 615 
            int input;
            Int32.TryParse(Console.ReadLine(), out input);

            // Declare variables for all possible digit positions 
            string index0 = ""; // 256^0
            string index1 = ""; // 256^1
            string index2 = ""; // 256^2
            string index3 = ""; // 256^3
            string index4 = ""; // 256^4
            string index5 = ""; // 256^5
            string index6 = ""; // 256^6
            string index7 = ""; // 256^7
            string index8 = ""; // 256^8

            if (input < 256) // <= 255
            {
                // PRINT DIGIT:     IndexOf(input[i]);
                for (int i = 0; i < digitsList.Count; i++)
                {
                    index0 = digitsList[input];
                }
                Console.WriteLine(index0);
            }
            else
            {
                // INDEX 0 
                int currentValue0 = input - 256; // временна променлива за индекс0

                while (!((currentValue0 - 256) < 256)) // <= 255
                {
                    currentValue0 = currentValue0 - 256;
                }
                currentValue0 = currentValue0 - 256;
                // Принтиране на полученото число за index0 
                for (int i = 0; i < digitsList.Count; i++)
                {
                    index0 = digitsList[currentValue0];
                }
                Console.WriteLine(index0);


                // INDEX 1 
                int currentValue1 = input - currentValue0; // временна променлива за индекс1

                if (!(currentValue1 > 255 * Math.Pow(256, 1)))
                {
                    currentValue1 = currentValue1 / 256;
                    // Принтиране на полученото число за index1 
                    for (int i = 0; i < digitsList.Count; i++)
                    {
                        index1 = digitsList[currentValue1];
                    }
                    Console.WriteLine(index1 + index0);
                }
                else
                {
                    while (!((currentValue1 / 256) > 255)) // <= 255
                    {
                        currentValue1 = currentValue0 / 256;
                    }
                    currentValue1 = currentValue1 / 256;
                    // Принтиране на полученото число за index0 
                    for (int i = 0; i < digitsList.Count; i++)
                    {
                        index1 = digitsList[currentValue0];
                    }
                    Console.WriteLine(index1 + index0);

                    // INDEX 2 
                    double currentValue2 = input - currentValue0 - currentValue1; // временна променлива за индекс2


                    if (!(currentValue2 > 255 * Math.Pow(256, 2)))
                    {
                        currentValue2 = currentValue2 / Math.Pow(256, 2);
                        // Принтиране на полученото число за index2 
                        for (int i = 0; i < digitsList.Count; i++)
                        {
                            index2 = digitsList[(int)currentValue2];
                        }
                        Console.WriteLine(index2 + index1 + index0);
                    }
                    else
                    {
                        while (!((currentValue2 / Math.Pow(256, 2)) > 255)) // <= 255
                        {
                            currentValue2 = currentValue2 / Math.Pow(256, 2);
                            Console.WriteLine("Current value: {0}", currentValue2);
                        }
                        currentValue2 = currentValue2 / Math.Pow(256, 2);
                        // Принтиране на полученото число за index2 
                        for (int i = 0; i < digitsList.Count; i++)
                        {
                            index2 = digitsList[(int)currentValue2];
                        }
                        Console.WriteLine(index2 + index1 + index0);

                        // INDEX 3 
                        double currentValue3 = input - currentValue0 - currentValue1 - currentValue2; // временна променлива за индекс3
                        


                        if (!(currentValue3 > 255 * Math.Pow(256, 3)))
                        {
                            currentValue3 = currentValue3 / Math.Pow(256, 3);
                            // Принтиране на полученото число за index2 
                            for (int i = 0; i < digitsList.Count; i++)
                            {
                                index3 = digitsList[(int)currentValue3];
                            }
                            Console.WriteLine(index3 + index2 + index1 + index0);
                        }
                        else
                        {
                            while (!((currentValue3 / Math.Pow(256, 3)) > 255)) // <= 255
                            {
                                currentValue3 = currentValue3 / Math.Pow(256, 3);
                            }
                            currentValue3 = currentValue3 / Math.Pow(256, 3);
                            // Принтиране на полученото число за index3 
                            for (int i = 0; i < digitsList.Count; i++)
                            {
                                index3 = digitsList[(int)currentValue3];
                            }
                            Console.WriteLine(index3 + index2 + index1 + index0);

                            // INDEX 4 
                            double currentValue4 = input - currentValue0 - currentValue1 - currentValue2 - currentValue3;

                            if (!(currentValue4 > 255 * Math.Pow(256, 4)))
                            {
                                currentValue4 = currentValue4 / Math.Pow(256, 4);
                                for (int i = 0; i < digitsList.Count; i++)
                                {
                                    index4 = digitsList[(int)currentValue4];
                                }
                                Console.WriteLine(index4 + index3 + index2 + index1 + index0);
                            }
                            else
                            {
                                while (!((currentValue4 / Math.Pow(256, 4)) > 255)) // <= 255
                                {
                                    currentValue4 = currentValue4 / Math.Pow(256, 4);
                                    Console.WriteLine("Current value: {0}", currentValue4);
                                }
                                currentValue4 = currentValue4 / Math.Pow(256, 4);
                                Console.WriteLine("Final value index4: {0}", currentValue4);
                                // Принтиране на полученото число за index3 
                                for (int i = 0; i < digitsList.Count; i++)
                                {
                                    index4 = digitsList[(int)currentValue4];
                                }
                                Console.WriteLine(index4 + index3 + index2 + index1 + index0);

                                // INDEX 5 
                                double currentValue5 = input - currentValue0 - currentValue1 - currentValue2 - currentValue3 - currentValue4;


                                if (!(currentValue5 > 255 * Math.Pow(256, 5)))
                                {
                                    currentValue5 = currentValue5 / Math.Pow(256, 5);
                                    for (int i = 0; i < digitsList.Count; i++)
                                    {
                                        index4 = digitsList[(int)currentValue5];
                                    }
                                    Console.WriteLine(index5 + index4 + index3 + index2 + index1 + index0);
                                }
                                else
                                {
                                    while (!((currentValue5 / Math.Pow(256, 5)) > 255)) // <= 255
                                    {
                                        currentValue5 = currentValue5 / Math.Pow(256, 5);
                                    }
                                    currentValue5 = currentValue5 / Math.Pow(256, 5);
                                    for (int i = 0; i < digitsList.Count; i++)
                                    {
                                        index5 = digitsList[(int)currentValue5];
                                    }
                                    Console.WriteLine(index5 + index4 + index3 + index2 + index1 + index0);

                                    // INDEX 5 
                                    double currentValue6 = input - currentValue0 - currentValue1 - currentValue2 - currentValue3 - currentValue4 - currentValue5;


                                    if (!(currentValue6 > 255 * Math.Pow(256, 6)))
                                    {
                                        currentValue6 = currentValue6 / Math.Pow(256, 6);
                                        for (int i = 0; i < digitsList.Count; i++)
                                        {
                                            index6 = digitsList[(int)currentValue6];
                                        }
                                        Console.WriteLine(index6 + index5 + index4 + index3 + index2 + index1 + index0);
                                    }
                                    else
                                    {
                                        while (!((currentValue6 / Math.Pow(256, 5)) > 255)) // <= 255
                                        {
                                            currentValue6 = currentValue6 / Math.Pow(256, 6);
                                        }
                                        currentValue6 = currentValue6 / Math.Pow(256, 6);
                                        for (int i = 0; i < digitsList.Count; i++)
                                        {
                                            index6 = digitsList[(int)currentValue6];
                                        }
                                        Console.WriteLine(index6 + index5 + index4 + index3 + index2 + index1 + index0);

                                        // INDEX 7 
                                        double currentValue7 = input - currentValue0 - currentValue1 - currentValue2 - currentValue3 - currentValue4 - currentValue5 - currentValue6;


                                        if (!(currentValue7 > 255 * Math.Pow(256, 7)))
                                        {
                                            currentValue7 = currentValue7 / Math.Pow(256, 7);
                                            for (int i = 0; i < digitsList.Count; i++)
                                            {
                                                index7 = digitsList[(int)currentValue7];
                                            }
                                            Console.WriteLine(index7 + index6 + index5 + index4 + index3 + index2 + index1 + index0);
                                        }
                                        else
                                        {
                                            while (!((currentValue7 / Math.Pow(256, 7)) > 255)) // <= 255
                                            {
                                                currentValue7 = currentValue7 / Math.Pow(256, 7);
                                            }
                                            currentValue7 = currentValue7 / Math.Pow(256, 7);
                                            for (int i = 0; i < digitsList.Count; i++)
                                            {
                                                index6 = digitsList[(int)currentValue7];
                                            }
                                            Console.WriteLine(index7 + index6 + index5 + index4 + index3 + index2 + index1 + index0);

                                            // INDEX 8 
                                            double currentValue8 = input - currentValue0 - currentValue1 - currentValue2 - currentValue3 - currentValue4 - currentValue5 - currentValue6 - currentValue7; // временна променлива за индекс8
                                            if (currentValue8 > 255 * Math.Pow(256, 7))
                                            {
                                                currentValue8 = Math.Pow(256, 8) - 1 - (255 * Math.Pow(256, 7));
                                                index8 = (currentValue8 / Math.Pow(256, 7)).ToString();
                                                // Принтиране на полученото число за index8 
                                                for (int i = 0; i < digitsList.Count; i++)
                                                {
                                                    index8 = digitsList[(int)currentValue8];
                                                }
                                                Console.WriteLine(index8 + index7 + index6 + index5 + index4 +
                                                    index3 + index2 + index1 + index0);
                                            }

                                        }
                                    }

                                }
                            }
                        }
                    }
                }
            }

        }
    }
}
