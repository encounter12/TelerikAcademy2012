using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
 
namespace Align_Both
{
    class Program
    {
        static List<string> words = new List<string>();
        static string result = string.Empty;
        static int w;
        static int fitted = 0;
 
        static void Main()
        {
            ReadInput();
 
            //for (int i = 0; i < words.Count; i++)
            //{
            //    Console.WriteLine(words[i]);
            //}
 
            GenerateResult();
 
            Console.WriteLine(result);
        }
 
        private static void GenerateResult()
        {
            do
            {
                int toFit = DetermineToFit();
                int whitespace = DetermineWS(toFit);
 
                //result += words[fitted - toFit];
 
                int left = w;
                string line = string.Empty;
                for (int i = fitted - 1; i >= fitted - toFit; i--)
                {
                    line = words[i] + line;
                    if (i != fitted - toFit)
                    {
                        line = " " + line;
                    }
                    left -= line.Length;
                }
                if (toFit > 1)
                {
                    int ind = -1;
                    while (line.Length < w)
                    {
                        ind = line.IndexOf(" ", ind + 2);
                        if (ind == -1)
                        {
                            ind = line.IndexOf(" ", ind + 2);
                        }
                        line = line.Insert(ind, " ");
                    }
                }
                if (fitted != words.Count)
                {
                    result += line + '\n';
                }
                else
                {
                    result += line;
                }
 
            } while (fitted < words.Count);
        }
 
        private static int DetermineWS(int toFit)
        {
            int nws = 0;
            for (int i = fitted - 1; i >= fitted - toFit; i--)
            {
                nws += words[i].Length;
            }
 
            return w - nws;
        }
 
        private static int DetermineToFit()
        {
            int canFit = 0;
            int sum = 0;
            int ind = fitted;
            do
            {
                sum += words[ind].Length + 1;
                canFit++;
                ind++;
            } while (sum < w && ind < words.Count);
 
            if (sum > w + 1)
            {
                canFit--;
            }
            fitted += canFit;
            return canFit;
        }
 
        private static void ReadInput()
        {
            int n = int.Parse(Console.ReadLine());
            w = int.Parse(Console.ReadLine());
 
            for (int i = 0; i < n; i++)
            {
                string line = Console.ReadLine();
                string word = string.Empty;
                bool inWord = false;
                for (int j = 0; j < line.Length; j++)
                {
                    if (line[j] > 32 && line[j] < 127)
                    {
                        inWord = true;
                        word += (char)line[j];
                    }
                    else if (inWord)
                    {
                        words.Add(word);
                        word = string.Empty;
                        inWord = false;
                    }
                    if (inWord && j == line.Length - 1)
                    {
                        words.Add(word);
                        word = string.Empty;
                        inWord = false;
                    }
                }
            }
        }
    }
}