using System;
using System.Collections.Generic;
using System.Text;
class ProvadiaNum
{
    static void Main()
    {
        ulong input;
        List<ulong> ulongForChars = new List<ulong> { };
        List<char> outChars = new List<char> { };
        List<ulong> upTo256 = new List<ulong> { };
        string utfOut;
        ulong outulong = 0;
        try
        {
            bool parseSuxess = ulong.TryParse(Console.ReadLine(), out input);
        }
        catch (IndexOutOfRangeException)
        {
 
 
            throw new Exception("");
        }
 
        if (input == 0)
        {
            Console.WriteLine("A");
        }
        else
        {
            ulongForChars = ListFill(input, 256);
            upTo256 = ListFill(ulongForChars[0], 26);
        }
        for (int i = 1; i < ulongForChars.Count; i++)
        {
            if ((i % 2) != 0)
            {
                outulong = 65 + ulongForChars[i];
            }
            else
            {
                outulong = 97 + ulongForChars[i];
            }
            utfOut = outulong.ToString("x");
            Console.Write((char)ulong.Parse(utfOut, System.Globalization.NumberStyles.AllowHexSpecifier));
        }
        for (int i = upTo256.Count - 1; i >= 0; i--)
        {
            if ((i % 2) == 0)
            {
                outulong = 65 + upTo256[i];
            }
            else
            {
                outulong = 97 + upTo256[i] - 1;
            }
            utfOut = outulong.ToString("x");
            Console.Write((char)ulong.Parse(utfOut, System.Globalization.NumberStyles.AllowHexSpecifier));
        }
        Console.WriteLine();
    }
 
    public static List<ulong> ListFill(ulong input, ulong divider)
    {
        List<ulong> arrulong = new List<ulong> { };
        ulong divisionRes = input / divider;
        ulong assigment = input % divider; ;
        while (assigment != 0)
        {
            arrulong.Add(assigment);
            assigment = divisionRes % divider;
            divisionRes = divisionRes / divider;
        }
        return arrulong;
    }
}
