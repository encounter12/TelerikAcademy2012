using System;
using System.Collections.Generic;

namespace Midget
{
    class Midget
    {
        static void Main(string[] args)
        {
            int[] valley = ReadIntegerArrayFromConsole();
            int numberofpatterns = int.Parse(Console.ReadLine());

            List<int[]> patterns = new List<int[]>();

            for (int i = 0; i < numberofpatterns; i++)
            {
                int[] newpattern = ReadIntegerArrayFromConsole();
                patterns.Add(newpattern);
            }

            int maxNumberOfCoins = int.MinValue;
            for (int i = 0; i < patterns.Count; i++)
            {
                int currentPatternCoins = GetPatternCoins(patterns[i], valley);
                if (currentPatternCoins > maxNumberOfCoins)
                    maxNumberOfCoins = currentPatternCoins;
            }
            Console.WriteLine(maxNumberOfCoins);
        }

        static int[] ReadIntegerArrayFromConsole()
        {
            string inputString = Console.ReadLine();
            string[] inputStringArray = inputString.Split(',');
            int[] resultArray = new int[inputStringArray.Length];
            for (int i = 0; i < inputStringArray.Length; i++)
            {
                resultArray[i] = int.Parse(inputStringArray[i]);
            }
            return resultArray;
        }

        static int GetPatternCoins(int[] pattern, int[] valley)
        {
            int sumOfCoins = 0;
            bool[] isVisited = new bool[valley.Length];
            int currentValleyIndex = 0;
            int currentPatternIndex = 0;

            while (!isVisited[currentValleyIndex] &&
                currentValleyIndex >= 0 && currentValleyIndex < valley.Length)
            {
                isVisited[currentValleyIndex] = true;
                sumOfCoins += valley[currentValleyIndex];
                currentValleyIndex += pattern[currentPatternIndex];
                currentPatternIndex++;

                if (currentPatternIndex == pattern.Length)
                    currentPatternIndex = 0;
            }

            return sumOfCoins;
        }
    }
}     
