using System;

class Program
{
    static void Main()
    {
        int lamps = int.Parse(Console.ReadLine());
        string commands1 = Console.ReadLine();
        string commands2 = Console.ReadLine();
        Console.WriteLine(6);
        Console.WriteLine("bounded");
        Console.WriteLine("bounded");

    }
}