using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2.midget
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            char[] charSeparators = new char[] { ' ',',' };
            string[] str = input.Split(charSeparators, StringSplitOptions.RemoveEmptyEntries);
            int[] valley = new int[str.Length];
            for (int i = 0; i < str.Length; i++)
            {
                valley[i] = int.Parse(str[i]);
            }
            int nPatterns = int.Parse(Console.ReadLine());
            int[,] patterns = new int[nPatterns, 200];
            for (int i = 0; i < nPatterns; i++)
            {
                for (int f = 0; f < 200; f++)
                {
                    patterns[i, f] = 9999;
                }
            }
            for (int i = 0; i < nPatterns; i++)
			{
			    input = Console.ReadLine();
                str = input.Split(charSeparators, StringSplitOptions.RemoveEmptyEntries);
                for (int p = 0; p < str.Length; p++)
                {
                    patterns[i, p] = int.Parse(str[p]);
                }
			}
            int maxCollected = 0;
            for (int i = 0; i < nPatterns; i++)
            {
                bool[] taken = new bool[valley.Length];
                int currentCoins = 0, possition = 0;
                for (int p = 0; ; p++)
                {
                    currentCoins += valley[possition];
                    taken[possition] = true;                   
                    if ((possition + patterns[i, p]) < 0 || (possition + patterns[i, p]) > valley.Length - 1 || (taken[possition + patterns[i, p]]) == true)
                    {
                        break;
                    }
                    else
                    {
                        possition += patterns[i, p];
                    }
                    if (patterns[i, p + 1] == 9999)
                    {
                        p = -1;
                    }
                }
                if (maxCollected < currentCoins)
                {
                    maxCollected = currentCoins;
                }
            }
            Console.WriteLine(maxCollected);
            
        }
    }
}
