using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        string[] valley_numbers = Console.ReadLine().Split(',');
        long patterns_count = long.Parse(Console.ReadLine());
        long[] valley_coins = new long[valley_numbers.Length];
        long[][] patterns = new long[patterns_count][];
        long best_sum = long.MinValue;
        // get the valley to a int array
        for (int v = 0; v < valley_numbers.Length; v++)
        {
            valley_coins[v] = int.Parse(valley_numbers[v]);
        }
        // get all paterns in to int array
        for (int p = 0; p < patterns_count; p++)
        {
            string[] pattern_steps = Console.ReadLine().Split(',');
            patterns[p] = new long[pattern_steps.Length];
            for (int step = 0; step < pattern_steps.Length; step++)
            {
                patterns[p][step] = long.Parse(pattern_steps[step]);
            }
        }
        for (int p = 0; p < patterns.Length; p++)
        {
            var x = patterns[p];
            long cur_sum = collect_coins(valley_coins, patterns[p]);
            if (best_sum < cur_sum)
            {
                best_sum = cur_sum;
            }
        }
        Console.WriteLine(best_sum);

    }

    static long collect_coins(long[] valley_coins, long[] pattern){
        bool[] valley_stepped = new bool[valley_coins.Length];
        long gold = 0;
        int pat_index = -1;
        long vall_index = 0;
        while(true){
            if (vall_index < 0 || vall_index >= valley_coins.Length)
            {
                break;
            }
            if (valley_stepped[vall_index] == true){
                break;
            }
            gold += valley_coins[vall_index];
            valley_stepped[vall_index]= true;
            pat_index++;
            if (pat_index >= pattern.Length){
                pat_index = 0;
            }
            vall_index += pattern[pat_index];
        }
        return gold;
    }
    /*static long collect_coins(long[] valley_coins, long[] pattern)
    {
        bool[] valley_stepped = new bool[valley_coins.Length];
        int stepa = 0;
        long place = pattern[stepa];
        long gold = valley_coins[0];
        valley_stepped[0] = true;
        while (true)
        {
            if (valley_stepped[place])
            {
                break;
            }
            else
            {
                gold += valley_coins[place];
                valley_stepped[place] = true;

                stepa++;
                if (stepa == pattern.Length)
                {
                    stepa = 0;
                }

                place += pattern[stepa];
                if (place < 0 || place >= valley_coins.Length)
                {
                    break;
                }
            }
        }
        return gold;
    }*/
}
