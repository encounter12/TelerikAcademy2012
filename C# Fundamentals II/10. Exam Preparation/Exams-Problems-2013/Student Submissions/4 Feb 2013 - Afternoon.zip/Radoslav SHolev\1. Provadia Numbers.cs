using System;
using System.Text;

class Program
{
    static void Main()
    {
        string[] digits = new string[256];
        FillTable(digits);
        ulong number = ulong.Parse(Console.ReadLine());
        ConverNumber(number,digits);
    }

    private static void ConverNumber(ulong number,string[] digits)
    {
        StringBuilder sb = new StringBuilder();
        int remainder;
        if (number > 0)
        {
            while (number > 0)
            {
                remainder = (int)(number % 256);
                number /= 256;
                sb.Insert(0, digits[remainder]);
            }
            Console.WriteLine(sb);
        }
        else
        {
            Console.WriteLine("A");
        }
    }

    private static void FillTable(string[] digits)
    {
        char c;
        for (int j = 0; j < 10; j++)
        {
            if (j > 0)
            {
                c = Convert.ToChar(j + 96);
                for (int i = 0; i < 26; i++)
                {
                    if (i + j * 26 >= digits.Length)
                    {
                        break;
                    }
                    digits[i + j * 26] =""+ c + Convert.ToChar(65 + i);
                }
            }
            else
            {
                for (int i = 0; i < 26; i++)
                {
                    digits[i + j * 26] += Convert.ToChar(65 + i);
                }
            }
        }
    }
}
