using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class Program
{
    static void Main()
    {
        ulong inputNumber = ulong.Parse(Console.ReadLine());
        
        //int inputNumber = 1000;
        //int inputNumber = int.Parse(Console.ReadLine());

        ulong tempNumber = inputNumber;
        ulong  provNumSystem = 256ul;
        char[] alfabet = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L','M', 'N','O','P','Q','R','S','T','U','V','W','X','Y','Z' };
                        //  0    1    2    3    4    5    6    7    8    9    10   11  12  13   14  15  16  17  18  19  20  21  22  23  24  25  26
   char[] alfabetLower = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n','o','p','q','r','s','t','u','v','w','x','y','z' };
        ulong[] provDigit = new ulong[8]; // big enough to hold Int32.MaxValue
        int index = provDigit.Length;
        ulong reminder;
        
        do
        {
            index--;
            reminder = tempNumber % provNumSystem;
            tempNumber = tempNumber / provNumSystem;

            provDigit[index] = reminder;
            //index--;
            if (tempNumber == 0)
            {
                continue;
            }

        } while (tempNumber > 0);

        for (int i = 0; i < provDigit.Length; i++)
        {
            ////skip all elements == 0 - they haven't usefull information
            if (provDigit[i] > 0)
            {
                //Console.WriteLine();
                for (int j = i; j < provDigit.Length; j++)
                {
                    if (provDigit[j] > 25) //16
                    { 
                        tempNumber = provDigit[j];
                        reminder = tempNumber % 26;
                        tempNumber = tempNumber / 26;
                        Console.Write(alfabetLower[tempNumber-1]);
                        Console.Write(alfabet[reminder]);
                    }
                    else
                    {
                        Console.Write(alfabet[provDigit[j]]);
                    }

                }

                break;
            }
        }

        //Console.WriteLine("\n");    
    }
}