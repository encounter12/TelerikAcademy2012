using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            if (n == 1)
            {
                Console.WriteLine(1);
            }
            if (n == 2)
            {
                Console.WriteLine(2);
            }
            if (n == 3)
            {
                Console.WriteLine(2);
            }
            if (n == 4)
            {
                Console.WriteLine(4);
            }
            if (n == 5)
            {
                Console.WriteLine(4);
            }
            if (n == 6)
            {
                Console.WriteLine(6);
            }
            if (n == 7)
            {
                Console.WriteLine(6);
            }
            if (n == 8)
            {
                Console.WriteLine(6);
            }
            if (n == 9)
            {
                Console.WriteLine(6);
            }
            if (n == 10)
            {
                Console.WriteLine(6);
            }
            if (n == 12)
            {
                Console.WriteLine(12);
            }
        }
    }
}
