using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_ProvadiaTohexa
{
    class DecimalTohexa
    {
        static string[] provadiaAlphabet = new string[256];
        static void Main()
        {
            //Console.Write("Write some number: ");

            ulong n = ulong.Parse(Console.ReadLine());

            //hardcode:
            //ulong n = 1844674407370955161;

            CreateProvadia();
            ConvertDecimalTohexa(n);
        }
        static void ConvertDecimalTohexa(ulong n)
        {
            ulong rest = n;
            //Console.WriteLine(n);
            List<string> provadia = new List<string>();
            do
            {
                provadia.Add(ProvadiaChar(rest % 256));
                rest = rest / 256;
            } while (rest > 0);
            provadia.Reverse();
            for (int i = 0; i < provadia.Count; i++)
            {
                Console.Write("{0}", provadia[i]);
            }
            Console.WriteLine();
        }
        static string ProvadiaChar(ulong n)
        {
            return provadiaAlphabet[n];
        }
        static void CreateProvadia()
        {
            char[] alphabet = new char[52];
            int charInAlphabet = 65;
            StringBuilder provadiaBuilder = new StringBuilder();

            //GENERATE ALPHABET
            for (int i = 0; i < 26; i++)
            {
                //velke
                alphabet[i] = (char)charInAlphabet;
                //male
                alphabet[i + 26] = (char)(charInAlphabet + 32);
                charInAlphabet++;
            }

            //GENERATE PROVADIA
            
            for (int i = 0; i < 26; i++)
            {
                provadiaAlphabet[i] = alphabet[i].ToString();
            }
            int k = 26;
            for (int i = 26; i < 50; i++)
            {
                for (int j = 0; j < 26 && k < 256; j++,k++)
                {
                    provadiaBuilder.Clear();
                    provadiaBuilder.Append( ((char)alphabet[i]).ToString() );
                    provadiaBuilder.Append( ((char)alphabet[j]).ToString() );
                    provadiaAlphabet[k] = provadiaBuilder.ToString();
                }
            }
            for (int i = 0; i < provadiaAlphabet.Length; i++)
            {
                //Console.WriteLine("provadia: {0}", provadiaAlphabet[i]);
            }
            
        }
    }
}
