using System;
using System.Numerics;

class Midget
{
    static void Main()
    {
        int[] valley = InputLine();
        int patCount = int.Parse(Console.ReadLine());

        BigInteger max = PlayPattern(InputLine(), valley); // The first pattern
        BigInteger current;

        for (int i = 1; i < patCount; i++)
        {
            current = PlayPattern(InputLine(), valley);
            if (current > max) max = current;
        }

        Console.WriteLine(max);
    }

    private static int[] InputLine()
    {
        string strV = Console.ReadLine();
        string[] strArrV = strV.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        int[] valley = new int[strArrV.Length];
        for (int i = 0; i < strArrV.Length; i++)
        {
            int.TryParse(strArrV[i], out valley[i]);
        }

        return valley;
    }

    private static BigInteger PlayPattern(int[] pattern, int[] valley)
    {
        bool[] visited = new bool[valley.Length];
        visited[0] = true;

        BigInteger sum = valley[0];

        int index = 0;
        int patI = 0;

        do
        {
            index += pattern[patI];

            if (index < 0 || index > valley.Length - 1 || visited[index] == true) break;
            // else
            sum += valley[index];
            visited[index] = true;

            ++patI;
            if (patI == pattern.Length) patI = 0;

        } while (true);

        return sum;
    }
}

