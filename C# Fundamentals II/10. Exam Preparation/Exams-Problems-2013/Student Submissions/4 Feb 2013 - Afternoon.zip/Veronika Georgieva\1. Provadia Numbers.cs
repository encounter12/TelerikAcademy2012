using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {

        int number = int.Parse(Console.ReadLine());
        Dictionary<int, string> letterCount = new Dictionary<int, string>();

        char[] LowerLetter = new char[26];
        char[] UpperLetter = new char[26];

        //Lower letter
        for (int count = 0, i = 97; i < 123; i++, count++)
        {
            LowerLetter[count] = (char)i;
        }

        //Upper letter
        for (int count = 0, i = 65; i < 91; i++, count++)
        {
            UpperLetter[count] = (char)i;
        }

        //Dictionary A-Z
        for (int count = 0, i = 65; i < 91; i++, count++)
        {
            char letter = (char)i;
            letterCount.Add(count, letter.ToString());
        }

        int last;
        int indexFirst = 0;
        int indexSecond = 0;
        string lastLetters = string.Empty;
        int countRegect = 0;

       // Dictionary aA - zZ

        for (int p = 0; p < UpperLetter.Length; p++)
        {
            for (int h = 0; h < LowerLetter.Length; h++)
            {
                 last = letterCount.Keys.Last();
                 letterCount.Add(last + 1, LowerLetter[p].ToString() + UpperLetter[h]);
            }
        }


        //while (countRegect <= 255 - 25)
        //{
        //    if (indexSecond == 26 && indexFirst< 26)
        //    {
        //        indexSecond = 0;
        //        indexFirst++;
        //    }
        //    if (indexFirst == 26)
        //    {
        //        indexFirst = 0;
        //    }
        //    last = letterCount.Keys.Last();
        //    letterCount.Add(last + 1, LowerLetter[indexFirst].ToString() + UpperLetter[indexSecond]);

        //    indexSecond++;
        //    countRegect++;
        //}

        foreach (var item in letterCount)
        {
            if (item.Key == number)
            {
                Console.WriteLine(item.Value);
            }
        }
    }
}