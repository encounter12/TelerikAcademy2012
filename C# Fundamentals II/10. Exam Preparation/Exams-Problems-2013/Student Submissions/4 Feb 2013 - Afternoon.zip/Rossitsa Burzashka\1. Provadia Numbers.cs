using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;

            string[] arrayNumbers = new string[256];

            for (int i = 0,j=65; i < 26; i++,j++)
            {
                arrayNumbers[i] = Convert.ToString((char)j);
            }

            for (int k = 97, i = 26; i < 256; k++)
            {
                for (int j = 65; j < 91; j++,i++)
                {
                    if (i == 256)
                    {
                        i++;
                        break;
                    }
                    arrayNumbers[i] = Convert.ToString((char)k) + Convert.ToString((char)j);
                }
            }


            ulong decNumber = ulong.Parse(Console.ReadLine());

            //ulong decNumber = 1000;
            List<ulong> residue = new List<ulong>();

            for (; decNumber > 0; )
            {
                residue.Add(decNumber % 256);
                decNumber /= 256;
            }

            for (int i = residue.Count - 1; i>-1 ;i-- )
            {
                Console.Write(arrayNumbers[residue[i]]);
            }
        }
    }
}
