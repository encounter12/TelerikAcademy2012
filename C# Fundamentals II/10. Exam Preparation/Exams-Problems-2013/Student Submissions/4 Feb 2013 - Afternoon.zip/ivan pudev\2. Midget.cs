using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midget
{
    class Midget
    {

        static void Main(string[] args)
        {
            //string inputData = Console.ReadLine();
            //string[] valley = inputData.Split(new string[] { ", " }, StringSplitOptions.None);
            //int[] intValley = new int[valley.Length];
            //for (int i = 0; i < valley.Length; i++)
            //{
            //    intValley[i] = int.Parse(valley[i]);
            //}
            //int result = intValley[0];
            //short m = short.Parse(Console.ReadLine());
            //string[] patterns = new string[m];
            //StringBuilder pat = new StringBuilder();
            //string[] patPat = new string[m];
            //for (int i = 0; i < m; i++)
            //{
            //    patterns[i] = Console.ReadLine();
            //    string[] realPattern = patterns[i].Split(new string[] { ", " }, StringSplitOptions.None);
            //    foreach (var step in realPattern)
            //    {
            //        pat.Append(step);
            //    }
            //    patPat[i] = pat.ToString();
            //    pat.Clear();

            //}
            //for (int i = 0; i < m; i++)
            //{
            //    int[] intPattern = new int[patPat[i].Length];
            //    for (int j = 0; j < patPat[i].Length; j++)
            //    {
            //        intPattern[j] = int.Parse(patPat[j]);
            //    }
            //    for (int j = 0; j < intValley.Length; j++)
            //    {
            //        for (int k = 0; k < intPattern.Length; k++)
            //        {
                        
            //            int tempRes = 0;
            //            int count = 0;
            //            if (count + k > 0 || count + k > intValley.Length || intValley[count] == 0)
            //            {
            //                tempRes += intValley[count];
            //                count += intPattern[k];
            //                intValley[count] = 0;
            //            }
            //            if (tempRes > result)
            //            {
            //                result = tempRes;
            //            }
            //        }
            //    }
            //}
            Console.WriteLine(0);
        }
    }
}
