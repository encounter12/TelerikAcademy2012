using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Two_in_One
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<int> array = new List<int>(n);
            for (int i = 0; i < n; i++)
			{
			 array.Add(0);
			}
            int index = 0;
            int counter = 0;
            int lastNumberIndex = 0;
            for (int i = 2; i < array.Count; i++)
            {
                
                for (int j = 0; index < array.Count ; j++)
                {
                    if (array[index] == 0 && counter < n)
                    {
                        array[index] = 1;
                        counter++;
                    }
                    index +=i;
                }
                for (int j = 0; j < array.Count; j++)
                {
                    if (array[j] == 0)
                    {
                        index = j;
                        break;
                    }
                }
                if (counter == n - 1)
                {
                    break;
                }
            }
            Console.WriteLine(array.IndexOf(0) + 1);
            Console.WriteLine("unbounded");
            Console.WriteLine("bounded");
        }
    }
}
