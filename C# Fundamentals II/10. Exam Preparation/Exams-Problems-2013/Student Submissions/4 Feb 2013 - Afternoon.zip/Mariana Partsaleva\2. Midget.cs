 string valley = Console.ReadLine();
            valley = valley.Trim();
            int sum = 0;

            int p = int.Parse(Console.ReadLine());
            int[] patterns = new int[p];
            string[] strNums = valley.Split(' ');
            for (int k = 0; k < patterns.Length; k++)
            {
                string pattNums = Console.ReadLine();
                pattNums = pattNums.Trim();

            }

            for (int i = 0; i < strNums.Length; i++)
            {
               

            }
           // sum = sum + int.Parse(strNums[i].Trim());

            Console.WriteLine(sum);