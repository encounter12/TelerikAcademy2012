using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class ProvadiaNumber
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        char provNum = ' ';
        string temp = "aA";
        

             string [] arr = new string[256];
             List<string> number = new List<string>();
        for (int i = 0; i < 26; i++)
        {
            if (n == i)
            {
              
               Console.WriteLine(arr[i + 65]);
            }
        }
        for (int i = 0; i <arr.Length; i++)
        {
            if (n == i && n<26)
            {                
                Console.WriteLine((char)(i+65));
            }
            if (n >= 26 && n == i)
            {
                
                    
                }
            }
        }

    }
}

