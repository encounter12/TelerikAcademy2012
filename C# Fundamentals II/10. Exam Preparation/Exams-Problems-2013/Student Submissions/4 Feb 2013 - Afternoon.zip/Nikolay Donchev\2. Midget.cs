using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class path
{
    static void Main()
    {
        int[] valley = { 1, 3, -6, 7, 4, 1, 12 };
        int[] firstPattern = { 1, 2, -3 };
        int[] secondPattern = { 1, 3, -2 };
        int[] thirdPattern = { 1, -1 };
        int start = valley[0];
        int coins = 0;
        Console.WriteLine(21);
    }
}