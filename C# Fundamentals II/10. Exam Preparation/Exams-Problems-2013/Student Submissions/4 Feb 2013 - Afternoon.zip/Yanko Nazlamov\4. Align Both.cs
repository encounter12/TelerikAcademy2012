using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace align_both
{
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int w  = int.Parse(Console.ReadLine());
            string[] inputStrings = new string[n];
            for (int i = 0; i < n; i++)
            {
                inputStrings[i] = Console.ReadLine();
            }
            
            StringBuilder text = new StringBuilder(20);

            for (int j = 0; j < inputStrings.Length; j++)
            {
                text.Append(inputStrings[j]+" ");
            }
            string wholeText = text.ToString();
            string [] temp = new string[20];
            
            for (int k = 0; k < wholeText.Length; k++)
            {
                temp[k] = wholeText.Substring(k, w);
                
            }
            foreach (string item in temp)
            {
                Console.WriteLine(item);
            }
        }
    }
}
