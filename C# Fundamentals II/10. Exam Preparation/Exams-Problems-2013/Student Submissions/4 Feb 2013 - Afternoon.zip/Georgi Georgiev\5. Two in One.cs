using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoInOne
{
    class Program
    {
        static int lamps(int n)
        {
            int[] arr = new int[n];
            int step = 2;
            int last=0;
            bool ok = true;
            int i;
            int start;
            while (ok)
            {
                start = Array.IndexOf(arr, 0);
                if (start == -1)
                    break;
                for (i = start; i < n; i+=step)
                {
                    while (arr[i] == 1)
                    {
                        i++;
                        if (i >= arr.Count())
                        {
                            ok = false;
                            break;
                            
                        }
                    }
                    if (ok)
                    {
                        arr[i] = 1;
                        last = i;
                    }
                }
            }
            return last;
        }
        static string joroBot(string moves)
        {
            char[] steps = moves.ToCharArray();
            int turns=0;
            for (int i = 0; i < steps.Count(); i++)
            {
                if (steps[i] == 'L' || steps[i] == 'R') turns++;
            }
            if (turns % 2 == 1) return "bounded";
            else return "unbounded";
        }
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string moves1 = Console.ReadLine();
            string moves2 = Console.ReadLine();
            Console.WriteLine(lamps(n));
            Console.WriteLine(joroBot(moves1));
            Console.WriteLine(joroBot(moves2));
        }
    }
}
