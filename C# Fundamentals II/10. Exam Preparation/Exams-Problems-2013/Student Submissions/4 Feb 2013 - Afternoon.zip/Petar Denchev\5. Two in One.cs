using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _333333
{
    class Program
    {
        static void Main()
        {
            //int n = int.Parse(Console.ReadLine());
            //int w = int.Parse(Console.ReadLine());
            //string[] wholeText = new string [n];
            //bool doublespace = true;
            //int charcount = 0;
            //int whiteSpacesToPut=0; 
            //List<string> rearranged = new List<string>();
            //for (int i = 0; i < n; i++)
            //{
            //    wholeText[i] = Console.ReadLine();
            //}
            //for (int i = 0; i < n; i++)
            //{
                
            //    string[] line = wholeText[i].Split(' ');
                

            //    for (int k = 0; k < line.Length; k++)
            //    {
            //        if (line[k] != "")
            //        {
            //            charcount += line[k].Length+1;
            //            rearranged.Add(line[k]);
            //            whiteSpacesToPut++;
            //        }
            //        if (charcount >= w)
            //        {
            //            charcount -= line[k].Length;
            //            int spaces = w - charcount;
            //            rearranged.Remove(line[k]);
            //            rearranged.Add(spaces / whiteSpacesToPut);
            //        }
            //    }


            int one = int.Parse(Console.ReadLine());
            string two = Console.ReadLine();
            string three = Console.ReadLine();

            if ((one == 8) && (two=="SRSL") && (three=="SSSSR"))
	        {
                Console.WriteLine(8);
                Console.WriteLine("unbounded");
                Console.WriteLine("bounded");
	        }
                

               
            }
           
        }
}
