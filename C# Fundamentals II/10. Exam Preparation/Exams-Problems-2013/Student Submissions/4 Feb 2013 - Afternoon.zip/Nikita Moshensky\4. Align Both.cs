using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Align_Both
{
    class Program
    {
        static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());
            int w = int.Parse(Console.ReadLine());
            string line;
            List<string> words = new List<string>();
            StringBuilder text = new StringBuilder();
            string[] tmp;

            for (int i = 0; i < lines; i++)
            {
                line = Console.ReadLine();
                line = Regex.Replace(line, @"\s+", " ");
                tmp = line.Split();
                foreach (var item in tmp)
                {
                    if(!String.IsNullOrWhiteSpace(item))
                        words.Add(item);
                }                
            }

            
            List<string> newLine = new List<string>();
            for (int i = 0; i < words.Count; i++)
            {
                text.Append(words[i]);
                if (text.Length == w)
                {
                    Console.WriteLine(text);
                    text.Clear();
                    continue;
                }
                else if (text.Length > w)
                {
                    text.Remove((text.Length - words[i].Length), words[i].Length);
                    i--;
                    JustifyString(text, w);
                    text.Clear();
                    continue;
                }
                else if (text.Length < w && i == words.Count - 1)
                {
                    JustifyString(text, w);
                    text.Clear();
                    continue;
                }

                text.Append(" ");
                if (text.Length == w)
                {
                    JustifyString(text, w);
                    text.Clear();
                }
            }




        }

        private static void JustifyString(StringBuilder text, int w)
        {
            //Console.WriteLine("DEBUG:" + text);
            string[] word = (text.ToString()).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int wordCount = word.Length;
            if (wordCount == 1)
            {
                Console.WriteLine(word[0]);
                return;
            }


            int spacesCount = wordCount - 1;
            int spacesLength = 1;

            int textLength;

            text.Clear();
            for (int i = 0; i < word.Length - 1; i++)
            {
                text.Append(word[i]);
                for (int j = 0; j < spacesLength; j++)
                {
                    text.Append(" ");
                }
            }
            text.Append(word[word.Length - 1]);
            //spacesLength++;
            textLength = text.Length;
            int atSpace = 1;
            while (textLength != w)
            {
                AddSpace(text, spacesLength, atSpace);
                atSpace++;
                if (atSpace > spacesCount)
                {
                    atSpace = 1;
                    spacesLength++;
                }
                textLength = text.Length;
            }

            Console.WriteLine(text);
        }

        private static void AddSpace(StringBuilder text, int spacesLength, int atSpace)
        {
            string spaces = "";
            for (int i = 0; i < spacesLength; i++)
			{
                spaces += " ";
			}
            string str = text.ToString();
            int k=0;
            for (int i = 0; i < atSpace; i++)
            {
                k = str.IndexOf(spaces);
            }

            text.Insert(k, " ");
            
        }
    }
}
