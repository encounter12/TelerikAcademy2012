using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{

    public static void DecimalToHex(ulong digit)
    {
        string result = null;
        string hexDecimal = null;

        StringBuilder hex = new StringBuilder();
        StringBuilder mex = new StringBuilder();

        if (digit == 0)
        {
            Console.WriteLine("A");
        }
        else
        {
            while (digit > 0)
            {
                ulong divider = (digit % 256);
                digit = digit / 256;

                hex.Append(DigiToAlfabet(divider));
            }

            hex.ToString();

            for (int i = hex.Length - 1; i >= 0; i--)
            {
                mex.Append(hex[i]);
            }

            Console.WriteLine(mex.ToString());
        }
    }

    public static string DigiToAlfabet(ulong digit)
    {

        char[] bigg = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
        char[] small = { ' ','a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };

        if (digit > 25 && digit < 256)
        {
            // small alfabet
            ulong set = (digit / 26);

            // big alfabet
            ulong met = (digit % 26);

            return (bigg[met] + "" +small[set] );
        }
        else
        {
            return bigg[digit].ToString();
        }
    }


    static void Main(string[] args)
    {
        ulong test = ulong.Parse(Console.ReadLine());
        DecimalToHex(test);
        
    }
}
