using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1_ProvadiaNumbers
{
    class Program
    {

        static void Main(string[] args)
        {
            ulong number;
            ulong rem = 0;
            ulong decCase = 0;
            ulong dec = 0;

            char[] cases = new char[26];
            StringBuilder outputNum = new StringBuilder();


            for (int i = 0; i < 26; i++)
            {
                cases[i] = (char)(i + 65);
            }

            Console.WriteLine("Enter a decimal number: ");
            number = ulong.Parse(Console.ReadLine());
            
            dec = number / 256;
            if (dec == 0)
            {
                decCase = number / 26;
                rem = number % 26;
                if (decCase != 0)
                {
                    outputNum.Append(cases[decCase-1].ToString().ToLower());
                }
                outputNum.Append(cases[rem]);
            }
            else {

                while (number / 256 != 0)
                {
                    if ((number / 256) / 26 == 0)
                    {
                        outputNum.Append(cases[(number / 256)]);
                    }
                    else
                    {
                        decCase = (number / 256) / 26;
                        rem = (number / 256) % 26;
                        if (decCase != 0)
                        {
                            outputNum.Append(cases[decCase-1].ToString().ToLower());
                        }
                        outputNum.Append(cases[rem]);
                    }
                    number = number - (number / 256) * 256;

                    decCase = number / 26;
                    rem = number % 26;
                    if (decCase != 0)
                    {
                        outputNum.Append(cases[decCase-1].ToString().ToLower());
                    }
                    outputNum.Append(cases[rem]);
                        
                }
            }

            Console.WriteLine("The number in Provadia number system is:");
            Console.WriteLine(outputNum.ToString());
        }
    }
}
