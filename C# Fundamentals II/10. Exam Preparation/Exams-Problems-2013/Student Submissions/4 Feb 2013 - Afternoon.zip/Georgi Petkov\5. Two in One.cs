using System;

class Program
{
    private static bool IsPrime(int n)
    {
        //already checked for 2 and beening even
        int sqrt = (int)Math.Sqrt(n);
        for (int i = 3; i <= sqrt; i += 2)
        {
            if (n % i == 0)
            {
                return false;
            }
        }
        return true;
    }

    private static int FindBiggestPrime(int n)
    {
        if (n == 2)
        {
            return n;
        }
        if (n % 2 == 0)
        {
            --n;
        }
        while (!IsPrime(n))
        {
            n -= 2;
        }
        return n;
    }

    public static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        if (n == 1)
        {
            Console.WriteLine(1);
        }
        else
        {
            Console.WriteLine(FindBiggestPrime(n + 1) - 1);
        }

        for (int i = 0; i < 2; ++i)
        {

            string command = Console.ReadLine();
            int length = command.Length;
            int direction = 0;
            int x = 0, y = 0;
            int rightTurns = 0;
            for (int j = 0; j < length; ++j)
            {
                switch (command[j])
                {
                    case 'S':
                        switch (direction)
                        {
                            case 0: ++x; break;
                            case 1: ++y; break;
                            case 2: --x; break;
                            case 3: --y; break;
                        }
                        break;
                    case 'L':
                        direction = (direction + 1) % 4;
                        --rightTurns;
                        break;
                    case 'R':
                        direction = (direction - 1) % 4;
                        ++rightTurns;
                        break;
                }
            }
            int turns = Math.Abs(rightTurns) % 4;
            if (x == 0 && y == 0 || turns == 2 || ((turns == 1 || turns == 3) && (Math.Abs(x) == Math.Abs(y) || x == 0 || y == 0)))
            {
                Console.WriteLine("bounded");
            }
            else
            {
                Console.WriteLine("unbounded");
            }
        }
    }
}