using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem2_Midget
{
    class Program
    {
        static int[] ParseValeys(string text)
        {
            string[] parsedString = text.Split(',');
            int[] parsedInt = new int[parsedString.Length];
            for (int p = 0; p < parsedInt.Length; p++)
            {
                parsedInt[p] = int.Parse(parsedString[p].Trim());
            }
            return parsedInt;
        }
        static void Main(string[] args)
        {
            string valeyNumbers = Console.ReadLine();
            int M = int.Parse(Console.ReadLine());
            int[] valeyNumbersInt = ParseValeys(valeyNumbers);
            long sum = 0;
            int current = 0;
            long max = int.MinValue;
            List<int> currents = new List<int>();

            string[] patterns = new string[M];
            int[][] patternsInt = new int[M][];
            for (int m = 0; m < M; m++)
            {
                patterns[m] = Console.ReadLine();
                patternsInt[m] = ParseValeys(patterns[m]); 
            }
  
            for (int i = 0; i < patternsInt.Length; i++)
            {          
                for (int k = 0; k < patternsInt[i].Length; k++)
                {
                    bool passed = false;
                    current += patternsInt[i][k];
                    for (int c = 0; c < currents.Count; c++)
                    {
                        if (current == currents[c])
                        {
                            passed = true;
                        }
                    }
                    currents.Add(current);
                    if (current < valeyNumbersInt.Length && current >= 0 && passed == false)
                    {
                        sum += (valeyNumbersInt[current]);
                        if (sum > max)
                        {
                            max = sum;
                        }
                    }
                    else
                    {
                        break;
                    }
                    passed = false;
                }
                sum = 0;
                current = 0;
            }
            Console.WriteLine(max);
        }
    }
}
