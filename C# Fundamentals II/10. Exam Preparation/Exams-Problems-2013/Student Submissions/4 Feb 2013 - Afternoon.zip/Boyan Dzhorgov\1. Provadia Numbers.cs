using System;
using System.Collections.Generic;

namespace Problem1ProvadiaNumbers
{
    class Problem1ProvadiaNumbers
    {
        static void Main()
        {
            Console.WriteLine("Enter a decimal number to convert it into its corresponding representation in Provadia: ");
            ulong number = ulong.Parse(Console.ReadLine());
            ulong quotent = 1;
            ulong reminder = 0;

            while (quotent > 0)
            {
                quotent = number / 256;
                reminder = number % 256;
                Console.WriteLine(reminder);
                number = quotent;
            }
            // n / m = quotient + remainder / m
        }
    }
}