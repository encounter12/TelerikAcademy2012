using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Problem1
{
    ulong num=0;
    ulong[] s = new ulong[512];
    string[] c = new string[512];

    void read() {

        string imp;
        imp=Console.ReadLine();

        int i;
        for( i=0; i<imp.Length; ++i ) 
        {

            //Console.WriteLine(num);
            num*=10;

            num=num + imp[i]-'0';
        }

       // Console.WriteLine(num);
    }

    void solve ()  {

        int n=0, i;
if( num == 0 ) Console.Write( 'A' );

        while( num!=0 ) {

            s[n]=num%256 ;
            num/=256;
            ++n;
        }
        char c1='A', c2='a';
        bool k=false;
        for( i = 0; i<256; ++i ) {

            if (k)
            {

                c[i] += c2;
                c[i] += c1;
            }
            else c[i] += c1;
            c1++;
            if( c1 > 'Z' ) {
                
                c1='A';
                if( k ) c2++;
                else k=true;
            }
        }


        

        for( i=n-1; i>=0; --i ) 

            Console.Write( c[s[i]] );
        

    }

    static void Main()
    { 

        Problem1 c = new Problem1();
        c.read();
        c.solve();
    }
}
