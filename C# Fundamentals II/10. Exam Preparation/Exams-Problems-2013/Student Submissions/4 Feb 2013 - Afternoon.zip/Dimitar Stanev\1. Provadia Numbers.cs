using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp___TelerikExam2
{
    class Task1
    {
        static void Main(string[] args)
        {
            decimal number = decimal.Parse(Console.ReadLine());
            if (number >= 0 && number <= 18446744073709551615)
            {
                char[] BigAlphabet = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I' , 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S' , 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
                char[] SmallAlphabet = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
                string[] realAlphabet = new string[256];
                List<string> realAlpha = new List<string>();
                Dictionary<decimal, string> Dict = new Dictionary<decimal,string>();
                for (decimal i = 0; i < 26; i++)
                {
                    Dict.Add(i, Convert.ToString(BigAlphabet[Convert.ToUInt32(i)]));
                }
                decimal counter = 26;
                for (decimal i = 0; i < 9; i++)
                {
                    for (decimal j = 0; j < 26; j++)
                    {
                        if (i == 8 && j >= 22)
                        {
                            break;
                        }
                        else
                        {
                            Dict.Add(System.Math.Truncate(counter) , String.Concat(Convert.ToString(SmallAlphabet[Convert.ToInt32(i)]), Convert.ToString(BigAlphabet[Convert.ToInt32(j)])));
                            counter++;
                        }
                    }
                }
                if (number <= 256)
                {
                    Console.WriteLine(Dict[System.Math.Truncate(number)]);
                }
                else 
                {
                    string result = string.Empty;
                    do
                    {   
                         result = Dict[System.Math.Truncate(number%256)] + result;
                         number = System.Math.Truncate(number / 256);
                    }
                    while (System.Math.Truncate(number) > 0);
                    Console.WriteLine(result);
                }
            }
        }
    }
}