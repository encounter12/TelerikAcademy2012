
using System;

 

  

 

class Problem1

 

{

 

  

 

    static void Main()

 

    {

 

  

 

        ulong input = ulong.Parse(Console.ReadLine());

 

  

 

        char letter = 'A';

 

  

 

        char[] smallLetters = new char[26];

 

  

 

        uint counter = 0;

 

  

 

        for (int i = 0; i <= smallLetters.Length - 1; i++)

 

        {

 

  

 

            smallLetters[i] = (char)('a' + i - 1);

 

  

 

        }

 

  

 

        if (input >= 26)

 

        {

 

  

 

            while (input >= 26)

 

            {

 

  

 

                counter++;

 

  

 

                input -= 26;

 

  

 

            }

 

  

 

            Console.WriteLine("{0}{1}", smallLetters[counter], (char)(letter + input));

 

        }

 

        else

 

        {

 

            Console.WriteLine((char)(letter + input));

 

  

 

        }

 

    }

 

}