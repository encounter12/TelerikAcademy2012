using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03_BallInCubiod
{
    class Program
    {
        static void Main(string[] args)
        {
            string size = Console.ReadLine();
            int width = int.Parse(size.Split()[0]);
            int height = int.Parse(size.Split()[1]);
            int depth = int.Parse(size.Split()[2]);
            string[, ,] cube = new string[width, height, depth];
            for (int h = 0; h < height; h++)
            {
                string row = Console.ReadLine();
                string[] rowParts = row.Split(new string[] { ") | (" }, StringSplitOptions.RemoveEmptyEntries);
                for (int d = 0; d < depth; d++)
                {
                    rowParts[d] = rowParts[d].TrimStart('(');
                    rowParts[d] = rowParts[d].TrimEnd(')');
                    string[] cells = rowParts[d].Split(new string[] { ")(" }, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < width; w++)
                    {
                        cube[w, h, d] = cells[w];
                    }
                }
            }
            //for (int w = 0; w < width; w++)
            //{
            //    for (int h = 0; h < height; h++)
            //    {
            //        for (int d = 0; d < depth; d++)
            //        {
            //            Console.Write(cube[w,h,d] + "    ");
            //        }
            //        Console.WriteLine();
            //    }
            //    Console.WriteLine();
            //}
            string ballInitialPos = Console.ReadLine();
            int ballWidth = int.Parse(ballInitialPos.Split()[0]);
            int ballDepth = int.Parse(ballInitialPos.Split()[1]);
            int ballHeight = 0;
            string ball = cube[ballWidth, ballHeight, ballDepth];

            while (ballHeight < height - 1)
            {
                ball = cube[ballWidth, ballHeight, ballDepth];
                if (ball == "B")
                {
                    Console.WriteLine("No");
                    Console.WriteLine("{0} {1} {2}", ballWidth, ballHeight, ballDepth);
                    break;
                }
                if (ball == "E")
                {
                    ballHeight++;
                    ball = cube[ballWidth, ballHeight, ballDepth];
                }
                if (ball.StartsWith("S"))
                {
                    string direction = ball.Substring(2);
                    switch (direction)
                    {
                        case "R":
                            {
                                if (ballWidth == width - 1)
                                {
                                    Console.WriteLine("No");
                                    Console.WriteLine("{0} {1} {2}", ballWidth, ballHeight, ballDepth);
                                    return;
                                }
                                else
                                {
                                    ballHeight++;
                                    ballWidth++;
                                }
                            }
                            break;
                        case "L":
                            {
                                if (ballWidth == 0)
                                {
                                    Console.WriteLine("No");
                                    Console.WriteLine("{0} {1} {2}", ballWidth, ballHeight, ballDepth);
                                    return;
                                }
                                else
                                {
                                    ballWidth--;
                                    ballHeight++;
                                }
                            }
                            break;
                        case "B":
                            {
                                if (ballDepth == depth - 1)
                                {
                                    Console.WriteLine("No");
                                    Console.WriteLine("{0} {1} {2}", ballWidth, ballHeight, ballDepth);
                                    return;
                                }
                                else
                                {
                                    ballDepth++;
                                    ballHeight++;
                                }
                            }
                            break;

                        case "F":
                            {
                                if (ballDepth == 0)
                                {
                                    Console.WriteLine("No");
                                    Console.WriteLine("{0} {1} {2}", ballWidth, ballHeight, ballDepth);
                                    return;
                                }
                                else
                                {
                                    ballDepth--;
                                    ballHeight++;
                                }
                            }
                            break;
                        case "FL":
                            {
                                if (ballDepth == 0 || ballWidth == 0)
                                {
                                    Console.WriteLine("No");
                                    Console.WriteLine("{0} {1} {2}", ballWidth, ballHeight, ballDepth);
                                    return;
                                }
                                else
                                {
                                    ballWidth--;
                                    ballDepth--;
                                    ballHeight++;
                                }
                            }
                            break;
                        case "FR":
                            {
                                if (ballDepth == 0 || ballWidth == width - 1)
                                {
                                    Console.WriteLine("No");
                                    Console.WriteLine("{0} {1} {2}", ballWidth, ballHeight, ballDepth);
                                    return;
                                }
                                else
                                {
                                    ballDepth--;
                                    ballWidth++;
                                    ballHeight++;
                                }
                            }
                            break;
                        case "BL":
                            {
                                if (ballDepth == depth - 1 || ballWidth == 0)
                                {
                                    Console.WriteLine("No");
                                    Console.WriteLine("{0} {1} {2}", ballWidth, ballHeight, ballDepth);
                                    return;
                                }
                                else
                                {
                                    ballDepth++;
                                    ballWidth--;
                                    ballHeight++;
                                }
                            }
                            break;
                        case "BR":
                            {
                                if (ballDepth == depth - 1 || ballWidth == width - 1)
                                {
                                    Console.WriteLine("No");
                                    Console.WriteLine("{0} {1} {2}", ballWidth, ballHeight, ballDepth);
                                    return;
                                }
                                else
                                {
                                    ballDepth++;
                                    ballWidth++;
                                    ballHeight++;
                                }
                            }
                            break;
                    }
                }
                if (ball.StartsWith("T"))
                {
                    string coords = ball.Substring(2);
                    ballWidth = int.Parse(coords.Split()[0]);
                    ballDepth = int.Parse(coords.Split()[1]);
                }
            }
            if (ball.StartsWith("S"))
            {
                Console.WriteLine("Yes");
                Console.WriteLine("{0} {1} {2}", ballWidth, ballHeight, ballDepth);
            }

            if (ball.StartsWith("T"))
            {
                string coords = ball.Substring(2);
                ballWidth = int.Parse(coords.Split()[0]);
                ballDepth = int.Parse(coords.Split()[1]);
            }
            if (ball == "B")
            {
                Console.WriteLine("No");
                Console.WriteLine("{0} {1} {2}", ballWidth, ballHeight, ballDepth);
                return;
            }
            if (ball == "E")
            {
                Console.WriteLine("Yes");
                Console.WriteLine("{0} {1} {2}", ballWidth, ballHeight, ballDepth);
            }

        }
    }
}
