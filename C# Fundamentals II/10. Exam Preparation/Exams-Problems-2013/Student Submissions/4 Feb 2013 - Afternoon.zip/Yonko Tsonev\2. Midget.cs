using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midgets
{
    class Program
    {
        static string[] valley;
        static void Main(string[] args)
        {
            string line = Console.ReadLine().Trim();

            valley = line.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int m = int.Parse(Console.ReadLine());
            List<string[]> patterns=new List<string[]>();
            for (int i = 0; i < m; i++)
			{
			   patterns.Add(Console.ReadLine().Split(new char[]{',',' '},StringSplitOptions.RemoveEmptyEntries));
			}
            int maxSum=0;
            for (int i = 0; i < m; i++)
			{
			  int sum = WalkTheValley(patterns[i]);
                if (sum>maxSum)
	            {
		            maxSum=sum;
	            }
			}
            Console.WriteLine(maxSum);
        }

        private static int WalkTheValley(string[] p)
        {
            int step = 0;
            List<int> previousSteps = new List<int>();
            int coins = 0;
            for (int i = 0; i <=p.Length; i++)
            {
                if (i==p.Length)
                {
                    i = 0; 
                }
                for (int z = 0; z < previousSteps.Count; z++)
                {
                    if (step==previousSteps[z])
                    {
                        return coins;
                    }
                }
                coins +=int.Parse(valley[step]);
                previousSteps.Add(step);
                
                    step = step+int.Parse(p[i]);
                

                if (step>valley.Length-1||step<0)
                {
                    return coins;
                }
            }
            return coins;
        }
    }
}
