// Tasc5 First half
using System;
using System.Text;
class Program
{
    static void Main()
    {
        int N = int.Parse(Console.ReadLine());
        bool[] A = new bool[N];
        bool StartGo = false,
             PaleniLampi = true;
        int Start = 1;
        int Step = 2, i = 1;
        int Last = 1;
        //A[0] = true;
        while (PaleniLampi)
        {
            //foreach (var j in A)
            //    if (j) Console.Write("1 ", j);
            //    else Console.Write("0 ");
            //Console.WriteLine();
 
            PaleniLampi = false;
            Start = 1;
            while ((Start <= N))
            {
                if (!A[Start - 1])
                {
                    if ((i == Step))
                    { // Palim
                        PaleniLampi = true;
                        A[Start - 1] = true;
                        Last = Start;
                        i = 1;
                    }
                    else
                        if (!StartGo)
                        {
                            StartGo = true;
                            PaleniLampi = true;
                            A[Start - 1] = true;
                            Last = Start;
                            i = 1;
                        }
                        else i++;
 
                }
                Start++;
            }
            Step++;
            StartGo = false;
        } //  PaleniLampi
        Console.WriteLine(Last);
        for (int k = 0; k < 2; k++)
        {
            int X = 0, Y = 0, Pos = 0;
       //     int X1 = 0, Y1 = 0;
            string B = Console.ReadLine();
            StringBuilder BB = new StringBuilder();
            BB.Append(B);
            bool FlagD = false;
            for (int j = 0; j < 4; j++)
            {
                for (int ii = 0; ii < BB.Length; ii++)
                {
                    switch (BB[ii])
                    {
                        case 'S':
                            {
                                FlagD = true;
                                //switch (Pos)
                                //{
                                //    case 0: Y++; break;
                                //    case 1: X++; break;
                                //    case 2: Y--; break;
                                //    case 3: X--; break;                                }
                                break;
                            }
                        case 'L':                            {
                                Pos--;
                                if (Pos < 0) Pos = 3;
                                break;
                            }
                        case 'R':                            {
                                Pos++;
                                if (Pos > 3) Pos = 0;
                                break;
                            }
                    }// 
                }
                if (!FlagD) break;
                if ((Pos != 0))
                {
                    X = 0;
                    Y = 0;
                    break;
                }
            }
            if ((X==0) && (Y== 0))
                Console.WriteLine("bounded");
            else
                Console.WriteLine("unbounded");           
        }
    }
}