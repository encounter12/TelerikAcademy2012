using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
   
namespace ProvadiaNumbers
{
    class ProvadiaNumbers
    {
   
        static char[] lowerLetters = {'a','b','c','d','e','f','g','h','i'};
        static char[] upperLetters = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
                                       'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
        static StringBuilder provadiaNumber = new StringBuilder();
   
        static void Main(string[] args)
        {
            ulong decimalNumber = ulong.Parse(Console.ReadLine());
   
            if (decimalNumber == 0) provadiaNumber.Append(upperLetters[decimalNumber]);
 
            while (decimalNumber > 0)
            {
                calculate256(decimalNumber % 256);
                decimalNumber /= 256;
            }
            Console.WriteLine(provadiaNumber);
        }
   
        static void calculate256(ulong number)
        {
            if (number < 26)
                provadiaNumber.Insert(0, upperLetters[(int)number]);
            else
            {
                int buffer = (int)(number / 26);
                provadiaNumber.Insert(0, upperLetters[(int)number - buffer * 26]);
                provadiaNumber.Insert(0, lowerLetters[buffer - 1]);
            }
        }
    }
}