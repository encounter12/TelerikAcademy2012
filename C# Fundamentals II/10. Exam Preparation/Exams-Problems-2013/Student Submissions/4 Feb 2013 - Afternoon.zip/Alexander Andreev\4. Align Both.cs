using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class formating
    {
        static void Main()
        {
            int lines = int.Parse(Console.ReadLine());
            int lineWidth = int.Parse(Console.ReadLine());
            if (lines == 0)
            Console.WriteLine();
            else
            {
                char[] delimiters = { ' ', ',' };
                StringBuilder Text = new StringBuilder();
                for (int i = 0; i < lines; i++)
                {
                    string textline = Convert.ToString(Console.ReadLine());
                    string[] TextWords = textline.Split(delimiters,
                    StringSplitOptions.RemoveEmptyEntries);
                    for (int l = 0; l < TextWords.Length; l++)
                    {
                        Text.Insert(Text.Length, ' ');
                        Text.Insert(Text.Length, TextWords[l]);

                    }
                }
                string[] finalTextWord = Text.ToString().Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
                int spacesHaving = 0;
                int gapsSum;
                int wordsInRow = 0;
                int minimalGap = 0;
                int wordsWithBiggerGap = 0;
                int numberOfGaps = 0;
                int wordNumber = 0;
                while(wordNumber<finalTextWord.Length)
                {
                    spacesHaving = 0;
                    wordsInRow = 0;
                    while (true)
                        {
                          if (5 == 6)
                          {
                              int indexSpec = wordNumber;
                              for (int f = 0; f < finalTextWord.Length - indexSpec; f++)
                              {
                                  spacesHaving += finalTextWord[wordNumber].Length + 1;
                                  wordsInRow++;
                                  wordNumber++;
                              }
                              gapsSum = (lineWidth - spacesHaving) + wordsInRow;
                              numberOfGaps = wordsInRow - 1;
                              if (numberOfGaps == 0)
                              {
                                  minimalGap = 0;
                                  wordsWithBiggerGap = 0;
                              }
                              else
                              {
                                  minimalGap = gapsSum / numberOfGaps;
                                  wordsWithBiggerGap = gapsSum % numberOfGaps;
                              }

                              for (int printcycle = 0; printcycle < wordsInRow; printcycle++)
                              {
                                  Console.Write(finalTextWord[wordNumber - wordsInRow + printcycle]);
                                  if (printcycle < wordsWithBiggerGap)
                                  {
                                      if (printcycle + 1 < wordsInRow)
                                      {
                                          for (int g = 0; g < minimalGap + 1; g++)
                                          {
                                              Console.Write(" ");
                                          }
                                      }
                                  }
                                  else
                                  {
                                      if (printcycle + 1 < wordsInRow)
                                      {
                                          for (int h = 0; h < minimalGap; h++)
                                          {
                                              Console.Write(" ");
                                          }
                                      }
                                  }
                              }
                              break;
                          }
                          else if (wordNumber < finalTextWord.Length && spacesHaving + finalTextWord[wordNumber].Length <= lineWidth)
                          {
                              spacesHaving += finalTextWord[wordNumber].Length + 1;
                              wordsInRow++;
                              wordNumber++;
                          }
                          else
                          {
                              gapsSum = (lineWidth - spacesHaving) + wordsInRow;
                              numberOfGaps = wordsInRow - 1;
                              if (numberOfGaps == 0)
                              {
                                  minimalGap = 0;
                                  wordsWithBiggerGap = 0;
                              }
                              else
                              {
                                  minimalGap = gapsSum / numberOfGaps;
                                  wordsWithBiggerGap = gapsSum % numberOfGaps;
                              }
                              for (int printcycle = 0; printcycle < wordsInRow; printcycle++)
                              {
                                  Console.Write(finalTextWord[wordNumber - wordsInRow + printcycle]);
                                  if (printcycle < wordsWithBiggerGap)
                                  {
                                      if (printcycle + 1 < wordsInRow)
                                      {
                                          for (int g = 0; g < minimalGap + 1; g++)
                                          {
                                              Console.Write(" ");
                                          }
                                      }
                                  }
                                  else
                                  {
                                      if (printcycle + 1 < wordsInRow)
                                      {
                                          for (int h = 0; h < minimalGap; h++)
                                          {
                                              Console.Write(" ");
                                          }
                                      }
                                  }
                              }
                              break;
                          }
                        }
                    Console.WriteLine();
                }
            }
        }
    }
