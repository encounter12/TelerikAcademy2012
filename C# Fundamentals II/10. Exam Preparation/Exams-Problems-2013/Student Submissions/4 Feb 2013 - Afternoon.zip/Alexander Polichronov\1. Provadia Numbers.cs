using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProvadiaNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder numbersAndLetters = new StringBuilder();
            ulong number = ulong.Parse(Console.ReadLine());
            ulong p = 0L;


            while (number != 0)
            {
                p = number & (ulong)255;

                if (p <= 25)
                {
                    numbersAndLetters.Append((char)(p + 65)+",");
                }
                else if (p > 25 && p <= 51)
                {
                    p -= (26 * 1);
                    numbersAndLetters.Append("a" + (char)(p + 65) + ",");
                }
                else if (p > 51 && p <= 77)
                {
                    p -= (26 * 2);
                    numbersAndLetters.Append("b" + (char)(p + 65) + ",");
                }
                else if (p > 77 && p <= 103)
                {
                    p -= (26 * 3);
                    numbersAndLetters.Append("c" + (char)(p + 65) + ",");
                }
                else if (p > 103 && p <= 129)
                {
                    p -= (26 * 4);
                    numbersAndLetters.Append("d" + (char)(p + 65) + ",");
                }
                else if (p > 129 && p <= 155)
                {
                    p -= (26 * 5);
                    numbersAndLetters.Append("e" + (char)(p + 65) + ",");
                }
                else if (p > 155 && p <= 181)
                {
                    p -= (26 * 6);
                    numbersAndLetters.Append("f" + (char)(p + 65) + ",");
                }
                else if (p > 181 && p <= 207)
                {
                    p -= (26 * 7);
                    numbersAndLetters.Append("g" + (char)(p + 65) + ",");
                }
                else if (p > 207 && p <= 233)
                {
                    p -= (26 * 8);
                    numbersAndLetters.Append("h" + (char)(p + 65) + ",");
                }
                else if (p > 155 && p <= 255)
                {
                    p -= (26 * 9);
                    numbersAndLetters.Append("i" + (char)(p + 65) + ",");
                }

                number >>= 8;
               
            }
           
            string numLet = numbersAndLetters.ToString();
            char[] ch = { ','};
            string[] numbers = numLet.Split(ch, StringSplitOptions.RemoveEmptyEntries);
            for (int i = numbers.Length-1; i >=0 ; i--)
            {
                 Console.Write(numbers[i]);
            }
            Console.WriteLine();
        }
    }
}