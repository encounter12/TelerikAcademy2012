using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int number1 = int.Parse(Console.ReadLine());
           
            
            switch (number1)
            {
                case 0: Console.WriteLine("A"); break;
                case 1: Console.WriteLine("B"); break;
                case 2: Console.WriteLine("C"); break;
                case 3: Console.WriteLine("D"); break;
                case 4: Console.WriteLine("E"); break;
                case 5: Console.WriteLine("F"); break;
                case 6: Console.WriteLine("G"); break;
                case 7: Console.WriteLine("H"); break;
                case 8: Console.WriteLine("I"); break;
                case 9: Console.WriteLine("J"); break;
                case 10: Console.WriteLine("K"); break;
                case 11: Console.WriteLine("L"); break;
                case 12: Console.WriteLine("M"); break;
                case 13: Console.WriteLine("N"); break;
                case 14: Console.WriteLine("O"); break;
                case 15: Console.WriteLine("P"); break;
                case 16: Console.WriteLine("Q"); break;
                case 17: Console.WriteLine("R"); break;
                case 18: Console.WriteLine("S"); break;
                case 19: Console.WriteLine("T"); break;
                case 20: Console.WriteLine("U"); break;
                case 21: Console.WriteLine("V"); break;
                case 22: Console.WriteLine("W"); break;
                case 23: Console.WriteLine("X"); break;
                case 24: Console.WriteLine("Y"); break;
                case 25: Console.WriteLine("Z"); break;
                case 26: Console.WriteLine("aA"); break;
                case 27: Console.WriteLine("aB"); break;
                case 28: Console.WriteLine("aC"); break;
                case 29: Console.WriteLine("aD"); break;
                case 30: Console.WriteLine("aE"); break;
                case 31: Console.WriteLine("aF"); break;
                case 32: Console.WriteLine("aG"); break;
                case 33: Console.WriteLine("aH"); break;
                case 34: Console.WriteLine("aI"); break;
                case 35: Console.WriteLine("aJ"); break;
                case 36: Console.WriteLine("aK"); break;
                case 37: Console.WriteLine("aL"); break;
                case 38: Console.WriteLine("aM"); break;
                case 39: Console.WriteLine("aN"); break;
                case 40: Console.WriteLine("aO"); break;
                case 41: Console.WriteLine("aP"); break;
                    case 42: Console.WriteLine("aQ"); break;
                    case 43: Console.WriteLine("aR"); break;
                    case 44: Console.WriteLine("aS"); break;
                    case 45: Console.WriteLine("aT"); break;
                    case 46: Console.WriteLine("aU"); break;
                    case 47: Console.WriteLine("aV"); break;
                    case 48: Console.WriteLine("aW"); break;
                    case 49: Console.WriteLine("aX"); break;
                    case 50: Console.WriteLine("aY"); break;
                    case 51: Console.WriteLine("aZ"); break;
                    case 52: Console.WriteLine("bA"); break;
                    case 53: Console.WriteLine("bB"); break;
                    case 54: Console.WriteLine("bC"); break;
                    case 55: Console.WriteLine("bD"); break;
                    case 56: Console.WriteLine("bE"); break;
                    case 57: Console.WriteLine("bF"); break;
                    case 58: Console.WriteLine("bG"); break;
                    case 59: Console.WriteLine("bH"); break;
                    case 60: Console.WriteLine("bI"); break;
                    case 61: Console.WriteLine("bJ"); break;
                    case 62: Console.WriteLine("bK"); break;
                    case 63: Console.WriteLine("bL"); break;
                    case 64: Console.WriteLine("bM"); break;
                    case 65: Console.WriteLine("bN"); break;
                    case 66: Console.WriteLine("bO"); break;
                    case 67: Console.WriteLine("bP"); break;
                    case 68: Console.WriteLine("bQ"); break;
                    case 69: Console.WriteLine("bR"); break;
                    case 70: Console.WriteLine("bS"); break;
                    case 71: Console.WriteLine("bT"); break;
                    case 72: Console.WriteLine("bU"); break;
                    case 73: Console.WriteLine("bV"); break;
                    case 74: Console.WriteLine("bW"); break;
                    case 75: Console.WriteLine("bX"); break;
                    case 76: Console.WriteLine("bY"); break;
                    case 77: Console.WriteLine("bZ"); break;
                    case 78: Console.WriteLine("cA"); break;
                    case 79: Console.WriteLine("cB"); break;
                    case 80: Console.WriteLine("cC"); break;
                    case 81: Console.WriteLine("cD"); break;
                    case 82: Console.WriteLine("cE"); break;
                    case 83: Console.WriteLine("cF"); break;
                    case 84: Console.WriteLine("cG"); break;
                    case 85: Console.WriteLine("cH"); break;
                    case 86: Console.WriteLine("cI"); break;
                    case 87: Console.WriteLine("cJ"); break;
                    case 88: Console.WriteLine("cK"); break;
                    case 89: Console.WriteLine("cL"); break;
                    case 90: Console.WriteLine("cM"); break;
                    case 91: Console.WriteLine("cN"); break;
                    case 92: Console.WriteLine("cO"); break;
                    case 93: Console.WriteLine("cP"); break;
                    case 94: Console.WriteLine("cQ"); break;
                    case 95: Console.WriteLine("cR"); break;
                    case 96: Console.WriteLine("cS"); break;
                    case 97: Console.WriteLine("cT"); break;
                    case 98: Console.WriteLine("cU"); break;
                    case 99: Console.WriteLine("cV"); break;
                    case 100: Console.WriteLine("cW"); break;
                    case 101: Console.WriteLine("cX"); break;
                    case 102: Console.WriteLine("cY"); break;
                    case 103: Console.WriteLine("cZ"); break;
                    case 104: Console.WriteLine("dA"); break;
                    case 105: Console.WriteLine("dB"); break;
                    case 106: Console.WriteLine("dC"); break;
                    case 107: Console.WriteLine("dD"); break;
                    case 108: Console.WriteLine("dE"); break;
                    case 109: Console.WriteLine("dF"); break;
                    case 110: Console.WriteLine("dG"); break;
                    case 111: Console.WriteLine("dH"); break;
                    case 112: Console.WriteLine("dI"); break;
                    case 113: Console.WriteLine("dJ"); break;
                    case 114: Console.WriteLine("dK"); break;
                    case 115: Console.WriteLine("dL"); break;
                    case 116: Console.WriteLine("dM"); break;
                    case 117: Console.WriteLine("dN"); break;
                    case 118: Console.WriteLine("dO"); break;
                    case 119: Console.WriteLine("dP"); break;
                    case 120: Console.WriteLine("dQ"); break;
                    case 121: Console.WriteLine("dR"); break;
                    case 122: Console.WriteLine("dS"); break;
                    case 123: Console.WriteLine("dT"); break;
                    case 124: Console.WriteLine("dU"); break;
                    case 125: Console.WriteLine("dV"); break;
                    case 126: Console.WriteLine("dW"); break;
                    case 127: Console.WriteLine("dX"); break;
                    case 128: Console.WriteLine("dY"); break;
                    case 129: Console.WriteLine("dZ"); break;
                    case 130: Console.WriteLine("eA"); break;
                    case 131: Console.WriteLine("eB"); break;
                    case 132: Console.WriteLine("eC"); break;
                    case 133: Console.WriteLine("eD"); break;
                    case 134: Console.WriteLine("eE"); break;
                    case 135: Console.WriteLine("eF"); break;
                    case 136: Console.WriteLine("eG"); break;
                    case 137: Console.WriteLine("eH"); break;
                    case 138: Console.WriteLine("eI"); break;
                    case 139: Console.WriteLine("eJ"); break;
                    case 140: Console.WriteLine("eK"); break;
                    case 141: Console.WriteLine("eL"); break;
                    case 142: Console.WriteLine("eM"); break;
                    case 143: Console.WriteLine("eN"); break;
                    case 144: Console.WriteLine("eO"); break;
                    case 145: Console.WriteLine("eP"); break;
                    case 146: Console.WriteLine("eQ"); break;
                    case 147: Console.WriteLine("eR"); break;
                    case 148: Console.WriteLine("eS"); break;
                    case 149: Console.WriteLine("eT"); break;
                    case 150: Console.WriteLine("eU"); break;
                    case 151: Console.WriteLine("eV"); break;
                    case 152: Console.WriteLine("eW"); break;
                    case 153: Console.WriteLine("eX"); break;
                    case 154: Console.WriteLine("eY"); break;
                    case 155: Console.WriteLine("eZ"); break;
                  
            }

        }
    }
}
