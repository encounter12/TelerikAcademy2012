using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
 
namespace Task_1
{
    class FirstTask
    {
        static void Main(string[] args)
        {
            BigInteger givenNumber = BigInteger.Parse(Console.ReadLine());
            char[] smallLetters = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
            char[] bigLetters = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            StringBuilder newNumber = new StringBuilder();
            if (givenNumber < 26)
            {
                newNumber.Append(bigLetters[(int)givenNumber]);
            }
            else if (givenNumber > 25 && givenNumber < 256)
            {
                BigInteger small = givenNumber / 25;
                BigInteger big = givenNumber % 25;
                newNumber.Append(smallLetters[(int)small - 1]);
                newNumber.Append(bigLetters[(int)big - 1]);
            }
            else
            {
                BigInteger firstLetter = int.MaxValue;
                BigInteger remainder = 0;
                int counter = 0;
                while (firstLetter > 256)
                {
                    firstLetter = givenNumber / 255;
                    remainder = givenNumber % 255;
                    newNumber.Append(bigLetters[(int)firstLetter]);
                    counter++;
                }
                if (remainder < 26)
                {
                    newNumber.Append(bigLetters[(int)(remainder - counter)]);
                }
                else
                {
                    BigInteger small = remainder / 25;
                    BigInteger big = remainder % 25;
                    newNumber.Append(smallLetters[(int)(small - counter)]);
                    newNumber.Append(bigLetters[(int)(big - counter)]);
                }
            }
            Console.WriteLine(newNumber);
        }
    }
}