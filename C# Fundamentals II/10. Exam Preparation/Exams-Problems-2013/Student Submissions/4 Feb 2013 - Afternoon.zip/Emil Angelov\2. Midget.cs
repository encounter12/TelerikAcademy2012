using System;
using System.Collections.Generic;
using System.Linq;


class Midget
{
    static void Main(string[] args)
    {
        /*
         *  1, 3, -6, 7, 4, 1, 12
            3
            1, 2, -3
            1, 3, -2
            1, -1
         */
        var valley = Console.ReadLine().Split(new[] { ' ', ',' },
            StringSplitOptions.RemoveEmptyEntries)
            .Select(
                m => int.Parse(m)
            ).ToArray();
        // number of patterns
        int M = int.Parse(Console.ReadLine());

        List<int[]> patterns = new List<int[]>();
        for (int i = 0; i < M; i++)
        {
            patterns.Add(Console.ReadLine().Split(new[] { ' ', ',' },
            StringSplitOptions.RemoveEmptyEntries)
            .Select(
                m => int.Parse(m)
            ).ToArray());
        }

        bool[] alreadyVisited = new bool[valley.Length];
        alreadyVisited[0] = true;
        int coins = valley[0];
        int maxCoins = int.MinValue;
        foreach (var pattern in patterns)
        {
            int patternIndex = 0;
            int patternSum = 0;
            //Console.WriteLine("Valley");
            while (true)
            {
                //Console.WriteLine("patternIndex: "+patternIndex);
                patternSum += pattern[patternIndex];
                //Console.WriteLine("patternSum: " +patternSum);
                if (patternSum >= valley.Length
                    || patternSum < 0
                    || alreadyVisited[patternSum]) break;
                coins += valley[patternSum];
                alreadyVisited[patternSum] = true;
                patternIndex = ++patternIndex % pattern.Length;
            }
            //Console.WriteLine("Coins: {0}", coins);
            if (coins > maxCoins)
                maxCoins = coins;
            Array.Clear(alreadyVisited, 0, alreadyVisited.Length);
            coins = valley[0];
            alreadyVisited[0] = true;
        }
        Console.WriteLine(maxCoins);
    }
}

