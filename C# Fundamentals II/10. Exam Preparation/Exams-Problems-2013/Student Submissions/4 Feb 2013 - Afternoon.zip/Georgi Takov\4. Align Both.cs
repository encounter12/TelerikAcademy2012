using System;  
class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter an integer number: ");
            int number = int.Parse(Console.ReadLine()); 

        }
    }