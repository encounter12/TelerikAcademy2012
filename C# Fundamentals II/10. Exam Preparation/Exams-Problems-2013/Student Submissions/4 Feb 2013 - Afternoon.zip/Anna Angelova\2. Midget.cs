using System;
 
class Program
{
    public static int Coins(string[] valleyEl, string pattern)
    {       
        string[] patternEl = pattern.Split(new string[] { ", " }, StringSplitOptions.None);
        int[] visited = new int[valleyEl.Length];
        for (int i = 0; i < visited.Length; i++)
        {
            visited[i] = 0;
        }
        int sum = 0;
        int current = 0;
        int patternIndex = 0;
        while (current > -1 && current < valleyEl.Length && visited[current]!=1)
        {
            sum += int.Parse(valleyEl[current]);
            visited[current] = 1;
            current += int.Parse(patternEl[patternIndex % patternEl.Length]);
            patternIndex++;
        }
        return sum;
    }
 
    public static void Main()
    {
        string valley = Console.ReadLine();
        int pattenNum = int.Parse(Console.ReadLine());
         
        String[] patterns = new string[pattenNum];
        for (int i = 0; i < patterns.Length; i++)
        {
            patterns[i] = Console.ReadLine();
        }
        string[] valleyEl = valley.Split(new string[] { ", " }, StringSplitOptions.None);
        int maxCoins = int.MinValue;
        int tempCoins =int.MinValue;
        for (int i = 0; i < patterns.Length; i++)
        {
            tempCoins = Coins(valleyEl, patterns[i]);
            if (maxCoins < tempCoins) maxCoins = tempCoins;
        }
        Console.WriteLine(maxCoins);
    }
}