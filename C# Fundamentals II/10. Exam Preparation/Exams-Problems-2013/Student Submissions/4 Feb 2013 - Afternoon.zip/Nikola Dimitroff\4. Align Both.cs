using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class Program
{
	static char[] whitespaces = {' ', '\t', '\n'};

	static void Main(string[] args)
	{
#if DEBUG
		Console.SetIn(new StreamReader("input.txt"));
#endif

		var linesCount = int.Parse(Console.ReadLine());
		var width = int.Parse(Console.ReadLine());

		var words = new List<string>();
		for (int i = 0; i < linesCount; i++)
		{
			words.AddRange(Console.ReadLine().Split(whitespaces, StringSplitOptions.RemoveEmptyEntries));
		}

		var output = new List<string>() { string.Empty };
		int currentLineIndex = 0;
		var currentLineWords = new List<string>();
		while (words.Count > 0)
		{
			string current = output[currentLineIndex];
			bool appendSuccess = TryAppendWord(ref current, words.First(), width);
			if (appendSuccess)
			{
				currentLineWords.Add(words.First());
				words.RemoveAt(0);
				output[currentLineIndex] = current;
			}
			else
			{
				current = JustifyLine(current, currentLineWords, width);
				output[currentLineIndex] = current;
				currentLineIndex++;
				currentLineWords.Clear();
				output.Add(string.Empty);
			}
		}
		foreach (var line in output)
		{
			Console.WriteLine(line.Trim());
		}
	}

	static string JustifyLine(string current, List<String> words, int width)
	{
		current = current.TrimEnd();
		if (words.Count == 1)
			return current;

		int currentWord = 0;
		while (current.Length != width)
		{
			int index = (current.IndexOf(words[currentWord]) + words[currentWord].Length);
			current = current.Insert(index, " ");
			currentWord = (currentWord + 1) % (words.Count - 1);
		}
		return current;
	}

	static string JustifyLine2(string current, List<String> words, int width)
	{
		current = current.TrimEnd();
		if (words.Count == 1)
			return current;

			
		int difference = width - current.Length;
		int index = 0;
		if (words.Count == 2)
		{
			index = (current.IndexOf(words[0]) + words[0].Length);
			current = current.Insert(index, new string(' ', difference));
			return current;
		}

		var half = difference / 2;
		index = (current.IndexOf(words[0]) + words[0].Length);
		current = current.Insert(index, new string(' ', difference % 2 == 0 ? half : half + 1));


		index = (current.IndexOf(words[1]) + words[1].Length);
		current = current.Insert(index, new string(' ', half));
		return current;
	}

	static bool TryAppendWord(ref string line, string word, int maxWidth)
	{
		if (line.Length + word.Length > maxWidth)
			return false;
				
		line += (word) + " ";

		return true;
	}

	static string ReadNextWord(string sentence)
	{
		
		return sentence.Substring(0, sentence.IndexOfAny(whitespaces));
	}
}
