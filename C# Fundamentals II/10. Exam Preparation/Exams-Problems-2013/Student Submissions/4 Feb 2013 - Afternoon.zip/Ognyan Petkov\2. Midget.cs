using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace midget
{
    class midget
    {
        static void Main(string[] args)
        {
            char[] separators = new char[] { ' ', ',' };
            string valey = Console.ReadLine();
            string[] valeyString = valey.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            int[] arr = new int[valeyString.Length];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = int.Parse(valeyString[i]);
            }

            //int[] arr = new int[] { 1, 3, -6, 7, 4, 1, 12 };


            int m = int.Parse(Console.ReadLine());
            int bestResult = int.MinValue;
            //int[] path = new int[] { 1, 3, -2 };

            for (int j = 0; j < m; j++)
            {
                bool[] visited = new bool[arr.Length];
                string str = Console.ReadLine();
                string[] pathString = str.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                int[] path = new int[pathString.Length];
                for (int k = 0; k < path.Length; k++)
                {
                    path[k] = int.Parse(pathString[k]);
                }
                bool exit = true;
                int result = arr[0];
                int position = 0;
                visited[position] = true;

                while (exit)
                {
                    for (int i = 0; i < path.Length; i++)
                    {
                        position += path[i];
                        if ((position < 0) || (position > arr.Length - 1) || (visited[position] == true))
                        {
                            exit = false;
                            break;
                        }
                        else
                        {
                            visited[position] = true;
                            result += arr[position];
                            //Console.WriteLine(result);
                        }
                    }
                }
                if (result > bestResult)
                {
                    bestResult = result;
                }
            }
            Console.WriteLine(bestResult);
        }
    }
}
