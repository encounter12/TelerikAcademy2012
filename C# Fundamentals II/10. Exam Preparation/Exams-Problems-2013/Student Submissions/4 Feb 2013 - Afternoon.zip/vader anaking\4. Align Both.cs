using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<decimal> numbers = new List<decimal>();
            decimal n=decimal.Parse(Console.ReadLine());
            decimal counter=0;
            while (n > 0)
            {
                if (counter == 0)
                {
                    numbers.Add(n % 26);
                    counter++;
                    n -= n%26;
                }
                else
                {
                    if (n / 25 > 0)
                    {
                        numbers.Add(n % 26);
                        numbers[(int)counter] += 1;
                        counter++;
                        n -= 25;
                    }
                    else
                    {
                        numbers.Add(2 % 26);
                        counter++;
                        n -= n % 26;
                    }
                }
                foreach (var item in numbers)
                {
                    Console.WriteLine(item);
                }
            }
        }
    }
}
