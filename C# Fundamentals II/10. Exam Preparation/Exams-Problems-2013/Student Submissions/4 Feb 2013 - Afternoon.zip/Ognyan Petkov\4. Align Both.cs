using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlignBoth
{
    class AlignBoth
    {
        static void Main(string[] args)
        {
            int numberLines = int.Parse(Console.ReadLine());
            int maxLength = int.Parse(Console.ReadLine());
            List<string> words = new List<string>();
            for (int i = 0; i < numberLines; i++)
            {
                string line = Console.ReadLine();
                string[] wordsArray = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                for (int j = 0; j < wordsArray.Length; j++)
                {
                    words.Add(wordsArray[j]);
                }
            }
            int[] lenght = new int[words.Count];

            for (int j = 0; j < words.Count; j++)
            {
                lenght[j] = words[j].Length;
            }


            List<string> wordInLine = new List<string>();
            StringBuilder result = new StringBuilder();

            int currCount = 1;
            int counter = 0;
            int currentLength = lenght[counter];

            while (counter < words.Count)
            {
                if ((counter+1==words.Count))
                {
                    if (currCount == 1)
                    {
                        result.Append(words[counter]);
                        counter++;
                        currCount = 1;
                        Console.WriteLine(result.ToString());
                        result.Clear();
                        return;
                    }
                    else // poveche ot edin element na red
                    {
                        int freespace = maxLength;
                        int realspace = maxLength;
                        for (int i = 0; i < currCount; i++)
                        {
                            freespace -= (lenght[counter - currCount + 1 + i] + 1);
                            realspace -= (lenght[counter - currCount + 1 + i]);
                        }
                        int real = realspace;
                        //real++;
                        freespace++;// zaradi poslednata duma
                        int br = 0;
                        int reminder = freespace % maxLength;
                        int rem = reminder;
                        int space = freespace / maxLength;
                        int curr = currCount;
                        if (currCount == 2)
                        {
                            result.Append(words[counter-1]);
                            for (int i = 0; i < (maxLength - lenght[counter-1] - lenght[counter]); i++)
                            {
                                result.Append(" ");
                            }
                            result.Append(words[counter]);
                            Console.WriteLine(result.ToString());
                            result.Clear();
                                                        return;

                        }
                        else
                        {
                            while (reminder > 0)
                            {

                                result.Append(words[counter - currCount + 1]);
                                for (int i = 0; i < (realspace / (curr - 1)) + 1; i++)
                                {
                                    result.Append(" ");
                                    real--;

                                }
                                br++;
                                reminder--;
                                currCount++;
                            }
                            for (int i = 0; i < curr - rem; i++)
                            {
                                result.Append(words[counter - curr + i + 1 + br]);
                                if (real > 0)
                                {
                                    for (int j = 0; j < (realspace / (curr - 1)); j++)
                                    {
                                        result.Append(" ");
                                        real--;
                                    }
                                }
                                currCount++;
                            }
                            counter++;
                            currCount = 1;
                            Console.WriteLine(result.ToString());
                            currentLength = lenght[counter];
                            result.Clear();
                        }

                    }
                }
                else if ((currentLength == maxLength)&&(currCount==1))
                {
                    result.Append(words[counter]);
                    counter++;
                    currCount = 1;
                    currentLength = lenght[counter];
                    Console.WriteLine(result.ToString());
                    result.Clear();
                }
                else if ((currentLength + 1 + lenght[counter + 1]) > maxLength)
                {
                    // elementite za slagane = currCount -> counter +=currcount
                    // elemenitite sa ot counter + 0 do currCount
                    // svobodnoto miasto  = maxLength - legtn(counter+[currcount 0, 1, 2...])
                    if (currCount == 1)
                    {
                        result.Append(words[counter]);
                        counter++;
                        currCount = 1;
                    }
                    else // poveche ot edin element na red
                    {
                        int freespace = maxLength;
                        int realspace = maxLength;
                        for (int i = 0; i < currCount; i++)
                        {
                            freespace -= (lenght[counter - currCount+1+i] + 1);
                            realspace -= (lenght[counter - currCount + 1+i]  );
                        }
                        int real = realspace;
                        //real++;
                        freespace++;// zaradi poslednata duma
                        int br = 0;
                        int reminder = freespace % maxLength;
                        int rem = reminder;
                        int space = freespace / maxLength;
                        int curr = currCount;
                        if (currCount == 2)
                        {
                            result.Append(words[counter]);
                            for (int i = 0; i < (maxLength-lenght[counter]-lenght[counter+1]); i++)
                            {
                                result.Append(" ");
                            }
                            result.Append(words[counter + 1]);
                            currCount = 1;
                            counter += 2;
                            currentLength = lenght[counter];
                            Console.WriteLine(result.ToString());
                            result.Clear();
                        }
                        else
                        {
                            while (reminder > 0)
                            {
                                
                                result.Append(words[counter - currCount+1]);
                                for (int i = 0; i < (realspace / (curr-1)) + 1; i++)
                                {
                                    result.Append(" ");
                                    real--;
                                    
                                }
                                br++;
                                reminder--;
                                currCount++;
                            }
                            for (int i = 0; i < curr-rem; i++)
                            {
                                result.Append(words[counter - curr + i +1 +br]);
                                if (real > 0)
                                {
                                    for (int j = 0; j < (realspace / (curr - 1)); j++)
                                    {
                                        result.Append(" ");
                                        real--;
                                    }
                                }
                                currCount++;
                            }
                            counter ++;
                            currCount = 1;
                            Console.WriteLine(result.ToString());
                            currentLength = lenght[counter];
                            result.Clear();
                        }

                    }
                }
                else
                {
                    currentLength += 1 + lenght[counter + 1];
                    currCount++;
                    counter++;
                }
                 
            }

            //while (true)
            //{
            //    counter++;
            //    dist += lenght[counter] +1;
            //    if (dist > maxLength)
            //    {
            //        int numberElements = counter-
            //        break;
            //    }
            //    else
            //    {
            //        currCount++;  
            //    }
            //}




        }
    }
}
