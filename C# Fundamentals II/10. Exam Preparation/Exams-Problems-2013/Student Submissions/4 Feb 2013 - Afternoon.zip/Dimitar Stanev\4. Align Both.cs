using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task4
{
    class Program
    {

        static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());
            if (lines > 0 && lines < 1000)
            {
                int width = int.Parse(Console.ReadLine());
                if (width > 0 && width < 10000)
                {
                    char[] separator = new char[] { ' ' };
                    List<string> wholeTextArray = new List<string>();
                    for ( int i = 0; i < lines; i++)
                    {
                        string bufferLine = Console.ReadLine();
                        string[] singleLineWords = bufferLine.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                        for (int j = 0; j < singleLineWords.Length; j++)
                        {
                            wholeTextArray.Add(singleLineWords[j]);
                        }
                    }
                    List<string> justifiedText = new List<string>();
                    do
                    {
                        int i = 0;
                        int sum = 0;
                            if (wholeTextArray.Count > 1 && wholeTextArray[0].Length + wholeTextArray[1].Length + 1 > width)
                            {
                                justifiedText[i] = string.Concat( justifiedText[i], (wholeTextArray[0]));
                                justifiedText[i] = string.Concat( justifiedText[i], "\n");
                                wholeTextArray.RemoveAt(0);
                            }
                            else if (wholeTextArray.Count == 1)
                            {
                                justifiedText[i] = String.Concat(justifiedText[i], (wholeTextArray[0]));
                                break;
                            }
                            else
                            {
                                for (int j = 1; j < wholeTextArray.Count; j++)
                                {
                                    sum += wholeTextArray[j - 1].Length + wholeTextArray[j].Length + 1;
                                    if (sum > width)
                                    {
                                        justifiedText[i] = string.Concat( justifiedText[i] , "\n");
                                        break;
                                    }
                                    else if (sum <= width)
                                    {
                                        do
                                        {
                                            justifiedText[i] = string.Concat (justifiedText[i], (wholeTextArray[j - 1]);
                                            do
                                            {
                                                justifiedText[i] = string.Concat ( justifiedText[i], " ");
                                            } while (justifiedText[i].Length < width);
                                            wholeTextArray.RemoveAt(j - 1);
                                        } while (justifiedText[i].Length <= width);
                                    }
                                }
                            }
                        i++;
                    } while (wholeTextArray.Count > 0);
                         for (int i = 0; i < justifiedText.Count; i++)
                        {
                            Console.Write(justifiedText[i]);
                        }
                }
            }
        }
    }
}
