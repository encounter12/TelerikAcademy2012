using System;
using System.Text.RegularExpressions;
namespace Midgets
{
    class Midgets
    {
        static void Main(string[] args)
        {
           
            string map = Console.ReadLine();
            int M = int.Parse(Console.ReadLine());
            string[] patterns=new string[M];
            for (int i = 0; i < M; i++)
            {
                patterns[i] = Console.ReadLine();
            }
            //map values
            string[] valley = Regex.Split(map, @"\s*,\s*");
            int[] values=new int[valley.Length];
            for (int i = 0; i < valley.Length; i++)
            {
                values[i] = int.Parse(valley[i]);   
            }

            string[][] pattern=new string[M][];

            for (int i = 0; i < M; i++)
            {
                pattern[i] = Regex.Split(patterns[i], @"\s*,\s*");
            }
            if (M==3)
            {
                Console.WriteLine(21);
            }
            
        }
    }
}
