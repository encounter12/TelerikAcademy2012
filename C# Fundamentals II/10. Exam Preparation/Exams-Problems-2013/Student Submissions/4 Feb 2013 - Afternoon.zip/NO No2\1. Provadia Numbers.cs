using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Provadia_Numbers
{
    class Provadia_Numbers
    {   
        Encoding Provadia = Encoding.UTF8;
        static void Main(string[] args)
        {   
            ulong n = ulong.Parse(Console.ReadLine());
            if(n==1)
                Console.WriteLine("A");
            if (n == 1)
                Console.WriteLine("B");
            if (n == 2)
                Console.WriteLine("C");
            if (n == 3)
                Console.WriteLine("D");
            if (n == 4)
                Console.WriteLine("E");
            if (n == 5)
                Console.WriteLine("F");
            if (n == 6)
                Console.WriteLine("G");
            if (n == 7)
                Console.WriteLine("H");
            if (n == 8)
                Console.WriteLine("I");
            if (n == 9)
                Console.WriteLine("J");
            if (n == 10)
                Console.WriteLine("K");
            if (n == 11)
                Console.WriteLine("L");
            if (n == 12)
                Console.WriteLine("M");
            if (n == 13)
                Console.WriteLine("N");
            if (n == 14)
                Console.WriteLine("O");
            if (n == 15)
                Console.WriteLine("P");
            if (n == 16)
                Console.WriteLine("Q");
            if (n == 17)
                Console.WriteLine("R");
            if (n == 18)
                Console.WriteLine("S");
            if (n == 19)
                Console.WriteLine("T");
            if (n == 20)
                Console.WriteLine("U");
            if (n == 21)
                Console.WriteLine("V");
            if (n == 22)
                Console.WriteLine("W");
            if (n == 23)
                Console.WriteLine("X");
            if (n == 24)
                Console.WriteLine("Y");
            if (n == 25)
                Console.WriteLine("Z");
            if (n > 25 && n<=52)
            {
                n = n - 25;
                if (n == 1)
                    Console.WriteLine("aA");
                if (n == 1)
                    Console.WriteLine("aB");
                if (n == 2)
                    Console.WriteLine("aC");
                if (n == 3)
                    Console.WriteLine("aD");
                if (n == 4)
                    Console.WriteLine("aF");
                if (n == 5)
                    Console.WriteLine("aE");
                if (n == 6)
                    Console.WriteLine("aG");
                if (n == 7)
                    Console.WriteLine("aH");
                if (n == 8)
                    Console.WriteLine("aI");
                if (n == 9)
                    Console.WriteLine("aJ");
                if (n == 10)
                    Console.WriteLine("aK");
                if (n == 11)
                    Console.WriteLine("aL");
                if (n == 12)
                    Console.WriteLine("aM");
                if (n == 13)
                    Console.WriteLine("aN");
                if (n == 14)
                    Console.WriteLine("aO");
                if (n == 15)
                    Console.WriteLine("aP");
                if (n == 16)
                    Console.WriteLine("aQ");
                if (n == 17)
                    Console.WriteLine("aR");
                if (n == 18)
                    Console.WriteLine("aS");
                if (n == 19)
                    Console.WriteLine("aT");
                if (n == 20)
                    Console.WriteLine("aU");
                if (n == 21)
                    Console.WriteLine("aV");
                if (n == 22)
                    Console.WriteLine("aW");
                if (n == 23)
                    Console.WriteLine("aX");
                if (n == 24)
                    Console.WriteLine("aY");
                if (n == 25)
                    Console.WriteLine("aZ");
            }
            if (n > 52 && n <= 77)
            {
                n = n - 52;
                if (n == 1)
                    Console.WriteLine("bA");
                if (n == 1)
                    Console.WriteLine("bB");
                if (n == 2)
                    Console.WriteLine("bC");
                if (n == 3)
                    Console.WriteLine("bD");
                if (n == 4)
                    Console.WriteLine("bE");
                if (n == 5)
                    Console.WriteLine("bF");
                if (n == 6)
                    Console.WriteLine("bG");
                if (n == 7)
                    Console.WriteLine("bH");
                if (n == 8)
                    Console.WriteLine("bI");
                if (n == 9)
                    Console.WriteLine("bJ");
                if (n == 10)
                    Console.WriteLine("bK");
                if (n == 11)
                    Console.WriteLine("bL");
                if (n == 12)
                    Console.WriteLine("bM");
                if (n == 13)
                    Console.WriteLine("bN");
                if (n == 14)
                    Console.WriteLine("bO");
                if (n == 15)
                    Console.WriteLine("bP");
                if (n == 16)
                    Console.WriteLine("bQ");
                if (n == 17)
                    Console.WriteLine("bR");
                if (n == 18)
                    Console.WriteLine("bS");
                if (n == 19)
                    Console.WriteLine("bT");
                if (n == 20)
                    Console.WriteLine("bU");
                if (n == 21)
                    Console.WriteLine("bV");
                if (n == 22)
                    Console.WriteLine("bW");
                if (n == 23)
                    Console.WriteLine("bX");
                if (n == 24)
                    Console.WriteLine("bY");
                if (n == 25)
                    Console.WriteLine("bZ");
            }
            if (n > 77 && n <= 102)
            {
                n = n - 77;
                if (n == 1)
                    Console.WriteLine("cA");
                if (n == 1)
                    Console.WriteLine("cB");
                if (n == 2)
                    Console.WriteLine("cC");
                if (n == 3)
                    Console.WriteLine("cD");
                if (n == 4)
                    Console.WriteLine("cE");
                if (n == 5)
                    Console.WriteLine("cF");
                if (n == 6)
                    Console.WriteLine("cG");
                if (n == 7)
                    Console.WriteLine("cH");
                if (n == 8)
                    Console.WriteLine("cI");
                if (n == 9)
                    Console.WriteLine("cJ");
                if (n == 10)
                    Console.WriteLine("cK");
                if (n == 11)
                    Console.WriteLine("cL");
                if (n == 12)
                    Console.WriteLine("cM");
                if (n == 13)
                    Console.WriteLine("cN");
                if (n == 14)
                    Console.WriteLine("cO");
                if (n == 15)
                    Console.WriteLine("cP");
                if (n == 16)
                    Console.WriteLine("cQ");
                if (n == 17)
                    Console.WriteLine("cR");
                if (n == 18)
                    Console.WriteLine("cS");
                if (n == 19)
                    Console.WriteLine("cT");
                if (n == 20)
                    Console.WriteLine("cU");
                if (n == 21)
                    Console.WriteLine("cV");
                if (n == 22)
                    Console.WriteLine("cW");
                if (n == 23)
                    Console.WriteLine("cX");
                if (n == 24)
                    Console.WriteLine("cY");
                if (n == 25)
                    Console.WriteLine("cZ");
            }
            if (n > 102 && n <= 127)
            {
                n = n - 102;
                if (n == 1)
                    Console.WriteLine("dA");
                if (n == 1)
                    Console.WriteLine("dB");
                if (n == 2)
                    Console.WriteLine("dC");
                if (n == 3)
                    Console.WriteLine("dD");
                if (n == 4)
                    Console.WriteLine("dE");
                if (n == 5)
                    Console.WriteLine("dF");
                if (n == 6)
                    Console.WriteLine("G");
                if (n == 7)
                    Console.WriteLine("dH");
                if (n == 8)
                    Console.WriteLine("dI");
                if (n == 9)
                    Console.WriteLine("dJ");
                if (n == 10)
                    Console.WriteLine("dK");
                if (n == 11)
                    Console.WriteLine("dL");
                if (n == 12)
                    Console.WriteLine("dM");
                if (n == 13)
                    Console.WriteLine("dN");
                if (n == 14)
                    Console.WriteLine("dO");
                if (n == 15)
                    Console.WriteLine("dP");
                if (n == 16)
                    Console.WriteLine("dQ");
                if (n == 17)
                    Console.WriteLine("dR");
                if (n == 18)
                    Console.WriteLine("dS");
                if (n == 19)
                    Console.WriteLine("dT");
                if (n == 20)
                    Console.WriteLine("dU");
                if (n == 21)
                    Console.WriteLine("dV");
                if (n == 22)
                    Console.WriteLine("dW");
                if (n == 23)
                    Console.WriteLine("dX");
                if (n == 24)
                    Console.WriteLine("dY");
                if (n == 25)
                    Console.WriteLine("dZ");
            }
            if (n > 127 && n <= 152)
            {
                n = n - 127;
                if (n == 1)
                    Console.WriteLine("eA");
                if (n == 1)
                    Console.WriteLine("eB");
                if (n == 2)
                    Console.WriteLine("eC");
                if (n == 3)
                    Console.WriteLine("eD");
                if (n == 4)
                    Console.WriteLine("eE");
                if (n == 5)
                    Console.WriteLine("eF");
                if (n == 6)
                    Console.WriteLine("eG");
                if (n == 7)
                    Console.WriteLine("eH");
                if (n == 8)
                    Console.WriteLine("eI");
                if (n == 9)
                    Console.WriteLine("eJ");
                if (n == 10)
                    Console.WriteLine("eK");
                if (n == 11)
                    Console.WriteLine("eL");
                if (n == 12)
                    Console.WriteLine("eM");
                if (n == 13)
                    Console.WriteLine("eN");
                if (n == 14)
                    Console.WriteLine("eO");
                if (n == 15)
                    Console.WriteLine("eP");
                if (n == 16)
                    Console.WriteLine("eQ");
                if (n == 17)
                    Console.WriteLine("eR");
                if (n == 18)
                    Console.WriteLine("eS");
                if (n == 19)
                    Console.WriteLine("eT");
                if (n == 20)
                    Console.WriteLine("eU");
                if (n == 21)
                    Console.WriteLine("eV");
                if (n == 22)
                    Console.WriteLine("eW");
                if (n == 23)
                    Console.WriteLine("eX");
                if (n == 24)
                    Console.WriteLine("eY");
                if (n == 25)
                    Console.WriteLine("eZ");
            }
            if (n > 152 && n <= 177)
            {
                n = n - 152;
                if (n == 1)
                    Console.WriteLine("fA");
                if (n == 1)
                    Console.WriteLine("fB");
                if (n == 2)
                    Console.WriteLine("fC");
                if (n == 3)
                    Console.WriteLine("fD");
                if (n == 4)
                    Console.WriteLine("fE");
                if (n == 5)
                    Console.WriteLine("fF");
                if (n == 6)
                    Console.WriteLine("fG");
                if (n == 7)
                    Console.WriteLine("fH");
                if (n == 8)
                    Console.WriteLine("fI");
                if (n == 9)
                    Console.WriteLine("fJ");
                if (n == 10)
                    Console.WriteLine("fK");
                if (n == 11)
                    Console.WriteLine("fL");
                if (n == 12)
                    Console.WriteLine("fM");
                if (n == 13)
                    Console.WriteLine("fN");
                if (n == 14)
                    Console.WriteLine("fO");
                if (n == 15)
                    Console.WriteLine("fP");
                if (n == 16)
                    Console.WriteLine("fQ");
                if (n == 17)
                    Console.WriteLine("fR");
                if (n == 18)
                    Console.WriteLine("fS");
                if (n == 19)
                    Console.WriteLine("fT");
                if (n == 20)
                    Console.WriteLine("fU");
                if (n == 21)
                    Console.WriteLine("fV");
                if (n == 22)
                    Console.WriteLine("fW");
                if (n == 23)
                    Console.WriteLine("fX");
                if (n == 24)
                    Console.WriteLine("fY");
                if (n == 25)
                    Console.WriteLine("fZ");
            }
        }
    }
}
