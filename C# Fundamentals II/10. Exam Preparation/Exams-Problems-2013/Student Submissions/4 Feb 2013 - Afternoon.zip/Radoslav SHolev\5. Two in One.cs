using System;
using System.Diagnostics;

class Program
{
    static void Main()
    {
        //Stopwatch s = new Stopwatch();
        int N = int.Parse(Console.ReadLine());
        string firstLineOfCommands = Console.ReadLine();
        string secondLineOfCommands = Console.ReadLine();
        //s.Start();
        int lastLamp = CalculateLamps(N);
        Console.WriteLine(lastLamp);
        ExecuteCommands(firstLineOfCommands);
        ExecuteCommands(secondLineOfCommands);
        //s.Stop();
        //Console.WriteLine(s.ElapsedMilliseconds);
    }

    private static void ExecuteCommands(string lineOfComm)
    {
        int stepsForward = 0;
        int turnsLeft = 0;
        int turnsRight = 0;
        for (int i = 0; i < lineOfComm.Length; i++)
        {
            switch (lineOfComm[i])
            {
                case 'S':
                    stepsForward++;
                    break;
                case 'L':
                    turnsLeft++;
                    break;
                case 'R':
                    turnsRight++;
                    break;
            }
        }
        if (turnsRight != turnsLeft)
        {
            Console.WriteLine("bounded");
        }
        else
        {
            Console.WriteLine("unbounded");
        }
    }

    private static int CalculateLamps(int N)
    {
        int lastLamp = 0;
        bool[] lamps = new bool[N];
        int indexOfFirstTOL=0;
        int j = 2;
        while((indexOfFirstTOL=FirstTurnedOffLamp(indexOfFirstTOL,lamps))!=-1)
        {
            for (int i = indexOfFirstTOL; i < N;)
            {
                if (i == indexOfFirstTOL)
                {
                    lamps[i] = true;
                    lastLamp = i;
                    i++;
                }
                else
                {
                    int index = FindTheIthTOffL(i, j, lamps);
                    if (index == -1)
                    {
                        break;
                    }
                    else
                    {
                        lamps[index] = true;
                        lastLamp = index;
                        i = index;
                    }
                }
            }
            j++;
        }
        return lastLamp + 1;
    }

    private static int FindTheIthTOffL(int i, int theIthlamp, bool[] lamps)
    {
        int counter = 0;
        int index = -1;
        for (int j = i; j < lamps.Length; j++)
        {
            if (lamps[j] == false)
            {
                counter++;
            }
            if (counter == theIthlamp)
            {
                index = j;
                break;
            }
        }
        return index;
    }
    static int FirstTurnedOffLamp(int index,bool[] lamps)
    {
        for (int i = index; i < lamps.Length; i++)
        {
            if (lamps[i] == false)
            {
                return i;
            }
        }
        return -1;
    }
}
