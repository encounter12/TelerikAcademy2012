using System;

class midget
{
    static void Main()
    {
        string inputValley = Console.ReadLine();

        int[] valleyNumbers = GetNumbers(inputValley);

        //validate
        if (valleyNumbers.Length < 1 || valleyNumbers.Length > 10000) return;

        int m = int.Parse(Console.ReadLine());

        //validate M
        if (m <= 1 || m >= 500) return;

        int currSum = valleyNumbers[0], theSum = valleyNumbers[0];

        for (int i = 0; i < m; i++)
        {
            currSum = valleyNumbers[0];

            int[] valleyCopy = new int[valleyNumbers.Length];

            Array.Copy(valleyNumbers, valleyCopy, valleyNumbers.Length);

            string inputNumbers = Console.ReadLine();

            int[] currPattern = GetNumbers(inputNumbers);

            if (currPattern.Length > 100 || currPattern.Length == 0) return;

            int currPos = 0;

            valleyCopy[currPos] = 1111;

            bool escaped = false;

            while (!escaped)
            {
                for (int k = 0; k < currPattern.Length; k++)
                {
                    currPos += currPattern[k];

                    if (currPos < valleyCopy.Length && currPos >= 0)
                    {
                        if (valleyCopy[currPos] == 1111)
                        {
                            escaped = true;
                            break;
                        }
                    }
                    else
                    {
                        escaped = true;
                        break;
                    }

                    currSum += valleyCopy[currPos];

                    valleyCopy[currPos] = 1111;
                }
            }

            if (currSum > theSum)
            {
                theSum = currSum;
            }
        }

        Console.WriteLine(theSum);
    }

    static int[] GetNumbers(string numbers)
    {
        string[] valleyNumbers = numbers.Split(',');

        int[] actualValleyNumbers = new int[valleyNumbers.Length];

        int currNumber = 0;

        for (int i = 0; i < valleyNumbers.Length; i++)
        {
            if (currNumber < -1000 || currNumber > 1000)
            {
                return new int[]{};
            }

            actualValleyNumbers[i] = int.Parse(valleyNumbers[i]);
        }

        return actualValleyNumbers;
    }
}
