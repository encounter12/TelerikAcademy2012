using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
  
class Program
{
    static void Main(string[] args)
    {
#if DEBUG
        //Console.SetIn(new StreamReader("input.txt"));
#endif
  
        var lampsCount = int.Parse(Console.ReadLine());
        var robotTest1 = Console.ReadLine();
        var robotTest2 = Console.ReadLine();
  
        LampTurner(lampsCount);
        RobotWalker(robotTest1);
        RobotWalker(robotTest2);
  
    }
  
    private static void RobotWalker(string robotTest)
    {
        Robot robot = new Robot();
        var commands = new List<ICommand>();
        for (int i = 0; i < robotTest.Length; i++)
        {
            switch (robotTest[i])
            {
                case 'S':
                    int steps = robotTest.Skip(i).TakeWhile(x => x == 'S').Count();
                    commands.Add(new WalkCommand(steps));
                    i += steps - 1;
                    break;
                default:
                    int rotation = 0;
                    while (i < robotTest.Length && robotTest[i] != 'S')
                    {
                        if (robotTest[i] == 'R')
                            rotation += 90;
                        else
                            rotation -= 90;
                        i++;
                    }
                    commands.Add(new RotateCommand(rotation));
                    break;
            };
        }
  
        var testingRadius = 500;
        var positions = new HashSet<Robot>();
        positions.Add(new Robot(robot.X, robot.Y, robot.Rotation));
        for (int i = 0; i < testingRadius; i++)
        {
            ExecuteCommands(robot, commands);
              
            if (positions.Contains(robot, robot))
            {
                Console.WriteLine("bounded");
                return;
            }
            else
            {
                positions.Add(new Robot(robot.X, robot.Y, robot.Rotation));
            }
        }
  
        if (robot.SquaredDistance < (testingRadius * testingRadius) / 2)
            Console.WriteLine("bounded");
        else
            Console.WriteLine("unbounded");
    }
  
    private static void ExecuteCommands(Robot robot, List<ICommand> commands)
    {
        foreach (var command in commands)
        {
            command.Execute(robot);
        }
    }
  
    private static void LampTurner(int lampsCount)
    {
        var lamps = new bool[lampsCount + 1];
        int lampsOff = lampsCount;
        for (int i = 1; i < lampsCount + 1; i++)
        {
            if (lampsOff == 1)
            {
                Console.WriteLine(Array.IndexOf(lamps, false, 1));
                return;
            }
  
            int nextLampOff = Array.IndexOf(lamps, false, 1);
            while (nextLampOff > 0 && nextLampOff < lampsCount + 1)
            {
                lamps[nextLampOff] = true;
                lampsOff--;
                for (int k = 0; k < i + 1 && nextLampOff > 0 && nextLampOff < lampsCount + 1; k++)
                {
                    nextLampOff = Array.IndexOf(lamps, false, nextLampOff + 1);
                }
            }
        }
    }
  
    private static void LampTurner2(int lampsCount)
    {
        var lamps = new bool[lampsCount];
        int lampsOff = lampsCount;
        //int squareRoot = (int) Math.Ceiling(Math.Sqrt(lampsCount));
        for (int i = 2; i < lampsCount; i++)
        { 
            int max = lampsCount / i;
            for (int j = 0; j < max; j++)
            {
                lamps[j * i] = true;
                lampsOff--;
            }
            if (lampsOff == 1)
            {
                Console.WriteLine(Array.IndexOf(lamps, false, 1));
                return;
            }
        }
    }
  
}
  
class Robot : IEqualityComparer<Robot>
{
    public int X;
    public int Y;
  
    public int Rotation;
  
    public Robot(int x = 0, int y = 0, int rotation = 0)
    {
        // TODO: Complete member initialization
        this.X = x;
        this.Y = y;
        this.Rotation = rotation;
    }
  
    public int SquaredDistance
    {
        get
        {
            return X * X + Y * Y;
        }
    }
  
    public override string ToString()
    {
        return string.Format("X: {0}, Y: {1}", X, Y);
    }
  
    public bool Equals(Robot obj1, Robot obj2)
    {
        return
             obj1.X == obj2.X &&
             obj1.Y == obj2.Y &&
             obj1.Rotation == obj2.Rotation;
    }
  
    public int GetHashCode(Robot robot)
    {
        return robot.X.GetHashCode() + robot.Y.GetHashCode() + robot.Rotation.GetHashCode();
    }
}
  
interface ICommand
{
    void Execute(Robot robot);
}
  
class WalkCommand : ICommand
{
    private int steps;
  
    public WalkCommand(int steps)
    {
        this.steps = steps;
    }
    public void Execute(Robot robot)
    {
        switch (robot.Rotation)
        {
            case 0 :
                robot.Y += steps;
                break;
            case 90 :
                robot.X += steps;
                break;
            case 180 :
                robot.Y -= steps;
                break;
            default : //270
                robot.X -= steps;
                break;
        };
    }
}
  
class RotateCommand : ICommand
{
    int rotation;
  
    public RotateCommand(int dir)
    {
        rotation = dir;
    }
  
    public void Execute(Robot robot)
    {
        robot.Rotation += rotation;
        if (robot.Rotation == 360)
            robot.Rotation = 0;
    }
}
