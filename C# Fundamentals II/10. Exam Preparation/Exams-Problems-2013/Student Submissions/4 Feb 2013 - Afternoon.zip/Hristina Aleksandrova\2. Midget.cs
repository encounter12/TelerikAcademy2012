using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace align
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine();
            string[] valleye = str.Split(',', ' ');
            int numberOfPatterns = int.Parse(Console.ReadLine());
            for (int i = 0; i < numberOfPatterns; i++)
            {

                string pattern = Console.ReadLine();
                string[] num = pattern.Split(',', ' ');
            }
            Console.WriteLine();

        }
    }
}