using System;
using System.Collections.Generic;

    class MidGet
    {
        static bool isMarked(string element, List<int> visited) 
        {
            bool mark = false;
      
			    if (visited.Contains(Convert.ToInt32(element)))
                {
                    mark = true;
                    
                }
			
             
                
           return mark;
        }


        static int makeSum(string[] valley,string[] element) 
        {
            int sum = 0;
            int nextElement;
            int lastelement;
            List<int> visited = new List<int>();
                for (int j = 0, p=0; j < valley.Length &&   p < element.Length; j++)
                {
                    if (p < 1)
                    {
                        nextElement = Convert.ToInt32(valley[j]);
                    }
                    else nextElement = 0;
                     if (!isMarked(valley[j], visited))
                    {
                        visited.Add(Convert.ToInt32(valley[j]));
                    j = j + Convert.ToInt32(element[p]);
                    sum = sum + nextElement + Convert.ToInt32(valley[j]);
                    }
                     if (j  == 1)
                     {
                         j = 0;
                     }
                     else j = j - 1;
                    p++;
                     lastelement = Convert.ToInt32(valley[j]);
                }

                return sum - lastelement;
         }
        static void Main()
        {
            string line = Console.ReadLine();
            string[] valley = line.Split(',');
            int n = int.Parse(Console.ReadLine());
            string pattern = string.Empty;
            int maxsum = 0;
            int sum = 0;

            for (int i = 0; i < n; i++)
            {
                pattern = Console.ReadLine();
                string[] element = pattern.Split(',');
                sum = makeSum(valley, element);

                if (sum > maxsum)
                { maxsum = sum; }
             }

                Console.WriteLine(maxsum); 
            
        }
    }

