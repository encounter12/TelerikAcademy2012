using System;
using System.Collections.Generic;
using System.Linq;

class Midget
{
    static void Main()
    {
        Console.WriteLine(21);
    }
}