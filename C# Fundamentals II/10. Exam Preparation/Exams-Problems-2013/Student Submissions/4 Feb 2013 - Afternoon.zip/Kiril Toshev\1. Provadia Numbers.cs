using System;
using System.Numerics;
using System.Collections.Generic;

class ProvadiaNumbers
{
    static void Main()
    {
        string[] provadiaNumbers = new string[256];
        for (int index = 0; index < 256; index++)
        {
            string number = "";
            if (index < 26)
            {
                number = ((char)('A' + index)).ToString();
                provadiaNumbers[index] = number;
            }
            if (index > 25 && index < 52)
            {
                number = "a" + provadiaNumbers[index - 26];
                provadiaNumbers[index] = number;
            }
            if (index > 51 && index < 78)
            {
                number = "b" + provadiaNumbers[index - 52];
                provadiaNumbers[index] = number;
            }
            if (index > 77 && index < 104)
            {
                number = "c" + provadiaNumbers[index - 78];
                provadiaNumbers[index] = number;
            }
            if (index > 103 && index < 130)
            {
                number = "d" + provadiaNumbers[index - 104];
                provadiaNumbers[index] = number;
            }
            if (index > 129 && index < 156)
            {
                number = "e" + provadiaNumbers[index - 130];
                provadiaNumbers[index] = number;
            }
            if (index > 155 && index < 182)
            {
                number = "f" + provadiaNumbers[index - 156];
                provadiaNumbers[index] = number;
            }
            if (index > 181 && index < 208)
            {
                number = "g" + provadiaNumbers[index - 182];
                provadiaNumbers[index] = number;
            }
            if (index > 207 && index < 234)
            {
                number = "h" + provadiaNumbers[index - 208];
                provadiaNumbers[index] = number;
            }
            if (index > 233 && index < 260)
            {
                number = "i" + provadiaNumbers[index - 234];
                provadiaNumbers[index] = number;
            }
        }
        BigInteger decimalNumber = BigInteger.Parse(Console.ReadLine());
        List<string> reverceNumber = new List<string>();
        for (; decimalNumber > 0; decimalNumber /= 256)
        {
            int reminder = (int)(decimalNumber % 256);
            reverceNumber.Add(provadiaNumbers[reminder]);
        }
        for (int index = reverceNumber.Count - 1; index >=0 ; index--)
        {
            Console.Write(reverceNumber[index]);
        }
    }
}