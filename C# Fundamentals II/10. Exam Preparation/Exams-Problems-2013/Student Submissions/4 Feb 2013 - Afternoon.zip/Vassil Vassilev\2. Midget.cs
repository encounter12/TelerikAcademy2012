using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Numerics;

class Program
{
    static decimal bestSum;
    static bool[] beenThere;

    static void Main()
    {
        #if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
        #endif

        bestSum = decimal.MinValue;
        string input = Console.ReadLine();
        int numberOfPatterns = int.Parse(Console.ReadLine());

        int[][] patterns = new int[numberOfPatterns][];

        for (int i = 0; i < patterns.GetLength(0); i++)
        {
            patterns[i] = inputToArray(Console.ReadLine());
        }

        int[] array = inputToArray(input);

        for (int i = 0; i < patterns.GetLength(0); i++)
        {
            BestSumChecker(patterns[i], array);
        }

        Console.WriteLine(bestSum);
    }

    private static void BestSumChecker(int[] pattern, int[] array)
    {
        beenThere = new bool[array.Length];
        beenThere[0] = true;
        int currentIndex = 0;
        decimal currentSum = array[0];

        int patternIndex = 0;

        do
        {
            if (patternIndex == pattern.Length)
            {
                patternIndex = 0;
            }

            currentIndex += pattern[patternIndex];

            bool isOK = IsIndexOK(array, currentIndex);
            if (isOK)
            {
                currentSum += array[currentIndex];
                beenThere[currentIndex] = true;
                patternIndex++;
            }
            else
            {
                if (currentSum > bestSum)
                {
                    bestSum = currentSum;
                }
                return;
            }
        }
        while (true);
    }

    private static int[] inputToArray(string input)
    {
        int[] nums = input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries).Select(n => Int32.Parse(n)).ToArray();
        return nums;
    }

    private static bool IsIndexOK(int[] array, int index)
    {
        try
        {
            if (index <= 0 || index > array.Length || beenThere[index] == true)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        catch (Exception)
        {
            return false;
        }
    }
}