using System;
using System.Collections.Generic;

class Midget
{
    static int checkPattern(int[] valley, bool[] visited ,int[] pattern)
    {
        int visit = 0;
        int coins = 0;
        coins = valley[visit];
        visited[visit] = true;
        for (int i = 0; i < pattern.Length; i++)
        {
            visit += pattern[i];
            if (visit < 0 || visit >= valley.Length)
	        {
		        return coins;
	        }
            if (visited[visit])
            {
                return coins;
            }
            coins += valley[visit];
            visited[visit] = true;
            if (i == pattern.Length - 1)
            {
                i = -1;
            }
        }
        return coins;
    }

    static void Main()
    {
        string readValley = Console.ReadLine();
        char[] separator = {','};
        string[] vallayValues = readValley.Split(separator, StringSplitOptions.RemoveEmptyEntries);
        int[] valley = new int[vallayValues.Length];
        for (int i = 0; i < valley.Length; i++)
        {
            valley[i] = int.Parse(vallayValues[i]);
        }
        int patternsCount = int.Parse(Console.ReadLine());
        int[][] patterns = new int[patternsCount][];
        for (int i = 0; i < patternsCount; i++)
        {
            string readPattern = Console.ReadLine();
            string[] patternValues = readPattern.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            patterns[i] = new int [patternValues.Length];
            for (int j = 0; j < patternValues.Length; j++)
            {
                patterns[i][j] = int.Parse(patternValues[j]); 
            }
        }

        bool[] visited = new bool[valley.Length];        
        int maxCoins = 0;
        int coins = 0;

        for (int i = 0; i < patterns.GetLength(0); i++)
        {
            coins = checkPattern(valley, visited, patterns[i]);
            if (coins > maxCoins)
            {
                maxCoins = coins;
            }
            for (int j = 0; j < visited.Length; j++)
            {
                visited[j] = false;
            }
        }
        Console.WriteLine(maxCoins);
    }
}