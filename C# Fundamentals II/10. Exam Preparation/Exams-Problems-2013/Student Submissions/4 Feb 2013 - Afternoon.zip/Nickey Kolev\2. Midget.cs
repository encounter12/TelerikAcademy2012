using System;
using System.Collections.Generic;
using System.Text;

class Midget
{
	private static int[] ParseInputLine(string[] strArr, int maxNums)
	{
		int maxLength = strArr.Length;
		if (strArr.Length > maxNums)
		{
			throw new ArgumentOutOfRangeException();
		}

		if (strArr.Length == 0)
		{
			throw new ArgumentException();
		}

		int[] returnArr = new int[maxLength];
		for (int i = 0; i < maxLength; i++)
		{
			
			if ((int.Parse(strArr[i]) >= -1000) && (int.Parse(strArr[i]) <= 1000))
			{
				returnArr[i] = int.Parse(strArr[i]);
			}	
			
		}
		
		return returnArr;
	}

	static void Main(string[] args)
	{
		/* some constants */
		const int patternMaxLength = 99;
		const int valleyMaxLength = 10000;
		const int maxPatterns = 499;

		
		string valleyStr = Console.ReadLine();
		char[] separators = { ',' };

		string[] valleyArr = valleyStr.Split(separators, StringSplitOptions.RemoveEmptyEntries);
		int[] valley = ParseInputLine(valleyArr, valleyMaxLength);

		int maxSum = 0;

		int numM = int.Parse(Console.ReadLine());
		if ((numM > maxPatterns) && (numM < 1 ))
		{
			throw new ArgumentException();
		}

		for (int pattCount = 1; pattCount <= numM; pattCount++)
		{
			string inputPatt = Console.ReadLine();

			string[] pattArr = inputPatt.Split(separators, StringSplitOptions.RemoveEmptyEntries);
			int[] currPattern = ParseInputLine(pattArr, patternMaxLength);

			int[] visited = new int[patternMaxLength];
			int visitIndex = 0;

			bool exit = false;
			int currIndex = 0;
			int currSum = currPattern[0];
			int pattIndex = 0;
			int nextIndex = 0;

			while (exit != true)
			{
				nextIndex = currIndex + currPattern[pattIndex];

				foreach (int visitedCell in visited)
				{
					// check if not visited
					if (nextIndex == visitedCell)
					{
						if (currSum > maxSum)
						{
							maxSum = currSum;
						}
						exit = true;
						break;
					}
				}

				// check if next is legitimate index:
				if ((nextIndex > valley.Length-1) || (nextIndex < 0))
				{
					if (currSum > maxSum)
					{
						maxSum = currSum;
					}
					exit = true;
					break;
				}

				currIndex = nextIndex;
				pattIndex++;
				visitIndex++;

				if (pattIndex >= pattArr.Length)
				{
					pattIndex = 0;
				}

				currSum += valley[nextIndex];
				visited[visitIndex] = nextIndex;
				
			}
		}

		Console.WriteLine("{0}", maxSum);
	}
}