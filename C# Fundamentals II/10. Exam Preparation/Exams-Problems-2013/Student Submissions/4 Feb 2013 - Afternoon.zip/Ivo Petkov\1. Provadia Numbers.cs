using System;
using System.Numerics;

class ProvadiaNumbers
{
    static void Main()
    {
        BigInteger dec = BigInteger.Parse(Console.ReadLine());
        string[] representation = new string[256];
        string output = "";
        if (dec == 0)
        {
            Console.WriteLine("A");
            return;
        }
        for (int i = 0; i < 26; i++)
        {
            representation[i] = "" + (char)(65 + i);
        }

        int index = 26;
        for (int i = 0; i < 9; i++)
        {
            for (int j = 0; j < 26; j++)
            {
                if (i==8 && j == 22)
                {
                    break;
                }
                representation[index] = "" + (char)(97 + i);
                representation[index] += "" + (char)(65 + j);
                index++;
            }    
        }
        
        while (dec > 0)  
        {

            output = representation[(int)(dec % 256)] + output;
            dec /= 256;
        }              
        Console.WriteLine(output);
        
    }
}