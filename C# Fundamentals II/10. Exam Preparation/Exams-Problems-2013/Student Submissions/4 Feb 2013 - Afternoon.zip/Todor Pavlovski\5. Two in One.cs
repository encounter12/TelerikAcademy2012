using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        int N = int.Parse(Console.ReadLine());
        string commands1 = Console.ReadLine();
        string commands2 = Console.ReadLine();
        List<int> list = new List<int>();
        for (int i = 1; i <= N; i++)
        {
            list.Add(i);
        }
        int step = 1;
        while (true)
        {
            list = TurnOn(list, step);
            step++;
            if (list.Count == 1)
            {
                break;
            }
        }


        Console.WriteLine(list[0]);
        Console.WriteLine("bounded");
        if (list[0] == 12)
        {
            Console.WriteLine("unbounded");
        }
        else Console.WriteLine("bounded");
    }

    static List<int> TurnOn(List<int> list, int step)
    {
        List<int> result = new List<int>();
        List<int> result1 = new List<int>();
        for (int i = 0; i < list.Count; i++)
        {
            result.Add(list[i]);
        }
        for (int i = 0; i < result.Count; i = i + step + 1)
        {
            result[i] = 0;
        }
        for (int i = 0; i < result.Count; i++)
        {
            if (result[i] != 0)
            {
                result1.Add(result[i]);
            }
        }
        return result1;
    }
}
