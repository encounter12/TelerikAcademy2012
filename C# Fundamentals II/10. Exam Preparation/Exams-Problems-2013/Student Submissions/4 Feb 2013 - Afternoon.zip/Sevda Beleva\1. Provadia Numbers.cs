using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
 
namespace _1ProvadiaNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            ulong decimalNumber = ulong.Parse(Console.ReadLine());
            StringBuilder wantedNumber = new StringBuilder();
            while (decimalNumber > 0)
            {
                ulong result = decimalNumber >= 256 ? (decimalNumber % 256) : decimalNumber;
                switch (result)
                {
                    case 0: wantedNumber.Append('A');
                        break;
 
                    case 1: wantedNumber.Append('B');
                        break;
 
                    case 2: wantedNumber.Append('C');
                        break;
 
                    case 3: wantedNumber.Append('D');
                        break;
 
                    case 4: wantedNumber.Append('E');
                        break;
 
                    case 5: wantedNumber.Append('F');
                        break;
 
                    case 6: wantedNumber.Append('G');
                        break;
 
                    case 7: wantedNumber.Append('H');
                        break;
 
                    case 8: wantedNumber.Append('I');
                        break;
 
                    case 9: wantedNumber.Append('J');
                        break;
 
                    case 10: wantedNumber.Append('K');
                        break;
 
                    case 11: wantedNumber.Append('L');
                        break;
 
                    case 12: wantedNumber.Append('M');
                        break;
 
                    case 13: wantedNumber.Append('N');
                        break;
 
                    case 14: wantedNumber.Append('O');
                        break;
 
                    case 15: wantedNumber.Append('p');
                        break;
 
                    case 16: wantedNumber.Append('Q');
                        break;
 
                    case 17: wantedNumber.Append('R');
                        break;
 
                    case 18: wantedNumber.Append('S');
                        break;
 
                    case 19: wantedNumber.Append('T');
                        break;
 
                    case 20: wantedNumber.Append('U');
                        break;
 
                    case 21: wantedNumber.Append('V');
                        break;
 
                    case 22: wantedNumber.Append('W');
                        break;
 
                    case 23: wantedNumber.Append('X');
                        break;
 
                    case 24: wantedNumber.Append('Y');
                        break;
 
                    case 25: wantedNumber.Append('Z');
                        break;
 
 
 
 
 
                    case 26: wantedNumber.Append("aA");
                        break;
 
                    case 27: wantedNumber.Append("aB");
                        break;
 
                    case 28: wantedNumber.Append("aC");
                        break;
 
                    case 29: wantedNumber.Append("aD");
                        break;
 
                    case 30: wantedNumber.Append("aE");
                        break;
 
                    case 31: wantedNumber.Append("aF");
                        break;
 
                    case 32: wantedNumber.Append("aG");
                        break;
 
                    case 33: wantedNumber.Append("aH");
                        break;
 
                    case 34: wantedNumber.Append("aI");
                        break;
 
                    case 35: wantedNumber.Append("aJ");
                        break;
 
                    case 36: wantedNumber.Append("aK");
                        break;
 
                    case 37: wantedNumber.Append("aL");
                        break;
 
                    case 38: wantedNumber.Append("aM");
                        break;
 
                    case 39: wantedNumber.Append("aN");
                        break;
 
                    case 40: wantedNumber.Append("aO");
                        break;
 
                    case 41: wantedNumber.Append("aP");
                        break;
 
                    case 42: wantedNumber.Append("aQ");
                        break;
 
                    case 43: wantedNumber.Append("aR");
                        break;
 
                    case 44: wantedNumber.Append("aS");
                        break;
 
                    case 45: wantedNumber.Append("aT");
                        break;
 
                    case 46: wantedNumber.Append("aU");
                        break;
 
                    case 47: wantedNumber.Append("aV");
                        break;
 
                    case 48: wantedNumber.Append("aW");
                        break;
 
                    case 49: wantedNumber.Append("aX");
                        break;
 
                    case 50: wantedNumber.Append("aY");
                        break;
 
                    case 51: wantedNumber.Append("aZ");
                        break;
 
 
 
 
                    case 52: wantedNumber.Append("bA");
                        break;
 
                    case 53: wantedNumber.Append("bB");
                        break;
 
                    case 54: wantedNumber.Append("bC");
                        break;
 
                    case 55: wantedNumber.Append("bD");
                        break;
 
                    case 56: wantedNumber.Append("bE");
                        break;
 
                    case 57: wantedNumber.Append("bF");
                        break;
 
                    case 58: wantedNumber.Append("bG");
                        break;
 
                    case 59: wantedNumber.Append("bH");
                        break;
 
                    case 60: wantedNumber.Append("bI");
                        break;
 
                    case 61: wantedNumber.Append("bJ");
                        break;
 
                    case 62: wantedNumber.Append("bK");
                        break;
 
                    case 63: wantedNumber.Append("bL");
                        break;
 
                    case 64: wantedNumber.Append("bM");
                        break;
 
                    case 65: wantedNumber.Append("bN");
                        break;
 
                    case 66: wantedNumber.Append("bO");
                        break;
 
                    case 67: wantedNumber.Append("bP");
                        break;
 
                    case 68: wantedNumber.Append("bQ");
                        break;
 
                    case 69: wantedNumber.Append("bR");
                        break;
 
                    case 70: wantedNumber.Append("bS");
                        break;
 
                    case 71: wantedNumber.Append("bT");
                        break;
 
                    case 72: wantedNumber.Append("bU");
                        break;
 
                    case 73: wantedNumber.Append("bV");
                        break;
 
                    case 74: wantedNumber.Append("bW");
                        break;
 
                    case 75: wantedNumber.Append("bX");
                        break;
 
                    case 76: wantedNumber.Append("bY");
                        break;
 
                    case 77: wantedNumber.Append("bZ");
                        break;
 
 
 
                    case 209: wantedNumber.Append("hA");
                        break;
 
                    case 210: wantedNumber.Append("hB");
                        break;
 
                    case 211: wantedNumber.Append("hC");
                        break;
 
                    case 212: wantedNumber.Append("hD");
                        break;
 
                    case 213: wantedNumber.Append("hE");
                        break;
 
                    case 214: wantedNumber.Append("hF");
                        break;
 
                    case 215: wantedNumber.Append("hG");
                        break;
 
                    case 216: wantedNumber.Append("hH");
                        break;
 
                    case 217: wantedNumber.Append("hI");
                        break;
 
                    case 218: wantedNumber.Append("hJ");
                        break;
 
                    case 219: wantedNumber.Append("hK");
                        break;
 
                    case 220: wantedNumber.Append("hL");
                        break;
 
                    case 221: wantedNumber.Append("hM");
                        break;
 
                    case 222: wantedNumber.Append("hN");
                        break;
 
                    case 223: wantedNumber.Append("hO");
                        break;
 
                    case 224: wantedNumber.Append("hP");
                        break;
 
                    case 225: wantedNumber.Append("hQ");
                        break;
 
                    case 226: wantedNumber.Append("hR");
                        break;
 
                    case 227: wantedNumber.Append("hS");
                        break;
 
                    case 228: wantedNumber.Append("hT");
                        break;
 
                    case 229: wantedNumber.Append("hU");
                        break;
 
                    case 230: wantedNumber.Append("hV");
                        break;
 
                    case 231: wantedNumber.Append("hW");
                        break;
 
                    case 232: wantedNumber.Append("hX");
                        break;
 
                    case 233: wantedNumber.Append("hY");
                        break;
 
                    case 234: wantedNumber.Append("hZ");
                        break;
 
 
 
 
                    case 235: wantedNumber.Append("iA");
                        break;
 
                    case 236: wantedNumber.Append("iB");
                        break;
 
                    case 237: wantedNumber.Append("iC");
                        break;
 
                    case 238: wantedNumber.Append("iD");
                        break;
 
                    case 239: wantedNumber.Append("iE");
                        break;
 
                    case 240: wantedNumber.Append("iF");
                        break;
 
                    case 241: wantedNumber.Append("iG");
                        break;
 
                    case 242: wantedNumber.Append("iH");
                        break;
 
                    case 243: wantedNumber.Append("iI");
                        break;
 
                    case 244: wantedNumber.Append("iJ");
                        break;
 
                    case 245: wantedNumber.Append("iK");
                        break;
 
                    case 246: wantedNumber.Append("iL");
                        break;
 
                    case 247: wantedNumber.Append("iM");
                        break;
 
                    case 248: wantedNumber.Append("iN");
                        break;
 
                    case 249: wantedNumber.Append("iO");
                        break;
 
                    case 250: wantedNumber.Append("iP");
                        break;
 
                    case 251: wantedNumber.Append("iQ");
                        break;
 
                    case 252: wantedNumber.Append("iR");
                        break;
 
                    case 253: wantedNumber.Append("iS");
                        break;
 
                    case 254: wantedNumber.Append("iT");
                        break;
 
                    case 255: wantedNumber.Append("iU");
                        break;
 
                    case 256: wantedNumber.Append("iV");
                        break;     
                }
                decimalNumber = decimalNumber / 256;
            }
            // reverse string
            StringBuilder reversed = new StringBuilder();
            for (int i = wantedNumber.Length - 1; i > -1; i--)
            {
                reversed.Append(wantedNumber[i]);
            }
            // print reversed string and get the number you want
             
            Console.WriteLine(reversed.ToString());
 
             
 
   
        }
    }
}