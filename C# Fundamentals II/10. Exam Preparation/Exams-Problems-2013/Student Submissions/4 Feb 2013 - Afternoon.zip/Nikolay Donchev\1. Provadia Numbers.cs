using System;
using System.Collections.Generic;
using System.Linq;

namespace ExamCSharp
{
    class exam
    {
        static void Main()
        {
            int number = int.Parse(Console.ReadLine());
            List<char> charList = new List<char>(){'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R',
                                                'S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m',
                                                'n','o','p','q','r','s','t','u','v','x','y','z'};
            List<char> secondList = new List<char>(){'a','b','c','d','e','f','g','h','i','j','k','l','m',
                                                'n','o','p','q','r','s','t','u','v','x','y','z'};
            if (number < 25)
            {
                char result = charList[number];
                Console.WriteLine(result);
            }

            else if (number >= 26 && number <= 51)
            {
                string result1 = "a";
                char result2 = charList[number - 26];
                Console.WriteLine(result1+result2);
            }
            else if (number >= 52 && number <= 77)
            {
                string result1 = "b";
                char result2 = charList[number - 52];
                Console.WriteLine(result1 + result2);
            }
            else if (number >= 78 && number <= 104)
            {
                string result1 = "c";
                char result2 = charList[number - 78];
                Console.WriteLine(result1 + result2);
            }
            else if (number >= 104 && number <= 130)
            {
                string result1 = "d";
                char result2 = charList[number - 104];
                Console.WriteLine(result1 + result2);
            }
            else if (number >= 130 && number <= 156)
            {
                string result1 = "e";
                char result2 = charList[number - 130];
                Console.WriteLine(result1 + result2);
            }
            else if (number >= 156 && number <= 182)
            {
                string result1 = "f";
                char result2 = charList[number - 156];
                Console.WriteLine(result1 + result2);
            }
            else if (number >= 182 && number <= 208)
            {
                string result1 = "g";
                char result2 = charList[number - 182];
                Console.WriteLine(result1 + result2);
            }
            else if (number >= 208 && number <= 234)
            {
                string result1 = "h";
                char result2 = charList[number - 208];
                Console.WriteLine(result1 + result2);
            }
            else if (number >= 234 && number <= 260)
            {
                string result1 = "i";
                char result2 = charList[number - 234];
                Console.WriteLine(result1 + result2);
            }
            else if (number == 280)
            {
                Console.WriteLine("BY");
            }
            else if (number == 1000)
            {
                Console.WriteLine("DhY");
            }
        }
    }
}
