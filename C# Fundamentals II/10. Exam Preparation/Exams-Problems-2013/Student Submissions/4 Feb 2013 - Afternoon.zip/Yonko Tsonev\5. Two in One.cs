using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoInOne
{
    class Program
    {
        static byte[] lamps;
        static int lastLampTurnedOff;
        static int firstOn=0;
        static void Main(string[] args)
        {
            int numberOfLamps = int.Parse(Console.ReadLine());
            lamps = new byte[numberOfLamps];
            string commandsForJoro1 = Console.ReadLine();
            string commandsForJoro2 = Console.ReadLine();
            int everyHow = 2;
            while (everyHow!=0)
            {
                everyHow = LampSover(numberOfLamps, everyHow);
            }
            Console.WriteLine(lastLampTurnedOff+1);
            Console.WriteLine(SolveJoro(commandsForJoro1));
            Console.WriteLine(SolveJoro(commandsForJoro2));
        }

        private static string SolveJoro(string commandsForJoro)
        {
            char[] command = commandsForJoro.ToCharArray();
            int countL = 0;
            int countR = 0;
            for (int i = 0; i < command.Length; i++)
            {
                if (command[i]=='L')
                {
                    countL++;
                }
                if (command[i] == 'R')
                {
                    countR++;
                }
            }
            if (countL!=countR)
            {
                return "bounded";
            }
            else
	        {
                return "unbounded";
	        }
        }
        public static int LampSover(int numberOfLamps, int everyHow)
        {
           int counter = 0;
           int start = 0;
           for (int i = firstOn; i < numberOfLamps; i++)
           {
               if (lamps[i]==0)
               {
                   lamps[i] = 1;
                   lastLampTurnedOff = i;
                   start = i + 1;
                   firstOn = i;
                   break;
               }
               if (i==numberOfLamps-1)
               {
                   return 0;
               }
               
           }
           for (int i = start; i < numberOfLamps; i++)
           {
               if (lamps[i]==0)
               {
                   counter++;

                   if (counter == everyHow)
                   {
                       lamps[i] = 1;
                       lastLampTurnedOff = i;
                       counter = 0;
                       continue;
                   }
               }
           }
           return everyHow + 1;
        }
    }
}
