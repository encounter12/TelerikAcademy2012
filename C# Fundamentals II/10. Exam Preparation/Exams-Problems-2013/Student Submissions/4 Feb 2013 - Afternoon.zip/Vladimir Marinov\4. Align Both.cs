using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace tasc4
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int W = int.Parse(Console.ReadLine());
            for (int i = 0; i < N; i++)
            {
                string A = Console.ReadLine();
                string[] B = A.Split(new char[]{' '},StringSplitOptions.RemoveEmptyEntries);
                foreach (var X in B)
                Console.Write("{0} ",X);

            }

        }
    }
}
