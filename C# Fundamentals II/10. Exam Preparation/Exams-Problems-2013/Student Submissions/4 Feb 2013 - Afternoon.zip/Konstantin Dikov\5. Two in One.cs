using System;
using System.Collections.Generic;

class Task5
{
    static void Main()
    {
        int lampsCount = int.Parse(Console.ReadLine());
        int turn = 2;
        int currentTurn = 1;
        int offLamps = 0;
        int lastLamp = 0;

        List<int> lamps = new List<int>();

        for (int i = 1; i < lampsCount; i = i + 2)
        {
            lamps.Add(i);
        }
        while (true)
        {
            List<int> toRemove = new List<int>();
            turn++;
            toRemove.Add(lamps[0]);
            while (currentTurn < lamps.Count)
            {
                if (currentTurn % turn == 0)
                {
                    toRemove.Add(lamps[currentTurn]);
                }
                currentTurn++;
            }

            for (int i = 0; i < toRemove.Count; i++)
            {
                lamps.Remove(toRemove[i]);
                lastLamp = toRemove[i];
            }

            if (lamps.Count == 0)
            {
                break;
            }
            currentTurn = 0;
        }

        string commands = Console.ReadLine();
        string commands2 = Console.ReadLine();
        Console.WriteLine(lastLamp + 1);

        bool bounded = Robot(commands);
        if (bounded)
        {
            Console.WriteLine("bounded");
        }
        else
        {
            Console.WriteLine("unbounded");
        }
        bounded = Robot(commands2);
        if (bounded)
        {
            Console.WriteLine("bounded");
        }
        else
        {
            Console.WriteLine("unbounded");
        }
    }

    private static bool Robot(string commands)
    {
        int startPosition = 0;
        int X = 0;
        int Y = 0;

        int[] direction = new int[2];
        direction[0] = 1;
        direction[1] = 0;

        for (int i = 0; i < 4; i++)
        {
            for (int y  = 0; y < commands.Length; y++)
            {
                switch (commands[y])
                { 
                    case 'S':
                        X = X + direction[1];
                        Y = Y + direction[0];
                        break;
                    case 'R':
                    case 'L':
                        direction = ChangeDirection(direction, commands[y]);
                        break;
                }
            }
        }

        if (X == 0 && Y == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    private static int[] ChangeDirection(int[] direction, char command)
    {
        if (command == 'L')
        {
            if (direction[0] == 1 && direction[1] == 0)
            {
                direction[0] = 0;
                direction[1] = -1;
            }
            else if (direction[0] == 0 && direction[1] == -1)
            {
                direction[0] = -1;
                direction[1] = 0;
            }
            else if (direction[0] == -1 && direction[1] == 0)
            {
                direction[0] = 0;
                direction[1] = 1;
            }
            else if (direction[0] == 0 && direction[1] == 1)
            {
                direction[0] = 1;
                direction[1] = 0;
            }
        }
        if (command == 'R')
        {
            if (direction[0] == 1 && direction[1] == 0)
            {
                direction[0] = 0;
                direction[1] = 1;
            }
            else if (direction[0] == 0 && direction[1] == 1)
            {
                direction[0] = -1;
                direction[1] = 0;
            }
            else if (direction[0] == -1 && direction[1] == 0)
            {
                direction[0] = 0;
                direction[1] = -1;
            }
            else if (direction[0] == 0 && direction[1] == -1)
            {
                direction[0] = 1;
                direction[1] = 0;
            }
        }

        return direction;
    }
}