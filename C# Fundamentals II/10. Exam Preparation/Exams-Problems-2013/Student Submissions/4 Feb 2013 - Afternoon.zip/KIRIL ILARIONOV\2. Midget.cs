using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
sealed class Z2
{
    public static List<int> valley = new List<int>();
    public static int M;
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("input.txt"));
#endif
        string [] valueStrArray = (Console.ReadLine()).Split(',');
        //StringBuilder 
        for (int i = 0; i < valueStrArray.Length; i++)
        {
            valueStrArray[i]=valueStrArray[i].Trim();
            //Console.Write("{0}+", valueStrArray[i]);
            valley.Add(Convert.ToInt32(valueStrArray[i]));
        }

        //for (int i = 0; i < valley.Count; i++)
        //{
        //    Console.Write("{0} ",valley[i]);
        //}

        M = int.Parse(Console.ReadLine()); // pattern qty
        //Console.WriteLine("M={0}",M);
        List<int> [] patterns = new List<int> [M];

        //for (int i = 0; i < M; i++)
        //{
        //    patterns[i]=new List<int>();
        //}

        long[] sums = new long[M]; // zeros
        long max = long.MinValue;


        for (int i = 0; i < M; i++)
        {
            patterns[i] = new List<int>();
            sums[i] = valley[0];// 1st addEnd
            string[] patternStrArray = (Console.ReadLine()).Split(',');
            
            for (int k = 0; k < patternStrArray.Length; k++)
            {
                patternStrArray[k] = patternStrArray[k].Trim();
                //Console.Write(patternStrArray[k]);
                patterns[i].Add(Convert.ToInt32(patternStrArray[k]));
            };
            //Console.WriteLine();
        }
        //for (int i = 0; i < patterns.Length; i++)
        //{ // input is OK 
        //    for (int k = 0; k < patterns[i].Count; k++)
        //    {
        //        Console.Write("{0}+", patterns[i][k]);
        //    }
        //    Console.WriteLine();
        //}
        
        //for (int i = 0; i < sums.Length; i++)
        //{
        //    sums[i] = valley[0];// 1st addEnd
        //};
        bool[] visitedPositions = new bool[valley.Count];
        // and now to run through a set of patterns
        int pos=0;
        int remainder;
        for (int i = 0; i < patterns.Length; i++)
        {// to process a list into pattern[i]
            // to init visitedPosition through pattern[i]
            for (int j = 0; j < visitedPositions.Length; j++)
            {
                visitedPositions[j] = false;
            };
            visitedPositions[0] = true;
            pos = 0;
            remainder = 0;
            for (int k = 0; //(k < patterns[i].Count) &&
                            (pos + patterns[i][k%(patterns[i].Count)]<valley.Count)
                                ; k++, remainder = k % (patterns[i].Count))
            {
                if (visitedPositions[pos + patterns[i][remainder]])
                {
                    break;
                }
                else
                {
                    sums[i] += valley[pos + patterns[i][remainder]];
                    pos = pos + patterns[i][remainder];
                    //Console.WriteLine("sums[{0}] = {1}\t\tpos={2}", i, sums[i], pos);
                    visitedPositions[pos] = true;
                }
            }
            if (max < sums[i])
            {
                max = sums[i];
            }
        }
        // and now to find max(sum)
        //for (int i = 0; i < sums.Length; i++)
        //{//OK
        //    Console.WriteLine(sums[i]);
        //}
        
        //for (int i = 0; i < sums.Length; i++)
        //{
        //    if (max<sums[i])
        //    {
        //        max = sums[i];
        //    }
        //}
        Console.WriteLine(max);
    }
}