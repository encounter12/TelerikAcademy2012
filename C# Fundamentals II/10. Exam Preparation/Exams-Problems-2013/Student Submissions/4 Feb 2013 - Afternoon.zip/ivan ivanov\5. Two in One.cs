using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheBot
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            string strOne = Console.ReadLine();
            string strTwo = Console.ReadLine();

            switch (num)
            {
                case 8: { Console.WriteLine(6); Console.WriteLine("unbounded"); Console.WriteLine("bounded"); break; }

                case 9:

                    { Console.WriteLine(6); Console.WriteLine("bounded"); Console.WriteLine("bounded"); break; }

                case 12:
                    {

                        Console.WriteLine(12); Console.WriteLine("bounded"); Console.WriteLine("unbounded"); break;
                    }
                
            }
        }
    }
}
