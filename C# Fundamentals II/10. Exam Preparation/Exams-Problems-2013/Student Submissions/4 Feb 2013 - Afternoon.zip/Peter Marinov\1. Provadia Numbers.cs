using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha1
{
    class Program
    {

        static void Main(string[] args)
        {

            decimal chislo = decimal.Parse(Console.ReadLine());
            int br = 0;
            int[] bukvi = new int[2];
            if (chislo < 256)
            {
                for (int i = 0; i < chislo; i++)
                {
                    if (bukvi[1] < 27)
                    {
                        bukvi[1]++;
                    }
                    if (bukvi[1] == 26)
                    {
                        bukvi[1] = 0;
                        bukvi[0]++;
                    }
                }
                if (chislo < 26)
                {
                    Console.WriteLine((char)(bukvi[1] + 65));
                }
                else
                    Console.WriteLine("{0}{1}", (char)(bukvi[0] + 96), (char)(bukvi[1] + 65));
            }
        }
    }
}
