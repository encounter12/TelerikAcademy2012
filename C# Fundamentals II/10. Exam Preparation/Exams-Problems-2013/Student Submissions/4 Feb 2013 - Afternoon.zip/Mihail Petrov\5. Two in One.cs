using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
  
class Program
{
  
    public static void CountIt(List<int> list,int dem = 3)
    {
        for (int i = 0; i < list.Count; i +=dem)
        {
            if (i < list.Count)
            {
                list[i] = 0;
            }
        }
  
        list.RemoveAll(x => x.Equals(0));
  
        dem = dem + 1;
          
        if (list.Count > 1)
        {
            CountIt(list,dem);
        }
        else
        {
            Console.WriteLine(list[0]);
        }
    }
  
    public static void bundel(string steps){
  
        int count = 0;
        int step = 0;
        bool inStep = false;
  
        int stepLeft = 0;
        int stepRight = 0;
  
  
        if (steps.Length == 1)
        {
            if (steps[0] == 'L' || steps[0] == 'R')
            {
                Console.WriteLine("bounded");
            }
        }
        else
        {
            for (int i = 0; i < steps.Length; i++)
            {
                if (steps[i] == 'S')
                {
                    count++;
                }
  
                if (steps[i] == 'L')
                {
                    stepLeft++;
                }
  
                if (steps[i] == 'R')
                {
                    stepRight++;
                }
            }
  
            if (count == 0 || (stepLeft > stepRight || stepRight > stepLeft))
            {
                Console.WriteLine("bounded");
            }
            else
            {
                Console.WriteLine("unbounded");
            }
        }
  
         
    }
  
    static void Main(string[] args)
    {
  
        int set = int.Parse(Console.ReadLine());
  
        List<int> list = new List<int>();
        for (int i = 2; i <= set; i += 2)
        {
            list.Add(i);
        }
  
        string step1 = Console.ReadLine();
        string step2 = Console.ReadLine();
  
        CountIt(list);
        bundel(step1);
        bundel(step2);
  
    }
}