using System;
using System.Linq;
using System.Text;
using System.Numerics;
 
class Program
{
    static StringBuilder output = new StringBuilder();
 
    static void Main()
    {
        BigInteger input = BigInteger.Parse(Console.ReadLine());
        if (input == 0)
        {
            Console.WriteLine("A");
            return;
        }
        ConvertNumber(input);
        Console.WriteLine(output);
    }
 
    static string ConvertDecimalToProvadia(BigInteger number)
    {
        char firstLetter = (char)(number % 26 + 'A');
        if (number > 25)
        {
            char secondLetter = (char)(number / 26 + 'a' - 1);
            return String.Format("{0}{1}", secondLetter, firstLetter);
        }
        return String.Format("{0}", firstLetter);
    }
 
    static void ConvertNumber(BigInteger number)
    {
        BigInteger baseOutput = 256;
        while (number > 0)
        {
            BigInteger reminder = (BigInteger)number % baseOutput;
            output.Insert(0, ConvertDecimalToProvadia(reminder));
 
            number /= baseOutput;
        }
 
    }
}