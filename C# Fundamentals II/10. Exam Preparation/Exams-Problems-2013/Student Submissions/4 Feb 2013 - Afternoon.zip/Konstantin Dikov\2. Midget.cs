using System;
using System.Text;
using System.Text.RegularExpressions;

class Task2
{
    public static double[,] coinsValey;
    static void Main()
    {
        string input = Console.ReadLine();

        coinsValey = StringToPattern(input);
        int M = int.Parse(Console.ReadLine());
        string[] patterns = new string[M];

        for (int i = 0; i < M; i++)
        {
            patterns[i] = Console.ReadLine();
        }

        double max = int.MinValue;
        double currentMax = 0;
        double currentPosition = 0;

        for (int i = 0; i < M; i++)
        {
            double[,] pattern = StringToPattern(patterns[i]);
            currentMax = RunValey(pattern);
            if (currentMax > max)
            {
                max = currentMax;
            }
        }

        Console.WriteLine(max);
    }

    private static double RunValey(double[,] pattern)
    {
        double coins = 0;
        int currentPatternPosition = 0;
        int currentPosition = 0;

        double patL = coinsValey.GetLength(0);
        while (true)
        {
            if (currentPosition < 0 || currentPosition >= patL )
            {
                break;
            }
            if (coinsValey[currentPosition, 1] == 1)
            {
                break;
            }
            coins = coins + coinsValey[currentPosition,0];
            
            coinsValey[currentPosition, 1] = 1;
            currentPosition = (int)(currentPosition + pattern[currentPatternPosition, 0]);
            currentPatternPosition++;
            if (currentPatternPosition >= pattern.GetLength(0))
            {
                currentPatternPosition = 0;
            }
        }

        for (int i = 0; i < coinsValey.GetLength(0); i++)
        {
            coinsValey[i, 1] = 0;
        }
        return coins;
    }

    private static double[,] StringToPattern(string input)
    {
        string[] coinsInput = Regex.Replace(input, " ", "").Split(',');

        double[,] positions = new double[coinsInput.Length, 2];
        for (int i = 0; i < coinsInput.Length; i++)
        {
            positions[i, 0] = double.Parse(coinsInput[i]);
        }
        return positions;
    }
}