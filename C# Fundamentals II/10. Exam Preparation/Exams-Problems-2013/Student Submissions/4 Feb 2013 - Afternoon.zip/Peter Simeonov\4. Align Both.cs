using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam._4.AlignBoth
{
    class Program
    {

        static void Main(string[] args)
        {
            ushort numberOfLines = ushort.Parse(Console.ReadLine());
            ushort width = ushort.Parse(Console.ReadLine());
            List<string[,]> words = new List<string[,]>();

            for (int i = 0; i < numberOfLines; i++)
            {
                string[] inputLines = Console.ReadLine().Trim().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                for (int j = 0; j < inputLines.Length; j++)
                {
                    string[,] word = new string[2, 1];
                    word[0, 0] = inputLines[j];
                    word[1, 0] = inputLines[j].Length.ToString();
                    words.Add(word);

                }
            }

            int countPlaces = 0;
            StringBuilder line = new StringBuilder();
            int counter = 0;
            int wordCounter = 0;
            int entered = words.Count;
            while (words.Count > 0)
            {
                countPlaces += int.Parse(words[counter][1, 0]) + 1;
                entered--;
                wordCounter++;
                if (countPlaces - 1 >= width || entered == 0)
                {
                    if (countPlaces - 1 > width)
                    {
                        countPlaces -= int.Parse(words[counter][1, 0]) + 1;
                        counter--;
                        entered++;
                        wordCounter--;
                    }
                    for (int j = 0; j <= counter; j++)
                    {
                        line.Append(words[j][0, 0]);
                        if (j + 1 <= counter)
                        {
                            line.Append(" ");
                        }
                    }
                    int delta = width - line.Length;
                    int position = 0;
                    int turns = 2;

                    if (words.Count > 1 && wordCounter != 1)
                    {
                        for (int x = 0; x < delta; x++)
                        {
                            position = line.ToString().IndexOf(' ', position);
                            if (position == -1)
                            {
                                position = 0;
                                position = line.ToString().IndexOf(' ', position);
                                turns++;
                            }
                            line.Insert(position, " ");
                            position += turns;
                        }
                    }
                    Console.WriteLine(line.ToString());
                    for (int z = 0; z <= counter; z++)
                    {
                        words.RemoveAt(0);


                    }
                    line.Clear();
                    counter = -1;
                    countPlaces = 0;
                    wordCounter = 0;
                }
                counter++;
            }
        }
    }
}
