using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
  
class Program
{
    static void Main()
    {
        long number = long.Parse(Console.ReadLine());
        ConvertDecToProvNumb(number);
    }
    static void ConvertDecToProvNumb(long n)
    {
        StringBuilder provNumber = new StringBuilder();
        long current = 0;
        while (n > 0)
        {
            current = n % 256;
            if (current <= 25)
            {
                if (current==0)
                {
                    provNumber.Append('A');
                }
                else
                {
                    provNumber.Append(Convert.ToChar((65 + current)));
                }
                  
            }
            else if (current<=51)
            {
                provNumber.Append(Convert.ToChar((39 + current))+ "a");
            }
            else if (current<=77)
            {
                provNumber.Append(Convert.ToChar((13 + current))+"b"); // do tuk
            }
            else if (current <= 103)
            {
                provNumber.Append( Convert.ToChar((-13 + current))+"c");
            }
            else if (current <= 129)
            {
                provNumber.Append( Convert.ToChar((-39 + current))+"d" );
            }
            else if (current <= 155)
            {
                provNumber.Append( Convert.ToChar((-65 + current))+"e" );
            }
            else if (current <= 181)
            {
                provNumber.Append(Convert.ToChar((-91 + current))+"f");
            }
            else if (current <= 207)
            {
                provNumber.Append(Convert.ToChar((-117 + current))+"g" );
            }
            else if (current <= 233)
            {
                provNumber.Append(Convert.ToChar((-143 + current))+"h");
            }
            else if (current <= 255)
            {
                provNumber.Append( Convert.ToChar((-169 + current))+"i");
            }
  
            n /= 256;
        }
        string number = provNumber.ToString();
        char[] arrNumb = number.ToCharArray();
        Array.Reverse(arrNumb);
        foreach (var ch in arrNumb)
        {
            Console.Write(ch);
        }
    }
}