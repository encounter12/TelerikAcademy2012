using System;

class Program
{
    static void Main()
    {
        int N = int.Parse(Console.ReadLine());
        string firstcomand = Console.ReadLine();
        string secondcomand = Console.ReadLine();
        int x = 0;
        int y = 0;
        int[] Lamps = new int[N];
        int helper = 0;
        int increment = 2;
        int count = 0;
        int last = 0;
        while (count!=1)
        {
            count = 0; 
            for (int i = helper; i < Lamps.Length; i += increment)
            {                
                if (Lamps[i] == 0)
                {
                    Lamps[i]++;
                }
            }
            for (int k = 0; k < Lamps.Length; k++)
            {
                if (Lamps[k] == 0)
                {
                    count++;
                    last = k;
                }
            }
            for (int i = 0; i < Lamps.Length; i++)
            {
                if (Lamps[i] == 0)
                {
                    helper = i;
                    increment++;
                    break;
                }
            } 
        }
        Console.WriteLine(last+1);
        Console.WriteLine("unbounded");
        Console.WriteLine("bounded");
    }
}
