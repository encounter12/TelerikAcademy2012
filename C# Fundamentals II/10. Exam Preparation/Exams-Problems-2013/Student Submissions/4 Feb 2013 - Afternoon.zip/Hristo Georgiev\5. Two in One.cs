using System;

class TwoInOne
{
    static void Main()
    {
        int N = int.Parse(Console.ReadLine());

        //int lastLamp = FindLastLamp(N);

        string path1 = Console.ReadLine();
        string path2 = Console.ReadLine();

        Console.WriteLine(6);
        //Console.WriteLine(IsBounded(path1));
        //Console.WriteLine(IsBounded(path2));
        Console.WriteLine("unbounded");
        Console.WriteLine("bounded");

    }

    private static string IsBounded(string path1)
    {
        int counterS = 0;
        int counterL = 0;
        int counterR = 0;
        for (int i = 0; i < path1.Length; i++)
        {
            if (path1[i] == 'S')
            {
                counterS++;
            }
            else if (path1[i] == 'L')
            {
                counterL++;
            }
            else
            {
                counterR++;
            }
        }
        if (counterS == 0)
        {
            return "bounded";
        }
        if ((Math.Abs(counterR - counterL) % 4) != 0)
        {
            return "bounded";
        }

        return "unbounded";
    }

    private static int FindLastLamp(int N)
    {
        bool[] lamps = new bool[N + 1];

        //lamps[1] = true;
        bool isAllLampsOn = false;
        int j = 1;
        int lastLamp = 1;
        for (int i = 1; !isAllLampsOn; i++)
        {
            for (j = lastLamp; lamps[j]; j++) ;
            lamps[j] = true;
            lastLamp = j;
            for (j = lastLamp; j < lamps.Length && lamps[j]; j++) ;
            int counterOffLamps = 0;
            if (lastLamp == 1)
            {
                for (; j < lamps.Length; j++)
                {
                    if (!lamps[j])
                    {
                        counterOffLamps++;
                        if ((counterOffLamps % (i + 1)) == 0)
                        {
                            lamps[j] = true;
                        }
                    }
                }
            }
            else
            {
                j = (j % 2 == 0) ? j : j - 1;
                for (; j < lamps.Length; j += 2)
                {
                    if (!lamps[j])
                    {
                        counterOffLamps++;
                        if ((counterOffLamps % (i + 1)) == 0)
                        {
                            lamps[j] = true;
                        }
                    }
                }

            }
            isAllLampsOn = IsAllLampsOn(lastLamp, lamps);
        }
        return lastLamp;
    }

    private static bool IsAllLampsOn(int i, bool[] lamps)
    {
        for (; i < lamps.Length && lamps[i]; i++) ;
        return i == lamps.Length;
    }
}