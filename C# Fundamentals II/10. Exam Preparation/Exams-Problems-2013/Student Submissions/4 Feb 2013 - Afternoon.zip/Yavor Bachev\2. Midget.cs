using System;


class Problem_2
{
    
    static void Main()
    {

        //string test = "alabala";
        //char[] tr = new char[test.Length];

        //for (int i = 0; i < test.Length; i++)
        //{
        //    tr[i] = test[i];
        //}

        string line = Console.ReadLine();
        string[] valleyStr = line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

        int[] valey = new int[valleyStr.Length];
        for (int i = 0; i < valey.Length; i++)
        {
            valey[i] = int.Parse(valleyStr[i]);
        }

        int m = int.Parse(Console.ReadLine());
        int[][] patternJagg = new int[m][];

        for (int i = 0; i < m; i++)
        {
            line = Console.ReadLine();
            string[] inArrayStr = line.Split(new char[] { ',' });
            int[] temp = new int[inArrayStr.Length];
            
            for (int j = 0; j < inArrayStr.Length; j++)
            {
                temp[j] = int.Parse(inArrayStr[j]);
            }
            patternJagg[i] = temp;
        }

        int money = 0;
        int maxMoney = -1001;
        int[] tempValey = new int[valey.Length];
        int hopIndex = 0;   

        for (int i = 0; i < m; i++)
        {
            int[] innerArray = patternJagg [i];
            Array.Copy(valey, tempValey, valey.Length);
            int pattIndex = 0;
            money = 0;
            hopIndex = 0;

            while (hopIndex >= 0 && hopIndex < valey.Length && tempValey[hopIndex] != 0)
            {
                if ( hopIndex < valey.Length )
                {
                    money += tempValey[hopIndex];
                    tempValey[hopIndex] = 0;
                }

                hopIndex += innerArray[pattIndex];

                if (pattIndex == innerArray.Length - 1)
                {
                    pattIndex = 0;
                }
                else
                {
                    pattIndex++;
                }
            }

            if (maxMoney < money)
            {
                maxMoney = money;
            }
            
        }

        Console.WriteLine(maxMoney);

        //for (int i = 0; i < m; i++)
        //{
        //    int[] innerArray = patternJarrStr[i];
        //    for (int a = 0; a < innerArray.Length; a++)
        //    {
        //        Console.Write(innerArray[a] + " ");
        //    }
        //    Console.WriteLine();
        //}

        

    }
}
