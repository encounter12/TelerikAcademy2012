using System;

class Problem2
{
    public static short Moves(short[] valley, string move)
    {
        string[] moves = move.Split(',');

        for (short i = 0; i <= moves.Length -1; i++)
            moves[i] = moves[i].TrimStart();

        short[] pattern = new short[moves.Length];

        for (short i = 0; i <= moves.Length - 1; i++)
            pattern[i] = short.Parse(moves[i]);

        bool stop = false;
        short position = 0;
        short sum = 0;
        bool[] stops = new bool[valley.Length];
        for (short i = 0; i <= stops.Length - 1; i++)
        {
            stops[i] = true;
        }
        while (stop == false)
        {
                foreach (short item in pattern)
                {
                    if (position >= valley.Length || position < 0 || stops[position] == false)
                    {
                        stop = true;
                        break;
                    }
                    else
                    {
                        sum += valley[position];
                        position += item;
                        stops[position] = false;
                    }
                  

                }
                
        }
        return sum;
    }

    static void Main()
    {
        string valley = Console.ReadLine();
        string[] valley1 = valley.Split(',');

        for (short i = 0; i <= valley1.Length - 1; i++)
            valley1[i] = valley1[i].TrimStart();

        short[] array = new short[valley1.Length];

        for (short i = 0; i <= valley1.Length - 1; i++)
            array[i] = short.Parse(valley1[i]);

        short M = short.Parse(Console.ReadLine());
        short sum = short.MinValue;
        short maxSum = short.MinValue;

        for (short i = 0; i <= M - 1; i++)
        {
            string move = Console.ReadLine();
            sum = Moves(array, move);
            if (sum > maxSum)
            {
                maxSum = sum;
            }
        }
        Console.WriteLine(maxSum);
    }
}

