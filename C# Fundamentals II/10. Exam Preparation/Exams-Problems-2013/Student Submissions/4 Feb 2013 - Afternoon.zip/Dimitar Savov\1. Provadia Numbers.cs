using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LampsJoro
{
    class Program
    {
        static void Main()
        {
            int lampsNum = int.Parse(Console.ReadLine());
            string commands1 = Console.ReadLine();
            string commands2 = Console.ReadLine();
            Console.WriteLine(Lamps(lampsNum));
            Console.WriteLine(Robot(commands1));
            Console.WriteLine(Robot(commands2));
        

        }

        private static string Robot(string commands)
        {
            int rowStart = 2501;
            int colStart = 2501;
            int row = rowStart;
            int col = colStart;
            bool flag=true;
            string direction="N";
            int count = 0;
            string result = "";

            while (flag == true)
            {

                for (int i = 0; i < commands.Length; i++)
                {
                    if (commands[i] == 'S')
                    {
                        if (direction == "N")
                        {
                            row--;
                        }
                        else if(direction=="W")
                        {
                            col--;
                        }
                        else if (direction == "E")
                        {
                            col++;
                        }
                        else if (direction == "S")
                        {
                            row++;
                        } 
                    }
                    if (commands[i] == 'R')
                    {
                        if (direction == "N")
                        {
                            col++;
                            direction = "E";
                        }
                        else if (direction == "W")
                        {
                            row--;
                            direction = "N";
                        }
                        else if (direction == "E")
                        {
                            row++;
                            direction = "S";
                        }
                        else if (direction == "S")
                        {
                            col--;
                            direction = "W";
                        } 

                    }
                    if (commands[i] == 'L')
                    {
                        if (direction == "N")
                        {
                            col--;
                            direction = "W";
                        }
                        else if (direction == "W")
                        {
                            row++;
                            direction = "S";
                        }
                        else if (direction == "E")
                        {

                            row--;
                            direction = "N";
                        }
                        else if (direction == "S")
                        {
                            col++;
                            direction = "E";
                        } 
                    }
                }

                if (row == rowStart && col == colStart)
                {
                    flag = false;
                    result = "bounded";
                }
                count++;
                if (count > 5000)
                {
                    flag = false;
                    result = "unbounded";
                }
            }

            return result;
            
           

        }

        private static int Lamps(int lampsNum)
        {
            bool[] lamps = new bool[lampsNum+1];
            bool flag = false;
            int last = 0;
            int count = 2;
            for (int i = 1; i < lamps.Length; i++)
            {
                lamps[i] = false;
            }


            do
            {
                flag = true;
                for (int i = 1; i < lamps.Length; i++)
                {
                    if (lamps[i] == true)
                    {
                        continue;
                    }
                    else
                    {
                        for (int j = i; i < lamps.Length; i = i + count)
                        {
                            if (lamps[i] != true)
                            {
                                last = i;
                                lamps[i] = true;
                                
                            }
                            
                        }
                    }
                }


                for (int i = 1; i < lamps.Length; i++)
                {
                    if (lamps[i] == false)
                    {
                        flag = false;
                    }
                }
                count++;
            } while (flag == false);

            return last;
        }
    }
}
