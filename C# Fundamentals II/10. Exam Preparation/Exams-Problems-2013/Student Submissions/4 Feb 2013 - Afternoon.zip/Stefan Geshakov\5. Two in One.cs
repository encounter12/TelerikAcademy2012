using System;
using System.Collections.Generic;
using System.Text;


class TwoInOne
{
    static void JoroPath(string steps)
    {
        int x = 0;
        int y = 0;
        int r = steps.Length;

        bool positiveY = true;
        bool negativeY = false;
        bool positiveX = false;
        bool negativeX = false;
        char forward = 'S';
        char right = 'R';
        char left = 'L';
        bool stopLoop = false;
        int count = 0;

        while (((x * x) + (y * y) <= r * r) || !stopLoop)
        {
            for (int i = 0; i < steps.Length; i++)
            {
                if (steps[i] == forward)
                {
                    if (positiveY == true)
                    {
                        y++;
                    }
                    else if (negativeY == true)
                    {
                        y--;
                    }
                    else if (positiveX == true)
                    {
                        x++;
                    }
                    else if (negativeX == true)
                    {
                        x--;
                    }
                }
                else if (steps[i] == left)
                {
                    if (positiveY == true)
                    {
                        positiveY = false;
                        negativeX = true;
                    }
                    else if (negativeY == true)
                    {
                        negativeY = false;
                        positiveX = true;
                    }
                    else if (positiveX == true)
                    {
                        positiveX = false;
                        positiveY = true;
                    }
                    else if (negativeX == true)
                    {
                        negativeX = false;
                        negativeY = true;
                    }
                }
                else if (steps[i] == right)
                {
                    if (positiveY == true)
                    {
                        positiveY = false;
                        positiveX = true;
                    }
                    else if (negativeY == true)
                    {
                        negativeY = false;
                        negativeX = true;
                    }
                    else if (positiveX == true)
                    {
                        positiveX = false;
                        negativeY = true;
                    }
                    else if (negativeX == true)
                    {
                        negativeX = false;
                        positiveY = true;
                    }

                }
            }
            count++;
            if (count > 10)
            {
                break;
            }
        }
        if ((x * x) + (y * y) > r * r)
        {
            Console.WriteLine("unbounded");
        }
        else if ((x * x) + (y * y) <= r * r)
        {
            Console.WriteLine("bounded");
        }
    }

    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string commandsOne = Console.ReadLine();
        string commandsTwo = Console.ReadLine();
        bool[] boolArray = new bool[n];
        int firstOneOff = 0;
        int lastOneOn = 0;

        for (int i = 1; i < boolArray.Length; i++)
        {
            while (boolArray[firstOneOff])
            {
                firstOneOff++;
                if (firstOneOff == boolArray.Length)
                {
                    goto finish;
                }
            }
            for (int j = firstOneOff; j < boolArray.Length; j += i + 1)
            {
                boolArray[j] = true;
                lastOneOn = j;
            }

        }
    finish:
        Console.WriteLine(lastOneOn + 1);
        JoroPath(commandsOne);
        JoroPath(commandsTwo);
    }
}