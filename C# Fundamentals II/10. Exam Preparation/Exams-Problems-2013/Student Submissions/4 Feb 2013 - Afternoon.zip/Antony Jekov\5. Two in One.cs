using System;
using System.Collections.Generic;




class Problem05_TwoInOne
{
    static void Main()
    {
        // 8
        // SRSL
        // SSSSR

        int N = int.Parse(Console.ReadLine());
        List<int> lamps = new List<int>(N);

        for (int i = 0; i < N; i++)
        {
            lamps.Add(i + 1);
        }
        int lampsCount = N;

        int loop = 1;
        int position;
        int gap;

        while (lampsCount > 1)
        {
            position = 0;
            gap = loop + 1;
            while (position < lampsCount)
            {
                lamps[position] = 0;
                position += gap;
            }

            int index = 0;
            int count = lampsCount;
            for (int i = 0; i < count; i++)
            {
                if (lamps[i] != 0)
                {
                    lamps[index++] = lamps[i];
                }
                else
                {
                    lampsCount--;
                }
            }

            //int index2 = 0;
            //for (int i = 0; i < index + 1; i++)
            //{
            //    if (lamps[i] != 0)
            //    {
            //        lamps[index2++] = temp[i];
            //    }
            //}

            loop++;
        }


        char[] command1 = Console.ReadLine().ToCharArray();
        char[] command2 = Console.ReadLine().ToCharArray();

        int commandPosition = 0;
        int x = 0;
        int y = 0;

        bool upM = true;
        bool rightM = false;
        bool leftM = false;
        bool downM = false;

        int indexOf = -1;
        for (int i = 0; i < command1.Length; i++)
        {
            if (command1[i] == 'R' || command1[i] == 'L')
            {
                indexOf = i;
                break;
            }
        }

        Console.WriteLine(lamps[0]);
        if (command1.Length < 3)
        {
            Console.WriteLine("bounded");
        }
        else if (indexOf == -1)
        {
            Console.WriteLine("bounded");
        }
        else
        {
            for (int i = 0; i < 4; i++)
            {
                while (commandPosition < command1.Length)
                {
                    if (command1[commandPosition] == 'S')
                    {
                        if (upM)
                        {
                            y++;
                        }
                        else if (downM)
                        {
                            y--;
                        }
                        else if (rightM)
                        {
                            x++;
                        }
                        else if (leftM)
                        {
                            x--;
                        }
                    }
                    else if (command1[commandPosition] == 'L')
                    {
                        if (upM)
                        {
                            upM = false;
                            leftM = true;
                        }
                        else if (downM)
                        {
                            downM = false;
                            rightM = true;
                        }
                        else if (leftM)
                        {
                            leftM = false;
                            downM = true;
                        }
                        else if (rightM)
                        {
                            rightM = false;
                            upM = true;
                        }
                    }
                    else
                    {
                        if (upM)
                        {
                            upM = false;
                            rightM = true;
                        }
                        else if (downM)
                        {
                            downM = false;
                            leftM = true;
                        }
                        else if (leftM)
                        {
                            leftM = false;
                            upM = true;
                        }
                        else if (rightM)
                        {
                            rightM = false;
                            downM = true;
                        }
                    }

                    commandPosition++;
                }
                commandPosition = 0;
            }

            if (x == 0 && y == 0)
            {
                Console.WriteLine("bounded");
            }
            else
            {
                Console.WriteLine("unbounded");
            }
        }

        indexOf = -1;
        for (int i = 0; i < command1.Length; i++)
        {
            if (command1[i] == 'R' || command1[i] == 'L')
            {
                indexOf = i;
                break;
            }
        }
        commandPosition = 0;
        x = 0;
        y = 0;

        upM = true;
        rightM = false;
        leftM = false;
        downM = false;

        if (command2.Length < 3)
        {
            Console.WriteLine("bounded");
        }
        else if (indexOf == -1)
        {
            Console.WriteLine("bounded");
        }
        else
        {
            for (int i = 0; i < 4; i++)
            {
                while (commandPosition < command2.Length)
                {
                    if (command2[commandPosition] == 'S')
                    {
                        if (upM)
                        {
                            y++;
                        }
                        else if (downM)
                        {
                            y--;
                        }
                        else if (rightM)
                        {
                            x++;
                        }
                        else if (leftM)
                        {
                            x--;
                        }
                    }
                    else if (command2[commandPosition] == 'L')
                    {
                        if (upM)
                        {
                            upM = false;
                            leftM = true;
                        }
                        else if (downM)
                        {
                            downM = false;
                            rightM = true;
                        }
                        else if (leftM)
                        {
                            leftM = false;
                            downM = true;
                        }
                        else if (rightM)
                        {
                            rightM = false;
                            upM = true;
                        }
                    }
                    else
                    {
                        if (upM)
                        {
                            upM = false;
                            rightM = true;
                        }
                        else if (downM)
                        {
                            downM = false;
                            leftM = true;
                        }
                        else if (leftM)
                        {
                            leftM = false;
                            upM = true;
                        }
                        else if (rightM)
                        {
                            rightM = false;
                            downM = true;
                        }
                    }

                    commandPosition++;
                }
                commandPosition = 0;
            }

            if (x == 0 && y == 0)
            {
                Console.WriteLine("bounded");
            }
            else
            {
                Console.WriteLine("unbounded");
            }
        }
    }
}