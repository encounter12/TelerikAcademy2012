using System;
using System.Collections;
using System.Text.RegularExpressions;

class Midget
{
    static bool IsInValley(short[] valley, int ind)
    {
        return (ind >= 0) && (ind < valley.Length);
    }

    static int CollectPattern(short[] valley, short[] pattern)
    {
        bool[] visited = new bool[valley.Length];

        int currentInd = 0;
        int patternInd = 0;
        int sum = 0;

        while (IsInValley(valley, currentInd) && (visited[currentInd] == false))
        {
            visited[currentInd] = true;
            sum += valley[currentInd];

            currentInd += pattern[patternInd];

            patternInd++;
            if (patternInd == pattern.Length) patternInd = 0;
        }

        return sum;
    }

    static int CollectMaxCoins(short[] valley, ArrayList patterns)
    {
        int maxCoins = short.MinValue;
        int tempSum;

        foreach (short[] pattern in patterns)
        {
            tempSum = CollectPattern(valley, pattern);
            if (tempSum > maxCoins) maxCoins = tempSum;
        }

        return maxCoins;
    }

    static short[] ParseLine(string line)
    {
        string[] split = Regex.Split(line, @",+\s");
        short[] parsed = new short[split.Length];

        for (int i = 0; i < split.Length; i++)
        {
            parsed[i] = short.Parse(split[i]);
        }

        return parsed;
    }

    static void Main()
    {
        string line = Console.ReadLine();
        short[] valley = ParseLine(line);

        ArrayList patterns = new ArrayList();
        short m = short.Parse(Console.ReadLine());

        for (int i = 0; i < m; i++)
        {
            line = Console.ReadLine();
            short[] pattern = ParseLine(line);
            patterns.Add(pattern);
        }

        int maxSumCoins = CollectMaxCoins(valley, patterns);

        Console.WriteLine(maxSumCoins);
    }
}
