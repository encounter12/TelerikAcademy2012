using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace AlignBoth_4
{
    class AlignBoth_4
    {
        static void Main(string[] args)
        {
            string inputText = Console.ReadLine();
            int n = int.Parse(Console.ReadLine());
            int w = int.Parse(Console.ReadLine());
            if (0 > n && n > 1000)
            {
                Console.WriteLine("Invalid input!");
            }
            if (0 > w && w > 10000)
            {
                Console.WriteLine("Invalid input!");
            }

            int end = w - 1;
            string symbolLength = inputText.Substring(0, end);
            int start = 0;

            for (int j = 0; j <= n - 1; j++)
            {
                Console.WriteLine(inputText.Substring(start, end));
                start = end + 1;
                end = start + w - 1;
            }    
        }
    }
}