using System;

class Program
{
    public static void Main()
    {
        string[] numbers = Console.ReadLine().Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        int[] valley = new int[numbers.Length];

        for (int i = 0; i < valley.Length; ++i)
        {
            valley[i] = int.Parse(numbers[i]);
        }
        int patternsCount = int.Parse(Console.ReadLine());

        int maxCoins = int.MinValue;

        for (int i = 0; i < patternsCount; ++i)
        {
            numbers = Console.ReadLine().Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int[] pattern = new int[numbers.Length];

            for (int j = 0; j < pattern.Length; ++j)
            {
                pattern[j] = int.Parse(numbers[j]);
            }

            bool[] visited = new bool[valley.Length];

            int index = 0;
            int sum = valley[0];
            visited[0] = true;
            int indexInPattern = 0;
            while(index + pattern[indexInPattern] >= 0 && index + pattern[indexInPattern] < valley.Length && !visited[index + pattern[indexInPattern]])
            {
                index += pattern[indexInPattern];
                visited[index] = true;
                indexInPattern = (indexInPattern + 1) % pattern.Length;
                sum += valley[index];
            }
            if (sum > maxCoins)
            {
                maxCoins = sum;
            }
        }
        Console.WriteLine(maxCoins);

    }
}