using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CSharpPart2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadLine();
            int decNum = int.Parse(Console.ReadLine());
            //StringBuilder Provadia = new StringBuilder();
            //char converteddigit = new char();
            //string digittoconvert = "";
            string result = "";
            //while (decNum > 0)
            //{
                switch (decNum)
                {
                    //case 0 - 25:
                    //    //
                        
                    //    for (int i = 0; i < 26; i++)
                    //    {
                    //        converteddigit = 'a';
                    //        digittoconvert = converteddigit.ToString();
                    //        //converteddigit = 'a';
                    //        //Regex.Replace(decNum.ToString, i.ToString, converteddigit, "");
                    //        converteddigit++;
                    //        if (i==decNum)
                    //        {
                    //            result=digittoconvert);
                    //        }
                    //    }
                        
                    //    break;
                    case 0:
                        result="a";
                        break;
                    case 1:
                        result="b";
                        break;
                    case 2:
                        result="c";
                        break;
                    case 3:
                        result="d";
                        break;
                    case 4:
                        result="e";
                        break;
                    case 5:
                        result="f";
                        break;
                    case 6:
                        result="g";
                        break;
                    case 7:
                        result="h";
                        break;
                    case 8:
                        result="i";
                        break;
                    case 9:
                        result="j";
                        break;
                    case 10:
                        result="k";
                        break;
                    case 11:
                        result="l";
                        break;
                    case 12:
                        result="m";
                        break;
                    case 13:
                        result="n";
                        break;
                    case 14:
                        result="o";
                        break;
                    case 15:
                        result="p";
                        break;
                    case 16:
                        result="q";
                        break;
                    case 17:
                        result="r";
                        break;
                    case 18:
                        result="s";
                        break;
                    case 19:
                        result="t";
                        break;
                    case 20:
                        result="u";
                        break;
                    case 21:
                        result="v";
                        break;
                    case 22:
                        result="w";
                        break;
                    case 23:
                        result="v";
                        break;
                    case 24:
                        result="w";
                        break;
                    case 25:
                        result="x";
                        break;
                    case 26:
                        result="y";
                        break;
                    case 27:
                        result="z";
                        break;
                    default:
                        result="AA";
                        break;
                }
            //    decNum = decNum / 26;
            ////}
            //string endNum = Provadia.ToString();
            Console.WriteLine(result.ToUpper);
            //for (int i = endNum.Length - 1; i > -1; i--)
            //{
            //    Console.Write(endNum[i]);
            //}
            //Console.WriteLine();

        }
    }
}
