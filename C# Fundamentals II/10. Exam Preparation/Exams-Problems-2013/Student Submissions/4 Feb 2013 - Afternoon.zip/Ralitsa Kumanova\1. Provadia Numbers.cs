using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static char[] lettersCapital = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
    static StringBuilder inp = new StringBuilder();

    static void Main(string[] args)
    {
        int inputNum = int.Parse(Console.ReadLine());

        if (inputNum >= 0 && inputNum <= 25)
        {
            inp.Append(GetLetter(inputNum));
        }
        else if (inputNum >= 26 && inputNum <= 255)
        {
            int i = inputNum - 26;
            GetProvadiaNumber(i, inputNum);
        }
        else if (inputNum >= 256 && inputNum <= 511)
        {
            int temp = inputNum / 256;
            int remainder = inputNum - 256;
            inp.Append(GetLetter(temp));
            inp.Append(GetLetter(remainder));
        }
        else if (inputNum >= 512 && inputNum <= (256 * 256 - 1))
        {
            int temp = inputNum / 256;

            if (temp <= 25)
            {

                inp.Append(GetLetter(temp));
            }
            else {
                int p = 256 - temp;
                int count = 0;
                for (int j = 1; j < 9; j++)
                {
                    temp = temp / 26;
                    if (temp > 26)
                    {
                        count++;
                    }
                    else
                    {
                        break;
                    }
                }
                GetProvadiaNumber(temp - count * 26, p);   
            }
            int remainder = (int)((inputNum % 256));

            int i = 256 - remainder;
            if (i <= 25)
            {
                GetProvadiaNumber(i, remainder);
            }
            else
            {
                int count = 0;
                for (int j = 1; j < 9; j++)
                {
                    remainder = remainder / 26;
                    if (remainder > 26)
                    {
                        count++;
                    }
                    else
                    {
                        break;
                    }
                }
                GetProvadiaNumber(remainder-count*26, i);
            }
        }
        Console.WriteLine(inp);
    }

    static string GetLetter(int temp)
    {
        string ch = "";
        return ch += lettersCapital[temp].ToString();
    }

    static void GetProvadiaNumber(int i, int inputNum)
    {
        string ch = "";
        if (inputNum >= 26 && inputNum <= (26 * 2 - 1))
        {
            ch = "a" + lettersCapital[i];
            inp.Append(ch);
        }
        else if (inputNum >= (26 * 2) && inputNum <= (26 * 3 - 1))
        {
            ch = "b" + lettersCapital[i];
            inp.Append(ch);
        }
        else if (inputNum >= (26 * 3) && inputNum <= (26 * 4 - 1))
        {
            ch = "c" + lettersCapital[i];
            inp.Append(ch);
        }
        else if (inputNum >= (26 * 4) && inputNum <= (26 * 5 - 1))
        {
            ch = "d" + lettersCapital[i];
            inp.Append(ch);
        }

        else if (inputNum >= (26 * 5) && inputNum <= (26 * 6 - 1))
        {
            ch = "e" + lettersCapital[i];
            inp.Append(ch);
        }

        else if (inputNum >= (26 * 6) && inputNum <= (26 * 7 - 1))
        {
            ch = "f" + lettersCapital[i];
            inp.Append(ch);
        }

        else if (inputNum >= (26 * 7) && inputNum <= (26 * 8 - 1))
        {
            ch = "g" + lettersCapital[i];
            inp.Append(ch);
        }

        else if (inputNum >= (26 * 8) && inputNum <= (26 * 9 - 1))
        {
            ch = "h" + lettersCapital[i];
            inp.Append(ch);
        }

        else if (inputNum >= (26 * 9) && inputNum <= (255))
        {
            ch = "i" + lettersCapital[i];
            inp.Append(ch);
        }
    }
}


