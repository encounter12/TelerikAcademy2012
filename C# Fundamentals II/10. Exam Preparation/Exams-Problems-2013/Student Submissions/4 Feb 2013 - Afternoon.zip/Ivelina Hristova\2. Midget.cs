using System;

class Program
{
    static int Sum(int[] array, int[] arrayCheck)
    {
        bool[] seen = new bool[array.Length];
        int sum = array[0];
        int i = 0;
        for (int k = 0; k < array.Length; k++)
        {
            seen[k] = false;
        }
        seen[0] = true;
        while (true)
        {
            
            for (int j = 0; j < arrayCheck.Length; j++)
            {
                if (i + arrayCheck[j] < 0 || i + arrayCheck[j] >= array.Length)
                {

                    for (int k = 0; k < array.Length; k++)
                    {
                        seen[k] = false;
                    }
                    return sum;
                }
                if (seen[i + arrayCheck[j]] == false)
                {
                    sum += array[i + arrayCheck[j]];
                    if (i+arrayCheck[j] != arrayCheck.Length - 1)
                    {
                        seen[i + arrayCheck[j]] = true;
                    }
                    
                    i = i + arrayCheck[j];
                }
                else
                {
                    for (int k = 0; k < array.Length; k++)
                    {
                        seen[k] = false;
                    }
                    return sum;
                }

            }
            //int v = 0;
            //for (int j = 0; j < arrayCheck.Length; j++)
            //{
            //    seen[v + arrayCheck[j]] = true;
            //    v = v + arrayCheck[j];
            //}
        }
        return sum;
    }
    static int[] stringToArray(string str)
    {
        string[] numbers = str.Split(',');
        foreach (var item in numbers)
        {
            item.Trim();
        }
        int[] array = new int[numbers.Length];
        for (int i = 0; i < numbers.Length; i++)
        {
            array[i] = int.Parse(numbers[i]);
        }
        return array;
    }
    static void Main()
    {
        string str = Console.ReadLine();
        int max;
        int N = int.Parse(Console.ReadLine());
        string strs;
        int[] array = stringToArray(str);
        
        
        int[][] checkArrays = new int[N][];
        for (int i = 0; i < N; i++)
        {
            strs = Console.ReadLine();
            checkArrays[i] = stringToArray(strs);
        }
        max = Sum(array, checkArrays[0]);
        for (int i = 0; i < N; i++)
        {
            if (max < Sum(array, checkArrays[i]))
            {
                max = Sum(array, checkArrays[i]);
            }
        }
        Console.WriteLine(max);

    }
}