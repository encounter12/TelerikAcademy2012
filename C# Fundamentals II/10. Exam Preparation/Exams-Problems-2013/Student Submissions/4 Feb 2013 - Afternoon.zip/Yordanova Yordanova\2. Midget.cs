using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
  
class Program
    {
        static void Main(string[] args)
        {
            int valley = int.Parse(Console.ReadLine());

            int[] ints = new int[valley];

          
            for (int i = 0; i < valley; i++)
            {
                ints[i] = int.Parse(Console.ReadLine());
            }
    
        }

    }
