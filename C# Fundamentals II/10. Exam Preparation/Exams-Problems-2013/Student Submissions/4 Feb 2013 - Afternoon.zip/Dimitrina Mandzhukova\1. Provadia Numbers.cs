using System;
using System.Numerics;
using System.Text;

class ProvadiaNumbers
{
    static string Digit(BigInteger num)
    {
        string digit = "";

        BigInteger first = num / 26;

        if (first > 0)
        {
            digit += (char)(first - 1 + (int)'a');
        }

        BigInteger second = num % 26;
        digit += (char)(second + (int)'A');
        return digit;
    }

    static void Main()
    {
        BigInteger num = BigInteger.Parse(Console.ReadLine());
        StringBuilder sb = new StringBuilder();

        int counter = 0;

        while ((BigInteger)Math.Pow(256, counter) < num)
        {
            counter++;
        }
        counter--;

        BigInteger tempNum = num;

        for (int i = counter; i > 0; i--)
        {
            BigInteger stepen = (BigInteger)Math.Pow(256, i);

            sb.Append(Digit(tempNum / stepen));

            tempNum = tempNum % stepen;
        }

        sb.Append(Digit(tempNum % 256));

        Console.WriteLine(sb.ToString());
    }
}
