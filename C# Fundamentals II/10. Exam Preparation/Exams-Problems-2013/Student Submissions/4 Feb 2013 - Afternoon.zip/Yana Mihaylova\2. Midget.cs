using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Task2
{
    class SecondTask
    {
        static void Main(string[] args)
        {
            string theVallyStr = Console.ReadLine();
            char[] splitSeparators = new char[] { ' ', ',' };
            string[] vally = theVallyStr.Split(splitSeparators, StringSplitOptions.RemoveEmptyEntries);
            int[] theVally = new int[vally.Length];
            int maxSum = int.MinValue;
 
            for (int i = 0; i < vally.Length; i++)
            {
                theVally[i] = int.Parse(vally[i]);
            }
 
            int numberOfPatterns = int.Parse(Console.ReadLine());
            string[] patternsStr = new string[numberOfPatterns];
            for (int i = 0; i < numberOfPatterns; i++)
            {
                string line = Console.ReadLine();
                patternsStr[i] = line;
            }
            // List<int> currentPattern = new List<int>();
            for (int i = 0; i < patternsStr.Length; i++)
            {
                string[] spliterPattern = patternsStr[i].Split(splitSeparators, StringSplitOptions.RemoveEmptyEntries);
                int[] currentPattern = new int[spliterPattern.Length];
                for (int m = 0; m < spliterPattern.Length; m++)
                {
                    currentPattern[m] = int.Parse(spliterPattern[m]);
                }
                int curentSum = 0;
                int p = 0;
                bool flag = false;
                List<int> ps = new List<int>();
                bool hasAllNumberUsed = false;
                while ((p != 0) || (p != theVally.Length))
                {
                    for (int k = 0; k < currentPattern.Length; k++)
                    {
                         
                        curentSum += theVally[p];
                        p += currentPattern[k];
                        if (ps.Contains(p))
                        {
                          //if (ps.Count==theVally.Length)
                          //{
                          //    for (int pss = 0; pss < theVally.Length; pss++)
                          //    {
                          //        if (ps[pss] != theVally[pss])
                          //        {
                          //            break;
                          //        }
                          //        else
                          //        {
                          //            hasAllNumberUsed = true;
                          //        }
                          //    }
                          //}
                            hasAllNumberUsed = true;
                            break;
                        }
                        else
                        {
                            ps.Add(p);
                        }
                        
                        if ((p == 0) || (p > theVally.Length) || p < 0)
                        {
 
                            flag = true;
                            break;
                        }
                    }
                    if (flag == true||hasAllNumberUsed==true)
                    {
                        ps.Clear();
                        break;
                    }
                }
                if (curentSum > maxSum)
                {
                    maxSum = curentSum;
                }
            }
            Console.WriteLine(maxSum);
        }
    }
}