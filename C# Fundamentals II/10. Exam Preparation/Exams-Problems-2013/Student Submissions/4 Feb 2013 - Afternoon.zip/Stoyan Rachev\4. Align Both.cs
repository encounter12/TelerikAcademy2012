using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    public static String Justify(String s, Int32 count)
    {
        if (count <= 0)
            return s;

        Int32 middle = s.Length / 2;
        IDictionary<Int32, Int32> spaceOffsetsToParts = new Dictionary<Int32, Int32>();
        String[] parts = s.Split(' ');
        for (Int32 partIndex = 0, offset = 0; partIndex < parts.Length; partIndex++)
        {
            spaceOffsetsToParts.Add(offset, partIndex);
            offset += parts[partIndex].Length+2; // +1 to count space that was removed by Split
        }

        foreach (var pair in spaceOffsetsToParts.OrderBy(entry => Math.Abs(middle - entry.Key)))
        {
            count--;
            if (count < 0)
                break;
            parts[pair.Value] += ' ';
        }
        return String.Join(" ", parts).Trim();
        //return String.parts;
    }


    static void Main(String[] args)
    {

        int N = int.Parse(Console.ReadLine());
        int W = int.Parse(Console.ReadLine());

        List<string> words = new List<string>();

        for (int i = 1; i <= N; i++)
        {
            string line = Console.ReadLine();
            string[] wordLines=line.Split(new char[] { ' ' });
            for (int j = 0; j < wordLines.Length; j++)
            {
                if (!string.IsNullOrWhiteSpace(wordLines[j]))
                {
                    words.Add(wordLines[j]);
                    words.Add(" ");
                }
            }
        }

        words.RemoveAt(words.Count - 1);
        //end input 

        int countLetter = 0;
        int startIndex = 0;
        int endIndex = 0;
        List<string> output = new List<string>();

        StringBuilder tempLine = new StringBuilder();

        for (int i = 0; i < words.Count; i++)
        {
            countLetter += words[i].Length;
            if (countLetter > W)
            {
                for (int j = startIndex; j < i; j++)
                {
                    tempLine.Append(words[j]);
                }
                output.Add(tempLine.ToString());
                tempLine.Clear();
                countLetter = 0;
                startIndex = i;
                endIndex = i;
            }
        }

        for (int i = startIndex; i < words.Count; i++)
        {
            output.Add(words[i]);
        }

        for (int i = 0; i < output.Count; i++)
        {
            Console.WriteLine((Justify(output[i].Trim(), W)).Trim());
        }
    }
}