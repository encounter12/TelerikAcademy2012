using System;
using System.Collections.Generic;
using System.Numerics;

class ProvadiaNumbers
{
    
    
    static List<int> BaseConvert(BigInteger number)
    {
        int remainder = 0;
        List<int> result = new List<int>();

        while (number >= 1)
        {
            remainder = (int)(number % 256);
            number /= 256;
            result.Add(remainder);
        }
        result.Reverse();
        return result;
    }



    static void Main()
    {
        BigInteger number = BigInteger.Parse(Console.ReadLine());
        
        string[] array = new string[256];
        char ch = 'A';
        
        for (int k = 0; k < 26; k++)
        {
            array[k] = (ch++).ToString();
        }
        int index = 26;
        
        for (char i = 'a'; i <= 'i'; i++)
        {
            for (char j = 'A'; j <= 'Z'; j++)
            {
                if (i == 'i' && j > 'V')
                {
                    j = (char)91;
                    i = (char)106;

                }
                else
                {
                    array[index] = String.Concat(i, j);
                    index++;
                }
               
            }
        }

        List<int> converted =  BaseConvert(number);
        foreach (int num in converted)
        {
            Console.Write(array[num]);
        }
        

    }
}
