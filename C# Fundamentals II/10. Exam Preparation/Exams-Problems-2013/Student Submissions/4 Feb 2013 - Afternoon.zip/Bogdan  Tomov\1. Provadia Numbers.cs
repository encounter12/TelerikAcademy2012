using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace _1.Provadia
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] digits = new string[256];
            for (int i = 0, j = 65; i < 26; i++, j++)
            {
                digits[i] = ((char)j).ToString();
            }
            int z = 26;
            for (int q = 97; q < 106; q++)
            {
                for (int i = 65; z < digits.Length; i++, z++)
                {
                    if (i == 91)
                    {
                        break;
                    }
                    else
                    {
                        digits[z] = ((char)q).ToString() + ((char)i).ToString();
                    }
                }
            }
            BigInteger number = new BigInteger();
            number = BigInteger.Parse(Console.ReadLine());
            List<string> provadiaNumber = new List<string>();
            int buff = 0;
            if (number == 0)
            {
                Console.WriteLine("A");
            }
            else
            {
                while (number != 0)
                {
                    buff = (int)(number % 256);
                    if (number > 60000)
                    {
                        number = number / 256;
                        provadiaNumber.Add(digits[buff]);
                    }
                    else
                    {
                        number = (int)(number / 256);
                        provadiaNumber.Add(digits[buff]);
                    }

                }
                for (int i = provadiaNumber.Count - 1; i >= 0; i--)
                {
                    Console.Write(provadiaNumber[i]);
                }
            }
        }
    }
}
