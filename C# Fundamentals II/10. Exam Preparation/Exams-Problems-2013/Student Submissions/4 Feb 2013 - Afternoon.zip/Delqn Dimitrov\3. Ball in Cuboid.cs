using System;

class Class1
{
    string[][][] cube = new string[50][][];
    int[] prevh = new int[100000000], prevw = new int[100000000], prevd = new int[100000000];
    int w, h, d, bw, bd;

    void read()
    {

        string imp = Console.ReadLine();

        int i,j,k;
        for (i = 0; imp[i] != ' '; ++i)
        {

            w *= 10;
            w += imp[i] - '0';
        }
        ++i;
        for (; imp[i] != ' '; ++i)
        {

            h *= 10;
            h += imp[i] - '0';
        }
        for (; i < imp.Length; ++i)
        {

            d *= 10;
            d = +imp[i] - '0';
        }
        //Console.WriteLine("{0} {1} {2}", w, h, d);
        for (i = 0; i < h; ++i)
        {

            imp = Console.ReadLine();
            int m = 0;
            cube[i] = new string[50][];
            for (j = 0; j < d; ++j)
            {
                cube[i][j] = new string[50];
                for (k = 0; k < w; ++k)
                {

                    for (; m < imp.Length; ++m)
                    {

                        if (imp[m] == ' ' || imp[m] == '(' || imp[m] == ')' || imp[m] == '|') continue;
                        if (imp[m] == 'S')
                        {

                            cube[i][j][k] += 'S';
                            m++;
                            while (imp[m] != ')')
                            {

                                cube[i][j][k] += imp[m];
                                m++;
                            }
                            break;
                        }
                        if (imp[m] == 'E')
                        {

                            cube[i][j][k] += 'E';
                            m++;
                            break;
                        }
                        if (imp[m] == 'B')
                        {

                            cube[i][j][k] += 'B';
                            m++;
                            break;
                        }
                        if (imp[m] == 'T')
                        {
                            cube[i][j][k] += 'T';
                            m++;

                            while (imp[m] != ')')
                            {

                                cube[i][j][k] += imp[m];
                                m++;
                            }
                            break;
                        }
                    }
                }
            }
        }

        
        imp= Console.ReadLine();
        for( i=0; imp[i]!=' '; ++i ) {
            bw*=10;
            bw+=imp[i]-'0';
        } i++;
        for(; i<imp.Length; ++i ) {
            bd*=10;
            bd+=imp[i]-'0';
        }
        //Console.WriteLine("{0} {1}", bw, bd);

    }

    void solve()
    {

        int posh, posd, posw;
        posh = 0;
        posd = bd;
        posw = bw;
        int m = 0;

        while (posh < h && posh >= 0 && posd < d && posd >= 0 && posh < h && posh >= 0)
        {

            prevh[m] = posh;
            prevd[m] = posd;
            prevw[m] = posw;
            m++;
            if (cube[posh][posd][posw][0] == 'S')
            {

                if (cube[posh][posd][posw] == "S F")
                {

                    posh++;
                    posd--;
                    continue;
                }
                if (cube[posh][posd][posw] == "S B")
                {

                    posh++;
                    posd++;
                    continue;
                }
                if (cube[posh][posd][posw] == "S L")
                {

                    posw--;
                    posh++;
                    continue;
                }
                if (cube[posh][posd][posw] == "S R")
                {

                    posh++;
                    posw++;
                    continue;
                }
                if (cube[posh][posd][posw] == "S BR")
                {

                    posh++;
                    posd++;
                    posw++;
                    continue;
                }
                if (cube[posh][posd][posw] == "S BL")
                {

                    posh++;
                    posd++;
                    posw--;
                    continue;
                }
                if (cube[posh][posd][posw] == "S FL")
                {

                    posh++;
                    posd--;
                    posw--;
                    continue;
                }
                if (cube[posh][posd][posw] == "S FR")
                {

                    posh++;
                    posd--;
                    posw++;
                    continue;
                }
            }
            if (cube[posh][posd][posw][0] == 'E')
            {
                posh++;
                continue;
            }
            if (cube[posh][posd][posw][0] == 'B')
            {

                break;
            }
            if (cube[posh][posd][posw][0] == 'T')
            {
                int nd = 0, nw = 0;
                int j = 2;
                for (j = 2; cube[posh][posd][posw][j] != ' '; ++j)
                {

                    nw *= 10;
                    nw += cube[posh][posd][posw][j] - '0';
                }
                j++;
                for (; j < cube[posh][posd][posw].Length; ++j)
                {

                    nd *= 10;
                    nd += cube[posh][posd][posw][j] - '0';
                }
                //Console.WriteLine("Tel {0} {1}", nd, nw);
                posd = nd;
                posw = nw;
            }
        }
        int i;
        for (i = m-1; i >=0; --i)
        {

            if (prevh[i] >= 0 && prevh[i] < h && prevw[i] >= 0 && prevw[i] < w && prevd[i] >= 0 && prevd[i] < d) break;
        }
        if (cube[prevh[i]][prevd[i]][prevw[i]] == "B")
        {

            Console.WriteLine("No");
        }
        else Console.WriteLine("Yes");
        Console.WriteLine("{0} {1} {2}", prevw[i], prevh[i], prevd[i]);

    }

    static void Main()
    {

        Class1 c = new Class1();
        c.read();
        c.solve();
    }


}
