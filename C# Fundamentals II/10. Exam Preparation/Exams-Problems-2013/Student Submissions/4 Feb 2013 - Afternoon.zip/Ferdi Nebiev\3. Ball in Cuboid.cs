using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Cuboid
{
    class Program
    {
        struct Cube
        {
            public int w, h, d;
        }

        static void FillCube(int width, int height, int depth, string direction, Cube[, ,] theCube)
        {
            string[] goToCube = direction.Split(' ');
            int addW = 0, addH = 0, addD = 0;

            switch (goToCube[0][0])
            {
                case 'S':
                    {
                        if (goToCube.Length == 2)
                        {
                            addH = 1;
                            switch (goToCube[1])
                            {
                                case "L": addW = -1; addD = 0; break;
                                case "R": addW = 1; addD = 0; break;
                                case "F": addW = 0; addD = -1; break;
                                case "B": addW = 0; addD = 1; break;
                                case "FL": addW = -1; addD = -1; break;
                                case "FR": addW = 1; addD = -1; break;
                                case "BL": addW = -1; addD = 1; break;
                                case "BR": addW = 1; addD = 1; break;
                                default: Console.WriteLine("Slide error!"); break;
                            }
                        }
                        break;
                    }
                case 'T':
                    if (goToCube.Length == 3)
                    {
                        theCube[width, height, depth].h = height; theCube[width, height, depth].w = int.Parse(goToCube[1]); theCube[width, height, depth].d = int.Parse(goToCube[2]);
                    }
                    return;
                case 'E': addH = 1; break;
                case 'B': theCube[width, height, depth].h = -1; return;
                default: Console.WriteLine("Problem with reading direction"); break;
            }
            theCube[width, height, depth].w = width + addW;
            theCube[width, height, depth].h = height + addH;
            theCube[width, height, depth].d = depth + addD;
        }

        static Cube[, ,] ReadInput()
        {
            string[] dimensions = Console.ReadLine().Split(' ');
            int w = int.Parse(dimensions[0]);
            int h = int.Parse(dimensions[1]);
            int d = int.Parse(dimensions[2]);
            Cube[, ,] theCube = new Cube[w, h, d];
            //Console.WriteLine("{0} {1} {2}",w,h,d);

            for (int i = 0; i < h; i++)
            {
                string[] dSequence = Console.ReadLine().Split('|');
                for (int j = 0; j < dSequence.Length; j++)
                {
                    // Console.WriteLine(dSequence.Length);
                    MatchCollection wSequence = Regex.Matches(dSequence[j].Trim(), @"(?<=\()[^\(\)]*(?=\))");
                    for (int k = 0; k < wSequence.Count; k++)
                    {
                        //  Console.WriteLine(wSequence.Count);
                        FillCube(k, i, j, wSequence[k].ToString(), theCube);
                    }
                }
            }
            return theCube;
        }

        static void DropTheBall(int ballW, int ballD, Cube[, ,] theCube)
        {

           
                int currentH = 0, currentW = ballW, currentD = ballD;
                if (currentW < 0 || currentW >= theCube.GetLength(0)
                                || currentD < 0 || currentD >= theCube.GetLength(2)) return;

                while (true)
                {

                    int width = theCube[currentW, currentH, currentD].w;
                    int height = theCube[currentW, currentH, currentD].h;
                    int depth = theCube[currentW, currentH, currentD].d;
                    //Console.WriteLine("{0} {1} {2}", currentW,currentH,currentD);
                    try
                    {
                        if (theCube[currentW, currentH, currentD].h >= theCube.GetLength(1))
                        {
                            Console.WriteLine("Yes");
                            Console.WriteLine("{0} {1} {2}", currentW, currentH, currentD);
                            return;
                        }

                        if (height < 0 || width < 0 || width >= theCube.GetLength(0)
                            || depth < 0 || depth >= theCube.GetLength(2))
                        {
                            Console.WriteLine("No");
                            Console.WriteLine("{0} {1} {2}", currentW, currentH, currentD);
                            return;
                        }
                        currentW = width;
                        currentH = height;
                        currentD = depth;
                    }

                    catch (IndexOutOfRangeException e)
                    {
                        Console.WriteLine();
                    }
                }
        }
        static void Main(string[] args)
        {
            Cube[, ,] theCube = ReadInput();
            string[] ballCoord = Console.ReadLine().Split(' ');
            int ballW = int.Parse(ballCoord[0]);
            int ballD = int.Parse(ballCoord[1]);
            // Console.WriteLine("{0} {1} {2}", theCube[1,1, 0].w, theCube[1,1, 0].h, theCube[1,1, 0].d);

            DropTheBall(ballW, ballD, theCube);

        }
    }
}
