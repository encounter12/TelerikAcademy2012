using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlignBoth_4
{
    class AlignBoth_4
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter text: ");
            string inputText = Console.ReadLine();
            Console.WriteLine("Enter number of n -> 0 < n < 1000: ");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter number of w -> 0 < w < 10000: ");
            int w = int.Parse(Console.ReadLine());
           
            int end = w - 1;
            string symbolLength = inputText.Substring(0, end);
            int start = 0; 

                for (int j = 0; j <= n-1; j++)
                {
                    Console.WriteLine(inputText.Substring(start, end));
                    start = end + 1;
                }  