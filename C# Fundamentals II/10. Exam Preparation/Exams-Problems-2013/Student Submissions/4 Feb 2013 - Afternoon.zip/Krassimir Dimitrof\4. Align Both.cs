using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        
        public static string WordWrap(string text, int width)
        {
            int pos, next;
            StringBuilder sb = new StringBuilder();

            // Lucidity check
            if (width < 1)
                return text;

            // Parse each line of text
            for (pos = 0; pos < text.Length; pos = next)
            {
                // Find end of line
                int eol = text.IndexOf(Environment.NewLine, pos);
                if (eol == -1)
                    next = eol = text.Length;
                else
                    next = eol + Environment.NewLine.Length;

                // Copy this line of text, breaking into smaller lines as needed
                if (eol > pos)
                {
                    do
                    {
                        int len = eol - pos;
                        if (len > width)
                        len = BreakLine(text, pos, width);
                        sb.Append(text, pos, len);
                        sb.Append(" ");
                        sb.Append(Environment.NewLine);
                        // Trim whitespace following break
                        pos += len;
                        while (pos < eol && Char.IsWhiteSpace(text[pos]))
                            pos++;
                    } while (eol > pos);
                }
                else sb.Append(Environment.NewLine); // Empty line
            }
            return sb.ToString();
        }

        /// <summary>
        /// Locates position to break the given line so as to avoid
        /// breaking words.
        /// </summary>
        /// <param name="text">String that contains line of text</param>
        /// <param name="pos">Index where line of text starts</param>
        /// <param name="max">Maximum line length</param>
        /// <returns>The modified line length</returns>
        private static int BreakLine(string text, int pos, int width)
        {
            // Find last whitespace in line
            int i = width;
            while (i >= 0 && !Char.IsWhiteSpace(text[pos + i]))
                i--;

            // If no whitespace found, break at maximum length
            if (i < 0)
                return width;

            // Find start of whitespace
            while (i >= 0 && Char.IsWhiteSpace(text[pos + i]))
                i--;

            // Return length of text before whitespace
            return i + 1;
        }
        static void Main()
        {

            /// <summary>
            /// Word wraps the given text to fit within the specified width.
            /// </summary>
            int N = Int32.Parse(Console.ReadLine());
            if (N > 1000 || N < 0)
            {
                Console.WriteLine("Enter less lines");
            }
            int W = Int32.Parse(Console.ReadLine());

            if (W > 10000 || W < 0)
            {
                Console.WriteLine("Enter shorter words");
            }
            string [] text = new string [N];
            for (int i = 0; i < N; i++)
            {
                text[i] = Console.ReadLine();
            }
            foreach (var line in text)
            {
                Console.Write(WordWrap(line,W+5));
            }

        }
    }



}
