using System;
using System.Collections.Generic;
using System.Text;

class aLignBoth
{
    static void Main()
    {
        int inputTextLines = int.Parse(Console.ReadLine());
        int justifedWidth = int.Parse(Console.ReadLine());
        List<string> inputText = new List<string>();
        for (int i = 0; i < inputTextLines; i++)
        {
            inputText.Add(Console.ReadLine());
        }
        //inputText.Add("Beer beer beer Im going for");
        //inputText.Add("   a");
        //inputText.Add("beer");
        //inputText.Add("Beer beer beer Im gonna");
        //inputText.Add("drink some beer");
        //inputText.Add("I love drinkiiiiiiiiiing");
        //inputText.Add("beer");
        //inputText.Add("lovely");
        //inputText.Add("lovely");
        //inputText.Add("beer");
        List<string> wordList = new List<string>();
        foreach (var item in inputText)
        {
            string[] tempWordList = item.Split(' ');
            foreach (var tempWord in tempWordList)
            {
                if (tempWord!="")
                wordList.Add(tempWord.Trim());
            }
        }
        StringBuilder justifiedText = new StringBuilder();
        StringBuilder justifiedLine = new StringBuilder();
        List<string> lineWordList = new List<string>();
        int wordCounterIndex = 0;
        while (wordCounterIndex<wordList.Count)
        {
            justifiedLine.Clear();
            lineWordList.Clear();
            int lineLenght = wordList[wordCounterIndex].Length;
            lineWordList.Add(wordList[wordCounterIndex]);
            for (int i = wordCounterIndex+1; i < wordList.Count && (lineLenght + wordList[i].Length+1) <= justifedWidth; i++)
            {
                lineLenght += wordList[i].Length + 1;
                lineWordList.Add(wordList[i].PadLeft(wordList[i].Length+1,' '));
            }
            wordCounterIndex += lineWordList.Count;
            if (lineWordList.Count > 1)
            {
                int lineWordsCounter = 0;
                while (lineLenght < justifedWidth)
                {
                    if (lineWordsCounter < (lineWordList.Count - 1))
                    {
                        lineWordList[lineWordsCounter] = String.Format("{0}{1}", lineWordList[lineWordsCounter], " ");
                        lineLenght++;
                        lineWordsCounter++;
                    }
                    else
                    {
                        lineWordsCounter = 0;
                    }
                }
            }
            foreach (var item in lineWordList)
            {
                justifiedLine.Append(item);
            }
            justifiedLine.Append("\n");
            justifiedText.Append(justifiedLine);
        }
        Console.WriteLine(justifiedText);
    }
}