using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;


namespace ProvadiaNumbers
{
    class Program
    {
        static string ReverseString(string s)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = s.Length - 1; i >= 0; i = i - 2)
            {
                string two = s[i - 1].ToString() + s[i].ToString();
                sb.Append(two);
            }
            return sb.ToString();
        }
        static void Main(string[] args)
        {

            BigInteger number = BigInteger.Parse(Console.ReadLine());
            string[] letters = new string[256];
            string lettersUpper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string lettersLower = " " + lettersUpper.ToLower();
            for (int i = 0; i < 256; i++)
            {
                letters[i]=lettersLower[i/26].ToString()+lettersUpper[i%26].ToString();
               // Console.WriteLine(letters[i]);
            }
            StringBuilder sb = new StringBuilder();
            BigInteger index = 0;
            if (number == 0) Console.WriteLine("A");
            else
            {
                while (number > 0)
                {
                    index = number % 256;
                    sb.Append(letters[(int)index]);
                    number = number / 256;
                }
                string almostReady = ReverseString(sb.ToString());
                while (true)
                {
                    int i = almostReady.IndexOf(' ');
                    if (i < 0) break;
                    almostReady = almostReady.Remove(i, 1);
                }
                Console.WriteLine(almostReady);
            }
        }
    }
}
