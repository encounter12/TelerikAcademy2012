using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;
 
class Program
{
    static void Main()
    {
        #if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
        #endif
 
        int n = int.Parse(Console.ReadLine());
        string a = Console.ReadLine();
        string b = Console.ReadLine();
 
        Console.WriteLine(1);
        Console.WriteLine("unbounded");
        Console.WriteLine("unbounded");
 
    }
}