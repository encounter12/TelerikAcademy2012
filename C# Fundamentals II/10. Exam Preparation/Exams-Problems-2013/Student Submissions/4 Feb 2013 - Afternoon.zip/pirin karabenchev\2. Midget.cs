using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Midget
{
    static int[] valley;

    static void Main()
    {
        string input = Console.ReadLine();
        string[] inputs = input.Split(',');
        valley = new int[inputs.Length];
        
        for (int i = 0; i < inputs.Length; i++)
        {
            valley[i] = int.Parse(inputs[i]);
        }

        int M = int.Parse(Console.ReadLine());
        int[][] patterns = new int[M][];

        for (int m = 0; m < M; m++)
        {
            inputs = Console.ReadLine().Split(',');
            patterns[m] = new int[inputs.Length];
            for (int j = 0; j < inputs.Length; j++)
            {
                patterns[m][j] = int.Parse(inputs[j]);
            }
        }

        int maxCoinsCollected = int.MinValue;

        for (int m = 0; m < M; m++)
        {
            int currentCoinsCollected = CollectCoins(valley,patterns[m]);
            if (currentCoinsCollected > maxCoinsCollected)
            {
                maxCoinsCollected = currentCoinsCollected;
            }
        }

        Console.WriteLine(maxCoinsCollected);
    }

    private static int CollectCoins(int[] valley, int[] pattern)
    {
        int coins = 0;
        int pos = 0;
        int patternIndex = 0;
        bool[] isVisited = new bool[valley.Length];
        while (pos > -1 && pos < valley.Length && !isVisited[pos])
        {
            isVisited[pos] = true;
            coins += valley[pos];
            pos += pattern[patternIndex++ % pattern.Length];
        }
        return coins;
    }
    
}