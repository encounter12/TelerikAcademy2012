using System;
using System.Collections.Generic;
using System.Text;
class MidGet
{
    static void Main()
    {
        char[] separators = new char[] { ' ', ',', '.' };
        string exampleArrStr = Console.ReadLine();
        int indexArrLenght = int.Parse(Console.ReadLine());
        string indexArrStr = Console.ReadLine();
        string[] exampleArrChar = exampleArrStr.Split(separators);
        string[] IndexArrChar = indexArrStr.Split(separators);
        int[] exampleArr = new int[50];
        int[] indexArr = new int[indexArrLenght];
        int result = 0;
        int indexArrCount = 0;
        int indexExampleArr = 0;
        int tempRes=0;
        int starIndex = 0;
        for (int i = 0; i < exampleArr.Length; i++)
        {
            exampleArr[i] = int.Parse(exampleArrChar[i]);
        }
        for (int i = 0; i < indexArr.Length; i++)
        {
            indexArr[i]=int.Parse(IndexArrChar[i]);
        }
        do
        {
            result += exampleArr[indexExampleArr];
            indexExampleArr += indexArr[indexArrCount];
            indexArrCount++;
            
            if (indexArrCount == (indexArr.Length ))
            {
                if (starIndex==indexExampleArr)
                {
                    break; 
                }
                starIndex = indexExampleArr;
                indexArrCount = 0;
            }
            
        } while ((indexExampleArr > 0) & (indexExampleArr < exampleArr.Length));
        Console.WriteLine(result);
    }
}
