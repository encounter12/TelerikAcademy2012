using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThirdTry
{
    class Program
    {
        static void Main()
        {
            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            int width = int.Parse(sizes[0]);
            int height = int.Parse(sizes[1]);
            int depth = int.Parse(sizes[2]);
            string[, ,] cuboid = new string[width, height, depth];

            // Read the cuboid data
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] sequences = line.Split('|');
                for (int d = 0; d < depth; d++)
                {
                    string[] numbers = sequences[d].Split(
                        new char[] {')' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < width; w++)
                    {
                        string cubeValue = numbers[w];
                        cuboid[w, h, d] = cubeValue.Trim('(', ' ');
                    }
                }
            }
            string coordinates = Console.ReadLine();
            string[] crdts = coordinates.Split();
            int ballWidth = int.Parse(crdts[0]);
            int ballDebth = int.Parse(crdts[1]);

            MoveBall(cuboid, ballWidth, 0, ballDebth, width - 1, height - 1, depth - 1);

            //for (int h = 0; h < height; h++)
            //{
            //    for (int d = 0; d < depth; d++)
            //    {
            //        for (int w = 0; w < width; w++)
            //        {
            //            Console.Write(cuboid[w, h, d]);
            //        }
            //        Console.Write("|");
            //    }
            //    Console.WriteLine();
            //}
        }

        static void MoveBall(string[,,] cuboid, int width, int height, int debth, int staticWidth, int staticHeight, int staticDepth)
        {
            while (true)
            {
                
                if (cuboid[width, height, debth] == "S L")
                {
                    
                    if (height >= staticHeight || width > staticWidth || debth > staticDepth || width <= 0 || debth < 0)
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", width, height, debth);
                        break;
                    }
                    height++;
                    width--;
                }
                if (cuboid[width, height, debth] == "S R")
                {
                    
                    if (height >= staticHeight || width >= staticWidth || debth >= staticDepth || width <= 0 || debth <= 0)
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", width, height, debth);
                        break;
                    }
                    height++;
                    width++;
                }
                if (cuboid[width, height, debth] == "S F")
                {
                    
                    if (height >= staticHeight || width >= staticWidth || debth >= staticDepth || width <= 0 || debth <= 0)
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", width, height, debth);
                        break;
                    }
                    height++;
                    debth--;
                }
                if (cuboid[width, height, debth] == "S B")
                {
                    if (height >= staticHeight || width > staticWidth || debth >= staticDepth || width < 0 || debth < 0)
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", width, height, debth);
                        break;
                    }
                    height++;
                    debth++;
                }
                if (cuboid[width, height, debth] == "S FL")
                {
                    if (height >= staticHeight || width > staticWidth || debth > staticDepth || width <= 0 || debth <= 0)
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", width, height, debth);
                        break;
                    }
                    height++;
                    width--;
                    debth--;
                }
                if (cuboid[width, height, debth] == "S BL")
                {
                    if (height >= staticHeight || width > staticWidth || debth >= staticDepth || width <= 0 || debth < 0)
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", width, height, debth);
                        break;
                    }
                    height++;
                    width--;
                    debth++;
                }
                if (cuboid[width, height, debth] == "S FR")
                {
                    if (height >= staticHeight || width >= staticWidth || debth > staticDepth || width < 0 || debth <= 0)
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", width, height, debth);
                        break;
                    }
                    debth--;
                    width++;
                    height++;
                }
                if (cuboid[width, height, debth] == "S BR")
                {
                    if (height >= staticHeight || width >= staticWidth || debth >= staticDepth || width < 0 || debth < 0)
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", width, height, debth);
                        break;
                    }
                    height++;
                    width++;
                    debth++;
                }
                if (cuboid[width, height, debth] == "B")
                {
                    Console.WriteLine("No");
                    Console.WriteLine("{0} {1} {2}", width, height, debth);
                    break;
                }
                if (cuboid[width, height, debth] == "E")
                {
                    if (height >= staticHeight || width > staticWidth || debth > staticDepth || width < 0 || debth < 0)
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", width, height, debth);
                        break;
                    }
                    height++;
                }
                else
                {
                    string[] teleport = cuboid[width, height, debth].Split(new char[] {' '}, StringSplitOptions.RemoveEmptyEntries);
                    if (teleport[0] != "T")
                    {
                        continue;
                    }
                    else
                    {
                        width = int.Parse(teleport[1]);
                        debth = int.Parse(teleport[2]);
                    }
                    
                }

            }
        }
    }
}
