using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace _04.AlignBoth
{
    class Program
    {
        static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());
            int maxLength = int.Parse(Console.ReadLine());

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < lines; i++)
            {
                sb.AppendLine(Console.ReadLine());
            }

            string text = sb.ToString();

            string pattern = @"\s+";
            string newText = Regex.Replace(text, pattern, " ");

            
            char nextChar = newText[0];
            int start = 0;
            int leftSpace = 0;
            int totalSpace = 0;

            StringBuilder rebuild = new StringBuilder();
            for (int i = 0, multiply = 1; i < newText.Length; i++)
            {
                nextChar = newText[i];

                if (i == (multiply*maxLength) - 1)
                {
                    rebuild.Append("\r\n");
                    multiply++;
                    continue;
                }
                if (newText[i] == ' ')
                {
                    if (i < newText.Length - multiply*maxLength && newText[multiply*maxLength] != '\r')
                    {
                        rebuild.Append(nextChar);
                    }
                }
                else
                {
                    rebuild.Append(nextChar);
                }

                
                               
	
            }

            Console.WriteLine(rebuild.ToString());
        }
    }
}
