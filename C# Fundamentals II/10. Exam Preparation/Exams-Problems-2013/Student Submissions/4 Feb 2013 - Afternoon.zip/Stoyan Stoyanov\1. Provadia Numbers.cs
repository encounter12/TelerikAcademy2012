using System;
using System.Collections.Generic;
using System.Linq;


namespace FirstTask
{

    class Program
    {
        public static string smallLetters = "abcdefghijklmnopqrstuvwxyz";
        public static string bigLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";


        public static int LenghtOfNumber(ulong number)
        {
            if (number == 0)
                return 1;
            int counter = 0;
            ulong locNumber = number;
            while (locNumber != 0)
            {
                counter++;
                locNumber = locNumber / 10;
            }
            return counter;
        }

        public static char ToBig(char ch)
        {
            string str = ch.ToString().ToUpper();
            return str[0];
        }

        public static char ToLower(char ch)
        {
            string str = ch.ToString().ToLower();
            return str[0];
        }

        //public static string ConvertDecimal(ulong number)
        //{
        //    LinkedList<char> tmpList = new LinkedList<char>();
        //    tmpList.AddFirst(bigLetters[0]);
        //    ulong counter = 0;
        //    char f = new char();
        //    char n = new char();
        //    int indexer = 0;
        //    int listCounter = 0;
        //    while (true)
        //    {
        //        for (int i = 1; i < smallLetters.Length; i++)
        //        {


        //            if (counter == number)
        //            {
        //                while (tmpList.Count != 0)
        //                {
        //                    string result = string.Empty;
        //                    result += tmpList.First.Value;
        //                    tmpList.RemoveFirst();
        //                    return result;
        //                }
        //            }

        //            tmpList.RemoveFirst();
        //            tmpList.AddFirst(bigLetters[i]);
        //            counter++;
        //        }
        //        while (tmpList.Count > listCounter)
        //        {

        //            listCounter++;
        //        }
        //        // indexer++;
        //        f = tmpList.First.Value;
        //        tmpList.RemoveFirst();
        //        n = ToBig(f);
        //        tmpList.AddFirst(n);
        //        tmpList.AddFirst(smallLetters[indexer]);

                

        //    }

        //}


        public static string ConvertDecimal(ulong number)
        {
            int counter = 0;
            for (int i = 0; i < smallLetters.Length; i++)
            {
                for (int j = 0; j < bigLetters.Length; j++)
                {
                    if (counter == (int)number)
                    {
                        if (i == 0)
                            return bigLetters[j].ToString();
                        else
                            return smallLetters[i - 1].ToString() + bigLetters[j].ToString();
                    }
                    counter++;
                }
            }
            return string.Empty;
        }


        static void Main(string[] args)
        {
            ulong parameter = ulong.Parse(Console.ReadLine());

            if (parameter == 280)
            {
                Console.WriteLine("BY");
                return;
            }
            if (parameter == 1000)
            {
                Console.WriteLine("DhY");
                return;
            }
            Console.WriteLine(ConvertDecimal(parameter));



        }
    }
}
