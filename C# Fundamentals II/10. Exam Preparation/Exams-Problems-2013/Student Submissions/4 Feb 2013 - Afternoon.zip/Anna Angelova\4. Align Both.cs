using System;
using System.Text.RegularExpressions;
using System.Linq;

class Program
{
    public static string TheLongestWord(string[] words)
    {
        return words.OrderBy(x => x.Length).Last();
    }

    public static string AddWhitespace(string text, int width)
    {
        string result = "";
        string[] lines = text.Split('\n');
        for (int i = 0; i < lines.Length; i++)
        {
            if (lines[i].Length < width)
            {
                string[] words = lines[i].Split(new string[]{" "}, StringSplitOptions.RemoveEmptyEntries);
                int ws = width - lines[i].Length;
                string line = "";
                int ost = ws % (words.Length - 1);
                int wsBet =( ws / (words.Length - 1))+1;
                int j =0;
                for (; j < words.Length ; j++)
                {
                    if (i != lines.Length - 1)
                    {
                        if (ost != -1)
                        {
                            line += words[j] + new String(' ', wsBet + 1);
                            ost--;
                        }
                        else
                        {
                            if (j != words.Length - 1)
                            {
                                line += words[j] + new String(' ', wsBet);
                            }
                            else
                            {
                                line += words[j];
                            }
                        }
                    }
                    else
                    {
                        if (ost != 0)
                        {
                            line += words[j] + new String(' ', wsBet + 1);
                            ost--;
                        }
                        else
                        {
                            if (j != words.Length - 1)
                            {
                                line += words[j] + new String(' ', wsBet);
                            }
                            else
                            {
                                line += words[j];
                            }
                        }
                    }
                }
                if (i != lines.Length - 1)
                {
                    result += line + "\n";
                }
                else
                {
                    result += line;
                }
            }
            else
            {
                result += lines[i];
            }
        }
        return result;
    }
    public static string Aling(string text, int lines, int width)
    {
        string result = "";
        string[] words = text.Split(new char[]{' '}, StringSplitOptions.RemoveEmptyEntries);
        int longestWidth = TheLongestWord(words).Length;
        if (width < longestWidth) width = TheLongestWord(words).Length;
        int i = 0;
        while (lines != 0)
        {
            int tempLength = 0;
            string line = "";
            for (; i < words.Length; i++)
            {
                tempLength += words[i].Length + 1;
                if (tempLength < width)
                {                    
                    line += words[i] + " ";                    
                }
                else if (i != words.Length - 1)
                {
                    result+=line+"\n";
                    lines--;
                    break;
                }
                else
                {
                    result+=line + words[i];
                    lines--;
                    break;
                }
            }
        }
        return result;
    }
    public static void Main()
    {
        int lines = int.Parse(Console.ReadLine());
        int width = int.Parse(Console.ReadLine());
        int line = 0;
        string text = "";
        while (line != lines)
        {
            if (line == lines - 1) text += Console.ReadLine();
            else text += Console.ReadLine() + " ";
            line++;
        }
        Console.WriteLine(AddWhitespace(Aling(text, lines, width), width));
    }
}
