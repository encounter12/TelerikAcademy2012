using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlignBoth
{
    class Program
    {
        static void Main(string[] args)
        {
            int numbeOfLines = int.Parse(Console.ReadLine());
            int numberOfSymbolsJustified = int.Parse(Console.ReadLine());
            StringBuilder text = new StringBuilder();
            for (int i = 0; i < numbeOfLines; i++)
            {
                text.Append(Console.ReadLine() + " ");
            }
            string[] words = text.ToString().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            text.Clear();
            foreach (var item in words)
            {
                text.Append(item + " ");
            }
            for (int i = 20; i < text.Length; i+=20)
            {
                if (text[i]==' ')
                {
                    text[i] = '\n';
                }
                else
                {
                    text[text.ToString().LastIndexOf(' ',i)]='\n';
                }
            }
            string[] rows=text.ToString().Split('\n');
            text.Clear();
            for (int i = 0; i < rows.Length; i++)
            {
                    int start = 0;
                    text.Append(rows[i]);
                    int counter = 0;
                    while (true)
                    {
                        counter++;
                        if (start>text.Length-1)
                        {
                            start = 0;
                        }
                       int next=text.ToString().IndexOf(' ',start);
                       if (next==-1)
                       {
                           next = text.ToString().IndexOf(' ')+counter;
                       }
                       if (text.Length < numberOfSymbolsJustified)
                       {
                           text.Insert(next, ' ');
                           start = next + 2;
                       }
                       else
                       {
                           rows[i] = text.ToString();
                           text.Clear();
                           break;
                       }
                    }
                    
                
            }
            foreach (var item in rows)
            {
                Console.WriteLine(item);
            }
            

        }
    }
}
