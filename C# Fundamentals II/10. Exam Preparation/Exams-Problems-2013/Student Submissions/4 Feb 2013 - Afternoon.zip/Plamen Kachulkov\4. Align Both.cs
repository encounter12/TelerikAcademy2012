using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace _4.AlignBoth
{
    public static class Program
    {

        static void Main()
        {
            //A word is separated from other words by at least one whitespace (or new line)
            //Each line must have a fixed width W (at least the longest word in the text
            //each line must have at least one word, and each word can be on exactly one line
            //If a line contains exactly one word, there must be no whitespaces after it - this
            //is the only case in which the line can have _a width less than W_
            //We will call the whitespaces between two consecutive words "gasps"
            //One gap can have at most 1 whitespace more than any other gap
            //One gap cannot have more whitespaces than any other gap to its left
                //so, a gap can have a whitespace more than another gap "on its right", but
                //not vice versa
            //Justification happens by fitting as much words as possible on one line, and continuing with the next

            //The first line is formed by taking all words that can fit on that line from the next
            //The next line is formed by taking all words that can fit on that line 
            //from the remainning text, and so on
            //The order of the ltters in the text (excluding whitespaces) must remain the same

            int N = int.Parse(Console.ReadLine()); //total number of lines in text
            int W = int.Parse(Console.ReadLine()); //the number of symbols in each justified line

            string jorostr = null;
            for (int i = 0; i < N; i++)
            {
                jorostr += Console.ReadLine() + "\n";
            }
            //jorostr = "We happy few     we band\nof brothers for he who sheds\nhis blood\nwith\nme shall be my brother";



            string al = jorostr.Replace("\n", " ");

            string cleanstr = "";
            Regex r = new Regex(@"(\w+)", RegexOptions.IgnoreCase);
            foreach(Match m in r.Matches(al))
            {
                cleanstr += m.Groups[0].Value.ToString() + " ";
            }
            //Console.WriteLine(cleanstr);

            string newstr = "";
            int curr = -1;
            int currEnd = W;
            string prenos = "";
            int p = 0;
            for (int i = 0; i < N; i++)
            {
                for (int j = curr + 1; j < currEnd; j++)
                {
                    p = 0;
                    if (j == currEnd - 1 && cleanstr[j] != ' ' && i != N-1)
                    {
                        //prenasqne
                        p = j;
                        while (cleanstr[p] != ' ')
                        {
                            p--;
                        }
                        curr = p;
                        newstr = RemoveWord(newstr, p);
                    }
                    else if (j < N*W)
                    {
                        newstr += cleanstr[j];
                        curr = j;
                    }

                }
                currEnd = (curr + W);
                newstr += "\n";
            }

            string[] newstr2 = newstr.Split('\n');
            string[] newstr3 = (string[])newstr2.Clone();
            for (int i = 0; i < newstr2.Length-1; i++)
            {
                    int l = newstr2[i].Length;
                    int spaceswehave = W - l;
                    //Console.WriteLine(spaceswehave);

                    while (spaceswehave > 0)
                    {
                        char[] chararr = newstr2[i].ToCharArray();

                        int currPos = 0;

                        for (int j = 0; j < chararr.Length - 1; j++)
                        {
                            if (chararr[j] == ' ' && spaceswehave > 0 && j > currPos)
                            {
                                newstr2[i] = InsertChar(chararr, j);
                                chararr = newstr2[i].ToCharArray();
                                //Console.WriteLine(newstr2[i]);
                                spaceswehave--;
                                currPos = j + 1;
                            }
                        }
                    }
                    
            }

            string jed = "";
            //Console.WriteLine();
            for (int i = 0; i < newstr2.Length; i++)
            {
                jed += newstr2[i];
                if (i < newstr2.Length - 1) jed += "\n";
            }
            Console.Write(jed);
        }

        private static string InsertChar(char[] cinputarr, int j)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < j; i++) sb.Append(cinputarr[i]);
            sb.Append(" ");
            for (int i = j; i < cinputarr.Length; i++) sb.Append(cinputarr[i]);
            return sb.ToString();
        }

        private static string RemoveWord(string s, int startPos)
        {
            string newstring = s.Substring(0, startPos);
            return newstring;
        }


    }
}
