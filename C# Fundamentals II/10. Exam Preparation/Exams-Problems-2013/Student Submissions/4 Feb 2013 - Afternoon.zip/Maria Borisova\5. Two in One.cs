using System;
using System.Collections.Generic;

namespace Proble5_TwoInOne
{
    class Program
    {
        static void IsBounded(string command)
        {
            bool bounded = false;
            if (command.Length == 1)
            {
                if (command == "L" || command == "R")
                {
                    bounded = true;
                }
            }
            Console.WriteLine(bounded ? "bounded" : "unbounded");
        }
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            string command1 = Console.ReadLine();
            string command2 = Console.ReadLine();
            int count = 0;
            List<int> lapms = new List<int>(); 
            for (int i = 1; i <= N; i++)
            {
                lapms.Add(i);
            }

            for (int j = 0; j < N; j++)
            {
                count = j+1;
                for (int i = 0; i < lapms.Count; i += count)
                {
                    if (lapms.Count == 1)
                    {
                        break;
                    }
                    lapms.RemoveAt(i);    
                }
            }
            Console.WriteLine(lapms[0]);

            IsBounded(command1);
            IsBounded(command2);
        }
    }
}
