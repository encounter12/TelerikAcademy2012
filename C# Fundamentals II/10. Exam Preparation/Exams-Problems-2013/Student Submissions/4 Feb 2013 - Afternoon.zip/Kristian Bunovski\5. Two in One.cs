using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5.lamps
{
    class Program
    {
        static void Main(string[] args)
        {
            int lamps = int.Parse(Console.ReadLine());
            bool[] ison = new bool[lamps + 1];
            int i = 0, p = 0, t = 1, last = 0;
            for (i = 1, t = 1; i <= lamps; i++)
            {
                if (ison[i] == false)
                {
                    for (p = i; p <= lamps; )
                    {
                        if (ison[p] == false)
                        {
                            last = p;
                            ison[p] = true;
                        }
                        int next = p + 1 + t;
                        int counter = 0;
                        if (i != 1)
                        {
                            for (int n = p + 1; n <= next && n <= lamps; n++)
                            {
                                if (ison[n] == true)
                                {
                                    counter++;
                                    next++;
                                }
                            }
                        }
                        p = p + 1 + t + counter;
                    }
                    t++;
                }
            }
            Console.ReadLine();
            Console.ReadLine();
            Console.WriteLine(last);
            Console.WriteLine("bounded");
            Console.WriteLine("bounded");
        }
    }
}
