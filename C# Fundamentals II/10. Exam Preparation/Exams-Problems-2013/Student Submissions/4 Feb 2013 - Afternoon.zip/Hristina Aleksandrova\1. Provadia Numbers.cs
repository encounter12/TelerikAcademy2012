using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace hyt
{
    class Program
    {
        static void Main(string[] args)
        {
            int decNumber = int.Parse(Console.ReadLine());
            string[] smallLetters = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
            string result = " ";
            string[] upperLetters = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
            for (int i = 0; i < upperLetters.Length - 1; i++)
            {
                for (int j = 0; j < smallLetters.Length - 1; j++)
                {


                    switch (decNumber)
                    {
                        case 0: result = "A";
                            break;
                        case 1: result = "B";
                            break;
                        case 2: result = "C";
                            break;
                        case 3: result = "D";
                            break;
                        case 4: result = "E";
                            break;
                        case 5: result = "F";
                            break;
                        case 6: result = "G";
                            break;
                        case 7: result = "H";
                            break;
                        case 8: result = "I";
                            break;
                        case 9: result = "J";
                            break;
                        case 10: result = "K";
                            break;
                        case 11: result = "L";
                            break;
                        case 12: result = "M";
                            break;
                        case 13: result = "N";
                            break;
                        case 14: result = "O";
                            break;
                        case 15: result = "P";
                            break;
                        case 16: result = "Q";
                            break;
                        case 17: result = "R";
                            break;
                        case 18: result = "S";
                            break;
                        case 19: result = "T";
                            break;
                        case 20: result = "U";
                            break;
                        case 21: result = "V";
                            break;
                        case 22: result = "W";
                            break;
                        case 23: result = "X";
                            break;
                        case 24: result = "Y";
                            break;
                        case 25: result = "Z";
                            break;





                        case 26: result = "aA";
                            break;
                        case 27: result = "aB";
                            break;
                        case 28: result = "aC";
                            break;
                        case 29: result = "aD";
                            break;
                        case 30: result = "aE";
                            break;
                        case 31: result = "aF";
                            break;
                        case 32: result = "aG";
                            break;
                        case 33: result = "aH";
                            break;
                        case 34: result = "aI";
                            break;
                        case 35: result = "aJ";
                            break;
                        case 36: result = "aK";
                            break;
                        case 37: result = "aL";
                            break;
                        case 38: result = "aM";
                            break;
                        case 39: result = "aN";
                            break;
                        case 40: result = "aO";
                            break;
                        case 41: result = "aP";
                            break;
                        case 42: result = "aQ";
                            break;
                        case 43: result = "aR";
                            break;
                        case 44: result = "aS";
                            break;
                        case 45: result = "aT";
                            break;
                        case 46: result = "aU";
                            break;
                        case 47: result = "aV";
                            break;
                        case 48: result = "aW";
                            break;
                        case 49: result = "aX";
                            break;
                        case 50: result = "aY";
                            break;
                        case 51: result = "aZ";
                            break;
                        case 52: result = "bA";
                            break;
                        case 53: result = "bB";
                            break;
                        case 54: result = "bC";
                            break;
                        case 55: result = "bD";
                            break;
                        case 56: result = "bE";
                            break;
                        case 57: result = "bF";
                            break;
                        case 58: result = "bG";
                            break;
                        case 59: result = "bH";
                            break;
                        case 60: result = "bI";
                            break;
                        case 61: result = "bJ";
                            break;
                        case 62: result = "bK";
                            break;
                        case 63: result = "bL";
                            break;
                        case 64: result = "bM";
                            break;
                        case 65: result = "bN";
                            break;
                        case 66: result = "bO";
                            break;
                        case 67: result = "bP";
                            break;
                        case 68: result = "bQ";
                            break;
                        case 69: result = "bR";
                            break;
                        case 70: result = "bS";
                            break;
                        case 71: result = "bT";
                            break;
                        case 72: result = "bU";
                            break;
                        case 73: result = "bV";
                            break;
                        case 74: result = "bW";
                            break;
                        case 75: result = "bX";
                            break;
                        case 76: result = "bY";
                            break;
                        case 77: result = "bZ";
                            break;

                        case 78: result = "cA";
                            break;
                        case 79: result = "cB";
                            break;
                        case 80: result = "cC";
                            break;
                        case 81: result = "cD";
                            break;
                        case 82: result = "cE";
                            break;
                        case 83: result = "cF";
                            break;
                        case 84: result = "cG";
                            break;
                        case 85: result = "cH";
                            break;
                        case 86: result = "cI";
                            break;
                        case 87: result = "cJ";
                            break;
                        case 88: result = "cK";
                            break;
                        case 89: result = "cL";
                            break;
                        case 90: result = "cM";
                            break;
                        case 91: result = "cN";
                            break;
                        case 92: result = "cO";
                            break;
                        case 93: result = "cP";
                            break;
                        case 94: result = "cQ";
                            break;
                        case 95: result = "cR";
                            break;
                        case 96: result = "cS";
                            break;
                        case 97: result = "cT";
                            break;
                        case 98: result = "cU";
                            break;
                        case 99: result = "cV";
                            break;
                        case 100: result = "cW";
                            break;
                        case 101: result = "cX";
                            break;
                        case 102: result = "cY";
                            break;
                        case 103: result = "cZ";
                            break;

                        default: ;
                            break;


                    }
                    
                    

                }

            }
            Console.WriteLine(result);

        }

    }
}


