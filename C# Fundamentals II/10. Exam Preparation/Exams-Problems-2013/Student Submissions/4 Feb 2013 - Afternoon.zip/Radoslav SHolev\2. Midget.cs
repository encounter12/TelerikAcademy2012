using System;
using System.Collections.Generic;

class Program
{
    static long mostCoins = long.MinValue;
    static int[] ExtractNumbersArr(string text)
    {
        string[] textSpl = text.Split(',');
        int[] numbers = new int[textSpl.Length];
        for (int i = 0; i < textSpl.Length; i++)
        {
            numbers[i] = int.Parse(textSpl[i]);
        }
        return numbers;
    }
    static List<int> ExtractNumbersList(string text)
    {
        string[] textSpl = text.Split(',');
        List<int> numbers = new List<int>();
        for (int i = 0; i < textSpl.Length; i++)
        {
            numbers.Add(int.Parse(textSpl[i]));
        }
        return numbers;
    }
    static void RunPattern(int[] coins, List<int> pattern)
    {
        int coinsCollected = 0;
        bool[] path = new bool[coins.Length];
        int currElementIndex = 0;
        int patternIndexer=0;
        while (true)
        {
            if (currElementIndex >= coins.Length || currElementIndex < 0)
            {
                break;
            }
            if (path[currElementIndex] == true)
            {
                break;
            }
            if (patternIndexer == pattern.Count)
            {
                patternIndexer = 0;
            }
            coinsCollected += coins[currElementIndex];
            path[currElementIndex] = true;
            currElementIndex += pattern[patternIndexer];
            patternIndexer++;
        }
        if (coinsCollected > mostCoins)
        {
            mostCoins = coinsCollected;
        }
    }
    static void Main()
    {
        string valleyStr = Console.ReadLine();
        int[] coins = ExtractNumbersArr(valleyStr);
        int M = int.Parse(Console.ReadLine());
        List<int>[] patterns=new List<int>[M];
        for (int i = 0; i < M; i++)
        {
            patterns[i] = ExtractNumbersList(Console.ReadLine());
        }
        for (int i = 0; i < patterns.Length; i++)
        {
            RunPattern(coins, patterns[i]);
        }
        Console.WriteLine(mostCoins);
    }
}
