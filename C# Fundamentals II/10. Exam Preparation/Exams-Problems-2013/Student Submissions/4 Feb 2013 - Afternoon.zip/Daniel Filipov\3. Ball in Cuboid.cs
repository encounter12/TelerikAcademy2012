using System;
using System.Text;
using System.Collections.Generic;
class ball
{
	public static void Main (string[] args)
	{
		string[] temp = Console.ReadLine ().Split (' ');
		List<char> index = new List<char>{'S','B','E','T','L','R','F'};
		int width = int.Parse (temp [0]);
		int heigth = int.Parse (temp [1]);
		int depth = int.Parse (temp [2]);
		string[,,] cuboid = new string[width, heigth, depth];
		string[] d;
		string[] w;
		StringBuilder comand = new StringBuilder ();
		for (int i=0; i<heigth; i++) {
			d = Console.ReadLine ().Split ('|');
			for (int j=0; j<d.GetLength(0); j++) {
				w = d [j].Split (')');
				for (int k=0; k<w.GetLength(0)-1; k++) {
					for (int l=0; l<w[k].Length; l++)
					{
						if (index.Contains (w [k] [l]))
						{
							if(w [k] [l]=='T')
							{
								while(l<w[k].Length)
								{
									comand.Append (w [k] [l]);
									l++;
								}
							}
							else comand.Append (w [k] [l]);
						}
					}
					cuboid [k, i, j] = comand.ToString ();
					comand.Clear ();
				}
			}

		}
		string[] coor = Console.ReadLine ().Split (' ');
		int ballW = int.Parse (coor [0]);
		int ballD = int.Parse (coor [1]);
		int ballH = 0;
		while ((ballH<heigth)&&(ballW>=0)&&(ballW<width)&&(ballD>=0)&&(ballD<depth)) {
			int p=0;
			switch(cuboid[ballW,ballH,ballD][p])
			{
			case 'S':
				p++;
				switch(cuboid[ballW,ballH,ballD][p])
				{
				case 'B':
					ballD++;
					if(ballD==depth)
					{
						Console.WriteLine ("No");
						Console.WriteLine ("{0} {1} {2}",ballW,ballH,ballD-1);
						return;
					}
					if(p+1<cuboid[ballW,ballH,ballD-1].Length)
					{
						if(cuboid[ballW,ballH,ballD-1][p+1]=='R')
						{
							ballW++;
							if(ballW==width)
							{
								Console.WriteLine ("No");
								Console.WriteLine ("{0} {1} {2}",ballW-1,ballH,ballD-1);
								return;
							}
							ballH++;
							if(ballH==heigth)
							{
								Console.WriteLine ("Yes");
								Console.WriteLine ("{0} {1} {2}",ballW-1,ballH-1,ballD-1);
								return;
							}
						}
						else if(cuboid[ballW,ballH,ballD-1][p+1]=='L')
						{
							if(ballW==0)
							{
								Console.WriteLine ("No");
								Console.WriteLine ("{0} {1} {2}",ballW,ballH,ballD-1);
								return;
							}
							ballW--;
							ballH++;
							if(ballH==heigth)
							{
								Console.WriteLine ("Yes");
								Console.WriteLine ("{0} {1} {2}",ballW+1,ballH-1,ballD-1);
								return;
							}
						}
					}
					p=0;
					break;
				case 'F':
					if(ballD==0)
					{
						Console.WriteLine ("No");
						Console.WriteLine ("{0} {1} {2}",ballW,ballH,ballD);
						return;
					}
					if(p+1<cuboid[ballW,ballH,ballD].Length)
					{
						if(cuboid[ballW,ballH,ballD][p+1]=='R')
						{
							ballW++;
							if(ballW==width)
							{
								Console.WriteLine ("No");
								Console.WriteLine ("{0} {1} {2}",ballW-1,ballH,ballD);
								return;
							}
							ballH++;
							if(ballH==heigth)
							{
								Console.WriteLine ("Yes");
								Console.WriteLine ("{0} {1} {2}",ballW-1,ballH-1,ballD);
								return;
							}
						}
						else if(cuboid[ballW,ballH,ballD][p+1]=='L')
						{
							if(ballW==0)
							{
								Console.WriteLine ("No");
								Console.WriteLine ("{0} {1} {2}",ballW,ballH,ballD);
								return;
							}
							ballW--;
							ballH++;
							if(ballH==heigth)
							{
								Console.WriteLine ("Yes");
								Console.WriteLine ("{0} {1} {2}",ballW+1,ballH-1,ballD);
								return;
							}
						}
					}
					p=0;
					ballD--;
					break;
				case 'L':

					if(ballW==0)
					{
						Console.WriteLine ("No");
						Console.WriteLine ("{0} {1} {2}",ballW,ballH,ballD);
						return;
					}
					ballW--;
					ballH++;
					if(ballH==heigth)
					{
						Console.WriteLine ("Yes");
						Console.WriteLine ("{0} {1} {2}",ballW+1,ballH-1,ballD);
						return;
					}
					p=0;
					break;
				case 'R':
					ballW++;
					if(ballW==width)
					{
						Console.WriteLine ("No");
						Console.WriteLine ("{0} {1} {2}",ballW-1,ballH,ballD);
						return;
					}
					ballH++;
					if(ballH==heigth)
					{
						Console.WriteLine ("Yes");
						Console.WriteLine ("{0} {1} {2}",ballW-1,ballH-1,ballD);
						return;
					}
					p=0;
					break;
				}
				break;
			case 'B':
				Console.WriteLine ("No");
				Console.WriteLine ("{0} {1} {2}",ballW,ballH,ballD);
				return;
				break;
			case 'E':
				ballH++;
				if(ballH==heigth){
					Console.WriteLine ("Yes");
					Console.WriteLine ("{0} {1} {2}",ballW,ballH-1,ballD);
					return;
				}
				break;
			case 'T':
				string[] tport=cuboid[ballW,ballH,ballD].Split(' ');
				ballW=int.Parse(tport[1]);
				ballD=int.Parse(tport[1]);
				break;
			}
		}
	}
}
