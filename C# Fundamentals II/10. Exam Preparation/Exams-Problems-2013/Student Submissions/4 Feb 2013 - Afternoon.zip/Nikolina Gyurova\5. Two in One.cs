using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoInOne
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] lamps = new int[n];
            for (int i = 0; i < n; i++)
            {
                lamps[i] = 0;
            }
            int last = 0;
            int current = 0;
            bool lightoff = true, allLights = true;
            int o = 0;
            while (allLights)
            {
                while (lightoff)
                {
                    if (lamps[o] == 0)
                    {
                        current = o;
                        lightoff = false;
                    }
                    else
                    {
                        if (o == lamps.Length - 1)
                        {
                            allLights = false;
                            lightoff = false;
                        }
                        else o++;
                    }
                }
                lightoff = true;
                for (int i = current; i < lamps.Length; i = i + current + 2)
                {
                    if (lamps[i] == 0) last = i;
                    lamps[i] = 1;

                }

            }


            bool[] bot = new bool[2];
            for (int b = 0; b < 2; b++)
            {
                int[] dir = { 0, 0, 0, 0 };
                current = 0;
                string comands = Console.ReadLine();
                for (int j = 0; j < 4; j++)
                {
                    for (int i = 0; i < comands.Length; i++)
                    {
                        if (comands[i] == 'R') current++;
                        if (comands[i] == 'L') current--;
                        int index = (current+25000) % 4;
                        if (comands[i] == 'S') dir[index]++;
                    }
                }
                if (dir[0] == dir[2] && dir[1] == dir[3]) bot[b] = true;
                else bot[b] = false;
            }


            Console.WriteLine(last + 1);
            if (!bot[0]) Console.WriteLine("unbounded");
            else Console.WriteLine("bounded");
            if (!bot[1]) Console.WriteLine("unbounded");
            else Console.WriteLine("bounded");
        }
    }
}