using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class DecimalNumCorrespongingProvadia
{

    static void Main()
    {
       ulong number = ulong.Parse(Console.ReadLine());

        Console.WriteLine(convertNUmber((int)number + 1));
        
 
    }

    public static String convertNUmber(int number)
    {
        number--;
        String col = Convert.ToString((char)('A' + (number % 26)));
        while (number >= 26)
        {
            number = (number / 26) - 1;
            col = Convert.ToString((char)('a' + (number % 26))) + col;
        }
        return col;
    }
}
