using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace ProvadiaNumbers
{
    class Program
    {
        static string NumberLetters = "";

        static void BuildNumberLetters()
        {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < 26; i++)
            {
                builder.Append((char)('A' + i));
            }
            for (int i = 26; i < 256; i++)
            {
                builder.Append(((char)('a' + (i / 26 - 1))).ToString() + ((char)('A' + (i % 26))).ToString());
            }

            NumberLetters = builder.ToString();
        }

        static string AnyToAnyNumberFormat(string number)
        {
            BigInteger decimalNumber = BigInteger.Parse(number);
            string result = "";
            BigInteger remainder;
            int to = 256;
            if (decimalNumber.CompareTo(0) == 0) return "A";
            while (decimalNumber > 0)
            {
                BigInteger.DivRem(decimalNumber,to,out remainder);
                if (remainder > 25)
                {
                    result = NumberLetters[(int)remainder*2 - 26].ToString() + NumberLetters[(int)remainder*2 - 25].ToString() + result;
                }
                else
                {
                    result = NumberLetters[(int)remainder].ToString() + result;
                }
                decimalNumber /= to;
            }

            return result;
        }
        static void Main(string[] args)
        {
            BuildNumberLetters();
            Console.WriteLine(AnyToAnyNumberFormat(Console.ReadLine()));
        }
    }
}
