using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;


class Midget
{
    static void Main()
    {

        string valley = Console.ReadLine();
        List<int> valleyList = new List<int>();
        string[] valArr = valley.Split(new string[] { ", " }, StringSplitOptions.None);
        foreach (var item in valArr)
        {
            int number = int.Parse(item);
            valleyList.Add(number);
        }


        int numberPatterns = int.Parse(Console.ReadLine());
        int[] coins = new int[numberPatterns];
        string[] patterns = new string[numberPatterns];
        for (int i = 0; i < numberPatterns; i++)
        {
            int[] check = new int[valleyList.Count()];
            valleyList.CopyTo(check);
            patterns[i] = Console.ReadLine();
            List<int> patternList = new List<int>();
            string[] strArr = patterns[i].Split(new string[] { ", " }, StringSplitOptions.None);
            foreach (var item in strArr)
            {
                int number = int.Parse(item);
                patternList.Add(number);
            }
            coins[i] = valleyList[0]; 
            int index = 0;
            check[0] = int.MinValue;

            //while (check[index] != int.MinValue)
            //{
                for (int j = 0; j < patternList.Count();j++)
                {
                    
                    index = index + patternList[j];

                    if (index >= 0 && index < valleyList.Count())
                    {
                        if (check[index] != int.MinValue)
                        {
                            
                            coins[i] = coins[i] + valleyList[index];
                            check[index] = int.MinValue;
                            
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            //}

        }
        foreach (var item in coins)
        {
            Console.WriteLine(item);
        }










    }
}
