using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Number(int number)
        {
            for (int i = 0; i <= 25; i++)
            {
                if (number == i)
                {
                    Console.Write((char)((int)('A' + i)));
                }
            }
        }

        static void Number1(int number, int number1, int number2)
        { 
             switch (number1)
                {
                    case 1:
                        {
                            Console.Write('a');
                            Number(number2);
                            break;
                        }
                    case 2:
                        {
                            Console.Write('b');
                            Number(number2);
                            break;
                        }
                    case 3:
                        {
                            Console.Write('c');
                            Number(number2);
                            break;
                        }
                    case 4:
                        {
                            Console.Write('d');
                            Number(number2);
                            break;
                        }
                    case 5:
                        {
                            Console.Write('e');
                            Number(number2);
                            break;
                        }
                    case 6:
                        {
                            Console.Write('f');
                            Number(number2);
                            break;
                        }
                    case 7:
                        {
                            Console.Write('g');
                            Number(number2);
                            break;
                        }
                    case 9:
                        {
                            Console.Write('i');
                            Number(number2);
                            break;
                        }
                    default:
                        {
                            break;
                        }
             }
        }

        static void NumberA(int number, int number1, int number2)
        {
            if (number <= 25)
            {
                Number(number);
                
            }
            if ((number > 25) && (number <= 255))
            {
                Number1(number, number1, number2);

            }
        }

        static void Main(string[] args)
        {  
            int number = int.Parse(Console.ReadLine());
            int number1 = number / 26;
            int number2 = number % 26;
            int a;
            if (number <= 255)
            {
                NumberA( number,  number1,  number2);
            }
            //if(number <= 25)
            //{
            //    Number(number);
            //    Console.WriteLine();
            //}
            //if ((number > 25) && (number <= 255))
            //{
            //    Number1(number, number1, number2);
                
            //}
            
            if ((number > 255) && (number < 6630))
            {
                a = number / 256;
                
                
                switch (a)
                {
                    case 1:
                        {
                            
                            Console.Write("B");
                            NumberA(number - 256 * a, (number - 256*a) / 26, (number - 256*a) % 26);
                            break;
                        }
                    case 2:
                        {
                            Console.Write("C");
                            NumberA(number - 256 * a, ((number - 256) * a) / 26, ((number - 256) * a) % 26);
                            break;
                        }
                    case 3:
                        {
                            Console.Write("D");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 4:
                        {
                            
                            Console.Write("E");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 5:
                        {

                            Console.Write("F");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 6:
                        {

                            Console.Write("G");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }

                    case 7:
                        {

                            Console.Write("I");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 8:
                        {

                            Console.Write("H");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 9:
                        {
                            
                            Console.Write("J");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 10:
                        {

                            Console.Write("K");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 11:
                        {

                            Console.Write("L");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 12:
                        {

                            Console.Write("M");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 13:
                        {

                            Console.Write("N");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 14:
                        {

                            Console.Write("O");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 15:
                        {

                            Console.Write("P");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 16:
                        {

                            Console.Write("Q");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 17:
                        {

                            Console.Write("R");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 18:
                        {

                            Console.Write("S");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 19:
                        {

                            Console.Write("T");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 20:
                        {

                            Console.Write("U");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 21:
                        {

                            Console.Write("V");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 22:
                        {

                            Console.Write("W");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 23:
                        {

                            Console.Write("X");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 24:
                        {

                            Console.Write("Y");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 25:
                        {

                            Console.Write("Z");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    default:
                        break;
                }
                
            }
            if (number > 6630)
            {
                
                a = number / 512;
                Console.Write("B");
                number = number / 256;
                switch (a)
                {
                    case 1:
                        {
                            
                            Console.Write("B");
                            NumberA(number - 256 * a, (number - 256*a) / 26, (number - 256*a) % 26);
                            break;
                        }
                    case 2:
                        {
                            Console.Write("C");
                            NumberA(number - 256 * a, ((number - 256) * a) / 26, ((number - 256) * a) % 26);
                            break;
                        }
                    case 3:
                        {
                            Console.Write("D");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 4:
                        {
                            
                            Console.Write("E");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 5:
                        {

                            Console.Write("F");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 6:
                        {

                            Console.Write("G");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }

                    case 7:
                        {

                            Console.Write("I");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 8:
                        {

                            Console.Write("H");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 9:
                        {
                            
                            Console.Write("J");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 10:
                        {

                            Console.Write("K");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 11:
                        {

                            Console.Write("L");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 12:
                        {

                            Console.Write("M");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 13:
                        {

                            Console.Write("N");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 14:
                        {

                            Console.Write("O");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 15:
                        {

                            Console.Write("P");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 16:
                        {

                            Console.Write("Q");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 17:
                        {

                            Console.Write("R");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 18:
                        {

                            Console.Write("S");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 19:
                        {

                            Console.Write("T");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 20:
                        {

                            Console.Write("U");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 21:
                        {

                            Console.Write("V");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 22:
                        {

                            Console.Write("W");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 23:
                        {

                            Console.Write("X");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 24:
                        {

                            Console.Write("Y");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    case 25:
                        {

                            Console.Write("Z");
                            NumberA(number - 256 * a, (number - 256 * a) / 26, (number - 256 * a) % 26);
                            break;
                        }
                    default:
                        break;
                }
            }
           
        }
    }
}
