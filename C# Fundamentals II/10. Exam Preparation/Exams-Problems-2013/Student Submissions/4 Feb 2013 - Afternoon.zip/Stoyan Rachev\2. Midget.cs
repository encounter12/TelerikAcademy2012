using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        string[] n = Console.ReadLine().Split(new char[] { ',' });

        List<int> valley = new List<int>();
        for (int i = 0; i < n.Length; i++)
        {
            if (!string.IsNullOrWhiteSpace(n[i]))
            {
                valley.Add(int.Parse(n[i]));
            }
        }

        int M = int.Parse(Console.ReadLine());
        long maxCoins = 0;

        for (int i = 1; i <= M; i++)
        {
            int tmp = GetCoins(GetPattern(), valley);
            if (tmp > maxCoins)
            {
                maxCoins = tmp;
            }
        }

        Console.WriteLine(maxCoins);
    }

    public static int GetCoins(List<int> pattern, List<int> valley)
    {
        int tempCoins = 0;
        int currentPosValley = 0;
        int currentPosPattern = -1;
        bool backPos = false;
        List<int> beback = new List<int>();
        while (true)
        {

            for (int i = 0; i < beback.Count; i++)
            {
                if (currentPosValley == beback[i])
                {
                    backPos = true;
                }
            }
            if (backPos) break;
            if (currentPosValley == valley.Count || currentPosValley < 0)
            {
                break;
            }

            tempCoins += valley[currentPosValley];
            currentPosPattern++;
            beback.Add(currentPosValley);
            currentPosValley += pattern[currentPosPattern];



            if (currentPosPattern + 1 == pattern.Count )
            {
                if (currentPosValley > 0 && currentPosValley < valley.Count)
                {
                    currentPosPattern = -1;
                   // backPos = currentPosValley;
                }
                else
                {
                    break;
                }
            }
        }

        return tempCoins;
    }

    public static List<int> GetPattern()
    {
        string[] readPattern = Console.ReadLine().Split(new char[] { ',' });
        List<int> pattern = new List<int>();
        for (int i = 0; i < readPattern.Length; i++)
        {
            if (!string.IsNullOrWhiteSpace(readPattern[i]))
            {
                pattern.Add(int.Parse(readPattern[i]));
            }
        }
        return pattern;
    }
}