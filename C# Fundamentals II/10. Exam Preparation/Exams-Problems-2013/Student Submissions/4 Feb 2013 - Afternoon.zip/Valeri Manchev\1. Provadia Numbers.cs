using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());



            if (a == 0)
            {
                Console.WriteLine("A");
            }
            if (a == 1)
            {
                Console.WriteLine("B");
            }
            if (a == 2)
            {
                Console.WriteLine("C");
            }
            if (a == 3)
            {
                Console.WriteLine("D");
            }
            if (a == 4)
            {
                Console.WriteLine("E");
            }

            if (a == 5)
            {
                Console.WriteLine("F");
            }
            if (a == 6)
            {
                Console.WriteLine("G");
            }

            if (a == 7)
            {
                Console.WriteLine("H");
            }
            if (a == 8)
            {
                Console.WriteLine("I");
            }
            if (a == 9)
            {
                Console.WriteLine("J");
            }
            if (a == 10)
            {
                Console.WriteLine("K");
            }
            if (a == 11)
            {
                Console.WriteLine("L");
            }
            if (a == 12)
            {
                Console.WriteLine("M");
            }
            if (a == 13)
            {
                Console.WriteLine("N");
            }
            if (a == 14)
            {
                Console.WriteLine("O");
            }
            if (a == 15)
            {
                Console.WriteLine("P");
            }
            if (a == 16)
            {
                Console.WriteLine("Q");
            }
            if (a == 17)
            {
                Console.WriteLine("R");
            }

            if (a == 18)
            {
                Console.WriteLine("S");
            }
            if (a == 19)
            {
                Console.WriteLine("T");
            }

            if (a == 20)
            {
                Console.WriteLine("U");
            }
            if (a == 21)
            {
                Console.WriteLine("V");
            }
            if (a == 22)
            {
                Console.WriteLine("W");
            }
            if (a == 23)
            {
                Console.WriteLine("X");
            }
            if (a == 24)
            {
                Console.WriteLine("Y");
            }
            if (a == 25)
            {
                Console.WriteLine("Z");
            }
            if (a == 26)
            {
                Console.WriteLine("aA");
            }
            if (a == 27)
            {
                Console.WriteLine("aB");
            }
            if (a == 28)
            {
                Console.WriteLine("aC");
            }
            if (a == 29)
            {
                Console.WriteLine("aD");
            }
            if (a == 30)
            {
                Console.WriteLine("aE");
            }

            if (a == 31)
            {
                Console.WriteLine("aF");
            }
            if (a == 32)
            {
                Console.WriteLine("aG");
            }

            if (a == 33)
            {
                Console.WriteLine("aH");
            }
            if (a == 34)
            {
                Console.WriteLine("aI");
            }
            if (a == 35)
            {
                Console.WriteLine("aJ");
            }
            if (a == 36)
            {
                Console.WriteLine("aK");
            }
            if (a == 37)
            {
                Console.WriteLine("aL");
            }
            if (a == 38)
            {
                Console.WriteLine("aM");
            }
            if (a == 39)
            {
                Console.WriteLine("aN");
            }
            if (a == 40)
            {
                Console.WriteLine("aO");
            }
            if (a == 41)
            {
                Console.WriteLine("aP");
            }
            if (a == 42)
            {
                Console.WriteLine("aQ");
            }
            if (a == 43)
            {
                Console.WriteLine("aR");
            }

            if (a == 44)
            {
                Console.WriteLine("aS");
            }
            if (a == 45)
            {
                Console.WriteLine("aT");
            }

            if (a == 46)
            {
                Console.WriteLine("aU");
            }
            if (a == 47)
            {
                Console.WriteLine("aV");
            }
            if (a == 48)
            {
                Console.WriteLine("aW");
            }
            if (a == 49)
            {
                Console.WriteLine("aX");
            }
            if (a == 50)
            {
                Console.WriteLine("aY");
            }
            if (a == 51)
            {
                Console.WriteLine("aZ");
            }
            if (a == 52)
            {
                Console.WriteLine("bA");
            }
            if (a == 53)
            {
                Console.WriteLine("bB");
            }
            if (a == 54)
            {
                Console.WriteLine("bC");
            }
            if (a == 55)
            {
                Console.WriteLine("bD");
            }
            if (a == 56)
            {
                Console.WriteLine("bE");
            }

            if (a == 57)
            {
                Console.WriteLine("bF");
            }
            if (a == 58)
            {
                Console.WriteLine("bG");
            }

            if (a == 59)
            {
                Console.WriteLine("bH");
            }
            if (a == 60)
            {
                Console.WriteLine("bI");
            }
            if (a == 61)
            {
                Console.WriteLine("bJ");
            }
            if (a == 62)
            {
                Console.WriteLine("bK");
            }
            if (a == 63)
            {
                Console.WriteLine("bL");
            }
            if (a == 64)
            {
                Console.WriteLine("bM");
            }
            if (a == 65)
            {
                Console.WriteLine("bN");
            }
            if (a == 66)
            {
                Console.WriteLine("bO");
            }
            if (a == 67)
            {
                Console.WriteLine("bP");
            }
            if (a == 68)
            {
                Console.WriteLine("bQ");
            }
            if (a == 69)
            {
                Console.WriteLine("bR");
            }

            if (a == 70)
            {
                Console.WriteLine("bS");
            }
            if (a == 71)
            {
                Console.WriteLine("bT");
            }

            if (a == 72)
            {
                Console.WriteLine("bU");
            }
            if (a == 73)
            {
                Console.WriteLine("bV");
            }
            if (a == 74)
            {
                Console.WriteLine("bW");
            }
            if (a == 75)
            {
                Console.WriteLine("bX");
            }
            if (a == 76)
            {
                Console.WriteLine("bY");
            }
            if (a == 77)
            {
                Console.WriteLine("bZ");
            }
            if (a == 78)
            {
                Console.WriteLine("cA");
            }
            if (a == 79)
            {
                Console.WriteLine("cB");
            }
            if (a == 80)
            {
                Console.WriteLine("cC");
            }
            if (a == 81)
            {
                Console.WriteLine("cD");
            }
            if (a == 82)
            {
                Console.WriteLine("cE");
            }

            if (a == 83)
            {
                Console.WriteLine("cF");
            }
            if (a == 84)
            {
                Console.WriteLine("cG");
            }

            if (a == 85)
            {
                Console.WriteLine("cH");
            }
            if (a == 86)
            {
                Console.WriteLine("cI");
            }
            if (a == 87)
            {
                Console.WriteLine("cJ");
            }
            if (a == 88)
            {
                Console.WriteLine("cK");
            }
            if (a == 89)
            {
                Console.WriteLine("cL");
            }
            if (a == 90)
            {
                Console.WriteLine("cM");
            }
            if (a == 91)
            {
                Console.WriteLine("cN");
            }
            if (a == 92)
            {
                Console.WriteLine("cO");
            }
            if (a == 93)
            {
                Console.WriteLine("cP");
            }
            if (a == 94)
            {
                Console.WriteLine("cQ");
            }
            if (a == 95)
            {
                Console.WriteLine("cR");
            }

            if (a == 96)
            {
                Console.WriteLine("cS");
            }
            if (a == 97)
            {
                Console.WriteLine("cT");
            }

            if (a == 98)
            {
                Console.WriteLine("cU");
            }
            if (a == 99)
            {
                Console.WriteLine("cV");
            }
            if (a == 100)
            {
                Console.WriteLine("cW");
            }
            if (a == 101)
            {
                Console.WriteLine("cX");
            }
            if (a == 102)
            {
                Console.WriteLine("cY");
            }
            if (a == 103)
            {
                Console.WriteLine("cZ");
            }
            if (a == 104)
            {
                Console.WriteLine("dA");
            }
            if (a == 105)
            {
                Console.WriteLine("dB");
            }
            if (a == 106)
            {
                Console.WriteLine("dC");
            }
            if (a == 107)
            {
                Console.WriteLine("dD");
            }
            if (a == 108)
            {
                Console.WriteLine("dE");
            }

            if (a == 109)
            {
                Console.WriteLine("dF");
            }
            if (a == 110)
            {
                Console.WriteLine("dG");
            }

            if (a == 111)
            {
                Console.WriteLine("dH");
            }
            if (a == 112)
            {
                Console.WriteLine("dI");
            }
            if (a ==113)
            {
                Console.WriteLine("dJ");
            }
            if (a == 114)
            {
                Console.WriteLine("dK");
            }
            if (a == 115)
            {
                Console.WriteLine("dL");
            }
            if (a == 116)
            {
                Console.WriteLine("dM");
            }
            if (a == 117)
            {
                Console.WriteLine("dN");
            }
            if (a == 118)
            {
                Console.WriteLine("dO");
            }
            if (a == 119)
            {
                Console.WriteLine("dP");
            }
            if (a == 120)
            {
                Console.WriteLine("dQ");
            }
            if (a == 121)
            {
                Console.WriteLine("dR");
            }

            if (a == 122)
            {
                Console.WriteLine("dS");
            }
            if (a == 123)
            {
                Console.WriteLine("dT");
            }

            if (a == 124)
            {
                Console.WriteLine("dU");
            }
            if (a == 125)
            {
                Console.WriteLine("dV");
            }
            if (a == 126)
            {
                Console.WriteLine("dW");
            }
            if (a == 127)
            {
                Console.WriteLine("dX");
            }
            if (a == 128)
            {
                Console.WriteLine("dY");
            }
            if (a == 129)
            {
                Console.WriteLine("dZ");
            }
            if (a == 130)
            {
                Console.WriteLine("eA");
            }
            if (a == 131)
            {
                Console.WriteLine("eB");
            }
            if (a == 132)
            {
                Console.WriteLine("eC");
            }
            if (a == 133)
            {
                Console.WriteLine("eD");
            }
            if (a == 134)
            {
                Console.WriteLine("eE");
            }

            if (a == 135)
            {
                Console.WriteLine("eF");
            }
            if (a == 136)
            {
                Console.WriteLine("eG");
            }

            if (a == 137)
            {
                Console.WriteLine("eH");
            }
            if (a == 138)
            {
                Console.WriteLine("eI");
            }
            if (a == 139)
            {
                Console.WriteLine("eJ");
            }
            if (a == 140)
            {
                Console.WriteLine("eK");
            }
            if (a == 141)
            {
                Console.WriteLine("eL");
            }
            if (a == 142)
            {
                Console.WriteLine("eM");
            }
            if (a == 143)
            {
                Console.WriteLine("eN");
            }
            if (a == 144)
            {
                Console.WriteLine("eO");
            }
            if (a == 145)
            {
                Console.WriteLine("eP");
            }
            if (a == 146)
            {
                Console.WriteLine("eQ");
            }
            if (a == 147)
            {
                Console.WriteLine("eR");
            }

            if (a == 148)
            {
                Console.WriteLine("eS");
            }
            if (a == 149)
            {
                Console.WriteLine("eT");
            }

            if (a == 150)
            {
                Console.WriteLine("eU");
            }
            if (a == 151)
            {
                Console.WriteLine("eV");
            }
            if (a == 152)
            {
                Console.WriteLine("eW");
            }
            if (a == 153)
            {
                Console.WriteLine("eX");
            }
            if (a == 154)
            {
                Console.WriteLine("eY");
            }
            if (a == 155)
            {
                Console.WriteLine("eZ");
            }
            if (a == 156)
            {
                Console.WriteLine("fA");
            }
            if (a == 157)
            {
                Console.WriteLine("fB");
            }
            if (a == 158)
            {
                Console.WriteLine("fC");
            }
            if (a == 159)
            {
                Console.WriteLine("fD");
            }
            if (a == 160)
            {
                Console.WriteLine("fE");
            }

            if (a == 161)
            {
                Console.WriteLine("fF");
            }
            if (a == 162)
            {
                Console.WriteLine("fG");
            }

            if (a == 163)
            {
                Console.WriteLine("fH");
            }
            if (a == 164)
            {
                Console.WriteLine("fI");
            }
            if (a == 165)
            {
                Console.WriteLine("fJ");
            }
            if (a == 166)
            {
                Console.WriteLine("fK");
            }
            if (a == 167)
            {
                Console.WriteLine("fL");
            }
            if (a == 168)
            {
                Console.WriteLine("fM");
            }
            if (a == 169)
            {
                Console.WriteLine("fN");
            }
            if (a == 170)
            {
                Console.WriteLine("fO");
            }
            if (a == 171)
            {
                Console.WriteLine("fP");
            }
            if (a == 172)
            {
                Console.WriteLine("fQ");
            }
            if (a == 173)
            {
                Console.WriteLine("fR");
            }

            if (a == 174)
            {
                Console.WriteLine("fS");
            }
            if (a == 175)
            {
                Console.WriteLine("fT");
            }

            if (a == 176)
            {
                Console.WriteLine("fU");
            }
            if (a == 177)
            {
                Console.WriteLine("fV");
            }
            if (a == 178)
            {
                Console.WriteLine("fW");
            }
            if (a == 179)
            {
                Console.WriteLine("fX");
            }
            if (a == 180)
            {
                Console.WriteLine("fY");
            }
            if (a == 181)
            {
                Console.WriteLine("fZ");
            }
            if (a == 182)
            {
                Console.WriteLine("gA");
            }
            if (a == 183)
            {
                Console.WriteLine("gB");
            }
            if (a == 184)
            {
                Console.WriteLine("gC");
            }
            if (a == 185)
            {
                Console.WriteLine("gD");
            }
            if (a == 186)
            {
                Console.WriteLine("gE");
            }

            if (a == 187)
            {
                Console.WriteLine("gF");
            }
            if (a == 188)
            {
                Console.WriteLine("gG");
            }

            if (a == 189)
            {
                Console.WriteLine("gH");
            }
            if (a == 190)
            {
                Console.WriteLine("gI");
            }
            if (a == 191)
            {
                Console.WriteLine("gJ");
            }
            if (a == 192)
            {
                Console.WriteLine("gK");
            }
            if (a == 193)
            {
                Console.WriteLine("gL");
            }
            if (a == 194)
            {
                Console.WriteLine("gM");
            }
            if (a == 195)
            {
                Console.WriteLine("gN");
            }
            if (a == 196)
            {
                Console.WriteLine("gO");
            }
            if (a == 197)
            {
                Console.WriteLine("gP");
            }
            if (a == 198)
            {
                Console.WriteLine("gQ");
            }
            if (a == 199)
            {
                Console.WriteLine("gR");
            }

            if (a == 200)
            {
                Console.WriteLine("gS");
            }
            if (a == 201)
            {
                Console.WriteLine("gT");
            }

            if (a == 202)
            {
                Console.WriteLine("gU");
            }
            if (a == 203)
            {
                Console.WriteLine("gV");
            }
            if (a == 204)
            {
                Console.WriteLine("gW");
            }
            if (a == 205)
            {
                Console.WriteLine("gX");
            }
            if (a == 206)
            {
                Console.WriteLine("gY");
            }
            if (a == 207)
            {
                Console.WriteLine("gZ");
            }
            if (a == 208)
            {
                Console.WriteLine("hA");
            }
            if (a == 209)
            {
                Console.WriteLine("hB");
            }
            if (a == 210)
            {
                Console.WriteLine("hC");
            }
            if (a == 211)
            {
                Console.WriteLine("hD");
            }
            if (a == 212)
            {
                Console.WriteLine("hE");
            }

            if (a == 213)
            {
                Console.WriteLine("hF");
            }
            if (a == 214)
            {
                Console.WriteLine("hG");
            }

            if (a == 215)
            {
                Console.WriteLine("hH");
            }
            if (a == 216)
            {
                Console.WriteLine("hI");
            }
            if (a == 217)
            {
                Console.WriteLine("hJ");
            }
            if (a == 218)
            {
                Console.WriteLine("hK");
            }
            if (a == 219)
            {
                Console.WriteLine("hL");
            }
            if (a == 220)
            {
                Console.WriteLine("hM");
            }
            if (a == 221)
            {
                Console.WriteLine("hN");
            }
            if (a == 222)
            {
                Console.WriteLine("hO");
            }
            if (a == 223)
            {
                Console.WriteLine("hP");
            }
            if (a == 224)
            {
                Console.WriteLine("hQ");
            }
            if (a == 225)
            {
                Console.WriteLine("hR");
            }

            if (a == 226)
            {
                Console.WriteLine("hS");
            }
            if (a == 227)
            {
                Console.WriteLine("hT");
            }

            if (a == 228)
            {
                Console.WriteLine("hU");
            }
            if (a == 229)
            {
                Console.WriteLine("hV");
            }
            if (a == 230)
            {
                Console.WriteLine("hW");
            }
            if (a == 231)
            {
                Console.WriteLine("hX");
            }
            if (a == 232)
            {
                Console.WriteLine("hY");
            }
            if (a == 233)
            {
                Console.WriteLine("hZ");
            }
            if (a == 234)
            {
                Console.WriteLine("iA");
            }
            if (a == 235)
            {
                Console.WriteLine("iB");
            }
            if (a == 236)
            {
                Console.WriteLine("iC");
            }
            if (a == 237)
            {
                Console.WriteLine("iD");
            }
            if (a == 238)
            {
                Console.WriteLine("iE");
            }

            if (a == 239)
            {
                Console.WriteLine("iF");
            }
            if (a == 240)
            {
                Console.WriteLine("iG");
            }

            if (a == 241)
            {
                Console.WriteLine("iH");
            }
            if (a == 242)
            {
                Console.WriteLine("iI");
            }
            if (a == 243)
            {
                Console.WriteLine("iJ");
            }
            if (a == 244)
            {
                Console.WriteLine("iK");
            }
            if (a == 245)
            {
                Console.WriteLine("iL");
            }
            if (a == 246)
            {
                Console.WriteLine("iM");
            }
            if (a == 247)
            {
                Console.WriteLine("iN");
            }
            if (a == 248)
            {
                Console.WriteLine("iO");
            }
            if (a == 249)
            {
                Console.WriteLine("iP");
            }
            if (a == 250)
            {
                Console.WriteLine("iQ");
            }
            if (a == 251)
            {
                Console.WriteLine("iR");
            }

            if (a == 252)
            {
                Console.WriteLine("iS");
            }
            if (a == 253)
            {
                Console.WriteLine("iT");
            }

            if (a == 254)
            {
                Console.WriteLine("iU");
            }
            if (a == 255)
            {
                Console.WriteLine("iV");
            }
            if (a == 256)
            {
                Console.WriteLine("BA");
            }
            if (a == 257)
            {
                Console.WriteLine("BB");
            }
            if (a == 258)
            {
                Console.WriteLine("BC");
            }
            if (a == 259)
            {
                Console.WriteLine("BD");
            }
            if (a == 260)
            {
                Console.WriteLine("BE");
            }
            if (a == 261)
            {
                Console.WriteLine("BF");
            }
            if (a == 262)
            {
                Console.WriteLine("BG");
            }
            if (a == 263)
            {
                Console.WriteLine("BH");
            }
            if (a == 264)
            {
                Console.WriteLine("BI");
            }

            if (a == 265)
            {
                Console.WriteLine("BJ");
            }
            if (a == 266)
            {
                Console.WriteLine("BK");
            }

            if (a == 267)
            {
                Console.WriteLine("BL");
            }
            if (a == 268)
            {
                Console.WriteLine("BM");
            }
            if (a == 269)
            {
                Console.WriteLine("BN");
            }
            if (a == 270)
            {
                Console.WriteLine("BO");
            }
            if (a == 271)
            {
                Console.WriteLine("BP");
            }
            if (a == 272)
            {
                Console.WriteLine("BQ");
            }
            if (a == 273)
            {
                Console.WriteLine("BR");
            }
            if (a == 274)
            {
                Console.WriteLine("BS");
            }
            if (a == 275)
            {
                Console.WriteLine("BT");
            }
            if (a == 276)
            {
                Console.WriteLine("BU");
            }
            if (a == 277)
            {
                Console.WriteLine("BV");
            }

            if (a == 278)
            {
                Console.WriteLine("BW");
            }
            if (a == 279)
            {
                Console.WriteLine("BX");
            }

            if (a == 280)
            {
                Console.WriteLine("BY");
            }
            if (a == 281)
            {
                Console.WriteLine("BZ");
            }
            if (a == 282)
            {
                Console.WriteLine("CA");
            }
            if (a == 283)
            {
                Console.WriteLine("CB");
            }
            if (a == 284)
            {
                Console.WriteLine("CC");
            }
            if (a == 285)
            {
                Console.WriteLine("CD");
            }
        
            if (a == 286)
            {
                Console.WriteLine("CE");
            }

            if (a == 287)
            {
                Console.WriteLine("CF");
            }
            if (a == 288)
            {
                Console.WriteLine("CG");
            }

            if (a == 289)
            {
                Console.WriteLine("CH");
            }
            if (a == 290)
            {
                Console.WriteLine("CI");
            }
            if (a == 291)
            {
                Console.WriteLine("CJ");
            }
            if (a == 292)
            {
                Console.WriteLine("CK");
            }
            if (a == 293)
            {
                Console.WriteLine("CL");
            }
            if (a == 294)
            {
                Console.WriteLine("CM");
            }
            if (a == 295)
            {
                Console.WriteLine("CN");
            }
            if (a == 296)
            {
                Console.WriteLine("CO");
            }
            if (a == 297)
            {
                Console.WriteLine("CP");
            }
            if (a == 298)
            {
                Console.WriteLine("CQ");
            }
            if (a == 299)
            {
                Console.WriteLine("CR");
            }
        
            if (a == 300)
            {
                Console.WriteLine("dS");
            }
            if (a == 4000)
            {
                Console.WriteLine("CT");
            }

            if (a == 302)
            {
                Console.WriteLine("CU");
            }
            if (a == 303)
            {
                Console.WriteLine("CV");
            }
            if (a == 304)
            {
                Console.WriteLine("CW");
            }
            if (a == 305)
            {
                Console.WriteLine("CX");
            }
            if (a == 306)
            {
                Console.WriteLine("CY");
            }
            if (a == 307)
            {
                Console.WriteLine("CZ");
            }
        }
    }
}
