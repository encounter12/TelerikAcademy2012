using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class AlignBoth
{
    static string[] words;
    static int N, W;
    static int allWordsCount;
    static StringBuilder output;

    static void Main()
    {
        StringBuilder input = new StringBuilder();

        N = int.Parse(Console.ReadLine());
        W = int.Parse(Console.ReadLine());
        //List<string> words2 = new List<string>();

        for (int i = 0; i < N; i++)
        {
            string line = Console.ReadLine();
            input.Append(line);
        }


        words = input.ToString().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

        allWordsCount = words.Length;

        //string test = input.ToString();

        Console.WriteLine(words[0]);
    }

    public void solve()
    {
        try
        {
            DoAlign(0);
            Console.WriteLine("Unsolvable!");
        }
        catch (Exception)
        {
            //Console.WriteLine(ex.Message);
            //Console.WriteLine(this);
        }
    }

    public void DoAlign(int Number)
    {
        if (Number == allWordsCount)
        {
            throw new Exception("Finished!");
        }
        //int currPoss;

        for (int addSpaceNumber = 1; addSpaceNumber < W; addSpaceNumber++)
        {
            int toPosition = 1;
            output = new StringBuilder();
            for (int currPoss = 0; currPoss < toPosition; currPoss++)
            {
                output.Append(words[currPoss]).Append(new string(' ', addSpaceNumber));  
             
            }
            for (int currPoss = toPosition; currPoss < allWordsCount; currPoss++)
            {
                output.Append(words[currPoss]).Append(new string(' ', addSpaceNumber-1)); 
            }


            //for (int i = 0; i < Number; i++)
            //{
            //    output.Append(words[i]).Append();
            //}

        }



    }

}


