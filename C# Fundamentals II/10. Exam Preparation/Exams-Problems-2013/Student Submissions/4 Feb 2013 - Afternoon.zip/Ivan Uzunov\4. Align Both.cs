using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AlignBoth
{
    class AlignBoth
    {
        static void Main()
        {
            Console.WriteLine("Enter number of lines: ");
            string lineNo = Console.ReadLine();
            int n = int.Parse(lineNo);
            Console.WriteLine("Enter desiered lines width: ");
            string lines = Console.ReadLine();
            int W = int.Parse(lines);
            Console.WriteLine("Enter text line by line:");
            string text = null;
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
                for (int i = 0; i <= n; i++)
                {
                    do
                    {
                        
                    } while 
                
                }
            
                
            

           
        } 
    }
}
