using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int w = int.Parse(Console.ReadLine());
            string[] text = new string[n];
            StringBuilder formatedText = new StringBuilder();
            for (int i = 0; i < n; i++)
            {
                text[i] = Console.ReadLine();
            }
            int countWidth=0;
            for (int i = 0; i < text.Length; i++)
            {
                if (i > 0 && text[i] == ' ' && text[i - 1] == ' ') continue;
                formatedText.Append(text[i]);
                countWidth++;
                if (countWidth == w)
                {
                    formatedText.Append('\n');
                }
            }
            Console.WriteLine(formatedText.ToString());
        }
    }
}
