using System;

class Program
{
    static void Main(string[] args)
    {
        string valley = Console.ReadLine();
        char[] separators = { ',' };
        string[] val = valley.Split(separators);
        int[] vall = new int[val.Length];
        for (int i = 0; i < val.Length; i++)
        {
            vall[i] = int.Parse(val[i].Trim());
        }
        int M = int.Parse(Console.ReadLine());
        int bestSum = int.MinValue;
        for (int i = 0; i < M; i++)
        {
            string pattern = Console.ReadLine();
            string[] pat = pattern.Split(separators);
            int[] patt = new int[pat.Length];
            for (int j = 0; j < pat.Length; j++)
            {
                patt[j] = int.Parse(pat[j].Trim());
            }
            int s = Walk(vall, patt);
            if (bestSum < s)
            {
                bestSum = s;
            }
        }
        Console.WriteLine(bestSum);
    }

    static int Walk(int[] vall, int[] patt)
    {
        int sum = 0; int currPatt; int currVall = 0;
        bool[] visitted = new bool[vall.Length];
        sum = vall[0]; visitted[0] = true;

        while (true)
        {
            for (int i = 0; i < patt.Length; i++)
            {
                currPatt = patt[i];
                currVall = currVall + currPatt;
                if ((currVall > vall.Length - 1) || (currVall < 0))
                {
                    return sum;
                }
                if (visitted[currVall] == true)
                {
                    return sum;
                }
                sum = sum + vall[currVall];
                visitted[currVall] = true;
            }
        }
    }
}
