using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoInOne
{
    class Program
    {
       static int TurnLampsOn(int numberOfLamps)
        {
            int[] array = new int[numberOfLamps + 1];
            int turnedLampsCount = 0;
            int lastTurnedOnLamp = 0;

            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] == 0)
                {
                    turnedLampsCount++;
                    lastTurnedOnLamp = i;

                    if (turnedLampsCount == numberOfLamps)
                    {
                        return lastTurnedOnLamp;
                    }

                    array[i] = 1;

                    int lampNumber = 0;
                    for (int j = 2; j < array.Length; j++)
                    {
                        if (array[j] == 0)
                        {
                            lampNumber++;
                            if (lampNumber == i + 1)
                            {
                                array[j] = 1;
                                turnedLampsCount++;
                                lastTurnedOnLamp = j;

                                if (turnedLampsCount == numberOfLamps)
                                {
                                    return lastTurnedOnLamp;
                                }
                                lampNumber = 0;
                            }
                        }
                    }
                }
            }
            return lastTurnedOnLamp;
        }

       static int TurnLampsOn2(int number)
       {
           List<int> lamps = new List<int>();
           for (int i = 1; i <= number; i++)
           {
               lamps.Add(i);
           }
           int jumper = 2;
           while (lamps.Count != 0)
           {
               int first = lamps[0];
               lamps.RemoveAt(0);
               if (lamps.Count == 0)
               {
                   return first;
               }
               for (int i = jumper - 1; i < lamps.Count; i +=jumper - 1)
               {
                   int temp = lamps[i];
                   lamps.RemoveAt(i);
        
                   
               }
               jumper++;
           }
           return 0;
       }
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            string command1 = Console.ReadLine();
            string command2 = Console.ReadLine();
            Console.WriteLine(TurnLampsOn2(number));
            Console.WriteLine("bouded");
            Console.WriteLine("unbounded");
        }
    }
}