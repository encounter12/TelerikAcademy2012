using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Exam._1.ReadCarefully
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger userInput = BigInteger.Parse(Console.ReadLine());

            Console.WriteLine(ConvertFromTen(256, userInput));
        }

        private static string ConvertFromTen(int tbase, BigInteger number)
        {
            string convertedNumber = string.Empty;
            List<int> result = new List<int>();
            if (number == 0)
            {
                return Convert.ToString('A');
            }
            while (number > 0)
            {
                result.Add((int)(number % tbase));
                number /= tbase;
            }

            string letterDigit = string.Empty;
            for (int count = 0; count < result.Count; count++)
            {
                //if (result[count] < 0)
                //{
                //    letterDigit = Convert.ToString((char)('A'));
                //}
                //else 
                if (result[count] < 26) 
                {
                    letterDigit = Convert.ToString((char)('A' + result[count]));
                }
                else if (result[count] > 25 && result[count] < 52) 
                {
                    letterDigit = Convert.ToString(string.Concat('a', (char)('A' + result[count] - 26)));
                }
                else if (result[count] > 51 && result[count] < 78) 
                {
                    letterDigit = Convert.ToString(string.Concat('b', (char)('A' + result[count] - 52)));
                }
                else if (result[count] > 77 && result[count] < 104)
                {
                    letterDigit = Convert.ToString(string.Concat('c', (char)('A' + result[count] - 78)));
                }
                else if (result[count] > 103 && result[count] < 130) 
                {
                    letterDigit = Convert.ToString(string.Concat('d', (char)('A' + result[count] - 104)));
                }
                else if (result[count] > 129 && result[count] < 156)
                {
                    letterDigit = Convert.ToString(string.Concat('e', (char)('A' + result[count] - 130)));
                }
                else if (result[count] > 155 && result[count] < 182)
                {
                    letterDigit = Convert.ToString(string.Concat('f', (char)('A' + result[count] - 156)));
                }
                else if (result[count] > 181 && result[count] < 208) 
                {
                    letterDigit = Convert.ToString(string.Concat('g', (char)('A' + result[count] - 182)));
                }
                else if (result[count] > 207 && result[count] < 234) 
                {
                    letterDigit = Convert.ToString(string.Concat('h', (char)('A' + result[count] - 208)));
                }
                else if (result[count] > 233) 
                {
                    letterDigit = Convert.ToString(string.Concat('i', (char)('A' + result[count] - 234)));
                }

                convertedNumber = letterDigit + convertedNumber;
            }

            return convertedNumber;
        }

    }
}
