using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProvadiaNumbers
{
    class Program
    {
        static void Main(string[] args)
        {

          int a = System.Int32.Parse(Console.ReadLine());
          decimal b = Convert.ToDecimal(a);
           
          string[] Array=new string [] {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
          
          string[] Array2 = new string[254];
          for (int i = 0; i < 26; i++)
          {
            
              Array2[i] = Array[i];

          }
          for (int i = 26; i < 52; i++)
          {
              Array2[i] = "a" + Array[i - 26];
          }
          for (int i = 52; i < 77; i++)
          {
              Array2[i] = "b" + Array[i - 52];
          }
          for (int i = 77; i < 103; i++)
          {
              Array2[i] = "c" + Array[i - 77];
          }
          for (int i = 103; i < 129; i++)
          {
              Array2[i] = "d" + Array[i - 103];
          }
            for (int i=129; i< 155; i++)
            {
                Array2[i]="e"+ Array[i-129];
            }


              Console.WriteLine(Array2[a]);
        }
    }
}
