using System;
using System.Collections.Generic;
using System.Text;


class Example
{
    public static void Main()
    {
        Console.WriteLine(21);
    }
}
