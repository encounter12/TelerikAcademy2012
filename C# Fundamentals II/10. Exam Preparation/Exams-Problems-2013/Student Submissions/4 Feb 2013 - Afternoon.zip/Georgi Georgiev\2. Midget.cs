using System;
using System.Linq;

namespace Midget
{
    class Midget
    {
        static void Main(string[] args)
        {
            char[] charSeparators = new char[] { ',', ' ' };
            string[] val = Console.ReadLine().Split(charSeparators, StringSplitOptions.RemoveEmptyEntries);
            int[] valley = new int[val.Count()];
            int[] valley2 = new int[val.Count()];
            for (int i = 0; i < val.Count(); i++)
            {
                valley[i] = int.Parse(val[i]);
            }
            Array.Copy(valley, 0, valley2, 0,valley.Count());
            int m = int.Parse(Console.ReadLine());
            string[] patterns = new string[m];
            int[,] pats = new int[m, 101];
            int[] length = new int[m];
            for (int i = 0; i < m; i++)
            {
                patterns[i] = Console.ReadLine();
                string[] pattern = patterns[i].Split(charSeparators, StringSplitOptions.RemoveEmptyEntries);
                for (int j = 0; j < pattern.Count(); j++)
                {
                    pats[i, j] = int.Parse(pattern[j]);
                    length[i]++;
                }
            }
            int coins = 0;
            int maxCoins = int.MinValue;
            int index = 0, valIndex = 0;
            bool ok = true;
            for (int i = 0; i < m; i++)
            {
                ok = true;
                valIndex = 0;
                index = 0;
                coins += valley[0];
                valley[0] = 1001;
                while (ok)
                {
                    while (index < length[i])
                    {
                        valIndex += pats[i, index];
                        if (valIndex >= 0 && valIndex < valley.Count())
                        {
                            if (valley[valIndex] != 1001)
                            {
                                coins += valley[valIndex];
                                index++;
                                valley[valIndex] = 1001;
                            }
                            else
                            {
                                ok = false;
                                break;
                            }
                        }
                        else
                        {
                            ok = false;
                            break;
                        }
                    }
                    index = 0;
                }
                if (maxCoins < coins) maxCoins = coins;
                coins = 0;
                Array.Copy(valley2, 0, valley, 0, valley.Count());
            }

            Console.WriteLine(maxCoins);
        }
    }
}