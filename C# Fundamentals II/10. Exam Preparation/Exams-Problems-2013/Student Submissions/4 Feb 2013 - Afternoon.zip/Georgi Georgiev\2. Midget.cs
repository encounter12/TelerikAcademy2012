using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Promlem2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> valley = Console.ReadLine().Split(',').ToList();

            int numbersOfPatterns = int.Parse(Console.ReadLine());

            int[,] matrix = new int[rows, cols];

            // Enter the matrix elements
            for (int row = 0; row < rows; row++)
            {
                for (int col = 0; col < cols; col++)
                {
                    Console.Write("matrix[{0},{1}] = ", row, col);
                    int element = int.Parse(Console.ReadLine());
                    matrix[row, col] = element;
                }
            }

            int maxCoins = 0;
            for (int i = 0; i < 3; i++)
            {
                List<int> visited = new List<int>();
                int collect = 0;
                int pos = 0;
                bool visitedEl = false;
                for (int j = 0; j < arr[i].Length; j++)
                {

                    for (int k = 0; k < visited.Count; k++)
                    {
                        if (pos == visited[k])
                        {
                            visitedEl = true;
                            break;
                        }
                    }
                    if (visitedEl == true)
                    {
                        break;
                    }
                    collect += int.Parse(valley[pos]);
                    visited.Add(pos);
                    pos += int.Parse(arr[i][j]);

                }
                for (int j = 0; j < arr[i].Length; j++)
                {
                    for (int k = 0; k < visited.Count; k++)
                    {
                        if (pos == visited[k])
                        {
                            visitedEl = true;
                            break;
                        }
                    }
                    if (visitedEl == true)
                    {
                        break;
                    }
                    collect += int.Parse(valley[pos]);
                    visited.Add(pos);
                    pos += int.Parse(arr[i][j]);
                }
                if (maxCoins < collect)
                {
                    maxCoins = collect;
                }
                visited.TrimExcess();

            }
            Console.WriteLine(maxCoins);

            
            
        }
    }
}
