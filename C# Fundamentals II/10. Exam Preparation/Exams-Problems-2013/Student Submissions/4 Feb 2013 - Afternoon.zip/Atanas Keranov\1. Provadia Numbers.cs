using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProvadiaNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.Write("Enter source numeral system (e.g. 2 for binary, 10 for decimal, etc.): ");
            const int FromNumeralSystem = 10;

            //Console.Write("Enter destination numeral system: ");
            const int ToNumeralSystem = 256;

            //Console.Write("Enter number: ");
            string number = Console.ReadLine();

            ProvadianNumeralSystemConvert(number, FromNumeralSystem, ToNumeralSystem);
        }

        private static void ProvadianNumeralSystemConvert(string number, int fromNumeralSystem, int toNumeralSystem)
        {
            ulong decimalNumber = ulong.Parse(number);
            List<ulong> destNumber = new List<ulong>();
            string[] provadianDigits = GetProvadianDigits();
            StringBuilder output = new StringBuilder();

            do
            {
                destNumber.Add(decimalNumber % (ulong)toNumeralSystem);
                decimalNumber = decimalNumber / (ulong)toNumeralSystem;
            } while (decimalNumber > 0);

            for (int pos = destNumber.Count - 1; pos >= 0; pos--)
            {
                output.Append(provadianDigits[destNumber[pos]]);
            }

            Console.WriteLine(output);
        }

        private static string[] GetProvadianDigits()
        {
            string[] provadianDigits = new string[256];
            int charCodeMinor = 65; //max A=65 to A=90
            int charCodeMajor = 96; //max a=97 to z=122

            for (int i = 0; i < provadianDigits.Length; i++)
            {
                if (i < 26)
                {
                    if (charCodeMinor == 91)
                    {
                        charCodeMinor = 65;
                    }

                    provadianDigits[i] = ((char)charCodeMinor).ToString();
                    charCodeMinor++;
                }
                else
                {
                    if (charCodeMinor == 91)
                    {
                        charCodeMinor = 65;
                        charCodeMajor++;
                    }

                    provadianDigits[i] = String.Concat(((char)charCodeMajor).ToString(), ((char)charCodeMinor).ToString());
                    charCodeMinor++;
                }
            }

            return provadianDigits;
        }
    }
}
