using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Mideget
{
    static void Main(string[] args)
    {
        string input = Console.ReadLine();
        int[] valley = SplitArray(input);
        
        //int m = int.Parse(Console.ReadLine());

        int[][] jagged = { new int[] { 1, 2, -3 }, new int[] { 1, 3, -2 }, new int[] { 1, -1 } };

        int currentSum = valley[0];
        int maxSum = 0;
        int currentPosition = 0;
        int position = 0;

        for (int j = 0; j < jagged.Length; j++)
        {
            for (int i = 0; i < valley.Length; i++)
            {
                for (int k = 0; k < jagged[j].Length; k++)
                {
                    currentPosition += jagged[j][k];
                    if (currentPosition == position || currentPosition > valley.Length)
                    {
                        break;
                    }
                    else
                    {
                        currentSum += valley[currentPosition];
                    } 
                }
                if (currentSum > maxSum)
                {
                    maxSum = currentSum;
                }

            }
        }
        Console.WriteLine(maxSum);
    }

    static int[] SplitArray(string input)
    {
        string[] splitted = (input).Trim().Split(',');
        int[] intArray = new int[splitted.Length];

        for (int i = 0; i < splitted.Length; i++)
        {
            intArray[i] = int.Parse(splitted[i]);
        }
        return intArray;
    }
}

