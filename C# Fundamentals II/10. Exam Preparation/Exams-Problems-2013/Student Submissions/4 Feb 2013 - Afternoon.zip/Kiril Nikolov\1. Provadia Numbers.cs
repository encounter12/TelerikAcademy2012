using System;
using System.Text;
class Program
{
    static void Main()
    {
        ulong num = ulong.Parse(Console.ReadLine());
        short digit;
        StringBuilder sb = new StringBuilder();
        if (num == 0)
        {
            Console.WriteLine("A");
        }
        while (num > 0)
        {
            digit = (short)(num % 256);
            sb.Insert(0, (char)('A' + digit % 26));
            if (digit / 26 > 0)
            {
                sb.Insert(0, (char)('a' + digit / 26 - 1));
            }
            num /= 256;
        }
        Console.WriteLine(sb.ToString());
    }
}
