using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Linq.Expressions;

namespace _02.Midget
{
 
    class Program
    {
        static string RemoveSpaces(string pattern)
        {
            StringBuilder str2 = new StringBuilder(pattern);
            for (int j = 0; j < str2.Length; j++)
            {
                if (str2[j] == ' ')
                {
                    str2.Remove(j, 1);
                    j--;
                }
            }

            return pattern;
        }
        static void Main(string[] args)
        {
            string valley = Console.ReadLine();
            int counter = 0;
            ulong maxSum = 0;
            StringBuilder str = new StringBuilder(valley);
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == ' ')
                {
                    str.Remove(i, 1);
                    i--;
                }
            }
            valley = str.ToString();
            int[] valleyArray = valley.Split(',').Select(n => Convert.ToInt32(n)).ToArray();
            ulong sum = 0;
            int numberOfPatterns = 0;
            numberOfPatterns = int.Parse(Console.ReadLine());
            string[] patterns =  new string[numberOfPatterns];
           
           for (int i = 0; i < numberOfPatterns; i++)
            {
                patterns[i] = Console.ReadLine();
            } 
            for (int i = 0; i < numberOfPatterns; i++)
            {
                patterns[i] = RemoveSpaces(patterns[i]);
                int[] patternArray = patterns[i].Split(',').Select(n => Convert.ToInt32(n)).ToArray();
                int[] tempValley = new int[valleyArray.Length];
                for (int p = 0; p < valleyArray.Length; p++)
                {
                    tempValley[p] = valleyArray[p];
                }
                int k=0;
                while(k<tempValley.Length)
                {
                    if (counter >= patternArray.Length)
                        counter = 0;
                    if (tempValley[k] == 0)
                        break;
                    sum += (ulong)tempValley[k];
                    tempValley[k] = 0;
                    if (k + patternArray[counter] > valleyArray.Length)
                        break;
                    k += patternArray[counter];
                    if (counter < patternArray.Length - 1)
                        counter++;
                    else
                        counter = 0;
                }
                        
                
                if (maxSum < sum)
                {
                    maxSum = sum;
                }
                sum = 0;
                counter = 0;
                k = 0;
            }
            Console.WriteLine(maxSum);
        }
    }
}