using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class AlignBoth
{
    static void Main()
    {
        uint N = uint.Parse(Console.ReadLine());
        uint W = uint.Parse(Console.ReadLine());
        string inputText = "";
        for (int i = 0; i < N; i++)
        {
            inputText += Console.ReadLine();
            inputText += " ";
        }

        List<string> NewLine = new List<string>();

        string[] Words = inputText.Split();
        for (int i = 0; i < Words.Length; i++)
        {
            if (Words[i].Length > W)
            {
                W = (uint)Words[i].Length;
            }
        }

        string tempSentence = "";
        for (int i = 0; i < Words.Length; i++)
        {
            if ((tempSentence.Length + Words[i].Length) < W)
            {
                tempSentence += Words[i];
                tempSentence += " ";
                continue;
            }
            else
            {
                NewLine.Add(tempSentence);
                tempSentence = "";
            }
        }
        NewLine.Add(tempSentence);


        for (int i = 0; i < NewLine.Count; i++)
        {
            if ((NewLine[i].Length) < W)
            {
                JustifyIt(NewLine[i], W);
            }
        }

        foreach (var item in NewLine)
        {
            Console.WriteLine(item);
        }
    }

    private static void JustifyIt(string s, uint count)
    {
        int middle = s.Length / 2;
        IDictionary<int, int> spaceOffsetsToParts = new Dictionary<int, int>();
        String[] parts = s.Split(' ');
        for (int partIndex = 0, offset = 0; partIndex < parts.Length; partIndex++)
        {
            spaceOffsetsToParts.Add(offset, partIndex);
            offset += parts[partIndex].Length + 1;
        }
        foreach (var pair in spaceOffsetsToParts.OrderBy(entry => Math.Abs(middle - entry.Key)))
        {
            count--;
            if (count < 0)
                break;
            parts[pair.Value] += ' ';
        }

        String.Join(" ", parts);
    }
}
