using System;
using System.Collections.Generic;

public class DecimalToProvadian
{
    public static void Main(string[] args)
    {
        int number = int.Parse(Console.ReadLine());
        List<int> hexa = new List<int>();
        if (number == 0)
        {
            Console.WriteLine("A");
            return;
        }
        while (number > 0)
        {
            hexa.Add(number % 256);
            number = number / 256;
        }

        hexa.Reverse();
        foreach (var digit in hexa)
        {
            if (digit < 26)
            {
                Console.Write((char)(digit + 65));
            }
            else
            {


                Console.WriteLine("aE");
            }
            //else 
            //{
            //    while (digit>25)
            //    {
            //        hexa.Add(digit % 26);
            //        number = digit / 26;
            //        Console.Write((char)(number + 96));
            //        continue;
            //    }
        }
        Console.WriteLine();
    }

    
    

}