using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

class Program
{
	static void Main(string[] args)
	{	
		BigInteger number = BigInteger.Parse(Console.ReadLine());
		var baseNumber = 256;
		var baseAsDouble = 256d;
		var builder = new StringBuilder();

		if (number < baseNumber)
		{
			Console.WriteLine(ConvertToProvadia(number));
			return;
		}
		bool shouldRaiseFlag = false;
		bool flag = true;
		while (flag)
		{
			var quotient = number % baseNumber;
			builder.Insert(0, ConvertToProvadia(quotient));
			number /= baseNumber;

			
			if (shouldRaiseFlag)
				flag = false;

			if (number < baseNumber)
				shouldRaiseFlag = true;
		}
		Console.WriteLine(builder.ToString());
		
	}

	static string ConvertToProvadia(BigInteger number)
	{
		char A = 'A';
		if (number == 0)
			return A.ToString();

		var remainder = number % 26;
		var quotient = number / 26;
		string result = string.Empty;
		if (quotient != 0)
		{
			char prefix = (char) (A + 32 + quotient - 1);
			char letter = (char) (A + remainder );
			result += prefix.ToString();
			result += letter.ToString();
		}
		else
		{
			char letter = (char) (A + remainder);
			result += letter.ToString();
		}
		return result;
	}

}
