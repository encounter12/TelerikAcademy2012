using System;
using System.Numerics;

class ProvadiaNumbers
{
    static void Main()
    {
        string[] digits = new string[256];
        for (int i = 0; i < 26; i++)
        {
            char a = (char)(65 + i);
            digits[i] += a;
        }
        for (int i = 26; i < 256; i++)
        {
            char a = (char)(96 + (i / 26));
            char b = (char)(65 + (i % 26));
            digits[i] += a;
            digits[i] += b;
        }

        BigInteger input = BigInteger.Parse(Console.ReadLine());
        int count = 0;
        BigInteger comparer = 1;
        while (comparer <= input)
        {
            comparer *= 256;
            count++;
        }
        byte[] positions = new byte[count];
        for (int i = count - 1; i > 0; i--)
        {
            Console.Write(digits[(int)(input / (BigInteger)Math.Pow(256, i))]);
            input %= (BigInteger)Math.Pow(256, i);
        }
        Console.Write(digits[(int)input]);

   }
}