using System;
using System.Linq;

class Program
{
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
#endif

        long joroTaskNumbers = long.Parse(Console.ReadLine());

        string firstCommand = Console.ReadLine();
        string secondCommand = Console.ReadLine();

        bool[] numbers = new bool[joroTaskNumbers];
        int lastIndex = 0;
        int offset = 2;
        int nextNumber = 0;
        bool noNumbers = false;
        int index = 0;
        int startIndex = 0;
        while (true)
        {
            noNumbers = true;
            for (int i = startIndex; i < numbers.Length; i++)
            {
                if (!numbers[i])
                {
                    if (index == nextNumber)
                    {
                        numbers[i] = true;
                        noNumbers = false;
                        lastIndex = i;
                        nextNumber += offset;
                    }
                    index++;
                }
            }
            startIndex++;
            index = 0;
            offset++;
            nextNumber = 0;
            if (noNumbers)
            {
                break;
            }
        }

        Console.WriteLine(lastIndex + 1);
        CheckBinding(firstCommand);
        CheckBinding(secondCommand);
    }

    static void CheckBinding(string command)
    {
        if (command.Split('S').Length == 1)
        {
            Console.WriteLine("bounded");
        }
        if (command.Split(new char[] { 'L', 'R' }, StringSplitOptions.None).Length == 1)
        {
            Console.WriteLine("unbounded");
        }
        else
        {
            Console.WriteLine("bounded");
        }
    }
}
