using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NextTask
{
    class Program
    {
        static void Main(string[] args)
        {

            int maxGold = int.MinValue;
            int currentGold = 0;


            char[] separator = new char[] { ',', ' ' };
            string val = Console.ReadLine();
            short patterns = short.Parse(Console.ReadLine());
            string[] vall = val.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            short[] valleyOriginal = new short[vall.Length];
            for (int j = 0; j < vall.Length; j++)
            {
                valleyOriginal[j] = short.Parse(vall[j]);
            }



            for (short i = 0; i < patterns; i++)
            {
                currentGold = 0;
                short currentPosition = 0;
                short currentPatternPosition = 0;

                short[] valley = (short[])valleyOriginal.Clone();
                

                string currentPattern = Console.ReadLine();
                string[] splitter = currentPattern.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                short[] pattern = new short[splitter.Length];
                for (short j = 0; j < splitter.Length; j++)
                {
                    pattern[j] = short.Parse(splitter[j]);
                }



                while (true)
                {
                    //Console.WriteLine("1");
                    //ako sym minaval prez taq kletka breakvam
                    if (valley[currentPosition] == 10000)
                    {
                        break;
                    }

                    //Console.WriteLine("12");

                    currentGold += valley[currentPosition];
                    //zanulqvam kletkata prez koqto sym minal
                    valley[currentPosition] = 10000;
                    //proverqvam da ne sym izlqzal ot granicite na dolinata
                    if ((currentPosition + currentPatternPosition) >= valley.Length || (currentPosition + currentPatternPosition) < 0)
                    {
                        break;
                    }
                    // Console.WriteLine("123");

                    //prisvoqvam novoto polojienie v dolinata
                    if (currentPatternPosition >= pattern.Length)
                    {
                        currentPatternPosition = 0;
                    }
                    currentPosition += pattern[currentPatternPosition];
                    currentPatternPosition++;

                    //Console.WriteLine("1234");
                }
                if (currentGold > maxGold)
                {
                    maxGold = currentGold;
                }
            }
            Console.WriteLine(maxGold);
        }


    }
}