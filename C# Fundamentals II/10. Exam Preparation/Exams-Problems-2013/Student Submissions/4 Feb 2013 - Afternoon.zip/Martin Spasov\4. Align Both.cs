using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace _01.Task1
{
    class Program
    {
       
       
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int delitel = int.Parse(Console.ReadLine());
            List<string> str = new List<string>();
            StringBuilder stringBuilder = new StringBuilder();
            int count = 0;

            for (int i = 0; i < N; i++)
            {
                str.Add(Console.ReadLine());    
                
            }

            

            for (int j = 0; j < str.Count; j++)
            {
                stringBuilder.Append(str[j] + " ");   
            }

            string text = stringBuilder.ToString();
            char[] charsToTrim = {' ','\t' };
            string result = text.Trim(charsToTrim);
            
            List<string> a = result.ToCharArray().Select((c, i) => new { Char = c, Index = i }).GroupBy(o => o.Index / delitel).Select(g => new String(g.Select(o => o.Char).ToArray())).ToList();
            for (int c = 0; c < a.Count; c++)
            {
                Console.WriteLine(a[c]);
            }

            
        }
    }
}
