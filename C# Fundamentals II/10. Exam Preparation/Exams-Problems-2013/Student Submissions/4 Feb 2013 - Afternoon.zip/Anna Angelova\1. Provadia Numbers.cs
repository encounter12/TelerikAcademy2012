using System;

class Program
{
    public static string[] provadiaNumbers = new string[256];

    public static string ProvadiaNum(ulong number, string provNum)
    {
        if (number / 256 == 0) return (provadiaNumbers[number % 256]+provNum);
        else
        {
            return ProvadiaNum((number / 256), provadiaNumbers[(number % 256)]+provNum);
        }
    }

    public static void Main(string[] args)
    {
        for (int i = 0; i < 26; i++)
        {
            provadiaNumbers[i] = ((char)(i + 65)).ToString();   
        }
        for (int i = 26; i < provadiaNumbers.Length; i++)
        {   

            provadiaNumbers[i] = ((char)(i/26+96)).ToString()+provadiaNumbers[i%26];
        }
        ulong number = ulong.Parse(Console.ReadLine());
        string provNum = "";
        
        Console.WriteLine(ProvadiaNum(number, provNum));
    }
}
