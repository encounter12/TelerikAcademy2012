using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApplication1
{
    internal class Program
    {
        private static void Main()
        {
            var valley = Console.ReadLine().Replace('.', ',').Split(',').ToList();
            var paternsNumber = Int16.Parse(Console.ReadLine());

            var sums = new List<int>();

            for (var i = 0; i < paternsNumber; i++)
            {
                sums.Add(SumCointsDown(valley, Console.ReadLine().Replace('.', ',').Split(',').ToList()));
            }
            Console.WriteLine(sums.Max());
        }

        private static int SumCointsDown(List<string> val, List<string> patern)
        {
            var sumDown = Int16.Parse(val[0]);
            var curentPosition = 0;
            for (byte i = 0; i < patern.Count; i++)
            {
                if (curentPosition == 0 || patern.Contains(curentPosition.ToString()))
                {
                    break;
                }

                if (i + 1 < patern.Count)
                {
                    curentPosition += int.Parse(patern[i]);
                    sumDown += Int16.Parse(val[curentPosition]);
                }
                else
                {
                    curentPosition += int.Parse(patern[i]);
                }
            }

            Int16 sumUp = 0;

            for (byte i = 0; i < patern.Count; i++)
            {
                if (curentPosition == 0 || patern.Contains(curentPosition.ToString()))
                {
                  //  sumUp = 0;
                    break;
                }

                sumUp += Int16.Parse(val[curentPosition]);
                curentPosition += Int16.Parse(patern[i]);
            }

            return sumDown + sumUp;
        }
    }
}