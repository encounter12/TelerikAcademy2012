using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main()
        {
            string sequence = Console.ReadLine();
            string[] valley = sequence.Split(',');

            int M = int.Parse(Console.ReadLine());
            string[] pattern = new string[M];
            for (int i = 0; i < M; i++)
            {
                pattern[i] = Console.ReadLine();
            }
}
}