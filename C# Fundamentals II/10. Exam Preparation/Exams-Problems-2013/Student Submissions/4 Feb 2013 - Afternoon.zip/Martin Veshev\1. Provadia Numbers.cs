using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;


class ProvadiaNumbers
{
    static void Main()
    {
        BigInteger numberInput = BigInteger.Parse(Console.ReadLine());
        string[] numbers = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
        string[] numbersSmall = { "", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
        List<string> provadia = new List<string>();
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < numbersSmall.Length; i++)
        {
            for (int j = 0; j < numbers.Length; j++)
            {

                if (provadia.Count() < 256)
                {
                    str.Append(numbersSmall[i]);
                    str.Append(numbers[j].ToUpper());
                    provadia.Add(str.ToString());
                    str.Clear();
                }
            }
        }

        //foreach (var item in provadia)
        //{
        //    Console.WriteLine(item);
        //}
        StringBuilder fin = new StringBuilder();
        if (numberInput == 0)
        {
            Console.WriteLine(provadia[0]);
        }
        else
        {

            while (numberInput > 0)
            {

                fin.Insert(0, provadia[(int)(numberInput % 256)]);
                numberInput = numberInput / 256;
            }
            Console.WriteLine(fin);
        }

        

        //for (int i = fin.Length-1; i >=0; i--)
        //{
        //    Console.Write(fin[i]);
        //}
        //Console.WriteLine();


    }
}
