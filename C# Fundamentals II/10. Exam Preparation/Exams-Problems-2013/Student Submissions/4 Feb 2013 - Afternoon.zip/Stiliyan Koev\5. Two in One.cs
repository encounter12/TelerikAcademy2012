using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace _5.TwoInOne
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime now = DateTime.Now;
            int N = int.Parse(Console.ReadLine());
            Console.WriteLine(TIO(N));
            

        }
        static int TIO (int N)
        {
            bool[] TurnedOff = new bool[N + 1];
            TurnedOff[0] = true;
            int counter = 2;
            List<int> TurnedOn = new List<int>();
            int pos = 1;


            if (TurnedOn.Capacity != N)
            {
                for (int q = 1; q < N; q++)
                {
                    for (int i = 1; pos <= N; pos++)
                    {

                        if (TurnedOff[pos] == false)
                        {
                            if (counter == q + 1)
                            {
                                TurnedOff[pos] = true;
                                TurnedOn.Add(pos);

                                counter = 1;
                            }
                            else
                            {

                                counter++;
                            }

                        }
                    }
                    pos = 1;
                    counter = q + 2;
                }
            }
               
            
            return TurnedOn[TurnedOn.Count - 1];
                
        }
    }
}
