using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02.Midget
{
    class Program
    {
        static void Main(string[] args)
        {
            //string numbers = Console.ReadLine(); 
            string numbers = " 1, 3, -6, 7, 4, 1, 12 "; //пътеката
            char separator = ',';
            string[] valleyString = numbers.Split(separator);
            int[] valley = new int[valleyString.Length];
            int j = 0;
            foreach (String text in valleyString)
            {
                int.TryParse(text, out valley[j]);
                ++j;
            }
          /*
            foreach (int number in valley)
            {

                Console.WriteLine(number);

            }
            */
            
            int numbersOfPatterns = int.Parse(Console.ReadLine());


            StringBuilder stringPatterns = new StringBuilder();
            for (int i = 0; i < numbersOfPatterns; i++)
            {
                string patternLines = Console.ReadLine();
                stringPatterns.AppendFormat("{0}", patternLines);
            }

            string[] paternToParse = stringPatterns.ToString().Split(separator);
            int[] pattern = new int[paternToParse.Length];
            int k = 0;
            foreach (String text in paternToParse)
            {
                int.TryParse(text, out pattern[k]);
                ++k;
            }


            int coins = 0;

            for (int i = 0; i < valley.Length; i++)
            {
                coins = coins + valley[0];
                for (int p = 0; p < pattern.Length; p++)
                {
                    coins = coins + valley[i + pattern[p]];
                }
            } 
            Console.WriteLine(coins);
            
        }
    }
}
