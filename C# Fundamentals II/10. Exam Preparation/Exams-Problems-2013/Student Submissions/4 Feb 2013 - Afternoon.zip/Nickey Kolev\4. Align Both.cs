using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Align
{
	class Align
	{
		static void Main(string[] args)
		{
			int numRows = int.Parse(Console.ReadLine());
			int rowSymbols = int.Parse(Console.ReadLine());

			StringBuilder inputText = new StringBuilder();

			for (int inputRow = 0; inputRow < numRows; inputRow++)
			{
				inputText.AppendLine(Console.ReadLine());
			}

			//string[] words = inputText.ToString().Split();

			int remRowSymbols = rowSymbols;
			int currSpaces = 0;

			StringBuilder justifiedRow = new StringBuilder();

			//for (int word = 0; word < words.Length; word++)
			//{
				
			//}
		}
	}
}
