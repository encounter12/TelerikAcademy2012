using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Problem4
{
    static int ordinaryGap = 0;
    static int differenceGap = 0;

    static void Main()
    {
        int numberN = int.Parse(Console.ReadLine());
        int numberW = int.Parse(Console.ReadLine());
        List<string> wordsInText = new List<string>();
        for (int i = 0; i < numberN; i++)
        {
            string lineToRead = Console.ReadLine();
            char[] delimiters = new char[] { ' ' };
            string[] words = lineToRead.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
            foreach (string item in words)
            {
                wordsInText.Add(item);
            }
        }
        int counter = 0;
        int secondCounter = 0;
        List<string> line = new List<string>();
        for (int i = 0; i < wordsInText.Count; i++)
        {
            if (counter == 0)
            {
                AddWord(wordsInText, ref counter, ref secondCounter, line, i);
            }
            else if (wordsInText[i].Length + counter + 1 <= numberW)
            {
                AddWord(wordsInText, ref counter, ref secondCounter, line, i);
            }
            else
            {
                if (line.Count == 1)
                {
                    PrintOneLine(ref counter, ref secondCounter, line, ref i);
                }
                else
                {
                    PrintLine(numberW, ref counter, ref secondCounter, line, ref i);
                }
            }
        }
        if (line.Count == 1)
        {
            Console.WriteLine(line[0]);
        }
        else if (line.Count == 0)
        {

        }
        else
        {
            int x = 0;
            PrintLine(numberW, ref counter, ref secondCounter, line, ref x );
        }


    }

    private static void AddWord(List<string> wordsInText, ref int counter, ref int secondCounter, List<string> line, int i)
    {
        line.Add(wordsInText[i]);
        if (line.Count == 1)
        {
            counter = counter + wordsInText[i].Length;
            secondCounter = secondCounter + wordsInText[i].Length;
        }
        else
        {
            counter = counter + wordsInText[i].Length + 1;
            secondCounter = secondCounter + wordsInText[i].Length;
        }

    }

    private static void PrintOneLine(ref int counter, ref int secondCounter, List<string> line, ref int i)
    {
        Console.WriteLine(line[0]);
        line.Clear();
        counter = 0;
        secondCounter = 0;
        i--;
    }

    private static void PrintLine(int numberW, ref int counter, ref int secondCounter, List<string> line, ref int i)
    {
        secondCounter = numberW - secondCounter;
        ordinaryGap = secondCounter / (line.Count - 1);
        string gap = new String(' ', ordinaryGap);
        differenceGap = secondCounter % (line.Count - 1);
        for (int z = 0; z < line.Count; z++)
        {
            if (z == line.Count - 1)
            {
                Console.Write(line[z]);
            }
            else
            {
                Console.Write(line[z]);
                Console.Write(gap);
                if (differenceGap > 0)
                {
                    Console.Write(' ');
                    differenceGap--;
                }
            }


        }
        Console.Write("\r\n");
        line.Clear();
        counter = 0;
        secondCounter = 0;
        i--;
    }
}