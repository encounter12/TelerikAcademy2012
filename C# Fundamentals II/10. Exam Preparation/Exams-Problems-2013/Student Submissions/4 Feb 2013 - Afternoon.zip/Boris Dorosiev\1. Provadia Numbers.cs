using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            //string valley = "1, 3, -6, 7, 4,1,12";
            //int m = 3;

            Console.WriteLine("Enter the valley: ");
            string valley = Console.ReadLine();
            string[] arguments = new string[] { " ", "," };
            string[] valleyArr = valley.Split(arguments, StringSplitOptions.RemoveEmptyEntries);
            Console.WriteLine("Enter number of patterns : ");
            int m = int.Parse(Console.ReadLine());
            string pattern = "";
            int checker = int.MinValue;
            int maxSum = int.MinValue;
            int checkSum = int.MinValue;
            for (int p = 0; p < m; p++)
            {
                checker = checkValley(arguments, valleyArr, m, checkSum, pattern, p);
                if (checker > maxSum)
                {
                    maxSum = checker;
                }
            }
            Console.WriteLine(maxSum);

        }

        static int checkValley(string[] arguments, string[] valleyArr, int m, int checkSum, string pattern, int p)
        {
            Console.WriteLine("Enter pattern {0}", p + 1);
            pattern = Console.ReadLine();
            string[] patternEdit = pattern.Split(arguments, StringSplitOptions.RemoveEmptyEntries);
            int[] ints1 = patternEdit.Select(x => int.Parse(x)).ToArray();
            int index = 0;
            int lastindex = 0;
            int sum = 0;
            bool hasMore = true;
            bool play = true;
            List<int> resultList = new List<int>();
            //for (int z = 1; z < m; z++)
            //{
            //play = true;

            while (play)
            {
                resultList.Add(int.Parse(valleyArr[0]));
                for (int i = 0; i < ints1.Length; i++)
                {
                    if (ints1[i] < 0)
                    {
                        index = lastindex + ((int)ints1[i]);
                        lastindex = index;
                        for (int k = 0; k < resultList.Count; k++)
                        {
                            if ((int.Parse(valleyArr[index]) == resultList[k]))
                            {
                                hasMore = false;
                                break;
                            }
                        }


                    }
                    else
                    {
                        index = i + ((int)ints1[i]);
                        lastindex = index;
                        resultList.Add(int.Parse(valleyArr[index]));
                    }
                }
                if (hasMore == true)
                {
                    resultList.Add(int.Parse(valleyArr[index]));
                    for (int i = 0; i < ints1.Length; i++)
                    {
                        if (ints1[i] < 0)
                        {
                            index = lastindex + ((int)ints1[i]);
                            lastindex = index;
                            for (int k = 0; k < resultList.Count; k++)
                            {
                                if ((int.Parse(valleyArr[index]) == resultList[k]))
                                {
                                    hasMore = false;
                                    break;
                                }

                            }

                        }
                        else
                        {
                            index = lastindex + ((int)ints1[i]);
                            lastindex = index;
                            resultList.Add(int.Parse(valleyArr[index]));
                        }
                    }
                }

                foreach (var num in resultList)
                {
                    sum += num;
                }
                play = false;
            } if (sum > checkSum)
            {
                checkSum = sum;
            } return checkSum;
        }

    }
}
