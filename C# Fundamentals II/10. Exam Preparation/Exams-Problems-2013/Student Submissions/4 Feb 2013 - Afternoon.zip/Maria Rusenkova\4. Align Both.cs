using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02.Problem2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int w = int.Parse(Console.ReadLine());
            string[] input = new string[n];

            for (int i = 0; i < n; i++)
            {
                input[i] = Console.ReadLine();
            }            
           
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < n; i++)
            {
                string[] words = input[i].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                foreach (var item in words)
                {                   
                    sb.Append(item + " ");
                }             
            }
            string str = sb.ToString();
            int index = 0;
            int startIndex = 0;
            string[] result = new string[n];
            string sub = "";
            for (int i = 0; i < result.Length; i++)
            {
                if (startIndex + w+1 < str.Length)
                {

                    sub = str.Substring(startIndex, w+1);
                    index = sub.LastIndexOf(' ');
                    sub = sub.Remove(index);
                    sub = sub.Trim();

                    result[i] = sub;
                    //sub = "";
                    startIndex += index;
                    Console.WriteLine(result[i]);
                }
                else
                {
                    sub = str.Substring(startIndex);
                    sub = sub.Trim();
                    result[i] = sub;
                    Console.WriteLine(result[i]);
                }
            }
        }
    }
}
