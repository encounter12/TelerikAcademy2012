using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_1_ProvadiaNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
             string[] numbers=new string[256];

             for (int i = 0; i < 26; i++)
             {
                 numbers[i] = ((char)(65+i)).ToString(); 
             }

             StringBuilder nnn = new StringBuilder();
             for (int j = 26; j < 256; j++)
             {
                 int a = j % 26;
                 int b = j / 26;
                 nnn.Append(((char)(b + 96)).ToString());
                 nnn.Append( numbers[a]);
                 numbers[j] =nnn.ToString();
                 nnn.Clear();
             }

            decimal num = decimal.Parse(Console.ReadLine());
            string result = "";
            if (num == 0)
                result = numbers[0];

            while (num>0)
                {
                    int k = (int)(num % 256);
                    num = Math.Floor(num / 256); 
                    result = string.Concat(numbers[k], result);
                }
            Console.WriteLine(result);  
         }
    }
}
