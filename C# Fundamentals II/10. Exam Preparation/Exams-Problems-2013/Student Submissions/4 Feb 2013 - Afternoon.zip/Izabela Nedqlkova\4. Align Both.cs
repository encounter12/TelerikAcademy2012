using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Task4AlignBoth
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberLines = int.Parse(Console.ReadLine());
            int maximalSymbolsOnLine = int.Parse(Console.ReadLine());
            string[] lines = new string[numberLines];
            List<string> words = new List<string>();
            for (int i = 0; i < numberLines; i++)
            {
                lines[i] = Console.ReadLine();
                string[] wordsOnLine = Regex.Split(lines[i], @"\s+");
                for (int j = 0; j < wordsOnLine.Length; j++)
                {
                    words.Add(wordsOnLine[j]);
                }
            }
            for (int i = 0; i < words.Count; i++)
            {
                Console.WriteLine(words[i]);
            }

            int index = 0;
            for (int i = 0; i < lines.Length; i++)
            {
                int lengthWordsTogether = 0;
                int minGapsCount = 0;
              
                StringBuilder result = new StringBuilder();
                //for (int i = 0; i < words.Count; i++)
                //{
                while ((lengthWordsTogether + minGapsCount + words[index].Length) <= maximalSymbolsOnLine)
                {
                    lengthWordsTogether += words[index].Length;
                    result.Append(words[index]);
                    result.Append(" ");
                    minGapsCount++;
                    index++;
                    if (index == maximalSymbolsOnLine - 1)
                    {
                        break;
                    }
                    //Console.WriteLine(lengthWordsTogether);
                }
                lines[i] = result.ToString();
                lines[i] = lines[i].PadRight(20, ' ');
                int spaceIndex = 0;
                int lastSpaceIndex = 0;
                while (lines[i][lines[i].Length - 1] == ' ')
                {
                    Console.WriteLine(spaceIndex);
                    
                    
                    spaceIndex = lines[i].IndexOf(' ', spaceIndex);
                    if (spaceIndex == maximalSymbolsOnLine - 1)
                    {
                        break;
                    }
                    if (spaceIndex == -1)
                    {
                        if (lines[i].Length > maximalSymbolsOnLine)
                        {
                            break;
                            //Console.WriteLine("baba");
                        }
                        else
                        {
                            spaceIndex = lastSpaceIndex;
                        }
                    }
                    
                    lines[i] = lines[i].Insert(spaceIndex, " ");
                    lines[i] = lines[i].Remove(lines[i].Length - 1);
                    spaceIndex += 2;
                    lines[i] = lines[i].TrimStart();
                    if (lines[i].Length > maximalSymbolsOnLine)
                    {
                        break;
                        //Console.WriteLine("baba");
                    }

                }
                //}
                Console.WriteLine(lines[i].ToString());
            }
        }
    }
}
