using System;

class Provadia
{
    static char ToChar(int n)
    {
        return (char)(n+65);
    }
    static void Main()
    {
        int number = int.Parse(Console.ReadLine());
        if (number < 26)
        { 
            Console.WriteLine(ToChar(number)); 
        } 
    }
}
