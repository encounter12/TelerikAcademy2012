using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace _1.Numbers
{
    class Numbers
    {
        static void Main(string[] args)
        {
            ulong number = ulong.Parse(Console.ReadLine());
 
            string[] digits = new string[260];
            int index = 0;
 
            for (char i = 'A'; i <='Z' ;  i++)
            {
                digits[index] = i.ToString();
                index++;
                 
            }
             
            for (char i = 'a'; i <= 'i' ; i++)
            {
                for (char j = 'A'; j <= 'Z' ; j++)
                {
                    digits[index] = i.ToString() + j.ToString();
                    index++;
                }
 
            }
 
            string pNumber ="" ;

            if (number == 0)
            {
                pNumber = "A";
            }

                while (number > 0)
                {
                    byte remainder = (byte)(number & 255);

                    pNumber = digits[remainder] + pNumber;
                                        
                    number = number >> 8;
                }
 
                     
            
             
 
            Console.WriteLine(pNumber);
 
 
 
        }
    }
}