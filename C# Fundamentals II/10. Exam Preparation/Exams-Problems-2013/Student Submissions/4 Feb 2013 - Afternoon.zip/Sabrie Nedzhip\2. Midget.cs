using System;

class Ex2
{
    static void Main()
    {
        string valley = Console.ReadLine();

        int m = int.Parse(Console.ReadLine());
        string[] patterns = new string[m];

        for (int i = 0; i < patterns.Length; i++)
        {
            patterns[i] = Console.ReadLine();
        }

        string[] tokens = valley.Split(',');
        int[] valleyArr = new int[tokens.Length];

        // fill the valley with numbers
        for (int i = 0; i < tokens.Length; i++)
        {
            valleyArr[i] = int.Parse(tokens[i].Trim());
        }

        int currentCoins = 0;
        int maxCoins = 0;
        for (int index = 0; index < patterns.Length; index++)
        {
            string patAtIndex = patterns[index];
            string[] tokensPat = patAtIndex.Split(',');
            int[] patArr = new int[tokensPat.Length];
            int counter = 0;
            currentCoins = 0;
            int[] valleyCopy = new int[valleyArr.Length];
            
            for (int i = 0; i < valleyArr.Length; i++)
            {
                valleyCopy[i] = valleyArr[i];
            }

            for (long i = 0; i < valleyArr.Length; i++)
            {                
                patArr[i % patArr.Length] = int.Parse(tokensPat[i % patArr.Length].Trim());
                currentCoins = currentCoins + valleyCopy[counter];
                valleyCopy[counter] = -1111;
                counter = counter + patArr[i % patArr.Length];
                if (counter >= valleyArr.Length || counter < 0)
                {
                    break;
                }
                if (valleyCopy[counter] == -1111)
                {
                    break;
                }
            }
            if (currentCoins > maxCoins)
            {
                maxCoins = currentCoins;
            }
        }
        Console.WriteLine(maxCoins);
    }
}
