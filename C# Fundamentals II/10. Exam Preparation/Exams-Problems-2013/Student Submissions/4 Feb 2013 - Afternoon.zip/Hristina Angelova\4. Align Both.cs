using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AlignBoth
{
    class AlignBoth
    {
        static string[] separators = new string[] { " ", "\n" };
        static void Main()
        {
            StringBuilder sb = new StringBuilder();
            int rowNumber = int.Parse(Console.ReadLine());
            int signInline = int.Parse(Console.ReadLine());
            for (int i = 0; i < rowNumber; i++)
            {
                sb.Append(Console.ReadLine());
            }

            string[] text = sb.ToString().Split(separators, StringSplitOptions.RemoveEmptyEntries);

            sb.Clear();

            for (int i = 0; i < text.Length - 1;)
            {
                StringBuilder line = new StringBuilder(text[i]);
                line.Append(" ");
                for (int j = i + 1; j < text.Length; j++)
                {
                    if ((line.Length + text[j].Length) <= signInline)
                    {
                        line.Append(text[j]);
                        line.Append(" ");
                    }
                    else
                    {
                        if (line.Length != signInline)
                        {
                            string spacePattern = " ";
                            int spaces = signInline - line.Length;
                            int indexNext = line.ToString().IndexOf(spacePattern);
                            while (spaces > 0)
                            {
                                if (indexNext < 0)
                                {
                                    spacePattern += " ";
                                    indexNext = line.ToString().IndexOf(spacePattern);
                                }   
                                line.Replace(spacePattern, spacePattern + " ", indexNext, 1);
                                spaces--;
                                indexNext = (indexNext < line.Length - 1) ? line.ToString().IndexOf(spacePattern, indexNext + 1) : -1;
                            }
                            
                        }
                        sb.AppendLine(line.ToString());
                        i = j;
                        break;
                    }
                }
            }          
            Console.Write(sb.ToString());
        }

        
    }
}
