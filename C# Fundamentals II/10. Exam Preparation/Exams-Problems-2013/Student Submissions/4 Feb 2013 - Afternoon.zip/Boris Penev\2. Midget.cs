using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midget
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] separators = new char[] {' ', ','};
            string input = Console.ReadLine();
            string[] vally = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);

            int M = int.Parse(Console.ReadLine());
            long coinsCollected = 0;
            long maxCoin = long.MinValue;
            long firstCoin ;
            ///////////////////////////////////////
            string[][] jaggedArray;
            jaggedArray = new string[M][];
            for (int pat = 0; pat < M; pat++)
			{
			    string pattern = Console.ReadLine();
                jaggedArray[pat] = pattern.Split(separators, StringSplitOptions.RemoveEmptyEntries);                
			}
            //////////////////////////////////////////
            string isVisited = "1";
            string[] visited = new string[vally.Length];
            ////////////////////////////////////////
            
            
            int i = 0;
                firstCoin = Convert.ToInt32(vally[i]);
                visited[0] = "1";
                for (int jagg = 0; jagg < M; jagg++)
			    {
                    visited[0] = "1";
                    
                    for (int patt = 0; patt < jaggedArray[jagg].Length; )
			        {
                        i = i + Convert.ToInt32(jaggedArray[jagg][patt]);
                        //if (visited[i] != "1")
                        //{
                        //    patt = 0;
                        //}
                        if (i >= vally.Length || visited[i] == "1")
                        {
                            break;//ako prehvarlim max vally krai
                        }
                        else if (visited[i] != isVisited)                      
                        {
                            
                            visited[i] = isVisited;
                            coinsCollected += Convert.ToInt64(vally[i]);
                            patt++;                            
                        }
                        //if (patt == 2)
                        //{
                        //    patt = 0;
                        //}
                        
			        }
                    
                    coinsCollected += firstCoin;                    
                    if (maxCoin < coinsCollected)
                    {
                        maxCoin = coinsCollected;
                    }
                    //Console.WriteLine(maxCoin);
                    coinsCollected = 0;
                    i = 0;
                    for (int vis = 0; vis < vally.Length; vis++)
                    {
                        visited[vis] = "";
                    }                    
			    }                
            Console.WriteLine(maxCoin);
        }
    }
}
