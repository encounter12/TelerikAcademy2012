using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem2_Midget
{
    class Program
    {
        static void Main(string[] args)
        {
            string valley;
            int numbPatterns;
            string [] patterns;
            char[] seprators = new char[] { ' ', ',' };
            string[][] splitPatterns;
            string[] splitValley;
            int collectedCoins = 0;
            int maxCoins = 0;
            int index = 0;
            int[] val;


            Console.WriteLine("Enter the numbers of the valley(separated with \", \"): ");
            valley = Console.ReadLine();

            Console.WriteLine("Enter the number of patterns: ");
            numbPatterns = int.Parse(Console.ReadLine());

            patterns = new string[numbPatterns];

            Console.WriteLine("Enter the numbers for the {0} patters (for each pattern on differnt line): ", numbPatterns);

            for (int i = 0; i < numbPatterns; i++)
            {
                patterns[i] = Console.ReadLine();
            }

            splitValley = valley.Split(seprators, StringSplitOptions.RemoveEmptyEntries);
            splitPatterns = new string [numbPatterns][];

            for (int i = 0; i<patterns.Length; i++)
            {
                splitPatterns[i] = patterns[i].Split(seprators, StringSplitOptions.RemoveEmptyEntries);
            }

            /******* start collecting coins by different patterns in the valley ********/

            val = new int[splitValley.Length];

            for (int i = 0; i < splitValley.Length; i++)
            {
                val[i] = int.Parse(splitValley[i]);
            }

                for (int i = 0; i < numbPatterns; i++)
                {
                    collectedCoins = val[0];
                    val[0] = int.MaxValue;

                    for (int j = 0; j < splitPatterns[i].Length; j++)
                    {
                        index += int.Parse(splitPatterns[i][j]);

                        if (index > val.Length - 1)
                        {
                            break;
                        }

                        if (val[index] == int.MaxValue)
                        {
                            break;
                        }

                        collectedCoins += val[index];
                        val[index] = int.MaxValue;

                        if (j == splitPatterns[i].Length - 1)
                        {
                            j = -1;
                        }
                    }

                    if (maxCoins < collectedCoins)
                    {
                        maxCoins = collectedCoins;
                        collectedCoins = 0;
                    }

                    for (int k = 0; k < splitValley.Length; k++)
                    {
                        val[k] = int.Parse(splitValley[k]);
                    }
                }
            Console.WriteLine("The maximal collected coins are:");
            Console.WriteLine(maxCoins);
        }
    }
}
