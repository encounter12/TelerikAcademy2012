using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public static class GlobalData
{
    public static string[] Foo = new string[16];
};
  class Program
    {
 
        static void Main()
        {
            int number = int.Parse(Console.ReadLine());
            StringBuilder strUpper = new StringBuilder();
            strUpper.Append("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
 
 
            StringBuilder strLower = new StringBuilder();
            strLower.Append("ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToLower());
            //Console.WriteLine(strLower);
            StringBuilder result = new StringBuilder();
            StringBuilder result2 = new StringBuilder();
            StringBuilder result3 = new StringBuilder();
            StringBuilder result4 = new StringBuilder();
            if(number < 26)
                Console.WriteLine(strUpper[number]);
            else
                if (number > 25 && number < 52)
                {
                     
                    result.Append(strLower[(number/26)-1]);
                    result.Append(strUpper[number - 26]);
                    Console.WriteLine(result);
                }
            if (number >= 52 && number <= 255)
            {
 
                result.Append(strLower[(number / 26) - 1]);
                result.Append(strUpper[(number%26) ]);
                Console.WriteLine(result);
            }
            else if (number > 255)
            {
                int www = number / 256;
                result.Append(strUpper[www]);
                //Console.WriteLine(result);
                if ((number%256) >= 52 && (number%256) <= 255)
                {
 
                    result2.Append(strLower[((number%256) / 26) - 1]);
                    result2.Append(strUpper[((number%256) % 26)]);
                   // Console.WriteLine(result2);
                }
                result.Append(result2);
                Console.WriteLine(result);
                
            }
        }
    }