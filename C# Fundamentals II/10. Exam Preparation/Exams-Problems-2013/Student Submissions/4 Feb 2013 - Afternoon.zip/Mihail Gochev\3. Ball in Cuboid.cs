
using System;
using System.Linq;

class MaxWalk
{
    static string[, ,] cube;
    static bool[, ,] visited;
    static int inputWidth;
    static int inputHeight;
    static int inputDepth;
    static int LastWidth;
    static int LastHeight;
    static int LastDepth;

    static void Main()
    {

#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
#endif

        string inputString = Console.ReadLine();
        string[] input = inputString.Split(' ');

        inputWidth = int.Parse(input[0]);
        inputHeight = int.Parse(input[1]);
        inputDepth = int.Parse(input[2]);

        cube = new string[inputWidth, inputHeight, inputDepth];
        visited = new bool[inputWidth, inputHeight, inputDepth];


        for (int height = 0; height < inputHeight; height++)
        {
            string line = Console.ReadLine();
            string[] lines = line.Split('|');
            for (int depth = 0; depth < lines.Length; depth++)
            {
                string[] numbers = lines[depth].Split(new string[] { ")(", }, StringSplitOptions.RemoveEmptyEntries);
                for (int width = 0; width < inputWidth; width++)
                {
                    string block = numbers[width];
                    block = block.Replace("(", "").Replace(")", "").Trim();
                    cube[width, height, depth] = block;
                }
            }
        }

        inputString = Console.ReadLine();
        input = inputString.Split(' ');

        int ballW = int.Parse(input[0]);
        int ballD = int.Parse(input[1]);

        LastWidth=ballW;
        LastHeight=0;
        LastDepth = ballD;
        PlayTurn(ballW, 0, ballD);
    }


    static bool OutOfBounds(int width, int height, int depth)
    {
        if (width >= inputWidth || width < 0 || height >= inputHeight || height < 0 || depth >= inputDepth || depth < 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    static void PlayTurn(int width, int height, int depth)
    {

        if (OutOfBounds(width, height, depth))
        {
            Console.WriteLine("No");
            Console.WriteLine("{0} {1} {2}", LastWidth, LastHeight, LastDepth);
            return;
        }


        if (cube[width, height, depth][0] == 'T')
        {
            string location = cube[width, height, depth].Replace("T ", "");
            string[] numbers = location.Split(' ');
            int w = int.Parse(numbers[0]);
            int d = int.Parse(numbers[1]);
            PlayTurn(w, height, d);
            return;
        }

        if (cube[width, height, depth] == "B")
        {
            Console.WriteLine("No");
            Console.WriteLine("{0} {1} {2}", width, height, depth); 
            return;
        }

        if (height == inputHeight - 1)
        {
            Console.WriteLine("Yes");
            Console.WriteLine("{0} {1} {2}", width, height, depth);
            return;
        }

        LastWidth = width;
        LastHeight = height;
        LastDepth = depth;


        switch (cube[width, height, depth])
        {
            case "S L":
                PlayTurn(width - 1, height + 1, depth);
                break;
            case "S R":
                PlayTurn(width + 1, height + 1, depth);
                break;
            case "S B":
                PlayTurn(width, height + 1, depth + 1);
                break;
            case "S F":
                PlayTurn(width, height + 1, depth - 1);
                break;
            case "S FL":
                PlayTurn(width - 1, height + 1, depth - 1);
                break;
            case "S FR":
                PlayTurn(width + 1, height + 1, depth - 1);
                break;
            case "S BL":
                PlayTurn(width - 1, height + 1, depth + 1);
                break;
            case "S BR":
                PlayTurn(width + 1, height + 1, depth + 1);
                break;
            case "E":
                PlayTurn(width, height + 1, depth);
                break;
        }
    }
}
