using System;

class Midget
{
    static short[] parser(string input)
    {
        string[] splitString = input.Split(',');
        short[] result = new short[splitString.Length];
        for (int i = 0; i < result.Length; i++)
        {
            result[i]=short.Parse(splitString[i]);
        }
        return result;
    }

    static void initFalse(bool[] visited)
    {
        for (int i = 0; i < visited.Length; i++)
            visited[i] = false;
    }

    static void Main(string[] args)
    {
        string input = Console.ReadLine();
        short[] coins = parser(input);
        bool[] visited = new bool[coins.Length];

        short m = short.Parse(Console.ReadLine());
        string[] patterns = new string[m];
        for (int i = 0; i < m; i++)
        {
            patterns[i] = Console.ReadLine();
        }

        int max = int.MinValue;
        for (int i = 0; i < m; i++)
        {
            short[] path = parser(patterns[i]);
            int sum = 0;
            int position = 0;
            initFalse(visited);
            while (!visited[position])
            {
                for (int j = 0; j < path.Length; j++)
                {
                    sum += coins[position];
                    visited[position] = true;
                    position += path[j];
                    if (position < visited.Length && position >= 0)
                    {
                        if (visited[position] == true)
                            break;
                    }
                    else break;
                }
                if (position >= visited.Length || position < 0)
                    break;
            }
            if (sum > max)
                max = sum;
        }

        Console.WriteLine(max);
    }
}