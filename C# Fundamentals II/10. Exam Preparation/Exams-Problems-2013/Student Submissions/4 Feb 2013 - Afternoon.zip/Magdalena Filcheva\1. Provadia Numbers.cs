using System;
using System.Numerics;
using System.Text;

class ProvadiaNumber
{
    public static StringBuilder GetNumIn26(BigInteger n)
    {
        BigInteger num = n;
        StringBuilder _26system = new StringBuilder();
        StringBuilder numIn26 = new StringBuilder();
        BigInteger temp = 0;
        int count = 0;
        if (n == 0)
        {
            _26system.Append((char)(temp + 65));
        }
        while (num != 0)
        {
            temp = (num % 26);
            if (count == 0)
            {
                _26system.Append((char)(temp + 65));
                num = num / 26;
                count++;
            }
            else
            {
                _26system.Append((char)(temp + 96));
                num = num / 26;
            }
        }

        for (int index = _26system.Length - 1; index >= 0; index--)
        {
            numIn26.Append(_26system[index]);
        }
        return numIn26;
    }
    public static StringBuilder GetNumIn256(BigInteger n)
    {
        BigInteger num = n;
        StringBuilder _256system = new StringBuilder();
        BigInteger temp = 0;
        if (n == 0)
        {
            _256system.Insert(0, (GetNumIn26(temp)));
        }
        while (num != 0)
        {
            temp = (num % 256);

            _256system.Insert(0,(GetNumIn26(temp)));
            num = num / 256;
        }

        return _256system;
 
    }

    static void Main()
    {
        BigInteger n = BigInteger.Parse(Console.ReadLine());
        
        Console.WriteLine(GetNumIn256(n));
    }

}