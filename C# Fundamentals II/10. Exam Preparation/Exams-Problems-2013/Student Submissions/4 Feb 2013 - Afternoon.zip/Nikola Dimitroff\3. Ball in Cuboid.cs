using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
	static void Main(string[] args)
	{
#if DEBUG
		Console.SetIn(new StreamReader("input.txt"));
#endif
		var input = Console.ReadLine().Split(' ');
		int width = int.Parse(input[0]);
		int height = int.Parse(input[1]);
		int depth = int.Parse(input[2]);
		
		var cuboid = new ICube[width, height, depth];

		for (int i = 0; i < height; i++)
		{
			var rows = Console.ReadLine().Split(new string[] {" | "}, StringSplitOptions.RemoveEmptyEntries);
			for (int j = 0; j < depth; j++)
			{
				var depths = rows[j].Split(new string[] {")("}, StringSplitOptions.RemoveEmptyEntries);
				for (int k = 0; k < width; k++)
				{
					string current = depths[k].Replace("(","").Replace(")","");
					cuboid[k, i, j] = ParseCuboid(current);
				}
			}
		}

		var ballCoordinates = Console.ReadLine().Split(' ');
		var ball = new Ball(int.Parse(ballCoordinates[0]), 0, int.Parse(ballCoordinates[1]));

		while (true)
		{
			var currentCube = cuboid[ball.X, ball.Y, ball.Z];
			Ball now = new Ball(ball.X, ball.Y, ball.Z);
			bool movedSuccessfully = currentCube.TryMoveBall(ball);

			if (movedSuccessfully && ball.Y >= height)
			{
				Console.WriteLine("Yes");
				Console.WriteLine(now);
				return;
			}
			if (!movedSuccessfully || ball.X < 0 || ball.X >= width || ball.Z < 0 || ball.Z >= depth)
			{
				Console.WriteLine("No");
				Console.WriteLine(ball);
				return;
			}
		}
		
	}

	private static ICube ParseCuboid(string current)
	{
		if (current == "E")
			return new EmptyCube();
		else if (current == "B")
			return new Basket();
		else if (current.StartsWith("S"))
		{
			return new Slider(current.Replace("S ", ""));
		}
		else
		{
			current = current.Replace("T ", "");
			int spaceIndex = current.IndexOf(" ");
			return new Teleporter(
				int.Parse(current.Substring(0, spaceIndex)), 
				int.Parse(current.Substring(spaceIndex, current.Length - spaceIndex)));
		}
	}
}

class Ball
{
	public int X;
	public int Y;
	public int Z;

	public Ball(int x, int y, int z)
	{
		X = x;
		Y = y;
		Z = z;
	}

	public override string ToString()
	{
		return String.Format("{0} {1} {2}", X, Y, Z);
	}
}

interface ICube 
{
	bool TryMoveBall(Ball ball);
}

#region Cubes
class Slider : ICube
{
	private string Direction;
	
	public Slider(string direction)
	{
		Direction = direction;
	}

	public bool TryMoveBall(Ball ball)
	{
		if (Direction.Contains("L"))
			ball.X--;
		else if (Direction.Contains("R"))
			ball.X++;
		if (Direction.Contains("B"))
			ball.Z++;
		else if (Direction.Contains("F"))
			ball.Z--;

		ball.Y++;

		return true;
	}
}

class Teleporter : ICube
{
	private int destinationX;
	private int destinationZ;

	public Teleporter(int dirX, int dirZ)
	{
		destinationX = dirX;
		destinationZ = dirZ;
	} 

	public bool TryMoveBall(Ball ball)
	{
		ball.X = destinationX;
		ball.Z = destinationZ;
		return true;
	}
}

class EmptyCube : ICube
{
	public bool TryMoveBall(Ball ball)
	{
		ball.Y++;
		return true;
	}
}

class Basket : ICube
{
	public bool TryMoveBall(Ball ball)
	{
		return false;
	}
}

#endregion
