using System;

class Program
{
    static string[, ,] cube;
    static int height, width, depth;

    private static void ReadCube()
    {
        string[] dimensions = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        width = int.Parse(dimensions[0]);
        height = int.Parse(dimensions[1]);
        depth = int.Parse(dimensions[2]);
        cube = new string[height, depth, width];

        for (int h = 0; h < height; ++h)
        {
            string[] rows = Console.ReadLine().Split(new string[] { " | " }, StringSplitOptions.RemoveEmptyEntries);
            for (int d = 0; d < depth; ++d)
            {
                string[] row = rows[d].Split(new char[] { ')', '(' }, StringSplitOptions.RemoveEmptyEntries);
                for (int w = 0; w < width; ++w)
                {
                    cube[h, d, w] = row[w];
                }
            }
        }
    }

    public static void Main()
    {
        ReadCube();

        string[] dimensions = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        int ballW = int.Parse(dimensions[0]);
        int ballD = int.Parse(dimensions[1]);

        int level = 0;
        bool successful = true;
        while (true)
        {
            if (!successful)
            {
                Console.WriteLine("No");
                Console.WriteLine("{0} {1} {2}", ballW, level, ballD);
                return;
            }

            if (level == height)
            {
                Console.WriteLine("Yes");
                Console.WriteLine("{0} {1} {2}", ballW, height - 1, ballD);
                return;
            }
            switch (cube[level, ballD, ballW][0])
            {
                case 'S':
                    if (level == height - 1)
                    {
                        ++level;
                        break;
                    }
                    string direction = cube[level, ballD, ballW].Substring(2);
                    switch (direction)
                    {
                        case "R":
                            if (ballW < width - 1)
                            {
                                ++ballW;
                                ++level;
                            }
                            else
                            {
                                successful = false;
                            }
                            break;
                        case "L":
                            if (ballW > 0)
                            {
                                --ballW;
                                ++level;
                            }
                            else
                            {
                                successful = false;
                            }
                            break;
                        case "F":
                            if (ballD > 0)
                            {
                                --ballD;
                                ++level;
                            }
                            else
                            {
                                successful = false;
                            }
                            break;
                        case "B":
                            if (ballD < depth - 1)
                            {
                                ++ballD;
                                ++level;
                            }
                            else
                            {
                                successful = false;
                            }
                            break;
                        case "BR":
                            if (ballD < depth - 1 && ballW < width - 1)
                            {
                                ++ballW;
                                ++ballD;
                                ++level;
                            }
                            else
                            {
                                successful = false;
                            }
                            break;
                        case "BL":
                            if (ballD < depth - 1 && ballW > 0)
                            {
                                --ballW;
                                ++ballD;
                                ++level;
                            }
                            else
                            {
                                successful = false;
                            }
                            break;
                        case "FR":
                            if (ballD > 0 && ballW < width - 1)
                            {
                                ++ballW;
                                --ballD;
                                ++level;
                            }
                            else
                            {
                                successful = false;
                            }
                            break;
                        case "FL":
                            if (ballD > 0 && ballW > 0)
                            {
                                --ballW;
                                --ballD;
                                ++level;
                            }
                            else
                            {
                                successful = false;
                            }
                            break;
                    }
                    break;
                case 'T':
                    string[] coodinates = cube[level, ballD, ballW].Substring(2).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    ballW = int.Parse(coodinates[0]);
                    ballD = int.Parse(coodinates[1]);
                    break;
                case 'E':
                    ++level;
                    break;
                case 'B':
                    successful = false;
                    break;
            }
        }
    }
}