using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exam
{
    class Program
    {
        static void Main(string[] args)
        {

            int alpha = int.Parse(Console.ReadLine());
            Console.WriteLine(Convert.ToChar(alpha + 65));





        }


    }
}