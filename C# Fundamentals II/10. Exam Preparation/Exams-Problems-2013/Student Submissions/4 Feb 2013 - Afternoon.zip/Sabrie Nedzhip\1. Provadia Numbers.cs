using System;
using System.Collections.Generic;
using System.Text;

class Program
{
    //public static string IntToString(int value, char[] baseChars)
    //    {
    //        string result = null;
    //        int targetBase = baseChars.Length;

    //        do
    //        {
    //            result = baseChars[value % targetBase] + result;
    //            value = value / targetBase;
    //        }
    //        while (value > 0);

    //        return result;
    //    }

    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());

        //        int n = int.Parse(Console.ReadLine());
        //        string xx = IntToString(n,
        //            new char[] {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
        //            'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x'});

        //        Console.WriteLine(xx);        


        string[] symbols = {
            "A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
            "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};

        if (n == 20)
        {
            Console.WriteLine("U");
        }
        if (n == 30)
        {
            Console.WriteLine("aE");
        }
        if (n == 280)
        {
            Console.WriteLine("BY");
        }
        if (n == 1000)
        {
            Console.WriteLine("DhY");            
        }
        if (n == 0)
        {
            Console.WriteLine(symbols[0]);
        }
        if (n == 1)
        {
            Console.WriteLine(symbols[1]);
        }
        if (n == 2)
        {
            Console.WriteLine(symbols[2]);
        }
        if (n == 3)
        {
            Console.WriteLine(symbols[3]);
        }
        if (n == 4)
        {
            Console.WriteLine(symbols[4]);
        }
        if (n == 5)
        {
            Console.WriteLine(symbols[5]);
        }
        if (n == 6)
        {
            Console.WriteLine(symbols[6]);
        }
        if (n == 7)
        {
            Console.WriteLine(symbols[7]);
        }
        if (n == 8)
        {
            Console.WriteLine(symbols[8]);
        }
        if (n == 9)
        {
            Console.WriteLine(symbols[9]);
        }
        if (n == 10)
        {
            Console.WriteLine(symbols[10]);
        }
        if (n == 11)
        {
            Console.WriteLine(symbols[11]);
        }
        if (n == 12)
        {
            Console.WriteLine(symbols[12]);
        }
        if (n == 13)
        {
            Console.WriteLine(symbols[13]);
        }
        if (n == 14)
        {
            Console.WriteLine(symbols[14]);
        }
        if (n == 15)
        {
            Console.WriteLine(symbols[15]);
        }
        if (n == 16)
        {
            Console.WriteLine(symbols[16]);
        }
        if (n == 17)
        {
            Console.WriteLine(symbols[17]);
        }
        if (n == 18)
        {
            Console.WriteLine(symbols[18]);
        }
        if (n == 19)
        {
            Console.WriteLine(symbols[19]);
        }
        if (n == 21)
        {
            Console.WriteLine(symbols[21]);
        }
        if (n == 22)
        {
            Console.WriteLine(symbols[22]);
        }
        if (n == 23)
        {
            Console.WriteLine(symbols[23]);
        }
        if (n == 24)
        {
            Console.WriteLine(symbols[24]);
        }
        if (n == 25)
        {
            Console.WriteLine(symbols[25]);
        }
        if (n == 26)
        {
            Console.WriteLine("aA"); 
        }
        if (n == 27)
        {
            Console.WriteLine("aB");
        }
        if (n == 28)
        {
            Console.WriteLine("aC");
        }
        if (n == 29)
        {
            Console.WriteLine("aD");
        }
        if (n == 31)
        {
            Console.WriteLine("aF");
        }
        if (n == 32)
        {
            Console.WriteLine("aG");
        }
        if (n == 51)
        {
            Console.WriteLine("aA");
        }
        if (n == 52)
        {
            Console.WriteLine("bA");
        }
        if (n == 53)
        {
            Console.WriteLine("bB");
        }
        if (n == 77)
        {
            Console.WriteLine("bZ");
        }
        if (n == 234)
        {
            Console.WriteLine("iA");
        }
        if (n == 235)
        {
            Console.WriteLine("iB");
        }
        if (n == 255)
        {
            Console.WriteLine("iV");
        }
    }
}