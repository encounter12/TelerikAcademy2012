using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;

class DecimalToProvadiaNum
{
    static void Main()
    {
        BigInteger dec = BigInteger.Parse(Console.ReadLine());
        List<BigInteger> prov = new List<BigInteger>(0);

        BigInteger result = 0;
        while (dec % 256 > 0)
        {
            result = dec % 256;
            prov.Add(result);
            dec = dec / 256;

        }
        prov.Reverse();
        foreach (int num in prov)
        {
            switch (num)
            {
                case 0:
                    Console.Write("A");
                    break;
                case 1:
                    Console.Write("B");
                    break;
                case 2:
                    Console.Write("C");
                    break;
                case 3:
                    Console.Write("D");
                    break;
                case 4:
                    Console.Write("E");
                    break;
                case 5:
                    Console.Write("F");
                    break;
                case 6:
                    Console.Write("G");
                    break;
                case 7:
                    Console.Write("H");
                    break;
                case 8:
                    Console.Write("I");
                    break;
                case 9:
                    Console.Write("J");
                    break;
                case 10:
                    Console.Write("K");
                    break;
                case 11:
                    Console.Write("L");
                    break;
                case 12:
                    Console.Write("M");
                    break;
                case 13:
                    Console.Write("N");
                    break;
                case 14:
                    Console.Write("O");
                    break;
                case 15:
                    Console.Write("P");
                    break;
                case 16:
                    Console.Write("Q");
                    break;
                case 17:
                    Console.Write("R");
                    break;
                case 18:
                    Console.Write("S");
                    break;
                case 19:
                    Console.Write("T");
                    break;
                case 20:
                    Console.Write("U");
                    break;
                case 21:
                    Console.Write("V");
                    break;
                case 22:
                    Console.Write("W");
                    break;
                case 23:
                    Console.Write("X");
                    break;
                case 24:
                    Console.Write("Y");
                    break;
                case 25:
                    Console.Write("Z");
                    break;
                case 26:
                    Console.Write("aA");
                    break;
                case 27:
                    Console.Write("aB");
                    break;
                case 28:
                    Console.Write("aC");
                    break;
                case 29:
                    Console.Write("aD");
                    break;
                case 30:
                    Console.Write('a');
                    Console.Write('E');
                    break;
                case 31:
                    Console.Write("aF");
                    break;
                case 32:
                    Console.Write("aG");
                    break;
                case 33:
                    Console.Write("aH");
                    break;
                case 34:
                    Console.Write("aI");
                    break;
                case 35:
                    Console.Write("aJ");
                    break;
                case 36:
                    Console.Write("aK");
                    break;
                case 37:
                    Console.Write("aL");
                    break;
                case 38:
                    Console.Write("aM");
                    break;
                case 39:
                    Console.Write("aN");
                    break;
                case 40:
                    Console.Write("aO");
                    break;
                case 41:
                    Console.Write("aP");
                    break;
                case 42:
                    Console.Write("aQ");
                    break;
                case 43:
                    Console.Write("aR");
                    break;
                case 44:
                    Console.Write("aS");
                    break;
                case 45:
                    Console.Write("aT");
                    break;
                case 46:
                    Console.Write("aU");
                    break;
                case 47:
                    Console.Write("aV");
                    break;
                case 48:
                    Console.Write("aW");
                    break;
                case 49:
                    Console.Write("aX");
                    break;
                case 50:
                    Console.Write("aY");
                    break;
                case 51:
                    Console.Write("aZ");
                    break;
                case 52:
                    Console.Write("bA");
                    break;
                case 53:
                    Console.Write("bB");
                    break;
                case 54:
                    Console.Write("bC");
                    break;
                case 55:
                    Console.Write("bD");
                    break;
                case 56:
                    Console.Write("bE");
                    break;
                case 57:
                    Console.Write("bF");
                    break;
                case 58:
                    Console.Write("bG");
                    break;
                case 59:
                    Console.Write("bH");
                    break;
                case 60:
                    Console.Write("bI");
                    break;
                case 61:
                    Console.Write("bJ");
                    break;
                case 62:
                    Console.Write("bK");
                    break;
                case 63:
                    Console.Write("bL");
                    break;
                case 64:
                    Console.Write("bM");
                    break;
                case 65:
                    Console.Write("bN");
                    break;
                case 66:
                    Console.Write("bO");
                    break;
                case 67:
                    Console.Write("bP");
                    break;
                case 68:
                    Console.Write("bQ");
                    break;
                case 69:
                    Console.Write("bR");
                    break;
                case 70:
                    Console.Write("bS");
                    break;
                case 71:
                    Console.Write("bT");
                    break;
                case 72:
                    Console.Write("bU");
                    break;
                case 73:
                    Console.Write("bV");
                    break;
                case 74:
                    Console.Write("bW");
                    break;
                case 75:
                    Console.Write("bX");
                    break;
                case 76:
                    Console.Write("bY");
                    break;
                case 77:
                    Console.Write("bZ");
                    break;
                case 78:
                    Console.Write("cA");
                    break;
                case 79:
                    Console.Write("cB");
                    break;
                case 80:
                    Console.Write("cC");
                    break;
                case 81:
                    Console.Write("cD");
                    break;
                case 82:
                    Console.Write("cE");
                    break;
                case 83:
                    Console.Write("cF");
                    break;
                case 84:
                    Console.Write("cG");
                    break;
                case 85:
                    Console.Write("cH");
                    break;
                case 86:
                    Console.Write("cI");
                    break;
                case 87:
                    Console.Write("cJ");
                    break;
                case 88:
                    Console.Write("cK");
                    break;
                case 89:
                    Console.Write("cL");
                    break;
                case 90:
                    Console.Write("cM");
                    break;
                case 91:
                    Console.Write("cN");
                    break;
                case 92:
                    Console.Write("cO");
                    break;
                case 93:
                    Console.Write("cP");
                    break;
                case 94:
                    Console.Write("cQ");
                    break;
                case 95:
                    Console.Write("cR");
                    break;
                case 96:
                    Console.Write("cS");
                    break;
                case 97:
                    Console.Write("cT");
                    break;
                case 98:
                    Console.Write("cU");
                    break;
                case 99:
                    Console.Write("cV");
                    break;
                case 100:
                    Console.Write("cW");
                    break;
                case 101:
                    Console.Write("cX");
                    break;
                case 102:
                    Console.Write("cY");
                    break;
                case 103:
                    Console.Write("cZ");
                    break;
                case 104:
                    Console.Write("dA");
                    break;
                case 105:
                    Console.Write("dB");
                    break;
                case 106:
                    Console.Write("dC");
                    break;
                case 107:
                    Console.Write("dD");
                    break;
                case 108:
                    Console.Write("dE");
                    break;
                case 109:
                    Console.Write("dF");
                    break;
                case 110:
                    Console.Write("dG");
                    break;
                case 111:
                    Console.Write("dH");
                    break;
                case 112:
                    Console.Write("dI");
                    break;
                case 113:
                    Console.Write("dJ");
                    break;
                case 114:
                    Console.Write("dK");
                    break;
                case 115:
                    Console.Write("dL");
                    break;
                case 116:
                    Console.Write("dM");
                    break;
                case 117:
                    Console.Write("dN");
                    break;
                case 118:
                    Console.Write("dO");
                    break;
                case 119:
                    Console.Write("dP");
                    break;
                case 120:
                    Console.Write("dQ");
                    break;
                case 121:
                    Console.Write("dR");
                    break;
                case 122:
                    Console.Write("dS");
                    break;
                case 123:
                    Console.Write("dT");
                    break;
                case 124:
                    Console.Write("dU");
                    break;
                case 125:
                    Console.Write("dV");
                    break;
                case 126:
                    Console.Write("dW");
                    break;
                case 127:
                    Console.Write("dX");
                    break;
                case 128:
                    Console.Write("dY");
                    break;
                case 129:
                    Console.Write("dZ");
                    break;
                case 130:
                    Console.Write("eA");
                    break;
                case 131:
                    Console.Write("eB");
                    break;
                case 132:
                    Console.Write("eC");
                    break;
                case 133:
                    Console.Write("eD");
                    break;
                case 134:
                    Console.Write("eE");
                    break;
                case 135:
                    Console.Write("eF");
                    break;
                case 136:
                    Console.Write("eG");
                    break;
                case 137:
                    Console.Write("eH");
                    break;
                case 138:
                    Console.Write("eI");
                    break;
                case 139:
                    Console.Write("eJ");
                    break;
                case 140:
                    Console.Write("eK");
                    break;
                case 141:
                    Console.Write("eL");
                    break;
                case 142:
                    Console.Write("eM");
                    break;
                case 143:
                    Console.Write("eN");
                    break;
                case 144:
                    Console.Write("eO");
                    break;
                case 145:
                    Console.Write("eP");
                    break;
                case 146:
                    Console.Write("eQ");
                    break;
                case 147:
                    Console.Write("eR");
                    break;
                case 148:
                    Console.Write("eS");
                    break;
                case 149:
                    Console.Write("eT");
                    break;
                case 150:
                    Console.Write("eU");
                    break;
                case 151:
                    Console.Write("eV");
                    break;
                case 152:
                    Console.Write("eW");
                    break;
                case 153:
                    Console.Write("eX");
                    break;
                case 154:
                    Console.Write("eY");
                    break;
                case 155:
                    Console.Write("eZ");
                    break;
                case 156:
                    Console.Write("fA");
                    break;
                case 157:
                    Console.Write("fB");
                    break;
                case 158:
                    Console.Write("fC");
                    break;
                case 159:
                    Console.Write("fD");
                    break;
                case 160:
                    Console.Write("fE");
                    break;
                case 161:
                    Console.Write("fF");
                    break;
                case 162:
                    Console.Write("fG");
                    break;
                case 163:
                    Console.Write("fH");
                    break;
                case 164:
                    Console.Write("fI");
                    break;
                case 165:
                    Console.Write("fJ");
                    break;
                case 166:
                    Console.Write("fK");
                    break;
                case 167:
                    Console.Write("fL");
                    break;
                case 168:
                    Console.Write("fM");
                    break;
                case 169:
                    Console.Write("fN");
                    break;
                case 170:
                    Console.Write("fO");
                    break;
                case 171:
                    Console.Write("fP");
                    break;
                case 172:
                    Console.Write("fQ");
                    break;
                case 173:
                    Console.Write("fR");
                    break;
                case 174:
                    Console.Write("fS");
                    break;
                case 175:
                    Console.Write("fT");
                    break;
                case 176:
                    Console.Write("fU");
                    break;
                case 177:
                    Console.Write("fV");
                    break;
                case 178:
                    Console.Write("fW");
                    break;
                case 179:
                    Console.Write("fX");
                    break;
                case 180:
                    Console.Write("fY");
                    break;
                case 181:
                    Console.Write("fZ");
                    break;
                case 182:
                    Console.Write("gA");
                    break;
                case 183:
                    Console.Write("gB");
                    break;
                case 184:
                    Console.Write("gC");
                    break;
                case 185:
                    Console.Write("gD");
                    break;
                case 186:
                    Console.Write("gE");
                    break;
                case 187:
                    Console.Write("gF");
                    break;
                case 188:
                    Console.Write("gG");
                    break;
                case 189:
                    Console.Write("gH");
                    break;
                case 190:
                    Console.Write("gI");
                    break;
                case 191:
                    Console.Write("gJ");
                    break;
                case 192:
                    Console.Write("gK");
                    break;
                case 193:
                    Console.Write("gL");
                    break;
                case 194:
                    Console.Write("gM");
                    break;
                case 195:
                    Console.Write("gN");
                    break;
                case 196:
                    Console.Write("gO");
                    break;
                case 197:
                    Console.Write("gP");
                    break;
                case 198:
                    Console.Write("gQ");
                    break;
                case 199:
                    Console.Write("gR");
                    break;
                case 200:
                    Console.Write("gS");
                    break;
                case 201:
                    Console.Write("gT");
                    break;
                case 202:
                    Console.Write("gU");
                    break;
                case 203:
                    Console.Write("gV");
                    break;
                case 204:
                    Console.Write("gW");
                    break;
                case 205:
                    Console.Write("gX");
                    break;
                case 206:
                    Console.Write("gY");
                    break;
                case 207:
                    Console.Write("gZ");
                    break;
                case 208:
                    Console.Write("hA");
                    break;
                case 209:
                    Console.Write("hB");
                    break;
                case 210:
                    Console.Write("hC");
                    break;
                case 211:
                    Console.Write("hD");
                    break;
                case 212:
                    Console.Write("hE");
                    break;
                case 213:
                    Console.Write("hF");
                    break;
                case 214:
                    Console.Write("hG");
                    break;
                case 215:
                    Console.Write("hH");
                    break;
                case 216:
                    Console.Write("hI");
                    break;
                case 217:
                    Console.Write("hJ");
                    break;
                case 218:
                    Console.Write("hK");
                    break;
                case 219:
                    Console.Write("hL");
                    break;
                case 220:
                    Console.Write("hM");
                    break;
                case 221:
                    Console.Write("hN");
                    break;
                case 222:
                    Console.Write("hO");
                    break;
                case 223:
                    Console.Write("hP");
                    break;
                case 224:
                    Console.Write("hQ");
                    break;
                case 225:
                    Console.Write("hR");
                    break;
                case 226:
                    Console.Write("hS");
                    break;
                case 227:
                    Console.Write("hT");
                    break;
                case 228:
                    Console.Write("hU");
                    break;
                case 229:
                    Console.Write("hV");
                    break;
                case 230:
                    Console.Write("hW");
                    break;
                case 231:
                    Console.Write("hX");
                    break;
                case 232:
                    Console.Write("hY");
                    break;
                case 233:
                    Console.Write("hZ");
                    break;
                case 234:
                    Console.Write("iA");
                    break;
                case 235:
                    Console.Write("iB");
                    break;
                case 236:
                    Console.Write("iC");
                    break;
                case 237:
                    Console.Write("iD");
                    break;
                case 238:
                    Console.Write("iE");
                    break;
                case 239:
                    Console.Write("iF");
                    break;
                case 240:
                    Console.Write("iG");
                    break;
                case 241:
                    Console.Write("iH");
                    break;
                case 242:
                    Console.Write("iI");
                    break;
                case 243:
                    Console.Write("iJ");
                    break;
                case 244:
                    Console.Write("iK");
                    break;
                case 245:
                    Console.Write("iL");
                    break;
                case 246:
                    Console.Write("iM");
                    break;
                case 247:
                    Console.Write("iN");
                    break;
                case 248:
                    Console.Write("iO");
                    break;
                case 249:
                    Console.Write("iP");
                    break;
                case 250:
                    Console.Write("iQ");
                    break;
                case 251:
                    Console.Write("iR");
                    break;
                case 252:
                    Console.Write("iS");
                    break;
                case 253:
                    Console.Write("iT");
                    break;
                case 254:
                    Console.Write("iU");
                    break;
                case 255:
                    Console.Write("iV");
                    break;
                default:
                    break;
            }
        }
        Console.WriteLine();
    }
}