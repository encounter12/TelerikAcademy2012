using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{

    public static int[] toNew(string pattern)
    {
        string[] test = pattern.Split(',');
        List<int> list = new List<int>();

        for (int i = 0; i < test.Length; i++)
        {
            list.Add(int.Parse(test[i].ToString().Trim()));
        }

        return list.ToArray();
    }


    static void Main(string[] args)
    {

        string pattern = Console.ReadLine();

        string[] test = pattern.Split(',');
        List<int> list = new List<int>();

        for (int i = 0; i < test.Length; i++)
        {
            list.Add(int.Parse(test[i].ToString().Trim()));
        }

        int num = int.Parse(Console.ReadLine());

        List<int[]> arrayList = new List<int[]>();

        for (int i = 0; i < num; i++)
        {
            string newLine = Console.ReadLine();
            arrayList.Add(toNew(newLine));
        }
        
        //*** DWORFING


        List<int> resultList = new List<int>();

        
        for (int x = 0; x < num; x++)
        {

            bool ok = true;
            int result = list[0];
            int position = 0;


            List<int> newList = new List<int>(list);
            newList[0] = -371;

            while (ok)
            {
                for (int i = 0; i < arrayList[x].Length; i++)
                {
                    position += (0 + arrayList[x][i]);
                    

                    if (position > newList.Count - 1 || position < 0)
                    {
                        ok = false;
                        break;
                    }
                    else
                    {
                        if (newList[position] == -371)
                        {
                            ok = false;
                            break;
                        }
                        else
                        {
                            result += newList[position];
                            newList[position] = -371;
                        }
                    }
                }
            }
            resultList.Add(result);

            
        }


        resultList.Sort();

        Console.WriteLine(resultList[resultList.Count-1]);
        



    }
}
