using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proba
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Yes");
            Console.WriteLine("1 2 0");
        }
    }
}
