using System;
using System.Collections.Generic;

class AlignBoth
{
    static string cleanWhitespace(string input)
    {
        string output = "";
        for (int i = 0; i < input.Length - 1; i++)
        {
            if (input.Substring(i, 2) != "  ")
                output += input[i];
            
        }
        output += input[input.Length - 1];

        return output;
    }

    static string Concatenate(string[] input)
    {
        string result = "";
        for (int i = 0; i < input.Length; i++)
        {
            result += input[i] + " ";
        }
        return result;
    }

    static List<string> splitToLines(string[] input, int w)
    {
        List<string> result = new List<string>();
        string temp = cleanWhitespace(Concatenate(input));
        while (temp !="")
        {
            int lastSpace = 0;
            int count = 0;
            while (count <= w)
            {
                if (temp[count] == ' ')
                    lastSpace = count;
                count++;
                if (count == temp.Length)
                    break;
            }
            result.Add(temp.Substring(0, lastSpace));
            temp = temp.Substring(lastSpace + 1);
        }

        return result;
    }

    static string fillWithSpace(string input, int w)
    {
        string result = "";
        string[] words = input.Split(' ');
        if (words.Length == 1)
        {
            result += words[0];
        }
        else
        {
            int totalLength = 0;
            for (int i = 0; i < words.Length; i++)
                totalLength += words[i].Length;
            int countOfWhiteSpace = w - totalLength;
            int[] exactSpaces = separateNums(countOfWhiteSpace, words.Length - 1);
            for (int i = 0; i < words.Length - 1; i++)
            {
                result += words[i];
                for (int j = 0; j < exactSpaces[i]; j++)
                    result += ' ';
            }
            result += words[words.Length - 1];
        }

        return result;
    }

    static int[] separateNums(int input, int count)
    {
        int[] result = new int[count];
        for (int i = 0; i < count; i++)
        {
            result[i] = input / (count - i);
            input -= input / (count - i);
        }
        Array.Reverse(result);

        return result;
    }


    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int w = int.Parse(Console.ReadLine());
        string[] lines = new string[n];
        for (int i = 0; i < n; i++)
            lines[i] = Console.ReadLine();

        List<string> result = splitToLines(lines, w);
        for (int i = 0; i < result.Count; i++)
        {
            string temp = fillWithSpace(result[i], w);
            Console.WriteLine(temp);
        }
    }
}