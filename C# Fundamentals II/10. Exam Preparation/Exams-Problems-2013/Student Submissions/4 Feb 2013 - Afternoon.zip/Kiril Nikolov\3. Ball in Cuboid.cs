using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

class Program
{
    static short[] Teleport(string teleport)
    {
        string[] teleportInfo = teleport.Split();
        string letter = teleportInfo[0];
        short w = short.Parse(teleportInfo[1]);
        short d = short.Parse(teleportInfo[2]);

        short[] cords = { w, d };
        return cords;
    }

    static void Main(string[] args)
    {

        string cuboidSize = Console.ReadLine();
        string[] sizes = cuboidSize.Split();
        short width = short.Parse(sizes[0]);
        short height = short.Parse(sizes[1]);
        short depth = short.Parse(sizes[2]);
        string[, ,] cuboid = new string[width, height, depth];

        for (int he = 0; he < height; he++)
        {
            string line = Console.ReadLine();
            string[] sequences = line.Split('|');
            for (int de = 0; de < depth; de++)
            {
                string pattern = @"(?<=\().+?(?=\))";
                MatchCollection matches = Regex.Matches(sequences[de], pattern);
                string[] directions = new string[matches.Count];

                for (int i = 0; i < matches.Count; i++)
                {
                    directions[i] = matches[i].ToString();
                }

                for (int wi = 0; wi < width; wi++)
                {
                    cuboid[wi, he, de] = directions[wi];
                }
            }
        }
        string positionStr = Console.ReadLine();
        string[] position = positionStr.Split();
        short ballW = short.Parse(position[0]);
        short ballD = short.Parse(position[1]);

        bool success = false;
        bool bucket = false;
        string firstPosition = cuboid[ballW, 0, ballD];

        string nextPosition = firstPosition;
        short w = ballW;
        short h = 0;
        short d = ballD;

        while (success == false && bucket == false)
        {
            nextPosition = cuboid[w, h, d];

            switch (nextPosition)
            {
                case "S L": w--; h++;
                    break;
                case "S R": w++; h++;
                    break;
                case "S F": d--; h++;
                    break;
                case "S B": d++; h++;
                    break;
                case "S FL": w--; d--; h++;
                    break;
                case "S FR": w++; d--; h++;
                    break;
                case "S BL": w--; d++; h++;
                    break;
                case "S BR": w++; d++; h++;
                    break;
                case "E": h++;
                    break;
                case "B": bucket = true;
                    break;
                default: short[] toTeleport = Teleport(cuboid[w, h, d]);
                    w = toTeleport[0];
                    d = toTeleport[1];
                    break;
            }

            if (bucket)
            {
                break;
            }

            if (w < 0)
            {
                bucket = true;
                w++;
            }
            if (w >= width)
            {
                bucket = true;
                w--;
            }
            if (d < 0)
            {
                bucket = true;
                d++;
            }
            if (d > depth)
            {
                bucket = true;
                d--;
            }
            if (h >= height - 1)
            {
                success = true;
                if (h > height - 1)
                {
                    h--;
                }
            }

        }
        if (success)
        {
            Console.WriteLine("Yes");
            Console.WriteLine("{0} {1} {2}", w, h, d);
        }
        else
        {
            Console.WriteLine("No");
            Console.WriteLine("{0} {1} {2}", w, h, d);
        }

    }
}