using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
#endif
        StringBuilder input = new StringBuilder();
        int inputLines = int.Parse(Console.ReadLine());
        int lineLenght = int.Parse(Console.ReadLine());
        for (int i = 0; i < inputLines; i++)
        {
            input.Append(string.Format(" {0} ", Console.ReadLine()));
        }

        string[] words = input.ToString().Split(new char[] { ' ', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        List<string> currentLine = new List<string>();

        int wordIndex = 0;
        while (wordIndex < words.Length)
        {
            int currentLineLengt = words[wordIndex].Length;
            currentLine.Add(words[wordIndex++]);// ERROR

            while (wordIndex < words.Length)
            {
                if (currentLineLengt + words[wordIndex].Length < lineLenght)
                {
                    currentLineLengt += words[wordIndex].Length + 1;
                    currentLine.Add(words[wordIndex++]);// ERROR
                }
                else
                {
                    break;
                }
            }
            PrintLine(currentLine, lineLenght);
            currentLine.Clear();
        }
    }


    static void PrintLine(List<string> words, int lineLenght)
    {
        if (words.Count == 1)
        {
            Console.WriteLine(words[0]);
            return;
        }
        int wordsLenght = 0;
        int countOfGaps = words.Count - 1;

        foreach (var item in words)
        {
            wordsLenght += item.Length;
        }

        int gap = lineLenght - wordsLenght;
        int gapLeft = gap % countOfGaps;
        int initialGap = gap / countOfGaps;

        for (int index = 0; index < words.Count; index++)
        {
            if (index == 0)
            {
                Console.Write(words[index]);
            }
            else if (index <= gapLeft)
            {
                Console.Write("{0}{1}", new String(' ', initialGap + 1), words[index]);
            }
            else
            {
                Console.Write("{0}{1}", new String(' ', initialGap), words[index]);
            }
        }
        Console.WriteLine();

    }
}
