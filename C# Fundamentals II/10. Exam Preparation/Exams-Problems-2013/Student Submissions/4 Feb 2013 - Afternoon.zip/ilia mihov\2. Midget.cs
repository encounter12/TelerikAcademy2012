using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Midget
{
    class Midget
    {
        static int[] GetInts(string ints)
        {
            //if (string.IsNullOrEmpty(ints))
            //{
            //    //exception
            //}

            string[] res = ints.Split(',');

            int[] result = new int[res.Length];
            for (int i = 0; i < res.Length; i++)
            {
                result[i] = Convert.ToInt32(res[i]);
            }
            return result;
        }

        static int CollectedCoins(int[] Valey, int[] Path)
        {
            int nSum = 0;
            int nCurrLocation = 0;
            bool HaveToCheck = true;
            do
            {
                for (int i = 0; i < Path.Length; i++)
                {
                    nSum += Valey[nCurrLocation];
                    Valey[nCurrLocation] = int.MaxValue; //add max value to visited cells
                    nCurrLocation += Path[i];

                    if ( nCurrLocation < 1 || nCurrLocation > Valey.Length - 1)
                    {
                        HaveToCheck = false;
                        break;
                    }
                    if (int.MaxValue == Valey[nCurrLocation]) //if nCurrLocation is out of range it will exit with if above
                    {
                        HaveToCheck = false;
                        break;
                    }
                }
            } while (HaveToCheck);

            return nSum;
        }

        static void Main(string[] args)
        {
            int[] arrValley = GetInts(Console.ReadLine());

            int nPatternsNum = int.Parse(Console.ReadLine());
            int[] temp = new int[arrValley.Length];

            int nMaxCoins = int.MinValue;
            for (int i = 0; i < nPatternsNum; i++)
            {
                Array.Copy(arrValley, temp, arrValley.Length); //make copy
                int nCurrCoins = CollectedCoins(temp, GetInts(Console.ReadLine()));

                if (nCurrCoins > nMaxCoins)
                {
                    nMaxCoins = nCurrCoins;
                }
            }

            Console.WriteLine("{0}", nMaxCoins);

        }
    }
}
