using System;

class twoInOne
{
    static int FindLastLamp(bool[] lamps, int index) 
    {
        int count = 0;
        for (int lastIndex = lamps.Length - 1; lastIndex > index; lastIndex--)
        {
            if (lamps[lastIndex] == false)
            {
                count++;
            }
            if (count > 1)
            {
                break;
            }
        }
        return count;
    }
    static void TurnOnLamps(bool[] lamps, int index) 
    {
        int lampsToTurnOn = index + 2;
        for (int currentIndex = index; currentIndex < lamps.Length; currentIndex += lampsToTurnOn)
        {
            lamps[currentIndex] = true;       
        }
    }
    static void Main()
    {
        int numOfLamps = int.Parse(Console.ReadLine());
        string firstCommand = Console.ReadLine();
        string secondCommand = Console.ReadLine();

        bool[] lapms = new bool[numOfLamps];
        int lastLamp = 0;

        for (int index = 0; index < lapms.Length; index++)
        {
            if (FindLastLamp(lapms, index) == 1)
            {
                lastLamp = index + 2;
            }
            TurnOnLamps(lapms, index);
        }
        Console.WriteLine(lastLamp);

        //string firstCommand = "SSSSR";
        //string secondCommand = "L";

        int roboX = 0;
        int roboY = 0;
        int roboDirection = 1;

        foreach (var command in firstCommand)
        {
            if (command == 'L' || command == 'R')
            {
                roboDirection = GetDirection(roboDirection, command);
            }
            if (command == 'S')
            {
                if (roboDirection == 1)
                {
                    roboY++;
                }
                if (roboDirection == 2)
                {
                    roboX++;
                }
                if (roboDirection == -1)
                {
                    roboY--;
                } if (roboDirection == -2)
                {
                    roboX--;
                }
            }
            //if (roboDirection == 1 && command == 'S')
            //{
            //    roboX++;
            //}
            //if (roboDirection == 2 && command == 'S')
            //{
            //    roboY++;
            //}
            //if (roboDirection == -1 && command == 'S')
            //{
            //    roboX--;
            //}
            //if (roboDirection == -2 )
            //{
            //    roboY--;
            //}
        }
        if (roboX == 0 || roboY == 0)
        {
            Console.WriteLine("bounded");
        }
        else
        {
            Console.WriteLine("unbounded");
        }
        roboX = 0;
        roboY = 0;
        roboDirection = 1;
        foreach (var command in secondCommand)
        {
            if (command == 'L' || command == 'R')
            {
                roboDirection = GetDirection(roboDirection, command);
            }
            if (roboDirection == 1 && command == 'S')
            {
                roboX++;
            }
            if (roboDirection == 2 && command == 'S')
            {
                roboY++;
            }
            if (roboDirection == -1 && command == 'S')
            {
                roboX--;
            }
            if (roboDirection == -2 )
            {
                roboY--;
            }     
        }
        if (roboX == 0 || roboY == 0)
        {
            Console.WriteLine("bounded");
        }
        else
        {
            Console.WriteLine("unbounded");
        }
    }
    static int GetDirection(int currentDirection,char turn) 
    {
        int newDirection = 0;
        if (currentDirection == 1 && turn == 'R')
        {
            newDirection = 2;
        }
        if (currentDirection == 2 && turn == 'R')
        {
            newDirection = -1;
        }
        if (currentDirection == -1 && turn == 'R')
        {
            newDirection = -2;
        }
        if (currentDirection == -2 && turn == 'R')
        {
            newDirection = 1;
        }
        if (currentDirection == 1 && turn =='L')
        {
            newDirection = -2;
        }
        if (currentDirection == -2 && turn == 'L')
        {
            newDirection = -1;
        }
        if (currentDirection == -1 && turn == 'L')
        {
            newDirection = 2;
        }
        if (currentDirection == 2 && turn == 'L')
        {
            newDirection = 1;
        }
        return newDirection;
    }
}