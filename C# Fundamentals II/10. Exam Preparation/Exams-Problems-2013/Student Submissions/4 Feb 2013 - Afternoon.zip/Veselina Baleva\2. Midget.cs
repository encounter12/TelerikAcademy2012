using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            string valley = Console.ReadLine();
            char[] separator={' ', ','};
            string[] numbersInValley = valley.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            int m = int.Parse(Console.ReadLine());
            int best = int.MinValue;
            int current = 0;
            for (int i = 0; i < m; i++)
            {
                string patternStr = Console.ReadLine();
                string[] pattern = patternStr.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                bool[] isVisited = new bool[numbersInValley.Length];

                for (int n = 0; n < isVisited.Length ; n++)
                {
                    isVisited[n] = false;
                }

                int j = 0;
                int q=0;

                
                current = int.Parse(numbersInValley[0]);
                isVisited[0] = true;
                
              
                    for (int p = 0; p < pattern.Length; p++)
                    {

                        q = int.Parse(pattern[p]);
                        if (j + q >= numbersInValley.Length || j + q < 0)
                        {
                            break;
                        }
                        if (isVisited[j + q] )
                        {
                            break;
                        }
                        current += int.Parse(numbersInValley[j + q]);
                        isVisited[j + q] = true;
                        j += q;
                        if (p == pattern.Length - 1) p = -1;
               
                     }
                    if (current > best) best = current;             
                        
              }
            Console.WriteLine(best);
         }
    }
}
