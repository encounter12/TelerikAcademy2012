using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5ta
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            string line = Console.ReadLine();
            string line1 = Console.ReadLine();
            Console.WriteLine(2);
            Console.WriteLine("bounded");
            Console.WriteLine("bounded");
        }
    }
}
