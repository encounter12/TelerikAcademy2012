using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
         static void Main()
    {
        Console.WriteLine("Please write something:");
        string s = Console.ReadLine();

        Console.WriteLine("Please provide the number of lines N:");
        int n = int.Parse(Console.ReadLine());

        Console.WriteLine("Please provide the number of symbols on each line W:");
        int w = int.Parse(Console.ReadLine());

       

        Int32 middle = s.Length / 2;
        IDictionary<Int32, Int32> spaceOffsetsToParts = new Dictionary<Int32, Int32>();
        String[] parts = s.Split(' ');

        for (Int32 partIndex = 0, offset = 0; partIndex < parts.Length; partIndex++)
        {
            spaceOffsetsToParts.Add(offset, partIndex);
            offset += parts[partIndex].Length + 1; // +1 to count space that was removed by Split
        }

        foreach (var pair in spaceOffsetsToParts.OrderBy(entry => Math.Abs(middle - entry.Key)))
        {
            w--;
            if (w < 0)
                break;
            parts[pair.Value] += ' ';
        }
        Console.WriteLine("Result:  ", j);


        //if (str.Length > 20)
        //{
        //    string cut = str.Remove(20, (str.Length - 20));
        //    Console.WriteLine(cut);
        //}
        //else if (str.Length < 20)
        //{
        //    StringBuilder twentyChars = new StringBuilder();
        //    twentyChars.Append(str);

        //    while (twentyChars.Length < 20)
        //    {
        //        twentyChars.Append('*');
        //    }

        //    Console.WriteLine(twentyChars.ToString());
        }
    }
}
