using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static int N, M, maxSum = int.MinValue;
    static bool[] used;
    static int[] coins;
    static int[][] patterns;

    static void Main(string[] args)
    {

        string numbersAsStringLine = Console.ReadLine();
        char[] separators = new char[] { ',', ' ' };

        string[] numbersAsStrings = numbersAsStringLine.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        N = numbersAsStrings.Length;

        coins = new int[N];
        for (int i = 0; i < N; i++)
        {
            coins[i] = (int.Parse(numbersAsStrings[i]));
        }

        M = int.Parse(Console.ReadLine());

        patterns = new int[M][];

        for (int i = 0; i < M; i++)
        {
            numbersAsStringLine = Console.ReadLine();
            numbersAsStrings = numbersAsStringLine.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            patterns[i] = new int[numbersAsStrings.Length];
            for (int p = 0; p < numbersAsStrings.Length; p++)
            {
                patterns[i][p] = (int.Parse(numbersAsStrings[p]));
            }


        }

        solve();

    }

    static void solve()
    {
        try
        {
            PlayPatterns(0);
            Console.WriteLine("Unsolvable!");
        }
        catch (Exception)
        {
            //Console.WriteLine(ex.Message);
            Console.WriteLine(maxSum);
        }
    }

    static void PlayPatterns(int m)
    {
        if (m > M)
        {
            throw new Exception("Finished!");
        }
        used = new bool[N];
        int sum = CalcPattern(m);
        if (sum > maxSum) maxSum = sum;

        PlayPatterns(m + 1);

    }

    static int CalcPattern(int m)
    {


        int currentPatternPos = 0;
        used[0] = true;
        int currentPos = patterns[m][currentPatternPos];
        
        //int sum = coins[currentPos];
        int sum = coins[0];

        while ((currentPos < N) && (currentPos > -1) && (!used[currentPos]))
        {
            used[currentPos] = true;
            sum = sum + coins[currentPos];
            currentPatternPos++;
            currentPatternPos = currentPatternPos % patterns[m].Length;
            currentPos = currentPos + patterns[m][currentPatternPos];

        }

        return sum;
    }

}


