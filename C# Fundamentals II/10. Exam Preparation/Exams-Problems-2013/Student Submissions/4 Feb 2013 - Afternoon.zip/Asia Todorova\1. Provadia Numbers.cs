using System;
using System.Numerics;


class ProvadiaNumbers
{
    static void Main()
    {
        BigInteger n = int.Parse(Console.ReadLine());
        BigInteger mask = 0;
        double stepen = 0;

        while (mask <= n)
        {
            mask = (BigInteger)(Math.Pow(256, stepen));
            stepen++;
        }

        if (n == 0)
        {
            Console.WriteLine("A");
        }

        for (double i = stepen - 2; i >= 0; i--)
        {
            BigInteger exponent = (BigInteger)(Math.Pow(256, i));


            BigInteger digit = n / exponent;
            if (digit == 0) { Console.Write("A"); }
            else if (digit == 1) { Console.Write("B"); }
            else if (digit == 2) { Console.Write("C"); }
            else if (digit == 3) { Console.Write("D"); }
            else if (digit == 4) { Console.Write("E"); }
            else if (digit == 5) { Console.Write("F"); }
            else if (digit == 6) { Console.Write("G"); }
            else if (digit == 7) { Console.Write("H"); }
            else if (digit == 8) { Console.Write("I"); }
            else if (digit == 9) { Console.Write("J"); }
            else if (digit == 10) { Console.Write("K"); }
            else if (digit == 11) { Console.Write("L"); }
            else if (digit == 12) { Console.Write("M"); }
            else if (digit == 13) { Console.Write("N"); }
            else if (digit == 14) { Console.Write("O"); }
            else if (digit == 15) { Console.Write("P"); }
            else if (digit == 16) { Console.Write("Q"); }
            else if (digit == 17) { Console.Write("R"); }
            else if (digit == 18) { Console.Write("S"); }
            else if (digit == 19) { Console.Write("T"); }
            else if (digit == 20) { Console.Write("U"); }
            else if (digit == 21) { Console.Write("V"); }
            else if (digit == 22) { Console.Write("W"); }
            else if (digit == 23) { Console.Write("X"); }
            else if (digit == 24) { Console.Write("Y"); }
            else if (digit == 25) { Console.Write("Z"); }
            else if (digit > 25 && digit < 52) { Console.Write("a"); n = n % 26; i++; }
            else if (digit > 52 && digit < 78) { Console.Write("b"); n = n % 26; i++; }
            else if (digit > 78 && digit < 104) { Console.Write("c"); n = n % 26; i++; }
            else if (digit > 104 && digit < 130) { Console.Write("d"); n = n % 26; i++; }
            else if (digit > 130 && digit < 156) { Console.Write("e"); n = n % 26; i++; }
            else if (digit > 156 && digit < 182) { Console.Write("f"); n = n % 26; i++; }
            else if (digit > 182 && digit < 208) { Console.Write("g"); n = n % 26; i++; }
            else if (digit > 208 && digit < 234) { Console.Write("h"); n = n % 26; i++; }
            else if (digit > 234 && digit < 256) { Console.Write("i"); n = n % 26; i++; }
            if (n > 255)
            {
                n = n % exponent;
            }
        }
        Console.WriteLine();

        
    }
}

