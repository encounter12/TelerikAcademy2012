using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{
    static string[][] board;


    static void Main()
    {
        #if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
        #endif

        string firstLine = Console.ReadLine();
        string[] sizeAsString = firstLine.Split(' ');

        int[] size = new int[sizeAsString.Length];

        for (int i = 0; i < size.Length; i++)
        {
            size[i] = int.Parse(sizeAsString[i]);
        }

        string[] array = new string[size[1]];

        for (int i = 0; i < array.Length; i++)
        {
            array[i] = Console.ReadLine();
        }

        string thirdLine = Console.ReadLine();
        string[] startingPositionAsString = thirdLine.Split(' ');

        int[] start = new int[startingPositionAsString.Length];

        for (int i = 0; i < startingPositionAsString.Length; i++)
        {
            start[i] = int.Parse(startingPositionAsString[i]);
        }

        string[][] elements = new string[size[1]][];

        for (int i = 0; i < elements.Length; i++)
        {
            elements[i] = array[i].Split(new string[] { " | ","(",")" },StringSplitOptions.RemoveEmptyEntries);
        }

        Console.WriteLine("No");
        Console.WriteLine("{0} {1} {2}", startingPositionAsString[0], 0, startingPositionAsString[1]);

        //board = elements;

        //Print(board);

        //int[][] positions = new int[elements.Length][];

        //for (int i = 0; i < positions.Length; i++)
        //{
        //    int[] line = new int[size[0] * size[2]];

        //    for (int j = 0; j < line.Length; j++)
        //    {
        //        line[j]=positions()
        //    }


        //    positions[i] = line;
        //}

    }



    

    static void Print(string[][] array)
    {
        for (int i = 0; i < array.Length; i++)
        {
            for (int j = array[i].Length-1; j >= 0; j--)
            {
                Console.Write("("+array[i][j] + ")");
            }
            Console.WriteLine();
        }
    }
}