using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;


namespace AlignBoth
{
    class Program
    {
        static void Main(string[] args)
        {
            ushort n = ushort.Parse(Console.ReadLine());
            ushort w = ushort.Parse(Console.ReadLine());
            string str = Console.ReadLine();
            str = Regex.Replace(str, @"\s+", " ");
            string[] line = new string[n];
            for (int i = 0; i < str.Length; i++)
                {
                for (int k = 0; k <n; k++)
			   { 
			     line[k] =str.Substring(w*k,w);
                 Console.WriteLine(line[k]);
                    }
                }
            }

        }
    }
