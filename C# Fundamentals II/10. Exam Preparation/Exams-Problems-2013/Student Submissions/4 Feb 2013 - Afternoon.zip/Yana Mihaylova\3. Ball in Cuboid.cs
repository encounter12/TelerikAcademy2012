using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_3
{
    class ThirdTask
    {
        static void Main(string[] args)
        {
            Console.WriteLine("No");
            Console.WriteLine("2 2 0");
        }
    }
}
