using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProvadiaNums
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("input a number");
            long number = long.Parse(Console.ReadLine());
            char[] UpperAlphabet = new char[26];
            for (int i = 0; i < 26; i++)
            {
                UpperAlphabet[i] = (char)('A' + i);
            }
            char[] LowerAlphabet = new char[26];
            for (int i = 0; i < 26; i++)
            {
                LowerAlphabet[i] = (char)('a' + i);  
            }
            char[] lowerUpper = new char[26];
            for (int i = 26; i < 51; i++)
            {
                foreach (var item in LowerAlphabet)
                {
                    Console.WriteLine(string.Concat(UpperAlphabet));
                }
            }
            for (int i = 2*26; i <(2*26)+26 ; i++)
            {
                foreach (var item in lowerUpper)
                {
                    Console.WriteLine(string.Concat(UpperAlphabet));
                }
            }
        }
    }
}