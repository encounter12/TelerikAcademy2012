using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1___Provadia_numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            ulong num = ulong.Parse(Console.ReadLine());

            Console.WriteLine(GetColumnName(num));
        }
        static string GetColumnName(ulong index)
        {
            string letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string lettersS = "abcdefghijklmnopqrstuvwxyz";
            var value = "";

            if (index >= (ulong)letters.Length)
            {
                value += lettersS[(int)index / letters.Length - 1];
            }
            value += letters[(int)index % letters.Length];

            return value;
        }
    }
}
