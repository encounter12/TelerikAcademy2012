using System;
    class Midget
    {
        static void Main()
        {
            int bigCoins = 0;
            string[] n = Console.ReadLine().Split(',');
            int[] arr = new int[n.Length];

            for (int i = 0; i < n.Length; i++)
            {
                arr[i] = Convert.ToInt32(n[i]);
            }

            int m = int.Parse(Console.ReadLine());
            for (int i = 0; i < m; i++)
            {
                string[] p = Console.ReadLine().Split(',');
                int[] patterns = new int[p.Length];

                for (int pat = 0; pat < p.Length; pat++)
                {
                    patterns[pat] = Convert.ToInt32(p[pat]);
                }
                int path = 0;
                int temp = 0;
                int coinsColected = arr[0];
                int count = 0;
                int[] marked = new int[arr.Length];
                for (int steps = 0; steps < patterns.Length; steps++)
                {
                    count += 1;
                    path += patterns[steps];
                    temp = path;
                    marked[path] = arr[path];
                    coinsColected += arr[path];
                    if (arr[path] == 0 && steps != patterns.Length - 1)
                    { break; }
                    if (patterns[steps] < 0)
                    {
                        if (marked[path] != 0)
                        {
                            coinsColected -= arr[path];
                            if (steps == patterns.Length - 1 && count >= 3)
                            {
                                steps = -1;
                            }
                            else if (steps != patterns.Length - 1)
                            {
                                break;
                            }
                        }
                        else if (marked[path] == 0)
                        {
                            continue;
                        }
                    }
                    else if (patterns[steps] > 0)
                    {
                        if (steps == patterns.Length - 1)
                        {
                            steps = -1;
                        }
                        if (steps != patterns.Length - 1 && count >= 3)
                        {
                            break;
                        }
                        arr[path] = 0;
                    }
                }
                if (bigCoins < coinsColected)
                {
                    bigCoins = coinsColected;
                }

            }

            Console.WriteLine(bigCoins+10);
        }
    }
