using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cuboid
{
    class Program
    {
        static char[, ,] cuboid;
        static int maxLine = -1;
        static int countMaxLine = 0;

        static void Main(string[] args)
        {
            string[] dimensions = Console.ReadLine().Split(' ');
            //string[] dimensions = "4 3 5".Split(' ');
            int width = int.Parse(dimensions[0]);
            int height = int.Parse(dimensions[1]);
            int depth = int.Parse(dimensions[2]);

            cuboid = new char[depth, height, width];
            //string[] input = {
            //                    "AAAA AAAA ABAA AAAB AABA",
            //                    "AAAA BBBA AABA AABA ABAA",
            //                    "BBBB ABBB ABBB ABAB BBAA",

            //                  };
            FillCuboid(width, height, depth /*,input*/);
            SameSliceRows();
            SameSliceCols();
            SameSliceUpDiagonal();
            SameSliceDownDiagonal();

            DepthCheck();
            DepthDownRightDiagonal();
            DepthDownLeftDiagonal();
            DepthUpRightDiagonal();
            DepthUpLeftDiagonal();

            HorizontalDiagonal();
            HorizontalUpWardDiagonal();

            DepthDiagonalColumn();
            DepthDiagonalUpColumn();

            if (maxLine != -1)
            {
                Console.WriteLine("{0} {1}", maxLine, countMaxLine);
            }
            else
            {
                Console.WriteLine("-1");
            }


        }

        private static void DepthDiagonalUpColumn()
        {
            for (int rows = 0; rows < cuboid.GetLength(1); rows++)
            {
                for (int cols = 0; cols < cuboid.GetLength(2); cols++)
                {
                    for (int slice = 0; slice < cuboid.GetLength(0); slice++)
                    {
                        char color = cuboid[slice, rows, cols];
                        int currentCount = 0;
                        for (int slicesCheck = slice, rowsCheck = rows;
                            slicesCheck < cuboid.GetLength(0) && rowsCheck >= 0;
                            slicesCheck++, rowsCheck--)
                        {
                            if (cuboid[slicesCheck, rowsCheck, cols] == color)
                            {
                                currentCount++;
                            }
                            else break;
                        }

                        CheckMax(currentCount);

                    }
                }
            }
        }

        private static void DepthDiagonalColumn()
        {
            for (int rows = 0; rows < cuboid.GetLength(1); rows++)
            {
                for (int cols = 0; cols < cuboid.GetLength(2); cols++)
                {
                    for (int slice = 0; slice < cuboid.GetLength(0); slice++)
                    {
                        char color = cuboid[slice, rows, cols];
                        int currentCount = 0;
                        for (int slicesCheck = slice, rowsCheck = rows;
                            slicesCheck < cuboid.GetLength(0) && rowsCheck < cuboid.GetLength(1);
                            slicesCheck++, rowsCheck++)
                        {
                            if (cuboid[slicesCheck, rowsCheck, cols] == color)
                            {
                                currentCount++;
                            }
                            else break;
                        }

                        CheckMax(currentCount);

                    }
                }
            }
        }

        private static void DepthUpLeftDiagonal()
        {
            for (int rows = 0; rows < cuboid.GetLength(1); rows++)
            {
                for (int cols = 0; cols < cuboid.GetLength(2); cols++)
                {
                    for (int slice = 0; slice < cuboid.GetLength(0); slice++)
                    {
                        char color = cuboid[slice, rows, cols];
                        int currentCount = 0;
                        for (int slicesCheck = slice, rowsCheck = rows, colsCheck = cols;
                            slicesCheck < cuboid.GetLength(0) && colsCheck >= 0 && rowsCheck >= 0;
                            slicesCheck++, rowsCheck--, colsCheck--)
                        {
                            if (cuboid[slicesCheck, rowsCheck, colsCheck] == color)
                            {
                                currentCount++;
                            }
                            else break;
                        }

                        CheckMax(currentCount);

                    }
                }
            }
        }

        private static void DepthUpRightDiagonal()
        {
            for (int rows = 0; rows < cuboid.GetLength(1); rows++)
            {
                for (int cols = 0; cols < cuboid.GetLength(2); cols++)
                {
                    for (int slice = 0; slice < cuboid.GetLength(0); slice++)
                    {
                        char color = cuboid[slice, rows, cols];
                        int currentCount = 0;
                        for (int slicesCheck = slice, rowsCheck = rows, colsCheck = cols;
                            slicesCheck < cuboid.GetLength(0) && colsCheck < cuboid.GetLength(2) && rowsCheck >= 0;
                            slicesCheck++, rowsCheck--, colsCheck++)
                        {
                            if (cuboid[slicesCheck, rowsCheck, colsCheck] == color)
                            {
                                currentCount++;
                            }
                            else break;
                        }

                        CheckMax(currentCount);

                    }
                }
            }
        }


        private static void HorizontalUpWardDiagonal()
        {
            for (int rows = 0; rows < cuboid.GetLength(1); rows++)
            {
                for (int cols = 0; cols < cuboid.GetLength(2); cols++)
                {
                    for (int slice = 0; slice < cuboid.GetLength(0); slice++)
                    {
                        char color = cuboid[slice, rows, cols];
                        int currentCount = 0;
                        for (int slicesCheck = slice, colsCheck = cols;
                            slicesCheck < cuboid.GetLength(0) && colsCheck < cuboid.GetLength(2);
                            slicesCheck++, colsCheck++)
                        {
                            if (cuboid[slicesCheck, rows, colsCheck] == color)
                            {
                                currentCount++;
                            }
                            else break;
                        }

                        CheckMax(currentCount);

                    }
                }
            }
        }

        private static void HorizontalDiagonal()
        {
            for (int rows = 0; rows < cuboid.GetLength(1); rows++)
            {
                for (int cols = 0; cols < cuboid.GetLength(2); cols++)
                {
                    for (int slice = 0; slice < cuboid.GetLength(0); slice++)
                    {
                        char color = cuboid[slice, rows, cols];
                        int currentCount = 0;
                        for (int slicesCheck = slice, colsCheck = cols;
                            slicesCheck < cuboid.GetLength(0) && colsCheck >= 0;
                            slicesCheck++, colsCheck--)
                        {
                            if (cuboid[slicesCheck, rows, colsCheck] == color)
                            {
                                currentCount++;
                            }
                            else break;
                        }

                        CheckMax(currentCount);

                    }
                }
            }
        }

        private static void DepthDownRightDiagonal()
        {
            for (int rows = 0; rows < cuboid.GetLength(1); rows++)
            {
                for (int cols = 0; cols < cuboid.GetLength(2); cols++)
                {
                    for (int slice = 0; slice < cuboid.GetLength(0); slice++)
                    {
                        char color = cuboid[slice, rows, cols];
                        int currentCount = 0;
                        for (int slicesCheck = slice, rowsCheck = rows, colsCheck = cols;
                            slicesCheck < cuboid.GetLength(0) && colsCheck < cuboid.GetLength(2) && rowsCheck < cuboid.GetLength(1);
                            slicesCheck++, rowsCheck++, colsCheck++)
                        {
                            if (cuboid[slicesCheck, rowsCheck, colsCheck] == color)
                            {
                                currentCount++;
                            }
                            else break;
                        }

                        CheckMax(currentCount);

                    }
                }
            }
        }

        private static void DepthDownLeftDiagonal()
        {
            for (int rows = 0; rows < cuboid.GetLength(1); rows++)
            {
                for (int cols = 0; cols < cuboid.GetLength(2); cols++)
                {
                    for (int slice = 0; slice < cuboid.GetLength(0); slice++)
                    {
                        char color = cuboid[slice, rows, cols];
                        int currentCount = 0;
                        for (int slicesCheck = slice, rowsCheck = rows, colsCheck = cols;
                            slicesCheck < cuboid.GetLength(0) && colsCheck >= 0 && rowsCheck < cuboid.GetLength(1);
                            slicesCheck++, rowsCheck++, colsCheck--)
                        {
                            if (cuboid[slicesCheck, rowsCheck, colsCheck] == color)
                            {
                                currentCount++;
                            }
                            else break;
                        }

                        CheckMax(currentCount);

                    }
                }
            }
        }

        private static void SameSliceDownDiagonal()
        {
            for (int slice = 0; slice < cuboid.GetLength(0); slice++)
            {
                for (int rows = 0; rows < cuboid.GetLength(1); rows++)
                {
                    for (int cols = 0; cols < cuboid.GetLength(2); cols++)
                    {
                        char color = cuboid[slice, rows, cols];
                        int currentCount = 0;
                        for (int colsCheck = cols, rowsCheck = rows;
                            colsCheck < cuboid.GetLength(2) && rowsCheck < cuboid.GetLength(1);
                            colsCheck++, rowsCheck++)
                        {
                            if (cuboid[slice, rowsCheck, colsCheck] == color)
                            {
                                currentCount++;
                            }
                            else break;
                        }

                        CheckMax(currentCount);
                    }
                }
            }
        }

        private static void SameSliceUpDiagonal()
        {
            for (int slice = 0; slice < cuboid.GetLength(0); slice++)
            {
                for (int rows = 0; rows < cuboid.GetLength(1); rows++)
                {
                    for (int cols = 0; cols < cuboid.GetLength(2); cols++)
                    {
                        char color = cuboid[slice, rows, cols];
                        int currentCount = 0;
                        for (int colsCheck = cols, rowsCheck = rows;
                            colsCheck < cuboid.GetLength(2) && rowsCheck >= 0;
                            colsCheck++, rowsCheck--)
                        {
                            if (cuboid[slice, rowsCheck, colsCheck] == color)
                            {
                                currentCount++;
                            }
                            else break;
                        }

                        CheckMax(currentCount);

                    }
                }
            }
        }

        private static void DepthCheck()
        {

            for (int rows = 0; rows < cuboid.GetLength(1); rows++)
            {
                for (int cols = 0; cols < cuboid.GetLength(2); cols++)
                {
                    for (int slice = 0; slice < cuboid.GetLength(0); slice++)
                    {
                        char color = cuboid[slice, rows, cols];
                        int currentCount = 0;
                        for (int slicesCheck = slice; slicesCheck < cuboid.GetLength(0); slicesCheck++)
                        {
                            if (cuboid[slicesCheck, rows, cols] == color)
                            {
                                currentCount++;
                            }
                            else break;
                        }

                        CheckMax(currentCount);

                    }
                }
            }
        }

        private static void SameSliceCols()
        {
            for (int slice = 0; slice < cuboid.GetLength(0); slice++)
            {
                for (int cols = 0; cols < cuboid.GetLength(2); cols++)
                {
                    for (int rows = 0; rows < cuboid.GetLength(1); rows++)
                    {
                        char color = cuboid[slice, rows, cols];
                        int currentCount = 0;
                        for (int rowsCheck = rows; rowsCheck < cuboid.GetLength(1); rowsCheck++)
                        {
                            if (cuboid[slice, rowsCheck, cols] == color)
                            {
                                currentCount++;
                            }
                            else break;
                        }

                        CheckMax(currentCount);

                    }
                }
            }
        }

        private static void SameSliceRows()
        {
            for (int slice = 0; slice < cuboid.GetLength(0); slice++)
            {
                for (int rows = 0; rows < cuboid.GetLength(1); rows++)
                {
                    for (int cols = 0; cols < cuboid.GetLength(2); cols++)
                    {
                        char color = cuboid[slice, rows, cols];
                        int currentCount = 0;
                        for (int colsCheck = cols; colsCheck < cuboid.GetLength(2); colsCheck++)
                        {
                            if (cuboid[slice, rows, colsCheck] == color)
                            {
                                currentCount++;
                            }
                            else break;
                        }

                        CheckMax(currentCount);

                    }
                }
            }
        }

        private static void CheckMax(int currentCount)
        {
            if (currentCount > maxLine && currentCount > 1)
            {
                maxLine = currentCount;
                countMaxLine = 1;
            }
            else if (currentCount == maxLine)
            {
                countMaxLine++;
            }
        }

        private static void FillCuboid(int width, int height, int depth/*, string[] input*/)
        {
            for (int rows = 0; rows < height; rows++)
            {
                //string[] line = input[rows].Split(' ');
                string[] line = Console.ReadLine().Split(' ');
                int lineLength = line.Length;

                for (int slices = 0; slices < lineLength; slices++)
                {
                    int slicesLength = line[slices].Length;

                    for (int cols = 0; cols < slicesLength; cols++)
                    {
                        cuboid[slices, rows, cols] = line[slices][cols];
                    }
                }

            }
        }
    }
}