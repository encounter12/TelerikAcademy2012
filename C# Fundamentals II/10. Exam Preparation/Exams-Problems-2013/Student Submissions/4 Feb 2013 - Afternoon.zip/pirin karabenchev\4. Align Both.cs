using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4.Again
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int w = int.Parse(Console.ReadLine());

            List<string> words = new List<string>();
            char[] separator = new char[] { ' ' };

            for (int i = 0; i < n; i++)
            {
                string[] lineWords = Console.ReadLine().Split(separator, StringSplitOptions.RemoveEmptyEntries);
                for (int j = 0; j < lineWords.Length; j++)
                {
                    words.Add(lineWords[j]);
                }
            }
            //words.Add("");
            //for (int i = 0; i < words.Count; i++)
            //{
            //    Console.WriteLine(words[i]);
            //}

            StringBuilder output = new StringBuilder();
            int currentWord = 0;

            while (currentWord < words.Count)
            {
                int lineLength = 0;
                int endWord = currentWord;
                int wordsPerLine = 0;
                int totalCharsPerLine = 0;
                while (endWord<words.Count-1)
                {
                    if (lineLength + words[endWord].Length > w)
                    {
                        endWord--;
                        break;
                    }
                    else
                    {
                        lineLength += words[endWord].Length;
                        wordsPerLine++;
                        
                        totalCharsPerLine += words[endWord].Length;
                        if (lineLength == w)
                        {
                            break;
                        }
                        else
                        {
                            lineLength++;
                        }
                        endWord++;
                    }
                }

                //if (endWord == words.Count - 1)
                //{
                //    output.Append(words[endWord]);
                //    break;
                //}
                if (wordsPerLine == 1)
                {
                    output.Append(words[endWord]);
                    //output.Append('!');
                    output.AppendLine();
                    currentWord = endWord + 1;
                }
                else
                {
                    if (endWord != words.Count - 1)
                    {

                        int spaceSize = (w - totalCharsPerLine) / (wordsPerLine - 1);
                        int addSpaceSizeCount = (w - totalCharsPerLine) % (wordsPerLine - 1);
                        for (int i = currentWord; i < endWord; i++)
                        {
                            output.Append(words[i]);
                            output.Append(new string(' ', spaceSize));
                            if (addSpaceSizeCount-- > 0)
                            {
                                output.Append(" ");
                            }
                        }
                        output.Append(words[endWord]);
                        //output.Append('!');
                        output.AppendLine();
                        currentWord = endWord + 1;
                    }
                    else
                    {
                        endWord--;
                        int spaceSize = (w - totalCharsPerLine) / (wordsPerLine - 1);
                        int addSpaceSizeCount = (w - totalCharsPerLine) % (wordsPerLine - 1);
                        for (int i = currentWord; i < endWord; i++)
                        {
                            output.Append(words[i]);
                            output.Append(new string(' ', spaceSize));
                            if (addSpaceSizeCount-- > 0)
                            {
                                output.Append(" ");
                            }
                        }
                        output.Append(words[endWord]);
                        //output.Append('!');
                        output.AppendLine();
                        currentWord = endWord + 1;
                        endWord++;
                        output.Append(words[endWord]);
                        break;
                    }
                }
            }
            Console.WriteLine(output);
        }
    }
}