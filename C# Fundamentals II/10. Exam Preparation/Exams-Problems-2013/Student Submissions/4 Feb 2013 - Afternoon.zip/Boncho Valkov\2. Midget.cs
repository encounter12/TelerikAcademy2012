using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class midget
{
    static void Main()
    {
        string valley = Console.ReadLine();
        int[] arrValley = valley.Split(',').Select(n => Convert.ToInt32(n)).ToArray();
        int numberOfPatterns = int.Parse(Console.ReadLine());
        int maxCointCOllected = int.MinValue;
        for (int i = 0; i < numberOfPatterns; i++)
        {
            int currentCoinsCOllected = 0;
            string pattern = Console.ReadLine();
            int[] currentPattern = pattern.Split(',').Select(n => Convert.ToInt32(n)).ToArray();
            bool[] beenHere = new bool[arrValley.Length];
            int indexPattern = 0;
            int indexValley = 0;
            while (true)
            {
                if (indexValley > arrValley.Length - 1 || indexValley < 0)
                {
                    break;
                }
                if (indexPattern == currentPattern.Length)
                {
                    indexPattern = 0;
                }
                if (beenHere[indexValley])
                {
                    break;
                }

                currentCoinsCOllected += arrValley[indexValley];
                beenHere[indexValley] = true;
                indexValley += currentPattern[indexPattern];
                indexPattern++;
            }
            if (currentCoinsCOllected > maxCointCOllected)
            {
                maxCointCOllected = currentCoinsCOllected;
            }
        }
        Console.WriteLine(maxCointCOllected);

    }
}// granichni sluchei

//1, 3,-6, 7, 4, 1, 12
//3
//1, 2, -3
//1, 3, -2
//1, -1