using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midget
{
    class Program
    {
        static int[] valley;
        static List<int[]> patterns = new List<int[]>();
        static int maxCoins = int.MinValue;

        static void Main()
        {
            ReadInput();

            MoveMidgets();

            Console.WriteLine(maxCoins);
        }

        private static void MoveMidgets()
        {
            bool isEnd = false;

            for (int i = 0; i < patterns.Count; i++)
            {
                bool[] visited = new bool[valley.Length];
                int coins = 0;
                int ind = 0;
                int k = 0;
                do
                {
                    visited[ind] = true;
                    coins += valley[ind];
                    ind += patterns[i][k % patterns[i].Length];
                    k++;
                    isEnd = (ind < 0 || ind > valley.Length - 1 || visited[ind] == true);
                } while (!isEnd);

                if (maxCoins < coins)
                {
                    maxCoins = coins;
                }
            }
        }

        private static void ReadInput()
        {
            string[] valleyStr = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

            int M = int.Parse(Console.ReadLine());

            for (int i = 0; i < M; i++)
            {
                string[] patternStr = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

                int[] pattern = new int[patternStr.Length];

                for (int j = 0; j < patternStr.Length; j++)
                {
                    pattern[j] = int.Parse(patternStr[j]);
                }

                patterns.Add(pattern);
            }

            valley = new int[valleyStr.Length];

            for (int i = 0; i < valleyStr.Length; i++)
            {
                valley[i] = int.Parse(valleyStr[i]);
            }
        }
    }
}
