using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Izpit
{
    class Program
    {
        static void Main(string[] args)
        {
            string strValley = Console.ReadLine();
            string[] strArrValley = strValley.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
 
            int[] arrValley = new int[strArrValley.Length];
            int[] arrPattern;
 
            int div = 0;
            List<int> whereIwas = new List<int>();
 
            for (int i = 0; i < strArrValley.Length; i++)
            {
                arrValley[i] = int.Parse(strArrValley[i]);
            }
 
            int numPattern = int.Parse(Console.ReadLine());
 
            int bestSum = -1000;
            int sum = arrValley[0];
            int NextPosValley;
            int LastPosValley = 0;
            bool step = false;
            bool stop = true;
 
            for (int i = 0; i < numPattern; i++)
            {
                string strPattern = Console.ReadLine();
                string[] strArrPatttern = strPattern.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                arrPattern = new int[strArrPatttern.Length];
                for (int k = 0; k < arrPattern.Length; k++)
                {
                    arrPattern[k] = int.Parse(strArrPatttern[k]);
                }
                step = false;
                while (stop)
                {
                     
                    NextPosValley = LastPosValley+ arrPattern[div % arrPattern.Length];
                    if (div > 0)
                    {
                        for (int c = 0; c < whereIwas.Count; c++)
                        {
                            if (whereIwas[c] == NextPosValley)
                            {
                                step = true;
                                break;
                            }
                        }
                    }
                    LastPosValley = NextPosValley;
 
                    whereIwas.Add(NextPosValley);
                     
                    
 
                     
                     
                    bool alreadyHere = step;
                    bool outOfBoundry = NextPosValley<0 || NextPosValley> arrValley.Length-1;
                    if (outOfBoundry || alreadyHere)
                    {
                        stop = false;
                        break;
                    }
 
                    sum = sum + arrValley[NextPosValley];
                    div++;
 
                    if (sum > bestSum)
                    {
                        bestSum = sum;
                    }
                }
            }
            Console.WriteLine(bestSum);
 
             
        }
    }
}