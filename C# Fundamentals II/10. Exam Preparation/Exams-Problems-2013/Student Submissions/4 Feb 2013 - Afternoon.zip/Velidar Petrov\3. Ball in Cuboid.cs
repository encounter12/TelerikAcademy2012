using System;

class BallInCuboid
{
    static int ballH = 0;
    static int ballW;
    static int ballD;

    static int cuboidW;
    static int cuboidH;
    static int cuboidD;

    static bool ballIsStuck = false;

    static Cube[, ,] cuboid;

    static void Main(string[] args)
    {
        string dimensionsStr = Console.ReadLine();
        string[] dimensions = dimensionsStr.Split(' ');
        cuboidW = int.Parse(dimensions[0]);
        cuboidH = int.Parse(dimensions[1]);
        cuboidD = int.Parse(dimensions[2]);

        cuboid = new Cube[cuboidW, cuboidH, cuboidD];

        for (int h = 0; h < cuboidH; h++)
        {
            string currentRow = Console.ReadLine();
            string[] dSequences = currentRow.Split('|');

            // run over the D squences:
            for (int d = 0; d < cuboidD; d++)
            {
                string[] wSequence = dSequences[d].Split(new char[] { ')' },
                        StringSplitOptions.RemoveEmptyEntries);

                for (int w = 0; w < cuboidW; w++)
                {
                    string cubeString = wSequence[w].Trim().Remove(0, 1);

                    string[] cubeParams = cubeString.Split(' ');
                    //Console.WriteLine("cubeString: {0}", cubeString);

                    switch (cubeParams[0])
                    {
                        case "S":
                            cuboid[w, h, d]
                                = new Cube('S', cubeParams[1]);
                            break;
                        case "T":
                            cuboid[w, h, d]
                                = new Cube('T',
                                    int.Parse(cubeParams[1]), 
                                    int.Parse(cubeParams[2]));
                            break;
                        case "E":
                            cuboid[w, h, d] = new Cube('E');
                            break;
                        case "B":
                            cuboid[w, h, d] = new Cube('B');
                            break;
                    }
                }
            }
        }

        string[] ballCoords = Console.ReadLine().Split(' ');
        ballW = int.Parse(ballCoords[0]);
        ballD = int.Parse(ballCoords[1]);

        // now let's get the baaaaaaal rooolling! :D

        while (!(BallIsOutside() || BallIsStuck())) 
        {
            MoveBall();
        }

        if (BallIsOutside())
        {
            ballH--;
            Console.WriteLine("Yes");
        }
        else if (BallIsStuck())
        {
            Console.WriteLine("No");
        }
        Console.WriteLine("{0} {1} {2}", ballW, ballH, ballD);
    }

    class Cube
    {
        public char type;   // 'S' or 'T' or 'E' or 'B'
        public string slideDirection;
        public int teleportW, teleportD;

        public Cube(char type, int teleportW, int teleportD)
        {
            this.type = type;
            this.teleportW = teleportW;
            this.teleportD = teleportD;
        }
        public Cube(char type, string slideDirection)
        {
            this.type = type;
            this.slideDirection = slideDirection;
        }
        public Cube(char type)
        {
            this.type = type;
        }
    }

    static void MoveBall()
    {
        // get the cube type
        Cube currentCube = cuboid[ballW, ballH, ballD];

        switch (currentCube.type)
        {
            case 'S':

                string slideDirection = currentCube.slideDirection;

                int newW;
                int newD;

                switch (slideDirection)
                {
                    case "L":
                        newW = ballW - 1;
                        if (!CoordInCuboid(newW, ballH, ballD))
                        {
                            ballIsStuck = true;
                            break;
                        }
                        ballH++;
                        ballW--;

                        break;
                    case "R":
                        newW = ballW + 1;
                        if (!CoordInCuboid(newW, ballH, ballD))
                        {
                            ballIsStuck = true;
                            break;
                        }
                        ballH++;
                        ballW++;

                        break;
                    case "F":
                        newD = ballD - 1;
                        if (!CoordInCuboid(ballW, ballH, newD))
                        {
                            ballIsStuck = true;
                            break;
                        }
                        ballH++;
                        ballD--;

                        break;
                    case "B":
                        newD = ballD + 1;
                        if (!CoordInCuboid(ballW, ballH, newD))
                        {
                            ballIsStuck = true;
                            break;
                        }
                        ballH++;
                        ballD++;

                        break;
                    case "FL":
                        newW = ballW - 1;
                        newD = ballD - 1;
                        if (!CoordInCuboid(newW, ballH, newD))
                        {
                            ballIsStuck = true;
                            break;
                        }
                        ballH++;
                        ballD--;
                        ballW--;

                        break;
                    case "FR":
                        
                        newW = ballW + 1;
                        newD = ballD - 1;
                        if (!CoordInCuboid(newW, ballH, newD))
                        {
                            ballIsStuck = true;
                            break;
                        }
                        ballH++;
                        ballD--;
                        ballW++;

                        break;
                    case "BL":
                        newW = ballW - 1;
                        newD = ballD + 1;

                        if (!CoordInCuboid(ballW, ballH, newD))
                        {
                            ballIsStuck = true;
                            break;
                        }
                        ballH++;
                        ballD++;
                        ballW--;

                        break;
                    case "BR":
                        
                        newW = ballW + 1;
                        newD = ballD + 1;

                        if (!CoordInCuboid(ballW, ballH, newD))
                        {
                            ballIsStuck = true;
                            break;
                        }
                        ballH++;
                        ballD++;
                        ballW++;

                        break;
                }
                break;
            case 'T':
                // teleport
                ballW = currentCube.teleportW;
                ballD = currentCube.teleportD;

                break;
            case 'E':
                // empty cube
                ballH++;

                break;
        }

    }

    static bool BallIsOutside()
    {
        return (ballH > (cuboidH - 1));
    }

    static bool BallIsStuck()
    {
        return (ballIsStuck || cuboid[ballW, ballH, ballD].type == 'B');
    }

    static bool CoordInCuboid(int w, int h, int d) 
    {
        return (w >= 0 && w <= cuboidW - 1 &&
            h >= 0 && h <= cuboidH - 1 &&
            d >= 0 && d <= cuboidD - 1);
    }
}
