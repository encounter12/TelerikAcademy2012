using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fsafa
{
    class Program
    {
        static void Main(string[] args)
        {
            long numberToConvert = long.Parse(Console.ReadLine());
            List<long> result = new List<long>();
            string upperCase = "";

            string lowerCase = "";
            if (numberToConvert <= 25)
            {
                switch (numberToConvert)
                {
                    case 0: Console.WriteLine("A"); break;
                    case 1: Console.WriteLine("B"); break;
                    case 2: Console.WriteLine("C"); break;
                    case 3: Console.WriteLine("D"); break;
                    case 4: Console.WriteLine("E"); break;
                    case 5: Console.WriteLine("F"); break;
                    case 6: Console.WriteLine("G"); break;
                    case 7: Console.WriteLine("H"); break;
                    case 8: Console.WriteLine("I"); break;
                    case 9: Console.WriteLine("J"); break;
                    case 10: Console.WriteLine("K"); break;
                    case 11: Console.WriteLine("L"); break;
                    case 12: Console.WriteLine("M"); break;
                    case 13: Console.WriteLine("N"); break;
                    case 14: Console.WriteLine("O"); break;
                    case 15: Console.WriteLine("P"); break;
                    case 16: Console.WriteLine("Q"); break;
                    case 17: Console.WriteLine("R"); break;
                    case 18: Console.WriteLine("S"); break;
                    case 19: Console.WriteLine("T"); break;
                    case 20: Console.WriteLine("U"); break;
                    case 21: Console.WriteLine("V"); break;
                    case 22: Console.WriteLine("W"); break;
                    case 23: Console.WriteLine("X"); break;
                    case 24: Console.WriteLine("Y"); break;
                    case 25: Console.WriteLine("Z"); break;
                }
            }
            
            else if (numberToConvert > 25 && numberToConvert < 256)
            {
                while (numberToConvert > 0)
                {
                    
                result.Add(numberToConvert % 25);
                numberToConvert = numberToConvert / 25;
                }
                result.Reverse();
                for (int j = 0; j < result.Count; j++)
			{
                if (j == 0)
                {
                    switch (result[j])
                    {
                        case 1: lowerCase = "a"; break;
                        case 2: lowerCase = "b"; break;
                        case 3: lowerCase = "c"; break;
                        case 4: lowerCase = "d"; break;
                        case 5: lowerCase = "e"; break;
                        case 6: lowerCase = "f"; break;
                        case 7: lowerCase = "g"; break;
                        case 8: lowerCase = "h"; break;
                        case 9: lowerCase = "i"; break;
                        case 10: lowerCase = "j"; break;
                        case 11: lowerCase = "k"; break;
                        case 12: lowerCase = "l"; break;
                        case 13: lowerCase = "m"; break;
                        case 14: lowerCase = "n"; break;
                        case 15: lowerCase = "o"; break;
                        case 16: lowerCase = "p"; break;
                        case 17: lowerCase = "q"; break;
                        case 18: lowerCase = "r"; break;
                        case 19: lowerCase = "s"; break;
                        case 20: lowerCase = "t"; break;
                        case 21: lowerCase = "u"; break;
                        case 22: lowerCase = "v"; break;
                        case 23: lowerCase = "w"; break;
                        case 24: lowerCase = "x"; break;
                        case 25: lowerCase = "y"; break;
                        case 26: lowerCase = "z"; break;

                    }

                }
                else
                {
                    switch (result[j])
                    {
                        case 1: lowerCase = "A"; break;
                        case 2: lowerCase = "B"; break;
                        case 3: lowerCase = "C"; break;
                        case 4: lowerCase = "D"; break;
                        case 5: lowerCase = "E"; break;
                        case 6: lowerCase = "F"; break;
                        case 7: lowerCase = "G"; break;
                        case 8: lowerCase = "H"; break;
                        case 9: lowerCase = "I"; break;
                        case 10: lowerCase = "J"; break;
                        case 11: lowerCase = "K"; break;
                        case 12: lowerCase = "L"; break;
                        case 13: lowerCase = "M"; break;
                        case 14: lowerCase = "N"; break;
                        case 15: lowerCase = "O"; break;
                        case 16: lowerCase = "P"; break;
                        case 17: lowerCase = "P"; break;
                        case 18: lowerCase = "R"; break;
                        case 19: lowerCase = "S"; break;
                        case 20: lowerCase = "T"; break;
                        case 21: lowerCase = "U"; break;
                        case 22: lowerCase = "V"; break;
                        case 23: lowerCase = "W"; break;
                        case 24: lowerCase = "X"; break;
                        case 25: lowerCase = "Y"; break;
                        case 26: lowerCase = "Z"; break;

                    }
                }
               
                     Console.Write(lowerCase);
                }

                
                
            }
            else
                {
                while (numberToConvert > 0)
                {
                    result.Add(numberToConvert % 256);
                    numberToConvert = numberToConvert / 256;
                }
                result.Reverse();
                for (int i = 0; i <result.Count; i++)
                {
                   
                        switch (result[i])
                        {
                            case 0: upperCase = "A"; break;
                            case 1: upperCase ="B"; break;
                            case 2: upperCase="C"; break;
                            case 3: upperCase="D"; break;
                            case 4: upperCase="E"; break;
                            case 5: upperCase="F"; break;
                            case 6: upperCase="G"; break;
                            case 7: upperCase="H"; break;
                            case 8: upperCase="I"; break;
                            case 9: upperCase="J"; break;
                            case 10: upperCase="K"; break;
                            case 11: upperCase="L"; break;
                            case 12: upperCase="M"; break;
                            case 13: upperCase="N"; break;
                            case 14: upperCase="O"; break;
                            case 15: upperCase="P"; break;
                            case 16: upperCase="Q"; break;
                            case 17: upperCase="R"; break;
                            case 18: upperCase="S"; break;
                            case 19: upperCase="T"; break;
                            case 20: upperCase="U"; break;
                            case 21: upperCase="V"; break;
                            case 22: upperCase="W"; break;
                            case 23: upperCase="X"; break;
                            case 24: upperCase="Y"; break;
                            case 25: upperCase="Z"; break;
                        }
                      /*  switch (result[i])
                        {
                            case 0: lowerCase= "a"; break;
                            case 1: lowerCase = "b"; break;
                            case 2: lowerCase = "c"; break;
                            case 3: lowerCase = "d"; break;
                            case 4: lowerCase = "e"; break;
                            case 5: lowerCase = "f"; break;
                            case 6: lowerCase = "g"; break;
                            case 7: lowerCase = "h"; break;
                            case 8: lowerCase = "i"; break;
                            case 9: lowerCase = "j"; break;
                            case 10: lowerCase = "k"; break;
                            case 11: lowerCase = "l"; break;
                            case 12: lowerCase = "m"; break;
                            case 13: lowerCase = "n"; break;
                            case 14: lowerCase = "o"; break;
                            case 15: lowerCase = "p"; break;
                            case 16: lowerCase = "q"; break;
                            case 17: lowerCase = "r"; break;
                            case 18: lowerCase = "s"; break;
                            case 19: lowerCase = "t"; break;
                            case 20: lowerCase = "u"; break;
                            case 21: lowerCase = "v"; break;
                            case 22: lowerCase = "w"; break;
                            case 23: lowerCase = "x"; break;
                            case 24: lowerCase = "y"; break;
                            case 25: lowerCase = "z"; break;
                        }*/
                        Console.Write(upperCase);
                    }
                
                }
            }
        }
    }


