using System;


namespace Izpit
{
    class Exam
    {
        static void Main(string[] args)
        {
            int numLamps = int.Parse(Console.ReadLine());
            //string commandsForJoro = Console.ReadLine();
            //string anotherCommandsForJoro = Console.ReadLine();

            int lastLamp = GetNumberOffLastTurnedOnLamp(numLamps);
            Console.WriteLine(lastLamp);

        }

        private static int GetNumberOffLastTurnedOnLamp(int numLamps)
        {
            int[] lamps = new int[numLamps];

            int lastTurnOn = 0;
            int indexOfTurnedOffLamp = Array.IndexOf(lamps, 0);

            for (int index = indexOfTurnedOffLamp; index < lamps.Length; index+=2)
            {
                lamps[index] = 1;
                for (int i = index; i < lamps.Length; i+=2+index)
                {
                    indexOfTurnedOffLamp = Array.IndexOf(lamps, 0);
                    
                }
            }

            return lastTurnOn = indexOfTurnedOffLamp + 1;

        }
    }
}
