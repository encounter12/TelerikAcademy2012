using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class PrograProvadiaNumbers
{
    static string[] provadiaNums ={"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w",
                                  "x","w","z"};
    static void Main(string[] args)
    {
        
        long input = long.Parse(Console.ReadLine());
        string result;
        if (input <= 25)
        {
            result = provadiaNums[input].ToUpper();
        }
        else
        {
            result = ConvertToSBased(input, 26);
            if (result.Length % 2 == 0)
            {
                StringBuilder temp = new StringBuilder();
                for (int i = 1; i < result.Length; i += 2)
                {

                    temp.Append(result);
                    temp[i] = Convert.ToChar(result[i].ToString().ToUpper());
                }
                result = temp.ToString();
            }
            else
            {
                StringBuilder temp = new StringBuilder();
                for (int i = 0; i < result.Length; i += 2)
                {

                    temp.Append(result);
                    temp[i] = Convert.ToChar(result[i].ToString().ToUpper());
                }
                result = temp.ToString();
            }
            
        }
        Console.WriteLine(result);
    }
    public static string ConvertToSBased(long number, int s)
    {
        string temp = string.Empty;
        while (number > 0)
        {
            if (number % s == 0)
            {
                temp = provadiaNums[0] + temp;
            }
            else if (number==1)
            {
                temp = provadiaNums[0] + temp; 
            }
            else
            {
                temp = provadiaNums[number % s] + temp;
                
            }
            number = number / s;
        }
        return temp;
    }  
}

