using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
        {

        ushort n = ushort.Parse(Console.ReadLine());
        ushort w = ushort.Parse(Console.ReadLine());
        
        while (n < 1000 && w < 10000)
            {
                string text = (Console.ReadLine());

                int count = 0;
                foreach (char a in text)
                {
                    if (char.IsLetterOrDigit(a))
                    {
                        count++;
                    }
                }
                Console.WriteLine(count);
                Console.ReadLine();
            }
        }
}
