using System;
using System.Collections.Generic;
using System.Numerics;

namespace Task2
{
	class Task2
	{
		static void Main()
		{
			string sValley = Console.ReadLine();
			var valley =  GetInputArray(sValley);

			int patternsCount = int.Parse(Console.ReadLine());

			var patterns = new List<short[]>();
			for (int i = 0; i < patternsCount; i++)
			{
				var sPattern = Console.ReadLine();
				patterns.Add(GetInputArray(sPattern));
			}

			BigInteger maxCoins = int.MinValue;
			for (int i = 0; i < patternsCount; i++)
			{
				var curentCoins = GetCollectedCoins(valley, patterns[i]);
				if(curentCoins > maxCoins)
				{
					maxCoins = curentCoins;
				}
			}

			Console.WriteLine(maxCoins);
		}

		private static BigInteger GetCollectedCoins(short[] valley, short[] pattern)
		{
			var moves = new bool[valley.Length];

			bool wasStepped = false;
			bool outOfValley = false;
			BigInteger collectedCoins = 0;
			int patternIndex = 0;
			int valleyIndex = 0;

			do
			{
				if(valleyIndex < 0 || valleyIndex > valley.Length-1)
				{
					break;
				}

				if(moves[valleyIndex])
				{
					break;
				}

				collectedCoins += valley[valleyIndex];
				moves[valleyIndex] = true;
				valleyIndex += pattern[patternIndex];

				if(patternIndex >= pattern.Length -1)
				{
					patternIndex = 0;
				}
				else
				{
					patternIndex++;
				}
				
			} while (!wasStepped && !outOfValley);

			return collectedCoins;
		}

		private static short[] GetInputArray(string sValley)
		{
			string[] valleyArr = sValley.Split(',');

			var valley = new short[valleyArr.Length];
			for (int i = 0; i < valleyArr.Length; i++)
			{
				valley[i] = short.Parse(valleyArr[i].Trim());
			}

			return valley;
		}
	}
}
