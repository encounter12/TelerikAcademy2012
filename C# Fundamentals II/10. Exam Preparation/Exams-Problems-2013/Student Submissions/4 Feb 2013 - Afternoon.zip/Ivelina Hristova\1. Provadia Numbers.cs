using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;
class Program
{
    static string digits(BigInteger number)
    {
        StringBuilder digit = new StringBuilder();
        BigInteger i = number / 26;
        if (i>=1)
        {
            char first = (char)(97 + i - 1);
            digit.Append(first.ToString());
        }
        
        char last = (char)(number % 26 + 65);
        digit.Append(last.ToString());
        return digit.ToString();
    }
    static void Reverse(BigInteger number)
    {
        StringBuilder provadia = new StringBuilder();
        List<string> provadiaNotReversed = new List<string>();
        while (number>255)
        {
            provadiaNotReversed.Add(digits(number % 256));
            number /= 256;
        }
        provadiaNotReversed.Add(digits(number));
        for (int i =  provadiaNotReversed.Count-1; i >=0; i--)
        {
            provadia.Append(provadiaNotReversed[i]);
        }
        Console.WriteLine(provadia.ToString());
    }
    static void Main()
    {
        BigInteger number = BigInteger.Parse(Console.ReadLine());
        Reverse(number);
    }
}