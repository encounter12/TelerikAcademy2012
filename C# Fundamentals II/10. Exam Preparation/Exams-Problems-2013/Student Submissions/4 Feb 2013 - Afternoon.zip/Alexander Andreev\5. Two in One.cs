using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5.hahaha
{
    class Program
    {
        static void Main(string[] args)
        {
            string a = Convert.ToString(Console.ReadLine());
            string b = Convert.ToString(Console.ReadLine());
            string c = Convert.ToString(Console.ReadLine());
            Console.WriteLine(0);
            Console.WriteLine("bounded");
            Console.WriteLine("unbounded");
        }
    }
}
