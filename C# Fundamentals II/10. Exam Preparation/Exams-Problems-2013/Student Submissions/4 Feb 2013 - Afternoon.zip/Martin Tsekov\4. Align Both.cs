using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
 
namespace Justify_text
{
    class Program
    {
        static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());
            int maxL = int.Parse(Console.ReadLine());
            string text = "";
            for (int i = 0; i < lines; i++)
            {
                text += Console.ReadLine().Trim() + "\n";
            }
 
            text = " " + String.Join(" ", text.Split(new char[] { ' ', '\n' }, StringSplitOptions.RemoveEmptyEntries)) + " ";
             
            Regex regex = new Regex(@"(?<=\s)(.{1,"+maxL+@"}\b)(?=\s)");
            MatchCollection rows = regex.Matches(text);
             
            string line = "";
            foreach (Match l in rows)
            {
                line = l.ToString();
                int spaces = 1;
                while (line.Length < maxL)
                {
                    if (line.IndexOf(' ') < 0) break;
                    Regex rex = new Regex(@"\b(\s{"+spaces+@"})\b");
                    if (!rex.IsMatch(line)) { spaces++; }
                    line = rex.Replace(line, "$1 ", 1);
 
                }
                Console.WriteLine(line);
            }
        }
    }
}