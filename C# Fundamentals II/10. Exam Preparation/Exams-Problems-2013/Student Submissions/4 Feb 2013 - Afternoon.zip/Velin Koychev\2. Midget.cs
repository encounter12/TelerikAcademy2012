using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Problem2
{
    static void Main()
    {
        string valley = Console.ReadLine();
        char[] delimiters = new char[] { ' ', ',' };
        string[] valleyArray = valley.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
        List<int> valleyNumbers = new List<int>();
        foreach (var item in valleyArray)
        {
            valleyNumbers.Add(Convert.ToInt32(item));
        }
        int mNUmber = int.Parse(Console.ReadLine());
        List<string> patterns = new List<string>();
        for (int i = 0; i < mNUmber; i++)
        {
            string newPattern = Console.ReadLine();
            patterns.Add(newPattern);
        }
        int bestSum = int.MinValue;
        for (int i = 0; i < patterns.Count; i++)
        {
            string patternToCheck = patterns[i];
            string[] patternNumbers = patternToCheck.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
            List<int> valleyNewNumbers= new List<int>(valleyNumbers);
            List<int> numbers = new List<int>();
            foreach (string item in patternNumbers)
            {
                numbers.Add(Convert.ToInt32(item));
            }

            int currentSum = valleyNewNumbers[0];
            valleyNewNumbers[0] = int.MinValue;
            int currentLocation = 0;
            for (int j = 0; j < numbers.Count + 1; j++)
            {
                if (j == numbers.Count)
                {
                    j = 0;
                }
                int changeLocation = numbers[j];
                if ((currentLocation + changeLocation < valleyNewNumbers.Count) && (currentLocation + changeLocation > 0))
                {
                    if (valleyNewNumbers[currentLocation + changeLocation] != int.MinValue)
                    {
                        currentSum = currentSum + valleyNewNumbers[currentLocation + changeLocation];
                        valleyNewNumbers[currentLocation + changeLocation] = int.MinValue;
                        currentLocation = currentLocation + changeLocation;
                    }
                    else
                    {
                        if (currentSum > bestSum)
                        {
                            bestSum = currentSum;
                        }
                        break;
                    }
                }
                else
                {
                    if (currentSum > bestSum)
                    {
                        bestSum = currentSum;
                    }
                    break;
                }

            }
        }
        Console.WriteLine(bestSum);

    }
}
