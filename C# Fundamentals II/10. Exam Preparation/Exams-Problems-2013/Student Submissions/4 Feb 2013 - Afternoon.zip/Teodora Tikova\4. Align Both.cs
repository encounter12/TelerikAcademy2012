using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

    class AlignBoth
    {
        static void Main()
        {
            int k = int.Parse(Console.ReadLine());
            int w = int.Parse(Console.ReadLine());
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < k; i++)
            {
                string j = Console.ReadLine();
                builder.Append(j + "\n");
            }
            string text = builder.ToString();

            //string text = "Beer beer beer Im going for\n  a\n beer beer beer Im gonna\n dring some beer\n I Love drinkiiiiiiiiiiiiiiing\n beeer\n lovely\n   lovelu\nbeer\nbeer\n";
            string pattern = @"\s+|,\s*|\.\s*|!\s*";
            List<string> wordInText = new List<string>();


            foreach (string word in Regex.Split(text, pattern))
            {
                wordInText.Add(word);
            }

            char[] row = new char[w];
            int freeCells = w;
            int lastFullCell =0;
            for (int i = 0; i < wordInText.Count; i++)
            {
                if (freeCells > wordInText[i].Length)
                {
                    for (int j = 0; j < wordInText[i].Length; j++)
                    {
                        row[lastFullCell + j] = wordInText[i][j];
                    }
                    row[wordInText[i].Length+lastFullCell] = '\t';
                    freeCells -= wordInText[i].Length+1;
                    lastFullCell += wordInText[i].Length +1;
                }
                else 
                {
                    foreach (var item in row)
	                    {
                            Console.Write(item);
	                    }
                    Console.WriteLine();
                    for (int h = 0; h < row.Length; h++)
                    {
                        row[h] = '0';
                        
                    }
                    freeCells = w;
                    lastFullCell = 0;
                    for (int j = 0; j < wordInText[i].Length; j++)
                    {
                        row[lastFullCell + j] = wordInText[i][j];
                    }
                    row[wordInText[i].Length + lastFullCell] = '\t';
                    freeCells -= wordInText[i].Length + 1;
                    lastFullCell += wordInText[i].Length + 1;
                }  
            }


        }
    }
