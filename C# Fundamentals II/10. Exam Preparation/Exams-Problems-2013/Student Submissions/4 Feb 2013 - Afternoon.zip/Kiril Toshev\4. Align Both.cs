using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class AlignBoth
{
    static void Main()
    {
        int numOfLines = int.Parse(Console.ReadLine());
        int lineWidth = int.Parse(Console.ReadLine());
        List<string> allWords = new List<string>();
        for (int lines = 0; lines < numOfLines; lines++)
		{
            string pattern = @"\b\w+\b";
            MatchCollection wordInLine = Regex.Matches(Console.ReadLine(), pattern);
            foreach (var word in wordInLine)
            {
                allWords.Add(word.ToString());
            }
		}
        StringBuilder line = new StringBuilder();
        bool exit = false;
        for (int wordIndex = 0; wordIndex < allWords.Count && (!exit);)
        {
            while (line.Length < lineWidth)
            {
                if (line.Length + allWords[wordIndex].Length < lineWidth)
                {
                    if (line.Length != 0)
                    {
                        line.Append(" ");
                    }
                    line.Append(allWords[wordIndex]);
                    if (wordIndex + 1 == allWords.Count)
                    {
                        exit = true;
                        break;
                    }
                    wordIndex++;
                }
                else
                {
                    int startIndex = line.ToString().IndexOf(' ', 0);
                    while (line.Length < lineWidth )
                    {
                        line.Insert(startIndex,' ');
                        if (line.ToString().IndexOf(' ', (startIndex + 1)) < line.Length)
                        {
                            startIndex = line.ToString().IndexOf(' ', (startIndex + 4));
                        }
                        else
                        {
                            startIndex = 0;
                        }
                    }
                }
            }
            Console.WriteLine(line.ToString());
            line.Clear();
        }
    }
}