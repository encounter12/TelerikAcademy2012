using System;
using System.Text;
 
class ProvadiaNumbers
{
    static string provadianPrimes =
        "A B C D E F G H I J K L M N O P Q R S T U V W X Y Z " +
        "aAaBaCaDaEaFaGaHaIaJaKaLaMaNaOaPaQaRaSaTaUaVaWaXaYaZ"
      + "bAbBbCbDbEbFbGbHbIbJbKbLbMbNbObPbQbRbSbTbUbVbWbXbYbZ"
      + "cAcBcCcDcEcFcGcHcIcJcKcLcMcNcOcPcQcRcScTcUcVcWcXcYcZ"
      + "dAdBdCdDdEdFdGdHdIdJdKdLdMdNdOdPdQdRdSdTdUdVdWdXdYdZ"
      + "eAeBeCeDeEeFeGeHeIeJeKeLeMeNeOePeQeReSeTeUeVeWeXeYeZ"
      + "fAfBfCfDfEfFfGfHfIfJfKfLfMfNfOfPfQfRfSfTfUfVfWfXfYfZ"
      + "gAgBgCgDgEgFgGgHgIgJgKgLgMgNgOgPgQgRgSgTgUgVgWgXgYgZ"
      + "hAhBhChDhEhFhGhHhIhJhKhLhMhNhOhPhQhRhShThUhVhWhXhYhZ"
      + "iAiBiCiDiEiFiGiHiIiJiKiLiMiNiOiPiQiRiSiTiUiViWiXiYiZ";
 
    static void Main()
    {
        ulong number = ulong.Parse(Console.ReadLine());
 
        if (number >= 0 && number <= 255)
        {
            Console.WriteLine(GetPrimeProvadianNumberString(number));
        }
        else if (number >= 256 && number <= 65535)
        {
            ulong multiplier = 1;
 
            ulong leftover = number - 256;
            ulong times = number / 256;
            while (leftover > 256)
            {
                leftover = number - 256 * multiplier++;
            }
             
 
            Console.WriteLine("{0}{1}",
                GetPrimeProvadianNumberString(times), GetPrimeProvadianNumberString(leftover));
        }
        else
        {
            Console.WriteLine("Shit happened. I got the right idea too late.");
        }
    }
 
    static string GetPrimeProvadianNumberString(ulong number)
    {
        if (number > 255)
        {
            throw new ArgumentOutOfRangeException("Prime Provadian Number"
                , "Input number must be in the range [0-255]");
        }
 
        string provNumber = provadianPrimes.Substring((int)number * 2, 2);
        return provNumber.Trim();
    }
}