using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5b
{
    class TwoInOne_B
    {
        static int lightedLamps;
        static void Main(string[] args)
        {
            // HARD CODE
            //int n = 12;
            //string inputPath = "SRSL";

            // CONSOLE INPUT
            int n = int.Parse(Console.ReadLine());
            string inputPath = Console.ReadLine();
            string inputPath2 = Console.ReadLine();

            List<int> lamps = new List<int>();
            lightedLamps = n;
            for (int i = 0; i < n; i++)
            {
                lamps.Add(i);
            }

            //ligth the lamps:
            LingthTheLamps(lamps, 1);

            //steps in path:
            Steps(inputPath);
            Steps(inputPath2);
        }
        static void LingthTheLamps(List<int> lamps, int lampsToSkip)
        {
            int ilamp;
            if (lightedLamps == 1)
            {
                Console.WriteLine(lamps[0] + 1);
                return;
            }
            else
            {
                for (ilamp = 0; ilamp < lamps.Count(); ilamp += lampsToSkip)
                {
                    if (lightedLamps == 1)
                    {
                        Console.WriteLine(lamps[0] + 1);
                    }
                    lamps.RemoveAt(ilamp);
                    lightedLamps--;
                }
                LingthTheLamps(lamps, lampsToSkip + 1);
            }
            
        }

        //second part
        static void Steps(string inputPath)
        {
            // my array of direction  +y | +x | -y | -x
            int[] stepsInDirection = new int[] { 0, 0, 0, 0 };
            int currentDirrection = 0;
            bool bounded;
            int counter = 1;
            do
            {
                for (int steps = 0; steps < inputPath.Length; steps++)
                {
                    switch (inputPath[steps])
                    {
                        case 'S': stepsInDirection[currentDirrection]++;
                            break;
                        case 'R':
                            if (currentDirrection == 3)
                            {
                                currentDirrection = 0;
                            }
                            else 
                            {
                                currentDirrection++;
                            }
                            break;
                        case 'L':
                            if (currentDirrection == 0)
                            {
                                currentDirrection = 3;
                            }
                            else
                            {
                                currentDirrection--;
                            }
                            break;
                        default: Console.WriteLine("Invalid Input");
                            break;
                    }
                }
                bounded = (stepsInDirection[0] - stepsInDirection[2] == 0)  &&
                           (stepsInDirection[1] - stepsInDirection[3] == 0);
                counter++;
            } while(!bounded && counter < 20);
           
            if (bounded)
            {
                Console.WriteLine("bounded");
            }
            else
            {
                Console.WriteLine("unbounded");
            }
        }
    }
}

