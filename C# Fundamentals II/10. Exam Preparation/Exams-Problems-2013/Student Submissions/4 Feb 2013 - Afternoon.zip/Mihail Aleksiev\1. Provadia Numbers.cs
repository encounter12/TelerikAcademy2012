using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2
{
    class Provadia
    {
        static void Main(string[] args)
        {
            ulong input = ulong.Parse(Console.ReadLine());
            Console.WriteLine(ToProvadian(input));
            
        }

        private static string ToProvadian(ulong number)
        {
            char[] caps = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            char[] smalls = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
            string[] proDigits = new string[257];
            int k = 0;
            for (int i = -1; i < smalls.Length; i++)
            {
                if (i < 0)
                {
                    for (int j = 0; j < caps.Length; j++)
                    {
                        proDigits[k] = caps[j].ToString();
                        k++;
                    }
                }
                else if (i < smalls.Length - 1)
                {
                    for (int j = 0; j < caps.Length; j++)
                    {
                        proDigits[k] = smalls[i].ToString() + caps[j].ToString();
                        k++;
                    }
                }
                else if (i == smalls.Length - 1)
                {
                    for (int j = 0; j < 22; j++)
                    {
                        proDigits[k] = smalls[i].ToString() + caps[j].ToString();
                        k++;
                    }
                }
            }
            if (number > 255)
                {
                    List<string> finalResult = new List<string>();
                ulong remainder;
                while (number != 0)
                {
                    remainder = number % 256;
                    finalResult.Add(proDigits[remainder]);
                    number = number / 256;
                }
                StringBuilder sbResult = new StringBuilder();
                for (int i = finalResult.Count - 1; i >= 0; i--)
                {
                    sbResult.Append(finalResult[i]);
                }
                return sbResult.ToString();
                }
            else
                {
                    return proDigits[number];
                }
        }
    }
}
