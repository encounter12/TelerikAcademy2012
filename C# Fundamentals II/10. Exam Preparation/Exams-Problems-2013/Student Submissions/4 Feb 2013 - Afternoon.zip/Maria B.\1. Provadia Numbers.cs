using System;
using System.Collections.Generic;
using System.Numerics;

class Program
{
    static void Main()
    {
        List<string> result = new List<string>();
        BigInteger n = new BigInteger();
        string str = Console.ReadLine();
        
        n = BigInteger.Parse(str);
        if (n == 0) { Console.WriteLine('A'); }
        else
        {
            int baseD = 256;
            string[] letters = new string[256];
            // fill arr 
            for (int i = 0; i < 26; i++)
            {
                letters[i] = ((char)('A' + i)).ToString();
            }
            for (int i = 26; i < 256; i++)
            {
                letters[i] = ((char)(i / 26 + 'a' - 1)).ToString();
                letters[i] = letters[i] + ((char)(i % 26 + 'A')).ToString();
            }
            while (n > 0)
            {
                int remainder = (int)(n % baseD);
                result.Add(letters[remainder]);
                n = n / baseD;
            }
            for (int i = result.Count - 1; i >= 0; i--)
            {
                Console.Write(result[i]);
            }
            Console.WriteLine();
        }
    }
}