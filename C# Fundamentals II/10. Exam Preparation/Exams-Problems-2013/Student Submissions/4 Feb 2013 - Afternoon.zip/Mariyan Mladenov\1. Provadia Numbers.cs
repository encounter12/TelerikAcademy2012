using System;
using System.Text;
using System.Linq;
class DecimalToHexademical
{
    static StringBuilder DecimalTOHezademic(ulong number)
    {
        StringBuilder convertedNum = new StringBuilder();
        while (number > 0)
        {
            switch (number % 256)
            {
                case 0:
                    convertedNum.Append('A');
                    break;
                case 1:
                    convertedNum.Append('B');
                    break;
                case 2:
                    convertedNum.Append('C');
                    break;
                case 3:
                    convertedNum.Append('D');
                    break;
                case 4:
                    convertedNum.Append('E');
                    break;
                case 5:
                    convertedNum.Append('F');
                    break;
                case 6:
                    convertedNum.Append('G');
                    break;
                case 7:
                    convertedNum.Append('H');
                    break;
                case 8:
                    convertedNum.Append('I');
                    break;
                case 9:
                    convertedNum.Append('J');
                    break;
                case 10:
                    convertedNum.Append('K');
                    break;
                case 11:
                    convertedNum.Append('L');
                    break;
                case 12:
                    convertedNum.Append('M');
                    break;
                case 13:
                    convertedNum.Append('N');
                    break;
                case 14:
                    convertedNum.Append('O');
                    break;
                case 15:
                    convertedNum.Append('P');
                    break;
                case 16:
                    convertedNum.Append('Q');
                    break;
                case 17:
                    convertedNum.Append('R');
                    break;
                case 18:
                    convertedNum.Append('S');
                    break;
                case 19:
                    convertedNum.Append('T');
                    break;
                case 20:
                    convertedNum.Append('U');
                    break;
                case 21:
                    convertedNum.Append('V');
                    break;
                case 22:
                    convertedNum.Append('W');
                    break;
                case 23:
                    convertedNum.Append('X');
                    break;
                case 24:
                    convertedNum.Append('Y');
                    break;
                case 25:
                    convertedNum.Append('Z');
                    convertedNum.Append('a');
                    break;
                case 26:
                    convertedNum.Append('A');
                    convertedNum.Append('a');
                    break;
                case 27:
                    convertedNum.Append('B');
                    convertedNum.Append('a');
                    break;
                case 28:
                    convertedNum.Append('C');
                    convertedNum.Append('a');
                    break;
                case 29:
                    convertedNum.Append('D');
                    convertedNum.Append('a');
                    break;
                case 30:
                    convertedNum.Append('E');
                    convertedNum.Append('a');
                    break;
                case 31:
                    convertedNum.Append('F');
                    convertedNum.Append('a');
                    break;
                case 32:
                    convertedNum.Append('G');
                    convertedNum.Append('a');
                    break;
                case 33:
                    convertedNum.Append('H');
                    convertedNum.Append('a');
                    break;
                case 34:
                    convertedNum.Append('I');
                    convertedNum.Append('a');
                    break;
                case 35:
                    convertedNum.Append('J');
                    convertedNum.Append('a');
                    break;
                case 36:
                    convertedNum.Append('K');
                    convertedNum.Append('a');
                    break;
                case 37:
                    convertedNum.Append('L');
                    convertedNum.Append('a');
                    break;
                case 38:
                    convertedNum.Append('M');
                    convertedNum.Append('a');
                    break;
                case 39:
                    convertedNum.Append('N');
                    convertedNum.Append('a');
                    break;
                case 40:
                    convertedNum.Append('O');
                    convertedNum.Append('a');
                    break;
                case 41:
                    convertedNum.Append('P');
                    convertedNum.Append('a');
                    break;
                case 42:
                    convertedNum.Append('Q');
                    convertedNum.Append('a');
                    break;
                case 43:
                    convertedNum.Append('R');
                    convertedNum.Append('a');
                    break;
                case 44:
                    convertedNum.Append('S');
                    convertedNum.Append('a');
                    break;
                case 45:
                    convertedNum.Append('T');
                    convertedNum.Append('a');
                    break;
                case 46:
                    convertedNum.Append('U');
                    convertedNum.Append('a');
                    break;
                case 47:
                    convertedNum.Append('V');
                    convertedNum.Append('a');
                    break;
                case 48:
                    convertedNum.Append('W');
                    convertedNum.Append('a');
                    break;
                case 49:
                    convertedNum.Append('X');
                    convertedNum.Append('a');
                    break;
                case 50:
                    convertedNum.Append('Y');
                    convertedNum.Append('a');
                    break;
                case 51:
                    convertedNum.Append('Z');
                    convertedNum.Append('a');
                    break;
                case 52:
                    convertedNum.Append('A');
                    convertedNum.Append('b');
                    break;
                case 53:
                    convertedNum.Append('B');
                    convertedNum.Append('b');
                    break;
                case 54:
                    convertedNum.Append('C');
                    convertedNum.Append('b');
                    break;
                case 55:
                    convertedNum.Append('D');
                    convertedNum.Append('b');
                    break;
                case 56:
                    convertedNum.Append('E');
                    convertedNum.Append('b');
                    break;
                case 57:
                    convertedNum.Append('F');
                    convertedNum.Append('b');
                    break;
                case 58:
                    convertedNum.Append('G');
                    convertedNum.Append('b');
                    break;
                case 59:
                    convertedNum.Append('H');
                    convertedNum.Append('b');
                    break;
                case 60:
                    convertedNum.Append('I');
                    convertedNum.Append('b');
                    break;
                case 61:
                    convertedNum.Append('J');
                    convertedNum.Append('b');
                    break;
                case 62:
                    convertedNum.Append('K');
                    convertedNum.Append('b');
                    break;
                case 63:
                    convertedNum.Append('L');
                    convertedNum.Append('b');
                    break;
                case 64:
                    convertedNum.Append('M');
                    convertedNum.Append('b');
                    break;
                case 65:
                    convertedNum.Append('N');
                    convertedNum.Append('b');
                    break;
                case 66:
                    convertedNum.Append('O');
                    convertedNum.Append('b');
                    break;
                case 67:
                    convertedNum.Append('P');
                    convertedNum.Append('b');
                    break;
                case 68:
                    convertedNum.Append('Q');
                    convertedNum.Append('b');
                    break;
                case 69:
                    convertedNum.Append('R');
                    convertedNum.Append('b');
                    break;
                case 70:
                    convertedNum.Append('S');
                    convertedNum.Append('b');
                    break;
                case 71:
                    convertedNum.Append('T');
                    convertedNum.Append('b');
                    break;
                case 72:
                    convertedNum.Append('U');
                    convertedNum.Append('b');
                    break;
                case 73:
                    convertedNum.Append('V');
                    convertedNum.Append('b');
                    break;
                case 74:
                    convertedNum.Append('W');
                    convertedNum.Append('b');
                    break;
                case 75:
                    convertedNum.Append('X');
                    convertedNum.Append('b');
                    break;
                case 76:
                    convertedNum.Append('Y');
                    convertedNum.Append('b');
                    break;
                case 77:
                    convertedNum.Append('Z');
                    convertedNum.Append('b');
                    break;
                case 78:
                    convertedNum.Append('A');
                    convertedNum.Append('c');
                    break;
                case 79:
                    convertedNum.Append( 'B');
                    convertedNum.Append('c');
                    break;
                case 80:
                    convertedNum.Append('C');
                    convertedNum.Append('c');
                    break;
                case 81:
                    convertedNum.Append('D');
                    convertedNum.Append('c');
                    break;
                case 82:
                    convertedNum.Append('E');
                    convertedNum.Append('c');
                    break;
                case 83:
                    convertedNum.Append('F');
                    convertedNum.Append('c');
                    break;
                case 84:
                    convertedNum.Append('G');
                    convertedNum.Append('c');
                    break;
                case 85:
                    convertedNum.Append('H');
                    convertedNum.Append('c');
                    break;
                case 86:
                    convertedNum.Append('I');
                    convertedNum.Append('c');
                    break;
                case 87:
                    convertedNum.Append('J');
                    convertedNum.Append('c');
                    break;
                case 88:
                    convertedNum.Append('K');
                    convertedNum.Append('c');
                    break;
                case 89:
                    convertedNum.Append('L');
                    convertedNum.Append('c');
                    break;
                case 90:
                    convertedNum.Append('M');
                    convertedNum.Append('c');
                    break;
                case 91:
                    convertedNum.Append('N');
                    convertedNum.Append('c');
                    break;
                case 92:
                    convertedNum.Append('O');
                    convertedNum.Append('c');
                    break;
                case 93:
                    convertedNum.Append('P');
                    convertedNum.Append('c');
                    break;
                case 94:
                    convertedNum.Append('Q');
                    convertedNum.Append('c');
                    break;
                case 95:
                    convertedNum.Append('R');
                    convertedNum.Append('c');
                    break;
                case 96:
                    convertedNum.Append('S');
                    convertedNum.Append('c');
                    break;
                case 97:
                    convertedNum.Append('T');
                    convertedNum.Append('c');
                    break;
                case 98:
                    convertedNum.Append('U');
                    convertedNum.Append('c');
                    break;
                case 99:
                    convertedNum.Append('V');
                    convertedNum.Append('c');

                    break;
                case 100:
                    convertedNum.Append('W');
                    convertedNum.Append('c');
                    break;
                case 101:
                    convertedNum.Append('X');
                    convertedNum.Append('c');
                    break;
                case 102:
                    convertedNum.Append('Y');
                    convertedNum.Append('c');
                    break;
                case 103:
                    convertedNum.Append('Z');
                    convertedNum.Append('c');
                    break;
                case 104:
                    convertedNum.Append('A');
                    convertedNum.Append('d');
                    break;
                case 105:
                    convertedNum.Append('B');
                    convertedNum.Append('d');
                    break;
                case 106:
                    convertedNum.Append('C');
                    convertedNum.Append('d');
                    break;
                case 107:
                    convertedNum.Append('D');
                    convertedNum.Append('d');
                    break;
                case 108:
                    convertedNum.Append('E');
                    convertedNum.Append('d');
                    break;
                case 109:
                    convertedNum.Append('F');
                    convertedNum.Append('d');
                    break;
                case 110:
                    convertedNum.Append('G');
                    convertedNum.Append('d');
                    break;
                case 111:
                    convertedNum.Append('H');
                    convertedNum.Append('d');
                    break;
                case 112:
                    convertedNum.Append('I');
                    convertedNum.Append('d');
                    break;
                case 113:
                    convertedNum.Append('J');
                    convertedNum.Append('d');
                    break;
                case 114:
                    convertedNum.Append('K');
                    convertedNum.Append('d');
                    break;
                case 115:
                    convertedNum.Append('L');
                    convertedNum.Append('d');
                    break;
                case 116:
                    convertedNum.Append('M');
                    convertedNum.Append('d');
                    break;
                case 117:
                    convertedNum.Append('N');
                    convertedNum.Append('d');
                    break;
                case 118:
                    convertedNum.Append('O');
                    convertedNum.Append('d');
                    break;
                case 119:
                    convertedNum.Append('P');
                    convertedNum.Append('d');
                    break;
                case 120:
                    convertedNum.Append('Q');
                    convertedNum.Append('d');
                    break;
                case 121:
                    convertedNum.Append('R');
                    convertedNum.Append('d');
                    break;
                case 122:
                    convertedNum.Append('S');
                    convertedNum.Append('d');
                    break;
                case 123:
                    convertedNum.Append('T');
                    convertedNum.Append('d');
                    break;
                case 124:
                    convertedNum.Append('U');
                    convertedNum.Append('d');
                    break;
                case 125:
                    convertedNum.Append('V');
                    convertedNum.Append('d');
                    break;
                case 126:
                    convertedNum.Append('W');
                    convertedNum.Append('d');
                    break;
                case 127:
                    convertedNum.Append('X');
                    convertedNum.Append('d');
                    break;
                case 128:
                    convertedNum.Append('Y');
                    convertedNum.Append('d');
                    break;
                case 129:
                    convertedNum.Append('Z');
                    convertedNum.Append('d');
                    break;
                case 130:
                    convertedNum.Append('A');
                    convertedNum.Append('e');
                    break;
                case 131:
                    convertedNum.Append('B');
                    convertedNum.Append('e');
                    break;
                case 132:
                    convertedNum.Append('C');
                    convertedNum.Append('e');
                    break;
                case 133:
                    convertedNum.Append('D');
                    convertedNum.Append('e');
                    break;
                case 134:
                    convertedNum.Append('E');
                    convertedNum.Append('e');
                    break;
                case 135:
                    convertedNum.Append('F');
                    convertedNum.Append('e');
                    break;
                case 136:
                    convertedNum.Append('G');
                    convertedNum.Append('e');
                    break;
                case 137:
                    convertedNum.Append('H');
                    convertedNum.Append('e');
                    break;
                case 138:
                    convertedNum.Append('I');
                    convertedNum.Append('e');
                    break;
                case 139:
                    convertedNum.Append('J');
                    convertedNum.Append('e');
                    break;
                case 140:
                    convertedNum.Append('K');
                    convertedNum.Append('e');
                    break;
                case 141:
                    convertedNum.Append('L');
                    convertedNum.Append('e');
                    break;
                case 142:
                    convertedNum.Append('M');
                    convertedNum.Append('e');
                    break;
                case 143:
                    convertedNum.Append('N');
                    convertedNum.Append('e');
                    break;
                case 144:
                    convertedNum.Append('O');
                    convertedNum.Append('e');
                    break;
                case 145:
                    convertedNum.Append('P');
                    convertedNum.Append('e');
                    break;
                case 146:
                    convertedNum.Append('Q');
                    convertedNum.Append('e');
                    break;
                case 147:
                    convertedNum.Append('R');
                    convertedNum.Append('e');
                    break;
                case 148:
                    convertedNum.Append('S');
                    convertedNum.Append('e');
                    break;
                case 149:
                    convertedNum.Append('T');
                    convertedNum.Append('e');
                    break;
                case 150:
                    convertedNum.Append('U');
                    convertedNum.Append('e');
                    break;
                case 151:
                    convertedNum.Append('V');
                    convertedNum.Append('e');
                    break;
                case 152:
                    convertedNum.Append('W');
                    convertedNum.Append('e');
                    break;
                case 153:
                    convertedNum.Append('X');
                    convertedNum.Append('e');
                    break;
                case 154:
                    convertedNum.Append('Y');
                    convertedNum.Append('e');
                    break;
                case 155:
                    convertedNum.Append('Z');
                    convertedNum.Append('e');
                    break;
                case 156:
                    convertedNum.Append('A');
                    convertedNum.Append('f');
                    break;
                case 157:
                    convertedNum.Append('B');
                    convertedNum.Append('f');
                    break;
                case 158:
                    convertedNum.Append('C');
                    convertedNum.Append('f');
                    break;
                case 159:
                    convertedNum.Append('D');
                    convertedNum.Append('f');
                    break;
                case 160:
                    convertedNum.Append('E');
                    convertedNum.Append('f');
                    break;
                case 161:
                    convertedNum.Append('F');
                    convertedNum.Append('f');
                    break;
                case 162:
                    convertedNum.Append('G');
                    convertedNum.Append('f');
                    break;
                case 163:
                    convertedNum.Append('H');
                    convertedNum.Append('f');
                    break;
                case 164:
                    convertedNum.Append('I');
                    convertedNum.Append('f');
                    break;
                case 165:
                    convertedNum.Append('J');
                    convertedNum.Append('f');
                    break;
                case 166:
                    convertedNum.Append('K');
                    convertedNum.Append('f');
                    break;
                case 167:
                    convertedNum.Append('L');
                    convertedNum.Append('f');
                    break;
                case 168:
                    convertedNum.Append('M');
                    convertedNum.Append('f');
                    break;
                case 169:
                    convertedNum.Append('N');
                    convertedNum.Append('f');
                    break;
                case 170:
                    convertedNum.Append('O');
                    convertedNum.Append('f');
                    break;
                case 171:
                    convertedNum.Append('P');
                    convertedNum.Append('f');
                    break;
                case 172:
                    convertedNum.Append('Q');
                    convertedNum.Append('f');
                    break;
                case 173:
                    convertedNum.Append('R');
                    convertedNum.Append('f');
                    break;
                case 174:
                    convertedNum.Append('S');
                    convertedNum.Append('f');
                    break;
                case 175:
                    convertedNum.Append('T');
                    convertedNum.Append('f');
                    break;
                case 176:
                    convertedNum.Append('U');
                    convertedNum.Append('f');
                    break;
                case 177:
                    convertedNum.Append('V');
                    convertedNum.Append('f');
                    break;
                case 178:
                    convertedNum.Append('W');
                    convertedNum.Append('f');
                    break;
                case 179:
                    convertedNum.Append('X');
                    convertedNum.Append('f');
                    break;
                case 180:
                    convertedNum.Append('Y');
                    convertedNum.Append('f');
                    break;
                case 181:
                    convertedNum.Append('Z');
                    convertedNum.Append('f');
                    break;
                case 182:
                    convertedNum.Append('A');
                    convertedNum.Append('g');
                    break;
                case 183:
                    convertedNum.Append('B');
                    convertedNum.Append('g');
                    break;
                case 184:
                    convertedNum.Append('C');
                    convertedNum.Append('g');
                    break;
                case 185:
                    convertedNum.Append('D');
                    convertedNum.Append('g');
                    break;
                case 186:
                    convertedNum.Append('E');
                    convertedNum.Append('g');
                    break;
                case 187:
                    convertedNum.Append('F');
                    convertedNum.Append('g');
                    break;
                case 188:
                    convertedNum.Append('G');
                    convertedNum.Append('g');
                    break;
                case 189:
                    convertedNum.Append('H');
                    convertedNum.Append('g');
                    break;
                case 190:
                    convertedNum.Append('I');
                    convertedNum.Append('g');
                    break;
                case 191:
                    convertedNum.Append('J');
                    convertedNum.Append('g');
                    break;
                case 192:
                    convertedNum.Append('K');
                    convertedNum.Append('g');
                    break;
                case 193:
                    convertedNum.Append('L');
                    convertedNum.Append('g');
                    break;
                case 194:
                    convertedNum.Append('M');
                    convertedNum.Append('g');
                    break;
                case 195:
                    convertedNum.Append('N');
                    convertedNum.Append('g');
                    break;
                case 196:
                    convertedNum.Append('O');
                    convertedNum.Append('g');
                    break;
                case 197:
                    convertedNum.Append('P');
                    convertedNum.Append('g');
                    break;
                case 198:
                    convertedNum.Append('Q');
                    convertedNum.Append('g');
                    break;
                case 199:
                    convertedNum.Append('R');
                    convertedNum.Append('g');
                    break;
                case 200:
                    convertedNum.Append('S');
                    convertedNum.Append('g');
                    break;
                case 201:
                    convertedNum.Append('T');
                    convertedNum.Append('g');
                    break;
                case 202:
                    convertedNum.Append('U');
                    convertedNum.Append('g');
                    break;
                case 203:
                    convertedNum.Append('V');
                    convertedNum.Append('g');
                    break;
                case 204:
                    convertedNum.Append('W');
                    convertedNum.Append('g');
                    break;
                case 205:
                    convertedNum.Append('X');
                    convertedNum.Append('g');
                    break;
                case 206:
                    convertedNum.Append('Y');
                    convertedNum.Append('g');
                    break;
                case 207:
                    convertedNum.Append('Z');
                    convertedNum.Append('g');
                    break;
                case 208:
                    convertedNum.Append('A');
                    convertedNum.Append('h');
                    break;
                case 209:
                    convertedNum.Append('B');
                    convertedNum.Append('h');
                    break;
                case 210:
                    convertedNum.Append('C');
                    convertedNum.Append('h');
                    break;
                case 211:
                    convertedNum.Append('D');
                    convertedNum.Append('h');
                    break;
                case 212:
                    convertedNum.Append('E');
                    convertedNum.Append('h');
                    break;
                case 213:
                    convertedNum.Append('F');
                    convertedNum.Append('h');
                    break;
                case 214:
                    convertedNum.Append('G');
                    convertedNum.Append('h');
                    break;
                case 215:
                    convertedNum.Append('H');
                    convertedNum.Append('h');
                    break;
                case 216:
                    convertedNum.Append('I');
                    convertedNum.Append('h');
                    break;
                case 217:
                    convertedNum.Append('J');
                    convertedNum.Append('h');
                    break;
                case 218:
                    convertedNum.Append('K');
                    convertedNum.Append('h');
                    break;
                case 219:
                    convertedNum.Append('L');
                    convertedNum.Append('h');
                    break;
                case 220:
                    convertedNum.Append('M');
                    convertedNum.Append('h');
                    break;
                case 221:
                    convertedNum.Append('N');
                    convertedNum.Append('h');
                    break;
                case 222:
                    convertedNum.Append('O');
                    convertedNum.Append('h');
                    break;
                case 223:
                    convertedNum.Append('P');
                    convertedNum.Append('h');
                    break;
                case 224:
                    convertedNum.Append('Q');
                    convertedNum.Append('h');
                    break;
                case 225:
                    convertedNum.Append('R');
                    convertedNum.Append('h');
                    break;
                case 226:
                    convertedNum.Append('S');
                    convertedNum.Append('h');
                    break;
                case 227:
                    convertedNum.Append('T');
                    convertedNum.Append('h');
                    break;
                case 228:
                    convertedNum.Append('U');
                    convertedNum.Append('h');
                    break;
                case 229:
                    convertedNum.Append('V');
                    convertedNum.Append('h');
                    break;
                case 230:
                    convertedNum.Append('W');
                    convertedNum.Append('h');
                    break;
                case 231:
                    convertedNum.Append('X');
                    convertedNum.Append('h');
                    break;
                case 232:
                    convertedNum.Append('Y');
                    convertedNum.Append('h');
                    break;
                case 233:
                    convertedNum.Append('Z');
                    convertedNum.Append('h');
                    break;
                case 234:
                    convertedNum.Append('A');
                    convertedNum.Append('i');
                    break;
                case 235:
                    convertedNum.Append('B');
                    convertedNum.Append('i');
                    break;
                case 236:
                    convertedNum.Append('C');
                    convertedNum.Append('i');
                    break;
                case 237:
                    convertedNum.Append('D');
                    convertedNum.Append('i');
                    break;
                case 238:
                    convertedNum.Append('E');
                    convertedNum.Append('i');
                    break;
                case 239:
                    convertedNum.Append('F');
                    convertedNum.Append('i');
                    break;
                case 240:
                    convertedNum.Append('G');
                    convertedNum.Append('i');
                    break;
                case 241:
                    convertedNum.Append('H');
                    convertedNum.Append('i');
                    break;
                case 242:
                    convertedNum.Append('I');
                    convertedNum.Append('i');
                    break;
                case 243:
                    convertedNum.Append('J');
                    convertedNum.Append('i');
                    break;
                case 244:
                    convertedNum.Append('K');
                    convertedNum.Append('i');
                    break;
                case 245:
                    convertedNum.Append('L');
                    convertedNum.Append('i');
                    break;
                case 246:
                    convertedNum.Append('M');
                    convertedNum.Append('i');
                    break;
                case 247:
                    convertedNum.Append('N');
                    convertedNum.Append('i');
                    break;
                case 248:
                    convertedNum.Append('O');
                    convertedNum.Append('i');
                    break;
                case 249:
                    convertedNum.Append('P');
                    convertedNum.Append('i');
                    break;
                case 250:
                    convertedNum.Append('Q');
                    convertedNum.Append('i');
                    break;
                case 251:
                    convertedNum.Append('R');
                    convertedNum.Append('i');
                    break;
                case 252:
                    convertedNum.Append('S');
                    convertedNum.Append('i');
                    break;
                case 253:
                    convertedNum.Append('T');
                    convertedNum.Append('i');
                    break;
                case 254:
                    convertedNum.Append('U');
                    convertedNum.Append('i');
                    break;
                case 255:
                    convertedNum.Append('V');
                    convertedNum.Append('i');
                    break;
                default:
                    convertedNum.Append(number % 16);
                    break;
            }
            number = number / 256;
        }
        return convertedNum;
    }
    static void Main(string[] args)
    {
        ulong number = ulong.Parse(Console.ReadLine());
        string stringNum = DecimalTOHezademic(number).ToString();
        for (int i = stringNum.Length - 1; i >= 0; i--)
        {
            Console.Write(stringNum[i]);
        }
    }
}