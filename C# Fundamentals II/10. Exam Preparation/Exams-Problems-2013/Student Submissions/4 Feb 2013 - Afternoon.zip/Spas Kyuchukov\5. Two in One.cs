using System;

class TwoInOne
{
    static void Main(string[] args)
    {
        int lampsCount;
        int.TryParse(Console.ReadLine(), out lampsCount);
        string robot1 = Console.ReadLine();
        string robot2 = Console.ReadLine();

        Console.WriteLine(LastLamp(lampsCount));
        Console.WriteLine(RobotIsBounded(robot1) ? "bounded" : "unbounded");
        Console.WriteLine(RobotIsBounded(robot2) ? "bounded" : "unbounded");
    }

    private static int LastLamp(int count)
    {
        // One based solution
        bool[] lamps = new bool[count + 1];

        int lastIndex = -1;

        for (int i = 1; i < lamps.Length; i++)
        {
            if (lamps[i] == false)
            {
                for (int j = i; j < lamps.Length; j += i + 1)
                {
                    if (lamps[j] == false)
                    {
                        lastIndex = j;
                        lamps[j] = true;
                    }

                }
            }
        }

        return lastIndex;
    }

    private static bool RobotIsBounded(string commands)
    {
        if (!commands.Contains("S")) return true;

        int posX = 0, posY = 0;
        int currentDirection = 0; // 0-top, 1-left, 2-down, 3-right

        if (ExecuteOnce(0, commands, ref currentDirection, ref posX, ref posY)) return true;

        double currentDistance = Distance(posX, posY);
        double maxDistance = currentDirection;

        int counter = 0;

        for (int i = 0; i < 1000; i++)
        {
            for (int index = 0; index < commands.Length; index++)
            {
                if (ExecuteOnce(index, commands, ref currentDirection, ref posX, ref posY)) return true;
                currentDistance = Distance(posX, posY);
                if (currentDistance > maxDistance)
                {
                    maxDistance = currentDistance;
                    counter = 0;
                }
                else ++counter;

                if (counter > 25*commands.Length)
                {
                    return true;
                }
            }
        }

        return false;
    }

    private static bool ExecuteOnce(int index, string commands, ref int currentDirection, ref int posX, ref int posY)
    {
        char command = commands[index];
        {
            if (command == 'L')
            {
                ++currentDirection;
                currentDirection %= 4;
            }

            if (command == 'R')
            {
                --currentDirection;
                if (currentDirection == -1) currentDirection = 3;
            }

            if (command == 'S')
            {
                switch (currentDirection)
                {
                    case 0:
                        {
                            ++posX;
                            break;
                        }
                    case 1:
                        {
                            --posY;
                            break;
                        }
                    case 2:
                        {
                            --posX;
                            break;
                        }
                    case 3:
                        {
                            ++posY;
                            break;
                        }
                }

                //if((posX==0)&&(posY==0)) return true;
            }
        }

        return false;
    }

    private static double Distance(int posX, int posY)
    {
        return Math.Sqrt(posX * posX + posY * posY);
    }

}