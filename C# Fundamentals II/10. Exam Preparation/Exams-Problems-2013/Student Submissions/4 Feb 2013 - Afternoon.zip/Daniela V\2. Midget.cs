using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midget
{
    class Program
    {
        static int GetMax(int[] array)
        {
            int largest = array[0];
            for (int i = 0; i < array.Length; i++)
            {

                if (array[i] > largest)
                {
                    largest = array[i];
                }
            }
            return largest;
        }

        static void Main(string[] args)
        {
            string valleyinput = Console.ReadLine();
            string[] valleyNumbers = valleyinput.Split(',');            
            int l = valleyNumbers.Length;
            Int32[] valley = new int[l];
            for (int i = 0; i < valleyNumbers.Length; i++)
            {
                valley[i] = Convert.ToInt32(valleyNumbers[i]);
            } 
            int pats = Int32.Parse(Console.ReadLine());
            int[][] numberPattarns = new int[pats][];
            string[][] current = new string[pats][];
            //List<string> current = new List<string>();

            //string cur = "";
            int[] results = new int[pats];
            for (int j = 0; j < pats; j++)
            {
                ////cur = Console.ReadLine();
                ////current = cur.Split(',');
                ////Stringtoread(current, cur);
                //current[j] = Stringtoread();
                //int currentLenght = current[j].Length;
                //int k = 0;
                //foreach (var item in current[j])
                //{
                //    numberPattarns[j][k] = Convert.ToInt32(item);
                //    k++;
                //}



                numberPattarns[j] = Stringtoread(pats);


                //for (int k = 0; k < currentLenght; k++)
                //{
                //    numberPattarns[j][k] = Convert.ToInt32(current[j][k]);
                //}
                //cur = "";
           
            }
            bool isVisited = false;
            for (int h = 0; h < pats; h++)
            {
                int n = 0;
                int p = 0;
                int z = 0;
                while (z < valley.Length && isVisited == false && p < numberPattarns[h].Length)
	            {
                    
                    n = numberPattarns[h][p];
	                results[h] += valley[z];
                    valley[z] = 0;
                    z = z + n;
                    if (valley[z] == 0)
                    {
                        isVisited = true;
                    }

                    
                    if (p<numberPattarns[h].Length)
                    {
                        p++;
                    }
                    else
                    {
                        p = 0;
                    }
	            }
                
            }

            Console.WriteLine(GetMax(results));
  

            
        }

        //private static string[] Stringtoread(string[] current, string cur)
        //{
        //    //current(cur.Split(','));
        //    //string valleyinput = Console.ReadLine();
        //    string[] rcurrent = cur.Split(',');
        //    return rcurrent;
        //}
        private static Int32[] Stringtoread(int pa)
        {
            //current(cur.Split(','));
            string cur = Console.ReadLine();
            string[] rcurrent = cur.Split(',');
            int[] thepatterns = new int[rcurrent.Length];
            int k=0;
            foreach (var item in rcurrent)
            {
                thepatterns[k] = Convert.ToInt32(item);
                k++;
            }
            return thepatterns;
        }
    }
}
