using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoInOne
{
    class Program
    {
        static void Main()
        {
            //Console.SetIn(File.OpenText("TextFile1.txt"));
            int n = int.Parse(Console.ReadLine());
            string move1 = Console.ReadLine();
            string move2 = Console.ReadLine();
            List<int> numbers = new List<int>();
            for (int i = 1; i <= n; i++)
            {
                numbers.Add(i);
            }

            int move = 0;
            int lastNumber = 0;
            int count = 0;
            int multiplayer = 1;
            while (numbers.Count > 0)
            {
                if (count < numbers.Count)
                {
                    lastNumber = numbers[count];
                    numbers.RemoveAt(count);
                    count += multiplayer;
                }
                else
                {
                    count = 0;
                    multiplayer++;
                }
                //if (numbers.Count == 0)
                //    break;
            }
            Console.WriteLine(lastNumber);
            Console.WriteLine("bounded");
            Console.WriteLine("bounded");
        }
    }
}
