using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midget
{
    class Program
    {
        public static void Main(string[] args)
        {

            Console.WriteLine("Enter valley numbers:");
            string valley = Console.ReadLine();

            string[] valleyArr = valley.Split(',');

            for (int i = 0; i < valleyArr.Length; i++)
            {
                Console.Write(valleyArr[i]+ ", ");
            }
            Console.WriteLine();
            Console.WriteLine("M-patterns:");
             int num = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter pattern:");
            string pattern = Console.ReadLine();

            string[] patternArr = pattern.Split(',');

            for (int i = 0; i < num; i++)
            {
                Console.Write(patternArr[i] + ", ");
            }

            for (int i = 0; i < valleyArr.Length; i++)
            {
              string collected = valleyArr[i];
               string position = (patternArr[i]) + patternArr[i + 1];
            }
        }    
    }
} 