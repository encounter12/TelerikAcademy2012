using System;

class Midget
{
    static void Main()
    {
        string valley = Console.ReadLine();
        int M = int.Parse(Console.ReadLine());

        char[] separators = new char[] {' ', ','};
        string[] valley_digit = valley.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        int[] valleyInt = new int[valley_digit.Length];
        for (int index = 0; index < valley_digit.Length; ++index)
        {
            int temp;
            string s1 = valley_digit[index];
            if (int.TryParse(s1, out temp))
            {
                valleyInt[index] = temp;
            }
        }
        int CollectedMax = 0;
        while (M >= 0)
        {
            int Collected = 0, count = 0;

            string patern = Console.ReadLine();
            string[] paternDigit = patern.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            int[] PaternInt = new int[paternDigit.Length];

            for (int j = 0; j < paternDigit.Length; ++j)
            {
                int k;
                string s = paternDigit[j];
                if (int.TryParse(s, out k))
                {
                    PaternInt[j] = k;
                }
            }
            int m = 0;
            if (M % 2 != 0)
            {
                for (int sum = 0; sum < PaternInt.Length; sum++)
                {
                    count = count + PaternInt[sum];
                    Collected = Collected + valleyInt[count];
                    if (CollectedMax < Collected)
                    {
                        CollectedMax = Collected;
                    }
                    if (sum == PaternInt.Length && m == 0)
                    {
                        sum = 0;
                        m = 1;
                    }
                }
            }
            else
            {
                for (int sum = 0; sum < PaternInt.Length; sum++)
                {
                    count = count + PaternInt[sum];
                    Collected = Collected + valleyInt[count];
                    if (CollectedMax < Collected)
                    {
                        CollectedMax = Collected;
                    }
                }
            }
            M--;
        }
        Console.WriteLine(CollectedMax);
    }
}

