using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {

            int number = int.Parse(Console.ReadLine());

            StringBuilder provadiaNumber = new StringBuilder();
            StringBuilder lettersGenerator = new StringBuilder();
            string letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string lettersSmall = letters.ToLower();


            string allLetters = lettersGenerator.ToString();
            bool isEnd = true;
            while (isEnd)
            {
                if (number <= 25)
                {
                    provadiaNumber.Append(letters[number]);
                    isEnd = false;
                }
                else
                {

                    int remainder = number % 256;
                    int delitel = number / 256;
                    while (remainder > 25)
                    {
                        provadiaNumber.Append(lettersSmall[delitel]);
                        remainder = remainder % 25;
                        delitel = delitel / 25;
                    }
                    provadiaNumber.Append(letters[remainder-1]);
                }

                string provadiaNumberEnd = provadiaNumber.ToString();
                isEnd = false;
                Console.WriteLine(provadiaNumberEnd);

            }
        }
    }
}