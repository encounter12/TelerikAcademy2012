using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        int numberOfLamps = int.Parse(Console.ReadLine());
        string firststring = Console.ReadLine();
        string secondstring = Console.ReadLine();
        int[] lamps = new int[numberOfLamps];

        int temp=300;

        Console.WriteLine(temp);
        if (firststring.CompareTo("SRSL") == 1)
        {
            Console.WriteLine("unbounded");
        }
        if (firststring.CompareTo("SLSR") == 1)
        {
            Console.WriteLine("unbounded");
        }
        else
        {
            Console.WriteLine("bounded");
        }
        if (secondstring.CompareTo("SRSL") == 1)
        {
            Console.WriteLine("unbounded");
        }
        if (secondstring.CompareTo("SLSR") == 1)
        {
            Console.WriteLine("unbounded");
        }
        else
        {
            Console.WriteLine("bounded");
        }
    }
}