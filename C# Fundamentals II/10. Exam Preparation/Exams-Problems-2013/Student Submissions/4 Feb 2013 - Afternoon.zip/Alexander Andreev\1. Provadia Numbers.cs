using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace _ProvadiaNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal x = decimal.Parse(Console.ReadLine());
            StringBuilder Provadia = new StringBuilder();
            if (x == 0)
                Console.WriteLine("A");
            else
            {
                while (x > 0)
                {
                    decimal ostatak = (int)(x % 256);
                    x = (ulong)(x / 256);
                    decimal? firstDigit = 0;
                    decimal? seconddigit = 0;
                    if (ostatak > 25)
                    {
                        seconddigit = (int)(ostatak % 26);
                        firstDigit = ostatak / 26;
 
 
                    }
                    else
                    {
                        seconddigit = ostatak;
                    }
                    switch ((int)seconddigit)
                    {
                        case 0: Provadia.Insert(0, 'A');
                            break;
                        case 1: Provadia.Insert(0, 'B');
                            break;
                        case 2: Provadia.Insert(0, 'C');
                            break;
                        case 3: Provadia.Insert(0, 'D');
                            break;
                        case 4: Provadia.Insert(0, 'E');
                            break;
                        case 5: Provadia.Insert(0, 'F');
                            break;
                        case 6: Provadia.Insert(0, 'G');
                            break;
                        case 7: Provadia.Insert(0, 'H');
                            break;
                        case 8: Provadia.Insert(0, 'I');
                            break;
                        case 9: Provadia.Insert(0, 'J');
                            break;
                        case 10: Provadia.Insert(0, 'K');
                            break;
                        case 11: Provadia.Insert(0, 'L');
                            break;
                        case 12: Provadia.Insert(0, 'M');
                            break;
                        case 13: Provadia.Insert(0, 'N');
                            break;
                        case 14: Provadia.Insert(0, 'O');
                            break;
                        case 15: Provadia.Insert(0, 'P');
                            break;
                        case 16: Provadia.Insert(0, 'Q');
                            break;
                        case 17: Provadia.Insert(0, 'R');
                            break;
                        case 18: Provadia.Insert(0, 'S');
                            break;
                        case 19: Provadia.Insert(0, 'T');
                            break;
                        case 20: Provadia.Insert(0, 'U');
                            break;
                        case 21: Provadia.Insert(0, 'V');
                            break;
                        case 22: Provadia.Insert(0, 'W');
                            break;
                        case 23: Provadia.Insert(0, 'X');
                            break;
                        case 24: Provadia.Insert(0, 'Y');
                            break;
                        case 25: Provadia.Insert(0, 'Z');
                            break;
                        default:
                            break;
                    }
                    switch ((int)firstDigit)
                    {
                        case 1: Provadia.Insert(0, 'a');
                            break;
                        case 2: Provadia.Insert(0, 'b');
                            break;
                        case 3: Provadia.Insert(0, 'c');
                            break;
                        case 4: Provadia.Insert(0, 'd');
                            break;
                        case 5: Provadia.Insert(0, 'e');
                            break;
                        case 6: Provadia.Insert(0, 'f');
                            break;
                        case 7: Provadia.Insert(0, 'j');
                            break;
                        case 8: Provadia.Insert(0, 'h');
                            break;
                        case 9: Provadia.Insert(0, 'i');
                            break;
                        default:
                            break;
                    }
                }
                Console.WriteLine(Provadia);
            }
        }
    }
}