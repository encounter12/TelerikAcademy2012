using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

class Program
{

    public static void Main()
    {
        int numberLines = int.Parse(Console.ReadLine());
        int lineLength = int.Parse(Console.ReadLine());
        List<string> words = new List<string>();

        for (int i = 0; i < numberLines; ++i)
        {
            string line = Console.ReadLine();
            MatchCollection wordsOnLine = Regex.Matches(line, @"[^\s]+");
            foreach (Match word in wordsOnLine)
            {
                words.Add(word.ToString());
            }
        }

        StringBuilder lineSB = new StringBuilder();
        int length = words.Count;
        int k = 0;
        while (k < length)
        {
            int StartIndex = k;
            int remainingSpace = lineLength - words[k].Length;
            ++k;
            while (k < length && remainingSpace > words[k].Length)
            {
                remainingSpace -= words[k].Length + 1;
                ++k;
            }
            if (k - StartIndex == 1)
            {
                Console.WriteLine(words[StartIndex]);
            }
            else
            {
                int count = k - StartIndex;
                int endIndex = remainingSpace % (count - 1);
                int spacesCount = remainingSpace / (count - 1) + ((endIndex != 0) ? 1 : 0);
                lineSB.Append(words[StartIndex]);
                for (int j = 0; j < endIndex; ++j)
                {
                    lineSB.Append(new String(' ', spacesCount + 1));
                    lineSB.Append(words[StartIndex + j + 1]);
                }
                spacesCount = remainingSpace / (count - 1);
                for (int j = endIndex; j < count - 1; ++j)
                {
                    lineSB.Append(new String(' ', spacesCount + 1));
                    lineSB.Append(words[StartIndex + j + 1]);
                }
                Console.WriteLine(lineSB);
                lineSB.Clear();
            }
        }
    }
}