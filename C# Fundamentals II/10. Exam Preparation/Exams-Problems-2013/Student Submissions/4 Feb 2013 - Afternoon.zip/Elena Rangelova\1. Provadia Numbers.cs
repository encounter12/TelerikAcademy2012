using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
    class ProvadiaNumbers
    {
        static void Main()
        {
            int num=int.Parse(Console.ReadLine());
            string result=" ";
            string[] bigLetters = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
            string[] smallLetters = new string[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
            StringBuilder sb = new StringBuilder();
            bool isInLoop = true;
            bool isOutLoop = false;
            if (num <= 25)
            {
                isInLoop = true;
                isOutLoop = false;

            
                for (int i = 0; i < bigLetters.Length; i++)
                {

                    result = bigLetters[num];
                    
                }
                Console.WriteLine(result);
            }
            else if(num > 25 && num < 256)
            {
                isInLoop = false;
                isOutLoop = true;
                

               
                    string resultFirst = "";
                    string resultSecond = "";
                    for (int j = 0; j < smallLetters.Length; j++)
                    {

                        resultFirst = smallLetters[num/25-1];
                        
                      
                        for (int k = 0; k < bigLetters.Length; k++)
                        {

                          resultSecond = bigLetters[num%25 - num/25];
                          
                        }
                    
                
                    string str = String.Concat(resultFirst, resultSecond);
                    Console.WriteLine(str);
                    break;
                
                    

                    
                }
                
            
            }


            


        }
    }