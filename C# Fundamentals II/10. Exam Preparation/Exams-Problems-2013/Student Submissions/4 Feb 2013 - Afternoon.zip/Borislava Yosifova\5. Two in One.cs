using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.TwoInOne
{
    class Program
    {
        static void Main(string[] args)
        {

            int num = int.Parse(Console.ReadLine());
            string pahtOne = Console.ReadLine();
            string pahtTwo = Console.ReadLine();

            Console.WriteLine(FirstTask(num));
            Console.WriteLine(SecondTask(pahtOne));
            Console.WriteLine(SecondTask(pahtTwo));
        }

        static int FirstTask(int n)
        {
            bool[] arrLamps = new bool[n + 1];
            int lastOn = 0;

            for (int i = 0; i < arrLamps.Length; i++)
            {
                arrLamps[i] = false;
            }

            for (int i = 1; i < arrLamps.Length; i++)
            {
                if (arrLamps[i] == false)
                {
                    for (int j = i; j < arrLamps.Length; j += i + 1)
                    {
                        if (arrLamps[j] == false)
                        {
                            arrLamps[j] = true;
                            lastOn = j;
                        }
                    }
                }
            }

            return lastOn;
        }

        static string SecondTask(string str)
        {
            int[] count = new int[3]; //S = 0, R/L = 1;
            string brum = "";

            for (int i = 0; i < str.Length; i++)
            {
                switch (str[i])
                {
                    case 'S':
                        count[0]++;
                        break;
                    case 'R':
                        count[1]++;
                        break;
                    case 'L':
                        count[1]--;
                        break;
                }
            }
            if (count[0] == 0)
            { brum = "bounded"; }
            else
            {
                if (count[1] % 4 != 0)
                {
                    brum = "unbounded";
                }
                if (count[1] == 0)
                {
                    brum = "unbounded";
                }
                if (count[1] != 0)
                {
                    brum = "bounded";
                }
            }
                return brum;
        }

    }
}
