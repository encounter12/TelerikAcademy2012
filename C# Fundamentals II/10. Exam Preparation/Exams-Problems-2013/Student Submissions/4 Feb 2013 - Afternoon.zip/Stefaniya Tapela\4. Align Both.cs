using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AlignBoth
{
    class Program
    {
        static void Main(string[] args)
        {
            short N = short.Parse(Console.ReadLine());
            short W = short.Parse(Console.ReadLine());

            StringBuilder result = new StringBuilder();
            while (N > 0)
            {
                result.AppendLine(Console.ReadLine());
                N--;
            }

            string[] words = result.ToString().Split(new char[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries);

            result = new StringBuilder();
            List<string> row = new List<string>();
            string rowhelp = string.Empty;
            if (words.Length > 0)
            {
                row.Add(words[0]);

                for (short i = 1; i < words.Length; i++)
                {
                    if ((String.Join(" ", row) + " " + words[i]).Length > W)
                    {
                        rowhelp = String.Join(" ", row);
                        if (W - rowhelp.Length > 0 && row.Count > 1)
                        {
                            for (int s = 0; s < W - rowhelp.Length; s++)
                                row[s % (row.Count - 1)] += " ";
                            result.AppendLine(String.Join(" ", row));
                        }
                        else
                            result.AppendLine(rowhelp);

                        row = new List<string>();

                    }

                    row.Add(words[i]);

                }
                if (row.Count > 0)
                    result.AppendLine(String.Join(" ", row));

                Console.WriteLine(result.ToString());
            }
        }
    }
}
