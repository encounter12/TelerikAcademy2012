using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;

class ProvadiaNumbers
{
    static void Main()
    {
        BigInteger num = BigInteger.Parse(Console.ReadLine());
        List<string> digits = new List<string>();
        for (char ch = 'A'; ch <= 'Z'; ch++)
        {
            digits.Add(ch.ToString());
        }
        for (char ch = 'a'; ch <= 'h'; ch++)
        {
            for (char ch1 = 'A'; ch1 <= 'Z'; ch1++)
            {
                digits.Add(ch.ToString() + ch1.ToString());
            }
        }
        for (char ch = 'A'; ch <= 'V'; ch++)
        {
            digits.Add("i" + ch.ToString());
        }
        Console.WriteLine(DecTo_Provadia(digits, num, 256));
    }

    static string DecTo_Provadia(List<string> digits, BigInteger num, int baseD)
    {
        if (num == 0) return "A";
        //Stack<string> stack = new Stack<string>();
        List<string> list = new List<string>();
        StringBuilder strB = new StringBuilder();
        BigInteger n = num;
        while (n > 0)
        {
            //stack.Push(digits[(int)(n % baseD)]);
            list.Add(digits[(int)(n % baseD)]);
            n = n / baseD;
        }
        /*
        for (int i = 0; i < stack.Count; i++)
        {
            strB.Append(stack.Pop().Trim());
        }
        if (stack.Count > 0)
        {
            strB.Append(stack.Pop().Trim());
        }
        */
        for (int i = list.Count - 1; i >= 0; i--)
        {
            strB.Append(list[i]);
        }
        return strB.ToString();
    }
}
