using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task2Midget
{
    class Program
    {
        static void Main(string[] args)
        {
            string valleyStr = Console.ReadLine();
            string[] valley = valleyStr.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            //List<int> valley = new List<int>();
            //for (int i = 0; i < valleySplitedStr.Length; i++)
            //{
            //    valley.Add(int.Parse(valleySplitedStr[i]));
            //}


            //for (int i = 0; i < valley.Length; i++)
            //{
            //    Console.WriteLine(valley[i]);
            //}


            int NumberPatterns = int.Parse(Console.ReadLine());
            //List<List<int>> patterns = new List<List<int>>();
            List<string[]> patterns = new List<string[]>(NumberPatterns);
            for (int i = 0; i < NumberPatterns; i++)
            {
                string currentPatternStr = Console.ReadLine();
                string[] currentPattern = currentPatternStr.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
                patterns.Add(currentPattern);
            }

            //for (int i = 0; i < patterns[0].Length; i++)
            //{
            //    Console.WriteLine(patterns[0][i]);
            //}


            int currentPosition = 0;
            long sum = 0;
            long maxSum = Int64.MinValue;
            for (int i = 0; i < patterns.Count; i++)
            {
                bool[] visited = new bool[valley.Length];
                visited[0] = true;
                currentPosition = 0;
                if (currentPosition >= valley.Length || currentPosition < 0)
                {
                    goto Out;
                }
                sum = 0;
                //for (int j = 1; j < patterns[i].Length; j++)
                //{
                //    sum += int.Parse(valley[currentPosition]);
                //    visited[currentPosition] = true;
                //    currentPosition += int.Parse(patterns[i][j]);
                //    if (currentPosition >= valley.Length || currentPosition < 0)
                //    {
                //        goto Out;
                //    }
                //    //Console.WriteLine("sum[{0}] = {1}", i, sum);
                //}
                while (true)
                {
                    for (int j = 0; j < patterns[i].Length; j++)
                    {
                        
                        sum += int.Parse(valley[currentPosition]);
                        //Console.WriteLine("sum[{0}] = {1}", i, sum);
                        visited[currentPosition] = true;
                        currentPosition += int.Parse(patterns[i][j]);
                        if (currentPosition >= valley.Length || currentPosition < 0)
                        {
                            goto Out;
                        }
                        if (visited[currentPosition])
                        {
                            goto Out;
                        }
                        //Console.WriteLine("sum[{0}] = {1}", i, sum);
                    }

                }
            Out:
                if (sum > maxSum)
                {
                    maxSum = sum;
                }

            }
            Console.WriteLine(maxSum);
        }
    }
}