using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Start2
{


    class Program
    {
        static void Main()
        {
            int bestSum = int.MinValue;
            string str = Console.ReadLine();
            string[] separator = { ", " };
            string[] strCoins = str.Split(separator, StringSplitOptions.None);
            int n = strCoins.Length;
            int[] coins = new int[n];
            for (int i = 0; i < n; i++)
            {
                coins[i] = int.Parse(strCoins[i]);
            }


            int m = int.Parse(Console.ReadLine());
            string[] patternsStr = new string[m];

            // read 
            for (int i = 0; i < m; i++)
            {
                patternsStr[i] = Console.ReadLine();
            }

            //fill and check
            for (int i = 0; i < m; i++)
            {
                bool[] coinsCollected = new bool[n];
                int currentSum = 0;
                string[] pStr = patternsStr[i].Split(separator, StringSplitOptions.None);
                int indexes = pStr.Length;
                int[] value = new int[indexes];
                for (int pat= 0; pat < indexes; pat++)
                {
                    value[pat] = int.Parse(pStr[pat]);
                }
                int positionInPattern = 0;
                int indexInPattern = value[positionInPattern];
                for (int calcIndex = 0; calcIndex >= 0 && calcIndex < n && !coinsCollected[calcIndex]; )
                {
                    currentSum += coins[calcIndex];

                    coinsCollected[calcIndex] = true;
                   
                    indexInPattern = value[positionInPattern++ % indexes];

                    calcIndex += indexInPattern;
                }

                if (currentSum > bestSum)
                {
                    bestSum = currentSum;
                }

            }
            Console.WriteLine(bestSum);//

        }
    }
}