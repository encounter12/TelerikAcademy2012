using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midget
{
    class Program
    {
        static void Main(string[] args)
        {
            string numbers = Console.ReadLine();
            string[] valleyStr=numbers.Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            int[] valley = new int[valleyStr.Length];
            for (int i = 0; i < valleyStr.Length; i++)
            {
                valley[i] = int.Parse(valleyStr[i]);
            }
            int[] valleyCrossed = new int[valley.Length];
            int coins = 0, maxCoins = 0;
            int m = int.Parse(Console.ReadLine());
            for (int i = 0; i < m; i++)
            {
                numbers = Console.ReadLine();
                string[] patternStr = numbers.Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
                int[] pattern = new int[patternStr.Length];
                for (int j = 0; j < patternStr.Length; j++)
                {
                    pattern[j] = int.Parse(patternStr[j]);
                }
                for (int v = 0; v < valleyCrossed.Length; v++)
                {
                    valleyCrossed[v] = 0;
                }
                int z = 0, c = 0;
                while(z>-1&&z<valley.Length&&valleyCrossed[z]==0)
                {
                    coins = coins + valley[z];
                    valleyCrossed[z] = 1;
                    z = z + pattern[c];
                    if (c < pattern.Length-1) c++;
                    else c = 0;
                }
                if (coins > maxCoins) maxCoins = coins;
                coins = 0;
            }
            Console.WriteLine(maxCoins);
        }
    }
}
