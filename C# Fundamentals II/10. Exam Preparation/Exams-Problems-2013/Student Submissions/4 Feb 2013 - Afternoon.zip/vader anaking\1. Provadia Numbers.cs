using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            double input=double.Parse(Console.ReadLine());
            double number=input;
            double counter=1;
            while(number-Math.Pow(25,counter)>0)
            {
                counter++;
            }
            char[] smallLetter = {'0', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
            char[] bigLetter   = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            double[] array = new double[(int)counter];
            char[] arrayChar = new char[(int)counter];
            for (int i = (int)counter-1; i >=0; i--)
            {
                array[i] =(int) number / 26;
                number -= (int)(number / 26)*26;
                if (i == 0)
                {
                    array[i] = number % 26;
                    number -= number % 26;
                }
            }
            for (int i =(int) counter-1; i >= 0; i--)
            {
                if (i % 2 == 0)
                {
                    arrayChar[i] = bigLetter[(int)array[i]];
                }
                else
                {
                    arrayChar[i] = smallLetter[(int)array[i]];
                }
                Console.Write(arrayChar[i]);
            }
            Console.WriteLine();
        }
    }
}
