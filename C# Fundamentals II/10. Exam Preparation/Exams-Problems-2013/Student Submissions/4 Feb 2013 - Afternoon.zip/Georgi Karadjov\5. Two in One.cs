using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Task_five
{
    static void Main()
    {
        int inputTaskOne = int.Parse(Console.ReadLine());
        string inputTaskTwo_1 = Console.ReadLine();
        string inputTaskTwo_2 = Console.ReadLine();
        int[] arr = new int[inputTaskOne];
        for (int i = 0; i < inputTaskOne; i++)
        {
            arr[i] = i + 1;
        }

        int removeCount = 2;
        int temp = 0;
        
        while (true)
        {
            if (arr[temp] == 0)
            {
                while (arr[temp] == 0)
                {
                    if (temp == inputTaskOne - 1)
                    {
                        break;
                    }
                    if (temp < inputTaskOne - 1 )
                    {
                        temp++;
                    }
   
                }
            }
           
                arr[temp] = 0;
                temp += removeCount;
   
        
            if (arr.Count(n=> n != 0) == 1)
            {
                Console.WriteLine(arr.First(n => n != 0));
                break;
            }
            if (temp > inputTaskOne - 1)
            {
                temp = arr.ToList().IndexOf(arr.First(n => n != 0));
                removeCount++;
            }
        }

        // task two ~~~~~~~~~~~

        int length = inputTaskTwo_1.Length;

        bool turnL = false;
        bool turnR = false;
        int bound = 0;
        for (int i = 0; i < length; i++)
        {
            if (inputTaskTwo_1[i] == 'L')
            {
                turnL = true;
                continue;
            }

            if (inputTaskTwo_1[i] == 'R')
            {
                turnR = true;
                continue;
            }

            if (inputTaskTwo_1[i] == 'S')
            {
                if (turnR == true)
                {
                    bound++;
                    turnR = false;
                    continue;
                }

                if (turnL == true)
                {
                    bound--;
                    turnL = false;
                    continue;
                }
            }
        }

        if (bound == 0)
        {
            Console.WriteLine("bounded");
        }
        else
        {
            Console.WriteLine("unbounded");
        }



        length = inputTaskTwo_2.Length;

        turnL = false;
        turnR = false;
        bound = 0;
        for (int i = 0; i < length; i++)
        {
            if (inputTaskTwo_2[i] == 'L')
            {
                turnL = true;
                continue;
            }

            if (inputTaskTwo_2[i] == 'R')
            {
                turnR = true;
                continue;
            }

            if (inputTaskTwo_2[i] == 'S')
            {
                if (turnR == true)
                {
                    bound++;
                    turnR = false;
                    continue;
                }

                if (turnL == true)
                {
                    bound--;
                    turnL = false;
                    continue;
                }
            }
        }

        if (bound == 0)
        {
            Console.WriteLine("bounded");
        }
        else
        {
            Console.WriteLine("unbounded");
        }
    }
}
