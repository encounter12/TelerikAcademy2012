using System;
using System.Collections.Generic;
using System.Text;

    class ProvadiaNumbers
    {
        static void Main()
        {
            string[] digitsNumber = new string[256];
            List<int> newDigits = new List<int>();
            int digit;
            int index = 0;
            StringBuilder sb = new StringBuilder();
            for (int i = 'a'-1; i <= 'z'; i++)
            {
                if (i!='a'-1)
                {
                    sb.Append((char)i); 
                }
                if (index == 256)
                {
                    break;
                }
                for (int b = 'A'; b <= 'Z'; b++)
                {
                    sb.Append((char)b);
                    digitsNumber[index]=sb.ToString();
                    index++;
                    if (index==256)
                    {
                        break;
                    }
                    sb.Remove(sb.Length - 1,1);
                }
                sb.Clear();
            }
            
            ulong input = ulong.Parse(Console.ReadLine());
            if (input<=255)
            {
                digit = int.Parse((input % 256).ToString());
                Console.WriteLine(digitsNumber[digit]);
                return;
            }
            do
            {
                digit = int.Parse((input % 256).ToString());
                newDigits.Add(digit);
                input /= 256;

            } while (input>0);
            sb.Clear();
            for (int i = newDigits.Count-1; i >= 0; i--)
            {
                sb.Append(digitsNumber[newDigits[i]]);
            }
            Console.WriteLine(sb.ToString()); 
        }

    }

