using System;
using System.Linq;
 
  
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum=0;
            int bestSum = 0;
            string input = Console.ReadLine();
            input = input.Trim();
            string[] numbers = input.Split(',');
            int[] numbersInt = new int[numbers.Length];
            int[] numbersIntSave = new int[numbers.Length];
            int currentPosition=0;
            for (int i = 0; i < numbers.Length; i++)
            {
                numbersInt[i] = int.Parse(numbers[i]);
                numbersIntSave[i] = int.Parse(numbers[i]);
            }
            int amount = int.Parse(Console.ReadLine());
            int movesCount=0;
            for (int i = 0; i < amount; i++)
            {
                currentPosition = 0;
                movesCount = 0;
                numbersInt = numbersIntSave;
                sum = 0;
                string moves = Console.ReadLine();
                moves = moves.Trim();
                string[] movesAmount = moves.Split(',');
                int[] movesInt = new int[movesAmount.Length];
                for (int j = 0; j < movesAmount.Length; j++)
                {
                    movesInt[j] = int.Parse(movesAmount[j]);
                }
                while ((currentPosition>=0&&currentPosition < numbers.Length) && numbersInt[currentPosition]!=0)
                {
                    sum += numbersInt[currentPosition];
                    if (sum > bestSum) bestSum = sum;
                    numbersInt[currentPosition] = 0;
                    currentPosition += movesInt[movesCount];
                    movesCount++;
                    if (movesCount == amount)
                    {
                        movesCount = 0;
                    }
                }
            }
            Console.WriteLine(bestSum);
        }
    }
}