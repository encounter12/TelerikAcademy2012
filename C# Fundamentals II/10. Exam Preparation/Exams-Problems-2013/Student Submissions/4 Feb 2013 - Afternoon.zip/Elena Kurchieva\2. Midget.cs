using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class Problem2Midget
{
    static void Main()
    {
        char[] separators = { ' ', ',' };
        string valleyLine = Console.ReadLine();
        string[] val = valleyLine.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        int[] valley = val.Select(x => int.Parse(x)).ToArray();
        int  countValley = val.Length;

        int maxSum = 0;
        int m = int.Parse(Console.ReadLine());
        string[] patterns = new string[m];

        for (int i = 0; i < m; i++)
        {
            patterns[i] = Console.ReadLine();

            string[] pattStr = patterns[i].Split(separators, StringSplitOptions.RemoveEmptyEntries);
            int[] patt = pattStr.Select(x => int.Parse(x)).ToArray();  

            int count = patt.Length;
            bool[] arrVisit = new bool[countValley];

            for (int j = 0; j < countValley; j++)
            {
                arrVisit[j] = false;
            } 

            int t = 0;
            int possition=0+patt[0];
            int sum = valley[0];
            arrVisit[0] = true;

            while (possition >= 0 && possition < countValley && !arrVisit[possition])
            {   
                sum += valley[possition];
                arrVisit[possition] = true;
                if (t >= count-1)
                { 
                    t = 0;
                }
                else
                {
                    t++;
                } 
                possition = possition + patt[t]; 
                
            }
            maxSum = Math.Max(maxSum, sum);
        }
        
        Console.WriteLine(maxSum);
    }
}
