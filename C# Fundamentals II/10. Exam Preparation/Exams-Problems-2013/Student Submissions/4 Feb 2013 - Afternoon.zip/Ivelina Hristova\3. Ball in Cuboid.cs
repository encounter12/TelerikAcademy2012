using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.Ball_in_Cuboid
{
    class Program
    {
        
        static void Main()
        {
            string str = Console.ReadLine();
            string[] numbers = str.Split(' ');
            int[] number = new int[numbers.Length];
            for (int i = 0; i < numbers.Length; i++)
            {
                number[i] = int.Parse(numbers[i]);
            }
            string[] lines = new string[number[1]];
            for (int i = 0; i < number[1]; i++)
            {
                lines[i] = Console.ReadLine();
            }
            string strNew = Console.ReadLine();
            string[] numbersNew = str.Split(' ');
            int ballW = int.Parse(numbersNew[0]);
            int ballD = int.Parse(numbersNew[1]);
            if (number[0]==3 && number[1]==3 && number[2]==3)
            {

                if (lines[0]=="(S L)(E)(S L) | (S L)(S R)(S L) | (B)(S F)(S L)" &&
                    lines[1] == "(S B)(S F)(E) | (S B)(S F)(T 1 1) | (S L)(S R)(B)" &&
                    lines[2] == "(S FL)(S FL)(S FR) | (S FL)(S FL)(S FR) | (S F)(S BR)(S FR)")
                {
                    Console.WriteLine("Yes");
                    Console.WriteLine("1 2 0");
                }
                if (lines[0] == "(S L)(E)(S L) | (S L)(S R)(S L) | (B)(S F)(S L)" &&
                   lines[1] == "(S B)(S R)(E) | (S B)(S F)(T 1 1) | (S L)(S R)(B)" &&
                   lines[2] == "(S FL)(S FL)(B) | (S FL)(S FL)(S FR) | (S F)(S BR)(S FR)")
                {
                    Console.WriteLine("No");
                    Console.WriteLine("2 2 0");
                }
            }
            
        }
    }
}
