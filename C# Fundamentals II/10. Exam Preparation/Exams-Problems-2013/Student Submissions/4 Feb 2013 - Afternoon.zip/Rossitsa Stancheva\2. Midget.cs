using System;
using System.Text;

class Midget
{
    static void Main()
    {
    
            string inputValley = Console.ReadLine();
            char[] separators = new char[] { ' ', ',' };
            string[] inputSeparated = inputValley.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            int length = inputSeparated.Length;
            int[] valley = new int[length];

            for (int i = 0; i < inputSeparated.Length; i++)
            {
                valley[i] = Convert.ToInt32(inputSeparated[i]);
            }

            int m = int.Parse(Console.ReadLine());

            int[] pattern = new int[m];
            int sumCoins1 = 0;
            int sumMoves = 0;
            int coin = 0;

            for (int i = 0; i < pattern.Length; i++)
            {
                int move = pattern[i];

                if (move > 0)
                    if (i <= 0)
                    {
                        coin = valley[move - 1];
                        sumCoins1 += coin;
                        sumMoves += move;
                    }
                    else
                    {
                        int currentMove = sumMoves + move;
                        coin = valley[currentMove - 1];
                        sumCoins1 += coin;
                        sumMoves += move;
                    }

                Console.WriteLine("the sum is: {0}", sumCoins1);
            }
        }
       
    }
