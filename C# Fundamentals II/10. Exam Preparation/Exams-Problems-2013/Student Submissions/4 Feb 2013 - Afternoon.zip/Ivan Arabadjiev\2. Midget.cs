using System;
using System.Collections.Generic;

class Program
{
    static int[] ReadNumbers(string str)
    {
        string[] values = str.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        int[] numbers = new int[values.Length];
        for (int i = 0; i < values.Length; i++)
        {
            numbers[i] = int.Parse(values[i]);
        }
        return numbers;
    }

    static void Main()
    {
        string strValley = Console.ReadLine();
        int[] valley = ReadNumbers(strValley);
        int numberOfPatterns = int.Parse(Console.ReadLine());
        long maxCoins = long.MinValue;
        List<int> used = new List<int>();
        for (int i = 0; i < numberOfPatterns; i++)
        {
            long currentCoins = valley[0];
            used.Add(0);
            int start = 0;
            int[] currentPattern = ReadNumbers(Console.ReadLine());
            int j = 0;
            while (true)
            {
                int patterItem = j % currentPattern.Length;
                if ((start + currentPattern[patterItem]) >= 0 && (start + currentPattern[patterItem]) < valley.Length && !used.Contains(start + currentPattern[patterItem]))
                {
                    currentCoins += valley[start + currentPattern[patterItem]];
                    used.Add(start + currentPattern[patterItem]);
                    start += currentPattern[patterItem];
                    j++;
                }
                else
                {
                    if (maxCoins < currentCoins)
                    {
                        maxCoins = currentCoins;
                    }
                    break;
                }
            }
            used.Clear();
        }
        Console.WriteLine(maxCoins);
        
    }
}