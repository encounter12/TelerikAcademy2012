using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Midget
{
    static void Main()
    {
        string inputPath = Console.ReadLine();
        string[] splitter = new string[] { "," };
        string[] reps = inputPath.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
        int[] realPath = reps.Select(x => int.Parse(x)).ToArray();
        //for (int i = 0; i < realPath.GetLength(0); i++)
        //{
        //    Console.WriteLine(realPath[i]);
        //}
        int numberOfPatterns = int.Parse(Console.ReadLine());
        int sum = 0;
        for (int i = 1; i <= numberOfPatterns; i++)
        {
        string goldInputPath = Console.ReadLine();
        string[] goldSplitter = new string[] { "," };
        string[] goldReps = goldInputPath.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
        int[] goldRealPath = goldReps.Select(x => int.Parse(x)).ToArray();
        }
    }
}
