using System;
using System.Collections.Generic;
using System.Text;

class Program
{
    static void Main()
    {

        int inputLines = int.Parse(Console.ReadLine());
        int maxChars = int.Parse(Console.ReadLine());
        List<string> words = new List<string>();
        for (int i = 0; i < inputLines; i++)
        {
            string str = Console.ReadLine();
            string[] currentWords = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var word in currentWords)
            {
                words.Add(word);
            }
        }
        StringBuilder result = new StringBuilder();
        int currentCharSum = 0;
        int wordsCount = 0;
        int usedwords = 0;
        while (usedwords + wordsCount < words.Count)
        {
            usedwords += wordsCount;
            wordsCount = 0;
            for (int i = usedwords; i < words.Count; i++)
            {
                if (currentCharSum + words[i].Length <= maxChars - wordsCount)
                {
                    currentCharSum += words[i].Length;
                    wordsCount++;
                }
                else
                {
                    break;
                }
            }
            int numberOfBlankSpace = maxChars - currentCharSum;
            int wordGaps = wordsCount - 1;
            if (wordGaps == 0)
            {
                result.Append(words[usedwords]);
                result.Append("\n");
            }
            else
            {
                int[] gaps = new int[wordGaps];
                int left = numberOfBlankSpace % wordGaps;
                for (int i = 0; i < left; i++)
                {
                    gaps[i] = (numberOfBlankSpace / wordGaps) + 1;
                }
                for (int i = left; i < wordGaps; i++)
                {
                    gaps[i] = numberOfBlankSpace / wordGaps;
                }
                for (int i = 0; i < wordsCount - 1; i++)
                {
                    result.Append(words[usedwords + i]);
                    result.Append(new string(' ', gaps[i]));
                }
                result.Append(words[usedwords + wordsCount - 1]);
                result.Append("\n");
            }
                currentCharSum = 0;
            
        }
        Console.WriteLine(result.ToString());
    }
}
