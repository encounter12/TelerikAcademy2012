using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class ProvadiaNumbers
{
    static string ConvertNum(string input, string[] digits)
    {
        ulong[] arr = new ulong[10];
        ulong number = ulong.Parse(input);
        int count = 0;
        while (number / 256 != 0)
        {
            arr[count] = number % 256;
            number /= 256;
            count++;
        }
        arr[count] = number;

        StringBuilder result = new StringBuilder();

        for (int i = count; i>=0; i--)
        {

            result.Append(digits[arr[i]]);
        }

        return result.ToString();

    }

    static void Main()
    {
        //Read the input
        string input = Console.ReadLine();

        #region Initialize digits
        //Initialize digits
        string[] digits = new string[256];
        for (int i = 0; i < 256; i++)
        {
            if (i<26)
            {
                digits[i] = ((char)((i % 26) + 65)).ToString();
            }
            else
            {
                digits[i] = ((char)((i / 26) + 96)).ToString() + (char)((i % 26) + 65);
            }
        }
        #endregion

        Console.WriteLine(ConvertNum(input,digits));
    }
}
