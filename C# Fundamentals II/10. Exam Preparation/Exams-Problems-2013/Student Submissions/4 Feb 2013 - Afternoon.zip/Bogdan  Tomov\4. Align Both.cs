using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alighn
{
    class Program
    {
         static string[] GetTheWords(int lines)
        {
            string oneLine = null;
            for (int i = 0; i < lines; i++)
            {
                string input = Console.ReadLine();
                oneLine = oneLine + input;
            }
            string[] words = oneLine.Split(' ');
            return words;
        }
        static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());
            int symbolPerLine = int.Parse(Console.ReadLine());
            string[] words = GetTheWords(lines);

        }
    }
}
