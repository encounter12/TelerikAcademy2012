using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Provadia_Numbers
{
    class Program
    {
        static void Main()
        {
            ulong num = ulong.Parse(Console.ReadLine());

            string result = string.Empty;
            ulong remainder;
            string ch = string.Empty;

            if (num == 0)
            {
                Console.WriteLine('A');
                return;
            }

            while (num > 0)
            {
                remainder = num % 256;
                num /= 256;

                int remainderR;
                do
                {
                    remainderR = (int)(remainder % 26);
                    remainder /= 26;

                    if (remainder > 0)
                    {
                        ch = ((char)(remainder + 'a' - 1)).ToString() + ((char)(remainderR + 'A')).ToString() + ch;
                    }
                    else 
                    {
                        ch = ((char)(remainderR + 'A')).ToString() + ch;
                    }
                } while (remainder > 25) ;


                result = ch + result;
                ch = string.Empty;

            }

            Console.WriteLine(result);
        }
    }
}
