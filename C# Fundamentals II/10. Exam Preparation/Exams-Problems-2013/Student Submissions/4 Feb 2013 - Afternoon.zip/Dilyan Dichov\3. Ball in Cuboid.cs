using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _03
{
    

    class Program
    {
        static int ballW ;
        static int ballH ;
        static int ballD ;

        static bool isBasket = false;
        
        

        private static void ReadInput(string[, ,] cube, int w, int h, int d)
        {
            for (int height = 0; height < h; height++)
            {
                string line = Console.ReadLine();
                string[] rows = line.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                for (int depth = 0; depth < d; depth++)
                {
                    string row = rows[depth].Trim();
                    string[] tempW = row.Split(new char[] { '(', ')' }, StringSplitOptions.RemoveEmptyEntries);
                    List<string> temp = new List<string>();
                    foreach (var item in tempW)
                    {
                        if (!item.StartsWith(" "))
                        {
                            temp.Add(item);
                        }
                    }

                    for (int width = 0; width < w; width++)
                    {
                        cube[width, height, depth] = temp[width];
                    }
                }
            }
        }

        private static void CheckBall(string [, ,] cube )//int w1, int h1, int d1
        {
            string str = cube[ballW, ballH, ballD];
            string[] directions = str.Split(new char[] { ' '}, StringSplitOptions.RemoveEmptyEntries);
            if (directions[0]=="S")
            {
                ballH++;
                if (directions[1] == "L")
                {
                    ballW ++;
                }
                else if (directions[1] == "R")
                {
                    ballW++;
                }
                else if (directions[1] == "F")
                {
                    ballD--;
                }
                else if (directions[1] == "B")
                {
                    ballD++;
                }
                else if (directions[1] == "FL")
                {
                    ballD--;
                    ballW++;
                }
                else if (directions[1] == "FR")
                {
                    ballD--;
                    ballW++;
                }
                else if (directions[1] == "BL")
                {
                    ballD++;
                    ballW--;
                }
                else if (directions[1] == "BR")
                {
                    ballD++;
                    ballW++;
                }
            }
            else if (directions[0] == "T")
            {
                ballW = int.Parse(directions[1]);
                ballD = int.Parse(directions[2]);
            }
            else if (directions[0] == "E")
            {
                ballH ++;

            }
            else //if (directions[0] == "B")
            {
                isBasket = true;
            }
        }


        static void Main(string[] args)
        {
            string temp = Console.ReadLine();

            int w = int.Parse(temp.Split()[0]);
            int h = int.Parse(temp.Split()[1]);
            int d = int.Parse(temp.Split()[2]);
            string [, ,] cube = new string[w, h, d];
            ReadInput(cube, w, h, d);
            temp = Console.ReadLine();
            ballW = int.Parse(temp.Split()[0]);
            ballH = 0;
            ballD = int.Parse(temp.Split()[1]);

            int lastW = ballW;
            int lastH = ballH;
            int lastD = ballD;


            while (!isBasket && ballD >= 0 && ballD < d && ballH >= 0 && ballH < h && ballW >= 0 && ballW < w)
            {
                 lastW = ballW;
                 lastD = ballD;
                 lastH = ballH;
                 CheckBall(cube); // lastW, lastH, lastD
               // CheckCoordinates(ballW, ballH, ballD, w, d, h);
            }
            if (isBasket)
            {
                Console.WriteLine("No");
                Console.WriteLine("{0} {1} {2}", ballW, ballH, ballD);
            }
          
            else if (lastH ==h-1)
            {
                Console.WriteLine("Yes");
                Console.WriteLine("{0} {1} {2}", lastW, lastH, lastD);
            }
            else
            {
                Console.WriteLine("No");
                Console.WriteLine("{0} {1} {2}", lastW, lastH, lastD);
            }
        }

    }
}
