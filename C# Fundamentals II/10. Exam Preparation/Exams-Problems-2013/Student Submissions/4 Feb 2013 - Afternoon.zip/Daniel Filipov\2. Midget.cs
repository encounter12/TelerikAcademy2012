using System;
using System.Collections.Generic;
class Midget
{
	public static void Main ()
	{
		string sval = Console.ReadLine ();
		string[] svalley = sval.Split (',');
		int[] valley = new int[svalley.GetLength (0)];
		for (int i=0; i<valley.GetLength(0); i++) {
			valley [i] = int.Parse (svalley [i].Trim ());
		}
		int M = int.Parse (Console.ReadLine ());
		int[][] patterns = new int[M][];
		string spat;
		for (int i=0; i<M; i++) {
			spat = Console.ReadLine ();
			string[] temp = spat.Split (',');
			patterns [i] = new int[temp.GetLength (0)];
			for (int j=0; j<temp.GetLength(0); j++) {
				patterns [i] [j] = int.Parse (temp [j]);
			}
		}
		long bestResult = long.MinValue;
		List<int> passed = new List<int> ();

		for (int i=0; i<M; i++) {
			int pos = 0;
			long result=0;
			int j=0;
			while((pos<valley.GetLength(0))&&(pos>=0)&&!(passed.Contains(pos))){
				result+=valley[pos];
				passed.Add(pos);
				pos+=patterns[i][j];
				j=(j+1)%patterns[i].GetLength(0);
			}
			if(result>bestResult)  bestResult=result;
			passed.Clear();
		}
		Console.WriteLine (bestResult);

	}
}
