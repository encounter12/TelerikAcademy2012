using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class TheGreedyDwarfs
{
    static void Main()
    {
        char[] delimiters = {' ', ','};
        string valley = Convert.ToString(Console.ReadLine());
        string[] valleyNumbers = valley.Split(delimiters,
            StringSplitOptions.RemoveEmptyEntries);

        int[] RealValley = new int[valleyNumbers.Length];
        for (int i = 0; i < valleyNumbers.Length; i++)
        {
            RealValley[i] =int.Parse(valleyNumbers[i]);
        }


        int numberOfPatterns = int.Parse(Console.ReadLine());
        string[][] patternIndex = new string[numberOfPatterns][];
        for (int i = 0; i < patternIndex.Length; i++)
        {
            string tempString = Convert.ToString(Console.ReadLine());
            patternIndex[i] =tempString.Split(delimiters,
            StringSplitOptions.RemoveEmptyEntries);
        }
        int tempMax = 0; int max = int.MinValue;
        for (int i = 0; i < patternIndex.Length; i++)
        {
            int[] copyValley = new int[RealValley.Length];
            Array.Copy(RealValley, copyValley, RealValley.Length);
            int l = 0;
            int pattern = 0;
            tempMax = 0;
            while(l>= 0 && l<patternIndex[i].Length )
            {
                if (copyValley[l] == -501)
                {
                    break;
                }
                tempMax += copyValley[l];
                copyValley[l] = -501;
                l +=int.Parse(patternIndex[i][pattern]);


            }
            if (max < tempMax)
                max = tempMax;
        }

        Console.WriteLine(max);
    }
}
