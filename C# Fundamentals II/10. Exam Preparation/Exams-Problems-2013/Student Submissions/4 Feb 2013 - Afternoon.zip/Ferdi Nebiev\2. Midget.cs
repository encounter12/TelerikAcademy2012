using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Midget
{
    class Program
    {
        static int CalculatePatternSum(int[] coins, int[] pattern)
        {
            int sum = coins[0];
            bool[] visited = new bool[coins.Length];
            visited[0] = true;
            int patternIndexer = 0, coinIndexer = 0;
            coinIndexer+=pattern[patternIndexer%pattern.Length];
            patternIndexer++;
            while (coinIndexer >= 0 && coinIndexer<coins.Length && !visited[coinIndexer])
            {
                visited[coinIndexer] = true;
                sum += coins[coinIndexer];
                coinIndexer += pattern[patternIndexer % pattern.Length];
                patternIndexer++;
            }
            return sum;
        }

        static int[] ParseLine(string line)
        {
            string[] numbersAsString = Regex.Split(line,",\\s");
            int[] numbers = new int[numbersAsString.Length];

            for (int i = 0; i < numbersAsString.Length; i++)
            {
                numbers[i] = int.Parse(numbersAsString[i]);
            }

            return numbers;
        }
        static void Main()
        {
            int[] coins = ParseLine(Console.ReadLine());
            int patternCount = int.Parse(Console.ReadLine());
            int[][] pattern = new int[patternCount][];
            int maxSum = int.MinValue;

            for (int i = 0; i < patternCount; i++)
            {
                pattern[i] = ParseLine(Console.ReadLine());
                int tempSum = CalculatePatternSum(coins, pattern[i]);
                if (tempSum > maxSum)
                {
                    maxSum = tempSum;
                }
            }
            Console.WriteLine(maxSum);
        }
    }
}
