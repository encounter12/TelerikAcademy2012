using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class BallInCuboid
{
    static void Main(string[] args)
    {
        string demention = Console.ReadLine();
        string[] dementions = demention.Split(' ');
        int width = int.Parse(dementions[0]);
        int height = int.Parse(dementions[1]);
        int depth = int.Parse(dementions[2]);

        string[, ,] cube = new string[width, height, depth];
        for (int h = 0; h < height; h++)
        {
            string[] input = Console.ReadLine().Split('|');
            for (int d = 0; d < depth; d++)
            {
                string[] elements = input[d].Split(new char[] { '(',')' }, StringSplitOptions.RemoveEmptyEntries);
                elements = MySplit(elements);
                for (int w = 0; w < width; w++)
                {
                    cube[w, h, d] = elements[w];
                }
            }
        }

        string inputCoords = Console.ReadLine();
        string[] ballCoords = inputCoords.Split(' ');
        int W = int.Parse(ballCoords[0]);
        int D = int.Parse(ballCoords[1]);
        int H = 0;
        int prevW = W;
        int prevH = H;
        int prevD = D;

        
        while (true)
        {
            //Console.WriteLine("{0} {1} {2}", W, H, D);
            //Console.WriteLine(cube[W, H, D]);
            //Console.WriteLine(new string('-', 70));
            if (!isInside(W, H, D, cube, prevW, prevH, prevD))
            {
                break;
            }
            
            
            prevW = W;
            prevH = H;
            prevD = D;

            
            switch (cube[W, H, D][0])
            {
                case 'E':
                    H++;
                    break;
                case 'B':
                    Console.WriteLine("No");
                    Console.WriteLine("{0} {1} {2}", W, H, D);
                    break;
                case 'S':
                    
                    switch (cube[W, H, D][0+2])
                    {
                        case 'L':
                            W--;
                            break;
                        case 'R':
                            W++;
                            break;
                        case 'B':
                            D++;
                            break;
                        case 'F':
                            D--;
                            break;
                    }
                    if (cube[W, H, D].Length>3)
                    {
                        switch (cube[W, H, D][0 + 2])
                        {
                            case 'L':
                                W--;
                                break;
                            case 'R':
                                W++;
                                break;
                        }
                        
                    }
                    H++;
                    break;
                case 'T':
                    string[] coords = cube[W, H, D].Split(new char[] {' '}, StringSplitOptions.RemoveEmptyEntries);
                    W = int.Parse(coords[1]);
                    H = int.Parse(coords[2]);
                    break;
                default:
                    Console.WriteLine("Nekwa magariq!");
                    break;
            }
            
        }
    }

    static string[] MySplit(string[] lines)
    {
        List<string> listOfString = new List<string>();
        for (int i = 0; i < lines.Length; i++)
        {
            if (!String.IsNullOrWhiteSpace(lines[i]))
            {
                listOfString.Add(lines[i]);
            }
        }
        return listOfString.ToArray();

    }

    static bool isInside(int w, int h, int d, string[, ,] cube, int pw,int ph, int pd)
    {
        //Console.WriteLine("=----------->{0} {1} {2}", w, h, d); 
        if (h >= cube.GetLength(1) - 1)
        {
            if (cube[w, h, d][0] == 'B')
            {
                Console.WriteLine("No");
                Console.WriteLine("{0} {1} {2}", w, h,d);
                return false;
            }
            Console.WriteLine("Yes");
            Console.WriteLine("{0} {1} {2}", w,h,d);
            return false;
        }
        if (w < 0 || d < 0 || w >= cube.GetLength(0)-1 || d >= cube.GetLength(2)-1 || h < 0 )
        {
            Console.WriteLine("No");
            Console.WriteLine("{0} {1} {2}", w, h, d);
           // Console.WriteLine("{0} {1} {2}", pw ,ph, pd);
            return false;
        }
        return true;
    }
}