using System;
using System.Text;
using System.Numerics;

class Provadia
{
    static string[] InputProvadiaNumbers()
    {
        string[] numbers = new string[256];
        for (int i = 0; i < 26; i++)
        {
            numbers[i] = ((char)(65 + i)).ToString();
        }
        int l = 0;
        for (int i = 26; i < 256; i++)
        {
            l++;
            for (int j = 0; j < 26; j++)
            {
                string s = "";
                switch (l)
                {
                    case 1: s = "a";
                        break;
                    case 2: s = "b";
                        break;
                    case 3: s = "c";
                        break;
                    case 4: s = "d";
                        break;
                    case 5: s = "e";
                        break;
                    case 6: s = "f";
                        break;
                    case 7: s = "g";
                        break;
                    case 8: s = "h";
                        break;
                    case 9: s = "i";
                        break;
                }
                if (j + l * 26 >= 256) break;
                numbers[j + l * 26] = s + numbers[j];
            }
        }
        return numbers;
    }

    static int FindRemainder(BigInteger number)
    {
        int remainder = (int)(number % 256);
        return remainder;
    }

    static StringBuilder Findresult(BigInteger number, string[] arr, StringBuilder result)
    {
        while (number != 0)
        {
            result.Insert(0, arr[FindRemainder(number)]);
            number /= 256;
        }
        return result;
    }

    static void Main()
    {
        string[] numbers = InputProvadiaNumbers();
        BigInteger number = BigInteger.Parse(Console.ReadLine());        
        StringBuilder result = new StringBuilder();
        Console.WriteLine(Findresult(number, numbers, result));
    }
}
