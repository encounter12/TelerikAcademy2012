using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        ulong num = ulong.Parse(Console.ReadLine());

        //ulong num = ulong.MaxValue;
        char[] bigLetter = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
        char[] smallLetter = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};

        string[] proNumeration = new string[256];
        for (int i = 0; i < 26; i++)
        {
            proNumeration[i] = bigLetter[i].ToString();
        }

        int next = 26;

        for (int i = 0; i < smallLetter.Length; i++)
        {
            for (int j = 0; j < bigLetter.Length; j++ , next++)
            {
                
                string addRep = smallLetter[i].ToString() + bigLetter[j].ToString();
                proNumeration[next] = addRep;

            }
        }

        next = 234;

        for (int j = 0; j < bigLetter.Length-4; j++, next++)
        {

            string addRep = "i" + bigLetter[j].ToString();
            proNumeration[next] = addRep;

        }

        List<string> proRep = new List<string>();
        if (num == 0)
        {
            proRep.Add("A");
        }
        else
        {
            while (num > 0)
            {
                proRep.Add(proNumeration[num % 256]);
                num = num / 256;
            }
        }
        proRep.Reverse();
        for (int i = 0; i < proRep.Count; i++)
        {
            Console.Write(proRep[i]);
        }
    }
}