using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BallInCuboid
{
    class Program
    {

        static void Main(string[] args)
        {
           string[] sizes = Console.ReadLine().Split(' ');
           int width = int.Parse(sizes[0]);
           int height = int.Parse(sizes[1]);
           int depth = int.Parse(sizes[2]);
           string[,,] cube = ReadTheInput(width,height,depth);
           string[] ballStarter = Console.ReadLine().Split(' ');
           int ballStartW = int.Parse(ballStarter[0]);
           int ballStartD = int.Parse(ballStarter[1]);
           StartTheBall(cube, ballStartD, ballStartW,width,height,depth);
        }

        private static void StartTheBall(string[, ,] cube, int ballStartD, int ballStartW, int width, int height, int depth)
        {
            bool stuck = false;
            int h = 0;
            int w = ballStartW;
            int d = ballStartD;
            while (true)
            {
                if (cube[w, h, d] == "S L")
                {
                    if (w - 1 >= 0)
                    {
                        w = w - 1;
                        h = h + 1;
                    }
                    else if (h != height - 1)
                    {
                        stuck = true;
                        Console.WriteLine("No");
                        Console.WriteLine("{0} {1} {2}",w,h,d);
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                }
                if (cube[w, h, d] == "S R")
                {
                    if (w + 1 < width)
                    {
                        w = w + 1;
                        h = h + 1;
                    }
                    else if (h != height - 1)
                    {
                        stuck = true;
                        Console.WriteLine("No");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                }
                if (cube[w, h, d] == "S F")
                {
                    if (d - 1 >= 0)
                    {
                        d = d - 1;
                        h = h + 1;
                    }
                    else if (h != height - 1)
                    {
                        stuck = true;
                        Console.WriteLine("No");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                }
                if (cube[w, h, d] == "S B")
                {
                    if (d + 1 < depth)
                    {
                        d = d + 1;
                        h = h + 1;
                    }
                    else if (h != height - 1)
                    {
                        stuck = true;
                        Console.WriteLine("No");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }

                }
                if (cube[w, h, d] == "S FL")
                {
                    if (w - 1 >= 0 && d - 1 >= 0)
                    {
                        w = w - 1;
                        d = d - 1;
                        h = h + 1;
                    }
                    else if (h != height - 1)
                    {
                        stuck = true;
                        Console.WriteLine("No");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                }
                if (cube[w, h, d] == "S FR")
                {
                    if (w + 1 < width && d - 1 >= 0)
                    {
                        w = w + 1;
                        d = d - 1;
                        h = h + 1;
                    }
                    else if (h != height - 1)
                    {
                        stuck = true;
                        Console.WriteLine("No");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                }
                if (cube[w, h, d] == "S BR")
                {
                    if (w + 1 < width && d + 1 < depth)
                    {
                        w = w + 1;
                        d = d + 1;
                        h = h + 1;
                    }
                    else if (h != height - 1)
                    {
                        stuck = true;
                        Console.WriteLine("No");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                }
                if (cube[w, h, d] == "S BL")
                {
                    if (w - 1 >= 0 && d + 1 < depth)
                    {
                        w = w - 1;
                        d = d + 1;
                        h = h + 1;
                    }
                    else if (h != height - 1)
                    {
                        stuck = true;
                        Console.WriteLine("No");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                }
                if (cube[w, h, d] == "E")
                {
                    h++;
                    if (h == height - 1)
                    {
                        Console.WriteLine("Yes");
                        Console.WriteLine("{0} {1} {2}", w, h, d);
                        break;
                    }
                }
                if (cube[w, h, d] == "B")
                {
                    stuck = true;
                    Console.WriteLine("No");
                    Console.WriteLine("{0} {1} {2}", w, h, d);
                    break;
                }
                if (cube[w,h,d][0]=='T')
                {
                    char wchar = cube[w, h, d][2];
                    char dchar = cube[w, h, d][4];
                    w = ((int)(wchar))-48;
                    d = ((int)(wchar))-48;

                }

            }
        }

         static string[,,] ReadTheInput(int width,int height,int depth)
        {
             
            string[, ,] cube = new string[width, height, depth];
            string[] unSplited = new string[height];
            string allInput = null; ;
            for (int i = 0; i < height; i++)
            {
                unSplited[i] = Console.ReadLine();
                allInput = allInput + unSplited[i]; 
            }
            string[] splited = allInput.Split(new char[] { '|', '(', ')'},StringSplitOptions.RemoveEmptyEntries);
            List<string> forCube = new List<string>();
            for (int i = 0; i < splited.Length; i++)
            {
                
                    if (splited[i]!=" ")
                {
                    forCube.Add(splited[i]);
                }
            }
            int splitCounter = 0;
            for (int h = 0; h < height; h++)
            {
                for (int d = 0; d < depth; d++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        cube[w, h, d] =forCube[splitCounter];
                        splitCounter++;
                    }
                }
            }
            return cube;
        }
    }
}
