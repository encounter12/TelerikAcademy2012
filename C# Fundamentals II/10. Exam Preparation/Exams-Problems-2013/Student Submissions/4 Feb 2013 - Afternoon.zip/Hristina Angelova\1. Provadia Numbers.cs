using System;
using System.Text;

class ProvadiaNumbers
{
    static int startIndex = (int)'A';

    static void Main()
    {
        //
        Console.WriteLine("{0}", GetProvadiaNumber(decimal.Parse(Console.ReadLine())));
    }

    static string GetProvadiaNumber(decimal number)
    {
        if (0 <= number && number <= 255)
        {
            return GetProvadiaDigit((byte)number);
        }
        else
        {
            string provadiaNum = "";
            byte reminder = (byte)(number % 256);
            decimal quotient = number / 256;

            

            provadiaNum += quotient >= 256 ? GetProvadiaNumber(quotient) : GetProvadiaDigit((byte)(quotient % 256));
            provadiaNum += GetProvadiaDigit(reminder);
            return provadiaNum;
        }
    }

    static string GetProvadiaDigit(byte number)
    {
        int reminder = number % 26;
        int quotient = number / 26;

        string result = "";

        result += quotient > 0 ? ((char)(startIndex + 31 + quotient)).ToString() : "";
        result += (char)(startIndex + reminder);

        return result;
    }
}