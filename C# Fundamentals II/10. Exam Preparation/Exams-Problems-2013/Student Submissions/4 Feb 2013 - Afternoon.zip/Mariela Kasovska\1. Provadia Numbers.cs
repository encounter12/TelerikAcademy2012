using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class ProvadiaNumbers
{
    static void Main(string[] args)
    {
        int number = int.Parse(Console.ReadLine());

        string[] upperdigits = {"A", "B", "C", "D", "E", "F", "G", "H", "I" , "J", "K", "L", "M", 
                                 "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        string[] lowerdigits = {"a", "b", "c", "d", "e", "f", "g", "h", "i" };

        //StringBuilder sb = new StringBuilder();
        //string[] letters = new string[256];
    
        //for (int i = 0; i < lowerdigits.Length; i++)
        //{
        //    for (int j = 0; j < upperdigits.Length; j++)
        //    {
        //        letters[j] = sb.Append(lowerdigits[i]).Append(upperdigits[j]).ToString();
        //        Console.WriteLine(letters[j]);
        //        sb.Clear();
        //    }   
        //}

        for (int i = 0; i < upperdigits.Length; i++)
        {
            if (number == i)
            {
                Console.WriteLine(upperdigits[i]);
            }
            else
            {
                
            }
        }

    }
}
