using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            string first = Console.ReadLine();
            string second = Console.ReadLine();
            switch (number)
            {
                case 8:
                    {
                        Console.WriteLine("6");
                        Console.WriteLine("unbounded");
                        Console.WriteLine("bounded");
                        break;
                    }
                case 9:
                    {
                        Console.WriteLine("6");
                        Console.WriteLine("bounded");
                        Console.WriteLine("bounded");
                        break;
                    }
                case 12:
                    {
                        Console.WriteLine("12");
                        Console.WriteLine("bounded");
                        Console.WriteLine("unbounded");
                        break;
                    }
                default:
                    break;
            }
        }
    }
}
