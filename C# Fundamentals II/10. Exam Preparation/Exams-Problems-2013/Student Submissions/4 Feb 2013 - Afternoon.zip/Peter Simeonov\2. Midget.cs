using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Exam._2.Midget
{


    class Program
    {
        public static long coinsFinal = long.MinValue;
        public static int[,] valley;
        public static List<int[]> patterns = new List<int[]>();
        //public static int valleyLength = 0;

        static void Main(string[] args)
        {
            string[] tempValley = Console.ReadLine().Trim().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            int valleyLength = tempValley.Length;
            valley = new int[2, valleyLength];
            for (int index = 0; index < valleyLength; index++)
            {
                valley[0, index] = int.Parse(tempValley[index]);
                valley[1, index] = 0;
            }


            int numberOfPatterns = int.Parse(Console.ReadLine());
            for (int index = 0; index < numberOfPatterns; index++)
            {
                string[] pattern = Console.ReadLine().Trim().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                int[] newPattern = new int[pattern.Length];
                for (int items = 0; items < pattern.Length; items++)
                {
                    newPattern[items] = int.Parse(pattern[items]);
                }
                patterns.Add(newPattern);
            }

            int restartPattern = 0;

            for (int listIndex = 0; listIndex < patterns.Count; listIndex++)
            {
                long coins = valley[0, 0];
                for (int i = 0; i < valley.GetLength(1); i++)
                {
                    valley[1, i] = 0;
                }
                valley[1, 0] = 1;
                int positionValley = patterns[listIndex][0];
                int positionPattern = 0;
                while (!IsItVictory(positionValley, coins))
                {

                    coins += valley[0, positionValley];
                    valley[1, positionValley] = 1;
                    if (positionPattern < patterns[listIndex].Length - 1)
                    {
                        positionPattern++;

                    }
                    else
                    {
                        positionPattern = restartPattern;
                    }

                    positionValley += patterns[listIndex][positionPattern];


                }
            }
            Console.WriteLine(coinsFinal);

        }

        private static bool IsItVictory(int posValley, long coins)
        {
            bool victory = false;
            if (posValley < 0 || posValley > valley.GetLength(1))
            {
                victory = true;
            }
            else if (valley[1, posValley] == 1)
            {
                victory = true;
            }
            if (victory)
            {
                if (coinsFinal < coins)
                {
                    coinsFinal = coins;
                }
            }

            return victory;
        }
    }
}
