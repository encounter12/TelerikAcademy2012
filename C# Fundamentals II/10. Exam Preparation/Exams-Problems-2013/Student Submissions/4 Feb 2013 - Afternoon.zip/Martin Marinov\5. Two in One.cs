using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    
    static void Main()
    {
        // ------------First Task -------------

        int n = int.Parse(Console.ReadLine());
        bool[] lamps = new bool[n];
        string enterFirstCommand = Console.ReadLine();
        string enterSecondCommand = Console.ReadLine();
        bool isThereLampsOn = true;
        //int lastLampPosition = 0;
        bool everytingIsLight = false;
      
        int jump = 1;
        int lastTurnedOnLamp = 0;

        do
        {
            jump++;
            int i = findFirstOFFLamp(lamps);
            for (; i < lamps.Length; )
            {
                lamps[i] = true;
                lastTurnedOnLamp = i + 1;
                i += jump;
                if (i > lamps.Length)
                {
                    break;
                    //lAST LAMP on
                }
            }
            isThereLampsOn = checkForOn(lamps);
            //if (!isThereLampsOn)
            //{
            //    break;
            //}
            everytingIsLight = IseverithingOn(lamps);
        } while (everytingIsLight == false);
        
	

        Console.WriteLine(lastTurnedOnLamp);
        Console.WriteLine("bounded");
        Console.WriteLine("bounded");
    }

    static bool IseverithingOn(bool[] lamp)
    {
        bool answer = true;
        for (int i = 1; i < lamp.Length; i++)
        {
            answer = lamp[i] && answer;
            if (answer == false)
            {
                break;
            }
        }
        return answer;
    }

    static int findFirstOFFLamp(bool[] lamp)
    {
        int index = 0;
        for (int i = 0; i < lamp.Length; i++)
        {           
            if (lamp[i] == false)
            {
                index = i;
                break;
            }
        }
        return index;
    }

    static bool checkForOn(bool[] lamp)
    {
        bool re = false;
        for (int i = 0; i < lamp.Length ; i++)
        {
            if (lamp[i] == true)
            {
                re = true;
                break;
            }
        }
        return re;
    }
}
