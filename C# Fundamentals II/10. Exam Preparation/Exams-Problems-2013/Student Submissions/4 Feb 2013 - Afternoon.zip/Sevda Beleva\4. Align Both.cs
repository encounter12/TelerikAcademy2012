using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace _4.AlignBoth
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberOfLines = int.Parse(Console.ReadLine());
            int numberOfSymbolsOnLine = int.Parse(Console.ReadLine());
            string text = Console.ReadLine();
            StringBuilder newtext = new StringBuilder();
            
            for (int i = 0; i < numberOfLines; i++)
            {
                text = Console.ReadLine();
                newtext.Append(text[i]);
            }


            string some = newtext.ToString();
            some.Trim();
            string[] array = some.Split(' ');
            for (int i = 0; i <= numberOfLines; i++)
            {
                for (int j = 0; j <= numberOfSymbolsOnLine; j++)
                {
                    Console.WriteLine(array[j + ' ']);
                }
                
            }
           
        }
    }
}
