using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlignBoth
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int w = int.Parse(Console.ReadLine());
            string[] inLines = new string[n];
            StringBuilder allText = new StringBuilder();
            for (int i = 0; i < n; i++)
            {
                inLines[i] = Console.ReadLine() + " ";
                allText.Append(inLines[i]);
            }
            string allTextStr = allText.ToString();
            string[] words = allTextStr.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
            int countSymbols = 0, countLines = 0, countWords=0;
            for (int i = 0; i < words.Length; i++)
            {
                if (countSymbols + words[i].Length +countWords<= w)
                {
                    countSymbols = countSymbols + words[i].Length;
                    countWords++;
                }
                else
                {
                    countSymbols = 0;
                    countLines++;
                    countWords = 0;
                    countSymbols = countSymbols + words[i].Length;
                    countWords++;
                }

            }
            StringBuilder[] newLines = new StringBuilder[countLines+1];
            for (int i = 0; i < countLines+1; i++)
            {
                newLines[i] = new StringBuilder();
            }
            countSymbols = 0;
            countLines = 0;
            countWords = 0;
            for (int i = 0; i < words.Length; i++)
            {
                if (countSymbols + words[i].Length + countWords <= w)
                {
                    newLines[countLines].Append(words[i]);
                    newLines[countLines].Append(" ");
                    countSymbols = countSymbols + words[i].Length;
                    countWords++;
                }
                else
                {
                    countSymbols = 0;
                    countLines++;
                    countWords = 0;
                    newLines[countLines].Append(words[i]);
                    newLines[countLines].Append(" ");
                    countSymbols = countSymbols + words[i].Length;
                    countWords++;
                }

            }
            
            for (int i = 0; i < countLines+1; i++)
            {
                bool firstTry = true;
                int current = 0, next = 0;
                newLines[i] = newLines[i].Remove(newLines[i].Length - 1, 1);
                while (newLines[i].Length < w)
                {
                    
                    current = newLines[i].ToString().IndexOf(" ",current);
                    next = newLines[i].ToString().IndexOf(" ",current+1);
                    if (firstTry && current == -1) break;
                    while(current == next - 1)
                    {
                        current = next;
                        next = newLines[i].ToString().IndexOf(" ", current + 1);
                    }
                    if (current != -1)
                    {
                        firstTry = false;
                        newLines[i] = newLines[i].Insert(current, " ");
                        current = current + 2;
                    }
                    else
                    {
                        current = 0;
                        next = 0;
                    }
                }
                Console.WriteLine(newLines[i]);
            }
        }
    }
}
