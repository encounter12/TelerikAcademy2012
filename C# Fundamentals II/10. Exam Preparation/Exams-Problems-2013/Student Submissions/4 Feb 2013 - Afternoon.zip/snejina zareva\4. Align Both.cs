using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlignBoth
{
    class Program
    {
        static void Main(string[] args)
        {
          
            int N = int.Parse(Console.ReadLine());
            int W = int.Parse(Console.ReadLine());
        
            
                string line;
                line= Console.ReadLine();
            
            
            var arr = line.ToCharArray();
            
                for (int i = 0; i < W; i++)
                {
                    Console.Write(arr[i]);
                }
                

        }
    }
}
