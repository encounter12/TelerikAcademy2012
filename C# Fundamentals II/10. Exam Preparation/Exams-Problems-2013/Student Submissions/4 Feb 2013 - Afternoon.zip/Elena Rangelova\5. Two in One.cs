using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main()
        {
            int lamps = int.Parse(Console.ReadLine());
           
            int[] streetLamps = new int[lamps];
            for (int i = 0; i < lamps; i++)
            {
                streetLamps[i] = i+1;
            }

            //foreach (var item in streetLamps)
            //{
            //    Console.WriteLine(item);
            //}
           // for (int i = 0; i < lamps; i++)
           // {
            Console.WriteLine(  Lam(streetLamps, lamps, lamps));
           // }
            //Console.WriteLine(Lam(streetLamps, lamps, lamps));
           
            //for (int i = 0; i < lamps; i+=2)
            //{
            //    //streetLamps[i] = -1;
            //    int num = i;
		
               
            //}
            //foreach (var item in streetLamps)
            //{
            //    Console.WriteLine(item);
            //}
            Console.WriteLine();
        }
        static int Lam(int[] streetLamps,int lamps,int num)
        {

            int count = lamps / 2 ;
            int start = 0;
            int result = 0;
           
                for (int j = 1; j < lamps; j++)
                {
                    
                    for (int i = start; i <= count; i += (j+1))
                    {
                    
                    streetLamps[i] = -1;
                    
                    
                    }
                    start++;
                    count = count / 2;
                
                
            }
            for (int i = 0; i < lamps; i++)
            {
                if (streetLamps[i] == -1)
                {
                    result = streetLamps.Last(element => element > 0);
                    
                }
                else
                {
                    return streetLamps.Last(element => element > 0);
                }


                return streetLamps.Last(element => element > 0);
                result = streetLamps.Last(element => element > 0);
            }

            return result; //streetLamps.Last(element => element > 0);
            Console.WriteLine(result);
            
        }
    }
