using System;
using System.Numerics;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Linq;

class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        List<int> result = new List<int>();
        bool[] visited = new bool[n];
        int start = 0;
        int second = 2;

        while (start < n)
        {
            for (int i = start; i < n; i += second)
            {
                if (!visited[i])
                {
                    result.Add(i + 1);
                    visited[i] = true;
                }
            }
            start++;
            second += 4;
        }

        Console.WriteLine(result[result.Count - 1]);

        Console.WriteLine("bounded");
        Console.WriteLine("bounded");
    }
}