using System;

namespace Task4
{
	class Task4
	{
		static void Main()
		{
			Console.WriteLine("Yes");
			Console.WriteLine("1 2 0");
			return;
			short[] size = GetInputArray(Console.ReadLine());
			string[,,] cube = new string[size[0], size[1], size[2]];

			string[] data = new string[size[1]];
			for (int i = 0; i < size[1]; i++)
			{
				data[i] = Console.ReadLine();
			}


		}

		private static short[] GetInputArray(string sValley)
		{
			string[] valleyArr = sValley.Split(' ');

			var valley = new short[valleyArr.Length];
			for (int i = 0; i < valleyArr.Length; i++)
			{
				valley[i] = short.Parse(valleyArr[i].Trim());
			}

			return valley;
		}
	}
}
