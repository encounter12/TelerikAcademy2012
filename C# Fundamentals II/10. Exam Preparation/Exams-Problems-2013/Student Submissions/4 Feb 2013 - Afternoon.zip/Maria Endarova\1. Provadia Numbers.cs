using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] big ={ 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
                          'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
            char[] small ={ 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k','l', 'm',
                            'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x','y', 'z'};
            string[] array = new string[256];
            for (int i = 0; i < big.Length; i++)
            {
                array[i] = big[i].ToString();
            }
            int g = 26;
            for (int i = 0; i < 26; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    if (g < 256)
                    {
                        array[g] = small[i].ToString() + big[j].ToString();
                        g++;

                    }
                    else
                    {
                        break;
                    }

                }
            }
            //for (int i = 0; i < 256; i++)
            //{
            //    Console.WriteLine(array[i]);
            //}
            ulong number = ulong.Parse(Console.ReadLine());
            List<ulong> conv = new List<ulong>();
            if (number==0)
            {
                Console.WriteLine('A');
            }
            else
            {
                while (number > 0)
                {
                    conv.Add(number % 256);
                    number = number / 256;
                }
                conv.Reverse();
                for (int i = 0; i < conv.Count; i++)
                {
                    Console.Write(array[conv[i]]);
                }
            }
           
            Console.WriteLine();
        }
    }
}
