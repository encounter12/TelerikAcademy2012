using System;

class Midget
{
    static void Main()
    {
        //string str = "1, 3, -6, 7, 4, 1, 12";
        string[] valley = Console.ReadLine().Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
        int patterns = int.Parse(Console.ReadLine());
        bool[] valleyVisited = new bool[valley.Length];
        bool stop;
        int maxSum = int.MinValue;
        int num = 0;
        for (int patt = 0; patt < patterns; patt++)
        {
            string[] currentPattern = Console.ReadLine().Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            stop = false;
            int currentIndexinValley = 0;
            valleyVisited[currentIndexinValley] = true;
            int tmpSum = int.Parse(valley[currentIndexinValley]);
            //!(currentIndexinValley > valley.Length - 1 || currentIndexinValley < 0) && !(valleyVisited[currentIndexinValley] == true)
            while (stop == false)
            {
                for (int index = 0; index < currentPattern.Length; index++)
                {
                    num = int.Parse(currentPattern[index]);
                    currentIndexinValley += num;

                    if (!(currentIndexinValley > valley.Length - 1 || currentIndexinValley < 0))
                    {
                        if (valleyVisited[currentIndexinValley] == false)
                        {
                            tmpSum += int.Parse(valley[currentIndexinValley]);
                            valleyVisited[currentIndexinValley] = true;
                        }
                        else
                        {
                            stop = true;
                            break;
                        }
                    }
                    else
                    {
                        stop = true;
                        break;
                    }
                } 
            }            
            if (maxSum < tmpSum)
            {
                maxSum = tmpSum;
            }
            for (int index = 0; index < valleyVisited.Length; index++)
            {
                valleyVisited[index] = false;
            }
            tmpSum = 0;
        }

        Console.WriteLine(maxSum);

    }
}