using System;
using System.Text;

class Cuboid
{
    struct Coords
    {
        public int wCoord;
        public int hCoord;
        public int dCoord;
    }
    static Coords CalculateNewCoord(string cellString,Coords inputCoords)
    {
        Coords resultCoords = inputCoords;
        string[] parameters=cellString.Split(' ');
        if (parameters[0].ToUpper() == "S")
        {
            switch (parameters[1].ToUpper())
            {
                case "F": resultCoords.dCoord--;
                    resultCoords.hCoord++; break;
                case "B": resultCoords.dCoord++;
                    resultCoords.hCoord++; break;
                case "L": resultCoords.wCoord--;
                    resultCoords.hCoord++; break;
                case "R": resultCoords.wCoord++;
                    resultCoords.hCoord++;
                    break;
                case "FL": resultCoords.wCoord--;
                    resultCoords.hCoord++;
                    resultCoords.dCoord--; break;
                case "FR": resultCoords.wCoord++;
                    resultCoords.hCoord++;
                    resultCoords.dCoord--; break;
                case "BL": resultCoords.wCoord--;
                    resultCoords.hCoord++;
                    resultCoords.dCoord++;
                    break;
                case "BR": resultCoords.wCoord++;
                    resultCoords.hCoord++;
                    resultCoords.dCoord++; break;
                default:
                    break;
            } 
        }
        else 
        {
            int witdhCoord = int.Parse(parameters[1]);
            int depthCoord = int.Parse(parameters[2]);
            resultCoords.wCoord = witdhCoord;
            resultCoords.dCoord = depthCoord;
        }
        return resultCoords;
    }
    static void Main()
    {
        string[] inputDimensions = Console.ReadLine().Split(' ');
        int cubeWidth = int.Parse(inputDimensions[0]);
        int cubeHeight = int.Parse(inputDimensions[1]);
        int cubeDepth = int.Parse(inputDimensions[2]);
        string [,,] myCube= new string[cubeWidth,cubeHeight,cubeDepth];
        for (int i = 0; i < cubeHeight; i++)
        {
            string[] inputLine = Console.ReadLine().Split('|');
            int D = 0;
            foreach (var item in inputLine)
            {
                int W = 0;
                if (item != "")
                {
                    StringBuilder cubeCell = new StringBuilder();
                    bool isInBrackets = false;
                    for (int j = 0; j < item.Length; j++)
                    {
                        switch (item[j])
                        {
                            case '(': isInBrackets = true; break;
                            case ')': isInBrackets = false;
                                myCube[W, i, D] = cubeCell.ToString().Trim();
                                W++;
                                cubeCell.Clear();
                                break;
                            default: if (isInBrackets)
                                {
                                    cubeCell.Append(item[j].ToString());
                                }
                                break;
                        }
                    }
                }
                D++;
            }
        }
        string[] ballWD = Console.ReadLine().Split(' ');
        Coords ballCurrentCoors = new Coords();
        ballCurrentCoors.wCoord = int.Parse(ballWD[0]);
        ballCurrentCoors.hCoord = 0;
        ballCurrentCoors.dCoord = int.Parse(ballWD[1]);
        Coords bestBallCoords = new Coords();
        bestBallCoords = ballCurrentCoors;
        bool stucked = false;
        bool exited = false;
        string currentCell="";
        while (!stucked && !exited)
        {
            currentCell=myCube[ballCurrentCoors.wCoord,ballCurrentCoors.hCoord,ballCurrentCoors.dCoord];
            if (currentCell.Equals("B"))
            {
                stucked=true;
            }
            else
                if (currentCell.Equals("E"))
                {
                    ballCurrentCoors.hCoord++;
                }
                else
                {
                    bestBallCoords = ballCurrentCoors;
                    ballCurrentCoors=CalculateNewCoord(currentCell,ballCurrentCoors);
                }
            if (ballCurrentCoors.wCoord >= myCube.GetLength(0) || ballCurrentCoors.dCoord >= myCube.GetLength(2) ||
                ballCurrentCoors.wCoord < 0 || ballCurrentCoors.dCoord < 0)
            {
                stucked = true;
            }
            else if (ballCurrentCoors.hCoord == (myCube.GetLength(1)-1))
            {
                exited = true;
                bestBallCoords = ballCurrentCoors;
            }
        }
        Console.WriteLine("{0}",exited&&!stucked?"Yes":"No");
        Console.WriteLine("({0},{1},{2})",bestBallCoords.wCoord,bestBallCoords.hCoord,bestBallCoords.dCoord);
    }
}