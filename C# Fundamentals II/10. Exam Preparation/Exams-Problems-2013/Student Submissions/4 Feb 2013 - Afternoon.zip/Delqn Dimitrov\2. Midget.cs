using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Problem2
{
    int[] val = new int[10000], pn = new int[500];
    int[][] patterns = new int [500][];
    int n, np;


    void read()
    {

        string valley;
        valley = Console.ReadLine();
        int neg = 1;


        for (int i = 0; i < valley.Length; ++i)
        {

            if (valley[i] == ',')
            {

                val[n] *= neg;
                //Console.WriteLine(val[n]);
                n++;
                neg = 1;
                continue;
            }
            if (valley[i] == ' ') continue;
            if (valley[i] == '-')
            {

                neg = -1;
                continue;
            }
            val[n] *= 10;
            val[n] += valley[i] - '0';
            //Console.WriteLine(val[n]);
        }
        val[n] *= neg;
        n++;



        np = int.Parse(Console.ReadLine());

        for (int i = 0; i < np; ++i)
        {

            patterns[i] = new int[100];
            string s = Console.ReadLine();
            neg=1;
            for (int j = 0; j < s.Length; ++j)
            {

                if (s[j] == ',')
                {

                    patterns[i][pn[i]] *= neg;
                    pn[i]++;
                    neg = 1;
                    continue;
                }
                if (s[j] == ' ') continue;
                if (s[j] == '-')
                {

                    neg = -1;
                    continue;
                }
                patterns[i][pn[i]] *= 10;
                patterns[i][pn[i]] += s[j] - '0';
            }
            patterns[i][pn[i]] *= neg;
            pn[i]++;
        }
                
    }

    void solve()
    {

        int max = 0;

        for (int i = 0; i < np; ++i)
        {

            int cur = val[0], pos = 0, br = 0, j = 0 ;
            int[] used = new int[10000];


            while( used[pos] == 0 ) {

                used[pos] = 1;
                pos = pos + patterns[i][j % pn[i]];
                if (pos < 0 || pos >= n) break;
                cur += val[pos];
                ++j;
            }
            if (pos >= 0 && pos < n) { if (cur - val[pos] > max) max = cur - val[pos]; }
            else if (cur > max) max = cur;
        }

        Console.Write(max);
    }




    static void Main()
    {

        Problem2 c = new Problem2();
        c.read();
        c.solve();
    }
}
