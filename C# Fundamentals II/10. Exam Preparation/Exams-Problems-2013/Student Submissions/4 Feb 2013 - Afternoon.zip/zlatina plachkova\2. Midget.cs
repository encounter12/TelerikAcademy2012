using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.Midget
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder pattern = new StringBuilder(100); //i trite patterns
            StringBuilder lenghtPattren = new StringBuilder();
            StringBuilder usedPattern = new StringBuilder();

            //string line = Console.ReadLine(); 
            string line = "1, 3, -6, 7, 4, 1, 12";
            char[] separators = new char[] { ',', '.', ' ' };
            string[] valley = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);//4islata
            //for (int i = 0; i < lineNumbers.Length; i++)
            //{
            //    Console.WriteLine(lineNumbers[i]);
            //}
            int numberPattern = int.Parse(Console.ReadLine());//3
            int tempSum = int.Parse(valley[0]);
            int firstPosition = 0;
            int coinsPosition = 0;
            int visit = 0;
            int place = 0;
            int bestSum = 0;
            bool searchCoins = true;
            int tempVisit = 0;
            int result = 0;

            for (int i = 0; i < numberPattern; i++)
            {
                line = Console.ReadLine();
                string[] readPattern = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);//vremenno sahranqva pattern

                for (int j = 0; j < readPattern.Length; j++)
                {
                    pattern.Append(readPattern[j]);
                }
                lenghtPattren.Append(readPattern.Length);
            }
            
                for (int i = 0; i < numberPattern; i++)
                {

                    int num = lenghtPattren[i] - '0';
                    while(searchCoins)
                    {
                    for (int k = 0; k < num; k++)//broq 4isla v pattern
                    {

                        coinsPosition = pattern[k] - '0';
                        if (coinsPosition > 0)
                        {
                            
                            usedPattern.Append(firstPosition);
                            
                            for (int j = 0; j < usedPattern.Length; j++)
                            {
                                place = usedPattern[j] - '0';
                                if (firstPosition+coinsPosition != place)
                                {
                                     
                                    visit = int.Parse(valley[firstPosition + coinsPosition]);
                                    if (visit == tempVisit)
                                    {
                                        break;
                                    }
                                    tempSum += visit;
                                    tempVisit = visit;
                                    
                                }
                                    
                                else
                                {
                                    result = tempSum;
                                    searchCoins = false;
                                    
                                }
                            }
                            firstPosition = firstPosition + coinsPosition;
                            
                            
                        }
                        else if (coinsPosition < 0)
                        {
                            usedPattern.Append(firstPosition);

                            for (int j = 0; j < usedPattern.Length; j++)
                            {
                                place = usedPattern[j] - '0';
                                if (firstPosition + coinsPosition != place)
                                {

                                    visit = int.Parse(valley[firstPosition + coinsPosition]);
                                    if (visit == tempVisit)
                                    {
                                        break;
                                    }
                                    tempSum += visit;
                                    tempVisit = visit;

                                }

                                else
                                {
                                    result = tempSum;
                                    searchCoins = false;
                                    
                                }
                            }
                            firstPosition = firstPosition + coinsPosition;
                        }
                        
                    }
                    result = tempSum - 1;
                    if (result > bestSum)
                    {
                        bestSum = result;
                        result = 0;
                    }
                    
                    tempSum = 0;
                    firstPosition = 0;
                    coinsPosition = 0;
                    visit = 0;
                    tempVisit = 0;
                    place = 0;
                    usedPattern.Clear();
                    
                    Console.WriteLine(bestSum);

                }
            }

        }
    }
}