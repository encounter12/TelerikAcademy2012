using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Align_Both
{
    class Program
    {
        static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());
            int lineLenght = int.Parse(Console.ReadLine());
            string[] lineContent = new string[lines];
            List<string> words = new List<string>();
            for (int i = 0; i < lines; i++)
            {
                lineContent[i] += Console.ReadLine();
                string[] wordsLine = lineContent[i].Split(' ');
                foreach (var item in wordsLine)
                {
                    if (!string.IsNullOrEmpty(item))
                    {
                        words.Add(item);
                    }
                }
            }
            StringBuilder bilder = new StringBuilder();
            int lenghtCounter = 0;
            int spaceCounter = 1;
            int numberOfWords = 0;
            while (words.Count > 0)
            {
                for (int i = 0; i < words.Count; i++)
                {
                    lenghtCounter += words[i].Length;
                    spaceCounter ++;
                    numberOfWords++;
                    if ((lenghtCounter + spaceCounter - 1) >= lineLenght)
                    {
                        if ((lenghtCounter + spaceCounter - 1) > lineLenght)
                        {
                            lenghtCounter -= words[i].Length;
                            numberOfWords--;
                        }
                        spaceCounter = lineLenght - lenghtCounter;
                        int helpCounter = spaceCounter % numberOfWords;
                        int space = 0;
                        for (int j = 0; j < numberOfWords; j++)
			            {
                            if (numberOfWords > 1)
                            {
                                if (j == 0)
                                {
                                    if (helpCounter > 0)
                                    {
                                       space = 1; 
                                    }
                                    else
	                                {
                                        space = 0;
	                                }
                                    bilder.Append(words[j]);
                                    bilder.Append(' ', (spaceCounter / (numberOfWords - 1) + space));
                                    helpCounter--;
                                }
                                else
                                {
                                    //if (j < numberOfWords - 1)
                                    //{
                                        bilder.Append(words[j]);
                                        bilder.Append(' ', spaceCounter / (numberOfWords - 1) + space);
                                        helpCounter--;
                                   // }
                                }
                            }
                            else
                            {
                                bilder.Append(words[j]);
                            }
			            }
                        for (int j = 0; j < numberOfWords; j++)
                        {
                            words.RemoveAt(0);
                        }
                        lenghtCounter = 0;
                        spaceCounter = 0;
                        spaceCounter = 1;
                        numberOfWords = 0;
                        break;
                    }                   
                    if (i == words.Count - 1)
                    {
                        spaceCounter = lineLenght - lenghtCounter;
                        int helpCounter = spaceCounter % numberOfWords;
                        int space = 0;
                        for (int j = 0; j < numberOfWords; j++)
                        {                           
                            if (numberOfWords > 1)
                            {                               
                                if (helpCounter > 0)
                                {
                                    space = 1; 
                                }
                                else
	                            {
                                    space = 0;
	                            }
                                if (j == 0)
                                {
                                    bilder.Append(words[j]);
                                    bilder.Append(' ', (spaceCounter / (numberOfWords - 1) + space));
                                }
                                else
                                {
                                   // if (j <= numberOfWords - 1)
                                   // {
                                        bilder.Append(words[j]);
                                        bilder.Append(' ', spaceCounter / (numberOfWords - 1) + space
);
                                   //a }
                                }
                            }
                            else
                            {
                                bilder.Append(words[j]);
                            }
                        }
                        for (int p = 0; p < numberOfWords; p++)
                        {
                            words.RemoveAt(0);
                        }
                        break;
                    }
                }
                Console.WriteLine(bilder.ToString());
                bilder.Clear();
            }              
             
        }
    }
}
