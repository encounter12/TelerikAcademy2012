using System;
using System.Collections.Generic;
using System.Text;
 
class Base10ToBase16
{
    static void Main()
    {
 
        ulong nDec = ulong.Parse(Console.ReadLine());
        if (nDec==0)
        {
            Console.Write("A");
        }
        List<ulong> converted = ConverFromBase10ToBase256(nDec);
        Console.WriteLine(ConvertNumToLetter(converted));
 
    }
    static List<ulong> ConverFromBase10ToBase256(ulong nDec)
    {
        List<ulong> hexList = new List<ulong>();
        ulong res = 0;
 
        while (nDec > 0)
        {
            res = nDec / 256;
            hexList.Add(nDec % 256);
            nDec = res;
        }
        hexList.Reverse();
        return hexList;
    }
    static string ConvertNumToLetter(List<ulong> converted)
    {
        StringBuilder base26OnlyLetters = new StringBuilder();
 
        foreach (var num in converted)
        {
            switch (num)
            {
                case 0: base26OnlyLetters.Append("A"); break;
                case 1: base26OnlyLetters.Append("B"); break;
                case 2: base26OnlyLetters.Append("C"); break;
                case 3: base26OnlyLetters.Append("D"); break;
                case 4: base26OnlyLetters.Append("E"); break;
                case 5: base26OnlyLetters.Append("F"); break;
                case 6: base26OnlyLetters.Append("G"); break;
                case 7: base26OnlyLetters.Append("H"); break;
                case 8: base26OnlyLetters.Append("I"); break;
                case 9: base26OnlyLetters.Append("J"); break;
                case 10: base26OnlyLetters.Append("K"); break;
                case 11: base26OnlyLetters.Append("L"); break;
                case 12: base26OnlyLetters.Append("M"); break;
                case 13: base26OnlyLetters.Append("N"); break;
                case 14: base26OnlyLetters.Append("O"); break;
                case 15: base26OnlyLetters.Append("P"); break;
                case 16: base26OnlyLetters.Append("Q"); break;
                case 17: base26OnlyLetters.Append("R"); break;
                case 18: base26OnlyLetters.Append("S"); break;
                case 19: base26OnlyLetters.Append("T"); break;
                case 20: base26OnlyLetters.Append("U"); break;
                case 21: base26OnlyLetters.Append("V"); break;
                case 22: base26OnlyLetters.Append("W"); break;
                case 23: base26OnlyLetters.Append("X"); break;
                case 24: base26OnlyLetters.Append("Y"); break;
                case 25: base26OnlyLetters.Append("Z"); break;
 
                case 26: base26OnlyLetters.Append("aA"); break;
                case 27: base26OnlyLetters.Append("aB"); break;
                case 28: base26OnlyLetters.Append("aC"); break;
                case 29: base26OnlyLetters.Append("aD"); break;
                case 30: base26OnlyLetters.Append("aE"); break;
                case 31: base26OnlyLetters.Append("aF"); break;
                case 32: base26OnlyLetters.Append("aG"); break;
                case 33: base26OnlyLetters.Append("aH"); break;
                case 34: base26OnlyLetters.Append("aI"); break;
                case 35: base26OnlyLetters.Append("aJ"); break;
                case 36: base26OnlyLetters.Append("aK"); break;
                case 37: base26OnlyLetters.Append("aL"); break;
                case 38: base26OnlyLetters.Append("aM"); break;
                case 39: base26OnlyLetters.Append("aN"); break;
                case 40: base26OnlyLetters.Append("aO"); break;
                case 41: base26OnlyLetters.Append("aP"); break;
                case 42: base26OnlyLetters.Append("aQ"); break;
                case 43: base26OnlyLetters.Append("aR"); break;
                case 44: base26OnlyLetters.Append("aS"); break;
                case 45: base26OnlyLetters.Append("aT"); break;
                case 46: base26OnlyLetters.Append("aU"); break;
                case 47: base26OnlyLetters.Append("aV"); break;
                case 48: base26OnlyLetters.Append("aW"); break;
                case 49: base26OnlyLetters.Append("aX"); break;
                case 50: base26OnlyLetters.Append("aY"); break;
                case 51: base26OnlyLetters.Append("aZ"); break;
 
                case 52: base26OnlyLetters.Append("bA"); break;
                case 53: base26OnlyLetters.Append("bB"); break;
                case 54: base26OnlyLetters.Append("bC"); break;
                case 55: base26OnlyLetters.Append("bD"); break;
                case 56: base26OnlyLetters.Append("bE"); break;
                case 57: base26OnlyLetters.Append("bF"); break;
                case 58: base26OnlyLetters.Append("bG"); break;
                case 59: base26OnlyLetters.Append("bH"); break;
                case 60: base26OnlyLetters.Append("bI"); break;
                case 61: base26OnlyLetters.Append("bJ"); break;
                case 62: base26OnlyLetters.Append("bK"); break;
                case 63: base26OnlyLetters.Append("bL"); break;
                case 64: base26OnlyLetters.Append("bM"); break;
                case 65: base26OnlyLetters.Append("bN"); break;
                case 66: base26OnlyLetters.Append("bO"); break;
                case 67: base26OnlyLetters.Append("bP"); break;
                case 68: base26OnlyLetters.Append("bQ"); break;
                case 69: base26OnlyLetters.Append("bR"); break;
                case 70: base26OnlyLetters.Append("bS"); break;
                case 71: base26OnlyLetters.Append("bT"); break;
                case 72: base26OnlyLetters.Append("bU"); break;
                case 73: base26OnlyLetters.Append("bV"); break;
                case 74: base26OnlyLetters.Append("bW"); break;
                case 75: base26OnlyLetters.Append("bX"); break;
                case 76: base26OnlyLetters.Append("bY"); break;
                case 77: base26OnlyLetters.Append("bZ"); break;
 
                case 78: base26OnlyLetters.Append("cA"); break;
                case 79: base26OnlyLetters.Append("cB"); break;
                case 80: base26OnlyLetters.Append("cC"); break;
                case 81: base26OnlyLetters.Append("cD"); break;
                case 82: base26OnlyLetters.Append("cE"); break;
                case 83: base26OnlyLetters.Append("cF"); break;
                case 84: base26OnlyLetters.Append("cG"); break;
                case 85: base26OnlyLetters.Append("cH"); break;
                case 86: base26OnlyLetters.Append("cI"); break;
                case 87: base26OnlyLetters.Append("cJ"); break;
                case 88: base26OnlyLetters.Append("cK"); break;
                case 89: base26OnlyLetters.Append("cL"); break;
                case 90: base26OnlyLetters.Append("cM"); break;
                case 91: base26OnlyLetters.Append("cN"); break;
                case 92: base26OnlyLetters.Append("cO"); break;
                case 93: base26OnlyLetters.Append("cP"); break;
                case 94: base26OnlyLetters.Append("cQ"); break;
                case 95: base26OnlyLetters.Append("cR"); break;
                case 96: base26OnlyLetters.Append("cS"); break;
                case 97: base26OnlyLetters.Append("cT"); break;
                case 98: base26OnlyLetters.Append("cU"); break;
                case 99: base26OnlyLetters.Append("cV"); break;
                case 100: base26OnlyLetters.Append("cW"); break;
                case 101: base26OnlyLetters.Append("cX"); break;
                case 102: base26OnlyLetters.Append("cY"); break;
                case 103: base26OnlyLetters.Append("cZ"); break;
 
                case 104: base26OnlyLetters.Append("dA"); break;
                case 105: base26OnlyLetters.Append("dB"); break;
                case 106: base26OnlyLetters.Append("dC"); break;
                case 107: base26OnlyLetters.Append("dD"); break;
                case 108: base26OnlyLetters.Append("dE"); break;
                case 109: base26OnlyLetters.Append("dF"); break;
                case 110: base26OnlyLetters.Append("dG"); break;
                case 111: base26OnlyLetters.Append("dH"); break;
                case 112: base26OnlyLetters.Append("dI"); break;
                case 113: base26OnlyLetters.Append("dJ"); break;
                case 114: base26OnlyLetters.Append("dK"); break;
                case 115: base26OnlyLetters.Append("dL"); break;
                case 116: base26OnlyLetters.Append("dM"); break;
                case 117: base26OnlyLetters.Append("dN"); break;
                case 118: base26OnlyLetters.Append("dO"); break;
                case 119: base26OnlyLetters.Append("dP"); break;
                case 120: base26OnlyLetters.Append("dQ"); break;
                case 121: base26OnlyLetters.Append("dR"); break;
                case 122: base26OnlyLetters.Append("dS"); break;
                case 123: base26OnlyLetters.Append("dT"); break;
                case 124: base26OnlyLetters.Append("dU"); break;
                case 125: base26OnlyLetters.Append("dV"); break;
                case 126: base26OnlyLetters.Append("dW"); break;
                case 127: base26OnlyLetters.Append("dX"); break;
                case 128: base26OnlyLetters.Append("dY"); break;
                case 129: base26OnlyLetters.Append("dZ"); break;
 
                case 130: base26OnlyLetters.Append("eA"); break;
                case 131: base26OnlyLetters.Append("eB"); break;
                case 132: base26OnlyLetters.Append("eC"); break;
                case 133: base26OnlyLetters.Append("eD"); break;
                case 134: base26OnlyLetters.Append("eE"); break;
                case 135: base26OnlyLetters.Append("eF"); break;
                case 136: base26OnlyLetters.Append("eG"); break;
                case 137: base26OnlyLetters.Append("eH"); break;
                case 138: base26OnlyLetters.Append("eI"); break;
                case 139: base26OnlyLetters.Append("eJ"); break;
                case 140: base26OnlyLetters.Append("eK"); break;
                case 141: base26OnlyLetters.Append("eL"); break;
                case 142: base26OnlyLetters.Append("eM"); break;
                case 143: base26OnlyLetters.Append("eN"); break;
                case 144: base26OnlyLetters.Append("eO"); break;
                case 145: base26OnlyLetters.Append("eP"); break;
                case 146: base26OnlyLetters.Append("eQ"); break;
                case 147: base26OnlyLetters.Append("eR"); break;
                case 148: base26OnlyLetters.Append("eS"); break;
                case 149: base26OnlyLetters.Append("eT"); break;
                case 150: base26OnlyLetters.Append("eU"); break;
                case 151: base26OnlyLetters.Append("eV"); break;
                case 152: base26OnlyLetters.Append("eW"); break;
                case 153: base26OnlyLetters.Append("eX"); break;
                case 154: base26OnlyLetters.Append("eY"); break;
                case 155: base26OnlyLetters.Append("eZ"); break;
 
                case 156: base26OnlyLetters.Append("fA"); break;
                case 157: base26OnlyLetters.Append("fB"); break;
                case 158: base26OnlyLetters.Append("fC"); break;
                case 159: base26OnlyLetters.Append("fD"); break;
                case 160: base26OnlyLetters.Append("fE"); break;
                case 161: base26OnlyLetters.Append("fF"); break;
                case 162: base26OnlyLetters.Append("fG"); break;
                case 163: base26OnlyLetters.Append("fH"); break;
                case 164: base26OnlyLetters.Append("fI"); break;
                case 165: base26OnlyLetters.Append("fJ"); break;
                case 166: base26OnlyLetters.Append("fK"); break;
                case 167: base26OnlyLetters.Append("fL"); break;
                case 168: base26OnlyLetters.Append("fM"); break;
                case 169: base26OnlyLetters.Append("fN"); break;
                case 170: base26OnlyLetters.Append("fO"); break;
                case 171: base26OnlyLetters.Append("fP"); break;
                case 172: base26OnlyLetters.Append("fQ"); break;
                case 173: base26OnlyLetters.Append("fR"); break;
                case 174: base26OnlyLetters.Append("fS"); break;
                case 175: base26OnlyLetters.Append("fT"); break;
                case 176: base26OnlyLetters.Append("fU"); break;
                case 177: base26OnlyLetters.Append("fV"); break;
                case 178: base26OnlyLetters.Append("fW"); break;
                case 179: base26OnlyLetters.Append("fX"); break;
                case 180: base26OnlyLetters.Append("fY"); break;
                case 181: base26OnlyLetters.Append("fZ"); break;
 
                case 182: base26OnlyLetters.Append("gA"); break;
                case 183: base26OnlyLetters.Append("gB"); break;
                case 184: base26OnlyLetters.Append("gC"); break;
                case 185: base26OnlyLetters.Append("gD"); break;
                case 186: base26OnlyLetters.Append("gE"); break;
                case 187: base26OnlyLetters.Append("gF"); break;
                case 188: base26OnlyLetters.Append("gG"); break;
                case 189: base26OnlyLetters.Append("gH"); break;
                case 190: base26OnlyLetters.Append("gI"); break;
                case 191: base26OnlyLetters.Append("gJ"); break;
                case 192: base26OnlyLetters.Append("gK"); break;
                case 193: base26OnlyLetters.Append("gL"); break;
                case 194: base26OnlyLetters.Append("gM"); break;
                case 195: base26OnlyLetters.Append("gN"); break;
                case 196: base26OnlyLetters.Append("gO"); break;
                case 197: base26OnlyLetters.Append("gP"); break;
                case 198: base26OnlyLetters.Append("gQ"); break;
                case 199: base26OnlyLetters.Append("gR"); break;
                case 200: base26OnlyLetters.Append("gS"); break;
                case 201: base26OnlyLetters.Append("gT"); break;
                case 202: base26OnlyLetters.Append("gU"); break;
                case 203: base26OnlyLetters.Append("gV"); break;
                case 204: base26OnlyLetters.Append("gW"); break;
                case 205: base26OnlyLetters.Append("gX"); break;
                case 206: base26OnlyLetters.Append("gY"); break;
                case 207: base26OnlyLetters.Append("gZ"); break;
 
                case 208: base26OnlyLetters.Append("hA"); break;
                case 209: base26OnlyLetters.Append("hB"); break;
                case 210: base26OnlyLetters.Append("hC"); break;
                case 211: base26OnlyLetters.Append("hD"); break;
                case 212: base26OnlyLetters.Append("hE"); break;
                case 213: base26OnlyLetters.Append("hF"); break;
                case 214: base26OnlyLetters.Append("hG"); break;
                case 215: base26OnlyLetters.Append("hH"); break;
                case 216: base26OnlyLetters.Append("hI"); break;
                case 217: base26OnlyLetters.Append("hJ"); break;
                case 218: base26OnlyLetters.Append("hK"); break;
                case 219: base26OnlyLetters.Append("hL"); break;
                case 220: base26OnlyLetters.Append("hM"); break;
                case 221: base26OnlyLetters.Append("hN"); break;
                case 222: base26OnlyLetters.Append("hO"); break;
                case 223: base26OnlyLetters.Append("hP"); break;
                case 224: base26OnlyLetters.Append("hQ"); break;
                case 225: base26OnlyLetters.Append("hR"); break;
                case 226: base26OnlyLetters.Append("hS"); break;
                case 227: base26OnlyLetters.Append("hT"); break;
                case 228: base26OnlyLetters.Append("hU"); break;
                case 229: base26OnlyLetters.Append("hV"); break;
                case 230: base26OnlyLetters.Append("hW"); break;
                case 231: base26OnlyLetters.Append("hX"); break;
                case 232: base26OnlyLetters.Append("hY"); break;
                case 233: base26OnlyLetters.Append("hZ"); break;
 
                case 234: base26OnlyLetters.Append("iA"); break;
                case 235: base26OnlyLetters.Append("iB"); break;
                case 236: base26OnlyLetters.Append("iC"); break;
                case 237: base26OnlyLetters.Append("iD"); break;
                case 238: base26OnlyLetters.Append("iE"); break;
                case 239: base26OnlyLetters.Append("iF"); break;
                case 240: base26OnlyLetters.Append("iG"); break;
                case 241: base26OnlyLetters.Append("iH"); break;
                case 242: base26OnlyLetters.Append("iI"); break;
                case 243: base26OnlyLetters.Append("iJ"); break;
                case 244: base26OnlyLetters.Append("iK"); break;
                case 245: base26OnlyLetters.Append("iL"); break;
                case 246: base26OnlyLetters.Append("iM"); break;
                case 247: base26OnlyLetters.Append("iN"); break;
                case 248: base26OnlyLetters.Append("iO"); break;
                case 249: base26OnlyLetters.Append("iP"); break;
                case 250: base26OnlyLetters.Append("iQ"); break;
                case 251: base26OnlyLetters.Append("iR"); break;
                case 252: base26OnlyLetters.Append("iS"); break;
                case 253: base26OnlyLetters.Append("iT"); break;
                case 254: base26OnlyLetters.Append("iU"); break;
                case 255: base26OnlyLetters.Append("iV"); break;
            }                                      
        }                                          
        return base26OnlyLetters.ToString();       
    }                                              
}