using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace twoinone
{
    class Program
    {
        static void Main(string[] args)
        {
            int numlamps = int.Parse(Console.ReadLine());
            //int[] lamps = new int[numlamps];
            //for (int i = 0; i < lamps.Length; i++)
            //{
            //    lamps[i] = i+1;
            //}

            //for (int k = 2; k < lamps.Length/2; k++)
            //{
            
            //    for (int j = 0; j < lamps.Length; j += k)
            //    {
                    
            //        if (lamps[j] != 0)
            //        {
            //            lamps[j] = 0;
            //        }
            //    }
            //}

            List<int> lampi = new List<int>();
            for (int i = 0; i < numlamps; i++)
            {
                lampi.Add(i+1);
            }
            int last = 0;
            int k = 2;
            //for (int k = 2; k < lampi.Count; k++)
            //{

                for (int j = 0; j < lampi.Count; j += k)
                {

                    if (lampi.Count>1)
                    {
                        lampi.Remove(j);
                    }
                    else
                    {
                        last = lampi[0];
                    }
                    if (lampi.Count>1 && j==lampi.Count)
                    {
                        j = 0;
                        k++;
                    }
                }
            //}

            Console.WriteLine(last);
        }
    }
}
