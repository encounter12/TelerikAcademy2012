using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Provadia
{
    class Program
    {
        static void Main()
        {
            string str = Console.ReadLine();
            int lastdigit = int.Parse(str[str.Length-1].ToString());

            string[] nums = new string[257];
            int z = 0;
            for (int j = 65; j <= 90; j++)
            {
                nums[z] = ((char)j).ToString();
                //Console.WriteLine(nums);
                z++;
            }

            for (int i = 65, a = 0; i <= 90; i++, a++)
            {
                nums[z] = "a" + (char)i;
                z++;
            }
            for (int i = 65, a = 0; i <= 90; i++, a++)
            {
                nums[z] = "b" + (char)i;
                z++;
            }
            for (int i = 65, a = 0; i <= 90; i++, a++)
            {
                nums[z] = "c" + (char)i;
                z++;
            }
            for (int i = 65, a = 0; i <= 90; i++, a++)
            {
                nums[z] = "d" + (char)i;
                z++;
            }
            for (int i = 65, a = 0; i <= 90; i++, a++)
            {
                nums[z] = "e" + (char)i;
                z++;
            }
            for (int i = 65, a = 0; i <= 90; i++, a++)
            {
                nums[z] = "f" + (char)i;
                
                z++;
            }
            for (int i = 65, a = 0; i <= 90; i++, a++)
            {
                nums[z] = "g" + (char)i;
                
                z++;
            }
            for (int i = 65, a = 0; i <= 90; i++, a++)
            {
                nums[z] = "h" + (char)i;
                
                z++;
            }
            for (int i = 65, a = 0; i <= 86; i++, a++)
            {
                nums[z] = "i" + (char)i;
                
                z++;
            }

            int wholenumber = int.Parse(str.ToString());
            string res = null;

            //for (int i = 0; i < nums.Length-1; i++)
            //{
            //    Console.WriteLine("{0} : {1}", i, nums[i]);
            //};
            if (wholenumber < 255)
            {
                res = nums[wholenumber];
            }
            else
            {
                res = nums[wholenumber];
            }
            Console.WriteLine(res);
        }
    }
}
