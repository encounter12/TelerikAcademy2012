using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AlignBoth
{
    class AlignBoth
    {
        static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());
            int lineLength = int.Parse(Console.ReadLine());
            StringBuilder text = new StringBuilder();
            StringBuilder result = new StringBuilder();

            for (int i = 0; i < lines; i++)
                text.Append(Console.ReadLine() + " ");

            string editedText = Regex.Replace(text.ToString(), @"\W+", " ");
            text.Clear();

            while (true)
            {
                if (editedText.Length < lineLength) lineLength = editedText.Length - 1;
                int index = editedText.LastIndexOf(' ', lineLength);
                if (index < 0) break;
                string line = editedText.Substring(0, index);
                string[] words = line.Split(' ');
                int difference = lineLength - line.Length;
                int rest = 0;
                if (words.Length != 1)
                {
                    rest = difference % (words.Length - 1);
                    difference /= words.Length - 1;
                }
                if (rest > 0) difference += 1;
                for (int r = 0; r < words.Length; r++)
                {
                    text.Append(words[r]);
                    for (int t = 0; t < difference + 1; t++)
                    {
                        text.Append(' ');
                    }
                    if (r == rest - 1 && rest > 0) difference -= 1;
                }

                result.AppendLine(text.ToString().Trim());
                text.Clear();
                
                editedText = editedText.Substring(index + 1);
            }

            Console.WriteLine(result);
        }
    }
}
