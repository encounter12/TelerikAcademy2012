using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProvadiaNumbers
{
    class Program
    {
        static void ConvertToProvadia(ulong num, string[] provadiaNum)
        {
            List<string> provadia = new List<string>();
            string digit = "";
            if (num == 0)
            {
                Console.WriteLine(provadiaNum[0]);
            }
            else
            {

                while (num > 0)
                {
                    int mod = (int)(num % 256);
                    digit = provadiaNum[mod];
                    provadia.Add(digit);
                    num /= 256;
                }
                provadia.Reverse();
                string provadiaString = string.Join("", provadia);
                Console.WriteLine(provadiaString);
            }
        }


        static void Main(string[] args)
        {
            ulong number = ulong.Parse(Console.ReadLine());
            string[] provadiaNumbers = new string[256];
            for (int i = 0; i < 26; i++)
            {
                provadiaNumbers[i] = ((char)(65 + i)).ToString();                
            }
            int index = 26;
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 26; j++, index++)
                {
                    if (index == provadiaNumbers.Length)
                    {
                        break;
                    }
                    provadiaNumbers[index] = ((char)(97 + i)).ToString() + ((char)(65 + j)).ToString();
                }          
            }
            ConvertToProvadia(number, provadiaNumbers);  
        }
    }
}
