using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
  
namespace _01.Provadia_Numbers
{
    class Program
    {
        static void Main(string[] 

args)
        {
            int num = int.Parse

(Console.ReadLine());
            string str = "";
  
            int count = 0;
  
             
                if (num < 26)
                {
                    str += 

ReturnDigit(num, 0);
                }
                else
                {
                    int brum = num / 

26;
                    int temp = num - 

(brum * 26);
                    str += 

ReturnDigit(brum, 1);
                    str += 

ReturnDigit(temp, 0);
                }
             
            Console.WriteLine(str);
        }
  
        static string ReturnDigit

(int num, int count)
        {
            string brum = "";
              
            string[] lettersUP = new 

string[26];
            for (int i = 0; i < 26; 

i++)
            {
                lettersUP[i] = 

((char)(i + 65)).ToString();
            }
            string[] lettersLow = 

new string[26];
            for (int i = 0; i < 26; 

i++)
            {
                lettersLow[i] = 

((char)(i + 96)).ToString();
            }
  
            if (count == 0)
            {
                brum = lettersUP

[num];
            }
            else
            {
                brum = lettersLow

[num];
            }
            return brum;
        }
    }
}