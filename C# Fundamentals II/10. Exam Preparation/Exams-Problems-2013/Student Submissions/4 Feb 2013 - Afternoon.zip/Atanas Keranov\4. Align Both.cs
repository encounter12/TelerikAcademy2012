using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlignBoth
{
    class Program
    {
        static void Main(string[] args)
        {
            int linesCount = int.Parse(Console.ReadLine());
            int lineMaxLength = int.Parse(Console.ReadLine());
            string[][] lines = new string[linesCount][];
            char[] delimiters = { ' ' };
            List<StringBuilder> output = new List<StringBuilder>(linesCount);
            int outputLineCounter = 0;
            int lineCurrentLength = 0;
            string tempString;
            int indexOfWhiteSpace;

            for (int i = 0; i < linesCount; i++)
            {
                lines[i] = Console.ReadLine().Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
            }

            //for (int i = 0; i < linesCount; i++)
            //{
            //    for (int j = 0; j < lines[i].Length; j++)
            //    {
            //        Console.WriteLine(lines[i][j]);   
            //    }
            //}

            output.Add(new StringBuilder(lineMaxLength + 1));

            for (int line = 0; line < lines.Length; line++)
            {
                for (int word = 0; word < lines[line].Length; word++)
                {
                    lineCurrentLength += lines[line][word].Length;

                    if (lineCurrentLength <= lineMaxLength)
                    {
                        output[outputLineCounter].Append(lines[line][word]);

                        if (lineCurrentLength < lineMaxLength)
                        {
                            output[outputLineCounter].Append(" ");
                            lineCurrentLength++;
                        }
                    }
                    else
                    {
                        outputLineCounter++;
                        output.Add(new StringBuilder(lineMaxLength + 1));
                        lineCurrentLength = lines[line][word].Length + 1;
                        output[outputLineCounter].Append(lines[line][word]);
                        output[outputLineCounter].Append(" ");
                    }
                }
            }

            for (int i = 0; i < output.Count; i++)
            {
                tempString = output[i].ToString().TrimEnd();
                output[i].Clear();
                output[i].Append(tempString);
            }

            for (int i = 0; i < output.Count; i++)
            {
                if (output[i].ToString().Split(delimiters, StringSplitOptions.RemoveEmptyEntries).Length == 1)
                {
                    if (output[i][output[i].Length - 1] == ' ')
                    {
                        output[i].Remove((output[i].Length - 1), 1);
                    }
                }
                else
                {
                    while (output[i].Length < lineMaxLength)
                    {
                        for (int j = 0; j < output[i].Length; j++)
                        {
                            if (output[i][j] == ' ')
                            {
                                output[i].Insert(j, ' ');
                                j++;
                            }
                            if (output[i].Length == lineMaxLength)
                            {
                                break;
                            }
                        }
                    }
                }
            }

            foreach (StringBuilder sb in output)
            {
                Console.WriteLine(sb.ToString());
            }
        }
    }
}
