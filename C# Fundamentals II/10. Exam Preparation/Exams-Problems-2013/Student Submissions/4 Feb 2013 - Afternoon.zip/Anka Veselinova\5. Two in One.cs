using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class TwoInOne
{
    static void Main()
    {
        uint lampsNumber = uint.Parse(Console.ReadLine());
        //string firstCommand = Console.ReadLine();
        //string secondCommand = Console.ReadLine();

        bool[] lampsCondition = new bool[lampsNumber];
        List<uint> Order = new List<uint>();
        uint step = 2;
        for (uint i = 0; i < lampsNumber; i = i + 2)
        {
            lampsCondition[i] = true;
            Order.Add(i);
        }

        for (uint i = 1; i < lampsNumber; i = i + 2)
        {
            if (lampsCondition[i] == false)
            {
                step++;
                LightLamps(i, step, lampsNumber, lampsCondition, Order);
            }
        }

        Console.WriteLine(Order[Order.Count - 1] + 1);

        //for (int i = 1; i < 2500; i++)
        //{

        //}

    }

    private static void LightLamps(uint i, uint step, uint lampsNumber, bool[] lampsCondition, List<uint> Order)
    {
        uint counter = step;
        lampsCondition[i] = true;
        Order.Add(i);

        for (uint j = i + 1; j < lampsNumber; j++)
        {
            if (lampsCondition[j] == true)
            {
                continue;
            }
            else
            {
                counter--;
                if (counter == 0)
                {
                    lampsCondition[j] = true;
                    Order.Add(j);
                }
            }
        }
    }


}