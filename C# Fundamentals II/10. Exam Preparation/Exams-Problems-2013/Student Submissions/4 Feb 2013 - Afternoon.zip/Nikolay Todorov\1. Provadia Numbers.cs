using System;
using System.Numerics;
class ProvadiaNumbers
{
    static void Main()
    {
        int columnNumber = int.Parse(Console.ReadLine());
       
            int dividend = columnNumber + 1;
            string columnName = String.Empty;
            int modulo;

            while (dividend > 0)
            {
                modulo = (dividend - 1) % 26;
                if (columnNumber > 25)
                {
                    columnName = Convert.ToChar(65 + modulo).ToString().ToLower() + columnName.ToUpper();
                    dividend = (int)((dividend - modulo) / 26);
                }
                else if (columnNumber < 25)
                {
                    columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
                    dividend = (int)((dividend - modulo) / 26);
                }
            }
            Console.WriteLine(columnName);
        }

}
