using System;


class Midget
{
    static int[] InputValleyOrPattern() 
    {
        char[] separators = new char[] { ' ', ',' };
        string[] valleyasstr = (Console.ReadLine().Split(separators, StringSplitOptions.RemoveEmptyEntries));
        int[] valley = new int[valleyasstr.Length];
        for (int i = 0; i < valleyasstr.Length; i++)
        {
            valley[i] = int.Parse(valleyasstr[i]);
        }
        return valley;
    }

    static int CheckPattern(int[] valley, int[] pattern)
    {
        int i=0;
        int max = 0;
        bool flag = false;
        int sum=valley[i];
        bool[] visited = new bool[valley.Length];
        visited[i] = true;
        while (true)
        {
            foreach (var step in pattern)
            {
                if (i + step < 0 || i + step >= valley.Length)
                {
                    flag = true;
                    break;
                }
                if (visited[i + step] == true)
                {
                    flag = true;
                    break;
                }
                sum += valley[i + step];
                visited[i + step] = true;
                i = i + step;
            }
            if (flag == true) break;
        }
        max = sum;
        return max;
    }

    static void Main()
    {        
        int[] valley = InputValleyOrPattern();
        int m = int.Parse(Console.ReadLine());
        int max = 0;
        for (int i = 0; i < m; i++)
        {
            int[] pattern = InputValleyOrPattern();
            int currentmax = CheckPattern(valley, pattern);
            if (currentmax > max) max = currentmax;
        }
        Console.WriteLine(max);
    }
}
