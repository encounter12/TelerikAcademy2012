using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zad2
{
    class Program
    {
        static int CollectCoins(List<int> valley, List<int> pattern)
        {
            int sizeValley = valley.Count;
                int index = 0;
                int coins=valley[0];
                 
                while (valley[index] != 1001 && index > -1 && index < sizeValley) 
                {
                    
                    for (int i = 0; i < pattern.Count; i++)
                    {
                        
                        index = index + pattern[i];
                        if (valley[index] != 1001 && index > -1 && index < sizeValley)
                        {
                            coins += valley[index];
                            valley[index] = 1001;
                            
                        }
                        else
                        {
                            break;
                        }
                    }
                    
                } 
                return coins;
            
        }
        static List<int> ParseStringToListOfIntegers(string str)
        {
             
            string[] split = str.Split(' ', ',');
            List<int> listOfIntegers = new List<int>();
            for (int i = 0; i < split.Length; i++)
            {
                int s = 0;
                bool parse = int.TryParse(split[i].ToString(), out s);
                if (parse) listOfIntegers.Add(s);
            }
            return listOfIntegers;
        }
        static void Main(string[] args)
        {
            string valleyAsString = Console.ReadLine().Trim();
            short m =short.Parse(Console.ReadLine());
            List<int> valley = ParseStringToListOfIntegers(valleyAsString);
            string[] patternAsString = new string[m];
            for (int i = 0; i < patternAsString.Length; i++)
            {
                patternAsString[i] = Console.ReadLine();
            }


            int maxCoins = 0;
            int coinsCollected = 0;
           
          for (int i = 0; i < patternAsString.Length; i++)
           {
             List<int> pattern = ParseStringToListOfIntegers(patternAsString[i]);
             int coins= CollectCoins(valley, pattern);
             coinsCollected = coins;
             
             if (coinsCollected > maxCoins)
             {
                 maxCoins = coinsCollected;
                 coinsCollected = 0;
             }
             else
             {
                 coinsCollected = 0;
             }
           }
         
          Console.WriteLine(maxCoins);
          

        }
    }
}
