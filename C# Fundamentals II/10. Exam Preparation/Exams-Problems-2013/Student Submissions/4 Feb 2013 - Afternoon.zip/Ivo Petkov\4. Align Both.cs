using System;
using System.Text;
using System.Text.RegularExpressions;

class AlignBoth
{
    static void Main()
    {
        int lines = int.Parse(Console.ReadLine());
        int width = int.Parse(Console.ReadLine());
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < lines; i++)
        {
            text.Append(Console.ReadLine());
            if (i != lines - 1)
            {
                text.Append(' ');
            }
        }
        Regex separators = new Regex(@"\s+");
        string[] words = separators.Split(text.ToString());
        char[] separator = { ' ' };

        StringBuilder line = new StringBuilder();
        int left = width;
        for (int i = 0; i < words.Length; i++)
        {
            if (words[i].Length >= width)
            {
                line.Append(words[i]);
                Console.WriteLine(line.ToString());
                line.Clear();
                if (i != words.Length - 1)
                {
                    continue;
                }
            }
            if (words[i].Length < left)
            {
                line.Append(words[i]);
                if (words[i].Length != left)
                {
                    line.Append(" ");
                }
                left = width - line.Length;
                if (i != words.Length - 1)
                {
                    continue;
                }
            }
            if (words[i].Length >= left)
            {              
                string temp = line.ToString().Trim();
                line.Clear();                
                int add = width - temp.Length;
                int spaceCount = 0; ;
                foreach (char item in temp)
                {
                    if (item == ' ')
                    {
                        spaceCount++;
                    }
                }
                if (spaceCount != 0)
                {
                    StringBuilder[] toAdd = new StringBuilder[spaceCount];
                    for (int z = 0; z < toAdd.Length; z++)
                    {
                        toAdd[z] = new StringBuilder();
                        toAdd[z].Append(" ");
                    }
                    int k = 0;

                    for (int j = 0; j < add; j++)
                    {

                        toAdd[k].Append(" ");
                        k++;
                        if (k == toAdd.Length)
                        {
                            k = 0;
                        }
                    }

                    string[] wordsInLine = temp.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                    for (int l = 0; l < wordsInLine.Length; l++)
                    {
                        line.Append(wordsInLine[l]);
                        if (l != wordsInLine.Length - 1)
                        {
                            line.Append(toAdd[l]);
                        }
                    }
                }
                if (spaceCount == 0)
                {
                    line.Append(words[i].Trim());
                }
                string print = line.ToString().Trim();
                Console.WriteLine(line.ToString().Trim());
                line.Clear();
                left = width;
                if (i != words.Length)
                {
                   i--; 
                }
                
            }
        }

    }
}