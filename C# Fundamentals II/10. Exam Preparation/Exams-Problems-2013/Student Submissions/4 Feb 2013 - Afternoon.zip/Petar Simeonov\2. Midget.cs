using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Exercise1
{
    static void Main()
    {
        string valley = Console.ReadLine();
        string[] coins = valley.Split(',');
        for (int i = 0; i < coins.Length; i++)
        {
            coins[i] = coins[i].Trim();
        }
        int numberOfPatterns = int.Parse(Console.ReadLine());

        int[] tempSum = new int[numberOfPatterns];
        for (int i = 0; i < numberOfPatterns; i++)
        {
            tempSum[i] = int.Parse(coins[0]);
        }

        int index = 0, oldIndex = 0, count = 0;
        int[] visitedIndexes = new int[1000];
        bool isVisited = false;
        int maxSum = 0;
        for (int l = 0; l < numberOfPatterns; l++)
        {
            string patternStr = Console.ReadLine();
            patternStr = patternStr.Trim();
            string[] patterns = patternStr.Split(',');
            index = 0;
            tempSum[l] = 0;
            int k = 0;
            while (true)
            {
                
                    index = int.Parse(patterns[k]) + oldIndex;
                    visitedIndexes[count] = index;
                    count++;
                    for (int b = 0; b < visitedIndexes[b]; b++)
                    {
                        if (index == visitedIndexes[b])
                        {
                            break;
                        }
                    }
                    tempSum[l] = tempSum[l] + int.Parse(coins[index]);
                    oldIndex = index;
                    if (tempSum[l] > maxSum)
                    {
                        maxSum = tempSum[l];
                    }
                    if (index == 0)
                    {
                        break;
                    }
                    if (index > coins.Length)
                    {
                        break;
                    }
                    k++;
                
            }
        }
        Console.WriteLine(maxSum);
        Console.WriteLine(isVisited);

    }
}