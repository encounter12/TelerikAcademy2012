using System;
using System.Text;

class Program
{
    static int width;
    static int height;
    static int depth;
    static string[, ,] cube;
    static int wid;
    static int hei;
    static int dep;
    static bool isOver = false;

    static void Main()
    {
        string dimensions = Console.ReadLine();
        string[] dimspl = dimensions.Split(' ');
        width = int.Parse(dimspl[0]);
        height = int.Parse(dimspl[1]);
        depth = int.Parse(dimspl[2]);
        cube = new string[width, height, depth];
        FillCube();
        string ballCord = Console.ReadLine();
        string[] bc = ballCord.Split(' ');
        int w = int.Parse(bc[0]);
        int d = int.Parse(bc[1]);
        DropBall(w, d);
        if (isOver)
        {
            Console.WriteLine("No");
        }
        else
        {
            Console.WriteLine("Yes");
        }
        Console.WriteLine(wid + " " + (hei >= height?hei=height-1:hei) + " " + dep);
        //PrintCube();
    }

    private static void DropBall(int bw, int bd)
    {
        wid = bw;
        dep = bd;
        hei = 0;
        StringBuilder cmd = new StringBuilder();
        while (hei < height)
        {
            cmd.Append(cube[wid, hei, dep]);
            switch (cmd[0])
            {
                case 'E':
                    hei++;
                    break;
                case 'S':
                    Slide(cube[wid, hei, dep]);
                    if (isOver)
                    {
                        return;
                    }
                    else
                    {
                        hei++;
                    }
                    break;
                case 'B':
                    isOver = true;
                    return;
                case 'T':
                    string[] teleport = cmd.ToString().Split(' ');
                    wid = int.Parse(teleport[1]);
                    dep = int.Parse(teleport[2]);
                    break;
            }
            cmd.Clear();
        }
    }

    private static void Slide(string p)
    {
        string[] spl = p.Split(' ');
        if("L"==spl[1])
        {
            if (wid - 1 < 0)
            {
                isOver = true;
                return;
            }
            if (hei + 1 == height)
            {
                return;
            }
            wid=wid-1;
            return;
        }
        if ("R" == spl[1])
        {
            if (wid + 1 >= width)
            {
                isOver = true;
                return;
            }
            if (hei + 1 == height)
            {
                return;
            }
            wid = wid + 1;
            return;
        }
        if ("F" == spl[1])
        {
            if (dep - 1 < 0)
            {
                isOver = true;
                return;
            }
            if (hei + 1 == height)
            {
                return;
            }
            dep = dep - 1;
            return;
        }
        if ("B" == spl[1])
        {
            if (dep + 1 >= depth)
            {
                isOver = true;
                return;
            }
            if (hei + 1 == height)
            {
                return;
            }
            dep = dep + 1;
            return;
        }
        if ("FL" == spl[1])
        {
            if (wid - 1 < 0 || dep - 1 < 0)
            {
                isOver = true;
                return;
            }
            if (hei + 1 == height)
            {
                return;
            }
            wid = wid - 1;
            dep = dep - 1;
            return;
        }
        if ("FR" == spl[1])
        {
            if (dep - 1 < 0 || wid + 1 >= width)
            {
                isOver = true;
                return;
            }
            if (hei + 1 == height)
            {
                return;
            }
            wid = wid + 1;
            dep = dep - 1;
            return;
        }
        if ("BL" == spl[1])
        {
            if (dep + 1 >= depth || wid - 1 < 0)
            {
                isOver = true;
                return;
            }
            if (hei + 1 == height)
            {
                return;
            }
            wid = wid - 1;
            dep = dep + 1;
            return;
        }
        if ("BR" == spl[1])
        {
            if (dep + 1 >= depth || wid + 1 >= width)
            {
                isOver = true;
                return;
            }
            if (hei + 1 == height)
            {
                return;
            }
            wid = wid + 1;
            dep = dep + 1;
            return;
        }
    }

    private static void FillCube()
    {
        for (int h = 0; h < height; h++)
        {
            string line = Console.ReadLine();
            string[] splitLine = line.Split(new char[]{'|'},StringSplitOptions.RemoveEmptyEntries);
            for (int d = 0; d < depth; d++)
            {
                string[] splitCol = splitLine[d].Split(')');
                for (int w = 0; w < width; w++)
                {
                    if (d > 0 && w==0)
                    {
                        cube[w, h, d] = splitCol[w].Substring(2);
                    }
                    else
                    {
                        cube[w, h, d] = splitCol[w].Substring(1);
                    }
                }
            }
        }
    }
    static void PrintCube()
    {
        for (int h = 0; h < height; h++)
        {
            for (int d = 0; d < depth; d++)
            {
                for (int w = 0; w < width; w++)
                {
                    Console.Write(cube[w,h,d]);
                }
                Console.Write(" ");
            }
            Console.WriteLine();
        }
    }
}
