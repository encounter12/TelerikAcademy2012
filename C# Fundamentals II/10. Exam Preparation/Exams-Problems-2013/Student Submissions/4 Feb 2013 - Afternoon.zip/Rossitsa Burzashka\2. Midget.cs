using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;

            string vNumbers = Console.ReadLine();           //вход
            //string vNumbers = "1, 3, -6, 7, 4, 1, 12";
            string[] Numbers = vNumbers.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int[] valNumbers = new int[Numbers.Length];
            for (int i = 0; i < valNumbers.Length; i++)
            {
                valNumbers[i] = Convert.ToInt32(Numbers[i]);
            }

            int broi = Convert.ToInt32(Console.ReadLine());    //вход

            string[][] patternIn = new string[broi][];

            for (int i = 0; i < broi; i++)
            {
                string g = Console.ReadLine();
                patternIn[i] = g.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            }

            /**********************************/
            //int broi = 3;                                         //за закоментирване
            //string[] patternIn = new string[broi];
            //patternIn[0] = "1, 2, 3".Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            //patternIn[1] = "1, 3, -2".Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries); ;
            //patternIn[2] = "1, 1".Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);;
            /**********************************/


            List<int>[] pattern = new List<int>[broi];

            for (int i = 0; i < broi; i++)
            {
                pattern[i] = new List<int>();
                for (int j = 0; j < patternIn[i].Length; j++)
                {
                    pattern[i].Add(Convert.ToInt32(patternIn[i][j]));
                }
            }

            decimal tempSum = 0;
            decimal bestSum = 0;
            int patN;

            for (int i = 0; i < broi; i++)
            {
                tempSum = FindCoins(valNumbers, pattern, i);
                if (bestSum < tempSum)
                {
                    bestSum = tempSum;
                    patN = i;
                }
            }
            Console.WriteLine(bestSum);
        }


        static decimal FindCoins(int[] valNumbers, List<int>[] pattern, int inter)
        {
            decimal resultCoins = 0;
            decimal resultCoinsTemp;
            int[] judge = new int[valNumbers.Length];
            bool YesOrNo = true;

            for (int i = 0; YesOrNo ; )
            {
                resultCoinsTemp = 0;
                for (int j = 0; j < pattern[inter].Count; j++)
                {

                    if (i > valNumbers.Length - 1 || i < -1)
                    {
                        YesOrNo = false;
                        break;
                    }
                    else if (judge[i] == 1)
                    {
                        YesOrNo = false;
                        break;
                    }
                    resultCoinsTemp += valNumbers[i];
                    judge[i] = 1;
                    i = i + pattern[inter][j];
                }
                resultCoins += resultCoinsTemp;
            }
            return resultCoins;
        }

    }
}
