using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlignBoth2
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {   
                Console.Write("\r\nPlease enter the number of lines: ");
                string N = Console.ReadLine();
                if (N.Length == 0)
                    break;
                int val = 0;
                try
                {
                    val = Int32.Parse(N);
                }
                catch (Exception)
                {
                    Console.WriteLine("\r\nInvalid number");
                    continue;
                }
                Console.Write("\r\nPlease enter the number of symbols: ");
                var W = Console.ReadLine();
                if (W.Length == 0)
                    break;
                double variable1 = 0;
                try
                {
                    variable1 = Convert.ToDouble(W);
                }
                catch (Exception)
                {
                    Console.WriteLine("\r\nInvalid number");
                    continue;
                }
                string sentence;
                int partLength = 35;
                Console.WriteLine("Enter some characters.");
                sentence = Console.ReadLine();
                string[] words = sentence.Split(' ');
                var parts = new Dictionary<int, string>();
                string part = string.Empty;
                int partCounter = 0;
                foreach (var word in words)
                {
                    if (part.Length + word.Length < partLength)
                    {
                        part += string.IsNullOrEmpty(part) ? word : " " + word;
                    }
                    else
                    {
                        parts.Add(partCounter, part);
                        part = word;
                        partCounter++;
                    }
                }
                parts.Add(partCounter, part);
                foreach (var item in parts)
                {
                    Console.WriteLine("{1}", item.Key, item.Value, item.Value.Length);
                }
                Console.ReadLine();
            }
        }
    }
}