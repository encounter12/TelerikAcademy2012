using System;
using System.Collections.Generic;
using System.Linq;
 
 
namespace Midget
{
    class Program
    {
 
        public static int EvalCoins(List<int> val, List<int> pat)
        {
            try
            {
                int sum = 0;
                bool[] visited = new bool[val.Count];
                int indexVal = 0;
                sum = val[indexVal];
                visited[indexVal] = true;
                while (true)
                {
                    foreach (int item in pat)
                    {
                        indexVal += item;
                        if (indexVal < 0 || indexVal > val.Count)
                        {
                            return sum;
                        }
                        if (visited[indexVal])
                        {
                            return sum;
                        }
                        sum += val[indexVal];
                        visited[indexVal] = true;
 
                    }
 
                }
            }
            catch (IndexOutOfRangeException e)
            {
                return 0;
            }
 
        }
        static void Main(string[] args)
        {
            List<int> valley = new List<int>();
 
            string input = Console.ReadLine();
            string[] inputElems = input.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
 
            foreach (string item in inputElems)
            {
                valley.Add(int.Parse(item));
            }
 
 
            int numPat = int.Parse(Console.ReadLine());
 
            List<int> pattern = new List<int>();
            int tmpMax = 0;
            int max = int.MinValue;
            string strPatter = string.Empty;
 
            for (int i = 0; i < numPat; i++)
            {
                strPatter = Console.ReadLine();
                inputElems = strPatter.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string item in inputElems)
                {
                    pattern.Add(int.Parse(item));
                }
                tmpMax = EvalCoins(valley, pattern);
                if (tmpMax > max)
                {
                    max = tmpMax;
                }
                pattern.Clear();
            }
 
            Console.WriteLine(max);
 
        }
    }
}