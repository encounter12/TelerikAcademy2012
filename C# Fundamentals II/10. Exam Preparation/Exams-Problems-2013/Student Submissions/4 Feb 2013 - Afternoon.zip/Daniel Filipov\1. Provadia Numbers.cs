using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;
class ProvadiaNumbers
{
	public static void Main ()
	{
		BigInteger input = BigInteger.Parse (Console.ReadLine ());
		int digit;
		int d;
		int e;
		List<string> res = new List<string> ();
		string[] pdigit = new string[256];
		for (int i=0; i<26; i++) {
			pdigit [i] = ((char)(i + 65)).ToString ();
		}
		for (int i=26; i<256; i++) {
			d = i % 26;
			e = i / 26;
			pdigit [i] = ((char)(e + 96)).ToString () + ((char)(d + 65)).ToString ();
		}
		while (input>255) {
			digit = (int)(input % 256);
			input /= 256;
			res.Add (pdigit [digit]);
		}
		res.Add (pdigit [(int)input]);
		for (int i=res.Count-1; i>=0; i--) {
			Console.Write (res[i]);
		}
	}
}
