using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Provadia
{
    static void Main()
    {
        string[] codes = new string[256];
        for (int i = 0; i < 26; i++)
        {
            codes[i] = ((char)(('A' + i))).ToString();
        }
        for (int i = 26; i < 52; i++)
        {
            codes[i] = 'a' + ((char)(('A' + i - 26))).ToString();
        }
        for (int i = 52; i < 78; i++)
        {
            codes[i] = 'b' + ((char)(('A' + i - 52))).ToString();
        }
        for (int i = 78; i < 104; i++)
        {
            codes[i] = 'c' + ((char)(('A' + i - 78))).ToString();
        }
        for (int i = 104; i < 130; i++)
        {
            codes[i] = 'd' + ((char)(('A' + i - 104))).ToString();
        }
        for (int i = 130; i < 156; i++)
        {
            codes[i] = 'e' + ((char)(('A' + i - 130))).ToString();
        }
        for (int i = 156; i < 182; i++)
        {
            codes[i] = 'f' + ((char)(('A' + i - 156))).ToString();
        }
        for (int i = 182; i < 208; i++)
        {
            codes[i] = 'g' + ((char)(('A' + i - 182))).ToString();
        }
        for (int i = 208; i < 234; i++)
        {
            codes[i] = 'h' + ((char)(('A' + i - 208))).ToString();
        }
        for (int i = 234; i < 256; i++)
        {
            codes[i] = 'i' + ((char)(('A' + i - 234))).ToString();
        }
        ulong number = ulong.Parse(Console.ReadLine());
        ulong wholePart = 0;
        int remainder = 0;
        if (number < 256)
        {
            Console.WriteLine(codes[number]);
        }
        else
        {
            wholePart = number / 256;
            remainder = (int)(number % 256);
                while (wholePart > 256)
                {

                    Console.Write(codes[remainder]);
                    wholePart = wholePart / 256;
                    remainder = (int)(wholePart % 256);
                }
                Console.Write(codes[wholePart]);
                Console.Write(codes[remainder]);
            
        }
    }
}
