using System;
using System.Linq;
using System.Text;



class Task_fout
{
    static void Main()
    {
        int rows = int.Parse(Console.ReadLine());
        int rowLen = int.Parse(Console.ReadLine());
        string input = Console.ReadLine();

        string[] words = input.Split(' ');
        foreach(string word in words)
        {
            word.Trim();
        }
        int countWords = 0;
        for (int i = 0; i < rows; i++)
        {
            StringBuilder row = new StringBuilder(rowLen);

            int countWordsInRow = 0;
            while (true)
            {
                if (row.Length + words[countWords].Length < rowLen )
                {
                    row.Append(words[countWords]);
                    row.Append('|');
                    countWordsInRow++;
                    if (countWords + 1 == words.Length)
                    {
                        AlignWords(row, rowLen, countWordsInRow);
                        break;
                    }
                    else
                    {
                        countWords++;
                    }
                }
                else
                {
                    AlignWords(row, rowLen, countWordsInRow);
                    break;
                }
            }
        }
    }

    private static void AlignWords(StringBuilder input, int len, int numOfWords)
    {
        int rowLen = input.Length;
        int gaps = len - rowLen + 1;
        int gapLen = len / gaps;
        if (numOfWords == 1)
        {
            input.Remove(rowLen - 1, 1);
            Console.WriteLine(input.ToString());
        }
        else
        {
            if (len % gaps != 0)
            {
                input.Replace("|", new string(' ', gapLen));
                for (int i = 0; i < gaps - 1; i++)
                {
                    input.Replace("|", new string(' ', gapLen+1));
                }
            }
            else
            {
                for (int i = 0; i < gaps ; i++)
                {
                    input.Replace("|", new string(' ', gapLen));
                }
            }
            Console.WriteLine(input.ToString());
        }
    }
}
