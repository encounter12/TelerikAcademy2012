using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Provadia
{
    class ProvadiaNumbers
    {
        static void Main(string[] args)
        {
            UInt64 number = UInt64.Parse(Console.ReadLine());

            List<string> alphabet = new List<string>(256);
            for (int i = -1; i < 26; i++)
            {
                if (alphabet.Count == 256) break;
                for (int j = 0; j < 26; j++)
                {
                    if (alphabet.Count == 256) break;
                    if (alphabet.Count > 25)
                        alphabet.Add(((char)(i + 97)).ToString() + ((char)(j + 65)).ToString());
                    else
                        alphabet.Add(((char)(j + 65)).ToString());
                }
            }
            List<string> result = new List<string>();

            do
            {
                result.Add(alphabet[(int)(number % 256)]);
                number /= 256;
            }
            while (number > 0);

            result.Reverse();
            Console.WriteLine(String.Join("", result));
        }


    }
}
