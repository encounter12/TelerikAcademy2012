using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.BallInCuboid
{
    class Program
    {
        static void Main(string[] args)
        {
            bool bounded = true;
            if (bounded)
            {
                Console.WriteLine("\"bounded\"");
            }
            else
            {
                Console.WriteLine("\"unbounded\"");
            }

        }
    }
}
