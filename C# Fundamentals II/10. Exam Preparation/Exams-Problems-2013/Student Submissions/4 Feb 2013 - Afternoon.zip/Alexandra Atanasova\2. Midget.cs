using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
 
    class Midget
    {
        static void Main()
        {
            string valley = Console.ReadLine();
            int patternNum = int.Parse(Console.ReadLine());
            string pattern;
            int maxCount = 0;
            StringBuilder paths = new StringBuilder();
            int count = 0;
                      
            StringBuilder coins = new StringBuilder();
            foreach (string number in valley.Split(new Char[] { ',', ' ' }))
            {
                coins.Append(number);          
            }
            string coin = coins.ToString();
 
             
            for (int i = 0; i < patternNum; i++)
            {
                count = 0;
                pattern = Console.ReadLine();               
                foreach (string path in pattern.Split(new Char[] {',', ' '}))
                {                   
                    paths.Append(path);                    
                }
                 
               string pat = paths.ToString();
                for (int j = 0, k = 0; j < pat.Length-1 && k< pat.Length-1; j+= pat[k] - 48, k++)
                {
                    if (coin[j] == '0')
                    {
                        continue;
                    }
                    else
                    {
                        count += coin[j] - 48;
                        string blue = coin.Replace(coin[j], '0');
                         
                    }
                    if(maxCount <count)
                    {
                        maxCount = count;
                    }
                }
            }
            Console.WriteLine(count);
             
             
        }
    }