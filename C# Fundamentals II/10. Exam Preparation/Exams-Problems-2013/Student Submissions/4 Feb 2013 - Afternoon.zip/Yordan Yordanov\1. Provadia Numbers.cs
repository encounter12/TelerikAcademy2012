using System;

class Program
{
    static string ConvertFromDecimal(ulong inputNumber)
    {
        string alphabetIndex = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        if (inputNumber < 26)
        {
            return alphabetIndex[(int)inputNumber].ToString();
        }
        ulong temp = inputNumber / 26;
        ulong remainder = inputNumber % 26;
        string result = alphabetIndex[(int)temp-1].ToString().ToLower() + alphabetIndex[(int)remainder].ToString();
        return result;
    }
    static void Main()
    {
        ulong input = ulong.Parse(Console.ReadLine());
        ulong remainder = input % 256;
        input = input / 256;
        string result = ConvertFromDecimal(remainder);
        while (input > 0)
        {
            remainder = input % 256;
            input = input / 256;
            result = ConvertFromDecimal(remainder) + result;
        }
        Console.WriteLine(result);
       
    }
}