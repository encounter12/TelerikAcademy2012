using System;
using System.Collections.Generic;

class Program
{

    static int FindLastLamp(int lamps)
    {
        List<int> lamp = new List<int>();
        for (int i = 1; i <= lamps; i++)
        {
            lamp.Add(i);
        }
        int index = 2;
        while (lamp.Count > 1)
        {
            for (int i = 0; i < lamps; i+=index)
            {
                lamp.Remove(i + index - 1);
            }
            index++;
        }
        return lamp[0];
    }

    static string RobotPath(string str)
    {
        if (!str.Contains("S"))
        {
            return "bounded";
        }
        else if (str.Contains("R") && str.Contains("S") && !str.Contains("L"))
        {
            return "bounded";
        }
        else if (str.Contains("L") && str.Contains("S") && !str.Contains("R"))
        {
            return "bounded";
        }
        else
        {
            return "unbounded";
        }
    }

    static void Main()
    {
        int numberOfLamps = int.Parse(Console.ReadLine());
        string str1 = Console.ReadLine();
        string str2 = Console.ReadLine();

        Console.WriteLine(FindLastLamp(numberOfLamps));
        Console.WriteLine(RobotPath(str1));
        Console.WriteLine(RobotPath(str2));
    }

}
