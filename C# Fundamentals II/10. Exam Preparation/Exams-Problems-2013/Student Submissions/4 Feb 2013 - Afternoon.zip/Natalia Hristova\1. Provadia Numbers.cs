using System;
using System.Text;


namespace ProvadiaNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal number = decimal.Parse(Console.ReadLine());

            string inProvadia = GetProvadiaRepresentation(number);
            Console.WriteLine(inProvadia);
        }

        static string GetProvadiaRepresentation(decimal number)
        {
            string[] ProvadiaDigits = GenerateProvadiaDigits();
            return DecimalToStringFast(number, ProvadiaDigits);
        }

        static string[] GenerateProvadiaDigits()
        {
            char[] smallLetters = new char[26];
            char[] capitalLetters = new char[26];
            for (int i = 0; i < 26; i++)
            {
                char smallLetter = Convert.ToChar(97 + i);
                smallLetters[i] = smallLetter;
                char capLetter = Convert.ToChar(65 + i);
                capitalLetters[i] = capLetter;
            }

            string[] numersMap = new string[256];
            for (int i = 0; i < numersMap.Length; i++)
            {
                int capitalLetterIndex = i % 26;
                string capitalLetter = capitalLetters[capitalLetterIndex].ToString();

                int smallLetterIndex = i / 26;
                string smallLetter = string.Empty;

                if (smallLetterIndex > 0)
                {
                    smallLetter = smallLetters[smallLetterIndex - 1].ToString();
                }
                numersMap[i] = string.Format("{0}{1}", smallLetter, capitalLetter);
            }

            return numersMap;
        }

        static string DecimalToStringFast(decimal value, string[] baseChars)
        {
            int i = 64;
            string[] buffer = new string[i];
            int targetBase = baseChars.Length;

            do
            {
                buffer[--i] = baseChars[(long)(value % targetBase)];
                value = (long)(value / targetBase);
            }
            while (value > 0);

            string[] result = new string[64 - i];
            Array.Copy(buffer, i, result, 0, 64 - i);

            StringBuilder resultString = new StringBuilder();
            for (int j = 0; j < result.Length; j++)
            {
                resultString.Append(result[j]);
            }
            return resultString.ToString();
        }
    }
}
