using System;
using System.Text;

class text
{
    static void Clear(StringBuilder value)
    {
        value.Length = 0;
        value.Capacity = 0;
    }
    static StringBuilder AppendWhiteSpaces(StringBuilder line, int width, int pos)
    {
        
        while (line.Length < width)
        {
            pos = line.ToString().IndexOf(' ', pos + 2);
            line.Insert(pos + 1, ' ');
        }
        return line;
    }
    static void Main()
    {
        int rows = int.Parse(Console.ReadLine());
        int width = int.Parse(Console.ReadLine());
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < rows; i++)
        {
            text.Append(Console.ReadLine());
        }
        string[] arr = text.ToString().Split(new char[]{' '}, StringSplitOptions.RemoveEmptyEntries);
        StringBuilder line = new StringBuilder();
        foreach (var item in arr)
        {
            if (line.Length + item.Length < width)
            {
                line.Append(item).Append(' ');
            }
            else
            {
                line = AppendWhiteSpaces(line, width, -1);
                Console.WriteLine(line);
                Clear(line);
                line.Append(item).Append(' ');
            }

            
            
            
        }
        

    }
}
