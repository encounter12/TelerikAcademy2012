using System;
using System.Collections.Generic;

class ProvadiaNumbers
{
    static void Main()
    {
        decimal myNumber = decimal.Parse(Console.ReadLine());
        string ProvadiaNumbers1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        string ProvadiaNumbers2 = "abcdefghi";
        List<int> coefficientsList = new List<int>();
        string myProvadiaNumber = "";
        int coefficient;
        int residual;
        int tableSize = 256;
        int tablePointer;

        coefficient = (int)myNumber / tableSize;
        residual = (int)(myNumber - coefficient * tableSize);
        coefficientsList.Add(residual);
        if (coefficient > 0)
        {
            getCoefficientsValue(tableSize, coefficientsList, coefficient);
        }

        if (coefficientsList.Count > 0)
        {
            for (int i = 0; i < coefficientsList.Count; i++)
            {
                tablePointer = coefficientsList[coefficientsList.Count - i - 1];//3
                if (tablePointer > 25)
                {
                    tablePointer = tablePointer / 26;
                    myProvadiaNumber += ProvadiaNumbers2[tablePointer - 1].ToString();
                }                
                    myProvadiaNumber += ProvadiaNumbers1[coefficientsList[coefficientsList.Count - i - 1]%26].ToString();

            }
        }

        Console.WriteLine(myProvadiaNumber);
    }

    private static void getCoefficientsValue(int tableSize, List<int> coefficientsList, int coefficient)
    {
        if (coefficient < tableSize)
        {
            coefficientsList.Add(coefficient);
        }
        else
        {
            coefficientsList.Add(tableSize - 1);
            coefficient -= tableSize;
            getCoefficientsValue(tableSize, coefficientsList, coefficient);
        }

    }
}