using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5.hahaha
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] delimiters = { ' ', ',' };
            string valley = Convert.ToString(Console.ReadLine());
            string[] valleyNumbers = valley.Split(delimiters,
                StringSplitOptions.RemoveEmptyEntries);
            int H =int.Parse(valleyNumbers[1]);
            for (int i = 0; i < H; i++)
            {
                string a = Convert.ToString(Console.ReadLine());
            }
            string position = Convert.ToString(Console.ReadLine());

            Console.WriteLine("No");
                Console.Write(H + " ");
                Console.WriteLine(position);
        }
    }
}
