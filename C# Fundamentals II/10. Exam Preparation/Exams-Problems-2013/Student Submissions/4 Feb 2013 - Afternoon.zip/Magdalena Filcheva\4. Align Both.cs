using System;
using System.Text;
using System.Text.RegularExpressions;

class AlignBoth
{
    static void Main()
    {
        int lines = int.Parse(Console.ReadLine());
        int length = int.Parse(Console.ReadLine());
       // int lines = 6;
      //  int length = 18;

        StringBuilder currentLine = new StringBuilder();
        StringBuilder textInput = new StringBuilder();

       for (int idnex = 0; idnex < lines; idnex++)
        {
            textInput.Append(Console.ReadLine());
            textInput.Append('\n');
        }

        string text = textInput.ToString(); 
        

        string[] words = text.Split(new char[] {' ', '\r', '\n'}, StringSplitOptions.RemoveEmptyEntries);

        int currentLength = currentLine.Length;
        int addWhiteSpaces = 0;
        int indexForSpace = -1;
        int count = 1;
        int current = 0;
        for (int index = 0; index < words.Length; index++)
        {
            currentLength += words[index].Length;

            if (currentLength <= length)
            {
                currentLine.Append(words[index]);

                if (currentLength < length)
                {
                    currentLine.Append(" ");
                    currentLength++;
                    if (currentLength == length)
                    {
                        currentLine.Remove(currentLine.Length - 1, 1);
                    }
                }
            }
            else 
            {
                if (currentLine[currentLine.Length-1] == ' ')
                {
                    currentLine.Remove(currentLine.Length - 1, 1);
                }
                while (currentLine.Length < length)
                {
                    addWhiteSpaces = length - currentLine.Length;
                    if (addWhiteSpaces == 0)
                    {
                        Console.WriteLine(currentLine);
                        currentLine.Clear();
                        currentLength = currentLine.Length;
                        addWhiteSpaces = 0;
                        index--;
                        count = 1;
                        current = 0;
                        indexForSpace = -1;
                    }
                    else 
                    {
                        try
                        {
                            indexForSpace = currentLine.ToString().IndexOf(' ', indexForSpace + count);
                        }
                        catch (IndexOutOfRangeException)
                        {
                            indexForSpace = currentLine.Length;
                            break;
                        }
                        catch (ArgumentException)
                        {
                            indexForSpace = currentLine.Length;
                            break;
                        } 

                       // indexForSpace = currentLine.ToString().IndexOf(' ', indexForSpace + count);
                        /*if (indexForSpace == -1 && currentLine.ToString().IndexOf(' ', 0) == -1)
                        {
                            break;
                        }
                        else
                         */
                        if (indexForSpace == -1)
                        {
                            current++;
                            count = 1 + current;
                        }
                        else
                        {
                            currentLine.Insert(indexForSpace, ' ');
                            count++;
                        }
                    }
                }

                Console.WriteLine(currentLine);
                currentLine.Clear();
                currentLength = currentLine.Length;
                addWhiteSpaces = 0;
                index--;
                count = 1;
                current = 0;
                indexForSpace = -1;
            }
            if (index + 1 == words.Length)
            {
                if (currentLine[currentLine.Length - 1] == ' ')
                {
                    currentLine.Remove(currentLine.Length - 1, 1);
                }

                Console.WriteLine(currentLine);
 
            }
        }

    }
}