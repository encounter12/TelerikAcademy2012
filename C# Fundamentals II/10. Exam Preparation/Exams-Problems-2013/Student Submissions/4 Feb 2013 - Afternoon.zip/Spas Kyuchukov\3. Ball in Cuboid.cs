using System;
using System.Linq;

class BallInCuboid
{
    static void Main()
    {
        int width, height, depth;
        GetWHD(out width, out height, out depth);

        string[, ,] cube = GetCube(width, height, depth);

        int ballWidth, ballDepth;
        GetBallWD(out ballWidth, out ballDepth);

        bool exited = false;
        int currentWidth = ballWidth;
        int currentHeight = 0;
        int currentDepth = ballDepth;

        do
        {
            if (!Step(ref currentWidth, ref currentHeight, ref currentDepth, cube, ref exited)) break;
            if (exited) break;
        } while (true);

        Console.WriteLine(exited?"Yes":"No");
        Console.WriteLine("{0} {1} {2}", currentWidth, currentHeight, currentDepth);

    }

    // If false = stuck
    private static bool Step (ref int currentWidth, ref int currentHeight, ref int currentDepth, string[,,] cube, ref bool exited)
    {
        int nextWidth=currentWidth, nextHeight=currentHeight, nextDepth=currentDepth;

        string com = cube[currentHeight, currentWidth, currentDepth];
        string[] command = com.Split(' ');

        switch (command[0])
        {
            case "B":
                {
                    return false;
                }

            case "E":
                {
                    --nextHeight;
                    break;
                }

            case "T":
                {
                    nextWidth = int.Parse(command[1]);
                    nextDepth = int.Parse(command[2]);
                    break;
                }

            case "S":
                {
                    --nextDepth;
                    if (command[1].Contains('B')) ++nextDepth;
                    if (command[1].Contains('F')) --nextDepth;
                    if (command[1].Contains('L')) --nextWidth;
                    if (command[1].Contains('R')) ++nextWidth;
                    break;
                }
        }

        if (  (currentDepth == cube.GetLength(0) - 1 ) && ( nextHeight > cube.GetLength(0) - 1 ) ) 
        { 
            exited = true;
            return true;
        }

        if ((nextHeight > cube.GetLength(0) - 1) || (nextWidth > cube.GetLength(2) - 1) || (nextDepth > cube.GetLength(1) - 1))
            return false;

        if ((nextHeight < 0) || (nextWidth < 0) || (nextDepth < 0))
            return false;

        currentWidth=nextWidth;
        currentHeight = nextHeight;
        currentDepth = nextDepth;
        return true;
    }

    private static void GetBallWD(out int ballWidth, out int ballDepth)
    {
        string bwd = Console.ReadLine();
        string[] bwdA = bwd.Split(' ');
        int.TryParse(bwdA[0], out ballWidth);
        int.TryParse(bwdA[0], out ballDepth);
    }

    private static void GetWHD(out int width, out int height, out int depth)
    {
        string whd = Console.ReadLine();
        string[] whdA = whd.Split(' ');
        int.TryParse(whdA[0], out width);
        int.TryParse(whdA[1], out height);
        int.TryParse(whdA[2], out depth);
    }

    private static string[, ,] GetCube(int width, int height, int depth)
    {
        string[, ,] cube = new string[height, depth, width];

        string[] lines = new string[height];

        for (int h = 0; h < height; h++)
        {
            lines[h] = Console.ReadLine();

            string[] rows = new string[depth];

            rows = lines[h].Split(new string[] { " | " }, StringSplitOptions.RemoveEmptyEntries);

            for (int d = 0; d < depth; d++)
            {
                string[] cells = new string[width];
                cells = rows[d].Split(new string[] { ")(", "(", ")" }, StringSplitOptions.RemoveEmptyEntries);

                for (int c = 0; c < width; c++)
                {
                    cube[h, d, c] = cells[c];
                }
            }

        }

        return cube;
    }
}

