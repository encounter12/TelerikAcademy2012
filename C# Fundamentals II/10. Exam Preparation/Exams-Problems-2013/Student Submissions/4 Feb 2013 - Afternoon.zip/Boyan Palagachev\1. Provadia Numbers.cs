using System;
using System.Collections.Generic;

class ProvadiaNumbers
{
    
    static void Main(string[] args)
    {
        ulong number = ulong.Parse(Console.ReadLine());
        List<byte> provadiaNumber = ConvertDecToAny(number, 256);

        PrintProvadiaNumber(provadiaNumber);
    }
    static void PrintProvadiaNumber(List<byte> provadiaNumber)
    {
        for (int i = provadiaNumber.Count-1; i >=0; i--)
        {
            int times = provadiaNumber[i] / (int)('z'-'a'+1);
            int reminder = provadiaNumber[i] % (int)('z' - 'a'+1);

            if (times>0)
            {
                Console.Write((char)(times - 1 + 'a'));
            }
            Console.Write((char)('A'+reminder));
           
        }

    }
    static public List<byte> ConvertDecToAny(ulong decNumber, ulong destinationBase)
    {
        List<byte> destinationNumber = new List<byte>();
        while (decNumber > 0)
        {
            destinationNumber.Add((byte)(decNumber % destinationBase));
            decNumber /= destinationBase;
        }
        //return new AnyNumSystem(destinationNumber, destinationBase);
        return destinationNumber;
    }
}