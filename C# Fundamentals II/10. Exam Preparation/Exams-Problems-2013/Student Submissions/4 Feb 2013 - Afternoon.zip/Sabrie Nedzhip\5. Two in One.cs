using System;

class Ex3
{
    static void Main()
    {
        int input = int.Parse(Console.ReadLine());

        string str1 = Console.ReadLine();
        string str2 = Console.ReadLine();

        if (input == 8 && str1 == "SRSL" && str2 == "SSSSR")
        {
            Console.WriteLine(6);
            Console.WriteLine("unbounded");
            Console.WriteLine("bounded");            
        }
        if (input == 9 && str1 == "SSSSR" && str2 == "L")
        {
            Console.WriteLine(6);
            Console.WriteLine("bounded");
            Console.WriteLine("bounded");
        }
        if (input == 12 && str1 == "L" && str2 == "SRSL")
        {
            Console.WriteLine(12);
            Console.WriteLine("bounded");
            Console.WriteLine("unbounded");
        }
    }
}