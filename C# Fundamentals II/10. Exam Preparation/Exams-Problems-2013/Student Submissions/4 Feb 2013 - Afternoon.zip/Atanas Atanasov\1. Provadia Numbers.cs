using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class Program
{
    static void Main(string[] args)
    {
        decimal number = decimal.Parse(Console.ReadLine());
        Dictionary<int, string> num_system = new Dictionary<int, string>();
        char[] big_letters = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
        char[] small_letters = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
        int next_small_letter = -1;
        int cur_digit=0;
        for (int i = 0; cur_digit!=256; i++)
        {
            StringBuilder code = new StringBuilder();
            string small_letter = null; 
            if (i%26==0 && i!=0){
                i=0;
                next_small_letter++;
            }
            string big_letter = big_letters[i].ToString();
            if (next_small_letter>=0){
                if (next_small_letter%26==0 && next_small_letter!=0){
                    next_small_letter = 0;
                }
                small_letter=small_letters[next_small_letter].ToString();
            }
            code.Append(small_letter);
            code.Append(big_letter);
            num_system.Add(cur_digit,code.ToString());
            cur_digit++;
        }
        string result = from_dec_to_other(number, 256, num_system);
        Console.WriteLine(result);
    }

    static string from_dec_to_other(decimal number, int destination, Dictionary<int,string> digits)
    {
        //char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
        var result = new List<string>();
        if (number == 0)
        {
            return digits[0];
        }
        while (true)
        {
            if (number != 0)
            {
                result.Add(digits[(int)(number % destination)]);
                number = (long)(number / destination);
            }
            else
            {
                break;
            }
        }
        result.Reverse();
        var builder = new StringBuilder();
        Array.ForEach(result.ToArray(), x => builder.Append(x));
        var res = builder.ToString();
        return res;
    }
}
