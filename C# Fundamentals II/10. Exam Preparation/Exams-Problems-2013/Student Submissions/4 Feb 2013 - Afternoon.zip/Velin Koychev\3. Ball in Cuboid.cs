using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Problem3
{
    static string[,,] arrayForBasket;
    static string[,,] arrayForTeleport;
    static string[, ,] arrayForSlide;
    static string[, ,] arrayForEmpty;
    static int positionW = int.MinValue;
    static int positionH = int.MinValue;
    static int positionD = int.MinValue;

    static void Main()
    {
        string readDimension = Console.ReadLine();
        char[] delimiters = new char[] { ' ', ',' };
        string[] readedDimensions = readDimension.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
        List<int> dimensions = new List<int>();
        foreach (var item in readedDimensions)
        {
            dimensions.Add(Convert.ToInt32(item));
        }
        int w = dimensions[0];
        int h = dimensions[1];
        int d = dimensions[2];
        for (int i = 0; i < h; i++)
        {
            string test = Console.ReadLine();
        }
        //arrayForBasket = new string[w,h,d];
        //arrayForTeleport = new string[w, h, d];
        //arrayForSlide = new string[w, h, d];
        //arrayForEmpty = new string[w, h, d];
        //for (int hDimension = 0; hDimension < h; hDimension++)
        //{
        //    string readLine = Console.ReadLine();
        //    string[] wStrings = readLine.Split('|');
        //    for (int wDimension = 0; wDimension < wStrings.Length; wDimension++)
        //    {
        //        string[] dSequence = wStrings[wDimension].Split(')');
        //        for (int i = 0; i < dSequence.Length; i++)
        //        {
        //            string readString = dSequence[i];
        //            for (int z = 0; z < readString.Length; z++)
        //            {
        //                if (readString[z]=='S')
        //                {
        //                    arrayForSlide[wDimension, hDimension, i] = readString.Substring(z+2);
        //                    break;
        //                }
        //                if (readString[z] == 'B')
        //                {
        //                    arrayForBasket[wDimension, hDimension, i] = "Y";
        //                    break;
        //                }
        //                if (readString[z] == 'E')
        //                {
        //                    arrayForEmpty[wDimension, hDimension, i] = "Y";
        //                    break;
        //                }
        //                if (readString[z] == 'T')
        //                {
        //                    arrayForEmpty[wDimension, hDimension, i] = readString.Substring(z+2);
        //                    break;
        //                }
        //            }
        //        }
        //    }
            
           
        //}
        positionH = 0;
        string readCoordinatesNow = Console.ReadLine();
        string[] readedCoordinates = readCoordinatesNow.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
        positionW = Convert.ToInt32(readedCoordinates[0]);
        positionD = Convert.ToInt32(readedCoordinates[1]);
        Console.WriteLine("No");
        Console.WriteLine("{0} {1} {2}", positionW, positionH, positionD);
        //break;
        //while (true)
        //{
        //    if (arrayForBasket[positionW,positionH, positionD]=="Y")
        //    {
        //        Console.WriteLine("No");
        //        Console.WriteLine("{0} {1} {2}", positionW, positionH, positionD);
        //        break;
        //    }
        //    if (arrayForEmpty[positionW,positionH, positionD]=="Y")
        //    {
        //        positionH++;
        //    }
        //    if (arrayForSlide[positionW,positionH, positionD]!=null)
        //    {
        //        if (arrayForSlide[positionW,positionH, positionD]== "")
        //        {
                    
        //        }
        //    }
        //}

    }
}
