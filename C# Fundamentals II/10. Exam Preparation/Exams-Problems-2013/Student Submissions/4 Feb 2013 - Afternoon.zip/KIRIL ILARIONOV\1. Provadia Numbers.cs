using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Z1
{
    public static Dictionary<byte, string> digitValue = new Dictionary<byte, string>();
    private static string toProvadiaDigit(long n)
    {
        return digitValue[(byte)n];
    }
    public static string decToProvadia(long n)
    {
        if (n >= 0 && n <= 255)
            return (toProvadiaDigit(n % 256));
        else
            return decToProvadia(n / 256) + toProvadiaDigit(n % 256);
    }

    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("input.txt"));
#endif
        // init part
        char letterA = 'A';
        string tempStr;
        char[] alphabet = new char[26];
        
        for (byte i = 0; i < 26; i++)
        {
            alphabet[i] = letterA++;
            tempStr = alphabet[i].ToString();
            digitValue.Add(i, tempStr);
        }

        //foreach (KeyValuePair<string, byte> digit in digitValue)
        //{ // OK
        //    Console.WriteLine("Key: {0}, Value: {1}",
        //    digit.Key, digit.Value);
        //}

        // digitValue => init continue

        for (byte k = 26; k <= 51; k++)
        {
            digitValue.Add(k, 'a'.ToString()+alphabet[k%26]);
        }
        for (byte k = 52; k <= 51+26; k++)
        {
            digitValue.Add(k, 'b'.ToString() + alphabet[k % 26]);
        }
        for (byte k = 51 + 26+1; k <= 51 + 26 + 26; k++)
        {
            digitValue.Add(k, 'c'.ToString() + alphabet[k % 26]);
        }
        for (byte k = 51 + 26 + 26+1; k <= 51 + 26 + 26 + 26; k++)
        {
            digitValue.Add(k, 'd'.ToString() + alphabet[k % 26]);
        }
        for (byte k = 51 + 26 + 26 + 26+1; k <= 51 + 4 * 26; k++)
        {
            digitValue.Add(k, 'e'.ToString() + alphabet[k % 26]);
        }
        for (byte k = 51 + 4 * 26+1; k <= 51 + 5 * 26; k++)
        {
            digitValue.Add(k, 'f'.ToString() + alphabet[k % 26]);
        }
        for (byte k = 51 + 5 * 26 + 1; k <= 51 + 6 * 26; k++)
        {
            digitValue.Add(k, 'g'.ToString() + alphabet[k % 26]);
        }
        for (byte k = 51 + 6 * 26 + 1; k <= 51 + 7 * 26; k++)
        {
            digitValue.Add(k, 'h'.ToString() + alphabet[k % 26]);
        }
        for (byte k = 51 + 7 * 26+1; k < 255; k++)
        {
            //Console.WriteLine("key={0} val={1}", 'i'.ToString() + alphabet[k % 26], k);
            digitValue.Add(k, 'i'.ToString() + alphabet[k % 26]);
        }
        digitValue.Add(255, "iV");
        //foreach (KeyValuePair<byte, string> digit in digitValue)
        //{ // myDictionary is OK
        //    Console.WriteLine("Key: {0}, Value: {1}",
        //    digit.Key, digit.Value);
        //}

        long input = long.Parse(Console.ReadLine());
        //string inputIntDecimal = Console.ReadLine();
        Console.WriteLine(decToProvadia(input));
        //Console.WriteLine(result);
        // isCatitalLetter =>
        // else get smallPlusCapitalLetter
    }
}