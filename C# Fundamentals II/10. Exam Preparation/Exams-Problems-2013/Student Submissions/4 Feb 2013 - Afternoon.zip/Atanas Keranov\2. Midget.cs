using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midget
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] delimiters = {',', ' '};
            string[] numbersInTheValleyInput = Console.ReadLine().Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
            int patternsCountInput = int.Parse(Console.ReadLine());
            string[][] patternsInput = new string[patternsCountInput][];
            int maxGoldCollected = int.MinValue;
            int goldCollected = 0;

            for (int pattern = 0; pattern < patternsCountInput; pattern++)
            {
                patternsInput[pattern] = Console.ReadLine().Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
            }

            int[] numbersInTheValley = new int[numbersInTheValleyInput.Length];
            for (int i = 0; i < numbersInTheValley.Length; i++)
            {
                numbersInTheValley[i] = int.Parse(numbersInTheValleyInput[i]);
            }

            int[][] patterns = new int[patternsCountInput][];
            for (int i = 0; i < patternsCountInput; i++)
            {
                patterns[i] = new int[patternsInput[i].Length];

                for (int j = 0; j < patternsInput[i].Length; j++)
                {
                    patterns[i][j] = int.Parse(patternsInput[i][j]);
                }
            }

            for (int i = 0; i < patterns.Length; i++)
            {
                goldCollected = GetCollectedGold(patterns[i], numbersInTheValley);

                if (maxGoldCollected < goldCollected)
                {
                    maxGoldCollected = goldCollected;
                }
            }

            Console.WriteLine(maxGoldCollected);
        }

        static int GetCollectedGold(int[] pattern, int[] numbersInTheValley)
        {
            const int MidgetWasHere = -2000;
            int goldCollected;
            int currentIndexInValleyArray;
            int[] valleyNumbers = new int[numbersInTheValley.Length];

            for (int i = 0; i < valleyNumbers.Length; i++)
            {
                valleyNumbers[i] = numbersInTheValley[i];
            }

            goldCollected = valleyNumbers[0];
            currentIndexInValleyArray = 0;
            valleyNumbers[0] = MidgetWasHere;

            while (true)
            {
                for (int i = 0; i < pattern.Length; i++)
                {
                    if (IsInRange(currentIndexInValleyArray, valleyNumbers.Length))
                    {
                        currentIndexInValleyArray += pattern[i];

                        if (IsInRange(currentIndexInValleyArray, valleyNumbers.Length) && valleyNumbers[currentIndexInValleyArray] != MidgetWasHere)
                        {
                            goldCollected += valleyNumbers[currentIndexInValleyArray];
                            valleyNumbers[currentIndexInValleyArray] = MidgetWasHere;
                        }
                        else
                        {
                            return goldCollected;
                        }
                    }
                    else
                    {
                        return goldCollected;
                    }
                }
            }

            return goldCollected;
        }

        static bool IsInRange(int currentIndex, int length)
        {
            bool result = true;

            if (currentIndex >= length || currentIndex < 0)
            {
                result = false;
            }

            return result;
        }
    }
}
