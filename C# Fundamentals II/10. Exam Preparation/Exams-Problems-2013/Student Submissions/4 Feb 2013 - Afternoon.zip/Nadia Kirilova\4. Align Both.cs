using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AlignBoth
{
    class AlignBoth
    {
        static void Main(string[] args)
        {
            int numberN = int.Parse(Console.ReadLine());
            int numberW = int.Parse(Console.ReadLine());
            StringBuilder text = new StringBuilder(numberN);
            for (int i = 0; i < numberN; i++)
            {
                text.Append(Console.ReadLine());
                text.Append(" ");
            }
            int number = 0;
            for (int i = 0; i < text.Length ; i++)
			{
                if (text[i] == ' ')
                {
                    number = number + 1;
                }
            }

            
            //int count = text.Length;
            //Console.WriteLine(number);
            /*for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == ' ')
                {
                    number = number + 1;
                }
            }*/
            List<int> word = new List<int>();
            int numberWordStar = 0;
            int nnumberWordEnd = 0;
            for (int i = 0; i < text.Length ; i++)
			{
                if (text[i] == ' ')
                {
                    nnumberWordEnd=i;
                    word.Add(nnumberWordEnd - numberWordStar);
                    numberWordStar = i + 1;

                }
            }
            //int number1=0;
            StringBuilder text1 = text;
            StringBuilder textForPrint = new StringBuilder();
            for (int i = 0; i < word.Count; i++)
            {
                int number1=0;
                int l = word[i];
                while (l < numberW)
                {
                    i = i + 1;
                    l = l + word[i];
                    number1 = number1 + 1;
                }
                int nubberText =  l - word[i];
                int interval = (numberW-1) - nubberText;
                int brint = interval/number1;
                int ost = interval%number1;
                int tre =0;
                for (int ii = 0; ii < number1; ii++)
                {
                    for (int lm = 0; lm < text1.Length; )
                    {
                        if (text1[lm] != ' ')
                        {
                            textForPrint.Append(text[l]);
                            lm= lm + 1;
                        }
                        if (text1[lm] == ' ')
                        {
                            //number = number - 1;
                            for (int ik = 0; ik < brint; ik++)
                            {
                                textForPrint.Append(" ");
                            }
                            if (ost != 0)
                            {
                                textForPrint.Append(" ");
                                ost = ost - 1;
                            }
                        }
                        number = number - 1;
                        lm= text1.Length;
                    }
                    int id = text1.ToString().IndexOf(" ");
                    string ter = text1.ToString().TrimStart().Substring(id);
                    text1=ter.

                    


            }
 
        }
    }
}
