using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dwarfs
{
    class Program
    {
        static int[] GoTroughtValey(int numberOfPatterns, int[][] patterns, int[] staticValey)
        {
            
            int[] count = new int[numberOfPatterns];
            for (int i = 0; i < numberOfPatterns; i++)
            {
                int pwalk=0;
                int valeyIndex =0;
                int[] valey =(int[])staticValey.Clone();
                while (true)
                {
                    if (valey[valeyIndex] != 1001 && valeyIndex < valey.Length && valeyIndex >= 0)
                    {
                        count[i] += valey[valeyIndex];
                        valey[valeyIndex] = 1001;
                        valeyIndex += patterns[i][pwalk];
                    }
                    else
                    {
                        break;
                    }
                    pwalk++;
                    if (pwalk >= patterns[i].Length)
                    {
                        pwalk = 0;
                    }
                } 
            }
            return count;
        }


         static int[] InputValey()
        {
            string input = Console.ReadLine();
            string[] inputSplit = input.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            List<int> listValey = new List<int>();
            
            for (int i = 0; i < inputSplit.Length; i++)
            {
                if (inputSplit[i]!=""&&inputSplit[i]!=" ")
                {
                    listValey.Add(int.Parse(inputSplit[i]));
                }
            }
            int[] valey = new int[listValey.Count];
            for (int i = 0; i < valey.Length; i++)
            {
                valey[i] = listValey[i];
            }

                return valey;
        }
      
        static void Main(string[] args)
        {
            int[] valey = InputValey();
            int numberOfPatterns = int.Parse(Console.ReadLine());
            int[][] patterns = new int[numberOfPatterns][];
            for (int i = 0; i < numberOfPatterns; i++)
            {
                patterns[i] = InputValey();
            }
           int[] countGold = GoTroughtValey(numberOfPatterns,patterns,valey);
           Array.Sort(countGold);
           Console.WriteLine(countGold[countGold.Length-1]);
        }
    }
}
