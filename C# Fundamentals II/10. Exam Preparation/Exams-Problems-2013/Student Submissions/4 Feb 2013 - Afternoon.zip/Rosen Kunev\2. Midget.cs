using System;
using System.Collections.Generic;
using System.Text;

class Program
{
    static void Main()
    {
        List<int> valley = new List<int>();
        StringBuilder sb = new StringBuilder();
        string uInput = Console.ReadLine();
        string[] valleyStr = uInput.Split(',');
        for (int i = 0; i < valleyStr.Length; i++)      // Valley input & split
        {
            valley.Add(int.Parse(valleyStr[i]));
        }
        int M = int.Parse(Console.ReadLine());


        List<int> pattern = new List<int>();

        long maxCoins = 0;

        

        for (int i = 0; i < M; i++)
        {
            long coinsCollected = valley[0];
            bool[] visittedCell = new bool[valley.Count];
            int cell = 0;

            uInput = Console.ReadLine();
            string[] patternStr = uInput.Split(',');
            for (int patternStrIndex = 0; patternStrIndex < patternStr.Length; patternStrIndex++)      // Pattern input & split
            {
                pattern.Add(int.Parse(patternStr[patternStrIndex]));
            }
            int patternPosition = 0;
            
                for (int index = 0; index <= pattern[index]; index++)
                {
                    if (cell > valley.Count)
                    {
                        break;
                    }
                    patternPosition = pattern[index];
                    cell += patternPosition;
                    if (visittedCell[cell] == true) 
                    {
                        break;
                    }
                    
                    coinsCollected += valley[cell];
                    visittedCell[cell] = true;

                    if (maxCoins < coinsCollected)
                    {
                        maxCoins = coinsCollected;
                    }
                }
            
            pattern.Clear(); 
            coinsCollected = 0;
            maxCoins = 21;
        }

        Console.WriteLine(maxCoins);
        
    }
}