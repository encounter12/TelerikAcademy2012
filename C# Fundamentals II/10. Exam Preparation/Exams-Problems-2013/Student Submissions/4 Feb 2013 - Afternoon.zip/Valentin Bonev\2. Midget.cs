using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midget
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] valley = {1,3,-6,7,4,1,12};;
            Console.WriteLine("Enter the number of Patterns");
            int n = int.Parse(Console.ReadLine());
            int collected=0;
            int[] patternOne= { 0,1, 2, -3, };
            int[] patternTwo = { 1, 3, -2 };
            int[] patternThree = { 1, -1 };

            for (int i = 0; i < patternOne.Length; i++)
            {
                int item = patternOne[i];
                for (int j = item; j < valley.Length; j++)
                {
                    collected += valley[item];
                   
                } 
                
            }
            Console.WriteLine(collected);
            for (int i = 0; i < 3; ++i)
            {
                for (int j = 0; j < n; ++j)
                {
                    pattern[i, j] = int.parse(console.readline());
                }
            }

            for (int i = 0; i < valley.length; i++)
            {
                console.writeline("enter element № {0}", i + 1);
                valley[i] = int.parse(console.readline());
            }
           
        }
    }
}
