using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem4
{
    class Program
    {
        static void Main()
        {
            char[] delimiters = new char[] { ' ', '\r', '\n' };
            Int16 lineNumber = Int16.Parse(Console.ReadLine());
            Int16 charNumbers = Int16.Parse(Console.ReadLine());

            List<String> sb = new List<String>();
            for (var i = 0; i < lineNumber; i++)
            {
                sb.AddRange(Console.ReadLine().Split(delimiters, StringSplitOptions.RemoveEmptyEntries).ToList());
            }

            //sb.AddRange("we happy few   we band ".Split(delimiters, StringSplitOptions.RemoveEmptyEntries).ToList());
            //sb.AddRange("of brothers for he who sheds".Split(delimiters, StringSplitOptions.RemoveEmptyEntries).ToList());
            //sb.AddRange("his blood".Split(delimiters, StringSplitOptions.RemoveEmptyEntries).ToList());
            //sb.AddRange("with".Split(delimiters, StringSplitOptions.RemoveEmptyEntries).ToList());
            //sb.AddRange("me shall be my brother".Split(delimiters, StringSplitOptions.RemoveEmptyEntries).ToList());

            Console.WriteLine(Text(sb,charNumbers));
        }

        private static string Text(List<string> sb, Int16 charNumbers)
        {
            StringBuilder newSB = new StringBuilder();
            int currentCount = 0;
            for (int i = 0; i < sb.Count; i++)
            {
                currentCount += sb[i].Count()+1;
                if(currentCount <= charNumbers)
                {
                    newSB.Append(sb[i] + " ");
                }
                else
                {
                    newSB.Append("\n");
                    currentCount = 0;
                }
            }
            return newSB.ToString();
        }
    }
}
