using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1111
{
    class Program
    {
        static void Main()
        {
            string[] valley = Console.ReadLine().Split(new string[] {", "}, StringSplitOptions.None);

            int m = int.Parse(Console.ReadLine());
            
            long maxSum = long.MinValue;
            for (int i = 0; i < m; i++)
            {
                string[] valleyCopy = (string[])valley.Clone();

                long sum = 0;
                string[] pattern = Console.ReadLine().Split(new string[] { ", " }, StringSplitOptions.None);

                int valCounter= 0;
                int patCount = 0;
                while ((valCounter < valleyCopy.Length) && (valCounter >= 0) && (valleyCopy[valCounter] != "?"))
                {
                    sum += Convert.ToInt32(valleyCopy[valCounter]);
                    valleyCopy[valCounter] = "?";
                    valCounter += Convert.ToInt32(pattern[patCount]);
                    patCount++;
                    if (patCount >= pattern.Length)
                    {
                        patCount = 0;
                    }
                }
                if (sum > maxSum)
                {
                    maxSum = sum;
                }
            }
            Console.WriteLine(maxSum);
        }
    }
}
