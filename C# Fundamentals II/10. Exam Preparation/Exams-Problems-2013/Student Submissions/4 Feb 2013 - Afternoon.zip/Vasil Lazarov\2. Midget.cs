using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midget
{
    class Program
    {
        static long CollectedCoins(string[] line, int[] path)
        {
            long sum = path[0];
            int move = 0;

            List<int> visited = new List<int>();
            for (int j = 0; j < line.Length; j++)
            {
                int number = int.Parse(line[j]);
                move += number;
                if (move > path.Length - 1 || move <= 0 || visited.Contains(move))
                {
                    break;
                }
                visited.Add(move);
                sum += path[move];
                if (j == line.Length - 1)
                {
                    j = -1;
                }
            }

            return sum;
        }

        static void Main(string[] args)
        {
            string inputPath = Console.ReadLine();
            char[] separator = { ' ', ',' };
            string[] pathString = inputPath.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            int[] path = new int[pathString.Length];
            for (int i = 0; i < pathString.Length; i++)
            {
                path[i] = int.Parse(pathString[i]);
            }
            int m = int.Parse(Console.ReadLine());
            string[] pattern = new string[m];
            for (int i = 0; i < m; i++)
            {
                pattern[i] = Console.ReadLine();
            }
            long maxSum = Int32.MinValue;
            for (int i = 0; i < m; i++)
            {
                string[] line = pattern[i].Split(separator, StringSplitOptions.RemoveEmptyEntries);
                long sum = CollectedCoins(line, path);
                if (sum > maxSum)
                {
                    maxSum = sum;
                }
            }

            Console.WriteLine(maxSum);
        }
    }
}
