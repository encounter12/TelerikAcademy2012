using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AlignBoth
{
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int W = int.Parse(Console.ReadLine());

            StringBuilder sb = new StringBuilder();

            string[] textArray = UserInput(n, sb);

            int[] wordLength = new int[textArray.Length];
            int wordLen = 0;
            for (int i = 0; i < textArray.Length; i++)
			{
			    for (int j = 0; j < textArray[i].Length; j++)
                {
                    wordLen++;
                    
                }
                wordLength[i] = wordLen;
                wordLen = 0;
			}


            




            string output = "U";
            Console.WriteLine(output);

            
            
            
        }

        private static string[] UserInput(int n, StringBuilder sb)
        {
            for (int i = 0; i < n; i++)
            {
                string line = Console.ReadLine();
                line = line.Replace("\n", String.Empty);
                line = line.Replace("\r", String.Empty);
                line = line.Replace("\t", String.Empty);
                sb.Append(line);
                if (i < n - 1)
                {
                    sb.Append(' ');
                }

            }
            string text = sb.ToString();
            string[] textArray = text.Split(' ');
            return textArray;
        }
    }
}
