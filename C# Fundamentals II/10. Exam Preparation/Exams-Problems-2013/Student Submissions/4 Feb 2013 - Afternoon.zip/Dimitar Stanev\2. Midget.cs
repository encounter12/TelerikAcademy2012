using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Task2
    {

        static void Main(string[] args)
        {
            string valley = Console.ReadLine();
            char[] separator = new char[] { ' ', ',' };
            List<int> valleyNumbers = turnSequenceToArray(valley, separator);
            if (valleyNumbers.Count >= 1 && valleyNumbers.Count <= 10000)
            {
                int m = int.Parse(Console.ReadLine());
                if (m >= 1 && m <= 500)
                {
                    List<List<int>> listOfPatterns = new List<List<int>>();
                    for (int i = 0; i < m; i++)
                    {
                        string buffer = Console.ReadLine();
                        List<int> bufferList = turnSequenceToArray(buffer, separator);
                        if (bufferList.Count > 100)
                        {
                            return;
                        }
                        listOfPatterns.Add(bufferList);
                    }
                    
                        if (checkNumbers(valleyNumbers) == false)
                        {
                            return;
                        }

                        for (int i = 0; i < listOfPatterns.Count; i++)
                        {
                            if (checkNumbers(listOfPatterns[i]) == false)
                            {
                                return;
                            }
                        }
                    int maxScore = 0;
                    for (int i = 0; i < listOfPatterns.Count; i++)
                    {
                        if (executePattern(listOfPatterns[i], valleyNumbers) > maxScore)
                        {
                            maxScore = executePattern(listOfPatterns[i], valleyNumbers);
                        }
                    }
                    Console.WriteLine(maxScore);
                }
            }
        }

        private static List<int> turnSequenceToArray(string valley, char[] separator)
        {
            string[] valleyArray = valley.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            List<int> valleyNum = new List<int>();
            for (int i = 0; i < valleyArray.Length; i++)
            {
                valleyNum.Add(Convert.ToInt32(valleyArray[i]));
            }
            return valleyNum;
        }
        
        private static int executePattern(List<int> pattern, List<int> valleyNums )
        {
            int sum = valleyNums[0];
            int currentCell = 0;
            bool[] listOfVisited = new bool[valleyNums.Count*2];
            listOfVisited[0] = true;
            do
            {
                for (int i = 0; i < pattern.Count; i++)
                {
                    if (currentCell + pattern[i] > valleyNums.Count -1  || currentCell + pattern[i] < 1)
                    {
                        goto ReturnSum;
                    }
                    currentCell = currentCell + pattern[i];
                    if (checkForMore(listOfVisited, currentCell) == false)
                    {
                        goto ReturnSum;
                    }
                    listOfVisited[currentCell] = true;
                    sum += valleyNums[currentCell];
                }

            } while (true);

        ReturnSum: { return sum; }
        }
        private static bool checkForMore(bool[] visited, int currCell)
        {
            bool available = true;
            if (visited[currCell] == true)
            {
                available = false;
            }
            return available;
        }
        private static bool checkNumbers ( List<int> newList )
        {
            bool valid = true;
            for ( int i = 0; i < newList.Count; i++)
            {
                if (newList[i] < -1000 || newList[i] > 1000)
                {
                    valid = false;
                }
            }
            return valid;
        }
    }
}
