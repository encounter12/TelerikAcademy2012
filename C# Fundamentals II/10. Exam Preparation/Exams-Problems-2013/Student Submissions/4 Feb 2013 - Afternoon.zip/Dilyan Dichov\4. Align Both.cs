using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class Align
{

    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        int w = int.Parse(Console.ReadLine());

        List<string> words = new List<string>();
        List<string> lines = new List<string>();
        StringBuilder sb = new StringBuilder();
        StringBuilder currentLine = new StringBuilder();
        char space = ' ';

        for (int i = 0; i < n; i++)
        {
            string line = Console.ReadLine();
            string[] readedWords = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var word in readedWords)
            {
                words.Add(word);
            }
        }
        int wordIndex = 0;
        
        
        while (wordIndex<words.Count)
        {
            int counter = 1;
            int start=wordIndex;
            sb.Append(words[start]);
            currentLine.Append(words[start]);
            while (true) //sb.Length<=w
            {
                if (start+1>=words.Count)
                {
                    lines.Add(currentLine.ToString());
                    sb.Clear();
                    currentLine.Clear();
                    wordIndex=start+1;
                    break;
                }
                if ((sb.Length+words[start+1].Length+1)<=w)
                {
                    start++;
                    sb.Append(space);
                    sb.Append(words[start]);
                    counter++;
                }
                    else if (counter==1)
	            {
                        lines.Add(currentLine.ToString());
                        sb.Clear();
                        currentLine.Clear();
                        wordIndex=start+1;
                        break;
	            }
                else
                {
                    int minSpace = (w - sb.Length ) / (counter - 1);
                    int s1 = (w - sb.Length ) % (counter - 1);
                    string sp1 = new string(' ', minSpace + 1);
                    string sp2 = new string(' ', minSpace);
                    for (int j = 1; j < counter; j++)
                    {
                        if (j<=(counter - 1-s1))
                        {
                            currentLine.Append(sp1);
                        }
                        else
                        {
                            currentLine.Append(sp1);
                        }
                        currentLine.Append(words[wordIndex + j]);
                    }
                    lines.Add(currentLine.ToString());
                    sb.Clear();
                    currentLine.Clear();
                    wordIndex = start + 1;
                    break;
                }
            }
            //  posledna duma ?

        }//end 1 

        foreach (var line in lines)
        {
            Console.WriteLine(line);
        }
    }
}
