using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem2
{
    class Problem2
    {
        static void Main(string[] args)
        {

            string valleyStr = Console.ReadLine();
            string[] valleySplit = valleyStr.Split(',');
            int[] valleyNums = new int[valleySplit.Length];

            for (int i = 0; i < valleySplit.Length; i++)
            {
                valleyNums[i] = int.Parse(valleySplit[i].Trim());
            }

            int m = int.Parse(Console.ReadLine());
            int[][] pattern = new int[m][];
            for (int i = 0; i < m; i++)
            {
                string[] patternStr = (Console.ReadLine()).Split(',');
                pattern[i] = new int[patternStr.Length];
                for (int j = 0; j < patternStr.Length; j++)
                {
                    pattern[i][j] = int.Parse(patternStr[j].Trim());
                }
            }
            int[] valleyNumsCopy = new int[valleyNums.Length];
            for (int i = 0; i < valleyNums.Length; i++)
            {
                valleyNumsCopy[i] = valleyNums[i];
            }

            int coinsSum = 0;
            int position = 0;  
            int maxSum = Int32.MinValue;

            for (int i = 0; i < m; i++)
            {
                position = 0;
                coinsSum = 0;
                int step = -1;

                while (true)
                {
                    if (valleyNumsCopy[position] == 0)
                    {
                        break;
                    }
                    coinsSum += valleyNumsCopy[position];
                    valleyNumsCopy[position] = 0;
                    step++;
                    position += pattern[i][step % pattern[i].Length];
                    if (position >= valleyNums.Length || position < 0)
                    {
                        break;
                    }
                }
                for (int index = 0; index < valleyNums.Length; index++)
                {
                    valleyNumsCopy[index] = valleyNums[index];
                }
                if (coinsSum > maxSum)
                {
                    maxSum = coinsSum;
                }
            }
            Console.WriteLine(maxSum);
        }
    }
}