using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midget
{
    class Midget
    {
        static void Main(string[] args)
        {
            //string valeyString = "1, 3, -6, 7, 4, 1, 12";
            string valeyString = Console.ReadLine();
            //int m = 3;
            int m = int.Parse(Console.ReadLine());
            string[] patternString = new string[m];
            for (int i = 0; i < m; i++)
            {
                patternString[i] = Console.ReadLine();
            }
            //patternString[0] = "1, 2, -3";
            //patternString[1] = "1, 3, -2";
            //patternString[2] = "1, -1";
            int[] valey = ExtractNumbers(valeyString);
            int track = 0;
            int coinSum = 0;
            int maxSum = int.MinValue; //Make it minvalue later.
            for (int j = 0; j < m; j++)
            {
                int[] currentTrack = ExtractNumbers(patternString[j]);
            repeat:
                for (int i = 0; i < currentTrack.Length; i++)
                {
                    try
                    {
                        coinSum += valey[track + currentTrack[i]];
                        track += currentTrack[i];
                        if ((track == 0) || (track == valey.Length))
                        {
                            break;
                        }
                        else
                        {
                            continue;
                        }
                    }
                    catch (Exception)
                    {
                        break;
                    }
                }
                if (maxSum < coinSum)
                {
                    maxSum = coinSum;
                }
                coinSum = 0;
                track = 0;
            }
            Console.WriteLine(maxSum);
        }
        static int[] ExtractNumbers(string str)
        {
            string[] split = str.Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            int[] result = new int[split.Length];
            for (int i = 0; i < split.Length; i++)
            {
                result[i] = int.Parse(split[i]);
            }
            return result;
        }
    }
}
