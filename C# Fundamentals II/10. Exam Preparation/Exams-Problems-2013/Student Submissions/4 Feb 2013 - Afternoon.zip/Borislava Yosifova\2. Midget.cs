using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02Midget
{
    class Program
    {
        static int MaxCoins = -1000; 
        static void Main(string[] args)
        {
            string valleyStr = Console.ReadLine();

            string[] temp = valleyStr.Split(',');

            int[] valley = new int[temp.Length];
            for (int i = 0; i < temp.Length; i++)
            {
                valley[i] = int.Parse(temp[i].Trim());
            }

            List<string> patternStr = new List<string>();
            
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string str = Console.ReadLine();
                patternStr.Add(str);
            }

            
            for (
                int i = 0; i < patternStr.Count; i++)
			{
                string[] temp2 = new string[patternStr[i].Length];
			     temp2 = patternStr[i].Split(',');
                 int[] pattern = new int[temp2.Length];
                for (int j = 0; j < temp2.Length; j++)
                {
                    pattern[j] = int.Parse(temp2[j].Trim());
                }
                GetCoins(valley, pattern);
			}
            Console.WriteLine(MaxCoins);
            
            
        }
        static void GetCoins(int[] valley, int[] pattern)
        {
            int coins = 0;
            int brum = 0;
            int i = 0;

            bool[] isHere = new bool[valley.Length];

            for (int j = 0; j < isHere.Length; j++)
            {
                isHere[i] = false;
            }
            while (true)
            {
                if (isHere[brum] == false)
                {
                    coins += valley[brum];
                    isHere[brum] = true;
                    brum += pattern[i];
                    i++;
                    if (i >= pattern.Length)
                    {
                        i = 0;
                    }
                    if (brum >= valley.Length || brum < 0)
                    {
                        break;
                    }
                }
                else 
                {
                    break;
                }
            }

            if (coins > MaxCoins)
            {
                MaxCoins = coins;
            }
        }
    }
}
