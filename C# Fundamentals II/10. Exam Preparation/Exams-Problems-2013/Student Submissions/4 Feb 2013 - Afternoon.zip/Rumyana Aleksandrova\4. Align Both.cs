using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

class AlignBothLikeClearCode
{
   
    static void Main(string[] args)
    {
        StringBuilder code = new StringBuilder();
        int linesCount = int.Parse(Console.ReadLine());
        int lineWidth = int.Parse(Console.ReadLine());
        string word = string.Empty;

        for (int i = 0; i < linesCount; i++)
        {
            string line = Console.ReadLine();
            line = System.Text.RegularExpressions.Regex.Replace(line, @"\s+", " ");
            line = word + line;
            word = string.Empty;
            if (line.Length > lineWidth)
            {
                int lastSpace = line.LastIndexOf(" ");
                int len = line.Length - lastSpace;
                word = line.Substring(lastSpace+1, len-1)+" ";
                line = line.Substring(0, lastSpace);
            } 
            while (line.Length <= lineWidth)
            {
                int firstSpace = line.IndexOf(" ");
                int len = line.Length - firstSpace;
                line = line.Insert(firstSpace+1," ");
            }
            code.AppendLine(line);
           } Console.WriteLine();

        StringReader sr = new StringReader(code.ToString());
        string lineToPrint = null;
        while ((lineToPrint = sr.ReadLine()) != null)
        {
            if (!string.IsNullOrWhiteSpace(lineToPrint))
            {
                Console.WriteLine(lineToPrint);
            }
        }
    }
   
}
        

    

