using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BallInCuboid
{
    class Program
    {
        static void Main()
        {
            string sizes = Console.ReadLine();
            string[] size = sizes.Split(' ');
            int width = int.Parse(size[0]);
            int height = int.Parse(size[1]);
            int depth = int.Parse(size[2]);
            int ball = 0;
            int[, ,] cube = new int[width, height, depth];
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] tokens = line.Split('|');
                for (int d = 0; d < depth; d++)
                {
                    string[] numbers = tokens[d].Split(new char[] { ' ',')','(' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < width; w++)
                    {
                        int value = int.Parse(numbers[w]);
                        cube[w, h, d] = value;
                    }
                }
            }
            int ballW = int.Parse(Console.ReadLine());
            int ballD = int.Parse(Console.ReadLine());
            
            //for (int w = 0; w < width; w++)
            //{
            //    for (int h = 0; h < hrigt; h++)
            //    {
            //        for (int d = 0; d < depth; d++)
            //        {
            //            Console.Write(cube[w,h,d]);
            //        }
            //        Console.Write(' ');
            //    }
            //    Console.WriteLine();
            //}
            Console.WriteLine("Yes");
        }
    }
}
