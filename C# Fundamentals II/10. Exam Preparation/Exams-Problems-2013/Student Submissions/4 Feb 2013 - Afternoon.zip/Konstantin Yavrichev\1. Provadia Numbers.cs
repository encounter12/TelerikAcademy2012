using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01
{
    class Program
    {
        public static void Main()
        {
            decimal imputeValue = decimal.Parse(Console.ReadLine()) ;
            char charValue;
            char charValue1;
            char charValue2;
            char charValue3;
            decimal values1;
            decimal values2;
            decimal values3;

            if (imputeValue >= 0 && imputeValue <= 26)
            {
                    values2 = imputeValue+65;
                    charValue = (char)values2;
                    Console.WriteLine(charValue);
                }

            if (imputeValue >= 27 && imputeValue <= 701)
            {
                int trunc1 = (int)imputeValue/26;

                values1 = trunc1  + 96;
                values2 = imputeValue - (trunc1*26) + 65;
                //Console.WriteLine(values2);
                
                charValue1 = (char)values1;
                charValue2 = (char)values2;
                //charValue = charValue1 + charValue2;
                Console.WriteLine("{0,1}{1,1}", charValue1, charValue2);
            }

            if (imputeValue >= 702 && imputeValue <= 17602)
            {
                int trunc1 = (int)imputeValue / 26;

                values1 = trunc1 + 65;
                values2 = imputeValue - (trunc1 * 26) + 65;
                //Console.WriteLine(values2);

                charValue1 = (char)values1;
                charValue2 = (char)values2;
                //charValue = charValue1 + charValue2;
                Console.WriteLine("{0,1}{1,1}", charValue1, charValue2);
            }
            /*
            {
                int trunc1 = (int)imputeValue / 26;

                values1 = imputeValue - (trunc1 * 26) + 64;
                values2 = trunc1 + 96;
                values3 = imputeValue - (trunc1 * 26) + 64;
                Console.WriteLine(values2);

                charValue1 = (char)values1;
                charValue2 = (char)values2;
                charValue3 = (char)values3;
                //charValue = charValue1 + charValue2;
                Console.WriteLine("{0,1}{1,1}{2,1}", charValue1, charValue2, charValue3);
            }
                */
        }
    }
}
