using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;


class DecimalToHex
{
    static void Main()
    {
        ulong n = ulong.Parse(Console.ReadLine());
        StringBuilder hex = new StringBuilder();
        ulong newNum = n;
        ulong carry=0;

        if (n == 0)
        {
            Console.WriteLine('A');
        }
        else
        {
            for (ulong i = 256; newNum != 0; i = 256)
            {
                carry = newNum % i;
                newNum = newNum / i;
                if (carry >= 0 && carry <= 255)
                {
                    switch (carry)
                    {
                        case 0: hex.Append('A'); break;
                        case 1: hex.Append('B'); break;
                        case 2: hex.Append('C'); break;
                        case 3: hex.Append('D'); break;
                        case 4: hex.Append('E'); break;
                        case 5: hex.Append('F'); break;
                        case 6: hex.Append('G'); break;
                        case 7: hex.Append('H'); break;
                        case 8: hex.Append('I'); break;
                        case 9: hex.Append('J'); break;
                        case 10: hex.Append('K'); break;
                        case 11: hex.Append('L'); break;
                        case 12: hex.Append('M'); break;
                        case 13: hex.Append('N'); break;
                        case 14: hex.Append('O'); break;
                        case 15: hex.Append('P'); break;
                        case 16: hex.Append('Q'); break;
                        case 17: hex.Append('R'); break;
                        case 18: hex.Append('S'); break;
                        case 19: hex.Append('T'); break;
                        case 20: hex.Append('U'); break;
                        case 21: hex.Append('V'); break;
                        case 22: hex.Append('W'); break;
                        case 23: hex.Append('X'); break;
                        case 24: hex.Append('Y'); break;
                        case 25: hex.Append('Z'); break;
                        case 26: hex.Append('A'); hex.Append('a'); break;
                        case 27: hex.Append('B'); hex.Append('a'); break;
                        case 28: hex.Append('C'); hex.Append('a'); break;
                        case 29: hex.Append('D'); hex.Append('a'); break;
                        case 30: hex.Append('E'); hex.Append('a'); break;
                        case 31: hex.Append('F'); hex.Append('a'); break;
                        case 32: hex.Append('G'); hex.Append('a'); break;
                        case 33: hex.Append('H'); hex.Append('a'); break;
                        case 34: hex.Append('I'); hex.Append('a'); break;
                        case 35: hex.Append('J'); hex.Append('a'); break;
                        case 36: hex.Append('K'); hex.Append('a'); break;
                        case 37: hex.Append('L'); hex.Append('a'); break;
                        case 38: hex.Append('M'); hex.Append('a'); break;
                        case 39: hex.Append('N'); hex.Append('a'); break;
                        case 40: hex.Append('O'); hex.Append('a'); break;
                        case 41: hex.Append('P'); hex.Append('a'); break;
                        case 42: hex.Append('Q'); hex.Append('a'); break;
                        case 43: hex.Append('R'); hex.Append('a'); break;
                        case 44: hex.Append('S'); hex.Append('a'); break;
                        case 45: hex.Append('T'); hex.Append('a'); break;
                        case 46: hex.Append('U'); hex.Append('a'); break;
                        case 47: hex.Append('V'); hex.Append('a'); break;
                        case 48: hex.Append('W'); hex.Append('a'); break;
                        case 49: hex.Append('X'); hex.Append('a'); break;
                        case 50: hex.Append('Y'); hex.Append('a'); break;
                        case 51: hex.Append('Z'); hex.Append('a'); break;
                        case 52: hex.Append('A'); hex.Append('b'); break;
                        case 53: hex.Append('B'); hex.Append('b'); break;
                        case 54: hex.Append('C'); hex.Append('b'); break;
                        case 55: hex.Append('D'); hex.Append('b'); break;
                        case 56: hex.Append('E'); hex.Append('b'); break;
                        case 57: hex.Append('F'); hex.Append('b'); break;
                        case 58: hex.Append('G'); hex.Append('b'); break;
                        case 59: hex.Append('H'); hex.Append('b'); break;
                        case 60: hex.Append('I'); hex.Append('b'); break;
                        case 61: hex.Append('J'); hex.Append('b'); break;
                        case 62: hex.Append('K'); hex.Append('b'); break;
                        case 63: hex.Append('L'); hex.Append('b'); break;
                        case 64: hex.Append('M'); hex.Append('b'); break;
                        case 65: hex.Append('N'); hex.Append('b'); break;
                        case 66: hex.Append('O'); hex.Append('b'); break;
                        case 67: hex.Append('P'); hex.Append('b'); break;
                        case 68: hex.Append('Q'); hex.Append('b'); break;
                        case 69: hex.Append('R'); hex.Append('b'); break;
                        case 70: hex.Append('S'); hex.Append('b'); break;
                        case 71: hex.Append('T'); hex.Append('b'); break;
                        case 72: hex.Append('U'); hex.Append('b'); break;
                        case 73: hex.Append('V'); hex.Append('b'); break;
                        case 74: hex.Append('W'); hex.Append('b'); break;
                        case 75: hex.Append('X'); hex.Append('b'); break;
                        case 76: hex.Append('Y'); hex.Append('b'); break;
                        case 77: hex.Append('Z'); hex.Append('b'); break;
                        case 78: hex.Append('A'); hex.Append('c'); break;
                        case 79: hex.Append('B'); hex.Append('c'); break;
                        case 80: hex.Append('C'); hex.Append('c'); break;
                        case 81: hex.Append('D'); hex.Append('c'); break;
                        case 82: hex.Append('E'); hex.Append('c'); break;
                        case 83: hex.Append('F'); hex.Append('c'); break;
                        case 84: hex.Append('G'); hex.Append('c'); break;
                        case 85: hex.Append('H'); hex.Append('c'); break;
                        case 86: hex.Append('I'); hex.Append('c'); break;
                        case 87: hex.Append('J'); hex.Append('c'); break;
                        case 88: hex.Append('K'); hex.Append('c'); break;
                        case 89: hex.Append('L'); hex.Append('c'); break;
                        case 90: hex.Append('M'); hex.Append('c'); break;
                        case 91: hex.Append('N'); hex.Append('c'); break;
                        case 92: hex.Append('O'); hex.Append('c'); break;
                        case 93: hex.Append('P'); hex.Append('c'); break;
                        case 94: hex.Append('Q'); hex.Append('c'); break;
                        case 95: hex.Append('R'); hex.Append('c'); break;
                        case 96: hex.Append('S'); hex.Append('c'); break;
                        case 97: hex.Append('T'); hex.Append('c'); break;
                        case 98: hex.Append('U'); hex.Append('c'); break;
                        case 99: hex.Append('V'); hex.Append('c'); break;
                        case 100: hex.Append('W'); hex.Append('c'); break;
                        case 101: hex.Append('X'); hex.Append('c'); break;
                        case 102: hex.Append('Y'); hex.Append('c'); break;
                        case 103: hex.Append('Z'); hex.Append('c'); break;
                        case 104: hex.Append('A'); hex.Append('d'); break;
                        case 105: hex.Append('B'); hex.Append('d'); break;
                        case 106: hex.Append('C'); hex.Append('d'); break;
                        case 107: hex.Append('D'); hex.Append('d'); break;
                        case 108: hex.Append('E'); hex.Append('d'); break;
                        case 109: hex.Append('F'); hex.Append('d'); break;
                        case 110: hex.Append('G'); hex.Append('d'); break;
                        case 111: hex.Append('H'); hex.Append('d'); break;
                        case 112: hex.Append('I'); hex.Append('d'); break;
                        case 113: hex.Append('G'); hex.Append('d'); break;
                        case 114: hex.Append('K'); hex.Append('d'); break;
                        case 115: hex.Append('L'); hex.Append('d'); break;
                        case 116: hex.Append('M'); hex.Append('d'); break;
                        case 117: hex.Append('N'); hex.Append('d'); break;
                        case 118: hex.Append('O'); hex.Append('d'); break;
                        case 119: hex.Append('P'); hex.Append('d'); break;
                        case 120: hex.Append('Q'); hex.Append('d'); break;
                        case 121: hex.Append('R'); hex.Append('d'); break;
                        case 122: hex.Append('S'); hex.Append('d'); break;
                        case 123: hex.Append('T'); hex.Append('d'); break;
                        case 124: hex.Append('U'); hex.Append('d'); break;
                        case 125: hex.Append('V'); hex.Append('d'); break;
                        case 126: hex.Append('W'); hex.Append('d'); break;
                        case 127: hex.Append('X'); hex.Append('d'); break;
                        case 128: hex.Append('Y'); hex.Append('d'); break;
                        case 129: hex.Append('Z'); hex.Append('d'); break;
                        case 130: hex.Append('A'); hex.Append('e'); break;
                        case 131: hex.Append('B'); hex.Append('e'); break;
                        case 132: hex.Append('C'); hex.Append('e'); break;
                        case 133: hex.Append('D'); hex.Append('e'); break;
                        case 134: hex.Append('E'); hex.Append('e'); break;
                        case 135: hex.Append('F'); hex.Append('e'); break;
                        case 136: hex.Append('G'); hex.Append('e'); break;
                        case 137: hex.Append('H'); hex.Append('e'); break;
                        case 138: hex.Append('I'); hex.Append('e'); break;
                        case 139: hex.Append('G'); hex.Append('e'); break;
                        case 140: hex.Append('K'); hex.Append('e'); break;
                        case 141: hex.Append('L'); hex.Append('e'); break;
                        case 142: hex.Append('M'); hex.Append('e'); break;
                        case 143: hex.Append('N'); hex.Append('e'); break;
                        case 144: hex.Append('O'); hex.Append('e'); break;
                        case 145: hex.Append('P'); hex.Append('e'); break;
                        case 146: hex.Append('Q'); hex.Append('e'); break;
                        case 147: hex.Append('R'); hex.Append('e'); break;
                        case 148: hex.Append('S'); hex.Append('e'); break;
                        case 149: hex.Append('T'); hex.Append('e'); break;
                        case 150: hex.Append('U'); hex.Append('e'); break;
                        case 151: hex.Append('V'); hex.Append('e'); break;
                        case 152: hex.Append('W'); hex.Append('e'); break;
                        case 153: hex.Append('X'); hex.Append('e'); break;
                        case 154: hex.Append('Y'); hex.Append('e'); break;
                        case 155: hex.Append('Z'); hex.Append('e'); break;
                        case 156: hex.Append('A'); hex.Append('f'); break;
                        case 157: hex.Append('B'); hex.Append('f'); break;
                        case 158: hex.Append('C'); hex.Append('f'); break;
                        case 159: hex.Append('D'); hex.Append('f'); break;
                        case 160: hex.Append('E'); hex.Append('f'); break;
                        case 161: hex.Append('F'); hex.Append('f'); break;
                        case 162: hex.Append('G'); hex.Append('f'); break;
                        case 163: hex.Append('H'); hex.Append('f'); break;
                        case 164: hex.Append('I'); hex.Append('f'); break;
                        case 165: hex.Append('G'); hex.Append('f'); break;
                        case 166: hex.Append('K'); hex.Append('f'); break;
                        case 167: hex.Append('L'); hex.Append('f'); break;
                        case 168: hex.Append('M'); hex.Append('f'); break;
                        case 169: hex.Append('N'); hex.Append('f'); break;
                        case 170: hex.Append('O'); hex.Append('f'); break;
                        case 171: hex.Append('P'); hex.Append('f'); break;
                        case 172: hex.Append('Q'); hex.Append('f'); break;
                        case 173: hex.Append('R'); hex.Append('f'); break;
                        case 174: hex.Append('S'); hex.Append('f'); break;
                        case 175: hex.Append('T'); hex.Append('f'); break;
                        case 176: hex.Append('U'); hex.Append('f'); break;
                        case 177: hex.Append('V'); hex.Append('f'); break;
                        case 178: hex.Append('W'); hex.Append('f'); break;
                        case 179: hex.Append('X'); hex.Append('f'); break;
                        case 180: hex.Append('Y'); hex.Append('f'); break;
                        case 181: hex.Append('Z'); hex.Append('f'); break;
                        case 182: hex.Append('A'); hex.Append('g'); break;
                        case 183: hex.Append('B'); hex.Append('g'); break;
                        case 184: hex.Append('C'); hex.Append('g'); break;
                        case 185: hex.Append('D'); hex.Append('g'); break;
                        case 186: hex.Append('E'); hex.Append('g'); break;
                        case 187: hex.Append('F'); hex.Append('g'); break;
                        case 188: hex.Append('G'); hex.Append('g'); break;
                        case 189: hex.Append('H'); hex.Append('g'); break;
                        case 190: hex.Append('I'); hex.Append('g'); break;
                        case 191: hex.Append('G'); hex.Append('g'); break;
                        case 192: hex.Append('K'); hex.Append('g'); break;
                        case 193: hex.Append('L'); hex.Append('g'); break;
                        case 194: hex.Append('M'); hex.Append('g'); break;
                        case 195: hex.Append('N'); hex.Append('g'); break;
                        case 196: hex.Append('O'); hex.Append('g'); break;
                        case 197: hex.Append('P'); hex.Append('g'); break;
                        case 198: hex.Append('Q'); hex.Append('g'); break;
                        case 199: hex.Append('R'); hex.Append('g'); break;
                        case 200: hex.Append('S'); hex.Append('g'); break;
                        case 201: hex.Append('T'); hex.Append('g'); break;
                        case 202: hex.Append('U'); hex.Append('g'); break;
                        case 203: hex.Append('V'); hex.Append('g'); break;
                        case 204: hex.Append('W'); hex.Append('g'); break;
                        case 205: hex.Append('X'); hex.Append('g'); break;
                        case 206: hex.Append('Y'); hex.Append('g'); break;
                        case 207: hex.Append('Z'); hex.Append('g'); break;
                        case 208: hex.Append('A'); hex.Append('h'); break;
                        case 209: hex.Append('B'); hex.Append('h'); break;
                        case 210: hex.Append('C'); hex.Append('h'); break;
                        case 211: hex.Append('D'); hex.Append('h'); break;
                        case 212: hex.Append('E'); hex.Append('h'); break;
                        case 213: hex.Append('F'); hex.Append('h'); break;
                        case 214: hex.Append('G'); hex.Append('h'); break;
                        case 215: hex.Append('H'); hex.Append('h'); break;
                        case 216: hex.Append('I'); hex.Append('h'); break;
                        case 217: hex.Append('G'); hex.Append('h'); break;
                        case 218: hex.Append('K'); hex.Append('h'); break;
                        case 219: hex.Append('L'); hex.Append('h'); break;
                        case 220: hex.Append('M'); hex.Append('h'); break;
                        case 221: hex.Append('N'); hex.Append('h'); break;
                        case 222: hex.Append('O'); hex.Append('h'); break;
                        case 223: hex.Append('P'); hex.Append('h'); break;
                        case 224: hex.Append('Q'); hex.Append('h'); break;
                        case 225: hex.Append('R'); hex.Append('h'); break;
                        case 226: hex.Append('S'); hex.Append('h'); break;
                        case 227: hex.Append('T'); hex.Append('h'); break;
                        case 228: hex.Append('U'); hex.Append('h'); break;
                        case 229: hex.Append('V'); hex.Append('h'); break;
                        case 230: hex.Append('W'); hex.Append('h'); break;
                        case 231: hex.Append('X'); hex.Append('h'); break;
                        case 232: hex.Append('Y'); hex.Append('h'); break;
                        case 233: hex.Append('Z'); hex.Append('h'); break;
                        case 234: hex.Append('A'); hex.Append('i'); break;
                        case 235: hex.Append('B'); hex.Append('i'); break;
                        case 236: hex.Append('C'); hex.Append('i'); break;
                        case 237: hex.Append('D'); hex.Append('i'); break;
                        case 238: hex.Append('E'); hex.Append('i'); break;
                        case 239: hex.Append('F'); hex.Append('i'); break;
                        case 240: hex.Append('G'); hex.Append('i'); break;
                        case 241: hex.Append('H'); hex.Append('i'); break;
                        case 242: hex.Append('I'); hex.Append('i'); break;
                        case 243: hex.Append('G'); hex.Append('i'); break;
                        case 244: hex.Append('K'); hex.Append('i'); break;
                        case 245: hex.Append('L'); hex.Append('i'); break;
                        case 246: hex.Append('M'); hex.Append('i'); break;
                        case 247: hex.Append('N'); hex.Append('i'); break;
                        case 248: hex.Append('O'); hex.Append('i'); break;
                        case 249: hex.Append('P'); hex.Append('i'); break;
                        case 250: hex.Append('Q'); hex.Append('i'); break;
                        case 251: hex.Append('R'); hex.Append('i'); break;
                        case 252: hex.Append('S'); hex.Append('i'); break;
                        case 253: hex.Append('T'); hex.Append('i'); break;
                        case 254: hex.Append('U'); hex.Append('i'); break;
                        case 255: hex.Append('V'); hex.Append('i'); break;
                    }
                }
                else
                {
                    hex.Append(carry);
                }
            }
        }
        
        for (int i = hex.Length-1; i >= 0; i--)
        {
            Console.Write(hex[i]);
        }
        
    }
}
