using System;
using System.Collections.Generic;

class Midget
{
    static void Main()
    {
        //Input valley
        string valleyStr = Console.ReadLine();
        string[] valStr = valleyStr.Split(',');
        int[] valley = new int[valStr.Length];
        for (int i = 0; i < valStr.Length; i++)
        {
            valStr[i] = valStr[i].Trim();
            valley[i] = int.Parse(valStr[i]);
        }
        //End Input Valley
        //INput pattern number
        int m = int.Parse(Console.ReadLine());
        //END INput pattern number
        //Input Patterns
        string[] diffternPattern = new string[m];
        for (int i = 0; i < m; i++)
        {
            diffternPattern[i] = Console.ReadLine();
        }
        //for (int i = 0; i < m; i++)
        //{
        //    Console.WriteLine(diffternPattern[i]);
        //}


        //
        int bestSum = 0;
        for (int i = 0; i < m; i++)
        {
            string[] curPatternStr = diffternPattern[i].Split(',');
            int[] curPattern = new int[curPatternStr.Length];
            for (int j = 0; j < curPatternStr.Length; j++)
            {
                curPattern[j] = int.Parse(curPatternStr[j].Trim());
                // Console.WriteLine(curPattern[j]);
            }


            //imame current pattern
            int curSum = 0;
            int lastIndex = 0;
            if (SumOfPatt(curPattern) == 0)
            {
                for (int pattIndex = 0; pattIndex < curPattern.Length; pattIndex++)
                {
                    curSum = curSum + valley[lastIndex + curPattern[pattIndex]];
                    lastIndex = lastIndex + curPattern[pattIndex];

                }
                if (bestSum < curSum) bestSum = curSum;
                curSum = 0;
            }
            else
            {
                int nextIndex = 0;
                int patternIndex = 0;
                while (nextIndex >= 0 || nextIndex < valley.Length - 1)
                {
                    if (nextIndex < 0 || nextIndex > valley.Length - 1)
                    {

                        break;
                    }
                    curSum += valley[nextIndex];
                    valley[nextIndex] = 0;
                    // Console.WriteLine(valley[nextIndex]);
                    nextIndex += curPattern[patternIndex];
                    if (nextIndex < 0 || nextIndex > valley.Length - 1)
                    {

                        break;
                    }

                    if (patternIndex + 1 == curPattern.Length)
                    {
                        patternIndex = 0;

                    }
                    else
                    {
                        patternIndex++;
                    }

                    if (bestSum < curSum) bestSum = curSum;

                }

            }
            //
        }

        //
        Console.WriteLine(bestSum);
        //ENDInput Patterns
    }


    static int SumOfPatt(int[] arr)
    {
        int sum = 0;
        for (int i = 0; i < arr.Length; i++)
        {
            sum += arr[i];
        }
        return sum;
    }


}