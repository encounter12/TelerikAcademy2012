using System;
using System.Numerics;
using System.Text;

class ProvadiaNumbers
{
    static void Main()
    {
        BigInteger input;
        BigInteger.TryParse(Console.ReadLine(), out input);

        StringBuilder result = new StringBuilder();

        while (input > 0)
        {
            result.Insert(0, GetChar((byte)(input % 256)));
            input /= 256;
        }

        Console.WriteLine(result.ToString());
    }

    private static string GetChar(byte num)
    {
        StringBuilder sb = new StringBuilder();

        int first = (num/26);
        if (first != 0) sb.Append((char)(first+96));
        int second =  (num%26) + 65;

        sb.Append((char)second);

        return sb.ToString();
    }
}

