using System;
using System.Linq;


class Program
{
    static void Main()
    {
#if DEBUG
        Console.SetIn(new System.IO.StreamReader("../../input.txt"));
#endif
        long finalResult = 0;
        long result = 0;
        string valley = Console.ReadLine();
        string[] valleyNumbersString = valley.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
        long[] valleyNumbers = new long[valleyNumbersString.Length];
        bool[] visited = new bool[valleyNumbersString.Length];
        for (int i = 0; i < valleyNumbersString.Length; i++)
        {
            valleyNumbers[i] = long.Parse(valleyNumbersString[i]);
        }


        long numberOfPatterns = long.Parse(Console.ReadLine());
        long[][] patterns = new long[(int)numberOfPatterns][];

        for (int i = 0; i < numberOfPatterns; i++)
        {
            string pattern = Console.ReadLine();
            string[] patternNumbersString = pattern.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

            patterns[i] = new long[patternNumbersString.Length];

            for (int j = 0; j < patternNumbersString.Length; j++)
            {
                patterns[i][j] = long.Parse(patternNumbersString[j]);
            }
        }

        long maximumResult = long.MinValue;
        long index = 0;

        bool escape = false;

        for (int pattern = 0; pattern < patterns.Length; pattern++)
        {
            index = 0;
            while (true)
            {
                for (int patternIndex = 0; patternIndex < patterns[pattern].Length; patternIndex++)
                {
                    if (index >= valleyNumbers.Length || index < 0 || visited[index])
                    {
                        if (result > maximumResult)
                        {
                            maximumResult = result;
                        }
                        escape = true;
                        break;
                    }
                    result += valleyNumbers[index];
                    visited[index] = true;
                    index += patterns[pattern][patternIndex];
                }
                if (escape)
                {
                    escape = false;
                    visited = new bool[valleyNumbersString.Length];
                    result = 0;
                    break;
                }
            }
        }

        Console.WriteLine(maximumResult);
    }
}
