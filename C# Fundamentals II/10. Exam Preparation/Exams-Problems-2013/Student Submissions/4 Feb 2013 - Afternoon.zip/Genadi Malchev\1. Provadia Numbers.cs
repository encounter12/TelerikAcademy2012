using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
 
class Program
{
    static void Main()
    {
        int numbers =int.Parse(Console.ReadLine());
        string ancer = string.Empty;
 
        while (numbers / 256 >= 1)
        {
            int div = numbers / 256;
 
            switch (div)
            {
                case 0: ancer += 'A'; numbers -= div * 256; break;
                case 1: ancer += 'B'; numbers -= div * 256; break;
                case 2: ancer += 'C'; numbers -= div * 256; break;
                case 3: ancer += 'D'; numbers -= div * 256; break;
                case 4: ancer += 'E'; numbers -= div * 256; break;
                case 5: ancer += 'F'; numbers -= div * 256; break;
                case 6: ancer += 'G'; numbers -= div * 256; break;
                case 7: ancer += 'H'; numbers -= div * 256; break;
                case 8: ancer += 'I'; numbers -= div * 256; break;
                case 9: ancer += 'J'; numbers -= div * 256; break;
                case 10: ancer += 'K'; numbers -= div * 256; break;
                case 11: ancer += 'L'; numbers -= div * 256; break;
                case 12: ancer += 'M'; numbers -= div * 256; break;
                case 13: ancer += 'N'; numbers -= div * 256; break;
                case 14: ancer += 'O'; numbers -= div * 256; break;
                case 15: ancer += 'P'; numbers -= div * 256; break;
                case 16: ancer += 'Q'; numbers -= div * 256; break;
                case 17: ancer += 'R'; numbers -= div * 256; break;
                case 18: ancer += 'S'; numbers -= div * 256; break;
                case 19: ancer += 'T'; numbers -= div * 256; break;
                case 20: ancer += 'U'; numbers -= div * 256; break;
                case 21: ancer += 'V'; numbers -= div * 256; break;
                case 22: ancer += 'W'; numbers -= div * 256; break;
                case 23: ancer += 'X'; numbers -= div * 256; break;
                case 24: ancer += 'Y'; numbers -= div * 256; break;
                case 25: ancer += 'Z'; numbers -= div * 256; break;
                default:
                    break;
            }
        }
        while (numbers / 26 >= 1)
        {
          int div2 = numbers / 26;
 
          switch (div2)
          {
              case 1: ancer += 'a'; numbers -= div2 * 26; break;
              case 2: ancer += 'b'; numbers -= div2 * 26; break;
              case 3: ancer += 'c'; numbers -= div2 * 26; break;
              case 4: ancer += 'd'; numbers -= div2 * 26; break;
              case 5: ancer += 'e'; numbers -= div2 * 26; break;
              case 6: ancer += 'f'; numbers -= div2 * 26; break;
              case 7: ancer += 'g'; numbers -= div2 * 26; break;
              case 8: ancer += 'h'; numbers -= div2 * 26; break;
              case 9: ancer += 'i'; numbers -= div2 * 26; break;
              case 10: ancer += 'j'; numbers -= div2 * 26; break;
              case 11: ancer += 'k'; numbers -= div2 * 26; break;
              case 12: ancer += 'l'; numbers -= div2 * 26; break;
              case 13: ancer += 'm'; numbers -= div2 * 26; break;
              case 14: ancer += 'n'; numbers -= div2 * 26; break;
              case 15: ancer += 'o'; numbers -= div2 * 26; break;
              case 16: ancer += 'p'; numbers -= div2 * 26; break;
              case 17: ancer += 'q'; numbers -= div2 * 26; break;
              case 18: ancer += 'r'; numbers -= div2 * 26; break;
              case 19: ancer += 's'; numbers -= div2 * 26; break;
              case 20: ancer += 't'; numbers -= div2 * 26; break;
              case 21: ancer += 'u'; numbers -= div2 * 26; break;
              case 22: ancer += 'v'; numbers -= div2 * 26; break;
              case 23: ancer += 'w'; numbers -= div2 * 26; break;
              case 24: ancer += 'x'; numbers -= div2 * 26; break;
              case 25: ancer += 'y'; numbers -= div2 * 26; break;
              case 26: ancer += 'z'; numbers -= div2 * 26; break;
              default:
                  break;
          }     
        }
        if (numbers / 26 < 1)
        {
            switch (numbers)
            {
                case 0: ancer += 'A'; break;
                case 1: ancer += 'B'; break;
                case 2: ancer += 'C'; break;
                case 3: ancer += 'D'; break;
                case 4: ancer += 'E'; break;
                case 5: ancer += 'F'; break;
                case 6: ancer += 'G'; break;
                case 7: ancer += 'H'; break;
                case 8: ancer += 'I'; break;
                case 9: ancer += 'J'; break;
                case 10: ancer += 'K'; break;
                case 11: ancer += 'L'; break;
                case 12: ancer += 'M'; break;
                case 13: ancer += 'N'; break;
                case 14: ancer += 'O'; break;
                case 15: ancer += 'P'; break;
                case 16: ancer += 'Q'; break;
                case 17: ancer += 'R'; break;
                case 18: ancer += 'S'; break;
                case 19: ancer += 'T'; break;
                case 20: ancer += 'U'; break;
                case 21: ancer += 'V'; break;
                case 22: ancer += 'W'; break;
                case 23: ancer += 'X'; break;
                case 24: ancer += 'Y'; break;
                case 25: ancer += 'Z'; break;
                default:
                    break;
            }
        }
        Console.WriteLine(ancer);
    }
}