using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zad5
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int n = int.Parse(Console.ReadLine());
            StringBuilder lamps= new StringBuilder();
            for (int i = 0; i < n; i++)
            {
                lamps.Append("1");
            }
           
            
            

                int action = 2;
                int index1 = 0;
                int count = 0;
                int j = 0;

                while (count <= n && (j < lamps.Length))
                {
                    if (lamps[j] == '1')
                    {
                        for (int k = j; k < lamps.Length; k += action)
                        {
                            if (lamps[k] == '1')
                            {
                                lamps[k] = '0';
                                index1 = k;

                                count++;
                            }
                        }
                        action++;
                    }

                    j++;


                }
                
            
            
            string comands = Console.ReadLine();
           
            int countR = 0;
            int countL = 0;
            int indexOfR = 0;
            int indexOfL = 0;
            int alph = 0;
            while(indexOfL!=-1 || indexOfR!=-1)
            {
                indexOfR = comands.IndexOf("R", indexOfR + alph);
                indexOfL = comands.IndexOf("L", indexOfL + alph);
                if (indexOfL != -1)
                {
                    countL++;
                }
                if (indexOfR != -1)
                {
                    countR++;
                }
                alph = 1;
            }
            if (countL == countR)
            {
                
                Console.WriteLine(index1 + 1);
                Console.WriteLine("\"unbounded\"");
            }
            if (countR == 0 || countL == 0)
            {
               
                Console.WriteLine(index1 + 1);
                Console.WriteLine("\"bounded\"");
            }

          
        }
    }
}
