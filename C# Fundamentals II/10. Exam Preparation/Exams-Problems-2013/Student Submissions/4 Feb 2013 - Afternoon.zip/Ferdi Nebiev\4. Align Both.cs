using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace AlignBoth
{
    class Program
    {
        static void PrintLine(List<string> line, int width, int length)
        {
            if (line.Count == 1)
            {
                Console.WriteLine(line[0]);
                return;
            }
            int intervalCount = (width - length) / (line.Count - 1);
            int remainder = (width - length)%(line.Count - 1);
            for (int i = 0; i < line.Count - 1; i++)
            {
                Console.Write(line[i] + ' ');
                Console.Write(new string(' ',intervalCount));
                if (remainder > 0) Console.Write(' ');
                remainder--;
            }
            Console.WriteLine(line[line.Count - 1]);
        }
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int width = int.Parse(Console.ReadLine());
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < n; i++)
            {
                builder.Append(Console.ReadLine());
                if (i != n -1) builder.Append(' ');
            }

            string[] words = builder.ToString().Split(' ','\n');
            
            int length = 0;
            List<string> line = new List<string>();
            for (int i = 0; i < words.Length; i++)
            {
                if (String.IsNullOrWhiteSpace(words[i])) continue;
                if (length + words[i].Length + 1 <= width || line.Count == 0)
                {
                    line.Add(words[i]);
                    length += words[i].Length;
                    if (line.Count != 1) length++;
                }
                else
                {
                    PrintLine(line,width,length);
                    line = new List<string>();
                    length = 0;
               }
            }
        }
    }
}
