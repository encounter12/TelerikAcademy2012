using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace text
{
    class Program
    {
        static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());
            int width = int.Parse(Console.ReadLine());
            StringBuilder rest = new StringBuilder();
            StringBuilder newSB = new StringBuilder();
            for (int i = 0; i < lines; i++)
            {
                if (i == 0)
                {
                    string text = Console.ReadLine();
                    int count = 0;
                    int sum = 0;
                    string[] words = text.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int j = 0; j < words.Length; j++)
                    {
                        sum += words[j].Length + 1;
                        if (sum-1 < 20)
                        {
                            count++;
                        }
                    }
                    int gaps = width - sum-1;

                    int n = count;
                    for (int g = 0; g < n; g++)
                    {
                        if (((gaps % n) == 2) && (g == 0 || g == 1))
                        {
                            newSB.Append(words[g] + new String(' ', (gaps % n)));
                            count--;
                        }
                        else
                        {
                            newSB.Append(words[g] + new String(' ', (gaps / n)));
                            count--;
                        }
                    }
                    newSB.Append(".");
                    if (count < words.Length)
                    {
                        for (int f = n; f < words.Length; f++)
                        {
                            rest.Append(words[f]+' ');
                        }
                    }
                    rest.Append(' ');
                    
                }
                else
                {
                    string text = Console.ReadLine();
                    rest.Append(text);
                    string abc = rest.ToString();
                    int count = 0;
                    int sum = 0;
                    string[] words = abc.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int s = 0; s < words.Length; s++)
                    {
                        sum += words[s].Length + 1;
                        if (sum - 1 < 20)
                        {
                            count++;
                        }
                    }
                    int n = count;
                    int gaps = width - sum - 1;
                    rest.Clear();
               
                    for (int h = 0; h < n; h++)
                    {
                        if (((gaps % n) == 2) && (h == 0 || h == 1))
                        {
                            newSB.Append(words[h] + new String(' ', (gaps % n)));
                            count--;
                        }
                        else
                        {
                            newSB.Append(words[h] + new String(' ', (gaps / n)));
                            count--;
                        }
                    }
                    newSB.Append(".");
                    if (count < words.Length)
                    {
                        for (int l = n; l < words.Length; l++)
                        {
                            rest.Append(words[l]+' ');
                        }
                    }
                    rest.Append(' ');
                }
            }
            string newText = newSB.ToString();
            string[] kray = newText.Split('.');
            foreach (var item in kray)
            {
                Console.WriteLine(item);
            }

        }
    }
}
