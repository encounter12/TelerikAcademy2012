using System;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Text;

class AlignBoth
{
    static void PrintLine(List<string> list, int startInd, int endInd, int w)
    {
        int wordCount = endInd - startInd;

        if (wordCount == 1)
        {
            Console.WriteLine(list[startInd]);
            return;
        }

        StringBuilder sb = new StringBuilder();
        int lengthWords = 0;

        for (int i = startInd; i < endInd; i++)
        {
            lengthWords += list[i].Length;
        }

        int lengthWhites = w - lengthWords;

        int x = lengthWhites % (wordCount - 1);
        int y = lengthWhites / (wordCount - 1);

        int count = 0;
        for (int i = startInd; i < endInd -1; i++)
        {      
            sb.Append( list[i]);
            int whites = y;

            if(count<x)
            {
                whites++;
                count++;
            }
            sb.Append(new string(' ', whites));
            
        }
        sb.Append(list[endInd - 1]);
        Console.WriteLine(sb.ToString());
        
    }

    static void Main()
    {
        List<string> words = new List<string>();
        short n = short.Parse(Console.ReadLine());
        short w = short.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            string line = Console.ReadLine();
            string[] tempLines = Regex.Split(line, @"\s+");
            foreach(string word in tempLines)
            {
                words.Add(word);
            }
        }

        int length = 0;
        int wordsCount = 0;
        for (int i = 0, startInd=0; i < words.Count; length=0)
        {
            wordsCount = 1;
            startInd = i;
            length += words[i].Length;

            while (length +(wordsCount-1)< w)
            {
                i++;
                if (i == words.Count) break;
                wordsCount++;
                length += words[i].Length;
              
            }
            if (length + (wordsCount - 1) == w) i++;

            PrintLine(words, startInd, i, w);
        }
    }
}