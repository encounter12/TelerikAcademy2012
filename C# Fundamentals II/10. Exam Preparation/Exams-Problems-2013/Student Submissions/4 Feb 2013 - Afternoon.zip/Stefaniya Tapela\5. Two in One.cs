using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TwoInOne
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = Int32.Parse(Console.ReadLine());
            string command1 = Console.ReadLine();
            string command2 = Console.ReadLine();


            List<int> lamps = new List<int>();
            while (N > 0)
            {
                lamps.Add(N);
                N--;
            }
            lamps.Reverse();
            int t = 2;
            List<int> current = new List<int>();
            while (lamps.Count > 0)
            {
                current = new List<int>();
                for (int i = 0; i < lamps.Count; i += t)
                {
                    current.Add(lamps[i]);
                }
                lamps = lamps.Except(current).ToList();

                t++;
            }
            Console.WriteLine(current.Last());


            if (command1.Contains("LSR") || command1.Contains("RSL") )
                Console.WriteLine("unbounded");
            else
                Console.WriteLine("bounded");

            if (command1.Contains("LSR") || command1.Contains("RSL"))
                Console.WriteLine("unbounded");
            else
                Console.WriteLine("bounded");
        }

    }
}
