using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
	static void Main(string[] args)
	{
#if DEBUG
		Console.SetIn(new StreamReader("input.txt"));
#endif
		var delimiter = new char[] {','};
		var valleyString = Console.ReadLine().Replace(" ", "").Split(delimiter, StringSplitOptions.RemoveEmptyEntries);
		int[] valley = new int[valleyString.Length];
		for (int i = 0; i < valley.Length; i++)
		{
			valley[i] = int.Parse(valleyString[i]);
		}

		int numberOfPatterns = int.Parse(Console.ReadLine());
		int[][] patterns = new int[numberOfPatterns][];
		for (int i = 0; i < numberOfPatterns; i++)
		{
			var patternInput = Console.ReadLine().Replace(" ", "").Split(delimiter, StringSplitOptions.RemoveEmptyEntries);
			patterns[i] = new int[patternInput.Length];
			for (int j = 0; j < patternInput.Length; j++)
			{
				patterns[i][j] = int.Parse(patternInput[j]);
			}
		}

		Console.WriteLine(patterns.Max(x => CalculatePatternResult(valley.ToArray(), x)));
		
	}

	private static long CalculatePatternResult(int[] valley, int[] pattern)
	{
		var visited = int.MaxValue;
		int position = 0;
		int sum = valley[0];
		valley[0] = visited;
		for (int i = 0; true; i++)
		{
			position += pattern[i % pattern.Length];
			if (position < 0 || position >= valley.Length || valley[position] == visited)
				break;

			sum += valley[position];
			valley[position] = visited;
		}
		return sum;
	}
}
