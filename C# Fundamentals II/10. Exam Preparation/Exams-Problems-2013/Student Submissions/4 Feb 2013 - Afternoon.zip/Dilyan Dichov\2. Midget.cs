using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02
{
    class Program
    {
        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            int maxCoints = 0;
            string[] readedWords = line.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            int[] valley = new int[readedWords.Length];
            //int[] valley1 = new int[readedWords.Length];
            int length = valley.Length;
            for (int i = 0; i < length; i++)
            {
                valley[i] = int.Parse(readedWords[i]);
            }
            if (length!=0)
            {
            int m=int.Parse(Console.ReadLine());
            //int[,] pattern = new int[m, 100];

            for (int i = 0; i < m; i++)
            {
                string line1 = Console.ReadLine();
                string[] words = line1.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
                int []  pattern = new int[words.Length];
                for (int j = 0; j < words.Length; j++)
                {
                  pattern[j] = int.Parse(words[j]);
                }
                int currentCoints = CheckCoints(pattern, length, valley, pattern.Length);
                if (maxCoints < currentCoints)
                {
                    maxCoints = currentCoints;
                }
            }
            }
            Console.WriteLine(maxCoints);
        }

        private static int CheckCoints(int[] pattern, int length, int[] valley, int pLengt )
        {
            int[] valley1 =(int[]) valley.Clone();
            int maxCoints = valley1[0];
            valley1[0] = 1111111;
            int currentPos=0;

            for (int i = 0; i < pLengt; )
                {
                    int j = pattern[i];
                    if ((currentPos + j )>= 0 && (currentPos + j) < length)
                    {
                        if (valley1[currentPos+j] != 1111111)
                        {
                            maxCoints += valley1[currentPos + j];
                            valley1[currentPos + j] = 1111111;
                            currentPos = currentPos + j;
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                    if (i == pLengt - 1)
                    {
                        i = 0;
                    }
                    else
                    {
                        i++;
                    }
                }


                    return maxCoints;
        }
    }
}
