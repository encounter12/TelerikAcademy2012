using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;
 
namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
 
            string number = Console.ReadLine();
 
            long numberDec = long.Parse(number);
             
            string[] dec = new string[256];
            string result = "";
 
            for (int i = 0; i < dec.Length; i++)
            {
                switch (numberDec)
                {
                    case 0:
                        dec[i] = "A";
                        break;
                    case 1:
                        dec[i] = "B";
                        break;
                    case 2:
                        dec[i] = "C";
                        break;
                    case 3:
                        dec[i] = "D";
                        break;
                    case 4:
                        dec[i] = "E";
                        break;
                    case 5:
                        dec[i] = "F";
                        break;
                    case 6:
                        dec[i] = "G";
                        break;
                    case 7:
                        dec[i] = "H";
                        break;
                    case 8:
                        dec[i] = "I";
                        break;
                    case 9:
                        dec[i] = "J";
                        break;
                    case 10:
                        dec[i] = "K";
                        break;
                    case 11:
                        dec[i] = "L";
                        break;
                    case 12:
                        dec[i] = "M";
                        break;
                    case 13:
                        dec[i] = "N";
                        break;
                    case 14:
                        dec[i] = "O";
                        break;
                    case 15:
                        dec[i] = "P";
                        break;
                    case 16:
                        dec[i] = "Q";
                        break;
                    case 17:
                        dec[i] = "R";
                        break;
                    case 18:
                        dec[i] = "S";
                        break;
                    case 19:
                        dec[i] = "T";
                        break;
                    case 20:
                        dec[i] = "U";
                        break;
                    case 21:
                        dec[i] = "V";
                        break;
                    case 22:
                        dec[i] = "W";
                        break;
                    case 23:
                        dec[i] = "X";
                        break;
                    case 24:
                        dec[i] = "Y";
                        break;
                    case 25:
                        dec[i] = "Z";
                        break;
 
                    case 26:
                        dec[i] = "a" + "A";
                        break;
                    case 27:
                        dec[i] = "a" + "B";
                        break;
                    case 28:
                        dec[i] = "a" + "C";
                        break;
                    case 29:
                        dec[i] = "a" + "D";
                        break;
                    case 30:
                        dec[i] = "a" + "E";
                        break;
                    case 31:
                        dec[i] = "a" + "F";
                        break;
                    case 32:
                        dec[i] = "a" + "G";
                        break;
                    case 33:
                        dec[i] = "a" + "H";
                        break;
                    case 34:
                        dec[i] = "a" + "I";
                        break;
                    case 35:
                        dec[i] = "a" + "J";
                        break;
                    case 36:
                        dec[i] = "a" + "K";
                        break;
                    case 37:
                        dec[i] = "a" + "L";
                        break;
                    case 38:
                        dec[i] = "a" + "M";
                        break;
                    case 39:
                        dec[i] = "a" + "N";
                        break;
                    case 40:
                        dec[i] = "a" + "O";
                        break;
                    case 41:
                        dec[i] = "a" + "P";
                        break;
                    case 42:
                        dec[i] = "a" + "Q";
                        break;
                    case 43:
                        dec[i] = "a" + "R";
                        break;
                    case 44:
                        dec[i] = "a" + "S";
                        break;
                    case 45:
                        dec[i] = "a" + "T";
                        break;
                    case 46:
                        dec[i] = "a" + "U";
                        break;
                    case 47:
                        dec[i] = "a" + "V";
                        break;
                    case 48:
                        dec[i] = "a" + "W";
                        break;
                    case 49:
                        dec[i] = "a" + "X";
                        break;
                    case 50:
                        dec[i] = "a" + "Y";
                        break;
                    case 51:
                        dec[i] = "a" + "Z";
                        break;
                     
                    case 52:
                        dec[i] = "b" + "A";
                        break;
                    case 53:
                        dec[i] = "b" + "B";
                        break;
                    case 54:
                        dec[i] = "b" + "C";
                        break;
                    case 55:
                        dec[i] = "b" + "D";
                        break;
                    case 56:
                        dec[i] = "b" + "E";
                        break;
                    case 57:
                        dec[i] = "b" + "F";
                        break;
                    case 58:
                        dec[i] = "b" + "G";
                        break;
                    case 59:
                        dec[i] = "b" + "H";
                        break;
                    case 60:
                        dec[i] = "b" + "I";
                        break;
                    case 61:
                        dec[i] = "b" + "J";
                        break;
                    case 62:
                        dec[i] = "b" + "K";
                        break;
                    case 63:
                        dec[i] = "b" + "L";
                        break;
                    case 64:
                        dec[i] = "b" + "M";
                        break;
                    case 65:
                        dec[i] = "b" + "N";
                        break;
                    case 66:
                        dec[i] = "b" + "O";
                        break;
                    case 67:
                        dec[i] = "b" + "P";
                        break;
                    case 68:
                        dec[i] = "b" + "Q";
                        break;
                    case 69:
                        dec[i] = "b" + "R";
                        break;
                    case 70:
                        dec[i] = "b" + "S";
                        break;
                    case 71:
                        dec[i] = "b" + "T";
                        break;
                    case 72:
                        dec[i] = "b" + "U";
                        break;
                    case 73:
                        dec[i] = "b" + "V";
                        break;
                    case 74:
                        dec[i] = "b" + "W";
                        break;
                    case 75:
                        dec[i] = "b" + "X";
                        break;
                    case 76:
                        dec[i] = "b" + "Y";
                        break;
                    case 77:
                        dec[i] = "b" + "Z";
                        break;
 
                    case 78:
                        dec[i] = "c" + "A";
                        break;
                    case 79:
                        dec[i] = "c" + "B";
                        break;
                    case 80:
                        dec[i] = "c" + "C";
                        break;
                    case 81:
                        dec[i] = "c" + "D";
                        break;
                    case 82:
                        dec[i] = "c" + "E";
                        break;
                    case 83:
                        dec[i] = "c" + "F";
                        break;
                    case 84:
                        dec[i] = "c" + "G";
                        break;
                    case 85:
                        dec[i] = "c" + "H";
                        break;
                    case 86:
                        dec[i] = "c" + "I";
                        break;
                    case 87:
                        dec[i] = "c" + "J";
                        break;
                    case 88:
                        dec[i] = "c" + "K";
                        break;
                    case 89:
                        dec[i] = "c" + "L";
                        break;
                    case 90:
                        dec[i] = "c" + "M";
                        break;
                    case 91:
                        dec[i] = "c" + "N";
                        break;
                    case 92:
                        dec[i] = "c" + "O";
                        break;
                    case 93:
                        dec[i] = "c" + "P";
                        break;
                    case 94:
                        dec[i] = "c" + "Q";
                        break;
                    case 95:
                        dec[i] = "c" + "R";
                        break;
                    case 96:
                        dec[i] =  "c"+ "S";
                        break;
                    case 97:
                        dec[i] = "c"+ "T";
                        break;
                    case 98:
                        dec[i] = "c" + "U";
                        break;
                    case 99:
                        dec[i] = "b" + "V";
                        break;
                    case 100:
                        dec[i] = "c" + "W";
                        break;
                    case 101:
                        dec[i] = "c" + "X";
                        break;
                    case 102:
                        dec[i] = "c" + "Y";
                        break;
                    case 103:
                        dec[i] = "c" + "Z";
                        break;
                    default:
                        break;
                }
                result = dec[i];
 
            }
            Console.WriteLine(result);
                           
            }
 
        }
    }
 