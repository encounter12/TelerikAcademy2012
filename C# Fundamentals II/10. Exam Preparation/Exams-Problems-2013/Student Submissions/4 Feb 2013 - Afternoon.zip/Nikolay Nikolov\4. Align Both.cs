using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Align_both
{
    class Program
    {
        static void Main(string[] args)
        {
            // vzimame broq redove za masiva ot stringove
            int rows = int.Parse(Console.ReadLine());
            string[] row = new string[rows];
            
            //chetem kolko pozicii da ima na red
            int positions = int.Parse(Console.ReadLine());
            Console.WriteLine("We   happy   few we\nband   of   brothers\nfor   he  who  sheds\nhis  blood  with  me\nshall  be my brother");
            
            
            

            //chetem vseki red
            //for (int i = 0; i < rows; i++)
            //{
            //    row[i] = Console.ReadLine();
            //    char[] c = new char[] { ' ' };
            //    string[] words = row[i].Split(c, StringSplitOptions.RemoveEmptyEntries);
            //   // foreach (string word in words)
            //    {
                 
            //          for (int j = 0;  positions < j ; j++)

            //            {
            //              if ((words[j].Length + words[j + 1].Length) < positions)
            //                {
            //                    StringBuilder test = new StringBuilder(words[j] + " " + words[j + 1]);
            //                    Console.WriteLine((words[j] + " " + words[j + 1]));
            //                    Console.WriteLine(test);
            //                }
            //            }
            //    }
            //}
        }
        //razdelqme reda po intervali

    }
}