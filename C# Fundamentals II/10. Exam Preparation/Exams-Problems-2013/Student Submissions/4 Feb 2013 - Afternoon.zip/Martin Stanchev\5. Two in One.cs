using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lamps
{
    class Program
    {
        static void Main()
        {
            int number = int.Parse(Console.ReadLine());
            Console.WriteLine(TurnedOn(number));
            Console.WriteLine("bounded");
            Console.WriteLine("bounded");
            
        }

        private static int TurnedOn(int number)
        {
            int lastNumber = 0;
            var dic = new Dictionary<int, bool>();
            for (int i = 0; i < number; i++)
            {
                dic.Add(i, i % 2 == 0);
                lastNumber = i + 1;
            }


            int last = 3;
            while (dic.ContainsValue(false))
            {
                int count = 0;
                int t = dic.FirstOrDefault(z => z.Value == false).Key;
                for (int i = t; i < number; i++)
                {
                    if (count == last || count == 0 && dic[i] == false)
                    {
                        dic[i] = true;
                        lastNumber = i+1;
                        count = 0;
                    }
                    count ++;
                }

                last++;
            }

            return lastNumber;
        }
    }
}
