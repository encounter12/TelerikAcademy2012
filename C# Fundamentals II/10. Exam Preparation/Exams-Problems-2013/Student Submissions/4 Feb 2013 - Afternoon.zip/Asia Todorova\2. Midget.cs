using System;



class Midget
{
    static void Main()
    {
        int bestSum = 0;
        string line1 = Console.ReadLine();
        string [] valleyStr = line1.Split(',');
        int[] valley = new int[valleyStr.Length];

        for (int i = 0; i < valleyStr.Length; i++)
			{
                valleyStr[i] = valleyStr[i].Trim(' ', ',');
                valley[i] = int.Parse(valleyStr[i]);
			}

        //Console.WriteLine("\nresulet\n");
        //for (int l = 0; l < valley.Length; l++)
        //{
        //    Console.WriteLine(valley[l]);
        //}

        int numberOfLines = int.Parse(Console.ReadLine());

        string[] lines = new string[numberOfLines];

        for (int j = 0; j < numberOfLines; j++)
        {
            lines[j] = Console.ReadLine();
            string[] patternStr = lines[j].Split(',');
            int[] pattern = new int[patternStr.Length];

            for (int k = 0; k < patternStr.Length; k++)
            {
                patternStr[k] = patternStr[k].Trim(' ', ',');             
                pattern[k] = int.Parse(patternStr[k]);
            }

            //Console.WriteLine("\nresult\n");
            //for (int l = 0; l < pattern.Length; l++)
            //{
            //    Console.WriteLine(pattern[l]);
            //}

            int sum = 0;
            int index = 0;
            int[] veseted = new int[pattern.Length * 5];
            for (int l = 0; l < pattern.Length; l++)
            {
                index = index + pattern[l];
                if (index >= 0 && index < valley.Length && veseted[index] != 1)
                {
                    sum = sum + valley[index];
                    veseted[index] = 1;
                }
                else
                {
                    break;
                }
            }

            for (int m = 0; m < pattern.Length; m++)
            {
                if (index >= 0 && index < valley.Length && veseted[index] != 1)
                {
                    sum = sum + valley[index];
                }
                else
                {
                    break;
                }
                index = index + pattern[m];
            }

            if (sum > bestSum)
            {
                bestSum = sum;
            }

        }

        Console.WriteLine(bestSum);



    }
}

