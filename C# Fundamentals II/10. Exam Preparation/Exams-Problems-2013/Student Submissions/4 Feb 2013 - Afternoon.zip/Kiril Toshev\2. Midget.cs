using System;
using System.Numerics;
using System.Collections.Generic;

class Midget
{
    static void Main()
    {

        string[] valleyString = Console.ReadLine().Split(new[] {',', ' '}, StringSplitOptions.RemoveEmptyEntries);
        int[] valley = new int[valleyString.Length];
        for (int index = 0; index < valleyString.Length; index++)
        {
            valley[index] = int.Parse(valleyString[index]);
        }
        int numOfPatterns = int.Parse(Console.ReadLine());
        List<string[]> patternsStrings = new List<string[]>();
        for (int patternsIndex = 0; patternsIndex < numOfPatterns; patternsIndex++)
        {
            patternsStrings.Add(Console.ReadLine().Split(new[] {',', ' '}, StringSplitOptions.RemoveEmptyEntries));
        }
        BigInteger maxCoins = valley[0];
        List<int> currentPattern = new List<int>();
        foreach (string[] pattern in patternsStrings)
        {
            bool[] check = new bool[valley.Length];
            check[0] = true;
            BigInteger coinsCount = valley[0];
            
            foreach (string number in pattern)
            {
                currentPattern.Add(int.Parse(number));
            }
            int previousIndex = 0;
            bool inVally = true;
            while (inVally)
            {
                for (int patternIndex = 0; patternIndex < currentPattern.Count; patternIndex++)
                {
                    if ((previousIndex + currentPattern[patternIndex] < valley.Length) && (previousIndex + currentPattern[patternIndex] >= 0))
                    {
                        if ((check[previousIndex + currentPattern[patternIndex]] != true))
                        {
                            check[previousIndex + currentPattern[patternIndex]] = true;
                            coinsCount += valley[previousIndex + currentPattern[patternIndex]];
                            previousIndex = previousIndex + currentPattern[patternIndex];
                        }
                        else
                        {
                            inVally = false;
                            break;
                        }
                    }
                    else
                    {
                        inVally = false;
                        break;
                    }
                }
            }
            if (maxCoins < coinsCount)
            {
                maxCoins = coinsCount;
            }
            currentPattern.Clear();
        }
        Console.WriteLine(maxCoins);
    }
}