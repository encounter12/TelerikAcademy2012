using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlignBoth
{
    class AlignBoth
    {
        static void Main()
        {
            int N = int.Parse(Console.ReadLine());
            int W = int.Parse(Console.ReadLine());
            string input = Console.ReadLine();
            var result = input.Split(new[] { '\r', '\n' });

            Console.WriteLine(input.ToString());
        
            

            
            StringBuilder newText = new StringBuilder();
            

         for (int i = 0; i < N; i++)
           {
               for (int j = 0; j < W; j++)
              {
                    newText.Append(input[i]);
               }
               Console.WriteLine(newText);

           }



        }
    }
}
