using System;
using System.Text;
using System.Numerics;
class ProvadiaNumbers
{
    public static string ToProvadiaNumber(int inNumber)
    {
        string res = "";
        char c = (char)(inNumber % 26 + 'A');
        res = res + c;
        inNumber /= 26;
        if (inNumber > 0)
        {
            c = (char)(inNumber % 26 + 'a' - 1);
            res = c + res;
        }
        return res;
    }
    static void Main()
    {
        BigInteger inNumber = BigInteger.Parse(Console.ReadLine());
        if (inNumber != 0)
        {
            //BigInteger size = inNumber / 256;
            //size = (size < 2) ? 2 : size;

            StringBuilder builder = new StringBuilder();

            while (inNumber > 0)
            {
                int temp = (int)(inNumber % 256);
                builder.Insert(0, ToProvadiaNumber(temp));
                inNumber = inNumber / 256;
            }
            Console.WriteLine(builder.ToString());
        }
        else
        {
            Console.WriteLine("A");
        }
    }
}