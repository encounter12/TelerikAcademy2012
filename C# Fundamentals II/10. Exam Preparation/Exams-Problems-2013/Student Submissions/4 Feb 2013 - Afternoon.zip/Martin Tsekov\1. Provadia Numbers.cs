using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
class Program
{
    static void Main()
    {
        List<string> hex = new List<string>();
        for (int i = 0; i <= 25; i++)
        {
            hex.Add(((char)('A' + i)).ToString());
        }
        for (char down = 'a'; down <= 'i'; down++)
        {
            for (char up = 'A'; up <= 'Z'; up++)
            {
                hex.Add(down.ToString() + up.ToString());
            }
        }
        BigInteger num = BigInteger.Parse(Console.ReadLine().Replace(' ', '\x0'));
        //Console.Write("Input a decimal number to see its hexadecimal representation: ");

        string res = "";
        //string[] hex = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" , "G", "H"};
        //18446744073709551610
        if (num == 0)
        {
            Console.WriteLine("0");
            return;
        }
        BigInteger temp = 0;
        while (num > 0)
        {
            temp = num % 256;
            res = hex[(int)temp].ToString() + res;
            num /= 256;
        }
        Console.WriteLine("{0}", res);
    }
}
