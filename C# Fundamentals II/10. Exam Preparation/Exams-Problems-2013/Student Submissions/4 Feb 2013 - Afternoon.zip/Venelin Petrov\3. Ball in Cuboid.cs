using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Ball_In_Cuboid
{
    class Program
    {
        static int width = 0;
        static int height = 0;
        static int depth = 0;
        static string[, ,] cube;
        static int ballW;
        static int ballD;
        static int ballH = 0;
        static bool exit = false;

        static void Main()
        {
            ReadInput();

            MoveBall();

            if (exit)
            {
                Console.WriteLine("Yes");
            }
            else
            {
                Console.WriteLine("No");
            }
            Console.WriteLine("{0} {1} {2}", ballW, height - 1, ballD);
        }

        private static void MoveBall()
        {
            bool isEnd = false;
            do
            {
                string[] element;
                if (ballW >= 0 && ballD >= 0 && ballH >= 0 && ballW < width && ballH < height && ballD < depth)
                {
                    element = cube[ballW, ballH, ballD].Split(' ');
                }
                else
                {
                    break;
                }

                if (element[0] == "B")
                {
                    isEnd = true;
                    exit = false;
                    break;
                }
                else if (element[0] == "E")
                {
                    if (ballH == height - 1)
                    {
                        exit = true;
                        isEnd = true;
                    }
                    else
                    {
                        ballH++;
                    }
                }
                else if (element[0] == "S")
                {
                    if (ballH == height - 1)
                    {
                        exit = true;
                        isEnd = true;
                        break;
                    }
                    else
                    {
                        ballH++;
                    }
                    switch (element[1])
                    {
                        case "L":
                            if (ballW > 0)
                            {
                                ballW--;
                            }
                            else
                            {
                                exit = false;
                                isEnd = true;
                            }
                            break;
                        case "R":
                            if (ballW < width - 1)
                            {
                                ballW++;
                            }
                            else
                            {
                                exit = false;
                                isEnd = true;
                            }
                            break;
                        case "F":
                            if (ballD > 0)
                            {
                                ballD--;
                            }
                            else
                            {
                                exit = false;
                                isEnd = true;
                            }
                            break;
                        case "B":
                            if (ballD < depth - 1)
                            {
                                ballD++;
                            }
                            else
                            {
                                exit = false;
                                isEnd = true;
                            }
                            break;
                        case "FL":
                            if (ballW > 0 && ballD > 0)
                            {
                                ballW--;
                                ballD--;
                            }
                            else
                            {
                                exit = false;
                                isEnd = true;
                            }
                            break;
                        case "FR":
                            if (ballW < width - 1 && ballD > 0)
                            {
                                ballW++;
                                ballD--;
                            }
                            else
                            {
                                exit = false;
                                isEnd = true;
                            }
                            break;
                        case "BL":
                            if (ballW > 0 && ballD < depth - 1)
                            {
                                ballW--;
                                ballD++;
                            }
                            else
                            {
                                exit = false;
                                isEnd = true;
                            }
                            break;
                        case "BR":
                            if (ballW < width - 1 && ballD < depth - 1)
                            {
                                ballW++;
                                ballD++;
                            }
                            else
                            {
                                exit = false;
                                isEnd = true;
                            }
                            break;
                        default:
                            throw new Exception();
                    }
                }
                else if (element[0] == "T")
                {
                    ballW = int.Parse(element[1]);
                    ballD = int.Parse(element[2]);
                }
            } while (!isEnd);
        }

        private static void ReadInput()
        {
            string[] dimensionsStr = Console.ReadLine().Split(' ');
            width = int.Parse(dimensionsStr[0]);
            height = int.Parse(dimensionsStr[1]);
            depth = int.Parse(dimensionsStr[2]);

            cube = new string[width, height, depth];

            for (int h = 0; h < height; h++)
            {
                string[] seq = Regex.Split(Console.ReadLine(), "( \\| )");

                int d = 0;
                int k = 0;
                do
                {
                    if (seq[k] != " | ")
                    {
                        string[] cubes = seq[k].Split(new char[] { '(', ')' }, StringSplitOptions.RemoveEmptyEntries);
                        for (int w = 0; w < width; w++)
                        {
                            cube[w, h, d] = cubes[w];
                        }
                        d++;
                    }
                    k++;
                }while(d < depth && k < seq.Length);
            }

            string[] ballCoord = Console.ReadLine().Split(' ');
            ballW = int.Parse(ballCoord[0]);
            ballD = int.Parse(ballCoord[1]);
        }
    }
}
