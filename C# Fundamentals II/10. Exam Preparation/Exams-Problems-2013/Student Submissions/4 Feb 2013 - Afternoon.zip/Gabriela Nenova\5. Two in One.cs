using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{

    static int indexOfFirstFalse(bool[] arr)
    {
        int index = 0;
        for (int i = 0; i < arr.Length; i++)
        {
            if (arr[i] == false)
            {
                index = i;
                break;
            }
        }
        if (index != 0)
        {
            return index;
        }
        else return -1;
    }
    static void makePosAndEveryNthElementTrue(bool[] arr, int pos, int k)
    {
        int countFalse = 0;
        arr[pos] = true;
        for (int i = pos; i < arr.Length; i++)
        {
            if (arr[i] == false)
            {
                countFalse++;
            }
            if ((countFalse == k) && (arr[i] == false))
            {
                arr[i] = true;
            }
        }
    }
    static int indexOfLastFalse(bool[] arr)
    {
        int countFalse = 0;
        int resultIndex = -1;
        for (int i = 0; i < arr.Length; i++)
        {
            if (arr[i] == false)
            {
                countFalse++;
                resultIndex = i;
            }
        }
        if (countFalse == 1) return resultIndex;
        else return -1;
    }
    static bool checkBoundary(string str, string toFind)
    {
        if (str.Contains(toFind))
        {
            return true; }
        else
        { return false; }
    }
    static bool checkIfCommandIsSingle(string str)
    {
        if (str.Length == 1)
        {
            return true;
        }
        else return false;
    }
    static bool forDifferences(string str)
    {
        for (int i = 1; i < str.Length - 1; i++)
        {
            if (str[i] != str[i - 1] && str[i] != str[i + 1])
            {
                return false;
            }
            
        }
        return true;
    }
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string firstCommand = Console.ReadLine();
        string secondCommand = Console.ReadLine();

        bool[] array = new bool[n]; 

        for (int i = 0; i < array.Length; i++) 
        {
            array[i] = false;
        }


 




        int k = 0;
        int increment = 2;
        for (int j = 0; j < n; j++)
        {
            if ((j == k) && array[j] == false)
            {
                array[j] = true;
            }
            else
                if ((j == k + increment) && array[j] == false)
                {
                    array[j] = true;
                    increment = increment + 2;
                }
        }

        int incr = 3;
        while (indexOfLastFalse(array) == -1)
        {

            
            int nextFalseIndex = indexOfFirstFalse(array);
            makePosAndEveryNthElementTrue(array, nextFalseIndex, incr);

            incr = incr + 1;
        }
        Console.WriteLine(indexOfLastFalse(array) + 1);




        if (forDifferences(firstCommand))
        {
            Console.WriteLine("bounded");
        }
        else Console.WriteLine("unbounded");

        if (forDifferences(secondCommand))
        {
            Console.WriteLine("bounded");
        }
        else Console.WriteLine("unbounded");






    }


}



