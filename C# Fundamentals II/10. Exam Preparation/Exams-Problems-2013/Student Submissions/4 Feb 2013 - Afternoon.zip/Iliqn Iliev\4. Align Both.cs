using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int w = int.Parse(Console.ReadLine());
            string[] lines = new string[n];
            List<string> allWords = new List<string>();
            StringBuilder res = new StringBuilder();
            for (int i = 0; i < n; i++)
            {
                lines[i] = Console.ReadLine();
                res.AppendLine(lines[i]);
            }

            Console.WriteLine(res.ToString());
        }
    }
}
