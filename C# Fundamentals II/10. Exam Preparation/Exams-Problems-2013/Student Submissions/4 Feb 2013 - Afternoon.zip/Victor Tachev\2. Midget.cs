using System; 

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem2_Midget
{
    class Midget
    {
        static void Main(string[] args)
        {
            char[] separators = { ',', ' ' };
            
            // read input
            string valleyInput = Console.ReadLine();

            string[] valleyStr = valleyInput.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            int[] valley = new int[valleyStr.Length];

            for (int i = 0; i < valleyStr.Length; i++)
            {
                valley[i] = int.Parse(valleyStr[i]);
            }

            int numberOfPatterns = int.Parse(Console.ReadLine());
            string[] patternsInput = new string[numberOfPatterns]; 

            for (int i = 0; i < numberOfPatterns; i++)
            {
                patternsInput[i] = Console.ReadLine();
            }

            List<int[]> patterns = new List<int[]>();

            foreach (var pat in patternsInput)
            {
                string[] rawPattern = pat.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                int[] pattern = new int[rawPattern.Length];

                for (int i = 0; i < rawPattern.Length; i++)
                {
                    pattern[i] = int.Parse(rawPattern[i]);
                }
                patterns.Add(pattern);
            }

            // check paths
            
            long maxCollectedSum = 0;
            
            foreach (var path in patterns)
            {
                bool[] positionsCollected = new bool[valley.Length];
                int indexInValley = 0;
                int indexInPath = 0;
                long currentSum = 0;

                while (!positionsCollected[indexInValley])
                {
                    currentSum += valley[indexInValley];
                    positionsCollected[indexInValley] = true;
                    indexInValley += path[indexInPath % path.Length];
                    indexInPath++;
                    if (indexInValley >= valley.Length || indexInValley < 0)
                    {
                        break;
                    }
                }

                if (currentSum > maxCollectedSum)
                {
                    maxCollectedSum = currentSum;
                }
            }

            Console.WriteLine(maxCollectedSum);
        }
    }
}
