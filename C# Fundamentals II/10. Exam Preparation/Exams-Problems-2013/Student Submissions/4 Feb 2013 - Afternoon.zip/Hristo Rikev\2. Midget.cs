using System;
using System.Text;

namespace Task1
{
    class Program
    {


       static void Main()
        {
            int number = 21;
            for (int k = 21; k < 100; k++)
            {
                number = number +12;
                Console.WriteLine(number);
            }

        }

    }
}