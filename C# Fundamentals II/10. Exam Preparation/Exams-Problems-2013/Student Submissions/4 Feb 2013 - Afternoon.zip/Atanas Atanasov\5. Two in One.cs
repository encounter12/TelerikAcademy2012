using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        // input
        int lamps_cnt = int.Parse(Console.ReadLine());
        char[] commands_1 = Console.ReadLine().ToCharArray();
        char[] commands_2 = Console.ReadLine().ToCharArray();


        //first part
        for (int l = lamps_cnt+1; l>=0 ; l--)
        {
            if (is_prime(l)){
                Console.WriteLine(l-1);
                break;
            }
        }

        //second part
        if (is_bounded(commands_1)){
            Console.WriteLine("bounded");
        }
        else{
            Console.WriteLine("unbounded");
        }
        if (is_bounded(commands_2))
        {
            Console.WriteLine("bounded");
        }
        else
        {
            Console.WriteLine("unbounded");
        }
    }

    static bool is_bounded(char[] commands){
        bool forward = false;
        int circle_cnt =0;
        for (int c = 0; c < commands.Length; c++)
        {
            if (commands[c]=='S' || commands[c]=='s'){
                forward = true;
            }
            if (commands[c] == 'L' || commands[c] == 'l')
            {
                circle_cnt++;
            }
            if (commands[c] == 'R' || commands[c] == 'r')
            {
                circle_cnt--;
            }
        }
        if (forward){
            if (circle_cnt==0 || circle_cnt%4==0){
                return false;
            }
        }
        return true;
    }



    static bool is_prime(int number)
    {
        for (int i = 2; i < number; i++)
        {
            if (number % i == 0)
            {
                return false;
            }
        }
        return true;
    }
}
