using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


    class Midget
    {
        static void Main()
        {
              
            string[] pattern = new string[] { Console.ReadLine() };
            int num = int.Parse(Console.ReadLine());
            
            string[] numbers=new string[]{};

            for (int i = 0; i < num; i++)
            {
                string[][] jagged = new string[num][];
               
                string line = Console.ReadLine();
              
                string[] taken = line.Split(',',' ');
             
                    numbers = taken[i].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                  
                      int value =int.Parse(numbers[i]);
               
                    
                }
            foreach (var item in numbers)
            {
                Console.WriteLine(item);
            }
           
            }
    }