using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

class Program
{
    static void Main(string[] args)
    {
//        string text = @"We happy few          we band
//                        of brothers for he who sheds
//                        his blood
//                        with
//                        me shall be my brother";

        int n = int.Parse(Console.ReadLine());
        int p = int.Parse(Console.ReadLine());
        string text = Console.ReadLine();

        text = text.Trim();

        MatchCollection m = Regex.Matches(text,"\\b\\w+\\b");

        StringBuilder sb = new StringBuilder();
        int set = 0;
        int current = 0;
        foreach(var i in m){

            set += i.ToString().Length;

            if ((set) > 20)
            {
                sb.Append('\n');
                set = 0;
                
            }
            else
            {
                sb.Append(i);
                sb.Append(" ");
            }

            current = sb.Capacity;
        }

        Console.WriteLine(sb.ToString());



    }


}
