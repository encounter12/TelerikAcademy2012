using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Midget
{
    class Program
    {
        static List<short> valley;
        static void Main(string[] args)
        {
            valley = GetIntArray();

            int M = Int32.Parse(Console.ReadLine());
            List<List<short>> patterns = new List<List<short>>();
            while (M > 0)
            {
                patterns.Add(GetIntArray());
                M--;
            }

            int maxSum, currentSum;
            maxSum = CheckPattern(patterns[0]);
            for (int pIndex = 1; pIndex < patterns.Count; pIndex++)
            {
                currentSum = CheckPattern(patterns[pIndex]);
                if (currentSum > maxSum)
                    maxSum = currentSum;
            }

            Console.WriteLine(maxSum);
        }

        static int CheckPattern(List<short> p)
        {
            int currentIndex = 0;
            int sum = valley[currentIndex];

            List<short> visited = new List<short>() { 0 };
            for (int i = 0; i < p.Count; i++)
            {
                currentIndex += p[i];
                if (currentIndex < 0 || currentIndex > valley.Count - 1 || visited.Contains((short)currentIndex))
                    break;
                sum += valley[currentIndex];
                visited.Add((short)currentIndex);
                if (i == p.Count - 1)
                    i = -1;
            }
            return sum;
        }

        static List<short> GetIntArray()
        {
            List<Int16> list = new List<short>();
            foreach (var str in Console.ReadLine().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                list.Add(short.Parse(str));
            return list;
        }
    }
}
