using System;
using System.Collections.Generic;
using System.Text;

class Provadia
{
    static void Main()
    {
        decimal n = decimal.Parse(Console.ReadLine());

        if (n < 0 || n > decimal.MaxValue) return;

        if (n == 0)
        {
            Console.WriteLine('A');
            return;
        }

        List<string> result = new List<string>();

        string[] ProvadiaNumbers = new string[260];

        for (int i = 0; i < 26; i++)
        {
            ProvadiaNumbers[i] = ((char)('A' + i)).ToString();
        }

        for (int k = 1; k <= 9; k++)
        {
            for (int i = 26 * k; i < 26 * (k + 1); i++)
            {
                StringBuilder number = new StringBuilder();
                number.Append((char)('a' + k-1));
                number.Append((char)('A' + i - 26*k));

                ProvadiaNumbers[i] = number.ToString();
            }
        }

        while (n > 1)
        {
            result.Add(string.Format("{0}", ProvadiaNumbers[(int)(n % 256)]));
            n = n / 256;
        }

        result.Reverse();

        foreach (var item in result)
        {
            Console.Write(item);
        }

        Console.WriteLine();
    }
}
