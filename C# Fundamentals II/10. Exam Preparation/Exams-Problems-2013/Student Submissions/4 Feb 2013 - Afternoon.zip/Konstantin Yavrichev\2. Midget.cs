using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02
{
    class Program
    {
        public static void Main()
        {
            int[] Vally0 = {1, 3, -6, 7, 4, 1, 12};
            int Vally0_Length = Vally0.Length;

                        
            for (int i = 0; i < (Vally0_Length - 1); i++)
            {
                Console.Write("{0}, ", Vally0[i]);
                
            }
             Console.WriteLine("{0}", Vally0[Vally0_Length-1]);
            

            /*
            Console.Write("Enter N: ");
            int N = int.Parse(Console.ReadLine());


            int[] array = new int[N];
            for (int i = 0; i < N; i++)
            {
                Console.Write("Enter array element {0}: ", i);
                array[i] = int.Parse(Console.ReadLine());
            }
            */
        }
    }
}
