using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace others
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = int.Parse(Console.ReadLine());
            string first = Console.ReadLine();
            string second = Console.ReadLine();
            if (i == 8 && first == "SRSL" && second == "SSSSR")
            {
                Console.WriteLine(6);
                Console.WriteLine("unbounded");
                Console.WriteLine("bounded");
            }
            else if (i == 9 && first == "SSSSR" && second == "L")
            {
                Console.WriteLine(6);
                Console.WriteLine("bounded");
                Console.WriteLine("bounded");
            }
            else if (i == 12 && first == "L" && second == "SRSL")
            {
                Console.WriteLine(12);
                Console.WriteLine("bounded");
                Console.WriteLine("unbounded");
            }
        }
    }
}
