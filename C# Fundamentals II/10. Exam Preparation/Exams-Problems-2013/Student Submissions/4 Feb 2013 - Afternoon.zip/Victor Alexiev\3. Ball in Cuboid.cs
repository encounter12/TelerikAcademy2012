using System;

namespace BallInCuboid
{
    enum CellType
    {
        Slide,
        Teleport,
        Empty,
        Basket
    }

    class Cell
    {
        public CellType Type { get; private set; }
        public int DirectionWidth { get; private set; }
        public int DirectionDepth { get; private set; }

        public Cell(CellType type, int directionWidth, int directionDepth)
        {
            this.Type = type;
            this.DirectionWidth = directionWidth;
            this.DirectionDepth = directionDepth;
        }
    }

    class BallInCuboid
    {
        static void Main()
        {
            string inputDimensions = Console.ReadLine();
            string[] dimensions = inputDimensions.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            int width = Int32.Parse(dimensions[0]);
            int height = Int32.Parse(dimensions[1]);
            int depth = Int32.Parse(dimensions[2]);

            Cell[, ,] cuboid = new Cell[width, height, depth];

            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] sequence = line.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

                for (int d = 0; d < depth; d++)
                {
                    string[] codes = sequence[d].Split(new char[] { ')', '(', ' ' }, StringSplitOptions.RemoveEmptyEntries);

                    int index = -0;
                    int w = 0;
                    while (index < codes.Length)
                    {
                        switch (codes[index])
                        {
                            case "S":
                                {
                                    string direction = codes[++index];
                                    int dirWidth = 0;
                                    int dirDepth = 0;
                                    switch (direction)
                                    {
                                        case "L":
                                            {
                                                dirWidth = -1;
                                                dirDepth = 0;
                                                break;
                                            }
                                        case "R":
                                            {
                                                dirWidth = 1;
                                                dirDepth = 0;
                                                break;
                                            }
                                        case "F":
                                            {
                                                dirWidth = 0;
                                                dirDepth = -1;
                                                break;
                                            }
                                        case "B":
                                            {
                                                dirWidth = 0;
                                                dirDepth = 1;
                                                break;
                                            }
                                        case "FL":
                                            {
                                                dirWidth = -1;
                                                dirDepth = -1;
                                                break;
                                            }
                                        case "FR":
                                            {
                                                dirWidth = 1;
                                                dirDepth = -1;
                                                break;
                                            }
                                        case "BL":
                                            {
                                                dirWidth = -1;
                                                dirDepth = 1;
                                                break;
                                            }
                                        case "BR":
                                            {
                                                dirWidth = 1;
                                                dirDepth = 1;
                                                break;
                                            }
                                        default:
                                            {
                                                break;
                                            }
                                    }

                                    cuboid[w, h, d] = new Cell(CellType.Slide, dirWidth, dirDepth);
                                    break;
                                }
                            case "E":
                                {
                                    cuboid[w, h, d] = new Cell(CellType.Empty, 0, 0);
                                    break;
                                }
                            case "T":
                                {
                                    int dirWidth = Int32.Parse(codes[++index]);
                                    int dirDepth = Int32.Parse(codes[++index]);

                                    cuboid[w, h, d] = new Cell(CellType.Teleport, dirWidth, dirDepth);
                                    break;
                                }
                            case "B":
                                {
                                    cuboid[w, h, d] = new Cell(CellType.Basket, 0, 0);
                                    break;
                                }
                            default:
                                {
                                    break;
                                }
                        }

                        index++;
                        w++;
                    }
                }
            }

            string ballInput = Console.ReadLine();
            string[] ballCoordinates = ballInput.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            int ballWidth = Int32.Parse(ballCoordinates[0]);
            int ballDepth = Int32.Parse(ballCoordinates[1]);
            int ballHeight = 0;
            while (ballHeight < height)
            {
                Cell currentCell = cuboid[ballWidth, ballHeight, ballDepth];

                switch (currentCell.Type)
                {
                    case CellType.Slide:
                    case CellType.Teleport:
                        {
                            ballWidth += currentCell.DirectionWidth;
                            ballDepth += currentCell.DirectionDepth;
                            break;
                        }
                    case CellType.Empty:
                        {
                            ballHeight++;
                            break;
                        }
                    case CellType.Basket:
                        {
                            Console.WriteLine("No\n{0} {1} {2}", ballWidth, ballHeight, ballDepth);
                            return;
                        }
                    default:
                        {
                            break;
                        }
                }
            }

            Console.WriteLine("No\n{0} {1} {2}", ballWidth, ballHeight - 1, ballDepth);
        }
    }
}
