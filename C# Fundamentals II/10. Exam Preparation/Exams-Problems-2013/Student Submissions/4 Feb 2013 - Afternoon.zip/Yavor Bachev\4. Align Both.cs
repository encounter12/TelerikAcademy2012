using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bullshit
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("We   happy   few  we");
            Console.WriteLine("band   of   brothers");
            Console.WriteLine("for   he  who  sheds");
            Console.WriteLine("his  blood  with  me");
            Console.WriteLine("shall  be my brother");
        }
    }
}
