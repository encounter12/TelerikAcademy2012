using System;
using System.Numerics;

class ProvadiaNumbers
{
    static void Main(string[] args)
    {
        BigInteger dec = BigInteger.Parse(Console.ReadLine());

        string[] ProvadiaNumbers = new string[256];

        for (int i = 0, j = 65, k = 96; i < ProvadiaNumbers.Length; i++, j++)
        {
            if (j == 91)
            {
                j = 65;
                k++;
            }
            char value = (char)j;
            if (i < 26)
            {
                ProvadiaNumbers[i] = value.ToString();
            }
            else
            {
                ProvadiaNumbers[i] = (char)k + value.ToString();
            }
        }

        string result = "";

        if (dec == 0) result = ProvadiaNumbers[0];

        while (dec > 0)
        {
            result = ProvadiaNumbers[(int)(dec % 256)] + result;
            dec /= 256;
        }

        Console.WriteLine(result);
    }
}

