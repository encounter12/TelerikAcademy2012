using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
class Midget
{
    static void Main()
    {
        #region Read Input
        //Read Input
        string valleyStr = Console.ReadLine();
        int m = int.Parse(Console.ReadLine());
        string[] patternStr = new string[m];
        int[][] patterns = new int[m][];
 
        for (int i = 0; i < m; i++)
        {
            patternStr[i] = Console.ReadLine();
            string[] tempPat = patternStr[i].Split(',');
            patterns[i] = new int[tempPat.Length];
            for (int j = 0; j < tempPat.Length; j++)
            {
                patterns[i][j] = int.Parse(tempPat[j]);
            }
 
        }
 
        string[] tempValley = valleyStr.Split(',');
        int[] valley = new int[tempValley.Length];
        for (int i = 0; i < tempValley.Length; i++)
        {
            valley[i] = int.Parse(tempValley[i]);
        }
 
        #endregion
 
 
        long collectedCoins = 0;
        long maxNumCoins = long.MinValue;
        bool[] visited = new bool[valley.Length];
        bool visErr = false;
        bool outBox = false;
        collectedCoins = 0;
        int currentPos = 0;
        for (int i = 0; i < m; i++)
        {
            collectedCoins = valley[0];
            if (patterns[i][0] == 0)
            {
                maxNumCoins = valley[0];
                visErr = true;
                break;
            }
 
            for (int j = 0; j < patterns[i].GetLength(0); j++)
            {
                if (j == 0)
                {
                    if (patterns[i][0] == 0)
                    {
                        collectedCoins = valley[0];
                        break;
                    }
                }
 
 
 
                if ((currentPos + patterns[i][j]) >= 0 && (currentPos + patterns[i][j]) < valley.Length)
                {
                    if (visited[currentPos + patterns[i][j]] != true)
                    {
 
                        collectedCoins += valley[currentPos + patterns[i][j]];
                        visited[currentPos] = true;
                        currentPos += patterns[i][j];
                    }
                    else
                    {
                        visErr = true;
                        break;
                    }
                }
                else
                {
                    outBox = true;
                    break;
                }
            }
 
            while (outBox != true && visErr != true)
            {
                for (int j = 0; j < patterns[i].GetLength(0); j++)
                {
                    if ((currentPos + patterns[i][j]) >= 0 && (currentPos + patterns[i][j]) < valley.Length)
                    {
                        if (visited[currentPos + patterns[i][j]] != true)
                        {
                            collectedCoins += valley[currentPos + patterns[i][j]];
                            visited[currentPos] = true;
                            currentPos += patterns[i][j];
                        }
                        else
                        {
                            visErr = true;
                            break;
                        }
                    }
                    else
                    {
                        outBox = true;
                        break;
                    }
                }
 
            }
 
            if (collectedCoins > maxNumCoins)
            {
                maxNumCoins = collectedCoins;
            }
            collectedCoins = 0;
            currentPos = 0;
            visErr = false;
            outBox = false;
 
            for (int k = 0; k < visited.Length; k++)
            {
                visited[k] = false;
            }
        }
 
        Console.WriteLine(maxNumCoins);
 
 
    }
}