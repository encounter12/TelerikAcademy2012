using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem4_AllignBoth
{
    class AllignBoth
    {
        static void Main(string[] args)
        {
            int initialLines = int.Parse(Console.ReadLine());
            int lineMaxWidth = int.Parse(Console.ReadLine());

            StringBuilder text = new StringBuilder();

            List<string> words = new List<string>();

            for (int i = 0; i < initialLines; i++)
            {
                string line = Console.ReadLine();
                string[] lineArr = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                foreach (var word in lineArr)
                {
                    words.Add(word);
                }
            }

            int count = 1;
            int testWordIndex = 0;
            int wordsOnLine = 0;
            int testLength = 0;
            int lastWordIndex = 0;

            while (true)
            {
                StringBuilder line = new StringBuilder();
                if ((testLength + words[testWordIndex].Length + (wordsOnLine - 1)) < lineMaxWidth)
                {
                    testLength += words[testWordIndex].Length;
                    //line.Append(words[testWordIndex]);
                    //line.Append(' ');
                    wordsOnLine++;
                    testWordIndex++;
                    //words.Remove(words[testWordIndex]);
                }
                else if ((testLength + words[testWordIndex].Length + (wordsOnLine - 1)) > lineMaxWidth)
                {
                    testWordIndex--;
                    int difference = (testLength + words[testWordIndex].Length + (wordsOnLine)) - lineMaxWidth;
                    testLength = 0;

                    string gap = new string(' ', difference / wordsOnLine + 1);

                    for (int i = lastWordIndex; i <= testWordIndex; i++)
                    {
                        line.Append(words[i]);
                        if (i != testWordIndex)
                        {
                            line.Append(gap);
                        }
                    }
                    Console.WriteLine(line);
                    line.Clear();
                    wordsOnLine = 0;
                    testWordIndex++;
                    lastWordIndex = testWordIndex;
                }

                if (testWordIndex == words.Count)
                {
                    break;
                }
            }

        }
    }
}
