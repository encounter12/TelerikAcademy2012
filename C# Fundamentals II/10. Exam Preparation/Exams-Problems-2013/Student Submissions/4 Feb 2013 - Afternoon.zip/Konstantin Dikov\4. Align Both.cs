using System;
using System.Text.RegularExpressions;
using System.Text;

class Task3
{
    static void Main()
    {
        int linesN = int.Parse(Console.ReadLine());
        int width = int.Parse(Console.ReadLine());

        StringBuilder allText = new StringBuilder();
        for (int i = 0; i < linesN; i++)
        {
            allText.Append(Console.ReadLine());
            allText.Append(" ");
        }

        string[] words = Regex.Split(allText.ToString(), @"\s+");

        int currentWord = 0;
        int startWord = 0;
        int lineWords = 0;
        int currentWidth = 0;
        int whiteSpaces = 0;
        int neededWhiteSpaces = 0;
        bool spareSpace = true;
        int startingSpaces = 0;
        bool recursion = false;
        int buffer = 0;

        StringBuilder outputLine = new StringBuilder();
        while (true)
        {
            if (!recursion)
            {
                startWord = currentWord;
                currentWidth = 0;
            }
            else
            {
                currentWord = startWord;
            }
            
            
            while (currentWidth + lineWords + words[currentWord].Length + buffer <= width && currentWord < words.Length - 1)
            {
                currentWidth = currentWidth + words[currentWord].Length;
                currentWord++;
                lineWords++;
            }

            lineWords--;
            neededWhiteSpaces = width - currentWidth;
            if (lineWords!=0)
            {
                if (neededWhiteSpaces % lineWords == 0)
                {
                    whiteSpaces = neededWhiteSpaces / lineWords;
                }
                else
                {
                    whiteSpaces = neededWhiteSpaces / lineWords + 1;
                }
            }
            startingSpaces = whiteSpaces;
            
            for (int i = startWord; i < currentWord; i++)
            {
                if (i == currentWord - 1)
                {
                    outputLine.Append(words[i]);
                }
                else
                {
                    outputLine.Append(words[i] + "".PadRight(whiteSpaces, ' '));
                }
                neededWhiteSpaces = neededWhiteSpaces - whiteSpaces;
                lineWords--;

                if (startingSpaces - whiteSpaces > 1)
                {
                    recursion = true;
                    buffer = buffer + words[currentWord].Length;
                    break;
                }
                else
                {
                    recursion = false;
                }
                if (lineWords > 0)
                {
                    whiteSpaces = (int)Math.Ceiling(neededWhiteSpaces / (decimal)lineWords);
                }
            }

            if (!recursion)
            {
                Console.WriteLine(outputLine.ToString());
                lineWords = 0;
                if (currentWord >= words.Length - 1)
                {
                    break;
                }
                buffer = 0;
            }

            outputLine.Clear();
        }
    }
}