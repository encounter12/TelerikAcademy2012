
using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Threading.Tasks;



namespace zadacha5
{



    class Program
    {



        static void Main(string[] args)
        {

            // Lamps

            int n = int.Parse(Console.ReadLine());

            int[] lamps = new int[n];

            for (int i = 1; i <= n; i++)
            {

                lamps[i - 1] = i;

            }

            int indexOfLast = 0;

            for (int i = 0; i < n; i++)
            {

                if (lamps[i] != 0)
                {

                    lamps[i] = 0;

                    for (int j = i; j < n; j = j + i + 2)
                    {

                        lamps[j] = 0;

                    }

                    indexOfLast = i;

                }

            }

            indexOfLast++;

            //BOT



            string commands1;

            string commands2;



            commands1 = Console.ReadLine();

            commands2 = Console.ReadLine();



            int brS = 0;

            int brR = 0;

            int brL = 0;

            bool[] bound = new bool[2];

            bound[0] = true;

            bound[1] = true;


            for (int i = 0; i < commands1.Length; i++)
            {
                if (commands1[i] == 'S') brS++;
            }
            int maxDistance = brS;
            brS = 0;
            while (true)
            {
                for (int i = 0; i < commands1.Length; i++)
                {

                    if (commands1[i] == 'S') brS++;

                    if (commands1[i] == 'R' && (brR % 2) != 0)
                    {
                        bound[0] = false;
                        break;
                    }
                    else
                        if (commands1[i] == 'R') brR++;
                    if (commands1[i] == 'L' && (brR % 2) != 0)
                    {
                        bound[0] = false;
                        break;

                    }
                    else
                        if (commands1[i] == 'L')
                        {
                            brL++;
                        }
                }
                if (!bound[0]) break;

            }

            brS = 0;

            brR = 0;

            brL = 0;
            for (int i = 0; i < commands2.Length; i++)
            {
                if (commands2[i] == 'S') brS++;
            }
            maxDistance = brS;
            brS = 0;
            while (true)
            {
                for (int i = 0; i < commands2.Length; i++)
                {

                    if (commands2[i] == 'S') brS++;
                    if (maxDistance < brS)
                    {
                        bound[1] = false;
                        break;
                    }
                    if (commands2[i] == 'R' && (brR % 2) != 0)
                    {
                        bound[1] = false;
                        break;
                    }
                    else
                        if (commands2[i] == 'R') brR++;
                    if (commands2[i] == 'L' && (brR % 2) != 0)
                    {
                        bound[1] = false;
                        break;

                    }
                    else
                        if (commands2[i] == 'L')
                        {
                            brL++;
                        }
                }
                if (!bound[1]) break;
            }


            Console.WriteLine(indexOfLast);

            if (bound[0]) Console.WriteLine("bounded");

            else Console.WriteLine("unbounded");

            if (bound[1]) Console.WriteLine("bounded");

            else Console.WriteLine("unbounded");





        }

    }

}