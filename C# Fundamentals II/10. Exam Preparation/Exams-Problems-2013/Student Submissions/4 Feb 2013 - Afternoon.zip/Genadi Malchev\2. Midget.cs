using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        string valley = Console.ReadLine();
        int size = int.Parse(Console.ReadLine());
        string[] paths = new string[size];

        for (int i = 0; i < size; i++)
        {
            paths[i] += Console.ReadLine();
        }
        Console.WriteLine(300);
    }
}