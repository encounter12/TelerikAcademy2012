using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.Midget
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());

            int firstNumber = 2;
            int [] lamps = new int [N+1];
            int max = 2000001;

            for (int i = 0; i < N+1; i++)
			{
			    lamps[i] = i;
			}

            for (int i = 1; i < lamps.Length; i += 2)
            {
                lamps[i] = max;
            }

            for (int i = firstNumber; i < lamps.Length; i += 3)
            {
                if (lamps[i] < max)
                {
                    lamps[i] = max;
                }
                else
	                {
                        break;
	                }
            }

            for (int i = firstNumber+2; i < lamps.Length; i += 3)
            {
                if (lamps[i] < max)
                {
                    lamps[i] = max;
                }
                else
                {
                    break;
                }
            }

            for (int i = firstNumber+4; i < lamps.Length; i += 3)
            {
                if (lamps[i] < max)
                {
                    lamps[i] = max;
                }
                else
                {
                    break;
                }
            }

            for (int i = firstNumber + 6; i < lamps.Length; i += 3)
            {
                if (lamps[i] < max)
                {
                    lamps[i] = max;
                }
                else
                {
                    break;
                }
            }

            for (int i = firstNumber + 8; i < lamps.Length; i += 3)
            {
                if (lamps[i] < max)
                {
                    lamps[i] = max;
                }
                else
                {
                    break;
                }
            }

            for (int i = firstNumber + 12; i < lamps.Length; i += 3)
            {
                if (lamps[i] < max)
                {
                    lamps[i] = max;
                }
                else
                {
                    break;
                }
            }

            for (int i = 1; i < lamps.Length; i++)
            {
                if (lamps[i] < max)
                {
                    Console.WriteLine(lamps[i]);
                }
                continue;
            }
        }
    }

}