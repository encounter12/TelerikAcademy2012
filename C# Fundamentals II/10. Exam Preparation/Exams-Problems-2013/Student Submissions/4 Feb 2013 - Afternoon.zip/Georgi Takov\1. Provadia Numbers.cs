using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.TaskOne
{
    class Program
    {
        static void Main(string[] args)
        {
            ulong number = ulong.Parse(Console.ReadLine());
            int count=1;
            double test;
            int increment=0;
            int startIndex=65;
            int startIndexSmall=97;
            int smallcount = 0;
            ulong testNum=number;
            ulong remainder;
            int alphabetLength=25; // counting from 0
            string[] provadia = new string[256];
            for (int i = 0; i <=alphabetLength; i++)
            {
                
                    provadia[i] = char.ConvertFromUtf32(startIndex);
                    startIndex++;
                
            }
            startIndex=65;
            for (int i = alphabetLength+1; i < provadia.Length-1; i++)
            {
                while (startIndex < 91)
                {
                        provadia[i] = char.ConvertFromUtf32(startIndexSmall) + char.ConvertFromUtf32(startIndex);
                        startIndex++;
                        if (i + 1 < provadia.Length)
                            i++;
                        else
                            break;
                }
                i--;
                startIndex = 65;
                startIndexSmall++;
            }
            if (number <= 26)
                Console.WriteLine(provadia[Convert.ToInt32(number)]);
            else
                if (number < 256)
                    Console.WriteLine(provadia[Convert.ToInt32(number)]);
                else
                {
                    remainder = number - 255;
                    while ((remainder) > 255*256)
                    {
                        count++;
                        remainder -=255;
                    }
                    for (decimal i = 0; i < count; i++)
                    {
                        remainder = number - 255;
                        test = remainder % 256;
                        if(test>0.51)
                            while (remainder % 256 != 0)
                            {
                                increment++;
                                remainder++;
                            }
                        else
                            while (remainder % 256 != 0)
                            {
                                increment--;
                                remainder--;
                            }
                    }
                    Console.WriteLine("{0}{1}",provadia[remainder/256],provadia[number-remainder]);
                     
                }

        }
    }
}