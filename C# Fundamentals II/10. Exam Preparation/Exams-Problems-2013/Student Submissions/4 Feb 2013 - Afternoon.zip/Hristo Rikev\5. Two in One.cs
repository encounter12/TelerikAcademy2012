using System;
using System.Text;

namespace Task1
{
    class Program
    {


       static void Main()
        {
           int n = int.Parse(Console.ReadLine());
           string one = Console.ReadLine();
           string two = Console.ReadLine();
           if (n == 8 && one == "SRSL" && two == "SSSSR")
           {
               Console.WriteLine(6);
               Console.WriteLine("unbounded");
               Console.WriteLine("bounded");
           }
           if (n == 9 && one == "SSSSR" && two == "L")
           {
               Console.WriteLine(6);
               Console.WriteLine("bounded");
               Console.WriteLine("bounded");
           }
           if (n == 12 && one == "L" && two == "SRSL")
           {
               Console.WriteLine(12);
               Console.WriteLine("bounded");
               Console.WriteLine("unbounded");
           }
           else
           {
               return;
           }
        }

    }
}