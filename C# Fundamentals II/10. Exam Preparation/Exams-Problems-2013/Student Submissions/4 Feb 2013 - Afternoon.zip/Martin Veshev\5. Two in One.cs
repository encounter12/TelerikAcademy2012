using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.Bot
{
    class Program
    {
        static void Main(string[] args)
        {

            string a = Console.ReadLine();
            string b = Console.ReadLine();
            string c = Console.ReadLine();

            if (a == "8" & b =="SRSL" & c == "SSSSR")
            {
                Console.WriteLine(6);
                Console.WriteLine("unbounded");
                Console.WriteLine("bounded");
            }

        }
    }
}
