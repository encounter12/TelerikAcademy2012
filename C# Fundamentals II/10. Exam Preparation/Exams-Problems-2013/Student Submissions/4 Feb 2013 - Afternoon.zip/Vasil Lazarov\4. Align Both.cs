using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlignBoth
{
    class Program
    {
        static string WrihgtLine(List<string> words, int lenght, int i, int startWord, int count)
        {
            int whiteSpaces = i - startWord - 1;
            int numberWhiteSpaces = (lenght - count) / whiteSpaces + 1;
            int addWhiteSpaces = (lenght - count) % whiteSpaces;
            StringBuilder line = new StringBuilder();
            for (int j = startWord, a = 0; j < i; j++, a++)
            {
                line.Append(words[j]);
                if (j == i - 1)
                {
                    break;
                }
                for (int k = 0; k < numberWhiteSpaces; k++)
                {
                    line.Append(" ");
                }
                if (a < addWhiteSpaces && addWhiteSpaces > 0)
                {
                    line.Append(" ");
                }
            }
            return line.ToString();
        }

        static List<string> ReadWords(List<string> words, int lenght)
        {
            int count = 0;
            int startWord = 0;
            List<string> justify = new List<string>();
            for (int i = 0; i < words.Count; i++)
            {

                string word = words[i];
                count += word.Length + 1;
                if (count - 1 > lenght)
                {
                    if (startWord == i - 1)
                    {
                        string onOneLine = words[i - 1];
                        int whiteSpaces = lenght - words[i - 1].Length;
                        for (int j = 0; j < whiteSpaces; j++)
                        {
                            onOneLine += " ";
                        }
                        justify.Add(onOneLine);
                        startWord = i;
                        i = startWord - 1;
                    }
                    else
                    {
                        count -= words[i].Length;
                        justify.Add(WrihgtLine(words, lenght, i, startWord, count - 2));
                        startWord = i;
                        i = startWord - 1;
                    }
                    count = 0;
                }
                else if (i == words.Count - 1)
                {
                    if (startWord == i)
                    {
                        justify.Add(words[i]);
                    }
                    else
                    {
                        justify.Add(WrihgtLine(words, lenght, i + 1, startWord, count - 1));
                    }
                }
            }
            return justify;
        }

        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int w = int.Parse(Console.ReadLine());

            string[] text = new string[n];
            for (int i = 0; i < text.Length; i++)
            {
                text[i] = Console.ReadLine();
            }
            List<string> words = new List<string>();
            char[] separetor = { ' ' };
            for (int i = 0; i < text.Length; i++)
            {
                string[] wordsString = text[i].Split(separetor, StringSplitOptions.RemoveEmptyEntries);
                for (int j = 0; j < wordsString.Length; j++)
                {
                    int wordsLenght = wordsString[j].Length;
                    if (wordsLenght > w)
                    {
                        w = wordsLenght;
                    }
                    int lenght = wordsString[j].Length;
                    words.Add(wordsString[j]);
                }
            }
            List<string> justify = ReadWords(words, w);
            foreach (var item in justify)
            {
                Console.WriteLine(item);
            }
        }
    }
}
