using System;

class TrirdExam
{
    static void Main(string[] args)
    {
        Console.WriteLine(21);
    }
}
