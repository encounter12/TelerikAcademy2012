using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static int words_lenght=0;

    static void Main(string[] args)
    {
        int num_lines = int.Parse(Console.ReadLine());
        int line_len = int.Parse(Console.ReadLine());
        List<string> words = new List<string>();
        for (int l = 0; l < num_lines; l++){
			    words.AddRange(Console.ReadLine().Split(new char[] {' '}, StringSplitOptions.RemoveEmptyEntries).ToList<string>());
		}

        while(true){
            if(words.Count==0){
                break;
            }
            words_lenght = 0;
            int words_cnt = words_in_line(words, line_len);
            int white_cnt = words_cnt-1;
            StringBuilder line = new StringBuilder();

            int white_static = 0;
            int white_dinam = 0;
            if (white_cnt==0){
                white_static = 0;
                white_dinam = 0;
            }
            else{
                white_static = (line_len - words_lenght) / white_cnt;
                white_dinam = (line_len - words_lenght) % white_cnt;
            }

            for (int w = 0; w < words_cnt; w++)
            {
                line.Append(words[0]);
                if (white_static!=0 && w!=(words_cnt-1)){
                    if (white_dinam!=0){
                        line.Append(" ".PadLeft(white_static + 1));
                        white_dinam--;
                    }
                    else{
                        line.Append(" ".PadLeft(white_static));
                    }
                }
                words.RemoveAt(0);
            }
            Console.WriteLine(line.ToString());
        }
    }

    static int words_in_line(List<string> words, int line_len){
        int words_cnt = 0;
        int cur_lenght = 0;
        while(true){
            if (words_cnt == words.Count()){
                break;
            }
            cur_lenght += words[words_cnt].Length;
            if (cur_lenght+words_cnt>line_len){
                cur_lenght -= words[words_cnt].Length;
                break;
            }
            words_cnt++;
        }
        words_lenght = cur_lenght;
        return words_cnt;
    }
}
