using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opiti
{
    class Opiti
    {
        static void Main()
        {

            ulong number = ulong.Parse(Console.ReadLine());
            int remainder = 0;
            StringBuilder converted = new StringBuilder();
            int capitalRemainder = 0;
            int lowRemainder = 0;
            if (number == 0)
            {
                Console.WriteLine('A');
            }
            while (number > 0)
            {
                lowRemainder = 0;
                capitalRemainder = 0;
                remainder = (int)(number % 256);
                number = number / 256;
                if (remainder > 25)
                {
                    lowRemainder = remainder / 26;
                    capitalRemainder = remainder % 26;
                }
                else
                {
                    capitalRemainder = remainder;
                }
                converted.Append((char)(capitalRemainder + 'A'));
                if (lowRemainder > 0)
                {
                    converted.Append((char)(lowRemainder + 'a' - 1));
                }
            }


            for (int i = converted.Length - 1; i >= 0; i--)
            {
                Console.Write(converted[i]);
            }
        }
    }
}
