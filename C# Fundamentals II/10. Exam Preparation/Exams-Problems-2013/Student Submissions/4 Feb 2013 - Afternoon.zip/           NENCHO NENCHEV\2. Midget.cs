using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Midget
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] inputValley = Regex.Split(Console.ReadLine(), @"[, ]+");
            int valleyLength = inputValley.Length;
            int valleyFixedLength = inputValley.Length - 1;
            int[] valley = new int[valleyLength];

            for (int i = 0; i < valleyLength; i++)
                valley[i] = int.Parse(inputValley[i]);

            int patternCount = int.Parse(Console.ReadLine());
            int maxCoins = int.MinValue;
            int currentPatternCoins, currentPosition;

            for (int k = 0; k < patternCount; k++)
            {
                currentPatternCoins = 0;
                currentPosition = 0;
                string[] inputPattern = Regex.Split(Console.ReadLine(), @"[, ]+");
                int patternLength = inputPattern.Length;
                int[] pattern = new int[patternLength];
                bool[] visited = new bool[valleyLength];

                for (int j = 0; j < patternLength; j++)
                    pattern[j] = int.Parse(inputPattern[j]);

                int position = 0;
                while (true)
                {
                    if (position == patternLength) position = 0;
                    if (currentPosition < 0 || currentPosition > valleyFixedLength || visited[currentPosition] == true) break;
                    currentPatternCoins += valley[currentPosition];
                    visited[currentPosition] = true;
                    currentPosition += pattern[position];
                    position++;
                }
                if (currentPatternCoins > maxCoins) maxCoins = currentPatternCoins;
            }

            Console.WriteLine(maxCoins);
        }
    }
}
