using System;
using System.Drawing;

namespace TwoInOne
{
    class TwoInOne
    {
        public static bool IsBalanced1(string expression)
        {
            int level = 0;
            foreach (var character in expression)
            {
                if (character == 'R')
                {
                    if (level == 0)
                    {
                        return false;
                    }
                    level--;
                }
                else if (character == 'L')
                {
                    level++;
                }
            }

            return level == 0;
        }

        public static bool IsBalanced2(string expression)
        {
            int level = 0;
            foreach (var character in expression)
            {
                if (character == 'L')
                {
                    if (level == 0)
                    {
                        return false;
                    }
                    level--;
                }
                else if (character == 'R')
                {
                    level++;
                }
            }

            return level == 0;
        }

        private static int GetLastSwitchedOn(int count)
        {
            Point[] lamps = new Point[count];

            for (int i = 0; i < count; i++)
            {
                lamps[i] = new Point(i, -1);
            }

            for (int march = 0; march < count; march++)
            {
                for (int step = march; step < count; step += march + 2)
                {
                    if (lamps[step].Y == -1)
                    {
                        lamps[step].Y = march;
                    }
                }
            }

            int maxMarch = 0;
            int lastSwitchedOn = 0;

            foreach (Point lamp in lamps)
            {
                if (lamp.Y >= maxMarch)
                {
                    maxMarch = lamp.Y;
                    lastSwitchedOn = lamp.X;
                }
            }

            return lastSwitchedOn;
        }

        private static bool IsBounded(string commands)
        {
            if (commands.IndexOf("S") == -1)
            {
                return true;
            }

            if (IsBalanced1(commands) || IsBalanced2(commands))
            {
                return false;
            }

            return true;
        }

        static void Main()
        {
            string input = Console.ReadLine();
            int count = Int32.Parse(input);

            string commands1 = Console.ReadLine();

            string commands2 = Console.ReadLine();

            int last = 0;// GetLastSwitchedOn(count);

            Console.WriteLine(last + 1);

            bool isBounded1 = IsBounded(commands1);

            bool isBounded2 = IsBounded(commands2);

            Console.WriteLine("{0}bounded", isBounded1 ? String.Empty : "un");

            Console.WriteLine("{0}bounded", isBounded2 ? String.Empty : "un");
        }
    }
}