using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;


namespace CsharpExam2
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger input = BigInteger.Parse(Console.ReadLine());
            char[] table = new char[26];
            //for (int i = 0; i <= 25; i++)
            //{
            //    table[i] = (char)('A' + i);
            //}
            //StringBuilder numbers = new StringBuilder();
            //for (int i = 0; i <= 255; i++)
            //{
            //    numbers.Insert(i, table[i] );
            //}
            for (int i = 0; i < 26; i++)
            {
                table[i] = (char)('A' + i);
            }
            if (input >= 0 || input <=25 )
            {
                Console.WriteLine(table[(int)input]);
            }
        }
    }
}
