using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Midget
{
    class Midget
    {
        static string[] separators = new string[] { ",", " " };
        static void Main()
        {
            string[] valley = ConvertToArray(Console.ReadLine());
            int pattensNumber = short.Parse(Console.ReadLine());
            int maxCount = int.MinValue;

            for (int i = 0; i < pattensNumber; i++)
            {
                maxCount = Math.Max(maxCount, CollectCoins(valley, (ConvertToArray(Console.ReadLine()))));
            }
            Console.WriteLine(maxCount);
        }

        static string[] ConvertToArray(string inputString)
        {
            return inputString.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        }

        static int CollectCoins(string[] valley, string[] pattern)
        {
            int coins = 0;
            bool[] visited = new bool[valley.Length];
            
            int inPattern = 0;
            int inValley = 0;
            while (inValley >= 0 && inValley < valley.Length)
            {
                if (visited[inValley] == false)
                {
                    coins += int.Parse(valley[inValley]);
                    visited[inValley] = true;
                    inValley += int.Parse(pattern[inPattern]);
                    inPattern = (inPattern + 1) % pattern.Length;
                }
                else
                {
                    break;
                }
            }

            return coins;
        }
    }
}
