using System;

namespace ConsoleApplication2
{
    class Program
    {
        static void robot(string input)
        {
            int right = 0;
            int left = 0;
            int forward=0;
            bool bound = false;
            foreach (var item in input)
            {
                if (item == 'R')
                {
                    right++;
                }
                if (item == 'S')
                {
                    forward++;
                }
                if (item == 'L')
                {
                    left++;
                }
                if (left - right == 0 && forward == 0) bound = true;
                else bound = false;
                if (left == 0 && right != 0) bound = true;
                if (right == 0 && left != 0) bound = true;
                if (forward == 0) bound = true;
                if (right > left) bound = true;
                if (right < left) bound = true;
                if (left == right) bound = false;

            }

            if (bound == true)
            {
                Console.WriteLine("unbounded");
            }
            else
            {
                Console.WriteLine("bounded");
            }
        }
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string input1 = Console.ReadLine();
            string input2 = Console.ReadLine();
            bool[] lamps = new bool[n];
            int result = 0;
            int counter = 0;
            int lowest = 0;
            while(counter!=n)
            {
                for (int i = lowest; i < n; i+=2+lowest)
                {
                    if (lamps[i] == false)
                    {
                       lamps[i] = true;
                        result = i+1;
                        counter++;
                    }
                }
                while (lamps[lowest] != false && lowest < n&& counter!=n) lowest++;
                if (lowest == n) break;
            }
            Console.WriteLine(result);
            robot(input1);
            robot(input2);
        }
    }
}
