using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestLamps1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] lamps = new int[n + 1];
            lamps[0] = 1;
            int startIndex = 1;
            int lastLampSwitched = 1;
            int step = 1;
            int count = 0;
            while (startIndex > 0)
            {
                startIndex = Array.IndexOf(lamps, 0);

                if ((startIndex > n) || (startIndex < 0))
                {
                    break;
                }
                else
                {
                    //lastLampSwitched = startIndex;
                    for (int i = startIndex; i <= n; i = i + step + 1)
                    {
                        if (lamps[i] != 1)
                        {
                            lamps[i] = 1;
                            lastLampSwitched = i;
                        }
                       
                    }
                }
                step++;
                //Console.WriteLine(startIndex);
            }
            Console.WriteLine(lastLampSwitched);
            //for(int i = 0; i < n+1; i++)
            //{
                //Console.WriteLine(lamps[i]);
            //}
        }
    }
}
