using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace midget
{
    class Program
    {
        static void Main(string[] args)
        {
            string numbersInvalley = Console.ReadLine();
            string[] numbers = numbersInvalley.Split(',');
            int[] valey = new int[numbers.Length];

            for (int i = 0; i < valey.Length; i++)
            {
                valey[i] = int.Parse(numbers[i].Trim());
            }
            int[] newValey = new int[numbers.Length];
            for (int i = 0; i < valey.Length; i++)
            {
                newValey[i] = valey[i];
            }
            short numberpaterns = short.Parse(Console.ReadLine());
            //int[] pattern1 = { 1, 3, -2 };

            int sum = valey[0];
            int start = 0;
            bool inValey = true;
            int maxSum = int.MinValue;
            for (int i = 1; i <= numberpaterns; i++)
            {

                inValey = true;
                sum = valey[0];
                start = 0;
                string pat = Console.ReadLine();
                string[] patspl = pat.Split(',');
                int[] pattern1 = new int[patspl.Length];
                for (int f = 0; f < patspl.Length; f++)
                {
                    pattern1[f] = int.Parse(patspl[f].Trim());
                }
                while (inValey)
                {
                    for (int g = 0; g < pattern1.Length; g++)
                    {
                        int j = pattern1[g];
                        if (start + j > valey.Length - 1 || start + j <= 0)
                        {
                            inValey = false;
                            break;
                        }
                        else
                        {
                            if (valey[start + j] > -1000 & valey[start + j] < 1000)
                            {
                                sum = sum + valey[start + j];
                                if (valey[start] > 0)
                                {
                                    valey[start] += 1000;
                                }
                                else
                                {
                                    valey[start] += -1000;
                                }
                                if (valey[start + j] > 0)
                                {
                                    valey[start + j] += 1000;
                                }
                                else
                                {
                                    valey[start + j] += -1000;
                                }
                                start = start + j;
                            }
                            else
                            {
                                inValey = false;
                                break;
                            }
                        }
                    }
                }
                for (int m = 0; m < valey.Length; m++)
                {
                    valey[m] = newValey[m];
                }
                if (sum > maxSum)
                {
                    maxSum = sum;
                }
            }
            Console.WriteLine(maxSum);
        }
    }
}