using System;

class Program
{
    private static string Convert(ulong number)
    {
        string result = String.Empty;
        if (number > 25)
        {
            result += (char)(number / 26 + 'a' - 1);
        }
        result += (char)(number % 26 + 'A');
        return result;
    }

    static void Main()
    {
        ulong n = ulong.Parse(Console.ReadLine());
        int digitsCount = 0;
        ulong copyOfN = n;
        do
        {
            ++digitsCount;
            n /= 256;
        }
        while (n != 0);

        n = copyOfN;
        string number = String.Empty;
        ulong mask;
        for (int i = 0; i < digitsCount; ++i)
        {
            mask = 1ul << ((digitsCount - 1 - i) * 8);
            number += Convert(n / mask);
            n %= mask;
        }
        Console.WriteLine(number);
    }
}