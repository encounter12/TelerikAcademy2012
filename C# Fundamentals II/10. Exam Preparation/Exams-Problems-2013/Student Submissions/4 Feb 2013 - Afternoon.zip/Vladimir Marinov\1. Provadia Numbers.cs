using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tasc1
{
    class Program
    {
        static void Main(string[] args)
        {
           // Console.WriteLine((char)('a' + 1));
            ulong A = ulong.Parse(Console.ReadLine());
            string[] B = new string[256];
            for (int i = 0; i < 26; i++)
            {
                B[i] = ((char)(65 + i)).ToString();
               // Console.WriteLine(B[i]);
            }
            int j = 0;
            int k = 0;
            for (int i = 26; i < 256; i++)
            {


                B[i] = ((char)('a' + k)).ToString() + ((char)(65 + (i%26)));//.ToString();
               // Console.WriteLine(B[i]);
                j++;
                if (j == 26)
                {
                    j = 0;
                    k++;
                }
            }
            ulong C = A;
            int Ind = 0;
            //int Count = 0;
            byte[] Bit = new byte[1000];


            while (C > 0) 
            {
                byte Ost = (byte)(C % 256);
                Bit[Ind] = Ost;

              //  Console.WriteLine("C({0})/256 = i ost {1}", C, Bit[Ind]);
                C = C / 256;
              // Console.WriteLine("C({0})/256 = ", C);
                Ind++;
            }
          
            Bit[Ind] = (byte)(C % 256);
            //Ind++;
            if (A == 0) Console.WriteLine("A");
            else
            for (int i = Ind-1; i >= 0; i--)
            {
                Console.Write(B[Bit[i]]);
            }
            Console.WriteLine();
            


           // Console.WriteLine(ulong.MaxValue);
        }
    }
}
