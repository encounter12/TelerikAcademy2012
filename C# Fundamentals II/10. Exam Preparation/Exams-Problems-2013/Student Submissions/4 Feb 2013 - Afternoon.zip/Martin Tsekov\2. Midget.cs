using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1
{
    class Program
    {
        static void Main()
        {
            decimal bestSum = int.MinValue;
            string a = Console.ReadLine();
            //string a = "1.1, -2, 200, 1.53";
            
            string[] b = a.Split(',');
            decimal[] seq = new decimal[b.Length];
            for (int i = 0; i < b.Length; i++)
            {
                seq[i] = decimal.Parse(b[i]);
            }

            int lines = int.Parse(Console.ReadLine());
            decimal sum;
            for (int i = 0; i < lines; i++)
            {
                sum = 0;
                sum = GutSum(seq);
                if(sum>bestSum) bestSum = sum;
            }
            Console.WriteLine(bestSum);


        }

        private static decimal GutSum(decimal[] seq)
        {
            string a = Console.ReadLine();
            //string a = "1";
            string[] b = a.Split(',');
            int[] moves = new int[b.Length];
            for (int i = 0; i < b.Length; i++)
            {
                moves[i] = int.Parse(b[i]);
            }


            bool weAreDone = false;
            decimal sum = seq[0];
            bool[] beenHere = new bool[seq.Length];
            int position = 0;

            while (!weAreDone)
            {
                foreach (var move in moves)
                {
                    position += move;
                    if (position < 0) return sum;
                    if (position > seq.Length - 1) return sum;
                    if (!beenHere[position])
                    {
                        sum += seq[position];
                        beenHere[position] = true;
                    }
                    else
                    {
                        weAreDone = true;
                        break;
                    }
                }
            }
            return sum;
        }
    }
}
