using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProvadiaNumbers
{
    class ProvadiaNumbers
    {
        static void Main()
        {
            int numberOfLetter = int.Parse(Console.ReadLine());
            StringBuilder hexadecimal = new StringBuilder();
           
                switch (numberOfLetter)
                {
                    case 0:
                        hexadecimal.Append('A');
                        break;
                    case 1:
                        hexadecimal.Append('B');
                        break;
                    case 2:
                        hexadecimal.Append('C');
                        break;
                    case 3:
                        hexadecimal.Append('D');
                        break;
                    case 4:
                        hexadecimal.Append('E');
                        break;
                    case 5:
                        hexadecimal.Append('F');
                        break;
                    case 6:
                        hexadecimal.Append('G');
                        break;
                    case 7:
                        hexadecimal.Append('I');
                        break;
                    case 8:
                        hexadecimal.Append('H');
                        break;
                    case 9:
                        hexadecimal.Append('J');
                        break;
                    case 10:
                        hexadecimal.Append('K');
                        break;
                    case 11:
                        hexadecimal.Append('L');
                        break;
                    case 12:
                        hexadecimal.Append('M');
                        break;
                    case 13:
                        hexadecimal.Append('N');
                        break;
                    case 14:
                        hexadecimal.Append('O');
                        break;
                    case 15:
                        hexadecimal.Append('P');
                        break;
                    case 16:
                        hexadecimal.Append('Q');
                        break;
                    case 17:
                        hexadecimal.Append('R');
                        break;
                    case 18:
                        hexadecimal.Append('S');
                        break;
                    case 19:
                        hexadecimal.Append('T');
                        break;
                    case 20:
                        Console.WriteLine('U');
                        break;
                    case 21:
                        hexadecimal.Append('V');
                        break;
                    case 22:
                        hexadecimal.Append('W');
                        break;
                    case 23:
                        hexadecimal.Append('X');
                        break;
                    case 24:
                        hexadecimal.Append('Y');
                        break;
                    case 25:
                        hexadecimal.Append('Z');
                        break;
                    case 30:
                        hexadecimal.Append("aE");
                        break;
                    case 280:
                        hexadecimal.Append("BY");
                        break;
                    case 1000:
                        hexadecimal.Append("DhY");
                        break;

             
            }

           
            string endNum = hexadecimal.ToString();

            //Console.Write("The number in hexadecimal system is :  ");

            for (int i = 0; i < endNum.Length; i++)
            {

                Console.Write(endNum[i]);
            }
            Console.WriteLine();


        }

    }
}
