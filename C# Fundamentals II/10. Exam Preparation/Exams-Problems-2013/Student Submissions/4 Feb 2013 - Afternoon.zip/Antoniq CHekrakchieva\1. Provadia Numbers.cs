using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp2_Exam
{
    class Program
    {
        static void Main()
        {

            ulong number = ulong.Parse(Console.ReadLine());
            ulong resultt = number / 256;
            if (number / 25 >= 256)
            {
                number = number - 256;
                switch (number)
                {

                    case 0: Console.Write("A"); break;
                    case 1: Console.Write("B"); break;
                    case 2: Console.Write("C"); break;
                    case 3: Console.Write("D"); break;
                    case 4: Console.Write("E"); break;
                    case 5: Console.Write("F"); break;
                    case 6: Console.Write("G"); break;
                    case 7: Console.Write("H"); break;
                    case 8: Console.Write("I"); break;
                    case 9: Console.Write("J"); break;
                    case 10: Console.Write("K"); break;
                    case 11: Console.Write("L"); break;
                    case 12: Console.Write("M"); break;
                    case 13: Console.Write("N"); break;
                    case 14: Console.Write("O"); break;
                    case 15: Console.Write("P"); break;
                    case 16: Console.Write("Q"); break;
                    case 17: Console.Write("R"); break;
                    case 18: Console.Write("S"); break;
                    case 19: Console.Write("T"); break;
                    case 20: Console.Write("U"); break;
                    case 21: Console.Write("V"); break;
                    case 22: Console.Write("W"); break;
                    case 23: Console.Write("X"); break;
                    case 24: Console.Write("Y"); break;
                    case 25: Console.Write("Z"); break;


                }

            }

            if (resultt > 25) resultt = resultt - 26;
            
                switch (resultt)
                {

                //    case 0: Console.Write("A"); break;
                    case 1: Console.Write("B"); break;
                    case 2: Console.Write("C"); break;
                    case 3: Console.Write("D"); break;
                    case 4: Console.Write("E"); break;
                    case 5: Console.Write("F"); break;
                    case 6: Console.Write("G"); break;
                    case 7: Console.Write("H"); break;
                    case 8: Console.Write("I"); break;
                    case 9: Console.Write("J"); break;
                    case 10: Console.Write("K"); break;
                    case 11: Console.Write("L"); break;
                    case 12: Console.Write("M"); break;
                    case 13: Console.Write("N"); break;
                    case 14: Console.Write("O"); break;
                    case 15: Console.Write("P"); break;
                    case 16: Console.Write("Q"); break;
                    case 17: Console.Write("R"); break;
                    case 18: Console.Write("S"); break;
                    case 19: Console.Write("T"); break;
                    case 20: Console.Write("U"); break;
                    case 21: Console.Write("V"); break;
                    case 22: Console.Write("W"); break;
                    case 23: Console.Write("X"); break;
                    case 24: Console.Write("Y"); break;
                    case 25: Console.Write("Z"); break;


                }
                number = number % 256;

                if (number < 26)
                {
                    Console.WriteLine((char)(number + 65));
                }
                else if (number > 25 & number < 256)
                {
                    char result = ((char)((number / 26) + 96));
                    Console.Write(result);
                    switch (number % 26)
                    {
                        case 0: Console.WriteLine("A"); break;
                        case 1: Console.WriteLine("B"); break;
                        case 2: Console.WriteLine("C"); break;
                        case 3: Console.WriteLine("D"); break;
                        case 4: Console.WriteLine("E"); break;
                        case 5: Console.WriteLine("F"); break;
                        case 6: Console.WriteLine("G"); break;
                        case 7: Console.WriteLine("H"); break;
                        case 8: Console.WriteLine("I"); break;
                        case 9: Console.WriteLine("J"); break;
                        case 10: Console.WriteLine("K"); break;
                        case 11: Console.WriteLine("L"); break;
                        case 12: Console.WriteLine("M"); break;
                        case 13: Console.WriteLine("N"); break;
                        case 14: Console.WriteLine("O"); break;
                        case 15: Console.WriteLine("P"); break;
                        case 16: Console.WriteLine("Q"); break;
                        case 17: Console.WriteLine("R"); break;
                        case 18: Console.WriteLine("S"); break;
                        case 19: Console.WriteLine("T"); break;
                        case 20: Console.WriteLine("U"); break;
                        case 21: Console.WriteLine("V"); break;
                        case 22: Console.WriteLine("W"); break;
                        case 23: Console.WriteLine("X"); break;
                        case 24: Console.WriteLine("Y"); break;
                        case 25: Console.WriteLine("Z"); break;

                    }
                }
            
            }
        }
    }