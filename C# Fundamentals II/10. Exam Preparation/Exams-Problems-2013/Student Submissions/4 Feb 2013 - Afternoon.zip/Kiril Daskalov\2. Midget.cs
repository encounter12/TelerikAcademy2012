using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_2___Midget
{
    class Program
    {
     
        static void Main(string[] args)
        {
            string arr = Console.ReadLine(); //input Vally
            int numPatrens = int.Parse(Console.ReadLine()); //input M 
            arr = arr.Replace(" ", "");
            string[] valley = arr.Split(',');

            string[] pattrens = new string[numPatrens];
            int sum = int.Parse(valley[0]);
            int position = 1;
            List<int> pHolder = new List<int>();
            pHolder.Add(position);
            int buffPos = 0;
            int bestSum = 0;
            //pattrens[0] = "1, 2, -3"; // input m in each line
            //pattrens[1] = "1, 3, -2"; // input m in each line
            //pattrens[2] = "1, -1"; // input m in each line
            for (int i = 0; i < numPatrens; i++)
            {
                pattrens[i] = Console.ReadLine();
                pattrens[i] = pattrens[i].Replace(" ", "");
                string[] patren = pattrens[i].Split(',');


                for (int c = 0; c < patren.Length; c++)
                {

                    position += int.Parse(patren[c]);

                    if (pHolder.IndexOf(position) < 0)
                    {
                        pHolder.Add(position);
                        sum += int.Parse(valley[position - 1]);
                    }
                    if (position  <= valley.Length/2 && c == patren.Length - 1)
                    {
                        c = -1;

                        buffPos = position;

                    }
                    else if (position  > valley.Length/2 && c == patren.Length - 1)
                    {
                        position = 1;
                       
                        break;
                    }
                   
                    if (buffPos == 1)
                    {
                        break;
                    }
                    
                   

                }
                if (sum>bestSum)
                {
                    position = 1;
                    bestSum = sum;
                    sum = 1;
                    pHolder.Clear();
                    pHolder.Add(1);
                    buffPos = 0;
                }

            }
            Console.WriteLine(bestSum);

        }

    }
}
