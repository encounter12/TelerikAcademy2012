using System;

class TwoInOne
{      
    static void TurnLampsOn(int[] lamps)
    {
        int action = 1;
        int last = 0;
        for (int i = 1; i < lamps.Length; i++)
        {
            if (lamps[i] == 0)
            {
                lamps[i] = 1;
                last = i;
                int count = 0;
                for (int j = i; j < lamps.Length; j++)
                {
                    if (lamps[j] == 0) count++;
                    if (lamps[j] == 0 && (count % (action + 1) == 0 && count >= action))
                    {
                        lamps[j] = 1;
                        last = j;
                    }
                }
                action++;
            }
        }
        Console.WriteLine(last);
    }
    static void TheBot(string directions)
    {
        byte right = 0;
        int height = 0;
        int width = 0;
        byte flag = 0;
        for (int k = 0; k < 10; k++)
        {
            for (int i = 0; i < directions.Length; i++)
            {
                if (directions[i] == 'S')
                {
                    switch (right)
                    {
                        case 0:
                            height++;
                            break;
                        case 1:
                            width++;
                            break;
                        case 2:
                            height--;
                            break;
                        case 3:
                            width--;
                            break;
                    }
                    break;
                }
                if (directions[i] == 'R')
                {
                    right++;
                    break;
                }
                if (directions[i] == 'L')
                {
                    right--;
                    break;
                }
                if (right < 0) right += 4;
                if (right >= 4) right = 0;
            }
            if (width == 0 && height == 0)
            {
                flag = 1;
                Console.WriteLine("bounded");
                break;
            }
        }
        if (flag == 0) Console.WriteLine("unbounded");
    }


    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int[] lamps = new int[n+1];
        TurnLampsOn(lamps);
        string directions = Console.ReadLine();
        TheBot(directions);
        directions = Console.ReadLine();
        TheBot(directions);
    }
}
