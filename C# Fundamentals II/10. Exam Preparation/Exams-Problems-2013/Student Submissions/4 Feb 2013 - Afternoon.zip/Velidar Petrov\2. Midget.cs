using System;

class Midget
{
    static int[] valley;

    static void Main(string[] args)
    {
        string valleyStr = Console.ReadLine();

        valley = ParseCommaSeparatedIntArray(valleyStr);

        int patternCount = int.Parse(Console.ReadLine());

        long maxCoins = 0;

        for (int i = 0; i < patternCount; i++)
        {
            int[] currentPattern 
                = ParseCommaSeparatedIntArray(Console.ReadLine());

            long currentCoinCount = RunPattern(currentPattern);
            if (currentCoinCount > maxCoins)
            {
                maxCoins = currentCoinCount;
            }
        }
        Console.WriteLine(maxCoins);
    }

    static int[] ParseCommaSeparatedIntArray(string input)
    {
        string[] inputArray = input.Split(new char[] { ',' }
    , StringSplitOptions.RemoveEmptyEntries);

        int[] array = new int[inputArray.Length];

        for (int i = 0; i < inputArray.Length; i++)
        {
            array[i] = int.Parse(inputArray[i]);
        }
        return array;
    }

    static long RunPattern(int[] pattern)
    {
        bool[] visited = new bool[valley.Length];

        long coinCount = 0;

        int patternLength = pattern.Length;
        int currentPatternPos = 0;
        int currentValleyPos = 0;
        
        while (true)
        {    

            // check if we have "escaped the valley":
            if (currentValleyPos < 0 || currentValleyPos > valley.Length - 1
                || visited[currentValleyPos])
            {
                return coinCount;
            }
            coinCount += valley[currentValleyPos];
            visited[currentValleyPos] = true;

            currentValleyPos +=pattern[currentPatternPos];

            currentPatternPos++;

            if (currentPatternPos > patternLength - 1)
            {
                currentPatternPos = 0;
            }
        }
    }

    static void PrintArray(int[] arr) 
    {
        for (int i = 0; i < arr.Length; i++)
        {
            Console.Write("{0}, ", arr[i]);
        }
    }
}
