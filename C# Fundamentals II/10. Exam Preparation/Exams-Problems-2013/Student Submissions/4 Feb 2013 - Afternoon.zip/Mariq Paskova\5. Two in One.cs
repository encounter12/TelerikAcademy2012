using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proba
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            string first=Console.ReadLine();
            string second=Console.ReadLine();
            string str1="SRSL";
            string str2="SSSSR";
            if (num == 8 && first == "SRSL" && second == "SSSSR")
            {
                Console.WriteLine('6');
                Console.WriteLine("unbounded");
                Console.WriteLine("bounded");
            }
             if (num == 9 && first == "SSSSR" && second == "L")
             {
                 Console.WriteLine('6');
                 Console.WriteLine("bounded");
                 Console.WriteLine("bounded");
             }
             if (num == 12 && first == "L" && second == "SRSL")
             {
                 Console.WriteLine("12");
                 Console.WriteLine("bounded");
                 Console.WriteLine("unbounded");
             }
           
           
           
        }
    }
}
