using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoInOne
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            if (num==20)
            {
                Console.WriteLine("U");
            }
             if (num==30)
            {
                Console.WriteLine("aE");
            }
             if (num == 280)
             {
                 Console.WriteLine("BY");
             }
             if (num == 1000)
             {
                 Console.WriteLine("DhY");
             }
        }
    }
}
