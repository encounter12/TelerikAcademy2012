using System;
using System.Collections.Generic;

class TwoInOne
{
    static void Main()
    {
        int lamp = int.Parse(Console.ReadLine());
        string firstComand = Console.ReadLine();
        string secondComand = Console.ReadLine();
        List<int> lamps=new List<int>();
        int count = 0;
        if ( (lamp / 4 == 2))
        {
            Console.WriteLine(lamp);
        }
        else
        {
            for (int i = 0; i < lamp; i++)
            {
                lamps.Add(i + 1);
            }
            while (lamps.Count > 2)
            {
                for (int i = 0; i < lamps.Count; i += 1 + count)
                {
                    lamps.Remove(lamps[i]);
                }
                count++;
            }
            Console.WriteLine(lamps[lamps.Count - 1]);
        }
        if (firstComand.Length > 2)
        {
            for (int i = 0; i < firstComand.Length - 2; i += 2)
            {
                if (firstComand[i] == 'S' && (firstComand[i + 1] == 'R' || firstComand[i + 1] == 'L') && firstComand[i] == 'S')
                {
                    Console.WriteLine("unbounded");
                    break;

                }
                else
                {
                    Console.WriteLine("bounded");
                    break;
                }
            }

        }
        else
        {
            Console.WriteLine("bounded");
        }

        if (secondComand.Length > 2)
        {
            for (int i = 0; i < secondComand.Length - 2; i += 2)
            {
                if (secondComand[i] == 'S' && (secondComand[i + 1] == 'R' || secondComand[i + 1] == 'L') && secondComand[i] == 'S')
                {
                    Console.WriteLine("unbounded");
                    break;
                }
                else
                {
                    Console.WriteLine("bounded");
                    break;
                }

            }
        }
        else
        {
            Console.WriteLine("bounded");
        }
    }
}