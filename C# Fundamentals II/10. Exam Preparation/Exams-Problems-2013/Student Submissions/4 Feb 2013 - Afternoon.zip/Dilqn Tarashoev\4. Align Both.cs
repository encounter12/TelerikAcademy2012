using System;
using System.Collections.Generic;
using System.Text;

class alignBoth
{
    public static void Main()
    {
        //Console.WriteLine("Enter the number of lines, pls:");
        //int n = int.Parse(Console.ReadLine());
        int n = 5;
        //Console.WriteLine("Enter the number of symbols in a line, pls:");
        //int w = int.Parse(Console.ReadLine());
        int w = 20;
        //Console.WriteLine("Paste the text for justifying");
        //string text = Console.ReadLine();

        string text = "We happy few        we band \n of brothers for he who sheds \n his blood \n with \n me small be my brother";
        string[] words = text.Split(' ', '.', ',', '?', '!', ':', '-', ';');
        int wCount = words.Length;
        string gap = new string();
        gap = " ";

        List<string> line = new List<string>();
        for (i = 0; i <=wC; i++)
        {
            string line + string words[i] = string line
        }
        
        if line.Count <= w continue
        else Console.WriteLine(line);
        string[] counter = line.Split(' ');
        int lCount = counter.Lenght

        List<string> line = new List<string>();
        for (i = lCount; i <=wC; i++)
        {
            string line + string words[i] = string line
        }
        
        if line.Count <= w continue
        else Console.WriteLine(line);
    }
}