using System;
using System.Collections.Generic;

class Midget
{
    static void Main()
    {
        string valley = Console.ReadLine();

        int[] valleyInt = StringLineToIntArr(valley);

        int M = int.Parse(Console.ReadLine());

        List<int[]> patterns = new List<int[]>();

        for (int i = 0; i < M; i++)
        {
            string pattern = Console.ReadLine();
            patterns.Add(StringLineToIntArr(pattern));
        }
        long MaxSum = int.MinValue;
        foreach (var pattern in patterns)
        {
            bool[] visited = new bool[valleyInt.Length];
            int pos = 0;
            visited[0] = true;
            long tempSum = valleyInt[0];
            pos += pattern[0];
            for (int i = 1; (pos < valleyInt.Length && pos >= 0) && !visited[pos]; i++)
            {
                tempSum += valleyInt[pos];
                visited[pos] = true;
                pos += pattern[i % pattern.Length];
            }
            if (tempSum > MaxSum)
            {
                MaxSum = tempSum;
            }
        }
        Console.WriteLine(MaxSum);
    }

    private static int[] StringLineToIntArr(string valley)
    {
        string[] valleyList = valley.Split(new string[] { ", " }, StringSplitOptions.None);

        int[] valleyInt = new int[valleyList.Length];

        for (int i = 0; i < valleyList.Length; i++)
        {
            valleyInt[i] = int.Parse(valleyList[i]);
        }

        return valleyInt;
    }
}