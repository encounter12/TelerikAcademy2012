using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace _22222
{
    class Program
    {
        static void Main()
        {
            List<char> letters= new List<char>(); 
            BigInteger num = BigInteger.Parse(Console.ReadLine());
            char smallLetter = ' ';
            char bigLetter = ' ';
            while (num > 0)
            {
                BigInteger transition = num % 256;
                int reminder = (int) transition;
                if (reminder <= 25)
                {
                    bigLetter = Convert.ToChar(reminder + 65);
                    letters.Add(bigLetter);
                }
                else
                {
                    smallLetter = Convert.ToChar((reminder / 26) + 96);
                    bigLetter = Convert.ToChar((reminder % 26) + 65);                    
                    letters.Add(bigLetter);
                    letters.Add(smallLetter);
                }
                num /= 256;
            }
            for (int i = letters.Count-1; i >= 0; i--)
            {
                Console.Write(letters[i]);
            }
        }
    }
}
