using System;
using System.Text;

class Justification
{
    static void Main(string[] args)
    {
        StringBuilder text = new StringBuilder();
        int n = int.Parse(Console.ReadLine());
        int w = int.Parse(Console.ReadLine());
        for (int p = 0; p < n; p++)
        {
            text.AppendLine(Console.ReadLine());
        }

        string[] words = text.ToString().Split(new char[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
        StringBuilder output = new StringBuilder();
        StringBuilder line = new StringBuilder();

        int i = 0;
        int currentWordCount = 0;
        if (words.Length == 0)
        {
            return;
        }
        while (true)
        {
            if (line.Length + words[i].Length <= w)
            {
                line.Append(words[i] + ' ');
                currentWordCount++;
                if (++i >= words.Length)
                {
                    line.Remove(line.Length - 1, 1);
                    build(line, w, currentWordCount);
                    output.AppendLine(line.ToString());
                    break;
                }
            }
            else
            {
                line.Remove(line.Length - 1, 1);
                build(line, w, currentWordCount);
                output.AppendLine(line.ToString());

                currentWordCount = 0;
                line.Clear();
            }
        }
        Console.WriteLine(output.ToString());

    }

    static void build(StringBuilder sb, int w, int lineCount)
    {
        if (lineCount == 1)
        {
            return;
        }
        if (sb.Length == w)
        {
            return;
        }
        int i = 0;
        while (i < sb.Length && sb.Length < w)
        {
            if (sb[i++] == ' ')
            {
                sb.Insert(i, " ", 1);
                while (sb[i] == ' ')
                {
                    i++;
                }
            }
        }
        build(sb, w, lineCount);


    }
}