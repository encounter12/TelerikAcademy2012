using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midget
{
    class Program
    {
        static void Main(string[] args)
        {
            string valley = Console.ReadLine();
            int n = int.Parse(Console.ReadLine());
            string patt;
            int maxSum = 0;
            for (int i = 0; i < n; i++)
            {
                patt = Console.ReadLine();
                int sum = Collect(valley, patt);
                if (sum > maxSum)
                {
                    maxSum = sum;
                }
            }
            Console.WriteLine(maxSum);
         
        }

        private static int Collect(string str,string str2)
        {
            try
            {

           
           
            string[] num = str.Split(',');
            int[] valley = new int[str.Length];

            for (int i = 0; i < num.Length; i++)
            {
                valley[i] = int.Parse(num[i]);
            }

            
            string[] patt = str2.Split(',');
            int[] pattern = new int[patt.Length];

            for (int i = 0; i < patt.Length; i++)
            {
                pattern[i] = int.Parse(patt[i]);
            }


            bool[] steps = new bool[valley.Length];
            
            int sum = 0;
            for (int i = 0, p = 0; i < valley.Length; )
            {

                if (steps[i] == true)
                {
                    break;
                }
                try
                {
                    sum += valley[i];
                    steps[i] = true;
                    if (p == pattern.Length)
                    {
                        p = 0;
                    }
                    i += pattern[p];
                    p++;

                }
                catch (IndexOutOfRangeException)
                {

                    break;
                }

            }
            return sum;
            }
            catch (IndexOutOfRangeException)
            {

                return -1;
            }
        }
    }
}
