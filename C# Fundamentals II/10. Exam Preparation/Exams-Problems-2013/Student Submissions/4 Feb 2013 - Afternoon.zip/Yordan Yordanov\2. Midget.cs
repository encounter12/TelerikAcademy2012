using System;
using System.Collections.Generic;

class Midget
{
    static void Main()
    {
        string[] inputValeyString = Console.ReadLine().Split(',',' ');
        List<int> valeyNumbers = new List<int>();
        foreach (var item in inputValeyString)
        {
            if (item != "")
            {
                valeyNumbers.Add(int.Parse(item));
            }
        }
        int inputM = int.Parse(Console.ReadLine());
        List<List<int>> patternsList = new List<List<int>>();
        for (int i = 0; i < inputM; i++)
        {
            patternsList.Add(new List<int>());
            string[] tempLine = Console.ReadLine().Split(',',' ');
            foreach (var item in tempLine)
            {
                if (item!="") patternsList[i].Add(int.Parse(item));
            }
        }
        int bestCollected = int.MinValue;
        foreach (var list in patternsList)
        {
            bool[] visitedPositions = new bool[valeyNumbers.Count];
            int currentCollected = valeyNumbers[0];
            visitedPositions[0] = true;
            int nextPosition = list[0];
            int listIndex = 1;
            while (nextPosition>=0 && nextPosition<valeyNumbers.Count && !visitedPositions[nextPosition])
            {
                currentCollected += valeyNumbers[nextPosition];
                visitedPositions[nextPosition] = true;
                nextPosition += list[listIndex];
                listIndex++;
                if (listIndex >= list.Count)
                {
                    listIndex = 0;
                }
            }
            if (bestCollected < currentCollected)
            {
                bestCollected = currentCollected;
            }
        }
        Console.WriteLine(bestCollected);
    }
}