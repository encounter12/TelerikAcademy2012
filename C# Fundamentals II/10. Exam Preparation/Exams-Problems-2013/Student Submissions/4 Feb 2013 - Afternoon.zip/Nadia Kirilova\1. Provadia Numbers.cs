using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace readCarefully
{
    class readCerefully
    {
        static void Main(string[] args)
        {
            string[] array = new string[256 * 256];
            string[] list1 = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
            string[] list2 = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };

            for (int i = 0; i <= 25; i++)
            {
                array[i] = list2[i];
            }
            //int n = 0;
            //int m = 0;
            //string element = list1[n] + list2[m];
            for (ulong i = 26; i < ((256 * 256)-2*(10*25)); i++)
            {

                for (int n = 0; n <= 10; n++) //65536-526
                {
                    for (int m = 0; m <= 25; m++)
                    {
                        array[i] = list1[n] + list2[m];
                        i = i + 1;
                    }
                }
                for (int n = 0; n <= 10; n++) //65536-526
                {
                    for (int m = 0; m <= 25; m++)
                    {
                        array[i] = list2[n] + list2[m];
                        i = i + 1;
                    }
                }
            }
            int number = int.Parse(Console.ReadLine());
            Console.WriteLine(array[number]);
        }
    }
}
