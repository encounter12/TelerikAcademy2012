using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[256];
            string[] str = new string[256 * 256];
            int i = 0;
            int a = 0;
                       
               for(int j = 65; j <= 90; j++, i++)
               {
                    char ch = (char)j;
                    str[i] = ch.ToString();
                    a = i + 1;
               }            
             
                
                    
                for (int k = 97; k <= 122; k++)
                {
                    for (int b = 0; b < 26; b++, a++)
                    {
                        char ch2 = (char)k;
                        str[a] = ch2.ToString() + str[b];
                    }
                }

                int input = int.Parse(Console.ReadLine());
                Console.WriteLine(str[input]);
            
           
        }
    }
}
