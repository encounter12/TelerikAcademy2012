using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        
        //static void Arr()
        
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            char[] separator = {','};
            string[] digitStr = input.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            int[] digit = new int[digitStr.Length];
            int sum = 0;
            int bestSum = 0;
            for (int i = 0; i < digitStr.Length; i++)
            {
                digit[i] = Convert.ToInt32(digitStr[i]);
            }
            
            int valueM = int.Parse(Console.ReadLine());
            int[,] arr = new int[valueM, 100];
            for (int i = 0; i < valueM; i++)
            {
                string str = Console.ReadLine();
                string[] currStr = str.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                for (int j = 0; j < currStr.Length; j++)
                {
                    arr[i, j] = Convert.ToInt32(currStr[j]);
                }
            }

            //for (int i = 0; i < valueM; i++)
            //{
            //    for (int j = 0; j < 10; j++)
            //    {
            //        Console.Write(arr[i,j] + " ");
            //    }
            //    Console.WriteLine();
            //}
            for (int i = 0; i < valueM; i++)
            {
                sum = digit[0];
                for (int j = 0; j < 100; j++)
                {
                    sum += digit[arr[i, j]];
                    if (sum > bestSum)
                    {
                        bestSum = sum;
                    }
                }
                Console.WriteLine(sum);
            }
        }
    }
}
