using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine("No");
            Console.WriteLine(2+ " " +2+ " "+ 0);
        }
    }
}
