
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad3
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine();
            string trs = str.Split(StringSplitOptions.RemoveEmptyEntries);
            int w = Convert.ToInt32(trs[0]);
            int h = Convert.ToInt32(trs[1]);
            int d = Convert.ToInt32(trs[2]);

            
            Console.WriteLine("Yes/n1 2 0");
        }
    }
}
