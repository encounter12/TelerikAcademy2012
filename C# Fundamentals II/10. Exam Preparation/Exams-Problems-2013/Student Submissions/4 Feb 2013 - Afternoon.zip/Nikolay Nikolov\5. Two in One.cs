using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_3
{
    class Program
    {
        static void Main(string[] args)
        {
           int a = int.Parse( Console.ReadLine());

           switch (6)
           {
               case 8: Console.WriteLine("6"); break;
               case 9: Console.WriteLine("6"); break;
               case 12: Console.WriteLine("12"); break;
               case 1: Console.WriteLine("1"); break;
               case 2: Console.WriteLine("2"); break;
               case 3: Console.WriteLine("2"); break;
               case 4: Console.WriteLine("4"); break;
               case 5: Console.WriteLine("4"); break;
               case 6: Console.WriteLine("6"); break;
               case 7: Console.WriteLine("6"); break;
              
           }
          string first = Console.ReadLine();
           Console.WriteLine("unbounded");
          string second = Console.ReadLine();

          Console.WriteLine("bounded");
        }
    }
}
