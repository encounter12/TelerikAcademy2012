using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProvadiaNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal number = decimal.Parse(Console.ReadLine());
            decimal a = number % 26;
            decimal c = number / 256;
            decimal b = number / 26;

            if (number <= 25)
            {
                Console.WriteLine((char)(a + 65));
            }
            else if (number <=255)
            {
                Console.Write((char)(b + 96));
                Console.WriteLine((char)(a + 65));
            }
            else if (number <= 511)
            {
                Console.Write((char)(c + 65));
                Console.WriteLine((char)(a + 69));
            }
            else
            {
                Console.Write((char)(c + 65));
                Console.Write((char)(c+101));
                Console.WriteLine((char)(a+69));
            }
            

        }
    }
}