using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProvadiaNumbers
{
    class ProvadiaNumbers
    {
        static ulong[] convert(ulong decimalNum)
        {
            ulong d = 256;
            ulong[] newNumber = new ulong[32];
            int j = 0;
            while (decimalNum > 0)
            {
                newNumber[j] = decimalNum % d;
                decimalNum /= d;
                j++;
            }
            ulong[] provadia = new ulong[j];
            int z = 0;
            for (int i = j - 1; i >= 0; i--)
            {
                provadia[i] = newNumber[i];
            }
            return provadia;
        }
        static void Main(string[] args)
        {
            ulong number = ulong.Parse(Console.ReadLine());
            ulong[] arr = new ulong[100];
            StringBuilder provadia=new StringBuilder();
            ulong[] provadiaNum = convert(number);
            for (int i = provadiaNum.Length-1; i >=0; i--)
            {
                if (provadiaNum[i] < 26)
                {
                    provadia.Append((char)(provadiaNum[i]+17+'0'));
                }
                else 
                {
                    char first = (char)(provadiaNum[i] / 26 + 48+'0');
                    char second = (char)(provadiaNum[i] % 26 + 17+'0');
                    provadia.Append(first);
                    provadia.Append(second);
                }
            }
            if (number == 0)
            {
                Console.WriteLine("A");
            }
            else Console.WriteLine(provadia);
        }
    }
}
