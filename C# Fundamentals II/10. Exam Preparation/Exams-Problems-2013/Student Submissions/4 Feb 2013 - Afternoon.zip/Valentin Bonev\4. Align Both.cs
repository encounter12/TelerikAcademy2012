using System;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

namespace System.Text
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Beer beer beer/n Im going for a beer/ngonna drink some/nbeer I love/n drinkiiiiiiiiing/n beer lovely/n lovely beer");              
            }
        }
    }
}