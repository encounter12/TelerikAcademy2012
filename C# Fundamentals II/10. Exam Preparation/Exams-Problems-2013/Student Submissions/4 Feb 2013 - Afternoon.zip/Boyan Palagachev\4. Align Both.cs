using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04.JustifyText
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int W = int.Parse(Console.ReadLine());
            StringBuilder line = new StringBuilder();
            for (int i = 0; i < N; i++)
            {
                string input = Console.ReadLine();
                line.Append(input);
                line.Append("\r\n");
            }
            string[] words = line.ToString().Split(new char[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            int index = 0;
            int indexCorenctor = 0;

            while (indexCorenctor < words.Length)
            {
                index = indexCorenctor;
                int commonLength = 0;
                int wordsToTake = 0;

                while (commonLength < W && index < words.Length)
                {
                    commonLength += words[index].Length;

                    if (commonLength < W)
                    {
                        wordsToTake++;
                    }
                    else
                    {
                        commonLength -= words[index].Length + 1;
                        break;
                    }
                    index++;
                }
                if (commonLength == W)
                {
                    commonLength -= words[index].Length;
                    index--;
                }
                int whitespaces = W - commonLength;
                int middleSpaces;
                if (wordsToTake != 1)
                {
                    middleSpaces = whitespaces / (wordsToTake-1);
                }
                else
                {
                    middleSpaces = 0;

                }
                
                StringBuilder bla = new StringBuilder();
                for (int i = index - wordsToTake; i < index - 1; i++)
                {
                    bla.Append(words[i] + new string(' ', middleSpaces));

                }
                bla.Append(words[index - 1].Trim());
                int newIndex = 0;
                if (wordsToTake == 1)
                {
                      bla.Insert(0, new string(' ', W-commonLength));

                }
                if (bla.Length >W)
                {
                    for (int i = 0; i < bla.Length; i++)
                    {
                        if (bla[i] =='0')
                        {
                            bla.Remove(i, 1);
                            break;
                        }
                    }
                }
                if (bla.Length < W)
                {
                    while (index<bla.Length+1)
                    {
                        if (bla[newIndex] == ' ')
                        {
                            bla.Insert(newIndex, ' ');
                            index++;
                        }
                        newIndex++;
                        if (bla.Length >= W)
                        {
                            break;
                        }
                        if (newIndex >= bla.Length)
                        {
                            newIndex = 0;
                        }
                    }
                  
                }

                Console.WriteLine(bla);
                indexCorenctor += wordsToTake;

            }



        }
    }
}
