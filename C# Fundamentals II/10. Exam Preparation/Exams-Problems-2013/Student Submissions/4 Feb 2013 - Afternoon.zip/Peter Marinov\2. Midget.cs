using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha2
{
    class Program
    {
        static int[] valley;
        static int GoThoughPattern(string StringPattern)
        {
            int coins = 0;
            int[] valleyHolder = new int[valley.Length];
            for (int i = 0; i < valley.Length; i++)
            {
                valleyHolder[i] = valley[i];
            }
            string[] dummyPatter = StringPattern.Split(',');
            
            int[] pattern = new int[dummyPatter.Count<string>()];
            for (int i = 0; i < pattern.Length; i++)
            {
                pattern[i] = int.Parse(dummyPatter[i]);
            }
            int position = 0;
            
            while(true)
            {
                bool outOfValley = false;
                bool beenHere = false;

                for (int i = 0; i < pattern.Length; i++)
			    {  
                    
                    if (valleyHolder[position] != 0)
                    {
                        coins += valleyHolder[position];
                        valleyHolder[position] = 0;
                        position += pattern[i];
                        if (position > valley.Length-1||position<0)
                        {
                            outOfValley = true;
                            break;
                        }

                    }
                    else
                    {
                        beenHere = true;
                        break;
                    }
                    
			    }
                if (beenHere||outOfValley) break;

            }
                
           
           
            return coins;
        }

        static void Main(string[] args)
        {
            string stringValley = Console.ReadLine();
            int m =int.Parse(Console.ReadLine());
            string[] patterns = new string[m];
            string[] dummyPatter = stringValley.Split(',');

            valley=new int[dummyPatter.Count<string>()];
            for (int i = 0; i < valley.Length; i++)
            {
                valley[i] = int.Parse(dummyPatter[i]);
            }

            int[] coinsCollected= new int[m];
            for (int i = 0; i < m; i++)
            {
                patterns[i] = Console.ReadLine();
            }
            for (int i = 0; i < patterns.Length; i++)
            {
                coinsCollected[i] = GoThoughPattern(patterns[i]);
            }
            Console.WriteLine(coinsCollected.Max());
        }
    }
}
/*
1, 3, -6, 7, 4, 1, 12
3
1, 2, -3
1, 3, -2
1, -1

*/