using System;
using System.Globalization;
using System.Numerics;
using System.Text;

namespace Task1
{
	class Task1
	{
		static void Main()
		{
			BigInteger n = BigInteger.Parse(Console.ReadLine());
			Console.WriteLine(DecimalTo256(n));
		}

		public static string DecimalTo256(BigInteger value)
		{
			if(value == 0)
			{
				return "A";
			}

			string sign = "";
			if(value < 0)
			{
				sign = "-";
				value = value*(-1);
			}

			var result = new StringBuilder();
			int position = 0;
			while (value > 0)
			{
				string n = GetChar(value, position);
				result.Insert(0, n);
				value = value/256;
				position++;
			}

			return sign + result;
		}

		private static string GetChar(BigInteger value, int position)
		{
			value = value%256;

			string result = null;
			if(value<26)
			{
				result = ((char) (value + 65)).ToString(CultureInfo.InvariantCulture);
			}
			else if (value>=26 && value<52)
			{
				result = "a";
				value = value%26;
				result += ((char) (value + 65)).ToString();
			}
			else if (value>=52 && value<78)
			{
				result = "b";
				value = value%26;
				result += ((char) (value + 65)).ToString();
			}
			else if (value>=78 && value<104)
			{
				result = "c";
				value = value%26;
				result += ((char) (value + 65)).ToString();
			}
			else if (value>=104 && value<130)
			{
				result = "d";
				value = value%26;
				result += ((char) (value + 65)).ToString();
			}
			else if (value>=130 && value<156)
			{
				result = "e";
				value = value%26;
				result += ((char) (value + 65)).ToString();
			}
			else if (value>=156 && value<182)
			{
				result = "f";
				value = value%26;
				result += ((char) (value + 65)).ToString();
			}
			else if (value>=182 && value<208)
			{
				result = "g";
				value = value%26;
				result += ((char) (value + 65)).ToString();
			}
			else if (value>=208 && value<234)
			{
				result = "h";
				value = value%26;
				result += ((char) (value + 65)).ToString();
			}
			else if (value>=234 && value<256)
			{
				result = "i";
				value = value%26;
				result += ((char) (value + 65)).ToString();
			}
			else
			{
				throw new IndexOutOfRangeException();
			}

			return result;
		}
	}
}
