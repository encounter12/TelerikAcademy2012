using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main()
        {
            string sequence = Console.ReadLine();
            string[] valley = sequence.Split(',');

            int M = int.Parse(Console.ReadLine());
            string[] pattern = new string[M];
            for (int i = 0; i < M; i++)
            {
                pattern[i] = Console.ReadLine();
            }

            int maxSum = int.MinValue;

            for (int i = 0; i < M; i++)
            {
                
                int currentPosition = 0;
                int secondPosition=0;
                int currentSum = 0;
                string[] newpatt = pattern[i].Trim().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        
                for (int j = 0; j < newpatt.Length; j++)
                {
                    

                        currentSum += int.Parse(valley[currentPosition]);
                        currentPosition += int.Parse(newpatt[j]);
                        secondPosition = currentPosition;
                }
                secondPosition = currentPosition;
                for (int s = newpatt.Length-1; s >= 0; s--)
                {
                    secondPosition += int.Parse(newpatt[s]);
                    if (secondPosition >= valley.Length || secondPosition == currentPosition)
                    {
                        break;
                    }
                    currentSum += int.Parse(newpatt[s]);
                }

                    if (currentSum > maxSum)
                    {
                        maxSum = currentSum;
                    }
                


            }
            Console.WriteLine(maxSum);
        }
    }
        