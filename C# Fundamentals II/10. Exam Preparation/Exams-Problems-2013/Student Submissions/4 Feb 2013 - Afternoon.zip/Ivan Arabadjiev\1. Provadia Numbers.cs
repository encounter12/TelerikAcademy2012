using System;

class Program
{
    static void Main()
    {
        string[] digits = new string[256];
        for (int i = 0; i < 26; i++)
        {
            digits[i] = ((char)(65 + i)).ToString();
        }
        for (int i = 26; i < 256; i++)
        {
            digits[i] = digits[i / 26 - 1].ToLower() + digits[i % 26];
        }
        ulong number = ulong.Parse(Console.ReadLine());
        System.Text.StringBuilder result = new System.Text.StringBuilder();
        System.Collections.Generic.List<int> numbersDec = new System.Collections.Generic.List<int>();
        if (number == 0)
        {
            Console.WriteLine("A");
        }
        while (number > 0)
        {
            numbersDec.Add((int)(number % 256));
            number /= 256;
        }
        for (int i = numbersDec.Count - 1; i >= 0; i--)
        {
            result.Append(digits[numbersDec[i]]);
        }
        Console.WriteLine(result);
    }
}
