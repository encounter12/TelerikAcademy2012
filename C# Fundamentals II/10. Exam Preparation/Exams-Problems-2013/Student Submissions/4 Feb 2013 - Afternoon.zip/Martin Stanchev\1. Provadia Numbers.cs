using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1
{
    class Program
    {
        static void Main()
        {
            int a = System.Int32.Parse(Console.ReadLine());
            decimal b = Convert.ToDecimal(a);

            var array = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };

            var array2 = new string[254];
            for (int i = 0; i < 26; i++)
            {

                array2[i] = array[i];

            }
            for (int i = 26; i < 52; i++)
            {
                array2[i] = "a" + array[i - 26];
            }
            for (int i = 52; i < 77; i++)
            {
                array2[i] = "b" + array[i - 52];
            }
            for (int i = 77; i < 103; i++)
            {
                array2[i] = "c" + array[i - 77];
            }
            for (int i = 103; i < 129; i++)
            {
                array2[i] = "d" + array[i - 103];
            }
            for (int i = 129; i < 155; i++)
            {
                array2[i] = "e" + array[i - 129];
            }

            Console.WriteLine(array2[a]);
        }
    }
}