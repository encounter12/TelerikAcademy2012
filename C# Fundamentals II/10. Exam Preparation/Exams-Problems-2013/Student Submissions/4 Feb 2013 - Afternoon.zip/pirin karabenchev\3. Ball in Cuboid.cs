using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class BallInCuboid
{
    static int W, H, D;
    static Point pos;

    class Point
    {
        public int w;
        public int h;
        public int d;

        public Point(int w, int h, int d)
        {
            this.w = w;
            this.h = h;
            this.d = d;
        }
    }

    static void Main()
    {
        string[] dimensions = Console.ReadLine().Split();
        W = int.Parse(dimensions[0]);
        H = int.Parse(dimensions[1]);
        D = int.Parse(dimensions[2]);

        string[,,] cube = new string[W, H, D];
        for (int h = 0; h < H; h++)
        {
            string[] groups = Console.ReadLine().Split('|');
            for (int d = 0; d < D; d++)
            {
                string[] cubes = groups[d].Split(')');
                for (int w = 0; w < W; w++)
                {
                    cube[w, h, d] = cubes[w].Substring(1);
                }
            }
        }

        dimensions = Console.ReadLine().Split();
        pos = new Point(int.Parse(dimensions[0]), 0, int.Parse(dimensions[1]));

        bool go = true;
        bool escaped = false;
        Point lastPos = new Point(0, 0, 0);
        while (go)
        {
            lastPos = new Point(pos.w,pos.h,pos.d);
            string currentCube = cube[pos.w, pos.h, pos.d];
            switch (currentCube[0])
            {
                case 'S':
                    DoSlide(currentCube);
                    break;
                case 'T':
                    DoTeleport(currentCube);
                    break;
                case 'E':
                    pos.h++;
                    break;
                case 'B':
                    go = false;
                    break;
            }
            if (pos.h == H)
            {
                pos = lastPos;
                escaped = true;
                go = false;
            }
            else if (pos.w < 0 || pos.w >= W ||pos.d < 0 || pos.d >= D)
            {
                pos = lastPos;
                escaped = false;
                go = false;
            }
        }

        if (escaped)
        {
            Console.WriteLine("Yes");
        }
        else
        {
            Console.WriteLine("No");
        }

        Console.WriteLine("{0} {1} {2}", pos.w, pos.h, pos.d);
    }

    static void DoSlide(string cube)
    {
        string direction = cube.Substring(2);

        switch (direction)
        {
            case "FL":
                pos.d--;
                pos.w--;
                break;
            case "L":
                pos.w--;
                break;
            case "BL":
                pos.d++;
                pos.w--;
                break;
            case "B":
                pos.d++;
                break;
            case "BR":
                pos.d++;
                pos.w++;
                break;
            case "R":
                pos.w++;
                break;
            case "FR":
                pos.d--;
                pos.w++;
                break;
            case "F":
                pos.d--;
                break;
        }
        pos.h++;
    }

    static void DoTeleport(string cube)
    {
        string[] teleport = cube.Split();
        pos.w = int.Parse(teleport[1]);
        pos.d = int.Parse(teleport[2]);
    }
}