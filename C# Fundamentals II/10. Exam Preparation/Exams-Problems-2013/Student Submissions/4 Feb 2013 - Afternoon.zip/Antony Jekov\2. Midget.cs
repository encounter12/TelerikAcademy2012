using System;
using System.Collections.Generic;

class Problem02_Midget
{
    static void Main()
    {
        //   1, 3, -6, 7, 4, 1, 12
        //   3
        //   1, 2, -3
        //   1, 3, -2
        //   1, -1

        List<int> visitedPoints = new List<int>(1000);
        char[] separators = {' ', ',' };
        string[] valeyInput = Console.ReadLine().Split(separators, StringSplitOptions.RemoveEmptyEntries);
        int[] valey = new int[valeyInput.Length];
        for (int i = 0; i < valeyInput.Length; i++)
        {
            valey[i] = int.Parse(valeyInput[i]);
        }

        int M = int.Parse(Console.ReadLine());
        long maxCount = long.MinValue;

        for (int pattern = 0; pattern < M; pattern++)
        {
            string[] currentPattern = Console.ReadLine().Split(separators, StringSplitOptions.RemoveEmptyEntries);

            int valeyPosition = 0;
            int patternPosition = 0;

            long count = 0;
            bool isVisited = false;

            while (valeyPosition > -1 && valeyPosition < valey.Length)
            {
                for (int visited = 0; visited < visitedPoints.Count; visited++)
                {
                    if (valeyPosition == visitedPoints[visited])
                    {
                        isVisited = true;
                        break;
                    }
                }
                if (isVisited)
                {
                    break;
                }

                count += valey[valeyPosition];
                visitedPoints.Add(valeyPosition);
                valeyPosition += int.Parse(currentPattern[patternPosition++]);

                if (patternPosition > currentPattern.Length - 1)
                {
                    patternPosition = 0;
                }
            }
            if (count > maxCount)
            {
                maxCount = count;
            }
            visitedPoints.Clear();
        }
        Console.WriteLine(maxCount);
    }
}