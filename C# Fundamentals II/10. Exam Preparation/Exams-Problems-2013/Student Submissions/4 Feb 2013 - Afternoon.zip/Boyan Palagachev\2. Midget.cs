using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Midget
{
    static void Main()
    {
        List<short> valley = ParseValley(Console.ReadLine());
        int numberOfPatterns = int.Parse(Console.ReadLine());

        List<List<short>> allPatterns = new List<List<short>>();
        for (int i = 0; i < numberOfPatterns; i++)
        {
            List<short> pattern = ParseValley(Console.ReadLine());
            allPatterns.Add(pattern);
        }

        int bestCoins = -10001;

        foreach (var item in allPatterns)
        {
            int indexer = 0;
            int i = 0; 
            bool[] beenThere = new bool[valley.Count];
            int currentCoint = valley[0];
            beenThere[0] = true;
           while(true)
            {
                i += item[indexer];
                indexer++;
                if (indexer > item.Count-1)
                {
                    indexer = 0;
                }
                //Console.WriteLine(i);
                if (i > valley.Count - 1 || i < 0)
                {
                    // we are out
                    break;
                }

                if (beenThere[i] == true)
                {
                    break;
                }
                currentCoint += valley[i];
                beenThere[i] = true;
                //i++;
                
            }
            if (currentCoint>bestCoins)
            {
                bestCoins = currentCoint;
            }
            
            
        }
        Console.WriteLine(bestCoins);
        ////Console.WriteLine("Rakiq i salata: {0}", bestCoins);
        ////// print all patterns
        ////for (int i = 0; i < allPatterns.Count; i++)
        ////{
        ////    for (int j = 0; j < allPatterns[i].Count; j++)
        ////    {
        ////        Console.Write(allPatterns[i][j] + "   ");
        ////    }
        ////    Console.WriteLine();
        ////}
    }
    static List<short> ParseValley(string line)
    {
        List<short> valley = new List<short>();
        string[] numbers = line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        foreach (var item in numbers)
        {
            valley.Add(short.Parse(item));
        }
        return valley;
    }
}
