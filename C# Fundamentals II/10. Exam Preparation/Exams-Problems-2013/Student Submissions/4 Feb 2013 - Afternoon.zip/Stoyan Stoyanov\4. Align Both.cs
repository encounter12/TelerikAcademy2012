using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondTask
{
    class Program
    {

        static void Main(string[] args)
        {
            int numberOfLines = int.Parse(Console.ReadLine());
            int lineWidth = int.Parse(Console.ReadLine());
            StringBuilder res = new StringBuilder();
            for (int i = 0; i < 5; i++)
            {
                res.Append(Console.ReadLine());
            }

            Console.WriteLine(res.ToString());
        }
    }
}
