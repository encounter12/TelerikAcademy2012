using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        //string valleyCoinsStr = Console.ReadLine();
        string valleyCoinsStr = "1,3,-6,7,4,1,12";
        int[] valleyCoins = valleyCoinsStr.Split(',').Select(n => Convert.ToInt32(n)).ToArray();

        int m = 3;
        //int m = int.Parse(Console.ReadLine());
        string coinPatternStr = "";
        int[] coinPattern = new int[coinPatternStr.Length];
        List<int> coinPatternSummedPositions = new List<int>();
        int sumPosition = 0;
        int coinPatternSummedValue = 0;


        int index = new int();



        int result = 0;

        for (int i = 0; i < m; i++)
        {
            coinPatternStr = (Console.ReadLine());
            coinPattern = coinPatternStr.Split(',').Select(n => Convert.ToInt32(n)).ToArray();
            for (int j = 0; j < coinPattern.Length; j++)
            {

                for (int k = 0; k <= j; k++)
                {
                    sumPosition = sumPosition + coinPattern[k];
                }

                if ((coinPatternSummedPositions.IndexOf(sumPosition) != -1) || (sumPosition < 0) || (sumPosition >= valleyCoins.Length))
                {
                    break;
                }
                coinPatternSummedPositions.Add(sumPosition);
                sumPosition = 0;
                
            }
            foreach (var position in coinPatternSummedPositions)
            {
                result = result + valleyCoins[position];
            }
            coinPatternSummedPositions.Clear();
        }
        Console.WriteLine(result);
    }
}