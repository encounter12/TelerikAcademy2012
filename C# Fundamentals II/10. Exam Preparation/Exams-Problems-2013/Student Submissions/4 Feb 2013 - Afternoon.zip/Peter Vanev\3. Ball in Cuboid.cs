using System;

class BallInCuboid
{
    static void Main()
    {
        string dimensions = Console.ReadLine();
        string[] eachDim = dimensions.Split(' ');
        int width = int.Parse(eachDim[0]);
        int height = int.Parse(eachDim[1]);
        int depth = int.Parse(eachDim[2]);

        string[, ,] cube = new string[width, height, depth];

        for (int h = 0; h < height; h++)
        {
            string line = Console.ReadLine();
            string[] lines = line.Split('|');
            for (int d = 0; d < depth; d++)
            {
                string[] elements = lines[d].Split(')');
                for (int w = 0; w < width; w++)
                {
                    cube[w, h, d] = elements[w].Trim().Remove(0, 1);
                }
            }
        }

        string start = Console.ReadLine();
        int startW = int.Parse(start.Split(' ')[0]);
        int startD = int.Parse(start.Split(' ')[1]);
        int startH = 0;

        bool inside = true;
        bool movable = true;

        while (inside && movable)
        {
            if (cube[startW, startH, startD] == "B")
                movable = false;
            else if (cube[startW, startH, startD] == "E")
            {
                startH++;
                if (startH == (height - 1))
                {
                    inside = false;
                    break;
                }
            }
            else if (cube[startW, startH, startD][0] == 'T')
            {
                int baseW = startW;
                int baseD = startD;
                string[] coords = cube[startW, startH, startD].Split(' ');
                startW = int.Parse(coords[1]);
                startD = int.Parse(coords[2]);
                if (startD < 0 || startD >= depth || startW < 0 || startW >= width)
                {
                    movable = false;
                    startD = baseD;
                    startW = baseW;
                    break;
                }
            }
            else if (cube[startW, startH, startD][0] == 'S')
            {
                string direction = cube[startW, startH, startD].Split(' ')[1];
                int baseW = startW;
                int baseD = startD;

                if (startH == height - 1)
                {
                    inside = false;
                    break;
                }
                else switch (direction)
                    {
                        case "L": { startW--; startH++; } break;
                        case "R": { startW++; startH++; } break;
                        case "F": { startD--; startH++; } break;
                        case "B": { startD++; startH++; } break;
                        case "FL": { startW--; startD--; startH++; } break;
                        case "FR": { startW++; startD--; startH++; } break;
                        case "BL": { startW--; startD++; startH++; } break;
                        case "BR": { startW++; startD++; startH++; } break;
                    }

                if (startD < 0 || startD >= depth || startW < 0 || startW >= width)
                {
                    movable = false;
                    startD = baseD;
                    startW = baseW;
                    break;
                }
            }
        }

        if (!inside)
            Console.WriteLine("Yes");
        if (!movable)
            Console.WriteLine("No");
        Console.WriteLine(startW + " " + startH + " " + startD);
    }
}
