using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Task1ProvadiaNumbers
{
    class Program
    {
        static string Convert(int number)
        {
            switch (number)
            {
                case 0: return ((char)(number + 'A')).ToString();
                case 1: return ((char)(number + 'A')).ToString();
                case 2: return ((char)(number + 'A')).ToString();
                case 3: return ((char)(number + 'A')).ToString();
                case 4: return ((char)(number + 'A')).ToString();
                case 5: return ((char)(number + 'A')).ToString();
                case 6: return ((char)(number + 'A')).ToString();
                case 7: return ((char)(number + 'A')).ToString();
                case 8: return ((char)(number + 'A')).ToString();
                case 9: return ((char)(number + 'A')).ToString();
                case 10: return ((char)(number + 'A')).ToString();
                case 11: return ((char)(number + 'A')).ToString();
                case 12: return ((char)(number + 'A')).ToString();
                case 13: return ((char)(number + 'A')).ToString();
                case 14: return ((char)(number + 'A')).ToString();
                case 15: return ((char)(number + 'A')).ToString();
                case 16: return ((char)(number + 'A')).ToString();
                case 17: return ((char)(number + 'A')).ToString();
                case 18: return ((char)(number + 'A')).ToString();
                case 19: return ((char)(number + 'A')).ToString();
                case 20: return ((char)(number + 'A')).ToString();
                case 21: return ((char)(number + 'A')).ToString();
                case 22: return ((char)(number + 'A')).ToString();
                case 23: return ((char)(number + 'A')).ToString();
                case 24: return ((char)(number + 'A')).ToString();
                case 25: return ((char)(number + 'A')).ToString();
                case 26: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 27: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 28: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 29: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 30: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 31: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 32: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 33: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 34: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 35: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 36: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 37: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 38: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 39: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 40: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 41: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 42: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 43: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 44: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 45: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 46: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 47: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 48: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 49: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 50: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 51: return "a" + ((char)(number % 26 + 'A')).ToString();
                case 52: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 53: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 54: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 55: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 56: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 57: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 58: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 59: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 60: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 61: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 62: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 63: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 64: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 65: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 66: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 67: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 68: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 69: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 70: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 71: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 72: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 73: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 74: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 75: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 76: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 77: return "b" + ((char)(number % 26 + 'A')).ToString();
                case 78: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 79: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 80: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 81: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 82: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 83: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 84: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 85: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 86: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 87: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 88: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 89: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 90: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 91: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 92: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 93: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 94: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 95: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 96: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 97: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 98: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 99: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 100: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 101: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 102: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 103: return "c" + ((char)(number % 26 + 'A')).ToString();
                case 104: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 105: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 106: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 107: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 108: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 109: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 110: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 111: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 112: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 113: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 114: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 115: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 116: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 117: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 118: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 119: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 120: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 121: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 122: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 123: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 124: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 125: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 126: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 127: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 128: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 129: return "d" + ((char)(number % 26 + 'A')).ToString();
                case 130: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 131: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 132: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 133: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 134: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 135: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 136: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 137: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 138: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 139: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 140: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 141: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 142: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 143: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 144: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 145: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 146: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 147: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 148: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 149: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 150: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 151: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 152: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 153: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 154: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 155: return "e" + ((char)(number % 26 + 'A')).ToString();
                case 156: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 157: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 158: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 159: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 160: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 161: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 162: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 163: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 164: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 165: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 166: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 167: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 168: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 169: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 170: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 171: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 172: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 173: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 174: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 175: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 176: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 177: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 178: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 179: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 180: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 181: return "f" + ((char)(number % 26 + 'A')).ToString();
                case 182: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 183: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 184: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 185: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 186: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 187: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 188: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 189: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 190: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 191: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 192: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 193: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 194: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 195: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 196: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 197: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 198: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 199: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 200: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 201: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 202: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 203: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 204: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 205: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 206: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 207: return "g" + ((char)(number % 26 + 'A')).ToString();
                case 208: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 209: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 210: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 211: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 212: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 213: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 214: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 215: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 216: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 217: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 218: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 219: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 220: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 221: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 222: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 223: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 224: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 225: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 226: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 227: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 228: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 229: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 230: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 231: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 232: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 233: return "h" + ((char)(number % 26 + 'A')).ToString();
                case 234: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 235: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 236: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 237: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 238: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 239: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 240: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 241: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 242: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 243: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 244: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 245: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 246: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 247: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 248: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 249: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 250: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 251: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 252: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 253: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 254: return "i" + ((char)(number % 26 + 'A')).ToString();
                case 255: return "i" + ((char)(number % 26 + 'A')).ToString();
                default: return "baba";
            }
        }

        static void Main(string[] args)
        {
            //string builder
            BigInteger input = BigInteger.Parse(Console.ReadLine());
            if (input == 0)
            {
                Console.WriteLine('A');
            }
            else
            {
                int baba = 0;
                List<string> result = new List<string>();
                while (input > 0)
                {

                    baba = (int)(input % 256);

                    result.Add(Convert(baba));
                    //for (int i = 0; i < result.Count; i++)
                    //{
                    //    Console.WriteLine(result[i]);

                    //}
                    input /= 256;
                }
                result.Reverse();
                StringBuilder cool = new StringBuilder();
                for (int i = 0; i < result.Count; i++)
                {
                    cool.Append(result[i]);

                }
                Console.WriteLine(cool.ToString());
            }
        }
    }
}
