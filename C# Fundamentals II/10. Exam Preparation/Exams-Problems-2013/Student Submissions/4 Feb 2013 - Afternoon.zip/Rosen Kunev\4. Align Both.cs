using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AlignBoth
{
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int W = int.Parse(Console.ReadLine());

            StringBuilder sb = new StringBuilder();

            string[] textArray = UserInput(n, sb);

            int[] wordLength = new int[textArray.Length];
            int wordLen = 0;
            for (int i = 0; i < textArray.Length; i++)
			{
			    for (int j = 0; j < textArray[i].Length; j++)
                {
                    wordLen++;
                    
                }
                wordLength[i] = wordLen;
                wordLen = 0;
			}




            int curLineLen = 0;
            sb.Clear();
            int count = 0;
            List<string> lines = new List<string>();

            for (int i = 0; i < textArray.Length; i++)
            {
                curLineLen += wordLength[i];
                if (curLineLen + count < W)
                {
                    sb.Append(textArray[i]);

                    sb.Append(' ');
                    count++;
                }
                else
                {
                    lines.Add(sb.ToString());
                    curLineLen = 0;
                    sb.Clear();
                    i--;
                    count = 0;
                }
                if (i+1 ==  textArray.Length)
                {
                    lines.Add(sb.ToString());
                }
            }
            foreach (var item in lines)
            {
                Console.WriteLine(item);
            }
            //for (int i = 0; i < lines.Count; i++)
            //{

            //}

            
            
            
        }

        private static string[] UserInput(int n, StringBuilder sb)
        {
            for (int i = 0; i < n; i++)
            {
                string line = Console.ReadLine();
                sb.Append(line);
                if (i < n - 1)
                {
                    sb.Append(' ');
                }

            }
            string text = sb.ToString();
            string[] textArray = text.Split(' ');
            return textArray;
        }
    }
}
